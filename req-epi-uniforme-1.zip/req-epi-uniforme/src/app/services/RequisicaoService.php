<?php

namespace src\app\services;

use PDO;
use src\app\database\Database;
use src\app\database\entities\CrachaProvisorio;
use src\app\database\entities\Item;
use src\app\database\entities\Requisicao;
use src\app\database\entities\RequisicaoItem;

/**
 * Requisição de EPI's e Uniformes pelos Operadores (2.1.1.4).
 *
 * Fluxo: leitura do crachá → identificação do colaborador (Foracesso +
 * Logix/Sênior) → escolha EPI/Uniforme → seleção dos itens → confirmação.
 */
class RequisicaoService
{
    /** Código da empresa no Logix (funcionario, cargo, MX_CARGO_EPI). */
    private const COD_EMPRESA_LOGIX = '40';

    // ===================== Identificação do colaborador ===================

    /**
     * Identifica o colaborador a partir do número lido do crachá.
     *
     * Primeiro verifica se o número está na lista de crachás provisórios
     * (sincronizada do Foracesso). Se estiver e ainda não tiver nome de uso
     * registrado hoje, devolve 'situacao' => 'provisorio_pendente' para a
     * tela pedir matrícula/nome de quem está usando o crachá naquele dia.
     * Caso contrário, consulta o Foracesso (crachá → matrícula) e o
     * Logix (dados completos do colaborador).
     *
     * @return array{situacao:string, matricula:string, nome:string, centro_custo:?string, unidade_funcional:?string, cargo:?string, cracha_provisorio:bool}
     */
    public function identificarPorCracha(string $cracha): array
    {
        $cracha = trim($cracha);
        if ($cracha === '') {
            return $this->situacaoNaoEncontrado();
        }

        $provisorio = CrachaProvisorio::selectOne()->whereEquals('numero_cracha', $cracha)->finish();
        if ($provisorio) {
            return $this->identificarCrachaProvisorio($provisorio);
        }

        $matricula = $this->buscarMatriculaNoForacesso($cracha);
        if (!$matricula) {
            return $this->situacaoNaoEncontrado();
        }

        $dados = $this->buscarColaboradorNoLogix($matricula);
        if (!$dados) {
            return $this->situacaoNaoEncontrado();
        }

        return $this->situacaoIdentificado($dados, false);
    }

    /** Resolve a situação de um crachá já cadastrado como provisório. */
    private function identificarCrachaProvisorio(CrachaProvisorio $provisorio): array
    {
        $usadoHoje = $provisorio->data_uso === date('Y-m-d') && !empty($provisorio->matricula_uso);
        if (!$usadoHoje) {
            return [
                'situacao'          => 'provisorio_pendente',
                'matricula'         => '',
                'nome'              => '',
                'centro_custo'      => null,
                'unidade_funcional' => null,
                'cargo'             => null,
                'cracha_provisorio' => true,
            ];
        }

        $dados = $this->buscarColaboradorNoLogix((string) $provisorio->matricula_uso) ?? [
            'matricula'         => (string) $provisorio->matricula_uso,
            'nome'              => (string) $provisorio->nome_uso,
            'centro_custo'      => null,
            'unidade_funcional' => null,
            'cargo'             => null,
        ];
        return $this->situacaoIdentificado($dados, true);
    }

    /**
     * Registra a matrícula/nome de quem está usando um crachá provisório
     * hoje, e devolve os dados completos do colaborador (Logix).
     */
    public function registrarUsoCrachaProvisorio(string $numeroCracha, string $matricula, string $nome): array
    {
        $matricula = trim($matricula);
        $nome      = trim($nome);

        $dados = [
            'status'        => 'em_uso',
            'matricula_uso' => $matricula,
            'nome_uso'      => $nome,
            'data_uso'      => date('Y-m-d'),
            'hora_uso'      => date('H:i:s'),
            'sincronizado'  => 0,
            'updated_at'    => date('Y-m-d H:i:s'),
        ];

        $existente = CrachaProvisorio::selectOne()->whereEquals('numero_cracha', $numeroCracha)->finish();
        if ($existente) {
            CrachaProvisorio::update($dados)->whereEquals('uuid', $existente->uuid)->finish();
        } else {
            $dados['numero_cracha'] = $numeroCracha;
            CrachaProvisorio::create($dados);
        }

        $colaborador = $this->buscarColaboradorNoLogix($matricula) ?? [
            'matricula'         => $matricula,
            'nome'              => $nome,
            'centro_custo'      => null,
            'unidade_funcional' => null,
            'cargo'             => null,
        ];
        return $this->situacaoIdentificado($colaborador, true);
    }

    /** Monta o retorno padrão de colaborador identificado. */
    private function situacaoIdentificado(array $dados, bool $crachaProvisorio): array
    {
        $dados['situacao']          = 'identificado';
        $dados['cracha_provisorio'] = $crachaProvisorio;
        return $dados;
    }

    /** Monta o retorno padrão de crachá não identificado. */
    private function situacaoNaoEncontrado(): array
    {
        return [
            'situacao'          => 'nao_encontrado',
            'matricula'         => '',
            'nome'              => '',
            'centro_custo'      => null,
            'unidade_funcional' => null,
            'cargo'             => null,
            'cracha_provisorio' => false,
        ];
    }

    // ===================== Foracesso — crachá → matrícula ==================

    /**
     * Query que resolve a matrícula do colaborador a partir do código do
     * crachá (mifare) lido no leitor.
     *
     * A regra dá preferência ao crachá definitivo (IDMT_TIPOUTILIZACAO = 3)
     * de quem tem exatamente um crachá provisório ativo; quando isso não se
     * aplica, cai para a segunda metade da UNION, que resolve pelo crachá
     * provisório (IDMT_TIPOUTILIZACAO = 2) do colaborador ativo.
     */
    private const SQL_MATRICULA_POR_MIFARE = "
        SELECT DISTINCT
            M.MATR_MATRICULA AS matricula,
            I.IDTF_CODIGO AS mifare
        FROM FORACESSO.IDENTIFICACAO_MATRICULADO I
        INNER JOIN FORACESSO.MATRICULADO M
            ON I.MATR_ID = M.MATR_ID
        INNER JOIN FORACESSO.MATRICULADO_ALOCACAO A
            ON I.MATR_ID = A.MATR_ID
        WHERE I.MATR_ID IN (
            SELECT M.MATR_ID
            FROM FORACESSO.IDENTIFICACAO_MATRICULADO I
            INNER JOIN FORACESSO.MATRICULADO M
                ON I.MATR_ID = M.MATR_ID
            INNER JOIN FORACESSO.MATRICULADO_ALOCACAO A
                ON I.MATR_ID = A.MATR_ID
            WHERE I.MATR_ID IN (
                SELECT MATR_ID
                FROM FORACESSO.IDENTIFICACAO_MATRICULADO
                WHERE MATR_ID NOT IN (
                    SELECT MATR_ID
                    FROM FORACESSO.IDENTIFICACAO_MATRICULADO
                    WHERE IDMT_TIPOUTILIZACAO = '2'
                    AND IDMT_VALIDADE IS NULL
                    GROUP BY MATR_ID
                    HAVING COUNT(MATR_ID) > 1
                )
                AND MATR_ID IN (
                    SELECT MATR_ID
                    FROM FORACESSO.IDENTIFICACAO_MATRICULADO
                    WHERE IDMT_TIPOUTILIZACAO = '3'
                    AND IDMT_VALIDADE >= GETDATE()
                    AND IDMT_BAIXA IS NULL
                )
            )
            AND I.IDMT_TIPOUTILIZACAO = '2'
            AND I.IDMT_VALIDADE IS NULL
            AND A.EMPR_ID = '4'
        )
        AND I.IDMT_TIPOUTILIZACAO = '3'
        AND I.IDMT_BAIXA IS NULL
        AND A.EMPR_ID = '4'
        AND M.CNTR_ID IS NULL
        AND A.LOTA_ID NOT IN ('65')
        AND I.IDTF_CODIGO = ?

        UNION ALL

        SELECT DISTINCT
            M.MATR_MATRICULA AS matricula,
            I.IDTF_CODIGO AS mifare
        FROM FORACESSO.IDENTIFICACAO_MATRICULADO I
        INNER JOIN FORACESSO.MATRICULADO M
            ON I.MATR_ID = M.MATR_ID
        INNER JOIN FORACESSO.MATRICULADO_ALOCACAO A
            ON I.MATR_ID = A.MATR_ID
        WHERE I.MATR_ID NOT IN (
            SELECT M.MATR_ID
            FROM FORACESSO.IDENTIFICACAO_MATRICULADO I
            INNER JOIN FORACESSO.MATRICULADO M
                ON I.MATR_ID = M.MATR_ID
            INNER JOIN FORACESSO.MATRICULADO_ALOCACAO A
                ON I.MATR_ID = A.MATR_ID
            WHERE I.MATR_ID IN (
                SELECT M.MATR_ID
                FROM FORACESSO.IDENTIFICACAO_MATRICULADO I
                INNER JOIN FORACESSO.MATRICULADO M
                    ON I.MATR_ID = M.MATR_ID
                INNER JOIN FORACESSO.MATRICULADO_ALOCACAO A
                    ON I.MATR_ID = A.MATR_ID
                WHERE I.MATR_ID IN (
                    SELECT MATR_ID
                    FROM FORACESSO.IDENTIFICACAO_MATRICULADO
                    WHERE MATR_ID NOT IN (
                        SELECT MATR_ID
                        FROM FORACESSO.IDENTIFICACAO_MATRICULADO
                        WHERE IDMT_TIPOUTILIZACAO = '2'
                        AND IDMT_VALIDADE IS NULL
                        GROUP BY MATR_ID
                        HAVING COUNT(MATR_ID) > 1
                    )
                    AND MATR_ID IN (
                        SELECT MATR_ID
                        FROM FORACESSO.IDENTIFICACAO_MATRICULADO
                        WHERE IDMT_TIPOUTILIZACAO = '3'
                        AND IDMT_VALIDADE >= GETDATE()
                        AND IDMT_BAIXA IS NULL
                    )
                )
                AND I.IDMT_TIPOUTILIZACAO = '2'
                AND I.IDMT_VALIDADE IS NULL
                AND A.EMPR_ID = '4'
            )
            AND I.IDMT_TIPOUTILIZACAO = '3'
            AND I.IDMT_BAIXA IS NULL
            AND A.EMPR_ID = '4'
            AND M.CNTR_ID IS NULL
        )
        AND I.IDMT_TIPOUTILIZACAO = '2'
        AND I.IDMT_VALIDADE IS NULL
        AND I.MATR_ID IN (
            SELECT MATR_ID
            FROM FORACESSO.MATRICULADO
            WHERE MATR_ATIVO = '1'
        )
        AND A.EMPR_ID = '4'
        AND M.CNTR_ID IS NULL
        AND A.LOTA_ID NOT IN ('65')
        AND I.IDTF_CODIGO = ?
    ";

    /** Consulta o Foracesso para obter a matrícula a partir do código do crachá. */
    private function buscarMatriculaNoForacesso(string $cracha): ?string
    {
        $stmt = Database::get('foracesso')->prepare(self::SQL_MATRICULA_POR_MIFARE);
        // O parâmetro aparece duas vezes na query (antes e depois do UNION).
        $stmt->execute([$cracha, $cracha]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['matricula'] ?? null;
    }

    // ===================== Logix — dados do colaborador =====================

    private const SQL_COLABORADOR_POR_MATRICULA = "
        SELECT
            f.num_matricula AS matricula,
            f.nom_funcionario AS nome,
            SUBSTR(
                TRIM(f.cod_uni_funcio),
                LENGTH(TRIM(f.cod_uni_funcio)) - 3,
                4
            ) AS centro_custo,
            f.cod_uni_funcio AS unidade_funcional,
            c.den_cargo AS cargo
        FROM funcionario f, mx_mifare m, cargo c
        WHERE m.num_matricula = f.num_matricula
        AND f.cod_cargo = c.cod_cargo
        AND f.cod_empresa = ?
        AND f.cod_empresa = c.cod_empresa
        AND f.num_matricula = ?
    ";

    /**
     * Consulta os dados do colaborador (nome, centro de custo, unidade
     * funcional, cargo) no Logix a partir da matrícula.
     *
     * Nota: o Informix converte identificadores/aliases não citados para
     * MAIÚSCULAS — por isso o fetch abaixo lê as chaves em uppercase mesmo
     * a query usando alias em minúsculo.
     */
    private function buscarColaboradorNoLogix(string $matricula): ?array
    {
        $stmt = Database::get('informix')->prepare(self::SQL_COLABORADOR_POR_MATRICULA);
        $stmt->execute([self::COD_EMPRESA_LOGIX, $matricula]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return null;
        }

        return [
            'matricula'         => trim($row['MATRICULA']),
            'nome'              => trim($row['NOME']),
            'centro_custo'      => trim($row['CENTRO_CUSTO']),
            'unidade_funcional' => trim($row['UNIDADE_FUNCIONAL']),
            'cargo'             => trim($row['CARGO']),
        ];
    }

    // ===================== Itens disponíveis ===============================

    /** @return array<int, object> */
    public function itensPorTipo(string $tipo): array
    {
        return Item::select()->whereEquals('tipo', $tipo)->andWhereIsNull('deleted_at')->order('descricao', 'ASC')->finish() ?: [];
    }

    // ===================== Regra de reserva de EPI (MX_CARGO_EPI) ==========

    private const SQL_EPI_POR_MATRICULA_CARGO = "
        SELECT cod_item
        FROM MX_CARGO_EPI
        WHERE cod_empresa = ?
        AND num_matricula = ?
        AND cod_uni_funcio = ?
        AND cod_cargo = ?
    ";

    private const SQL_EPI_POR_CARGO_PADRAO = "
        SELECT cod_item
        FROM MX_CARGO_EPI
        WHERE cod_empresa = ?
        AND cod_uni_funcio = ?
        AND cod_cargo = ?
        AND num_matricula IS NULL
    ";

    /**
     * Consulta a tabela MX_CARGO_EPI para identificar os EPIs aplicáveis ao
     * colaborador.
     *
     * 1ª validação: matrícula + unidade funcional + cargo.
     * 2ª validação (fallback): unidade funcional + cargo, sem matrícula específica.
     *
     * @return array{regra:string, codigos:array<int,string>}|null 'regra' é 'prioridade_1' ou 'prioridade_2'.
     */
    public function regraCargoEpi(string $matricula, string $unidadeFuncional, string $cargo): ?array
    {
        $db = Database::get('informix');

        $stmt = $db->prepare(self::SQL_EPI_POR_MATRICULA_CARGO);
        $stmt->execute([self::COD_EMPRESA_LOGIX, $matricula, $unidadeFuncional, $cargo]);
        $codigos = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($codigos)) {
            return ['regra' => 'prioridade_1', 'codigos' => $codigos];
        }

        $stmt = $db->prepare(self::SQL_EPI_POR_CARGO_PADRAO);
        $stmt->execute([self::COD_EMPRESA_LOGIX, $unidadeFuncional, $cargo]);
        $codigos = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($codigos)) {
            return ['regra' => 'prioridade_2', 'codigos' => $codigos];
        }

        return null;
    }

    // ===================== Registro da requisição ===========================

    private function proximoNumero(): string
    {
        $ultima = Requisicao::select()->order('id', 'DESC')->limit(1)->finish();
        $seq = 1;
        if ($ultima) {
            $seq = ((int) preg_replace('/\D/', '', (string) $ultima[0]->numero)) + 1;
        }
        return str_pad((string) $seq, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Registra a requisição (cabeçalho + itens).
     *
     * @param array{matricula:string, nome:string, centro_custo:?string, unidade_funcional:?string, cargo:?string, lider_matricula:?string, projeto:?string, cracha_numero:?string, cracha_provisorio:bool, regra_utilizada:?string, observacao:?string} $colaborador
     * @param array<int, array{item_id:?int, item_tipo:string, item_codigo:string, item_descricao:string, quantidade:int, bloqueado?:bool, motivo_bloqueio?:string}> $itens
     */
    public function registrar(array $colaborador, array $itens): object
    {
        $requisicao = Requisicao::create([
            'numero'            => $this->proximoNumero(),
            'matricula'         => $colaborador['matricula'],
            'nome_colaborador'  => $colaborador['nome'],
            'centro_custo'      => $colaborador['centro_custo'] ?? null,
            'unidade_funcional' => $colaborador['unidade_funcional'] ?? null,
            'cargo'             => $colaborador['cargo'] ?? null,
            'lider_matricula'   => $colaborador['lider_matricula'] ?? null,
            'projeto'           => $colaborador['projeto'] ?? null,
            'cracha_numero'     => $colaborador['cracha_numero'] ?? null,
            'cracha_provisorio' => !empty($colaborador['cracha_provisorio']) ? 1 : 0,
            'regra_utilizada'   => $colaborador['regra_utilizada'] ?? null,
            'observacao'        => $colaborador['observacao'] ?? null,
            'data_solicitacao'  => date('Y-m-d'),
            'hora_solicitacao'  => date('H:i:s'),
        ]);

        $requisicaoId = is_object($requisicao) ? ($requisicao->id ?? null) : ($requisicao['id'] ?? null);

        foreach ($itens as $item) {
            RequisicaoItem::insert([
                'requisicao_id'         => $requisicaoId,
                'item_id'               => $item['item_id'] ?? null,
                'item_tipo'             => $item['item_tipo'],
                'item_codigo'           => $item['item_codigo'],
                'item_descricao'        => $item['item_descricao'],
                'quantidade_solicitada' => $item['quantidade'] ?? 1,
                'bloqueado'             => !empty($item['bloqueado']) ? 1 : 0,
                'motivo_bloqueio'       => ($item['motivo_bloqueio'] ?? '') ?: null,
            ])->finish();
        }

        return (object) ['id' => $requisicaoId, 'numero' => $requisicao->numero ?? null];
    }
}
