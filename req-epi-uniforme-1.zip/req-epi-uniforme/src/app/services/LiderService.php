<?php

namespace src\app\services;

use src\app\database\Database;
use src\app\database\entities\Lider;

/**
 * Cadastro de Líderes (2.1.1.2) — dados puxados do Sênior por matrícula
 * ou nome, e mantidos em cópia local para alimentar o formulário de
 * requisição rapidamente.
 */
class LiderService
{
    /** @return array<int, object> */
    public function listAll(): array
    {
        return Lider::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return Lider::getByUuid($uuid);
    }

    public function existeDuplicado(string $matricula, ?string $ignoreUuid = null): bool
    {
        $achados = Lider::select()->whereEquals('matricula', $matricula)->andWhereIsNull('deleted_at')->finish() ?: [];
        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) return true;
        }
        return false;
    }

    /**
     * Busca a matrícula no Sênior.
     *
     * Retorno:
     * [
     *     'matricula' => string,
     *     'nome'      => string
     * ]
     *
     * Retorna null caso não encontre.
     */
    public function buscarPorMatricula(string $matricula): ?array
    {
        $db = Database::get('senior');

        $sql = "
            SELECT 
                numcad,
                nomfun
            FROM senior.r034fun
            WHERE numcad = ?
        ";

        $stmt = $db->prepare($sql);
        $stmt->execute([$matricula]);

        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            return null;
        }

        return [
            'matricula' => (string) $row['numcad'],
            'nome'      => $row['nomfun']
        ];
    }
    public function buscarPorNome(string $nome): array
    {
        $db = Database::get('senior');

        $sql = "
            SELECT 
                numcad,
                nomfun
            FROM senior.r034fun
            WHERE nomfun LIKE ?
        ";

        $stmt = $db->prepare($sql);
        $stmt->execute(['%' . $nome . '%']);

        return $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    public function store(array $d): bool|array|object
    {
        return Lider::create([
            'matricula' => trim((string) $d['matricula']),
            'nome'      => trim((string) $d['nome']),
        ]);
    }

    public function update(string $uuid, array $d): mixed
    {
        return Lider::update([
            'matricula'  => trim((string) $d['matricula']),
            'nome'       => trim((string) $d['nome']),
            'updated_at' => date('Y-m-d H:i:s'),
        ])->whereEquals('uuid', $uuid)->finish();
    }

    public function delete(string $uuid): bool
    {
        Lider::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }
}
