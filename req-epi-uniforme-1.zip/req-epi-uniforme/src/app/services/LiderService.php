<?php

namespace src\app\services;

use PDO;
use src\app\database\Database;
use src\app\database\entities\Lider;

/**
 * Cadastro de Líderes (2.1.1.2) — dados puxados do Sênior por matrícula
 * ou nome, e mantidos em cópia local para alimentar o formulário de
 * requisição rapidamente.
 */
class LiderService
{
    /** @return array<int, object> */
    public function listAll(): array
    {
        return Lider::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return Lider::getByUuid($uuid);
    }

    public function existeDuplicado(string $matricula, ?string $ignoreUuid = null): bool
    {
        $achados = Lider::select()->whereEquals('matricula', $matricula)->andWhereIsNull('deleted_at')->finish() ?: [];
        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) return true;
        }
        return false;
    }

    private const SQL_POR_MATRICULA = "
        SELECT numcad, nomfun
        FROM senior.r034fun
        WHERE numcad = ?
    ";

    private const SQL_POR_NOME = "
        SELECT numcad, nomfun
        FROM senior.r034fun
        WHERE nomfun LIKE ?
    ";

    /** Busca a matrícula no Sênior. Retorna null caso não encontre. */
    public function buscarPorMatricula(string $matricula): ?array
    {
        $stmt = Database::get('senior')->prepare(self::SQL_POR_MATRICULA);
        $stmt->execute([$matricula]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $this->mapRegistro($row) : null;
    }

    /**
     * Busca por nome (quando a pessoa não sabe a matrícula).
     * @return array<int, array{matricula: string, nome: string}>
     */
    public function buscarPorNome(string $nome): array
    {
        $stmt = Database::get('senior')->prepare(self::SQL_POR_NOME);
        $stmt->execute(['%' . $nome . '%']);

        return array_map([$this, 'mapRegistro'], $stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
    }

    /** Normaliza uma linha do Sênior (numcad/nomfun) para o formato usado pela aplicação. */
    private function mapRegistro(array $row): array
    {
        return [
            'matricula' => (string) $row['numcad'],
            'nome'      => trim((string) $row['nomfun']),
        ];
    }

    public function store(array $d): bool|array|object
    {
        return Lider::create([
            'matricula' => trim((string) $d['matricula']),
            'nome'      => trim((string) $d['nome']),
        ]);
    }

    public function update(string $uuid, array $d): mixed
    {
        return Lider::update([
            'matricula'  => trim((string) $d['matricula']),
            'nome'       => trim((string) $d['nome']),
            'updated_at' => date('Y-m-d H:i:s'),
        ])->whereEquals('uuid', $uuid)->finish();
    }

    public function delete(string $uuid): bool
    {
        Lider::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }
}
