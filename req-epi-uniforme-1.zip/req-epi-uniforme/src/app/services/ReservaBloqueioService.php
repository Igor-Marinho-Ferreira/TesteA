<?php

namespace src\app\services;

use PDO;
use Throwable;
use src\app\database\Database;

/**
 * Regra de reposição de EPI/Uniforme (bloqueio de retirada).
 *
 * Portada do projeto lstres-requnif: a regra vive na tabela mx_matseg do
 * Logix, por item (cod_item), e é a MESMA para EPI e uniforme —
 * diferenciando só de onde vêm os dados de histórico (dias/qtd retirada).
 *
 *   BLOQUEADO quando:
 *     dias_desde_ultima_retirada < dias_reposicao
 *     E  qtd_ja_retirada        >= qtd_max_retirada
 *
 * Ex.: uniforme "2 conjuntos em 60 dias" → qtd_max_retirada = 2,
 * dias_reposicao = 60. Ao tentar o 3º conjunto antes dos 60 dias, bloqueia.
 */
class ReservaBloqueioService
{
    /** Código da empresa no Logix. */
    private const COD_EMPRESA_LOGIX = '40';

    /** Regra de reposição por item (versão vigente). */
    private const SQL_REGRA_ITEM = "
        SELECT FIRST 1
            cod_item,
            qtd_max_retirada,
            dias_reposicao
        FROM mx_matseg
        WHERE cod_empresa = :cod_empresa
        AND ies_versao_atual = 'S'
        AND cod_item = :cod_item
    ";

    /** @var array<string, object|null> Cache das regras por item na requisição atual. */
    private array $regraCache = [];

    /**
     * Avalia o status de bloqueio de um item para um colaborador.
     *
     * @return array{status:string, bloqueado:bool, motivo:string}
     *         'status' = 'liberado' | 'bloqueado' | 'indefinido'
     *         'indefinido' = sem regra para o item, ou sem histórico disponível
     *         (fonte de dias/qtd ainda não integrada — ver historicoItemPorMatricula()).
     */
    public function avaliar(string $codItem, string $matricula): array
    {
        $codItem = trim($codItem);
        if ($codItem === '') {
            return $this->indefinido();
        }

        $regra = $this->regraDoItem($codItem);
        if (!$regra) {
            // Item sem regra de reposição cadastrada = sem bloqueio aplicável.
            return $this->liberado();
        }

        $historico = $this->historicoItemPorMatricula($matricula, $codItem);
        if ($historico === null) {
            // Sem fonte de histórico ainda: não dá para afirmar liberado/bloqueado.
            return $this->indefinido();
        }

        $motivo = $this->motivoBloqueio(
            $codItem,
            $historico['dias'] ?? null,
            $historico['qtd_retirada'] ?? null,
            $regra
        );

        return $motivo !== '' ? $this->bloqueado($motivo) : $this->liberado();
    }

    /**
     * Avalia vários itens de uma vez.
     *
     * @param array<int, string> $codItens
     * @return array<string, array{status:string, bloqueado:bool, motivo:string}> indexado por cod_item
     */
    public function avaliarItens(array $codItens, string $matricula): array
    {
        $out = [];
        foreach ($codItens as $codItem) {
            $out[$codItem] = $this->avaliar((string) $codItem, $matricula);
        }
        return $out;
    }

    // ===================== Regra (mx_matseg) ==============================

    /** Busca (com cache) a regra de reposição vigente do item. */
    private function regraDoItem(string $codItem): ?object
    {
        if (array_key_exists($codItem, $this->regraCache)) {
            return $this->regraCache[$codItem];
        }

        $regra = null;
        try {
            $db = Database::get('informix');
            $this->prepararSessaoInformix($db);

            $stmt = $db->prepare(self::SQL_REGRA_ITEM);
            $stmt->bindValue(':cod_empresa', self::COD_EMPRESA_LOGIX);
            $stmt->bindValue(':cod_item', $codItem);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_OBJ);

            $regra = $stmt->fetch() ?: null;
        } catch (Throwable $e) {
            $regra = null;
        }

        return $this->regraCache[$codItem] = $regra;
    }

    // ===================== Histórico (ponto de integração) ================

    /**
     * Retorna o histórico do item para o colaborador: dias desde a última
     * retirada e quantidade já retirada — as duas entradas que a regra do
     * mx_matseg compara.
     *
     * FONTE AINDA NÃO DEFINIDA (aguardando query do cliente):
     *   - Uniforme: relatório de reservas do estoque (intranet), por matrícula + item.
     *   - EPI: status/relatório do Logix ou Power BI, por matrícula + item.
     *
     * Enquanto a query real não chega, retorna null → status 'indefinido'
     * (a tela mostra "verificar manualmente" em vez de liberado/bloqueado).
     *
     * @return array{dias:mixed, qtd_retirada:mixed}|null
     */
    private function historicoItemPorMatricula(string $matricula, string $codItem): ?array
    {
        // TODO: implementar quando a query por matrícula + item for enviada.
        // Retorno esperado: ['dias' => <int>, 'qtd_retirada' => <number>].
        return null;
    }

    // ===================== Avaliação da regra (portado 1:1) ===============

    /**
     * Reproduz a regra de bloqueio do lstres-requnif
     * (UniformWithdrawalReportService::getWithdrawalRuleBlockReason).
     */
    private function motivoBloqueio(string $codItem, mixed $dias, mixed $qtdRetirada, object $regra): string
    {
        $diasAtual        = $this->toNumber($dias);
        $qtdRetiradaAtual = $this->toNumber($qtdRetirada);
        $diasReposicao    = $this->toNumber($regra->dias_reposicao ?? $regra->DIAS_REPOSICAO ?? null);
        $qtdMaxRetirada   = $this->toNumber($regra->qtd_max_retirada ?? $regra->QTD_MAX_RETIRADA ?? null);

        if ($diasAtual === null || $qtdRetiradaAtual === null || $diasReposicao === null || $qtdMaxRetirada === null) {
            return '';
        }

        $diasMenorQueReposicao = $diasAtual < $diasReposicao;
        $qtdMenorQueMaxima     = $qtdRetiradaAtual < $qtdMaxRetirada;

        if ($diasMenorQueReposicao && !$qtdMenorQueMaxima) {
            return
                'Retirada bloqueada. O item ' . $codItem .
                ' possui apenas ' . $this->formatNumber($diasAtual) .
                ' dia(s) desde a última retirada, mas exige ' .
                $this->formatNumber($diasReposicao) .
                ' dia(s) para reposição. A quantidade total considerada foi ' .
                $this->formatNumber($qtdRetiradaAtual) .
                ', e a retirada só é permitida antes desse prazo quando a quantidade total for menor que ' .
                $this->formatNumber($qtdMaxRetirada) . '.';
        }

        return '';
    }

    // ===================== Helpers =======================================

    private function prepararSessaoInformix(PDO $db): void
    {
        try { $db->exec('SET ISOLATION TO DIRTY READ'); } catch (Throwable $e) {}
        try { $db->exec('SET LOCK MODE TO WAIT 10'); } catch (Throwable $e) {}
    }

    private function toNumber(mixed $value): ?float
    {
        if ($value === null) return null;
        $value = str_replace(' ', '', trim((string) $value));
        if ($value === '') return null;

        if (str_contains($value, ',') && str_contains($value, '.')) {
            $value = str_replace('.', '', $value);
            $value = str_replace(',', '.', $value);
        } else {
            $value = str_replace(',', '.', $value);
        }

        return is_numeric($value) ? (float) $value : null;
    }

    private function formatNumber(float $value): string
    {
        if (floor($value) == $value) return (string) ((int) $value);
        return number_format($value, 3, ',', '.');
    }

    private function liberado(): array
    {
        return ['status' => 'liberado', 'bloqueado' => false, 'motivo' => ''];
    }

    private function bloqueado(string $motivo): array
    {
        return ['status' => 'bloqueado', 'bloqueado' => true, 'motivo' => $motivo];
    }

    private function indefinido(): array
    {
        return ['status' => 'indefinido', 'bloqueado' => false, 'motivo' => ''];
    }
}
