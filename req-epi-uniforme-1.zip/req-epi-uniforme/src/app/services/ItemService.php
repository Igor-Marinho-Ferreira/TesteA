<?php

namespace src\app\services;

use src\app\database\Database;
use src\app\database\entities\Item;

/**
 * Cadastro de EPI's e Uniformes (2.1.1.1).
 *
 * O código é sempre validado contra o Logix (Informix) e a descrição é
 * sempre a que vier de lá — nunca digitada manualmente.
 */
class ItemService
{
    private const DIR_REL   = 'itens';
    private const ALLOWED   = ['png', 'jpg', 'jpeg', 'webp'];
    private const MAX_BYTES = 5_242_880; // 5 MB

    /** @return array<int, object> */
    public function listAll(): array
    {
        return Item::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return Item::getByUuid($uuid);
    }

    public function existeDuplicado(string $codigo, ?string $ignoreUuid = null): bool
    {
        $achados = Item::select()->whereEquals('codigo', $codigo)->andWhereIsNull('deleted_at')->finish() ?: [];
        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) return true;
        }
        return false;
    }

    /**
     * Busca o item no Logix (Informix) pelo código, para preencher a
     * descrição automaticamente e validar que o código existe.
     *
     * Retorno:
     * [
     *     'codigo' => string,
     *     'descricao' => string
     * ]
     *
     * Retorna null caso o item não seja encontrado.
     */
    public function buscarNoLogix(string $codigo): ?array
    {
        $db = Database::get('informix');

        $sql = "
            SELECT 
                cod_item AS codigo,
                den_item AS descricao
            FROM item
            WHERE cod_empresa = '40'
            AND cod_item = ?
        ";

        $stmt = $db->prepare($sql);
        $stmt->execute([$codigo]);

        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            return null;
        }

        return [
            'codigo'    => $row['codigo'],
            'descricao' => $row['descricao']
        ];
    }

    /** Valida o arquivo de imagem enviado (opcional). Retorna erro ou null. */
    public function imagemError(): ?string
    {
        $f = $_FILES['imagem'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
        if ($f['error'] !== UPLOAD_ERR_OK) return 'Falha no envio da imagem.';
        if ($f['size'] > self::MAX_BYTES) return 'A imagem excede o tamanho máximo de 5 MB.';
        $ext = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, self::ALLOWED, true)) return 'Tipo inválido. Use PNG, JPG ou WEBP.';
        return null;
    }

    private function moverImagem(): ?string
    {
        $f = $_FILES['imagem'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;

        $dirAbs = rtrim(path()->storage_server(''), '/') . '/' . self::DIR_REL;
        if (!is_dir($dirAbs)) mkdir($dirAbs, 0775, true);

        $ext  = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
        $nome = bin2hex(random_bytes(8)) . '.' . $ext;
        if (move_uploaded_file($f['tmp_name'], $dirAbs . '/' . $nome)) {
            return self::DIR_REL . '/' . $nome;
        }
        return null;
    }

    public function store(array $d): bool|array|object
    {
        return Item::create([
            'tipo'      => (string) $d['tipo'],
            'codigo'    => trim((string) $d['codigo']),
            'descricao' => trim((string) $d['descricao']),
            'imagem'    => $this->moverImagem(),
        ]);
    }

    public function update(string $uuid, array $d): mixed
    {
        $fields = [
            'tipo'       => (string) $d['tipo'],
            'codigo'     => trim((string) $d['codigo']),
            'descricao'  => trim((string) $d['descricao']),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        $img = $this->moverImagem();
        if ($img) $fields['imagem'] = $img;
        return Item::update($fields)->whereEquals('uuid', $uuid)->finish();
    }

    public function delete(string $uuid): bool
    {
        Item::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }
}
