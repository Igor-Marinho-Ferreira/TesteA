<?php

namespace src\app\services;

use PDO;
use src\app\database\Database;
use src\app\database\entities\Item;

/**
 * Cadastro de EPI's e Uniformes (2.1.1.1).
 *
 * O código é sempre validado contra o Logix (Informix) e a descrição é
 * sempre a que vier de lá — nunca digitada manualmente.
 */
class ItemService
{
    private const DIR_REL   = 'itens';
    private const ALLOWED   = ['png', 'jpg', 'jpeg', 'webp'];
    private const MAX_BYTES = 5_242_880; // 5 MB

    /** Código da empresa no Logix. */
    private const COD_EMPRESA_LOGIX = '40';

    /**
     * Cabeçalho obrigatório do arquivo de importação, na ordem exata.
     * A validação bloqueia o upload se o cabeçalho não bater.
     */
    public const COLUNAS_IMPORT = ['Tipo', 'Código', 'Descrição'];

    private const SQL_ITEM_POR_CODIGO = "
        SELECT cod_item AS codigo, den_item AS descricao
        FROM item
        WHERE cod_empresa = ?
        AND cod_item = ?
    ";

    /** @return array<int, object> */
    public function listAll(): array
    {
        return Item::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return Item::getByUuid($uuid);
    }

    public function existeDuplicado(string $codigo, ?string $ignoreUuid = null): bool
    {
        $achados = Item::select()->whereEquals('codigo', $codigo)->andWhereIsNull('deleted_at')->finish() ?: [];
        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) return true;
        }
        return false;
    }

    /**
     * Busca o item no Logix (Informix) pelo código, para preencher a
     * descrição automaticamente e validar que o código existe.
     *
     * Retorna null caso o item não seja encontrado.
     */
    public function buscarNoLogix(string $codigo): ?array
    {
        $stmt = Database::get('informix')->prepare(self::SQL_ITEM_POR_CODIGO);
        $stmt->execute([self::COD_EMPRESA_LOGIX, $codigo]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return null;
        }

        return [
            'codigo'    => $row['codigo'],
            'descricao' => $row['descricao'],
        ];
    }

    /** Valida o arquivo de imagem enviado (opcional). Retorna erro ou null. */
    public function imagemError(): ?string
    {
        $f = $_FILES['imagem'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
        if ($f['error'] !== UPLOAD_ERR_OK) return 'Falha no envio da imagem.';
        if ($f['size'] > self::MAX_BYTES) return 'A imagem excede o tamanho máximo de 5 MB.';
        $ext = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, self::ALLOWED, true)) return 'Tipo inválido. Use PNG, JPG ou WEBP.';
        return null;
    }

    private function moverImagem(): ?string
    {
        $f = $_FILES['imagem'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;

        $dirAbs = rtrim(path()->storage_server(''), '/') . '/' . self::DIR_REL;
        if (!is_dir($dirAbs)) mkdir($dirAbs, 0775, true);

        $ext  = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
        $nome = bin2hex(random_bytes(8)) . '.' . $ext;
        if (move_uploaded_file($f['tmp_name'], $dirAbs . '/' . $nome)) {
            return self::DIR_REL . '/' . $nome;
        }
        return null;
    }

    public function store(array $d): bool|array|object
    {
        return Item::create([
            'tipo'      => (string) $d['tipo'],
            'codigo'    => trim((string) $d['codigo']),
            'descricao' => trim((string) $d['descricao']),
            'imagem'    => $this->moverImagem(),
        ]);
    }

    public function update(string $uuid, array $d): mixed
    {
        $fields = [
            'tipo'       => (string) $d['tipo'],
            'codigo'     => trim((string) $d['codigo']),
            'descricao'  => trim((string) $d['descricao']),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        $img = $this->moverImagem();
        if ($img) $fields['imagem'] = $img;
        return Item::update($fields)->whereEquals('uuid', $uuid)->finish();
    }

    public function delete(string $uuid): bool
    {
        Item::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    // ===================== IMPORTAÇÃO EM LOTE =============================

    /**
     * Importa um arquivo (.xlsx ou .csv) de itens (Tipo, Código, Descrição),
     * validando o cabeçalho, o tipo e a duplicidade de código.
     *
     * @return array{ok:bool, inseridos:int, erros:array<int,string>}
     */
    public function importar(string $tmpPath, string $nomeOriginal): array
    {
        $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));

        try {
            if ($ext === 'csv') {
                $linhas = $this->lerCsv($tmpPath, ';');
            } elseif ($ext === 'xlsx') {
                $linhas = $this->lerXlsx($tmpPath);
            } else {
                return ['ok' => false, 'inseridos' => 0, 'erros' => ['Formato não permitido. Use .xlsx ou .csv.']];
            }
        } catch (\Throwable $e) {
            return ['ok' => false, 'inseridos' => 0, 'erros' => ['Falha ao ler o arquivo: ' . $e->getMessage()]];
        }

        if (empty($linhas)) {
            return ['ok' => false, 'inseridos' => 0, 'erros' => ['Arquivo vazio.']];
        }

        // 1ª linha = cabeçalho; deve bater com o layout esperado.
        $cabecalho = array_map(fn($c) => $this->normalizarCabecalho((string) $c), array_shift($linhas));
        $esperado  = array_map(fn($c) => $this->normalizarCabecalho($c), self::COLUNAS_IMPORT);

        if (array_slice($cabecalho, 0, count($esperado)) !== $esperado) {
            return [
                'ok' => false,
                'inseridos' => 0,
                'erros' => ['Cabeçalho inválido. As colunas devem seguir exatamente o layout: ' . implode(' | ', self::COLUNAS_IMPORT)],
            ];
        }

        $inseridos = 0;
        $erros = [];
        foreach ($linhas as $i => $linha) {
            $numLinha = $i + 2; // +1 header, +1 base 1
            if (count(array_filter($linha, fn($v) => trim((string) $v) !== '')) === 0) {
                continue; // linha vazia
            }
            $c = array_pad($linha, count(self::COLUNAS_IMPORT), '');

            $tipo      = $this->normalizarTipo((string) $c[0]);
            $codigo    = trim((string) $c[1]);
            $descricao = trim((string) $c[2]);

            if ($tipo === null) {
                $erros[] = "Linha {$numLinha}: Tipo inválido (use 'EPI' ou 'Uniforme').";
                continue;
            }
            if ($codigo === '') {
                $erros[] = "Linha {$numLinha}: Código é obrigatório.";
                continue;
            }
            if ($descricao === '') {
                $erros[] = "Linha {$numLinha}: Descrição é obrigatória.";
                continue;
            }
            if ($this->existeDuplicado($codigo)) {
                $erros[] = "Linha {$numLinha}: já existe item com o código '{$codigo}'.";
                continue;
            }

            $this->store(['tipo' => $tipo, 'codigo' => $codigo, 'descricao' => $descricao]);
            $inseridos++;
        }

        return ['ok' => $inseridos > 0, 'inseridos' => $inseridos, 'erros' => $erros];
    }

    /** Aceita EPI/EPIs/Uniforme/Uniformes (com ou sem acento) → 'epi' | 'uniforme' | null. */
    private function normalizarTipo(string $tipo): ?string
    {
        $t = mb_strtolower(trim($tipo), 'UTF-8');
        $t = strtr($t, ['á'=>'a','à'=>'a','ã'=>'a','â'=>'a','é'=>'e','ê'=>'e','í'=>'i','ó'=>'o','ô'=>'o','õ'=>'o','ú'=>'u','ç'=>'c']);
        if (in_array($t, ['epi', 'epis'], true)) return 'epi';
        if (in_array($t, ['uniforme', 'uniformes'], true)) return 'uniforme';
        return null;
    }

    private function normalizarCabecalho(string $s): string
    {
        $s = trim($s);
        $s = preg_replace('/\s+/', ' ', $s);
        return mb_strtolower($s, 'UTF-8');
    }

    /**
     * Lê um CSV em uma matriz de linhas.
     * @return array<int, array<int, string>>
     */
    private function lerCsv(string $path, string $sep = ';'): array
    {
        $linhas = [];
        if (($h = fopen($path, 'r')) !== false) {
            while (($row = fgetcsv($h, 0, $sep)) !== false) {
                $linhas[] = array_map(fn($v) => (string) $v, $row);
            }
            fclose($h);
        }
        // Remove BOM da primeira célula, se houver.
        if (isset($linhas[0][0])) {
            $linhas[0][0] = preg_replace('/^\xEF\xBB\xBF/', '', $linhas[0][0]);
        }
        return $linhas;
    }

    /**
     * Leitor mínimo de XLSX via ZipArchive + SimpleXML (sem dependência externa).
     * Lê a primeira planilha e resolve as sharedStrings.
     * @return array<int, array<int, string>>
     */
    private function lerXlsx(string $path): array
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new \RuntimeException('Extensão zip do PHP não disponível para ler .xlsx (use .csv).');
        }
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) {
            throw new \RuntimeException('Não foi possível abrir o .xlsx.');
        }

        // Shared strings
        $shared = [];
        $ssXml = $zip->getFromName('xl/sharedStrings.xml');
        if ($ssXml !== false) {
            $ss = simplexml_load_string($ssXml);
            if ($ss !== false) {
                foreach ($ss->si as $si) {
                    $txt = '';
                    if (isset($si->t)) {
                        $txt = (string) $si->t;
                    } else {
                        foreach ($si->r as $r) {
                            $txt .= (string) $r->t;
                        }
                    }
                    $shared[] = $txt;
                }
            }
        }

        // Primeira planilha
        $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
        $zip->close();
        if ($sheetXml === false) {
            throw new \RuntimeException('Planilha não encontrada no .xlsx.');
        }

        $xml = simplexml_load_string($sheetXml);
        $linhas = [];
        foreach ($xml->sheetData->row as $row) {
            $celulas = [];
            $colIdx = 0;
            foreach ($row->c as $c) {
                $ref = (string) $c['r'];
                $col = $this->colToIndex(preg_replace('/\d+/', '', $ref));
                while ($colIdx < $col) { $celulas[$colIdx] = ''; $colIdx++; }

                $val = '';
                $t = (string) $c['t'];
                if ($t === 's') {
                    $idx = (int) $c->v;
                    $val = $shared[$idx] ?? '';
                } elseif ($t === 'inlineStr') {
                    $val = (string) $c->is->t;
                } else {
                    $val = (string) $c->v;
                }
                $celulas[$colIdx] = $val;
                $colIdx++;
            }
            $linhas[] = $celulas;
        }
        return $linhas;
    }

    /** Converte referência de coluna (A, B, ..., AA) em índice 0-based. */
    private function colToIndex(string $letters): int
    {
        $letters = strtoupper($letters);
        $n = 0;
        for ($i = 0; $i < strlen($letters); $i++) {
            $n = $n * 26 + (ord($letters[$i]) - 64);
        }
        return $n - 1;
    }
}
