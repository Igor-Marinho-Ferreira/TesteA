<?php

namespace src\app\services;

use src\app\database\entities\Requisicao;
use src\app\database\entities\RequisicaoItem;

/**
 * Relatório de Requisição de EPIs e Uniformes (2.1.1.5).
 */
class RelatorioRequisicaoService
{
    /**
     * @param array{data_inicial?:string, data_final?:string, matricula?:string} $filtros
     * @return array<int, object> uma linha por item requisitado (requisição + item)
     */
    public function listar(array $filtros = []): array
    {
        $query = Requisicao::select()->whereIsNull('deleted_at');

        if (!empty($filtros['data_inicial']) && !empty($filtros['data_final'])) {
            $query = $query->andWhereBetween('data_solicitacao', $filtros['data_inicial'], $filtros['data_final']);
        }
        if (!empty($filtros['matricula'])) {
            $query = $query->andWhereEquals('matricula', trim((string) $filtros['matricula']));
        }

        $requisicoes = $query->order('data_solicitacao', 'DESC')->finish() ?: [];

        $linhas = [];
        foreach ($requisicoes as $r) {
            $itens = RequisicaoItem::select()->whereEquals('requisicao_id', $r->id)->finish() ?: [];
            foreach ($itens as $item) {
                $linhas[] = (object) [
                    'matricula'            => $r->matricula,
                    'nome_colaborador'     => $r->nome_colaborador,
                    'centro_custo'         => $r->centro_custo,
                    'unidade_funcional'    => $r->unidade_funcional,
                    'cargo'                => $r->cargo,
                    'numero_requisicao'    => $r->numero,
                    'data_solicitacao'     => $r->data_solicitacao,
                    'hora_solicitacao'     => $r->hora_solicitacao,
                    'cracha_provisorio'    => (bool) $r->cracha_provisorio,
                    'regra_utilizada'      => $r->regra_utilizada,
                    'item_tipo'            => $item->item_tipo,
                    'item_codigo'          => $item->item_codigo,
                    'item_descricao'       => $item->item_descricao,
                    'quantidade_solicitada' => $item->quantidade_solicitada,
                    'quantidade_atendida'  => $item->quantidade_atendida,
                    'bloqueado'            => (bool) ($item->bloqueado ?? false),
                    'motivo_bloqueio'      => $item->motivo_bloqueio ?? null,
                    'observacao'           => $r->observacao ?? null,
                    'status'               => $item->status,
                ];
            }
        }
        return $linhas;
    }
}
