<?php
$this->layout('templates/base', [
    'webTitle'  => 'Relatório de Requisições',
    'cardTitle' => 'Relatório de Requisição de EPIs e Uniformes',
    'backTo'    => route('menu'),
]);
$filtros = $filtros ?? ['data_inicial' => '', 'data_final' => '', 'matricula' => ''];
?>

<form action="<?= route('relatorio.index') ?>" method="GET" class="row g-3 align-items-end mb-4">
    <div class="col-6 col-md-3">
        <label class="form-label">Data inicial</label>
        <input type="date" name="data_inicial" class="form-control" value="<?= htmlspecialchars($filtros['data_inicial']) ?>">
    </div>
    <div class="col-6 col-md-3">
        <label class="form-label">Data final</label>
        <input type="date" name="data_final" class="form-control" value="<?= htmlspecialchars($filtros['data_final']) ?>">
    </div>
    <div class="col-12 col-md-3">
        <label class="form-label">Matrícula</label>
        <input type="text" name="matricula" class="form-control" value="<?= htmlspecialchars($filtros['matricula']) ?>" placeholder="Todas">
    </div>
    <div class="col-12 col-md-3 d-flex gap-2">
        <button type="submit" class="btn btn-primary flex-fill"><i class="ph ph-magnifying-glass"></i> Filtrar</button>
        <a class="btn btn-outline-success" href="<?= route('relatorio.excel', [], $filtros) ?>" title="Exportar Excel"><i class="ph ph-file-xls"></i></a>
    </div>
</form>

<div class="table-responsive">
    <table class="table table-hover at-table mb-0">
        <thead>
            <tr>
                <th>Matrícula</th><th>Nome</th><th>C. Custo</th><th>Unid. Funcional</th><th>Cargo</th>
                <th>Nº Requisição</th><th>Data/Hora</th><th>Regra</th><th>Tipo</th><th>Item</th>
                <th class="text-end">Qtd. Sol.</th><th class="text-end">Qtd. Atend.</th><th>Reposição</th><th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="14" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Use os filtros acima para consultar as requisições.</td></tr>
            <?php } else { ?>
                <?php foreach ($itens as $i) { ?>
                    <tr>
                        <td><?= htmlspecialchars((string) $i->matricula) ?></td>
                        <td><?= htmlspecialchars((string) $i->nome_colaborador) ?></td>
                        <td><?= htmlspecialchars((string) ($i->centro_custo ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($i->unidade_funcional ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($i->cargo ?? '—')) ?></td>
                        <td class="fw-medium"><?= htmlspecialchars((string) $i->numero_requisicao) ?></td>
                        <td><?= htmlspecialchars((string) $i->data_solicitacao) ?> <?= htmlspecialchars((string) $i->hora_solicitacao) ?></td>
                        <td><?= htmlspecialchars((string) ($i->regra_utilizada ?? '—')) ?></td>
                        <td><span class="badge rounded-pill text-bg-light border"><?= $i->item_tipo === 'epi' ? 'EPI' : 'Uniforme' ?></span></td>
                        <td><?= htmlspecialchars((string) $i->item_codigo) ?> — <?= htmlspecialchars((string) $i->item_descricao) ?></td>
                        <td class="text-end"><?= (int) $i->quantidade_solicitada ?></td>
                        <td class="text-end"><?= $i->quantidade_atendida !== null ? (int) $i->quantidade_atendida : '—' ?></td>
                        <td>
                            <?php if (!empty($i->bloqueado)) { ?>
                                <span class="badge rounded-pill text-bg-danger" title="<?= htmlspecialchars((string) ($i->motivo_bloqueio ?? '')) ?>">Bloqueado</span>
                                <?php if (!empty($i->observacao)) { ?><i class="ph ph-note text-muted" title="<?= htmlspecialchars((string) $i->observacao) ?>"></i><?php } ?>
                            <?php } else { ?>
                                <span class="text-muted small">—</span>
                            <?php } ?>
                        </td>
                        <td><?= htmlspecialchars((string) $i->status) ?></td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>
