<?php
$this->layout('templates/base', [
    'webTitle'  => 'Requisição de EPIs e Uniformes',
    'cardTitle' => 'Requisição de EPIs e Uniformes',
    'backTo'    => route('menu'),
]);
?>

<style>
    .req-step { display: none; }
    .req-step.is-active { display: block; }
    .req-cracha-input { font-size: 1.4rem; letter-spacing: .05em; text-align: center; }
    .req-item-card { border: 1px solid var(--bs-border-color, #dee2e6); border-radius: 10px; padding: .75rem; height: 100%; }
    .req-item-card.is-selected { border-color: #198754; background: #f4fbf6; }
    .req-item-card.is-blocked { border-color: #dc3545; }
    .req-item-card img { width: 100%; height: 96px; object-fit: contain; margin-bottom: .5rem; background: #f8f9fa; border-radius: 6px; }
    .req-item-card .req-qty { width: 70px; }
    .req-badge { display: inline-flex; align-items: center; gap: .25rem; font-size: .72rem; font-weight: 600; padding: .15rem .45rem; border-radius: 999px; margin-bottom: .4rem; }
    .req-badge.is-liberado { background: #e9f7ee; color: #1f8a4c; }
    .req-badge.is-bloqueado { background: #fdecee; color: #c0392b; }
    .req-badge.is-indefinido { background: #eef1f5; color: #64748b; }
    .req-obs-box { border: 1px solid #f1c0c6; background: #fdf2f3; border-radius: 10px; padding: .75rem; margin-top: 1rem; }
</style>

<div id="req-step-leitor" class="req-step is-active text-center py-5">
    <i class="ph ph-identification-card" style="font-size:2.5rem;"></i>
    <h5 class="fw-bold mt-2 mb-1">Aproxime o crachá do leitor</h5>
    <p class="text-muted">O campo abaixo recebe a leitura automaticamente.</p>
    <div class="col-12 col-md-5 mx-auto">
        <input type="text" id="req-cracha" class="form-control req-cracha-input" placeholder="Nº do crachá" autofocus autocomplete="off">
    </div>
    <div id="req-leitor-msg" class="mt-3 text-danger small"></div>
</div>

<div id="req-step-provisorio" class="req-step">
    <div class="at-form-panel mb-4">
        <div class="at-form-head">
            <span class="at-form-head__icon"><i class="ph ph-id-badge"></i></span>
            <div>
                <div class="at-form-head__title">Crachá provisório</div>
                <div class="at-form-head__subtitle">Este crachá é provisório. Informe quem está usando ele hoje.</div>
            </div>
        </div>
        <div class="row g-3">
            <div class="col-12 col-md-4">
                <label class="form-label">Matrícula <span class="text-danger">*</span></label>
                <input type="text" id="req-prov-matricula" class="form-control" autocomplete="off">
            </div>
            <div class="col-12 col-md-8">
                <label class="form-label">Nome <span class="text-danger">*</span></label>
                <input type="text" id="req-prov-nome" class="form-control" autocomplete="off">
            </div>
        </div>
        <div class="at-form-foot">
            <button type="button" class="btn btn-light" id="req-prov-cancelar">Cancelar</button>
            <button type="button" class="btn btn-success" id="req-prov-confirmar"><i class="ph ph-check"></i> Confirmar</button>
        </div>
    </div>
</div>

<div id="req-step-colaborador" class="req-step">
    <div class="at-form-panel mb-4">
        <div class="at-form-head">
            <span class="at-form-head__icon"><i class="ph ph-user-check"></i></span>
            <div>
                <div class="at-form-head__title" id="req-colab-nome">—</div>
                <div class="at-form-head__subtitle">Matrícula <span id="req-colab-matricula">—</span> · Centro de custo <span id="req-colab-cc">—</span></div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label class="form-label">Líder</label>
                <select id="req-lider" class="form-select">
                    <option value="">Selecione (opcional)</option>
                    <?php foreach ($lideres as $l) { ?>
                        <option value="<?= htmlspecialchars((string) $l->matricula) ?>"><?= htmlspecialchars((string) $l->nome) ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-6">
                <label class="form-label">Projeto</label>
                <select id="req-projeto" class="form-select">
                    <option value="">Selecione (opcional)</option>
                    <?php foreach ($projetos as $p) { ?>
                        <option value="<?= htmlspecialchars((string) $p->projeto) ?>"><?= htmlspecialchars((string) $p->projeto) ?></option>
                    <?php } ?>
                </select>
            </div>
        </div>

        <div class="mt-4">
            <label class="form-label d-block">O que você deseja requisitar?</label>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-primary req-tipo-btn" data-tipo="uniforme"><i class="ph ph-t-shirt"></i> Uniforme</button>
                <button type="button" class="btn btn-outline-primary req-tipo-btn" data-tipo="epi"><i class="ph ph-hard-hat"></i> EPIs</button>
            </div>
        </div>
    </div>
</div>

<div id="req-step-itens" class="req-step">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="at-form-title mb-0">Selecione os itens</h6>
        <button type="button" class="btn btn-light btn-sm" id="req-itens-voltar"><i class="ph ph-arrow-left"></i> Trocar tipo</button>
    </div>
    <div id="req-itens-grid" class="row g-3"></div>

    <div id="req-obs-box" class="req-obs-box" style="display:none;">
        <label class="form-label fw-medium text-danger mb-1"><i class="ph ph-warning"></i> Há item(ns) bloqueado(s) pela regra de reposição</label>
        <div class="text-muted small mb-2">Para prosseguir com um item bloqueado, registre a justificativa/liberação abaixo.</div>
        <textarea id="req-observacao" class="form-control" rows="2" placeholder="Observação / justificativa da liberação"></textarea>
    </div>

    <div class="at-form-foot mt-4">
        <span class="text-muted small" id="req-itens-resumo">Nenhum item selecionado.</span>
        <button type="button" class="btn btn-success" id="req-confirmar" disabled><i class="ph ph-paper-plane-tilt"></i> Confirmar requisição</button>
    </div>
</div>

<form id="req-form" action="<?= route('requisicao.store') ?>" method="POST" style="display:none"></form>

<script>
(function () {
    var ROTAS = {
        identificar: "<?= route('requisicao.identificar') ?>",
        crachaProvisorio: "<?= route('requisicao.cracha_provisorio') ?>",
        itens: "<?= route('requisicao.itens') ?>",
    };

    var steps = {
        leitor: document.getElementById('req-step-leitor'),
        provisorio: document.getElementById('req-step-provisorio'),
        colaborador: document.getElementById('req-step-colaborador'),
        itens: document.getElementById('req-step-itens'),
    };
    function irPara(nome) {
        Object.values(steps).forEach(function (el) { el.classList.remove('is-active'); });
        steps[nome].classList.add('is-active');
    }

    var crachaInput = document.getElementById('req-cracha');
    var leitorMsg = document.getElementById('req-leitor-msg');
    var crachaAtual = '';
    var colaborador = null;
    var tipoAtual = null;
    var selecionados = {}; // codigo -> {id, tipo, codigo, descricao, quantidade}

    function resetTudo() {
        crachaAtual = ''; colaborador = null; tipoAtual = null; selecionados = {};
        crachaInput.value = '';
        leitorMsg.textContent = '';
        irPara('leitor');
        crachaInput.focus();
    }

    crachaInput.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        var cracha = crachaInput.value.trim();
        if (!cracha) return;
        crachaAtual = cracha;
        leitorMsg.textContent = '';

        fetch(ROTAS.identificar + '?cracha=' + encodeURIComponent(cracha))
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (d.situacao === 'nao_encontrado') {
                    leitorMsg.textContent = 'Crachá não identificado. Tente novamente.';
                    crachaInput.value = '';
                    return;
                }
                if (d.situacao === 'provisorio_pendente') {
                    document.getElementById('req-prov-matricula').value = '';
                    document.getElementById('req-prov-nome').value = '';
                    irPara('provisorio');
                    return;
                }
                colaborador = d;
                mostrarColaborador();
            });
    });

    document.getElementById('req-prov-cancelar').addEventListener('click', resetTudo);
    document.getElementById('req-prov-confirmar').addEventListener('click', function () {
        var matricula = document.getElementById('req-prov-matricula').value.trim();
        var nome = document.getElementById('req-prov-nome').value.trim();
        if (!matricula || !nome) return;

        fetch(ROTAS.crachaProvisorio, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'cracha=' + encodeURIComponent(crachaAtual) + '&matricula=' + encodeURIComponent(matricula) + '&nome=' + encodeURIComponent(nome),
        })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                colaborador = d;
                mostrarColaborador();
            });
    });

    function mostrarColaborador() {
        document.getElementById('req-colab-nome').textContent = colaborador.nome || '—';
        document.getElementById('req-colab-matricula').textContent = colaborador.matricula || '—';
        document.getElementById('req-colab-cc').textContent = colaborador.centro_custo || '—';
        irPara('colaborador');
    }

    document.querySelectorAll('.req-tipo-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            tipoAtual = btn.getAttribute('data-tipo');
            selecionados = {};
            carregarItens();
        });
    });

    document.getElementById('req-itens-voltar').addEventListener('click', function () { irPara('colaborador'); });

    function badgeHtml(status, motivo) {
        if (status === 'bloqueado') {
            return '<span class="req-badge is-bloqueado" title="' + (motivo || '') + '"><i class="ph ph-lock"></i> Bloqueado</span>';
        }
        if (status === 'liberado') {
            return '<span class="req-badge is-liberado"><i class="ph ph-check-circle"></i> Liberado</span>';
        }
        return '<span class="req-badge is-indefinido" title="Sem histórico disponível para verificar a regra"><i class="ph ph-question"></i> Verificar</span>';
    }

    function carregarItens() {
        var url = ROTAS.itens + '?tipo=' + encodeURIComponent(tipoAtual) +
            '&matricula=' + encodeURIComponent(colaborador.matricula || '');
        fetch(url)
            .then(function (r) { return r.json(); })
            .then(function (d) {
                var grid = document.getElementById('req-itens-grid');
                grid.innerHTML = '';
                (d.itens || []).forEach(function (item) {
                    var col = document.createElement('div');
                    col.className = 'col-6 col-md-3';
                    col.innerHTML =
                        '<div class="req-item-card" data-codigo="' + item.codigo + '">' +
                        badgeHtml(item.status, item.motivo) +
                        (item.imagem ? '<img src="' + item.imagem + '" alt="">' : '') +
                        '<div class="fw-medium small">' + item.descricao + '</div>' +
                        '<div class="text-muted small mb-2">' + item.codigo + '</div>' +
                        (item.bloqueado ? '<div class="text-danger small mb-2">' + (item.motivo || '') + '</div>' : '') +
                        '<div class="d-flex align-items-center gap-2">' +
                        '<input type="checkbox" class="form-check-input req-check">' +
                        '<input type="number" class="form-control form-control-sm req-qty" value="1" min="1" disabled>' +
                        '</div></div>';

                    var card = col.querySelector('.req-item-card');
                    var check = col.querySelector('.req-check');
                    var qty = col.querySelector('.req-qty');

                    check.addEventListener('change', function () {
                        qty.disabled = !check.checked;
                        card.classList.toggle('is-selected', check.checked);
                        card.classList.toggle('is-blocked', check.checked && item.bloqueado);
                        if (check.checked) {
                            selecionados[item.codigo] = {
                                id: item.id, tipo: tipoAtual, codigo: item.codigo, descricao: item.descricao,
                                quantidade: parseInt(qty.value, 10) || 1,
                                bloqueado: !!item.bloqueado, motivo: item.motivo || ''
                            };
                        } else {
                            delete selecionados[item.codigo];
                        }
                        atualizarResumo();
                    });
                    qty.addEventListener('input', function () {
                        if (selecionados[item.codigo]) selecionados[item.codigo].quantidade = parseInt(qty.value, 10) || 1;
                    });

                    grid.appendChild(col);
                });
                irPara('itens');
            });
    }

    function temBloqueado() {
        return Object.values(selecionados).some(function (i) { return i.bloqueado; });
    }

    function atualizarResumo() {
        var n = Object.keys(selecionados).length;
        document.getElementById('req-itens-resumo').textContent = n ? (n + ' item(ns) selecionado(s).') : 'Nenhum item selecionado.';
        document.getElementById('req-obs-box').style.display = temBloqueado() ? 'block' : 'none';
        document.getElementById('req-confirmar').disabled = n === 0;
    }

    document.getElementById('req-confirmar').addEventListener('click', function () {
        var observacao = document.getElementById('req-observacao').value.trim();
        if (temBloqueado() && !observacao) {
            document.getElementById('req-observacao').focus();
            return;
        }

        var form = document.getElementById('req-form');
        form.innerHTML = '';

        function campo(nome, valor) {
            var i = document.createElement('input');
            i.type = 'hidden'; i.name = nome; i.value = valor == null ? '' : valor;
            form.appendChild(i);
        }

        campo('matricula', colaborador.matricula);
        campo('nome', colaborador.nome);
        campo('centro_custo', colaborador.centro_custo);
        campo('unidade_funcional', colaborador.unidade_funcional);
        campo('cargo', colaborador.cargo);
        campo('lider_matricula', document.getElementById('req-lider').value);
        campo('projeto', document.getElementById('req-projeto').value);
        campo('cracha', crachaAtual);
        campo('cracha_provisorio', colaborador.cracha_provisorio ? '1' : '');
        campo('observacao', observacao);

        Object.values(selecionados).forEach(function (item, idx) {
            campo('itens[' + idx + '][id]', item.id);
            campo('itens[' + idx + '][tipo]', item.tipo);
            campo('itens[' + idx + '][codigo]', item.codigo);
            campo('itens[' + idx + '][descricao]', item.descricao);
            campo('itens[' + idx + '][quantidade]', item.quantidade);
            campo('itens[' + idx + '][bloqueado]', item.bloqueado ? '1' : '');
            campo('itens[' + idx + '][motivo]', item.motivo);
        });

        form.submit();
    });
})();
</script>
