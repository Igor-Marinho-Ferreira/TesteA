<?php
$this->layout('templates/base', [
    'webTitle'  => 'Manual do Sistema',
    'cardTitle' => 'Manual — Como o processo e cada tela funcionam',
    'backTo'    => route('menu'),
]);

// Helper para um item de accordion
$item = function (string $id, string $titulo, string $conteudoHtml, string $pai) {
    echo '<div class="accordion-item">'
        . '<h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#' . $id . '">' . $titulo . '</button></h2>'
        . '<div id="' . $id . '" class="accordion-collapse collapse" data-bs-parent="#' . $pai . '"><div class="accordion-body">' . $conteudoHtml . '</div></div>'
        . '</div>';
};
?>

<style>
    .manual-flow{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin:.5rem 0 1rem}
    .manual-flow .step{background:#e9f7ee;color:#1f8a4c;border:1px solid #cdeed9;border-radius:10px;padding:.4rem .7rem;font-weight:600;font-size:.85rem}
    .manual-flow .arrow{color:#94a3b8}
    .manual-lead{color:#475569}
    .accordion-button:not(.collapsed){background:#eaf3fc;color:#1f6fb8}
</style>

<p class="manual-lead">
    O sistema digitaliza a requisição de EPIs e uniformes, hoje feita em painéis físicos. A lógica é sempre a mesma:
    <strong>parametrizar</strong> os cadastros base → o colaborador <strong>identifica-se pelo crachá</strong> →
    <strong>seleciona os itens</strong> → a requisição fica disponível no <strong>relatório</strong>.
</p>

<div class="manual-flow">
    <span class="step">Cadastros base</span><span class="arrow">→</span>
    <span class="step">Leitura do crachá</span><span class="arrow">→</span>
    <span class="step">Seleção de EPI/Uniforme</span><span class="arrow">→</span>
    <span class="step">Confirmação</span><span class="arrow">→</span>
    <span class="step">Relatório</span>
</div>

<div class="at-form-panel mb-4">
    <div class="at-form-title at-accent--slate"><i class="ph ph-info"></i> Como usar qualquer tela de cadastro</div>
    <ul class="mb-0">
        <li><strong>Formulário no topo</strong>: preencha e clique em <em>Registrar</em> (ou <em>Salvar alterações</em> ao editar). Campos com <span class="text-danger">*</span> são obrigatórios.</li>
        <li><strong>Filtrar…</strong>: a busca acima da tabela filtra os registros em tempo real.</li>
        <li><strong>Ações</strong>: ✏️ editar carrega o registro no formulário; 🗑️ excluir pede confirmação.</li>
        <li><strong>Notificações</strong>: mensagens de sucesso/erro aparecem no canto da tela.</li>
    </ul>
</div>

<!-- ===================== PARAMETRIZAÇÃO ===================== -->
<h6 class="at-form-title mt-4"><i class="ph ph-number-circle-one"></i> Parametrização</h6>
<div class="accordion mb-4" id="acc-b1">
    <?php
    $item('m-item', 'EPIs e Uniformes', '<p>Informe o <strong>código do item</strong> (validado automaticamente no Logix) — a descrição é preenchida sozinha e não pode ser digitada. Anexe uma imagem para facilitar a identificação visual na tela de requisição. Não é possível cadastrar código duplicado.</p>', 'acc-b1');
    $item('m-lider', 'Líderes', '<p>Informe a matrícula para buscar o nome automaticamente no Sênior (ou busque pelo nome, se a matrícula não for conhecida). Alimenta o formulário de requisição.</p>', 'acc-b1');
    $item('m-projeto', 'Projetos', '<p>Cadastro simples do nome do projeto. Alimenta o formulário de requisição.</p>', 'acc-b1');
    ?>
</div>

<!-- ===================== REQUISIÇÃO ===================== -->
<h6 class="at-form-title mt-4"><i class="ph ph-number-circle-two"></i> Requisição de EPIs e Uniformes (tela do operador)</h6>
<div class="accordion mb-4" id="acc-b2">
    <?php
    $item('m-cracha', 'Identificação pelo crachá', '<p>O colaborador aproxima o crachá do leitor (que digita o número e confirma sozinho). O sistema consulta o Foracesso e o Logix/Sênior e carrega <strong>matrícula, nome e centro de custo</strong> — campos que não podem ser editados manualmente.</p>', 'acc-b2');
    $item('m-cracha-prov', 'Crachá provisório', '<p>Se o número lido for de um crachá provisório (lista sincronizada do Foracesso) e ainda não tiver sido usado hoje, o sistema pede matrícula e nome de quem está usando o crachá naquele dia, e grava data/hora do uso.</p>', 'acc-b2');
    $item('m-selecao', 'Seleção dos itens', '<p>O colaborador escolhe <strong>Uniforme</strong> ou <strong>EPIs</strong> e seleciona um ou mais itens da lista (com imagem), ajustando a quantidade de cada um. Ao confirmar, a requisição é registrada com data, hora, colaborador e itens solicitados.</p>', 'acc-b2');
    $item('m-regra', 'Regra de reserva de EPI', '<p>O sistema consulta a tabela <code>MX_CARGO_EPI</code> para saber quais EPIs são liberados ao colaborador: primeiro por <strong>matrícula + unidade funcional + cargo</strong>; se não houver configuração específica, usa a configuração padrão por <strong>unidade funcional + cargo</strong>.</p>', 'acc-b2');
    $item('m-reposicao', 'Regra de reposição (bloqueio)', '<p>Cada item (EPI ou uniforme) pode ter uma regra de reposição em <code>mx_matseg</code>: <strong>quantidade máxima</strong> e <strong>prazo em dias</strong> (ex.: 2 conjuntos a cada 60 dias). Na seleção dos itens, cada um mostra um selo <span class="badge rounded-pill text-bg-light border">🟢 Liberado</span> / <span class="badge rounded-pill text-bg-danger">Bloqueado</span> / <span class="badge rounded-pill text-bg-light border">Verificar</span>. Ao confirmar com item bloqueado, é exigida uma <strong>observação/justificativa</strong> (liberação), que fica registrada no relatório para auditoria.</p>', 'acc-b2');
    ?>
</div>

<!-- ===================== RELATÓRIO / ADMIN ===================== -->
<h6 class="at-form-title mt-4"><i class="ph ph-number-circle-three"></i> Relatório e Administração</h6>
<div class="accordion mb-4" id="acc-b3">
    <?php
    $item('m-rel', 'Relatório de Requisições', '<p>Histórico completo das requisições, com filtros por <strong>período</strong> e <strong>matrícula</strong>. Mostra colaborador, item, quantidade solicitada/atendida, status e qual regra do <code>MX_CARGO_EPI</code> foi usada. Também permite <strong>exportar em Excel</strong>.</p>', 'acc-b3');
    $item('m-perfil', 'Perfis de Acesso', '<p>Define, por módulo, se cada pessoa <strong>Vê</strong> a tela e se pode <strong>Editar</strong> ou apenas visualizar. Vincule uma matrícula a um perfil — o menu e os botões passam a respeitar isso.</p>', 'acc-b3');
    ?>
</div>
