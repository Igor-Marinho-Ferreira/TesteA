<?php

namespace src\routes;


use src\app\controllers\ArquivoController;
use src\app\controllers\ItemController;
use src\app\controllers\LiderController;
use src\app\controllers\ManualController;
use src\app\controllers\MenuController;
use src\app\controllers\PerfilController;
use src\app\controllers\ProjetoController;
use src\app\controllers\RelatorioController;
use src\app\controllers\RequisicaoController;
use src\app\middlewares\IsLoggedMiddleware;
use src\core\Route;


// Requisição de EPI's e Uniformes — digitalização do processo de requisição

// Menu principal
Route::get('/', MenuController::class, 'index')
    ->name('menu')
    ->middlewares([IsLoggedMiddleware::class]);

// Servir arquivos do storage externo ({projeto}-storage)
Route::get('/arquivo', ArquivoController::class, 'download')
    ->name('arquivo')
    ->middlewares([IsLoggedMiddleware::class]);

// Manual do sistema
Route::get('/manual', ManualController::class, 'index')
    ->name('manual.index')
    ->middlewares([IsLoggedMiddleware::class]);

// Perfis de Acesso
Route::get('/perfis', PerfilController::class, 'index')->name('perfil.index')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/store', PerfilController::class, 'store')->name('perfil.store')->middlewares([IsLoggedMiddleware::class]);
Route::get('/perfis/{uuid}/editar', PerfilController::class, 'edit')->name('perfil.edit')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/update', PerfilController::class, 'update')->name('perfil.update')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/excluir', PerfilController::class, 'destroy')->name('perfil.destroy')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/vincular', PerfilController::class, 'vincular')->name('perfil.vincular')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/desvincular', PerfilController::class, 'desvincular')->name('perfil.desvincular')->middlewares([IsLoggedMiddleware::class]);


/**
 * Helper local: registra o CRUD padrão de um cadastro simples.
 * (index, store, edit, update, destroy)
 */
$crud = function (string $path, string $name, string $controller) {
    Route::get("/{$path}", $controller, 'index')->name("{$name}.index")->middlewares([IsLoggedMiddleware::class]);
    Route::post("/{$path}/store", $controller, 'store')->name("{$name}.store")->middlewares([IsLoggedMiddleware::class]);
    Route::get("/{$path}/{uuid}/editar", $controller, 'edit')->name("{$name}.edit")->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
    Route::post("/{$path}/update", $controller, 'update')->name("{$name}.update")->middlewares([IsLoggedMiddleware::class]);
    Route::post("/{$path}/excluir", $controller, 'destroy')->name("{$name}.destroy")->middlewares([IsLoggedMiddleware::class]);
};


// ── Telas de parametrização para uso do formulário de requisição ──────────
$crud('itens',    'item',    ItemController::class);
Route::get('/itens/buscar-logix', ItemController::class, 'buscarNoLogix')->name('item.buscar_logix')->middlewares([IsLoggedMiddleware::class]);
Route::post('/itens/importar', ItemController::class, 'importar')->name('item.importar')->middlewares([IsLoggedMiddleware::class]);
Route::get('/itens/template', ItemController::class, 'template')->name('item.template')->middlewares([IsLoggedMiddleware::class]);

$crud('lideres',  'lider',   LiderController::class);
Route::get('/lideres/buscar-matricula', LiderController::class, 'buscarPorMatricula')->name('lider.buscar_matricula')->middlewares([IsLoggedMiddleware::class]);
Route::get('/lideres/buscar-nome', LiderController::class, 'buscarPorNome')->name('lider.buscar_nome')->middlewares([IsLoggedMiddleware::class]);

$crud('projetos', 'projeto', ProjetoController::class);

// Requisição de EPI's e Uniformes pelos Operadores (2.1.1.4)
Route::get('/requisicao', RequisicaoController::class, 'index')->name('requisicao.index')->middlewares([IsLoggedMiddleware::class]);
Route::get('/requisicao/identificar', RequisicaoController::class, 'identificar')->name('requisicao.identificar')->middlewares([IsLoggedMiddleware::class]);
Route::post('/requisicao/cracha-provisorio', RequisicaoController::class, 'registrarCrachaProvisorio')->name('requisicao.cracha_provisorio')->middlewares([IsLoggedMiddleware::class]);
Route::get('/requisicao/itens', RequisicaoController::class, 'itens')->name('requisicao.itens')->middlewares([IsLoggedMiddleware::class]);
Route::post('/requisicao/store', RequisicaoController::class, 'store')->name('requisicao.store')->middlewares([IsLoggedMiddleware::class]);

// Relatório de Requisição de EPIs e Uniformes (2.1.1.5)
Route::get('/relatorio', RelatorioController::class, 'index')->name('relatorio.index')->middlewares([IsLoggedMiddleware::class]);
Route::get('/relatorio/excel', RelatorioController::class, 'excel')->name('relatorio.excel')->middlewares([IsLoggedMiddleware::class]);
