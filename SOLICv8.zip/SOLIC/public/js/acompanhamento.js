
/**
 * Verifica se há parâmetro de exibição na URL e aciona o gatilho correspondente.
 *
 * @returns {void}
 */
function isShowing() {
    if (getQuery().with)
        document.getElementById(`trigger-${getQuery().with}`).click();
}

isShowing();

function confirmDelete() {
    let btnWarning = document.getElementById("btnConfirm");
    let btnDelete = document.getElementById("btnDelete");
    if (btnWarning) btnWarning.classList.remove("d-none");
    if (btnDelete) btnDelete.classList.add("d-none");
}

window.onload = function (e) {
    let loadingWrapper = document.getElementById("loading-wrapper");
    if (loadingWrapper) loadingWrapper.style.display = "none";

    console.log(loadingWrapper);
};
async function initTable() {
    let translate = await fetch(route('/public/js/dt/en.json'));
    translate = await translate.json();

    let table = new DataTable("#list", {
        pageLength: 12,
        lengthChange: false,
        pagingType: "simple_numbers",
        info: false,
        order: [[0, "desc"]],
        language: translate,
        columnDefs: [
            { width: "5%", targets: 0 },
            { width: "25%", targets: 1 },
            { width: "7%", targets: 2 },
            { width: "7%", targets: 3 },
            { width: "10%", targets: 4 },
            { width: "8%", targets: 5 },
            { width: "7%", targets: 6 },
            { width: "7%", targets: 7 },
            { className: "dt-center", targets: "_all" },
            { targets: "_all", defaultContent: "" }
        ]
    });


    // Botão TODAS (Limpa qualquer filtro)
    document.getElementById("btnAll").addEventListener("click", function () {
        table.search("").columns().search("").draw();
    });

    // Botão PENDENTE
    document.getElementById("btnPendente").addEventListener("click", function () {
        table.search("PEN").draw();
    });

    // Botão VALIDAÇÃO
    document.getElementById("btnValidacao").addEventListener("click", function () {
        table.search("VAL").draw();
    });
}

initTable();

// document.addEventListener("DOMContentLoaded", function () {
//     const inputSolicitante = document.getElementById("solicitante");

//     if (inputSolicitante) {
//         const ac = new autoComplete({
//             selector: "#solicitante",
//             placeHolder: "Busque o solicitante...",
//             threshold: 2, 
//             debounce: 300,
//             data: {
//                 src: async (query) => {
//                     try {
//                         const source = await fetch(route(`dispositivos/autocomplete/?nome=${encodeURIComponent(query)}`));
//                         const data = await source.json();
//                         return data.data || [];
//                     } catch (error) {
//                         console.error("Erro ao buscar nomes:", error);
//                         return [];
//                     }
//                 },
//                 keys: ["nome"] 
//             },
//             resultsList: {
//                 tag: "div",
//                 id: "autocomplete-list",
//                 class: "autocomplete-results",
//                 destination: "#solicitante",
//                 position: "afterend",
//                 maxResults: 10,
//                 noResults: true,
//                 element: (list, data) => {
//                     if (!data.results.length) {
//                         const message = document.createElement("div");
//                         message.setAttribute("style", "padding: 10px; color: #999;");
//                         message.innerHTML = `<span>Nenhum resultado encontrado</span>`;
//                         list.prepend(message);
//                     }
//                 }
//             },
//             resultItem: {
//                 tag: "div",
//                 class: "autocomplete-item",
//                 element: (item, data) => {
//                     item.setAttribute("style", "padding: 12px; cursor: pointer; border-bottom: 1px solid #eee;");
//                     item.innerHTML = `
//                         <span>${data.value.nome}</span>
//                     `;
//                 },
//                 highlight: true
//             },
//             events: {
//                 input: {
//                     selection: (event) => {
//                         const nomeSelecionado = event.detail.selection.value.nome;
//                         inputSolicitante.value = nomeSelecionado;

//                         const urlParams = new URLSearchParams(window.location.search);
//                         urlParams.set("nome", nomeSelecionado);
//                         window.location.href = window.location.pathname + '?' + urlParams.toString();
//                     }
//                 }
//             }
//         });
//     }
// });


const selectSolicitante = document.getElementById('solicitante');
console.log(selectSolicitante);
function filtrar() {
    const params = new URLSearchParams(window.location.search);

    params.set('solicitante', selectSolicitante.value);

    window.location.search = params.toString();
}

selectSolicitante.addEventListener('change', filtrar);
