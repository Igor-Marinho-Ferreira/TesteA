/* ============================================================================
 *  calculoPerfis.js — calculadora de peso dos perfis lineares
 *  Peso(kg) = peso_por_metro(kg/m) × comprimento(m) × quantidade
 * ========================================================================== */

(function () {
    "use strict";

    const painel = document.getElementById("painelPerfil");

    if (!painel) {
        return;
    }

    let perfis = {};

    try {
        perfis = JSON.parse(painel.dataset.perfis || "{}");
    } catch (e) {
        perfis = {};
    }

    const select = document.getElementById("perfilSelect");
    const inputComp = document.getElementById("perfilComp");
    const inputQtde = document.getElementById("perfilQtde");
    const btnCalcular = document.getElementById("btnCalcularPerfil");

    function numero(valor) {
        const limpo = String(valor).replace(",", ".").replace(/[^0-9.]/g, "");
        const n = parseFloat(limpo);
        return isNaN(n) ? 0 : n;
    }

    function fmt(valor, dec) {
        return Number(valor).toLocaleString("pt-BR", {
            minimumFractionDigits: dec,
            maximumFractionDigits: dec
        });
    }

    function calcular() {
        const perfil = perfis[select.value];

        if (!perfil) {
            document.getElementById("perfilKgm").textContent = "—";
            document.getElementById("perfilCompTotal").textContent = "—";
            document.getElementById("perfilPesoUnit").textContent = "—";
            document.getElementById("perfilPesoTotal").textContent = "—";
            return;
        }

        const kgm = perfil.kgm;
        const compM = numero(inputComp.value) / 1000;
        const qtde = Math.max(1, Math.round(numero(inputQtde.value)));

        const pesoUnit = kgm * compM;
        const pesoTotal = pesoUnit * qtde;

        document.getElementById("perfilKgm").textContent = fmt(kgm, 3);
        document.getElementById("perfilCompTotal").textContent = fmt(compM * qtde, 3);
        document.getElementById("perfilPesoUnit").textContent = fmt(pesoUnit, 3);
        document.getElementById("perfilPesoTotal").textContent = fmt(pesoTotal, 3);
    }

    if (btnCalcular) {
        btnCalcular.addEventListener("click", calcular);
    }

    if (select) {
        select.addEventListener("change", calcular);
    }

    [inputComp, inputQtde].forEach(function (campo) {
        if (campo) {
            campo.addEventListener("keydown", function (evento) {
                if (evento.key === "Enter") {
                    evento.preventDefault();
                    calcular();
                }
            });
        }
    });
})();
