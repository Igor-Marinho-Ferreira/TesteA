<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.industrial.lista"),
    "webTitle"  => "Dispositivos - Industrial",
    "cardTitle" => "SOLICITAÇÃO DE PROJETO DE DISPOSITIVOS - INDUSTRIAL",
    "styles"    => [
        path()->css("desenvolvimento.css")
    ],
    "js" => [
        path()->js("desenvolvimentoProj.js"),
        // Depois de desenvolvimentoProj.js: embrulha gerenciarMudancaStatus
        path()->js("liberacaoAquisicao.js"),
        path()->js("industrialForm.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$formatarDataHora = function ($data) {
    if (empty($data) || $data === '0000-00-00 00:00:00') {
        return '--';
    }
    try {
        return (new DateTime($data))->format('d/m/Y H:i');
    } catch (Throwable $e) {
        return '--';
    }
};

// Valor para <input type="date"> (YYYY-MM-DD) ou vazio
$dataParaInput = function ($data) {
    if (empty($data) || $data === '0000-00-00' || $data === '0000-00-00 00:00:00') {
        return '';
    }
    try {
        return (new DateTime($data))->format('Y-m-d');
    } catch (Throwable $e) {
        return '';
    }
};

$temposEtapa = $temposEtapa ?? [];
$slLiberada  = $slLiberada ?? false;
$slCancelada = $slCancelada ?? false;

// 8ª rodada — Liberação + Aquisição/OC passaram para a Industrial
$podeLiberar         = $podeLiberar ?? false;
$itensComprados      = $itensComprados ?? [];
$resumoAquisicao     = $resumoAquisicao ?? ['total' => 0, 'liquidados' => 0, 'pendentes' => 0];
$aquisicaoHabilitada = $aquisicaoHabilitada ?? false;
$podeBypassAquisicao = $podeBypassAquisicao ?? false;

// Industrial só edita os campos com a SL liberada e não cancelada
$camposEditaveis = $slLiberada && !$slCancelada;

// Nome completo: a view roda dentro de um método do Plates, então "use" aqui
// seria erro de parse.
$formatarDuracao = function ($segundos) {
    return \src\support\Cronometro::formatar($segundos);
};
?>

<?php /* ---------------------------- CABEÇALHO ---------------------------- */ ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-2">
                <label class="form-label fs-7 fw-bold d-block mb-0">SL:</label>
                <span class="fs-5 fw-bold text-dark">SL<?= $h($solicitacao->ref) ?></span>
            </div>

            <div class="col-md-2">
                <label class="form-label fs-7 fw-bold d-block mb-0">CÓD Z:</label>
                <span class="text-uppercase"><?= $h($z_info->cod_z ?? $solicitacao->cod_z ?? '--') ?></span>
            </div>

            <div class="col-md-4">
                <label class="form-label fs-7 fw-bold d-block mb-0">SOLICITANTE:</label>
                <span class="text-uppercase"><?= $h($solicitacao->solicitante) ?></span>
            </div>

            <div class="col-md-2">
                <label class="form-label fs-7 fw-bold d-block mb-0">N° SFP / CC:</label>
                <span><?= $h($solicitacao->conta ?: '--') ?></span>
            </div>

            <div class="col-md-2">
                <label class="form-label fs-7 fw-bold d-block mb-0">VAGÃO | LOTE:</label>
                <span><?= $h($solicitacao->vagao) ?> | <?= $h($solicitacao->lote) ?></span>
            </div>

            <div class="col-md-8">
                <label class="form-label fs-7 fw-bold d-block mb-0">DESCRIÇÃO:</label>
                <span><?= $h($solicitacao->descricao) ?></span>
            </div>

            <div class="col-md-2">
                <label class="form-label fs-7 fw-bold d-block mb-0">CLASSE:</label>
                <span><?= $h($solicitacao->classe ?: '--') ?></span>
            </div>

            <div class="col-md-2">
                <label class="form-label fs-7 fw-bold d-block mb-0">LOCAL:</label>
                <span><?= $h($solicitacao->aplicacao ?: '--') ?></span>
            </div>
        </div>
    </div>
</div>

<?php /* ------------------------ BARRA DE PROGRESSO ------------------------ */ ?>
<div class="barra-progresso-container">
    <?php
    $class_map = [
        'OK'           => 'status-ok',
        'FINALIZADO'   => 'status-ok',
        'EM ANDAMENTO' => 'status-alerta',
        'ANDAMENTO'    => 'status-alerta',
        'MODELO'       => 'status-alerta',
        'PENDENTE'     => 'status-espera',
        'PARADO'       => 'status-espera',
        'CANCELADO'    => 'status-espera',
        '[VALIDAÇÃO]'  => 'status-alerta',
        'REVISAR'      => 'status-revisao',
        'BACKLOG'      => 'status-backlog',
        'AGUARDANDO'   => 'status-backlog',
        'PAUSADO'      => 'status-pausado',
        'TERCEIRIZADO' => 'status-pausado',
    ];

    foreach ($etapas as $etapa) :
        $valorAtual = strtoupper(trim((string) $etapa['valor']));
        $classeAtual = $class_map[$valorAtual] ?? 'status-espera';

        // Etapa terminal também trava (mesma regra da automação)
        $isTerminal  = in_array($valorAtual, ['CANCELADO'], true);
        $isDisabled  = !$etapa['edit'] || $isTerminal;
    ?>
        <div class="step-card">
            <label class="step-label text-truncate"><?= $h($etapa['label']) ?></label>

            <?php if (empty($etapa['opcoes'])) : ?>
                <?php /* Etapas da automação: só leitura aqui */ ?>
                <div class="form-select form-select-sm select-status <?= $classeAtual ?>"
                     style="pointer-events:none; opacity:.85; background-image:none;">
                    <?= $h($etapa['valor'] ?: '--') ?>
                </div>
            <?php else : ?>
                <select
                    class="form-select form-select-sm select-status <?= $classeAtual ?>"
                    data-id="<?= $h($solicitacao->ref) ?>"
                    data-coluna="<?= $h($etapa['coluna']) ?>"
                    onchange="gerenciarMudancaStatus(this), loading('show')"
                    <?= $isDisabled ? 'disabled' : '' ?>
                    title="<?= $slLiberada ? '' : 'Disponível somente após a liberação da SL' ?>"
                >
                    <?php if (!in_array($etapa['valor'], $etapa['opcoes'])) : ?>
                        <option value="<?= $h($etapa['valor']) ?>" selected><?= $h($etapa['valor']) ?></option>
                    <?php endif; ?>

                    <?php foreach ($etapa['opcoes'] as $opcao) : ?>
                        <option value="<?= $h($opcao) ?>" <?= ($valorAtual === strtoupper($opcao)) ? 'selected' : '' ?>>
                            <?= $h($opcao) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>

            <?php /* Cronômetro da etapa */ ?>
            <?php if (isset($temposEtapa[$etapa['coluna']])) : ?>
                <?php $tempoEt = $temposEtapa[$etapa['coluna']]; ?>
                <small class="d-block mt-1" style="font-size: 0.65rem;"
                       title="<?= !empty($tempoEt['derivado'])
                                    ? 'Tempo corrido entre início e fim da etapa'
                                    : 'Tempo somando apenas os períodos em andamento/terceirizado' ?>">
                    <i class="bi bi-stopwatch<?= !empty($tempoEt['rodando']) ? '-fill text-success' : ' text-muted' ?>"></i>
                    <span class="<?= !empty($tempoEt['rodando']) ? 'text-success fw-semibold' : 'text-muted' ?>">
                        <?= $h($formatarDuracao($tempoEt['segundos'])) ?>
                    </span>
                    <?= !empty($tempoEt['rodando']) ? '<span class="text-success">•</span>' : '' ?>
                </small>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<div class="d-flex align-items-center py-3">
    <div class="flex-grow-1 border-top"></div>
    <span class="mx-3 fw-bold text-uppercase fs-7">DADOS DO INDUSTRIAL</span>
    <div class="flex-grow-1 border-top"></div>
</div>

<div class="row">
    <div class="col-lg-8">
        <?php /* -------------------- CAMPOS DO INDUSTRIAL -------------------- */ ?>
        <form id="formCamposIndustrial" data-ref="<?= (int) $solicitacao->ref ?>">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="n_pasta" class="form-label fs-7 fw-bold mb-1"># Pasta</label>
                    <input type="text" class="form-control form-control-sm" id="n_pasta" name="n_pasta"
                           value="<?= $h($solicitacao->n_pasta ?? '') ?>" maxlength="60"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-3">
                    <label for="data_entrega" class="form-label fs-7 fw-bold mb-1">Data de Entrega</label>
                    <input type="date" class="form-control form-control-sm" id="data_entrega" name="data_entrega"
                           value="<?= $h($dataParaInput($solicitacao->data_entrega ?? null)) ?>"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-3">
                    <label for="equipeei" class="form-label fs-7 fw-bold mb-1">Equipe</label>
                    <input type="text" class="form-control form-control-sm" id="equipeei" name="equipeei"
                           value="<?= $h($solicitacao->equipeei ?? '') ?>" maxlength="60"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-3">
                    <label for="setor_pendencia" class="form-label fs-7 fw-bold mb-1">Setor</label>
                    <input type="text" class="form-control form-control-sm" id="setor_pendencia" name="setor_pendencia"
                           value="<?= $h($solicitacao->setor_pendencia ?? '') ?>" maxlength="60"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-4">
                    <label for="natureza" class="form-label fs-7 fw-bold mb-1">Natureza</label>
                    <input type="text" class="form-control form-control-sm" id="natureza" name="natureza"
                           value="<?= $h($solicitacao->natureza ?? '') ?>" maxlength="120"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-8">
                    <label for="descricaoservico" class="form-label fs-7 fw-bold mb-1">Descrição do Serviço</label>
                    <input type="text" class="form-control form-control-sm" id="descricaoservico" name="descricaoservico"
                           value="<?= $h($solicitacao->descricaoservico ?? '') ?>" maxlength="255"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>
            </div>

            <?php if ($camposEditaveis) : ?>
                <div class="d-flex justify-content-end align-items-center gap-2 mt-3">
                    <small class="text-muted fs-8" id="statusSalvarIndustrial"></small>
                    <button type="submit" class="btn btn-sm btn-primary" id="btnSalvarIndustrial">
                        <i class="bi bi-save me-1"></i> Salvar dados
                    </button>
                </div>
            <?php else : ?>
                <div class="alert alert-secondary fs-7 mt-3 mb-0">
                    <?= $slCancelada
                        ? 'SL cancelada — os campos estão bloqueados.'
                        : 'A SL ainda não foi liberada pela automação.' ?>
                </div>
            <?php endif; ?>
        </form>

        <?php /* Datas das etapas do industrial */ ?>
        <div class="row text-center pt-4">
            <div class="col-6 col-md-3">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Corte — Início</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->corte_inicio ?? null)) ?></span>
            </div>
            <div class="col-6 col-md-3 border-start">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Corte — Fim</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->corte_fim ?? null)) ?></span>
            </div>
            <div class="col-6 col-md-3 border-start">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Exec. — Início</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->exec_inicio ?? null)) ?></span>
            </div>
            <div class="col-6 col-md-3 border-start">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Exec. — Fim</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->exec_fim ?? null)) ?></span>
            </div>
        </div>
    </div>

    <?php /* ---------------------------- CHATBOX ---------------------------- */ ?>
    <div class="col-lg-4 container-history">
        <div class="card shadow-sm card-history">
            <div class="card-header bg-light py-2">
                <h6 class="mb-0 fw-bold text-uppercase fs-7 text-muted">
                    <i class="bi bi-clock-history me-2"></i>Histórico de Interações
                </h6>
            </div>

            <div class="card-body p-0" style="max-height: 400px; overflow-y: auto;">
                <div class="list-group list-group-flush shadow-none">
                    <?php foreach ($interacoes as $interacao) : ?>
                        <?php $data = new DateTime($interacao->created_at); ?>
                        <div class="list-group-item border-0 border-bottom p-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="fw-bold text-primary fs-7">
                                    <i class="bi bi-person-fill"></i> <?= strtoupper($h($interacao->usuario)) ?>
                                </span>
                                <small class="text-muted fs-8"><?= $data->format('d.m.Y - H:i') ?></small>
                            </div>
                            <div class="ps-3 border-start border-2 ms-1">
                                <p class="mb-1 text-dark fs-7">- <?= $h($interacao->mensagem) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (empty($interacoes)) : ?>
                        <div class="list-group-item border-0 p-3 text-muted">Nenhuma interação registrada.</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card-footer bg-white p-3">
                <form action="<?= route('dispositivos.historico.store', ['ref' => $solicitacao->ref, 'tipo' => 'industrial']) ?>" method="POST">
                    <input type="hidden" name="ref" value="<?= $h($solicitacao->ref) ?>">
                    <input type="hidden" name="usuario" value="<?= $h($_SESSION['usuarioNome'] ?? '') ?>">

                    <div class="input-group">
                        <textarea name="mensagem" class="form-control fs-7" rows="2"
                                  placeholder="Digite uma nova interação..." style="resize: none;" required></textarea>
                        <button class="btn btn-primary" type="submit" title="Enviar">
                            <i class="bi bi-send-fill"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php /* -------------------- AQUISIÇÃO / ITENS COMPRADOS (8ª rodada) -------------------- */ ?>
<div class="position-relative d-flex align-items-center py-3 pt-4">
    <div class="flex-grow-1 border-top"></div>
    <span class="mx-3 fw-bold text-uppercase fs-7">ITENS COMPRADOS E AQUISIÇÃO</span>
    <div class="flex-grow-1 border-top"></div>
</div>

<?php if (!$slLiberada) : ?>
    <div class="alert alert-secondary fs-7">
        <i class="bi bi-info-circle me-1"></i>
        A aquisição abre após a liberação da SL.
    </div>
<?php endif; ?>

<?= $this->insert('desenvolvimento/aquisicaoPanel', [
    'solicitacao'         => $solicitacao,
    'itensComprados'      => $itensComprados,
    'resumoAquisicao'     => $resumoAquisicao,
    'aquisicaoHabilitada' => $aquisicaoHabilitada,
    'podeBypassAquisicao' => $podeBypassAquisicao,
    'editavel'            => $camposEditaveis,
]) ?>

<?php /* ---------------------------- AÇÕES ---------------------------- */ ?>
<div class="row mt-4">
    <div class="col-md-3">
        <?php if ($slCancelada) : ?>
            <button type="button" class="btn btn-outline-secondary btn-sm w-100" disabled>
                <i class="bi bi-x-circle me-1"></i> SL Cancelada
            </button>
        <?php elseif ($slLiberada) : ?>
            <button type="button" class="btn btn-warning btn-sm w-100"
                    title="Retorna a SL para revisão (liberação)"
                    onclick="abrirModalMotivo(<?= (int) $solicitacao->ref ?>, 'retornar')">
                <i class="bi bi-arrow-counterclockwise me-1"></i> Retornar SL
            </button>
        <?php elseif ($podeLiberar) : ?>
            <?php /* 8ª rodada — Liberar SL agora é da Industrial */ ?>
            <button type="button" class="btn btn-company btn-sm w-100"
                    id="btnLiberarSl"
                    title="Liberar a SL e registrar a consideração"
                    onclick="abrirModalLiberacao(<?= (int) $solicitacao->ref ?>)">
                Liberar SL
            </button>
        <?php else : ?>
            <button type="button" class="btn btn-secondary btn-sm w-100" disabled
                    title="Disponível após Conceito e Detalhamento estarem OK">
                <i class="bi bi-hourglass-split me-1"></i> Aguardando projeto
            </button>
        <?php endif; ?>
    </div>

    <div class="col-md-3">
        <a href="<?= route('dispositivos.industrial.lista') ?>" class="btn btn-secondary btn-sm w-100">
            <i class="bi bi-list me-1"></i> Voltar para a lista
        </a>
    </div>
</div>
