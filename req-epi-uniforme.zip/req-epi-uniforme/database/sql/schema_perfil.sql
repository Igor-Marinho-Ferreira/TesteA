-- =====================================================================
-- Requisição de EPI's e Uniformes — Controle de Perfis de Acesso
-- Define o que cada pessoa vê no menu/nas telas e se pode editar ou só ver.
-- Banco: bd_amsted · Prefixo de tabelas: epi_
-- =====================================================================

-- Perfil de acesso (ex.: Administrador, Administrativo, Líder)
CREATE TABLE IF NOT EXISTS epi_perfil (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    nome        VARCHAR(120)    NOT NULL,
    descricao   VARCHAR(200)    NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_epi_perfil_uuid (uuid),
    UNIQUE KEY uq_epi_perfil_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Permissões do perfil por módulo (Ver / Editar)
CREATE TABLE IF NOT EXISTS epi_perfil_permissao (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    perfil_id   BIGINT UNSIGNED NOT NULL,
    modulo      VARCHAR(60)     NOT NULL,   -- chave do módulo (ex.: item, lider, projeto)
    pode_ver    TINYINT(1)      NOT NULL DEFAULT 0,
    pode_editar TINYINT(1)      NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    UNIQUE KEY uq_epi_pp_perfil_modulo (perfil_id, modulo),
    KEY idx_epi_pp_perfil (perfil_id),
    CONSTRAINT fk_epi_pp_perfil FOREIGN KEY (perfil_id) REFERENCES epi_perfil (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vínculo usuário (matrícula) → perfil
CREATE TABLE IF NOT EXISTS epi_usuario_perfil (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    matricula   VARCHAR(40)     NOT NULL,
    nome        VARCHAR(160)    NULL,
    perfil_id   BIGINT UNSIGNED NOT NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_epi_up_uuid (uuid),
    UNIQUE KEY uq_epi_up_matricula (matricula),
    KEY idx_epi_up_perfil (perfil_id),
    CONSTRAINT fk_epi_up_perfil FOREIGN KEY (perfil_id) REFERENCES epi_perfil (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
