-- =====================================================================
-- Requisição de EPI's e Uniformes — Digitalização do processo de requisição
-- Banco: bd_amsted · Prefixo de tabelas: epi_
-- =====================================================================

-- 2.1.1.1 — Cadastro de EPI's e Uniformes
-- Código/descrição vêm do Logix (Informix); gravamos uma cópia local para
-- exibir a lista rapidamente na tela de requisição sem depender do Informix.
CREATE TABLE IF NOT EXISTS epi_item (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    tipo        ENUM('epi','uniforme') NOT NULL,
    codigo      VARCHAR(40)     NOT NULL,      -- código do item no Logix
    descricao   VARCHAR(200)    NOT NULL,      -- preenchida automaticamente a partir do Logix
    imagem      VARCHAR(255)    NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_epi_item_uuid (uuid),
    UNIQUE KEY uq_epi_item_codigo (codigo),
    KEY idx_epi_item_tipo (tipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.1.2 — Cadastro de Líderes (dados puxados do Sênior; cópia local para
-- exibição rápida no formulário de requisição)
CREATE TABLE IF NOT EXISTS epi_lider (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    matricula   VARCHAR(40)     NOT NULL,
    nome        VARCHAR(160)    NOT NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_epi_lider_uuid (uuid),
    UNIQUE KEY uq_epi_lider_matricula (matricula),
    KEY idx_epi_lider_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.1.3 — Cadastro de Projeto
CREATE TABLE IF NOT EXISTS epi_projeto (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    projeto     VARCHAR(160)    NOT NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_epi_projeto_uuid (uuid),
    UNIQUE KEY uq_epi_projeto_nome (projeto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crachás provisórios (lista de origem Foracesso + registro do nome de uso
-- no dia, feito localmente enquanto o sistema estiver offline do Foracesso)
CREATE TABLE IF NOT EXISTS epi_cracha_provisorio (
    id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid           CHAR(36)        NOT NULL,
    numero_cracha  VARCHAR(40)     NOT NULL,
    status         VARCHAR(20)     NOT NULL DEFAULT 'disponivel', -- disponivel/em_uso
    nome_uso       VARCHAR(160)    NULL,       -- nome informado pelo colaborador no dia
    matricula_uso  VARCHAR(40)     NULL,
    data_uso       DATE            NULL,
    hora_uso       TIME            NULL,
    sincronizado   TINYINT(1)      NOT NULL DEFAULT 0, -- já enviado ao Foracesso
    created_at     DATETIME        NULL,
    updated_at     DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_epi_cracha_uuid (uuid),
    KEY idx_epi_cracha_numero (numero_cracha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.1.4 — Requisição de EPI's e Uniformes pelos Operadores (cabeçalho)
CREATE TABLE IF NOT EXISTS epi_requisicao (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid                CHAR(36)        NOT NULL,
    numero              VARCHAR(20)     NOT NULL,   -- nº sequencial da requisição
    matricula           VARCHAR(40)     NOT NULL,
    nome_colaborador    VARCHAR(160)    NOT NULL,
    centro_custo        VARCHAR(40)     NULL,
    unidade_funcional   VARCHAR(80)     NULL,
    cargo               VARCHAR(120)    NULL,
    lider_matricula     VARCHAR(40)     NULL,
    projeto             VARCHAR(160)    NULL,
    cracha_numero       VARCHAR(40)     NULL,
    cracha_provisorio   TINYINT(1)      NOT NULL DEFAULT 0,
    regra_utilizada     VARCHAR(20)     NULL,       -- prioridade_1 / prioridade_2 (regra MX_CARGO_EPI)
    data_solicitacao    DATE            NOT NULL,
    hora_solicitacao    TIME            NOT NULL,
    status              VARCHAR(20)     NOT NULL DEFAULT 'pendente', -- pendente/atendida/parcial/cancelada
    created_at          DATETIME        NULL,
    updated_at          DATETIME        NULL,
    deleted_at          DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_epi_requisicao_uuid (uuid),
    UNIQUE KEY uq_epi_requisicao_numero (numero),
    KEY idx_epi_requisicao_matricula (matricula),
    KEY idx_epi_requisicao_data (data_solicitacao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Itens (EPI/Uniforme) de cada requisição
CREATE TABLE IF NOT EXISTS epi_requisicao_item (
    id                     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    requisicao_id          BIGINT UNSIGNED NOT NULL,
    item_id                BIGINT UNSIGNED NULL,     -- referência ao cadastro (pode ser nulo se o item foi excluído)
    item_tipo              ENUM('epi','uniforme') NOT NULL,
    item_codigo            VARCHAR(40)     NOT NULL,
    item_descricao         VARCHAR(200)    NOT NULL,
    quantidade_solicitada  INT             NOT NULL DEFAULT 1,
    quantidade_atendida    INT             NULL,
    status                 VARCHAR(20)     NOT NULL DEFAULT 'pendente', -- pendente/atendida/parcial
    PRIMARY KEY (id),
    KEY idx_epi_req_item_requisicao (requisicao_id),
    KEY idx_epi_req_item_item (item_id),
    CONSTRAINT fk_epi_req_item_requisicao FOREIGN KEY (requisicao_id) REFERENCES epi_requisicao (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
