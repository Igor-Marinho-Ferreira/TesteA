# Copilot Instructions

This project is a **custom PHP MVC framework** — not Laravel, Symfony, or any other standard framework. All conventions below are specific to this codebase and must be followed precisely.

---

## Execution Flow

```
index.php
  └── Bootstrap::start()
        ├── Router          → matches URI to a registered route
        ├── Middleware      → executes all middlewares attached to the route
        └── Controller      → dispatches to the controller method → returns View | Redirect | Json
```

---

## Module Creation Flow

When creating a new module, always start from `src/routes/routes.php` and proceed in order:

1. **Route** — register in `src/routes/routes.php`
2. **Controller** — create in `src/app/controllers/`
3. **Middleware** — create in `src/app/middlewares/` (when needed)
4. **Request** — create in `src/app/requests/` (for POST form validation)
5. **Service** — create in `src/app/services/` (business logic)
6. **Entity** — create in `src/app/database/entities/` (DB model)
7. **View** — create in `src/app/views/` (Plates templates)

---

## 1. Route (`src/routes/routes.php`)

```php
use src\app\controllers\BookingController;
use src\app\middlewares\IsLoggedMiddleware;
use src\core\Route;

Route::get('/bookings', BookingController::class, 'index')
    ->name('booking.index')
    ->middlewares([IsLoggedMiddleware::class]);

Route::post('/bookings/store', BookingController::class, 'store')
    ->name('booking.store')
    ->middlewares([IsLoggedMiddleware::class]);
```

- Use `Route::get()` or `Route::post()` — no other HTTP methods are supported.
- Always call `->name()` with `module.action` notation.
- Always call `->middlewares([])` — pass an empty array if no middleware is needed.
- Dynamic segments use `{param}` syntax: `Route::get('/bookings/{id}', ...)`.

---

## 2. Controller (`src/app/controllers/`)

```php
<?php

namespace src\app\controllers;

use src\app\requests\StoreBookingRequest;
use src\app\services\BookingService;

class BookingController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $data = (new BookingService)->listAll();
        return view('booking.index', compact('data'));
    }

    function store(StoreBookingRequest $request): mixed
    {
        $request->execute();
        (new BookingService)->store($request->get());
        notification()->success('Reserva salva com sucesso!');
        return redirect()->route('booking.index');
    }
}
```

- Controllers are **plain classes** — do **not** extend any base class.
- The constructor must always be present, even if empty.
- Methods receive injected Request objects via PHP-DI (type-hint the request class in the method signature).
- Methods must return `view()`, `redirect()->...`, or a `Json` response.
- Do **not** echo output directly.

---

## 3. Middleware (`src/app/middlewares/`)

```php
<?php

namespace src\app\middlewares;

class IsAdminMiddleware
{
    function execute(): void
    {
        $user = user();
        if (!$user || $user->role !== 'admin') {
            $login_url = path()->get_host() . "/" . path()->get_company();
            header("Location: {$login_url}");
            exit;
        }
    }
}
```

- Must implement a single public method: `execute(): void`.
- Use `header()` + `exit` to redirect — do not use the `redirect()` helper inside middlewares.

---

## 4. Request (`src/app/requests/`)

```php
<?php

namespace src\app\requests;

class StoreBookingRequest extends Request
{
    protected array $rules = [
        'employee_id' => 'required',
        'epi_id'      => 'required',
        'date'        => 'required',
    ];
}
```

- Always `extends Request` (the abstract base in `src\app\requests\Request`).
- Define validation rules in `protected array $rules`.
- Call `$request->execute()` inside the controller to trigger validation; on failure it auto-redirects back with an error notification.
- Use `$request->get()` to retrieve all POST inputs (excluding the token) or `$request->input('key')` for a single field.

---

## 5. Service (`src/app/services/`)

```php
<?php

namespace src\app\services;

use src\app\database\entities\Booking;

class BookingService
{
    public function listAll(): array|null
    {
        return Booking::select()->finish();
    }

    public function store(array $data): object
    {
        return Booking::insert($data)->finish();
    }
}
```

- Services are **plain classes** — do not extend anything.
- Contains business logic only; no HTTP concerns (no redirects, no views).
- Inject/instantiate entities directly.

---

## 6. Entity (`src/app/database/entities/`)

```php
<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Booking extends Querio
{
    protected static string $table  = 'schema_name.table_name';
    protected static string $dbType = 'connection_key';
}
```

- Always `extends Querio`.
- `$table` must be the fully qualified table name (`schema.table`).
- `$dbType` is the key used to resolve the database connection from the environment config.

### Querio Query Builder API

All methods are static and chainable. Always terminate a query with `->finish()`.

| Method | Description |
|---|---|
| `::select(array $fields = [])` | SELECT query (returns array or null) |
| `::selectOne(array $fields = [])` | SELECT with LIMIT 1 (returns object or null) |
| `::insert(array $data)` | INSERT query |
| `::update(array $data)` | UPDATE query — always chain a `where*` clause |
| `::where($col, $op, $val)` | WHERE clause |
| `::whereEquals($col, $val)` | WHERE col = val |
| `::andWhere($col, $op, $val)` | AND col op val |
| `::andWhereEquals($col, $val)` | AND col = val |
| `::orWhere($col, $op, $val)` | OR col op val |
| `::whereIn($col, array $vals)` | WHERE col IN (...) |
| `::andIn($col, array $vals)` | AND col IN (...) |
| `::whereNotIn($col, array $vals)` | WHERE col NOT IN (...) |
| `::whereBetween($col, $start, $end)` | WHERE col BETWEEN |
| `::andWhereBetween($col, $start, $end)` | AND col BETWEEN |
| `::whereIsNull($col)` | WHERE col IS NULL |
| `::andWhereIsNull($col)` | AND col IS NULL |
| `::whereIsNotNull($col)` | WHERE col IS NOT NULL |
| `::innerJoin($table, $col1, $op, $col2)` | INNER JOIN |
| `::leftJoin($table, $col1, $op, $col2)` | LEFT JOIN |
| `::rightJoin($table, $col1, $op, $col2)` | RIGHT JOIN |
| `::limit(int $n)` | LIMIT clause |
| `::finish()` | Execute and return result |

Examples:

```php
// Select all
Booking::select()->finish();

// Select filtered
Booking::select()
    ->whereEquals('status', 'active')
    ->andWhere('created_at', '>=', '2024-01-01')
    ->finish();

// Select single record
Booking::selectOne()->whereEquals('id', $id)->finish();

// Insert
Booking::insert(['employee_id' => 1, 'epi_id' => 5, 'date' => '2024-06-01'])->finish();

// Update
Booking::update(['status' => 'cancelled'])->whereEquals('id', $id)->finish();
```

---

## 7. View (`src/app/views/`)

Views use **League/Plates** templating. The engine root is `src/app/views/`.

- Route-to-file mapping uses **dot notation**: `view('booking.index')` → `src/app/views/booking/index.php`
- Always inherit the base layout. **Do not** wrap the body in `$this->start('content')` / `$this->stop()` — the section name `content` is **reserved** in Plates and throws an error. The child template's output is captured automatically and rendered by the base layout via `$this->section('content')`. Just declare the layout and output the body directly:

```php
<?php $this->layout('templates/base', [
    'webTitle'  => 'Bookings',
    'cardTitle' => 'Lista de Reservas',
]) ?>

<table class="table">
    <!-- content here -->
</table>
```

- To reuse markup across views, extract a partial (e.g. `booking/_form.php`) and include it with `$this->insert('booking/_form', [...])`.

- To pass extra CSS or JS files, use the `styles` and `js` arrays:

```php
<?php $this->layout('templates/base', [
    'webTitle'  => 'Bookings',
    'cardTitle' => 'Lista de Reservas',
    'styles'    => ['booking.css'],
    'js'        => ['booking.js'],
]) ?>
```

- Use `old('field')` to repopulate form fields after validation failure.
- Use `isWrong('field')` / `isWrongText('field')` to show inline field errors.

---

## 8. Global Helpers

These functions are always available globally (defined in `src/helpers/`):

| Helper | Description |
|---|---|
| `view(string $view, array $data = [])` | Render a Plates view |
| `redirect()` | Returns a `Redirect` instance — chain `->route('name')`, `->back()`, `->uri('/path')`, then `->make()` |
| `path()` | URL/path builder — `->css()`, `->js()`, `->images()`, `->get_url()`, `->get_host()`, `->get_company()` |
| `notification()->success($msg)` | Flash success toast notification |
| `notification()->error($msg)` | Flash error toast notification |
| `notification()->warning($msg)` | Flash warning toast notification |
| `old(string $key)` | Retrieve old POST input after redirect |
| `isWrong(string $key)` | Check if a field failed validation |
| `isWrongText(string $key)` | Get the validation error message for a field |
| `formValidate(array $rules)` | Validate $_POST against rules, returns data or false |
| `user()` | Returns the current authenticated user from session, or null |
| `request()` | Raw request helper with `->all()`, `->get($key)`, `->has($key)`, `->type()` |
| `backError($messages)` | Shorthand for `redirect()->back()->withError($messages)` |
| `backSuccess($messages)` | Shorthand for `redirect()->back()->withSuccess($messages)` |

---

## 9. Naming Conventions

| Layer | Pattern | Example |
|---|---|---|
| Controller | `PascalCase` + `Controller` | `BookingController` |
| Middleware | `PascalCase` + `Middleware` | `IsAdminMiddleware` |
| Request | `PascalCase` + `Request` | `StoreBookingRequest` |
| Entity | `PascalCase` singular | `Booking` |
| Service | `PascalCase` + `Service` | `BookingService` |
| Route name | `module.action` | `booking.store` |
| View file | dot notation | `booking.index` → `src/app/views/booking/index.php` |

---

## 10. Namespace Map

| Layer | Namespace |
|---|---|
| Controllers | `src\app\controllers` |
| Middlewares | `src\app\middlewares` |
| Requests | `src\app\requests` |
| Services | `src\app\services` |
| Entities | `src\app\database\entities` |
| Core | `src\core` |
| Support | `src\support` |

---

## 11. What NOT to do

- Do **not** use Laravel, Symfony, or any other framework's patterns.
- Do **not** extend any base Controller class — controllers are plain PHP classes.
- Do **not** use `echo` inside controllers — always return a `view()` or `redirect()`.
- Do **not** call `redirect()` inside middlewares — use `header()` + `exit` instead.
- Do **not** write SQL strings manually in controllers or services — always use the Querio query builder.
- Do **not** access `$_POST`, `$_GET`, or `$_SESSION` directly in controllers — use the Request helpers and `Sessions` support class.
