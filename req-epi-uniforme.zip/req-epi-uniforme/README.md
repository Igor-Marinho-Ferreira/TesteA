# 🦺 Requisição de EPIs e Uniformes

Digitalização do processo de **requisição de EPIs (Equipamentos de Proteção Individual)
e uniformes** da Amsted Maxion.

Substitui os 4 painéis físicos onde os colaboradores hoje preenchem folhas de papel
(coletadas manualmente todo dia pelo administrativo e depois registradas nas telas
MAX0431/MAX5740) por um formulário digital com **identificação via leitor de crachá**,
eliminando o deslocamento para coleta e a perda de requisições.

## 🎯 Visão Geral

Hoje o processo depende de coleta física diária de folhas em 4 painéis, com validação
manual das informações preenchidas. Este projeto digitaliza o fluxo: o colaborador se
identifica pelo crachá, escolhe entre EPI ou uniforme, seleciona os itens e confirma —
tudo registrado com rastreabilidade e disponível em relatório para auditoria.

## ✨ Módulos (escopo)

**Parametrização**
- Cadastro de EPI's e Uniformes (código validado no Logix, imagem)
- Cadastro de Líderes (dados do Sênior)
- Cadastro de Projeto

**Requisição**
- Requisição de EPI's e Uniformes pelos Operadores (identificação via crachá,
  incluindo crachás provisórios do Foracesso)
- Regra de reserva de EPI por matrícula/unidade funcional/cargo (`MX_CARGO_EPI`)
- Relatório de Requisição de EPIs e Uniformes (filtros por período/matrícula, Excel)

> O detalhamento fino de campos e regras de cada tela está no documento de escopo
> enviado pelo cliente. As integrações externas (Logix, Foracesso, Sênior, via
> Informix) estão com pontos de extensão marcados como `TODO` nos services,
> aguardando as queries reais.

## 🏗️ Arquitetura

Aplicação **PHP** com arquitetura **MVC** própria (o mesmo framework reaproveitado
dos projetos DDS e Checklist de Soldagem). Convenções detalhadas em
[`.claude/instructions.md`](.claude/instructions.md).

```
src/
├── app/
│   ├── controllers/      # Controladores da aplicação
│   ├── database/         # Database, Querio (query builder) e entities
│   ├── middlewares/      # Middlewares (ex.: IsLoggedMiddleware)
│   ├── requests/         # Form requests
│   └── views/            # Views e templates (League Plates)
├── core/                 # Núcleo (Router, Controller, Route, Bootstrap)
├── exceptions/           # Exceções (incl. mapeamento de erros PDO)
├── helpers/              # Funções auxiliares globais
├── routes/               # Definição de rotas
├── support/               # Suporte (View, Request, Validate, Mailer, Logger, etc.)
└── traits/               # Traits reutilizáveis
```

**Convenção de tabelas:** banco `bd_amsted`, prefixo `epi_` (ex.: `epi_item`,
`epi_requisicao`).

## 🛠️ Stack

- **Backend**: PHP (MVC próprio)
- **Banco intranet**: MySQL (`dbType` = `intranet`, banco `bd_amsted`)
- **Template Engine**: League Plates
- **Dependências**: Guzzle HTTP, SimplexLSXGen (Excel), PHPSecLib, PHPMailer, Symfony Console
- **Integrações**: Logix/Informix (`dbType` = `informix`), Sênior (`dbType` = `senior`),
  Foracesso (`dbType` = `foracesso`)

## 📝 Licença

MIT
