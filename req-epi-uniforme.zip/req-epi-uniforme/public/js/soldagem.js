/**
 * SR-3297 — comportamentos compartilhados dos cadastros.
 *  1) Confirmação de exclusão via modal (#confirmDeleteModal) para
 *     qualquer <form class="js-confirm-delete"> (mensagem em data-confirm-text).
 *  2) Filtro client-side de tabela: <input data-filter-input="#tabela"
 *     data-filter-count="#badge"> filtra as <tr data-row> do tbody.
 */
(function () {
    // ---- 1) Confirmação de exclusão ---------------------------------------
    var modalEl = document.getElementById("confirmDeleteModal");
    if (modalEl && typeof bootstrap !== "undefined") {
        var modal = new bootstrap.Modal(modalEl);
        var textEl = document.getElementById("confirmDeleteText");
        var confirmBtn = document.getElementById("confirmDeleteBtn");
        var pendingForm = null;

        document.querySelectorAll("form.js-confirm-delete").forEach(function (form) {
            form.addEventListener("submit", function (e) {
                if (form.dataset.confirmed === "true") return;
                e.preventDefault();
                pendingForm = form;
                if (textEl)
                    textEl.textContent =
                        form.dataset.confirmText || "Deseja realmente excluir este registro?";
                modal.show();
            });
        });

        if (confirmBtn) {
            confirmBtn.addEventListener("click", function () {
                if (!pendingForm) return;
                pendingForm.dataset.confirmed = "true";
                pendingForm.submit();
            });
        }

        modalEl.addEventListener("hidden.bs.modal", function () {
            pendingForm = null;
        });
    }

    // ---- 2) Filtro de tabela ----------------------------------------------
    function norm(s) {
        return (s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
    }

    document.querySelectorAll("[data-filter-input]").forEach(function (input) {
        var table = document.querySelector(input.getAttribute("data-filter-input"));
        if (!table) return;

        var tbody = table.querySelector("tbody");
        var emptyRow = tbody.querySelector("[data-filter-empty]");
        var countSel = input.getAttribute("data-filter-count");
        var countEl = countSel ? document.querySelector(countSel) : null;

        function apply() {
            var q = norm(input.value.trim());
            var visible = 0;
            tbody.querySelectorAll("tr[data-row]").forEach(function (tr) {
                var show = q === "" || norm(tr.textContent).indexOf(q) !== -1;
                tr.style.display = show ? "" : "none";
                if (show) visible++;
            });
            if (emptyRow) emptyRow.style.display = visible === 0 ? "" : "none";
            if (countEl) countEl.textContent = visible + " registro(s)";
        }
        input.addEventListener("input", apply);
    });

    // ---- 4) Salvar rascunho (no banco, server-side) -----------------------
    // Uso: <form data-rascunho="modulo-referencia"> + botão [data-salvar-rascunho].
    // Salva o formulário no servidor (por matrícula); ao voltar, oferece restaurar.
    var R = window.__ROUTES || {};
    document.querySelectorAll("form[data-rascunho]").forEach(function (form) {
        var chave = form.getAttribute("data-rascunho") || "";
        var corte = chave.indexOf("-");
        if (corte < 0) return;
        var modulo = chave.slice(0, corte);
        var ref = chave.slice(corte + 1);

        function coleta() {
            var dados = [];
            form.querySelectorAll("input, select, textarea").forEach(function (el) {
                if (!el.name) return;
                if (["file", "submit", "button", "password"].indexOf(el.type) !== -1) return;
                if (el.type === "checkbox" || el.type === "radio") dados.push({ n: el.name, v: el.value, c: el.checked, t: el.type });
                else dados.push({ n: el.name, v: el.value, t: el.type });
            });
            return dados;
        }

        function esc(s) { return window.CSS && CSS.escape ? CSS.escape(s) : s.replace(/(["\\\]\[])/g, "\\$1"); }

        function restaura(dados) {
            var porNome = {};
            dados.forEach(function (x) { (porNome[x.n] = porNome[x.n] || []).push(x); });
            Object.keys(porNome).forEach(function (nome) {
                var els = form.querySelectorAll('[name="' + esc(nome) + '"]');
                var vals = porNome[nome];
                els.forEach(function (el, i) {
                    var x = vals[i];
                    if (!x) return;
                    if (el.type === "checkbox" || el.type === "radio") el.checked = !!x.c;
                    else el.value = x.v;
                    el.dispatchEvent(new Event("change"));
                });
            });
        }

        function salvar(btn) {
            if (!R.rascunhoSalvar) return;
            var fd = new FormData();
            fd.append("modulo", modulo);
            fd.append("ref", ref);
            fd.append("payload", JSON.stringify(coleta()));
            var txt = btn ? btn.innerHTML : "";
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="ph ph-spinner"></i> Salvando...'; }
            fetch(R.rascunhoSalvar, { method: "POST", body: fd })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (btn) {
                        btn.innerHTML = d && d.ok ? '<i class="ph ph-check"></i> Rascunho salvo' : '<i class="ph ph-warning"></i> Falhou';
                        setTimeout(function () { btn.innerHTML = txt; btn.disabled = false; }, 1800);
                    }
                })
                .catch(function () { if (btn) { btn.innerHTML = txt; btn.disabled = false; } });
        }

        function descartar() {
            if (!R.rascunhoDescartar) return;
            var fd = new FormData();
            fd.append("modulo", modulo);
            fd.append("ref", ref);
            fetch(R.rascunhoDescartar, { method: "POST", body: fd, keepalive: true }).catch(function () {});
        }

        function banner(dados) {
            var div = document.createElement("div");
            div.className = "alert alert-warning d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3";
            div.innerHTML = '<span><i class="ph ph-clock-counter-clockwise"></i> Você tem um rascunho salvo deste formulário.</span>' +
                '<span><button type="button" class="btn btn-sm btn-success me-2" data-r-restaurar>Restaurar</button>' +
                '<button type="button" class="btn btn-sm btn-outline-secondary" data-r-descartar>Descartar</button></span>';
            form.parentNode.insertBefore(div, form);
            div.querySelector("[data-r-restaurar]").addEventListener("click", function () { restaura(dados); div.remove(); });
            div.querySelector("[data-r-descartar]").addEventListener("click", function () { descartar(); div.remove(); });
        }

        form.querySelectorAll("[data-salvar-rascunho]").forEach(function (b) {
            b.addEventListener("click", function () { salvar(b); });
        });
        // Ao enviar de verdade, o rascunho não é mais necessário.
        form.addEventListener("submit", descartar);

        // Ao abrir, busca rascunho salvo no servidor.
        if (R.rascunhoObter) {
            fetch(R.rascunhoObter + "?modulo=" + encodeURIComponent(modulo) + "&ref=" + encodeURIComponent(ref))
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (!d || !d.payload) return;
                    var dados;
                    try { dados = JSON.parse(d.payload); } catch (e) { return; }
                    if (dados && dados.length) banner(dados);
                })
                .catch(function () {});
        }
    });

    // ---- 3) Auto-preencher descrição a partir de um <select> --------------
    // Uso: <select data-fill-desc="#alvo"> com <option data-desc="...">.
    // Ao selecionar, copia o data-desc da opção para o campo #alvo.
    document.querySelectorAll("select[data-fill-desc]").forEach(function (sel) {
        var alvo = document.querySelector(sel.getAttribute("data-fill-desc"));
        if (!alvo) return;
        sel.addEventListener("change", function () {
            var opt = sel.options[sel.selectedIndex];
            var desc = opt ? (opt.getAttribute("data-desc") || "") : "";
            // Só sobrescreve se o alvo estiver vazio ou se forçado (data-fill-force).
            if (desc !== "" && (alvo.value.trim() === "" || sel.hasAttribute("data-fill-force"))) {
                alvo.value = desc;
            }
        });
    });

    // ---- 5) Travar o botão ao enviar (Registrar / Atualizar / Salvar) -----
    // Ao enviar de verdade qualquer formulário, desabilita o botão clicado e
    // mostra um spinner "Processando...", evitando duplo clique / duplo envio.
    document.addEventListener("submit", function (e) {
        var form = e.target;
        // Se outro handler cancelou o envio (ex.: modal de exclusão) ou o form é
        // inválido (validação HTML5), não trava.
        if (e.defaultPrevented) return;
        if (form.checkValidity && !form.checkValidity()) return;

        var btn = e.submitter || form.querySelector('button[type="submit"], input[type="submit"]');
        if (!btn || btn.dataset.enviando === "1") return;
        btn.dataset.enviando = "1";
        var original = btn.innerHTML;
        var label = btn.getAttribute("data-loading") || "Processando...";

        // Desabilita APÓS o envio iniciar (setTimeout 0), para não remover o
        // name/value do botão clicado da submissão (ex.: Aprovar/Rejeitar).
        setTimeout(function () {
            if (btn.tagName === "BUTTON") {
                btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>' + label;
            }
            btn.disabled = true;
            btn.classList.add("disabled");
        }, 0);

        // Segurança: se a página não navegar (erro/cancelamento), reabilita.
        setTimeout(function () {
            btn.disabled = false;
            btn.classList.remove("disabled");
            btn.dataset.enviando = "";
            if (btn.tagName === "BUTTON") btn.innerHTML = original;
        }, 20000);
    }, false);
})();
