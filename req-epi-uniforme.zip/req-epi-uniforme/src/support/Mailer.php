<?php
namespace src\support;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Mailer
{
    private PHPMailer $mailer;


    function __construct()
    {
        $this->settingsPHPMailer();
    }

    public function settingsPHPMailer(
    ): void {
        $mailer = require("/var/www/htdocs/greenbrier/tools/mailer/return.php");
        $mailer->CharSet = 'UTF-8';
        $mailer->isHTML(true);
        $this->mailer = $mailer;
    }

    /**
     * Responsible for configuring the recipients
     * @param string|array<int, string> $addressees  array empty as default
     * @return self
     */
    public function setAddressees(string|array $addressees = []): self
    {
        if (is_array($addressees))
            foreach ($addressees as $address) {
                $this->mailer->addAddress($address);
            } else
            $this->mailer->addAddress($addressees);

        return $this;
    }

    /**
     * Responsible for configuring the body
     * @param string $body
     * @return self
     */
    public function setBody(string $body): self
    {
        $this->mailer->Body = $body;
        return $this;
    }


    /**
     * Responsible for configuring the title
     * @param string $subject
     * @return self
     */
    public function setSubject(string $subject): self
    {
        $this->mailer->Subject = $subject;
        return $this;
    }

    /**
     * Responsible for shooting the email
     * @return bool
     */
    public function fire(): bool
    {
        try {
            $this->mailer->send();
            $this->setAddressees();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}
