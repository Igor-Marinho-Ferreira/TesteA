<?php

namespace src\support;

final class Status
{

    public const OPENED = 2;
    public const PENDING_DEV = 10;
    public const PENDING_FORN = 7;
    public const PENDING_INFRA = 8;
    public const PENDING_SEC = 15;
    public const PENDING_SIS = 19;
    public const PENDING_CLI = 18;
    public const RESOLVED = 4;
    public const CLOSED = 5;
    public const PENDING_DIRECTOR = 14;
    public const PENDING_MANAGER = 13;

}
