<?php

namespace src\support;

use Exception;

class Token
{
    /**
     * Gera um token único e seguro
     * @param int $length Tamanho do token (padrão: 64)
     * @return string Token gerado
     */
    public static function generate(int $length = 64): string
    {
        return bin2hex(random_bytes($length / 2));
    }

    /**
     * Gera um hash seguro do token usando SHA-256
     * @param string $token Token em texto plano
     * @return string Hash do token
     */
    public static function hash(string $token): string
    {
        return hash('sha256', $token);
    }

    /**
     * Gera um token com prazo de validade
     * @param int $expirationMinutes Tempo de expiração em minutos (padrão: 60)
     * @return array Retorna um array com o token e a data de expiração
     */
    public static function generateWithExpiration(int $expirationMinutes = 60): array
    {
        $token = self::generate();
        $expiresAt = date('Y-m-d H:i:s', strtotime("+{$expirationMinutes} minutes"));

        return [
            'token' => $token,
            'hashed_token' => self::hash($token),
            'expires_at' => $expiresAt
        ];
    }

    /**
     * Verifica se um token está expirado
     * @param string $expiresAt Data de expiração no formato Y-m-d H:i:s
     * @return bool True se expirado, False caso contrário
     */
    public static function isExpired(string $expiresAt): bool
    {
        $expirationTime = strtotime($expiresAt);
        $currentTime = time();

        return $currentTime > $expirationTime;
    }

    /**
     * Valida se um token corresponde ao hash armazenado
     * @param string $token Token em texto plano
     * @param string $hashedToken Hash armazenado
     * @return bool True se válido, False caso contrário
     */
    public static function verify(string $token, string $hashedToken): bool
    {
        return hash_equals($hashedToken, self::hash($token));
    }

    /**
     * Gera um token de API
     * @param string $prefix Prefixo do token (ex: 'api', 'bearer')
     * @param int $length Tamanho do token
     * @return string Token com prefixo
     */
    public static function generateApiToken(string $prefix = 'api', int $length = 64): string
    {
        return $prefix . '_' . self::generate($length);
    }

    /**
     * Calcula o tempo restante até a expiração
     * @param string $expiresAt Data de expiração no formato Y-m-d H:i:s
     * @return int Segundos restantes (negativo se expirado)
     */
    public static function timeRemaining(string $expiresAt): int
    {
        $expirationTime = strtotime($expiresAt);
        $currentTime = time();

        return $expirationTime - $currentTime;
    }

    /**
     * Verifica se o token está prestes a expirar (dentro de X minutos)
     * @param string $expiresAt Data de expiração no formato Y-m-d H:i:s
     * @param int $thresholdMinutes Minutos de threshold (padrão: 5)
     * @return bool True se está prestes a expirar
     */
    public static function isExpiringSoon(string $expiresAt, int $thresholdMinutes = 5): bool
    {
        $remaining = self::timeRemaining($expiresAt);
        return $remaining > 0 && $remaining <= ($thresholdMinutes * 60);
    }
}
