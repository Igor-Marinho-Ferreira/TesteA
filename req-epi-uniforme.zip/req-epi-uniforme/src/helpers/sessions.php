<?php

use phpseclib3\Net\SFTP;
use src\support\Sessions;

/**
 * Its responsible for get a session from index 'old'
 *
 * @param string $key
 * @return mixed
 */
function old(string $key)
{
    if (isset($_SESSION['old']) and isset($_SESSION['old'][$key]))
        return $_SESSION['old'][$key];

    return null;
}





/**
 * Its responsible for return if an index exist in 'isWrong' from $_SESSION
 *
 * @param string $key
 * @return mixed
 */
function isWrong(string $key)
{
    $sessionIsWrong = isset($_SESSION['isWrong']);
    if (!$sessionIsWrong)
        return null;
    else
        return isset($_SESSION['isWrong'][$key]);
}

/**
 * Its responsible for return a text from 'isWrong' in $_SESSION
 *
 * @param string $key
 * @return mixed
 */
function isWrongText(string $key)
{
    $sessionIsWrong = isset($_SESSION['isWrong']);
    if (!$sessionIsWrong)
        return null;
    else
        return isset($_SESSION['isWrong'][$key]) ? $_SESSION['isWrong'][$key] : null;
}


/**
 * Its responsible for forget multiples sessions
 *
 * @param array<int, string> $sessions
 * @return void
 */
function forgetSessions($sessions = []): void
{
    foreach ($sessions as $index => $session) {
        if (isset($_SESSION[$session]))
            unset($_SESSION[$session]);
    }
}

/**
 * Its responsible for return 'is-invalid' or 'is-valid' when isWrong contais a key
 *
 * @param string $key
 * @return mixed
 */
function applyWrong(string $key)
{
    if (Sessions::get('isWrong')) {
        $keyWrong = isWrong($key) ? 'is-invalid' : 'is-valid';
        return $keyWrong;
    }
    return null;
}

/**
 * Its responsible for return the text from isWrongText
 *
 * @param string $key
 * @return mixed
 */
function applyWrongText(string $key)
{
    if (Sessions::get('isWrong'))
        return isWrongText($key);
    return null;
}

/**
 * Its verify if session 'old' exists
 *
 * @return boolean
 */
function hasOld()
{
    return Sessions::get('old');
}

/**
 * Its apply old in checkbox simple
 *
 * @param string $key
 * @return string
 */
function applyOldCheck(string $key): string
{
    $isChecked = '';
    if (hasOld())
        $isChecked = old($key) ? 'checked' : '';
    else
        $isChecked = 'checked';
    return $isChecked;
}


/**
 * Its apply old in simple select
 *
 * @param mixed $value
 * @param string $key
 * @return mixed
 */
function applyOldSelectSimple($value, $key)
{
    if (!hasOld())
        return null;
    else
        return ($value === old($key)) ? 'selected' : '';
}

/**
 * Its responsible for apply old in input
 *
 * @param string $key
 * @return mixed
 */
function applyOldInput(string $key)
{
    if (hasOld())
        return old($key);
    else
        return null;
}


function fromGet(string $k)
{
    $r = $_GET[$k] ?? null;

    if (empty($r))
        return null;

    return $_GET[$k] ?? null;
}


function getStatus(string $statusCode)
{
    $status = [
        "A" => "Em andamento",
        "C" => "Cancelado",
        "R" => "Rejeitado",
        "P" => "Finalizado",
    ];
    return $status[$statusCode] ?? null;
}





/**
 * Returns the first and last name from a full name string.
 *
 * @param string $fullName The full name of the person.
 * @return string The first and last name concatenated.
 */
function getFirstAndLastName(string $fullName): string
{
    // Clean and normalize whitespace
    $cleanName = trim(preg_replace('/\s+/', ' ', $fullName));

    // Split the name into parts
    $nameParts = explode(' ', $cleanName);

    // If there's only one name, return it
    if (count($nameParts) === 1) {
        return ucfirst(strtolower($nameParts[0]));
    }

    $firstName = ucfirst(strtolower($nameParts[0]));
    $lastName = ucfirst(strtolower(end($nameParts)));

    return "{$firstName} {$lastName}";
}


function user()
{
    if (is_remote()) {
        if (isset($_SESSION["user"]))
            return (object) $_SESSION["user"];
        return null;
    } else {
        return (object) [
            "matricula" => "000001",
            "nome" => "local user"
        ];
    }
}


/**
 * Matrículas autorizadas a acessar a tela de Configurações (dump do banco).
 *
 * @var array<int, string>
 */
const CONFIG_ADMIN_MATRICULAS = ['566674'];

/**
 * Indica se o usuário logado pode acessar a tela de Configurações.
 */
function can_access_configs(): bool
{
    $u = user();
    return $u && in_array((string) ($u->matricula ?? ''), CONFIG_ADMIN_MATRICULAS, true);
}



function dbEnv(string $file): array
{
    return is_remote() ? db_remote($file) : db_local();
}


/**
 * obtem os parâmetros para conexao remota com os servidores de teste e produção
 * @param string $file
 * @return array
 */
function db_remote(string $file): array
{
    $company = path()->get_company();
  

    $map = [
        "DB_FILE_INTRANET" => "/var/www/htdocs/{$company}/includes/configuracoes59.php",
        "DB_FILE_WORKFLOW" => "/var/www/htdocs/{$company}/includes/sqlserver_wf_prod.php",
        "DB_FILE_INFORMIX" => "/var/www/htdocs/{$company}/includes/informix.php",
        "DB_FILE_SENIOR" => "/var/www/htdocs/{$company}/includes/sqlserver_senior.php",
        "DB_FILE_SENIOR_GBMX" => "/var/www/htdocs/{$company}/includes/senior_gbmx.php",
        "DB_FILE_POWERBI" => "/var/www/htdocs/{$company}/includes/etl_ho.php",
        "DB_FILE_POWERBI_AMMX" => "/var/www/htdocs/{$company}/includes/etl_crz.php",
        "DB_FILE_FORACESSO" => "/var/www/htdocs/{$company}/includes/foracesso.php",
    ];
    return require $map[$file];
}

/**
 * obtém os parâmetros para conexão local (exemplo está usando o docker)
 * @return array{DB_HOST: string, DB_NAME: string, DB_PASSWORD: string, DB_TYPE: string, DB_USER: string}
 */
function db_local(): array
{
    return [
        "DB_TYPE" => "mysql",
        "DB_HOST" => "mysql-db",
        "DB_USER" => "root",
        "DB_PASSWORD" => "root",
        "DB_NAME" => "ammx",
    ];
}


/**
 * verifica se a execução do app está em um servidor remoto
 * @return bool
 */
function is_remote(): bool
{
    return in_array(
        path()->get_host(),
        ["http://172.30.0.59", "http://172.30.0.94", "http://172.29.5.2", "http://intranetprod.amstedmaxion.com.br", "https://intranetprod.amstedmaxion.com.br"]
    );
}



function sftp_connect(
    string $host,
    string $usuario,
    string $senha,
    int $porta = 22,
    int $timeout = 10
): SFTP {
    $sftp = new SFTP($host, $porta, $timeout);

    if (!$sftp->login($usuario, $senha)) {
        throw new Exception('Falha no login SFTP');
    }

    return $sftp;
}



function sftp_list(string $diretorio, SFTP $sftp): array
{
    $lista = $sftp->rawlist($diretorio);
    if ($lista === false)
        backError("Diretório não encontrado ou sem permissão de acesso.");


    $resultado = [
        'dirs' => [],
        'files' => []
    ];

    foreach ($lista as $nome => $info) {
        if (in_array($nome, ['.', '..'])) {
            continue;
        }

        $t = $info["type"] === 2 ? 'dirs' : 'files';
        $resultado[$t][] = [
            'nome' => $nome,
            'tipo' => ($info['type'] === 'dir') ? 'directory' : 'file',
            'tamanho' => $info['size'] ?? 0,
            'tamanho_formatado' => formatBytes($info['size'] ?? 0),
            'path' => rtrim($diretorio, '/') . '/' . $nome,
            'data_modificacao' => isset($info['mtime'])
                ? date('Y-m-d H:i:s', $info['mtime'])
                : null,
            'timestamp' => $info['mtime'] ?? null,
            'permissions' => isset($info['mode'])
                ? substr(sprintf('%o', $info['mode']), -4)
                : null
        ];
    }

    return $resultado;
}



function sftp_mk_dir(SFTP $sftp, string $diretorio): bool
{
    return $sftp->mkdir($diretorio, -1, true);
}


function sftp_move_file(SFTP $sftp, string $arquivo): bool
{
    $day = date('Ymd');
    $backupPath = "/totvs/garql/backup/{$day}/";


    $fileName = basename($arquivo);
    $backupFilePath = rtrim($backupPath, '/') . '/' . $fileName . "_" . time();

    try {
        if (!$sftp->is_dir($backupPath)) {
            $pathParts = array_filter(explode('/', trim($backupPath, '/')));
            $currentPath = '';

            foreach ($pathParts as $part) {
                $currentPath .= '/' . $part;
                if (!$sftp->is_dir($currentPath)) {
                    $sftp->mkdir($currentPath);
                }
            }
        }

        return $sftp->rename($arquivo, $backupFilePath);
    } catch (\Exception $e) {
        error_log("Erro ao mover arquivo para backup: " . $e->getMessage());
        return false;
    }
}

function sftp_dropfile(SFTP $sftp, string $arquivo): bool
{
    try {
        return $sftp->delete($arquivo);
    } catch (\Exception $e) {
        error_log("Erro ao deletar arquivo permanentemente: " . $e->getMessage());
        return false;
    }
}

function sftp_rmdir(SFTP $sftp, string $diretorio): bool
{
    return $sftp->rmdir($diretorio);
}

function sftp_rmdir_recursive(SFTP $sftp, string $diretorio): bool
{
    $contents = $sftp->rawlist($diretorio);

    if (!is_array($contents) || empty($contents)) {
        return $sftp->rmdir($diretorio);
    }

    foreach ($contents as $arquivo => $dados) {
        if ($arquivo === '.' || $arquivo === '..') {
            continue;
        }
        $path = rtrim($diretorio, '/') . '/' . $arquivo;

        if (is_array($dados) && isset($dados['type']) && $dados['type'] === 2) {
            sftp_rmdir_recursive($sftp, $path);
        } else {
            $sftp->delete($path);
        }
    }

    return $sftp->rmdir($diretorio);
}

function sftp_dir_rename(SFTP $sftp, string $dirPath, string $oldName, string $newName): bool
{
    try {
        $oldPath = $dirPath;
        $newPath = str_replace($oldName, $newName, $dirPath);
        $renamed = $sftp->rename($oldPath, $newPath);
        return $renamed;
    } catch (\Exception $e) {
        error_log("Erro ao renomear diretório: " . $e->getMessage());
        return false;
    }
}

/**
 * Formata bytes em formato legível
 * 
 * @param int $bytes
 * @param int $precision
 * @return string
 */
function formatBytes(int $bytes, int $precision = 2): string
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];

    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }

    return round($bytes, $precision) . ' ' . $units[$i];
}

/**
 * Lista informações de um diretório via SFTP
 * 
 * @param SFTP $sftp Instância de conexão SFTP
 * @param string $dirPath Caminho do diretório no servidor
 * @return array|null Retorna array com informações (nome, tamanho, path, permissões) ou null se não existir
 */
function getDirectoryInfo(SFTP $sftp, string $dirPath): ?array
{
    if (!$sftp->is_dir($dirPath)) {
        return null;
    }

    $dirName = basename($dirPath);
    $dirSize = calculateDirectorySize($sftp, $dirPath);
    $stat = $sftp->stat($dirPath);

    if (!$stat) {
        return null;
    }


    $permissions = substr(sprintf('%o', $stat['mode']), -4);
    return [
        'nome' => $dirName,
        'tamanho' => $dirSize,
        'tamanho_formatado' => formatBytes($dirSize),
        'path' => $dirPath,
        'permissoes' => $permissions,
        'permissoes_numerica' => $stat['mode'],
        'uid' => $stat['uid'] ?? null,
        'gid' => $stat['gid'] ?? null,
        'atime' => $stat['atime'] ?? null,
        'mtime' => $stat['mtime'] ?? null,
    ];
}

/**
 * Calcula o tamanho total de um diretório via SFTP recursivamente
 * 
 * @param SFTP $sftp Instância de conexão SFTP
 * @param string $dirPath Caminho do diretório no servidor
 * @return int Tamanho em bytes
 */
function calculateDirectorySize(SFTP $sftp, string $dirPath): int
{
    $size = 0;

    $contents = $sftp->rawlist($dirPath);
    if ($contents === false) {
        return 0;
    }

    foreach ($contents as $filename => $attributes) {
        if ($filename === '.' || $filename === '..') {
            continue;
        }

        $filePath = rtrim($dirPath, '/') . '/' . $filename;

        // Verificar se é arquivo
        if (isset($attributes['type']) && $attributes['type'] === 1) {
            $size += $attributes['size'] ?? 0;
        }
        // Verificar se é diretório
        elseif (isset($attributes['type']) && $attributes['type'] === 2) {
            $size += calculateDirectorySize($sftp, $filePath);
        }
        // Alternativa: verificar por permissões se type não estiver disponível
        elseif (!isset($attributes['type'])) {
            if ($sftp->is_file($filePath)) {
                $size += $attributes['size'] ?? 0;
            } elseif ($sftp->is_dir($filePath)) {
                $size += calculateDirectorySize($sftp, $filePath);
            }
        }
    }

    return $size;
}



function gflush(mixed $m)
{
    echo '<br>';
    echo '<br>';
    dump($m);
    ob_flush();
    flush();
}