<?php

namespace src\traits;

/**
 * Comportamento comum aos cadastros simples de parametrização
 * (Juntas, Metal Base, Gás, Treinamento, Modelo, Cliente, Estágio, etc.).
 *
 * A classe que usar este trait deve implementar:
 *   - entity(): string      → FQCN da entity (que herda Querio)
 *   - campoUnico(): string  → coluna usada para impedir duplicidade
 */
trait CadastroSimples
{
    /**
     * Lista os registros ativos (não excluídos), mais recentes primeiro.
     * @return array<int, object>
     */
    public function listAll(): array
    {
        $e = $this->entity();
        return $e::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    /**
     * Busca um registro pelo uuid.
     */
    public function find(string $uuid): mixed
    {
        $e = $this->entity();
        return $e::getByUuid($uuid);
    }

    /**
     * Indica se já existe um registro com o mesmo valor no campo único
     * (ignorando, opcionalmente, o registro de $ignoreUuid — usado na edição).
     */
    public function existeDuplicado(string $valor, ?string $ignoreUuid = null): bool
    {
        $e     = $this->entity();
        $campo = $this->campoUnico();

        $achados = $e::select()
            ->whereEquals($campo, $valor)
            ->andWhereIsNull('deleted_at')
            ->finish() ?: [];

        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) {
                return true;
            }
        }
        return false;
    }

    /**
     * Cria um novo registro. Se já existir um registro com o mesmo valor no
     * campo único que foi EXCLUÍDO (soft delete), ele é restaurado em vez de
     * inserir uma nova linha — isso evita o erro de UNIQUE ao "salvar de novo"
     * algo que havia sido apagado.
     * @param array<string, mixed> $data
     */
    public function store(array $data): bool|array|object
    {
        $e     = $this->entity();
        $campo = $this->campoUnico();
        $valor = $data[$campo] ?? null;

        if ($valor !== null) {
            $existente = $e::selectOne()->whereEquals($campo, $valor)->finish();
            if ($existente && $existente->deleted_at !== null) {
                // Restaura o registro excluído com os novos dados.
                unset($data['uuid']);
                $data['deleted_at'] = null;
                $data['updated_at'] = date('Y-m-d H:i:s');
                return $e::update($data)->whereEquals('uuid', $existente->uuid)->finish();
            }
        }

        return $e::create($data);
    }

    /**
     * Atualiza um registro pelo uuid.
     * @param array<string, mixed> $data
     */
    public function update(string $uuid, array $data): mixed
    {
        $e                    = $this->entity();
        $data['updated_at']   = date('Y-m-d H:i:s');
        return $e::update($data)->whereEquals('uuid', $uuid)->finish();
    }

    /**
     * Exclui (soft delete) um registro pelo uuid.
     */
    public function delete(string $uuid): bool
    {
        $e = $this->entity();
        $e::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }
}
