<?php

namespace src\app\requests;

class StoreItemRequest extends Request
{
    protected array $rules = [
        'tipo'   => 'required',
        'codigo' => 'required|maxLen:40',
    ];
}
