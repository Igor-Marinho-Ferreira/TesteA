<?php

namespace src\app\requests;

class StoreLiderRequest extends Request
{
    protected array $rules = [
        'matricula' => 'required|maxLen:40',
        'nome'      => 'required|maxLen:160',
    ];
}
