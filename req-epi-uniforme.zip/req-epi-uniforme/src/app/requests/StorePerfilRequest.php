<?php

namespace src\app\requests;

class StorePerfilRequest extends Request
{
    protected array $rules = [
        'nome' => 'required|maxLen:120',
    ];
}
