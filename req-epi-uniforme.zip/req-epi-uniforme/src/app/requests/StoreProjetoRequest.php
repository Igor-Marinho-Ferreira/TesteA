<?php

namespace src\app\requests;

class StoreProjetoRequest extends Request
{
    protected array $rules = [
        'projeto' => 'required|maxLen:160',
    ];
}
