<?php $this->layout('templates/base', [
    'webTitle'  => 'Projetos',
    'cardTitle' => 'Cadastro de Projeto',
    'backTo'    => route('menu'),
]) ?>

<?= $this->insert('partials/cadastro_simples', [
    'mod'         => 'projeto',
    'campo'       => 'projeto',
    'label'       => 'Projeto',
    'singular'    => 'projeto',
    'icon'        => 'ph-folder-simple',
    'placeholder' => 'Nome do projeto',
    'itens'       => $itens,
    'editing'     => $editing ?? null,
]) ?>
