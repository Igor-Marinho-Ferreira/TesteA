<?php
/**
 * Partial genérico para cadastros simples de um único campo.
 *
 * Variáveis esperadas:
 *   $mod         string  prefixo das rotas (ex.: 'junta')
 *   $campo       string  nome da coluna/campo (ex.: 'junta')
 *   $label       string  rótulo do campo (ex.: 'Junta')
 *   $singular    string  nome singular para mensagens (ex.: 'junta')
 *   $icon        string  classe do ícone phosphor (ex.: 'ph-git-merge')
 *   $placeholder string  placeholder do input
 *   $itens       array   registros
 *   $editing     ?object registro em edição
 */
$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$podeEditar = \src\app\services\PermissaoService::podeEditar($mod);

$action      = $isEditing ? route("$mod.update") : route("$mod.store");
$title       = $isEditing ? "Editar " . ucfirst($singular) : "Novo(a) " . ucfirst($singular);
$submitLabel = $isEditing ? 'Salvar alterações' : 'Registrar';
$valor       = old($campo) ?? ($editing->$campo ?? '');
?>

<?php if ($podeEditar) { ?>
<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : $icon ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= htmlspecialchars($title) ?></div>
            <div class="at-form-head__subtitle">Preencha o campo abaixo e clique em <?= $submitLabel ?>.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>

        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-8">
                <label for="fld-<?= $mod ?>" class="form-label"><?= htmlspecialchars($label) ?> <span class="text-danger">*</span></label>
                <?php $maiusculo = $maiusculo ?? false; ?>
                <input type="text" name="<?= $campo ?>" id="fld-<?= $mod ?>"
                    class="form-control <?= $maiusculo ? 'text-uppercase' : '' ?> <?= applyWrong($campo) ?>"
                    value="<?= htmlspecialchars((string) $valor) ?>"
                    <?= $maiusculo ? 'style="text-transform:uppercase"' : '' ?>
                    autocomplete="off" placeholder="<?= htmlspecialchars($placeholder ?? '') ?>" required>
                <div class="invalid-feedback"><?= applyWrongText($campo) ?></div>
            </div>
        </div>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?>
                <a href="<?= route("$mod.index") ?>" class="btn btn-light">Cancelar</a>
            <?php } ?>
            <button type="submit" class="btn btn-success">
                <i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $submitLabel ?>
            </button>
        </div>
    </form>
</div>
<?php } ?>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0"><?= htmlspecialchars($label) ?> cadastrados</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..."
                data-filter-input="#tbl-<?= $mod ?>" data-filter-count="#count-<?= $mod ?>">
        </div>
        <span id="count-<?= $mod ?>" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-<?= $mod ?>" class="table table-hover at-table mb-0">
        <thead>
            <tr>
                <th><?= htmlspecialchars($label) ?></th>
                <th class="text-end">Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr>
                    <td colspan="2" class="text-center at-empty">
                        <i class="ph ph-tray" style="font-size:1.5rem;"></i><br>
                        Nenhum registro cadastrado ainda.
                    </td>
                </tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;">
                    <td colspan="2" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td>
                </tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->$campo) ?></td>
                        <td class="text-end at-actions">
                            <?php if ($podeEditar) { ?>
                            <a href="<?= route("$mod.edit", ['uuid' => $item->uuid]) ?>"
                                class="btn btn-sm btn-outline-primary" title="Editar">
                                <i class="ph ph-pencil-simple"></i>
                            </a>
                            <form action="<?= route("$mod.destroy") ?>" method="POST" class="d-inline js-confirm-delete"
                                data-confirm-text="Deseja realmente excluir '<?= htmlspecialchars((string) $item->$campo) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir">
                                    <i class="ph ph-trash"></i>
                                </button>
                            </form>
                            <?php } else { ?><span class="text-muted small">—</span><?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
