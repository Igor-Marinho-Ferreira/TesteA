<?php
use src\app\services\PermissaoService;

$this->layout('templates/base', [
    'webTitle'  => 'Perfis de Acesso',
    'cardTitle' => 'Perfis de Acesso',
    'backTo'    => route('menu'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('perfil.update') : route('perfil.store');
$permsSel  = $permsSel ?? [];
$modulos   = PermissaoService::modulos();
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-user-gear' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar perfil' : 'Novo perfil de acesso' ?></div>
            <div class="at-form-head__subtitle">Marque, por módulo, se o perfil <strong>Vê</strong> a tela e se pode <strong>Editar</strong> (marcar Editar já libera Ver). Usuários sem perfil vinculado enxergam tudo.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?><input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>"><?php } ?>
        <div class="row g-3 mb-3">
            <div class="col-12 col-md-4">
                <label class="form-label">Nome do perfil <span class="text-danger">*</span></label>
                <input type="text" name="nome" class="form-control <?= applyWrong('nome') ?>" value="<?= htmlspecialchars((string) (old('nome') ?? ($editing->nome ?? ''))) ?>" required placeholder="Ex.: Demo Sprint 1">
            </div>
            <div class="col-12 col-md-8">
                <label class="form-label">Descrição</label>
                <input type="text" name="descricao" class="form-control" value="<?= htmlspecialchars((string) (old('descricao') ?? ($editing->descricao ?? ''))) ?>">
            </div>
        </div>

        <?php foreach ($modulos as $grupo => $itens) { ?>
            <div class="mb-2">
                <div class="d-flex align-items-center justify-content-between">
                    <h6 class="at-form-title mb-2"><?= htmlspecialchars($grupo) ?></h6>
                    <div class="small text-muted">
                        <a href="#" class="text-decoration-none me-2" data-marcar-grupo="ver" data-grupo="<?= md5($grupo) ?>">marcar Ver</a>
                        <a href="#" class="text-decoration-none" data-marcar-grupo="editar" data-grupo="<?= md5($grupo) ?>">marcar Editar</a>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table at-table mb-3">
                        <thead><tr><th>Módulo</th><th class="text-center" style="width:110px">Ver</th><th class="text-center" style="width:110px">Editar</th></tr></thead>
                        <tbody>
                            <?php foreach ($itens as $chave => $meta) {
                                $ver = $permsSel[$chave]['ver'] ?? false;
                                $ed  = $permsSel[$chave]['editar'] ?? false;
                                ?>
                                <tr>
                                    <td class="fw-medium"><?= htmlspecialchars($meta['label']) ?></td>
                                    <td class="text-center">
                                        <input type="checkbox" class="form-check-input grp-<?= md5($grupo) ?> chk-ver" name="ver[<?= $chave ?>]" value="1" data-mod="<?= $chave ?>" <?= $ver ? 'checked' : '' ?>>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" class="form-check-input grp-<?= md5($grupo) ?> chk-editar" name="editar[<?= $chave ?>]" value="1" data-mod="<?= $chave ?>" <?= $ed ? 'checked' : '' ?>>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php } ?>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('perfil.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar perfil' ?></button>
        </div>
    </form>
</div>

<!-- Lista de perfis -->
<h6 class="at-form-title">Perfis cadastrados</h6>
<div class="table-responsive mb-4">
    <table class="table table-hover at-table mb-0">
        <thead><tr><th>Perfil</th><th>Descrição</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($perfis)) { ?>
                <tr><td colspan="3" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum perfil cadastrado ainda.</td></tr>
            <?php } else { ?>
                <?php foreach ($perfis as $p) { ?>
                    <tr>
                        <td class="fw-medium"><?= htmlspecialchars((string) $p->nome) ?></td>
                        <td><?= htmlspecialchars((string) ($p->descricao ?? '—')) ?></td>
                        <td class="text-end at-actions">
                            <a href="<?= route('perfil.edit', ['uuid' => $p->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('perfil.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Excluir o perfil '<?= htmlspecialchars((string) $p->nome) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $p->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Vínculo de usuários (matrícula → perfil) -->
<div class="at-form-panel">
    <div class="at-form-title at-accent--violet"><i class="ph ph-user-list"></i> Usuários por perfil (por matrícula)</div>
    <form action="<?= route('perfil.vincular') ?>" method="POST" class="row g-3 align-items-end mb-3">
        <div class="col-12 col-md-3">
            <label class="form-label">Matrícula <span class="text-danger">*</span></label>
            <input type="text" name="matricula" class="form-control" placeholder="Ex.: 459844" required>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label">Nome (opcional)</label>
            <input type="text" name="nome" class="form-control">
        </div>
        <div class="col-12 col-md-3">
            <label class="form-label">Perfil <span class="text-danger">*</span></label>
            <select name="perfil_id" class="form-select" required>
                <option value="">Selecione...</option>
                <?php foreach ($perfis as $p) { ?><option value="<?= $p->id ?>"><?= htmlspecialchars((string) $p->nome) ?></option><?php } ?>
            </select>
        </div>
        <div class="col-12 col-md-2">
            <button type="submit" class="btn btn-success w-100"><i class="ph ph-link"></i> Vincular</button>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-hover at-table mb-0">
            <thead><tr><th>Matrícula</th><th>Nome</th><th>Perfil</th><th class="text-end">Ações</th></tr></thead>
            <tbody>
                <?php if (empty($usuarios)) { ?>
                    <tr><td colspan="4" class="text-center at-empty">Nenhum usuário vinculado. Quem não tem vínculo enxerga tudo.</td></tr>
                <?php } else { ?>
                    <?php foreach ($usuarios as $u) { ?>
                        <tr>
                            <td class="fw-medium"><?= htmlspecialchars((string) $u->matricula) ?></td>
                            <td><?= htmlspecialchars((string) ($u->nome ?? '—')) ?></td>
                            <td><span class="badge-tipo badge-status--muted"><?= htmlspecialchars((string) $u->perfil_nome) ?></span></td>
                            <td class="text-end at-actions">
                                <form action="<?= route('perfil.desvincular') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Remover o vínculo da matrícula '<?= htmlspecialchars((string) $u->matricula) ?>'?">
                                    <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $u->uuid) ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Remover vínculo"><i class="ph ph-x"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<?= $this->insert('templates/confirm_modal') ?>

<script>
(function () {
    // Editar implica Ver
    document.querySelectorAll('.chk-editar').forEach(function (ed) {
        ed.addEventListener('change', function () {
            if (ed.checked) {
                var mod = ed.getAttribute('data-mod');
                var ver = document.querySelector('.chk-ver[data-mod="' + mod + '"]');
                if (ver) ver.checked = true;
            }
        });
    });
    // Desmarcar Ver desmarca Editar
    document.querySelectorAll('.chk-ver').forEach(function (ver) {
        ver.addEventListener('change', function () {
            if (!ver.checked) {
                var mod = ver.getAttribute('data-mod');
                var ed = document.querySelector('.chk-editar[data-mod="' + mod + '"]');
                if (ed) ed.checked = false;
            }
        });
    });
    // Marcar grupo inteiro
    document.querySelectorAll('[data-marcar-grupo]').forEach(function (a) {
        a.addEventListener('click', function (e) {
            e.preventDefault();
            var tipo = a.getAttribute('data-marcar-grupo');
            var grupo = a.getAttribute('data-grupo');
            document.querySelectorAll('.grp-' + grupo + '.chk-' + tipo).forEach(function (c) {
                c.checked = true;
                if (tipo === 'editar') {
                    var ver = document.querySelector('.chk-ver[data-mod="' + c.getAttribute('data-mod') + '"]');
                    if (ver) ver.checked = true;
                }
            });
        });
    });
})();
</script>
