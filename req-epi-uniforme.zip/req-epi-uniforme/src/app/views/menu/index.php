<?php
use src\app\services\PermissaoService;

$this->layout('templates/base', [
    'webTitle'  => 'Requisição de EPIs e Uniformes — Menu',
    'cardTitle' => 'Requisição de EPIs e Uniformes',
]) ?>

<style>
    .container { max-width: 860px; }
</style>

<div class="mb-4">
    <h5 class="fw-bold mb-1">
        Olá<?= !empty($usuario->nome) ? ', ' . htmlspecialchars(explode(' ', $usuario->nome)[0]) : '' ?>! 👋</h5>
    <p class="text-muted mb-0">O que você deseja fazer?</p>
</div>

<?php
$modulos = PermissaoService::modulos();
$algumVisivel = false;

foreach ($modulos as $grupo => $itens) {
    // Filtra só os módulos que o usuário pode ver
    $visiveis = array_filter($itens, fn($chave) => PermissaoService::podeVer($chave), ARRAY_FILTER_USE_KEY);
    if (empty($visiveis)) continue;
    $algumVisivel = true;
    ?>
    <p class="menu-section-title"><?= htmlspecialchars($grupo) ?></p>
    <div class="menu-list">
        <?php foreach ($visiveis as $chave => $meta) { ?>
            <a href="<?= route($meta['rota']) ?>" class="menu-card menu-card--<?= $meta['cor'] ?>">
                <span class="menu-card__icon is-<?= $meta['cor'] ?>"><i class="ph <?= $meta['icone'] ?>"></i></span>
                <span class="menu-card__body">
                    <span class="menu-card__title"><?= htmlspecialchars($meta['label']) ?></span>
                    <span class="menu-card__desc"><?= htmlspecialchars($meta['desc']) ?></span>
                </span>
                <span class="menu-card__arrow"><i class="ph ph-arrow-right"></i></span>
            </a>
        <?php } ?>
    </div>
<?php } ?>

<?php if (!$algumVisivel) { ?>
    <div class="at-empty text-center py-5">
        <i class="ph ph-lock" style="font-size:2rem;"></i><br>
        Seu perfil não tem nenhum módulo liberado. Fale com o administrador.
    </div>
<?php } ?>
