<?php
$this->layout('templates/base', [
    'webTitle'  => 'Líderes',
    'cardTitle' => 'Cadastro de Líderes',
    'backTo'    => route('menu'),
]);

$editing    = $editing ?? null;
$isEditing  = (bool) $editing;
$action     = $isEditing ? route('lider.update') : route('lider.store');
$podeEditar = \src\app\services\PermissaoService::podeEditar('lider');
?>

<?php if ($podeEditar) { ?>
<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-user-gear' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar líder' : 'Novo líder' ?></div>
            <div class="at-form-head__subtitle">Informe a matrícula para buscar o nome automaticamente no Sênior.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST" data-lider-url="<?= route('lider.buscar_matricula') ?>" data-lider-nome-url="<?= route('lider.buscar_nome') ?>">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-3">
                <label class="form-label">Matrícula <span class="text-danger">*</span></label>
                <input type="text" name="matricula" id="lider-matricula" class="form-control <?= applyWrong('matricula') ?>"
                    value="<?= htmlspecialchars((string) (old('matricula') ?? ($editing->matricula ?? ''))) ?>"
                    autocomplete="off" placeholder="Ex.: 123456" required>
                <div class="invalid-feedback"><?= applyWrongText('matricula') ?></div>
            </div>
            <div class="col-12 col-md-7">
                <label class="form-label">Nome</label>
                <input type="text" name="nome" id="lider-nome" class="form-control <?= applyWrong('nome') ?>"
                    value="<?= htmlspecialchars((string) (old('nome') ?? ($editing->nome ?? ''))) ?>"
                    autocomplete="off" placeholder="Preenchido automaticamente" required>
                <div class="invalid-feedback"><?= applyWrongText('nome') ?></div>
            </div>
        </div>

        <div class="mt-2">
            <button type="button" class="btn btn-link btn-sm p-0" id="lider-toggle-busca-nome">Não sabe a matrícula? Buscar por nome</button>
            <div id="lider-busca-nome-box" class="row g-2 align-items-end mt-2" style="display:none;">
                <div class="col-12 col-md-7">
                    <input type="text" id="lider-busca-nome" class="form-control form-control-sm" placeholder="Digite parte do nome" autocomplete="off">
                </div>
                <div class="col-12 col-md-5">
                    <select id="lider-busca-nome-resultado" class="form-select form-select-sm">
                        <option value="">Resultados aparecerão aqui...</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('lider.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>
<?php } ?>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Líderes cadastrados</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..." data-filter-input="#tbl-lider" data-filter-count="#count-lider">
        </div>
        <span id="count-lider" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-lider" class="table table-hover at-table mb-0">
        <thead><tr><th>Matrícula</th><th>Nome</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="3" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum líder cadastrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="3" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->matricula) ?></td>
                        <td><?= htmlspecialchars((string) $item->nome) ?></td>
                        <td class="text-end at-actions">
                            <?php if ($podeEditar) { ?>
                            <a href="<?= route('lider.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('lider.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Deseja realmente excluir o líder '<?= htmlspecialchars((string) $item->nome) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                            <?php } else { ?><span class="text-muted small">—</span><?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>

<script>
(function () {
    var form = document.querySelector('form[data-lider-url]');
    if (!form) return;
    var url = form.getAttribute('data-lider-url');
    var matricula = document.getElementById('lider-matricula');
    var nome = document.getElementById('lider-nome');

    function buscar() {
        var m = (matricula.value || '').trim();
        if (!m) return;
        fetch(url + '?matricula=' + encodeURIComponent(m))
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (d) {
                if (d && d.nome) nome.value = d.nome;
            });
    }

    matricula.addEventListener('blur', buscar);
    matricula.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); buscar(); }
    });

    // Busca por nome (quando a matrícula não é conhecida)
    var nomeUrl = form.getAttribute('data-lider-nome-url');
    var toggle = document.getElementById('lider-toggle-busca-nome');
    var box = document.getElementById('lider-busca-nome-box');
    var buscaNome = document.getElementById('lider-busca-nome');
    var resultado = document.getElementById('lider-busca-nome-resultado');

    toggle.addEventListener('click', function () {
        box.style.display = box.style.display === 'none' ? 'flex' : 'none';
    });

    var timer = null;
    buscaNome.addEventListener('input', function () {
        clearTimeout(timer);
        var termo = buscaNome.value.trim();
        if (termo.length < 3) { resultado.innerHTML = '<option value="">Digite ao menos 3 letras...</option>'; return; }
        timer = setTimeout(function () {
            fetch(nomeUrl + '?nome=' + encodeURIComponent(termo))
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    var itens = d.itens || [];
                    resultado.innerHTML = itens.length
                        ? itens.map(function (i) { return '<option value="' + i.matricula + '">' + i.nome + '</option>'; }).join('')
                        : '<option value="">Nenhum resultado</option>';
                });
        }, 350);
    });

    resultado.addEventListener('change', function () {
        if (!resultado.value) return;
        matricula.value = resultado.value;
        nome.value = resultado.options[resultado.selectedIndex].text;
    });
})();
</script>
