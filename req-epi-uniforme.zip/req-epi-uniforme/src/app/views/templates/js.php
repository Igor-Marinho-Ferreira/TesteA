<?php if (isset($js)) { ?>
    <?php foreach ($js as $index => $js_) { ?>
        <?php $isModule = ''; ?>
        <?php if (str_contains($js_, '.module.')) {
            $isModule = 'type="module"';
        } ?>
        <script <?= $isModule ?> src="<?= $js_ . '?t=' . time() ?>"></script>
    <?php } ?>
<?php } ?>