<div class="modal fade sol-confirm" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-body text-center">
                <div class="sol-confirm-icon"><i class="ph ph-trash"></i></div>
                <h5 class="sol-confirm-title" id="confirmDeleteLabel">Excluir registro</h5>
                <p class="sol-confirm-text">
                    <span id="confirmDeleteText">Deseja realmente excluir este registro?</span><br>
                    Esta ação não poderá ser desfeita.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn sol-btn-cancel" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn sol-btn-delete" id="confirmDeleteBtn">Excluir</button>
            </div>
        </div>
    </div>
</div>
