<?php
$this->layout('templates/base', [
    'webTitle'  => 'EPIs e Uniformes',
    'cardTitle' => 'Cadastro de EPI\'s e Uniformes',
    'backTo'    => route('menu'),
]);

$editing    = $editing ?? null;
$isEditing  = (bool) $editing;
$action     = $isEditing ? route('item.update') : route('item.store');
$podeEditar = \src\app\services\PermissaoService::podeEditar('item');
$tipoAtual  = old('tipo') ?? ($editing->tipo ?? '');
?>

<?php if ($podeEditar) { ?>
<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-t-shirt' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar item' : 'Novo item' ?></div>
            <div class="at-form-head__subtitle">O código é validado no Logix; a descrição é preenchida automaticamente e não pode ser editada.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST" enctype="multipart/form-data" data-item-url="<?= route('item.buscar_logix') ?>">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-3">
                <label class="form-label">Tipo de Item <span class="text-danger">*</span></label>
                <select name="tipo" class="form-select <?= applyWrong('tipo') ?>" required>
                    <option value="">Selecione...</option>
                    <option value="uniforme" <?= $tipoAtual === 'uniforme' ? 'selected' : '' ?>>Uniformes</option>
                    <option value="epi" <?= $tipoAtual === 'epi' ? 'selected' : '' ?>>EPIs</option>
                </select>
                <div class="invalid-feedback"><?= applyWrongText('tipo') ?></div>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Código do Item <span class="text-danger">*</span></label>
                <input type="text" name="codigo" id="item-codigo" class="form-control <?= applyWrong('codigo') ?>"
                    value="<?= htmlspecialchars((string) (old('codigo') ?? ($editing->codigo ?? ''))) ?>"
                    autocomplete="off" placeholder="Código no Logix" required>
                <div class="invalid-feedback"><?= applyWrongText('codigo') ?></div>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Descrição do Item</label>
                <input type="text" id="item-descricao" class="form-control" value="<?= htmlspecialchars((string) ($editing->descricao ?? '')) ?>" placeholder="Preenchida automaticamente" readonly>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label">Imagem</label>
                <input type="file" name="imagem" class="form-control" accept=".png,.jpg,.jpeg,.webp">
            </div>
        </div>
        <?php if ($isEditing && !empty($editing->imagem)) { ?>
            <div class="mt-2"><small class="text-muted">Imagem atual: <a href="<?= route('arquivo', [], ['f' => $editing->imagem]) ?>" target="_blank">ver</a></small></div>
        <?php } ?>
        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('item.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>
<?php } ?>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Itens cadastrados</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..." data-filter-input="#tbl-item" data-filter-count="#count-item">
        </div>
        <span id="count-item" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-item" class="table table-hover at-table mb-0">
        <thead><tr><th>Imagem</th><th>Tipo</th><th>Código</th><th>Descrição</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="5" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum item cadastrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="5" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td>
                            <?php if (!empty($item->imagem)) { ?>
                                <img src="<?= route('arquivo', [], ['f' => $item->imagem]) ?>" alt="" style="width:36px;height:36px;object-fit:cover;border-radius:6px;">
                            <?php } else { ?><span class="at-file-empty">—</span><?php } ?>
                        </td>
                        <td><span class="badge rounded-pill text-bg-light border"><?= $item->tipo === 'epi' ? 'EPI' : 'Uniforme' ?></span></td>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->codigo) ?></td>
                        <td><?= htmlspecialchars((string) $item->descricao) ?></td>
                        <td class="text-end at-actions">
                            <?php if ($podeEditar) { ?>
                            <a href="<?= route('item.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('item.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Deseja realmente excluir o item '<?= htmlspecialchars((string) $item->descricao) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                            <?php } else { ?><span class="text-muted small">—</span><?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>

<script>
(function () {
    var form = document.querySelector('form[data-item-url]');
    if (!form) return;
    var url = form.getAttribute('data-item-url');
    var codigo = document.getElementById('item-codigo');
    var descricao = document.getElementById('item-descricao');

    function buscar() {
        var c = (codigo.value || '').trim();
        if (!c) return;
        fetch(url + '?codigo=' + encodeURIComponent(c))
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (d) {
                descricao.value = (d && d.descricao) ? d.descricao : '';
            });
    }

    codigo.addEventListener('blur', buscar);
    codigo.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); buscar(); }
    });
})();
</script>
