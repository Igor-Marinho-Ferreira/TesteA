<?php

namespace src\app\middlewares;


/**
 * Restringe o acesso à tela de Configurações às matrículas autorizadas
 * (ver CONFIG_ADMIN_MATRICULAS em helpers/sessions.php).
 */
class IsConfigAdminMiddleware
{
    function execute(): void
    {
        if (!can_access_configs()) {
            show_notification('Acesso restrito às Configurações.', 'error');
            header('Location: ' . route('menu'));
            exit;
        }
    }
}
