<?php

namespace src\app\middlewares;


class IsLoggedMiddleware
{
    function execute(): void
    {
        $has_session = user();
        if (!$has_session) {
            $login_url = path()->get_host() . "/" . path()->get_company();
            header("Location: {$login_url}");
            exit;
        }
    }
}
