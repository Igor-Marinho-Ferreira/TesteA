<?php

namespace src\app\controllers;

use src\app\requests\StoreItemRequest;
use src\app\services\ItemService;
use src\support\Json;

class ItemController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new ItemService)->listAll();
        $editing = null;
        return view('item.index', compact('itens', 'editing'));
    }

    function store(StoreItemRequest $request): mixed
    {
        $request->execute();
        $service = new ItemService;

        if ($erro = $service->imagemError()) {
            return redirect()->back()->withError($erro);
        }

        $codigo = trim((string) $request->input('codigo'));
        if ($service->existeDuplicado($codigo)) {
            return redirect()->back()->withError('Já existe um item cadastrado com esse código.');
        }

        $noLogix = $service->buscarNoLogix($codigo);
        if (!$noLogix) {
            return redirect()->back()->withError('Código não encontrado no Logix.');
        }

        $service->store([
            'tipo'      => (string) $request->input('tipo'),
            'codigo'    => $codigo,
            'descricao' => $noLogix['descricao'],
        ]);
        notification()->success('Item cadastrado com sucesso!');
        return redirect()->route('item.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new ItemService)->find($uuid);
        if (!$editing) {
            return redirect()->route('item.index')->withError('Item não encontrado.');
        }
        $itens = (new ItemService)->listAll();
        return view('item.index', compact('itens', 'editing'));
    }

    function update(StoreItemRequest $request): mixed
    {
        $request->execute();
        $service = new ItemService;

        $uuid = (string) $request->input('uuid');
        $item = $service->find($uuid);
        if (!$item) {
            return redirect()->route('item.index')->withError('Item não encontrado.');
        }
        if ($erro = $service->imagemError()) {
            return redirect()->back()->withError($erro);
        }

        $codigo = trim((string) $request->input('codigo'));
        if ($service->existeDuplicado($codigo, $uuid)) {
            return redirect()->back()->withError('Já existe um item cadastrado com esse código.');
        }

        $descricao = $item->descricao;
        if ($codigo !== $item->codigo) {
            $noLogix = $service->buscarNoLogix($codigo);
            if (!$noLogix) {
                return redirect()->back()->withError('Código não encontrado no Logix.');
            }
            $descricao = $noLogix['descricao'];
        }

        $service->update($uuid, [
            'tipo'      => (string) $request->input('tipo'),
            'codigo'    => $codigo,
            'descricao' => $descricao,
        ]);
        notification()->success('Item atualizado com sucesso!');
        return redirect()->route('item.index');
    }

    function destroy(): mixed
    {
        $service = new ItemService;
        $uuid    = (string) request()->get('uuid');

        if (!$service->find($uuid)) {
            return redirect()->route('item.index')->withError('Item não encontrado.');
        }

        $service->delete($uuid);
        notification()->success('Item excluído com sucesso!');
        return redirect()->route('item.index');
    }

    /** AJAX: busca a descrição do item no Logix pelo código. */
    function buscarNoLogix(): mixed
    {
        $codigo = (string) (request()->get('codigo') ?? '');
        $dados  = (new ItemService)->buscarNoLogix($codigo);
        return Json::return($dados ?: ['erro' => 'Código não encontrado no Logix'], $dados ? 200 : 404);
    }
}
