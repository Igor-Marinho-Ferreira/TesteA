<?php

namespace src\app\controllers;

use src\app\requests\StoreLiderRequest;
use src\app\services\LiderService;
use src\support\Json;

class LiderController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new LiderService)->listAll();
        $editing = null;
        return view('lider.index', compact('itens', 'editing'));
    }

    function store(StoreLiderRequest $request): mixed
    {
        $request->execute();
        $service = new LiderService;

        $matricula = trim((string) $request->input('matricula'));
        if ($service->existeDuplicado($matricula)) {
            return redirect()->back()->withError('Já existe um líder cadastrado com essa matrícula.');
        }

        $service->store(['matricula' => $matricula, 'nome' => (string) $request->input('nome')]);
        notification()->success('Líder cadastrado com sucesso!');
        return redirect()->route('lider.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new LiderService)->find($uuid);
        if (!$editing) {
            return redirect()->route('lider.index')->withError('Líder não encontrado.');
        }
        $itens = (new LiderService)->listAll();
        return view('lider.index', compact('itens', 'editing'));
    }

    function update(StoreLiderRequest $request): mixed
    {
        $request->execute();
        $service = new LiderService;

        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('lider.index')->withError('Líder não encontrado.');
        }

        $matricula = trim((string) $request->input('matricula'));
        if ($service->existeDuplicado($matricula, $uuid)) {
            return redirect()->back()->withError('Já existe um líder cadastrado com essa matrícula.');
        }

        $service->update($uuid, ['matricula' => $matricula, 'nome' => (string) $request->input('nome')]);
        notification()->success('Líder atualizado com sucesso!');
        return redirect()->route('lider.index');
    }

    function destroy(): mixed
    {
        $service = new LiderService;
        $uuid    = (string) request()->get('uuid');

        if (!$service->find($uuid)) {
            return redirect()->route('lider.index')->withError('Líder não encontrado.');
        }

        $service->delete($uuid);
        notification()->success('Líder excluído com sucesso!');
        return redirect()->route('lider.index');
    }

    /** AJAX: dados do sênior pela matrícula, para preencher o formulário de cadastro. */
    function buscarPorMatricula(): mixed
    {
        $matricula = (string) (request()->get('matricula') ?? '');
        $dados = (new LiderService)->buscarPorMatricula($matricula);
        return Json::return($dados ?: ['erro' => 'Matrícula não encontrada'], $dados ? 200 : 404);
    }

    /** AJAX: busca por nome, quando a matrícula não é conhecida. */
    function buscarPorNome(): mixed
    {
        $nome = (string) (request()->get('nome') ?? '');
        $dados = (new LiderService)->buscarPorNome($nome);
        return Json::return(['itens' => $dados], 200);
    }
}
