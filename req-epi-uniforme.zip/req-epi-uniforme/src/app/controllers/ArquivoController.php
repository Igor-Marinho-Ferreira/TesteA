<?php

namespace src\app\controllers;

/**
 * Serve arquivos gravados no storage externo ({projeto}-storage), que fica
 * fora da pasta do projeto e portanto não é acessível diretamente pelo Apache.
 */
class ArquivoController
{
    function __construct()
    {
    }

    function download(): mixed
    {
        $rel = (string) (request()->get('f') ?? '');

        // Segurança: sem travessia de diretório, só caminhos relativos simples.
        $rel = str_replace('\\', '/', $rel);
        if ($rel === '' || str_contains($rel, '..') || str_starts_with($rel, '/')) {
            http_response_code(400);
            die('Arquivo inválido.');
        }

        $base = rtrim(path()->storage_server(''), '/');
        $abs  = $base . '/' . $rel;

        if (!is_file($abs)) {
            http_response_code(404);
            die('Arquivo não encontrado.');
        }

        $mime = $this->mime($abs);
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($abs));
        header('Content-Disposition: inline; filename="' . basename($abs) . '"');
        header('X-Content-Type-Options: nosniff');
        readfile($abs);
        die;
    }

    private function mime(string $path): string
    {
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        return [
            'png'  => 'image/png',
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'gif'  => 'image/gif',
            'webp' => 'image/webp',
            'pdf'  => 'application/pdf',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'csv'  => 'text/csv',
        ][$ext] ?? 'application/octet-stream';
    }
}
