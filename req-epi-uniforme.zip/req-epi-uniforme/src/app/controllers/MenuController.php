<?php

namespace src\app\controllers;

class MenuController
{
    /**
     * Tela de menu principal da Requisição de EPIs e Uniformes.
     */
    function index(): mixed
    {
        return view('menu.index', ['usuario' => user()]);
    }
}
