<?php

namespace src\app\controllers;

class ManualController
{
    function __construct()
    {
    }

    /** Manual do sistema (como o processo e cada tela funcionam). */
    function index(): mixed
    {
        return view('manual.index');
    }
}
