<?php

namespace src\app\controllers;

use src\app\services\LiderService;
use src\app\services\ProjetoService;
use src\app\services\RequisicaoService;
use src\support\Json;

class RequisicaoController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $lideres  = (new LiderService)->listAll();
        $projetos = (new ProjetoService)->listAll();
        return view('requisicao.index', compact('lideres', 'projetos'));
    }

    /** AJAX: identifica o colaborador a partir do número lido do crachá. */
    function identificar(): mixed
    {
        $cracha = (string) (request()->get('cracha') ?? '');
        $dados  = (new RequisicaoService)->identificarPorCracha($cracha);
        return Json::return($dados, 200);
    }

    /** AJAX: registra o nome/matrícula de uso de um crachá provisório no dia. */
    function registrarCrachaProvisorio(): mixed
    {
        $cracha    = (string) (request()->get('cracha') ?? '');
        $matricula = (string) (request()->get('matricula') ?? '');
        $nome      = (string) (request()->get('nome') ?? '');

        if ($cracha === '' || $matricula === '' || $nome === '') {
            return Json::return(['erro' => 'Informe matrícula e nome.'], 422);
        }

        $dados = (new RequisicaoService)->registrarUsoCrachaProvisorio($cracha, $matricula, $nome);
        return Json::return($dados, 200);
    }

    /** AJAX: lista os itens (EPI ou Uniforme) disponíveis para requisição. */
    function itens(): mixed
    {
        $tipo = (string) (request()->get('tipo') ?? '');
        if (!in_array($tipo, ['epi', 'uniforme'], true)) {
            return Json::return(['erro' => 'Tipo inválido.'], 422);
        }

        $service = new RequisicaoService;
        $itens = array_map(fn($i) => [
            'id'        => (int) $i->id,
            'codigo'    => $i->codigo,
            'descricao' => $i->descricao,
            'imagem'    => $i->imagem ? route('arquivo', [], ['f' => $i->imagem]) : null,
        ], $service->itensPorTipo($tipo));

        return Json::return(['itens' => $itens], 200);
    }

    /** Confirma a requisição: grava o cabeçalho e os itens selecionados. */
    function store(): mixed
    {
        $matricula = trim((string) request()->get('matricula'));
        $nome      = trim((string) request()->get('nome'));
        $itensPost = (array) (request()->get('itens') ?? []);

        if ($matricula === '' || $nome === '' || empty($itensPost)) {
            return redirect()->route('requisicao.index')->withError('Selecione ao menos um item antes de confirmar.');
        }

        $service = new RequisicaoService;

        $centroCusto      = request()->get('centro_custo') ?: null;
        $unidadeFuncional = request()->get('unidade_funcional') ?: null;
        $cargo            = request()->get('cargo') ?: null;

        $regra = null;
        if ($unidadeFuncional && $cargo) {
            $r = $service->regraCargoEpi($matricula, (string) $unidadeFuncional, (string) $cargo);
            $regra = $r['regra'] ?? null;
        }

        $itens = [];
        foreach ($itensPost as $i) {
            $itens[] = [
                'item_id'        => isset($i['id']) ? (int) $i['id'] : null,
                'item_tipo'      => (string) ($i['tipo'] ?? ''),
                'item_codigo'    => (string) ($i['codigo'] ?? ''),
                'item_descricao' => (string) ($i['descricao'] ?? ''),
                'quantidade'     => max(1, (int) ($i['quantidade'] ?? 1)),
            ];
        }

        $requisicao = $service->registrar([
            'matricula'         => $matricula,
            'nome'              => $nome,
            'centro_custo'      => $centroCusto,
            'unidade_funcional' => $unidadeFuncional,
            'cargo'             => $cargo,
            'lider_matricula'   => request()->get('lider_matricula') ?: null,
            'projeto'           => request()->get('projeto') ?: null,
            'cracha_numero'     => request()->get('cracha') ?: null,
            'cracha_provisorio' => (bool) request()->get('cracha_provisorio'),
            'regra_utilizada'   => $regra,
        ], $itens);

        notification()->success('Requisição nº ' . $requisicao->numero . ' registrada com sucesso!');
        return redirect()->route('requisicao.index');
    }
}
