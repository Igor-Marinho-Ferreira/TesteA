<?php

namespace src\app\controllers;

use Shuchkin\SimpleXLSXGen;
use src\app\services\RelatorioRequisicaoService;

class RelatorioController
{
    function __construct()
    {
    }

    private function filtros(): array
    {
        return [
            'data_inicial' => (string) (fromGet('data_inicial') ?? ''),
            'data_final'   => (string) (fromGet('data_final') ?? ''),
            'matricula'    => (string) (fromGet('matricula') ?? ''),
        ];
    }

    function index(): mixed
    {
        $filtros = $this->filtros();
        $itens = (empty($filtros['data_inicial']) && empty($filtros['data_final']) && empty($filtros['matricula']))
            ? []
            : (new RelatorioRequisicaoService)->listar($filtros);
        return view('relatorio.index', compact('itens', 'filtros'));
    }

    function excel(): mixed
    {
        $filtros = $this->filtros();
        $itens = (new RelatorioRequisicaoService)->listar($filtros);

        $linhas = [[
            'Matrícula', 'Nome', 'Centro de Custo', 'Unidade Funcional', 'Cargo',
            'Nº Requisição', 'Data', 'Hora', 'Crachá Provisório', 'Regra Utilizada',
            'Tipo', 'Código do Item', 'Descrição do Item', 'Qtd. Solicitada', 'Qtd. Atendida', 'Status',
        ]];
        foreach ($itens as $i) {
            $linhas[] = [
                (string) $i->matricula,
                (string) $i->nome_colaborador,
                (string) ($i->centro_custo ?? ''),
                (string) ($i->unidade_funcional ?? ''),
                (string) ($i->cargo ?? ''),
                (string) $i->numero_requisicao,
                (string) $i->data_solicitacao,
                (string) $i->hora_solicitacao,
                $i->cracha_provisorio ? 'Sim' : 'Não',
                (string) ($i->regra_utilizada ?? ''),
                $i->item_tipo === 'epi' ? 'EPI' : 'Uniforme',
                (string) $i->item_codigo,
                (string) $i->item_descricao,
                (string) $i->quantidade_solicitada,
                (string) ($i->quantidade_atendida ?? ''),
                (string) $i->status,
            ];
        }

        $xlsx = SimpleXLSXGen::fromArray($linhas);
        $xlsx->downloadAs('relatorio_requisicao_epis_uniformes.xlsx');
        die;
    }
}
