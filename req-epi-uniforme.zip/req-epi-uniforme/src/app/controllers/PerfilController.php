<?php

namespace src\app\controllers;

use src\app\requests\StorePerfilRequest;
use src\app\services\PerfilService;

class PerfilController
{
    function __construct()
    {
    }

    private function dados(?object $editing): array
    {
        $service = new PerfilService;
        return [
            'service'   => $service,
            'perfis'    => $service->listAll(),
            'usuarios'  => $service->usuarios(),
            'editing'   => $editing,
            'permsSel'  => $editing ? $service->permissoesDo((int) $editing->id) : [],
        ];
    }

    function index(): mixed
    {
        return view('perfil.index', $this->dados(null));
    }

    function store(StorePerfilRequest $request): mixed
    {
        $request->execute();
        $service = new PerfilService;
        if ($service->existeNome(trim((string) $request->input('nome')))) {
            return redirect()->back()->withError('Já existe um perfil com esse nome.');
        }
        $service->store($request->get());
        notification()->success('Perfil cadastrado com sucesso!');
        return redirect()->route('perfil.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new PerfilService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('perfil.index')->withError('Perfil não encontrado.');
        }
        return view('perfil.index', $this->dados($editing));
    }

    function update(StorePerfilRequest $request): mixed
    {
        $request->execute();
        $service = new PerfilService;
        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('perfil.index')->withError('Perfil não encontrado.');
        }
        if ($service->existeNome(trim((string) $request->input('nome')), $uuid)) {
            return redirect()->back()->withError('Já existe um perfil com esse nome.');
        }
        $service->update($uuid, $request->get());
        notification()->success('Perfil atualizado com sucesso!');
        return redirect()->route('perfil.index');
    }

    function destroy(): mixed
    {
        $service = new PerfilService;
        $uuid    = (string) request()->get('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('perfil.index')->withError('Perfil não encontrado.');
        }
        if (!$service->delete($uuid)) {
            return redirect()->route('perfil.index')->withError('Perfil possui usuários vinculados: exclusão não permitida.');
        }
        notification()->success('Perfil excluído com sucesso!');
        return redirect()->route('perfil.index');
    }

    // ---- Usuários (matrícula → perfil) -----------------------------------
    function vincular(): mixed
    {
        $matricula = trim((string) request()->get('matricula'));
        $nome      = trim((string) request()->get('nome'));
        $perfilId  = (int) request()->get('perfil_id');

        if ($matricula === '' || !$perfilId) {
            return redirect()->route('perfil.index')->withError('Informe a matrícula e o perfil.');
        }
        (new PerfilService)->vincularUsuario($matricula, $nome, $perfilId);
        notification()->success('Usuário vinculado ao perfil.');
        return redirect()->route('perfil.index');
    }

    function desvincular(): mixed
    {
        $uuid = (string) request()->get('uuid');
        (new PerfilService)->desvincularUsuario($uuid);
        notification()->success('Vínculo removido.');
        return redirect()->route('perfil.index');
    }
}
