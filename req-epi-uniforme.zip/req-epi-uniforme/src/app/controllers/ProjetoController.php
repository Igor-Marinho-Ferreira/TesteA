<?php

namespace src\app\controllers;

use src\app\requests\StoreProjetoRequest;
use src\app\services\ProjetoService;

class ProjetoController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new ProjetoService)->listAll();
        $editing = null;
        return view('projeto.index', compact('itens', 'editing'));
    }

    function store(StoreProjetoRequest $request): mixed
    {
        $request->execute();
        $service = new ProjetoService;

        $valor = trim((string) $request->input('projeto'));
        if ($service->existeDuplicado($valor)) {
            return redirect()->back()->withError('Já existe um projeto com esse nome.');
        }

        $service->store(['projeto' => $valor]);
        notification()->success('Projeto cadastrado com sucesso!');
        return redirect()->route('projeto.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new ProjetoService)->find($uuid);
        if (!$editing) {
            return redirect()->route('projeto.index')->withError('Projeto não encontrado.');
        }
        $itens = (new ProjetoService)->listAll();
        return view('projeto.index', compact('itens', 'editing'));
    }

    function update(StoreProjetoRequest $request): mixed
    {
        $request->execute();
        $service = new ProjetoService;

        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('projeto.index')->withError('Projeto não encontrado.');
        }

        $valor = trim((string) $request->input('projeto'));
        if ($service->existeDuplicado($valor, $uuid)) {
            return redirect()->back()->withError('Já existe um projeto com esse nome.');
        }

        $service->update($uuid, ['projeto' => $valor]);
        notification()->success('Projeto atualizado com sucesso!');
        return redirect()->route('projeto.index');
    }

    function destroy(): mixed
    {
        $service = new ProjetoService;
        $uuid    = (string) request()->get('uuid');

        if (!$service->find($uuid)) {
            return redirect()->route('projeto.index')->withError('Projeto não encontrado.');
        }

        $service->delete($uuid);
        notification()->success('Projeto excluído com sucesso!');
        return redirect()->route('projeto.index');
    }
}
