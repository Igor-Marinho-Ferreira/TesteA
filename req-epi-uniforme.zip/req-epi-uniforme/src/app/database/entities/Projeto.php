<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Projeto extends Querio
{
    protected static string $table  = 'bd_amsted.epi_projeto';
    protected static string $dbType = 'intranet';
}
