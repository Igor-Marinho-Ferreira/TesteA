<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Perfil extends Querio
{
    protected static string $table  = 'bd_amsted.epi_perfil';
    protected static string $dbType = 'intranet';
}
