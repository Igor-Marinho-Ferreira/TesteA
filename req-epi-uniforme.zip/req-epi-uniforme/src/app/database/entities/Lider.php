<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Lider extends Querio
{
    protected static string $table  = 'bd_amsted.epi_lider';
    protected static string $dbType = 'intranet';
}
