<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Requisicao extends Querio
{
    protected static string $table  = 'bd_amsted.epi_requisicao';
    protected static string $dbType = 'intranet';
}
