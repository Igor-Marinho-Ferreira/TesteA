<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PerfilPermissao extends Querio
{
    protected static string $table  = 'bd_amsted.epi_perfil_permissao';
    protected static string $dbType = 'intranet';
}
