<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class RequisicaoItem extends Querio
{
    protected static string $table  = 'bd_amsted.epi_requisicao_item';
    protected static string $dbType = 'intranet';
}
