<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class CrachaProvisorio extends Querio
{
    protected static string $table  = 'bd_amsted.epi_cracha_provisorio';
    protected static string $dbType = 'intranet';
}
