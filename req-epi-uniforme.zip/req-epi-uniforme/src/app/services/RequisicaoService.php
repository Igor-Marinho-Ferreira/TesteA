<?php

namespace src\app\services;

use src\app\database\Database;
use src\app\database\entities\CrachaProvisorio;
use src\app\database\entities\Item;
use src\app\database\entities\Requisicao;
use src\app\database\entities\RequisicaoItem;

/**
 * Requisição de EPI's e Uniformes pelos Operadores (2.1.1.4).
 *
 * Fluxo: leitura do crachá → identificação do colaborador (Foracesso +
 * Logix/Sênior) → escolha EPI/Uniforme → seleção dos itens → confirmação.
 */
class RequisicaoService
{
    // ===================== Identificação do colaborador ===================

    /**
     * Identifica o colaborador a partir do número lido do crachá.
     *
     * Primeiro verifica se o número está na lista de crachás provisórios
     * (sincronizada do Foracesso). Se estiver e ainda não tiver nome de uso
     * registrado hoje, devolve 'situacao' => 'provisorio_pendente' para a
     * tela pedir matrícula/nome de quem está usando o crachá naquele dia.
     * Caso contrário, consulta o Foracesso (crachá → matrícula) e o
     * Logix/Sênior (dados completos do colaborador).
     *
     * @return array{situacao:string, matricula:string, nome:string, centro_custo:?string, unidade_funcional:?string, cargo:?string, cracha_provisorio:bool}
     */
    public function identificarPorCracha(string $cracha): array
    {
        $cracha = trim($cracha);
        if ($cracha === '') {
            return $this->naoEncontrado();
        }

        $provisorio = CrachaProvisorio::selectOne()->whereEquals('numero_cracha', $cracha)->finish();
        if ($provisorio) {
            $usadoHoje = $provisorio->data_uso === date('Y-m-d') && !empty($provisorio->matricula_uso);
            if (!$usadoHoje) {
                return [
                    'situacao'          => 'provisorio_pendente',
                    'matricula'         => '',
                    'nome'              => '',
                    'centro_custo'      => null,
                    'unidade_funcional' => null,
                    'cargo'             => null,
                    'cracha_provisorio' => true,
                ];
            }

            $dados = $this->buscarColaboradorNoLogix((string) $provisorio->matricula_uso) ?? [
                'matricula' => (string) $provisorio->matricula_uso,
                'nome'      => (string) $provisorio->nome_uso,
                'centro_custo' => null, 'unidade_funcional' => null, 'cargo' => null,
            ];
            $dados['situacao'] = 'identificado';
            $dados['cracha_provisorio'] = true;
            return $dados;
        }

        $matricula = $this->buscarMatriculaNoForacesso($cracha);
        if (!$matricula) return $this->naoEncontrado();

        $dados = $this->buscarColaboradorNoLogix($matricula);
        if (!$dados) return $this->naoEncontrado();

        $dados['situacao'] = 'identificado';
        $dados['cracha_provisorio'] = false;
        return $dados;
    }

    private function naoEncontrado(): array
    {
        return [
            'situacao' => 'nao_encontrado', 'matricula' => '', 'nome' => '',
            'centro_custo' => null, 'unidade_funcional' => null, 'cargo' => null,
            'cracha_provisorio' => false,
        ];
    }

    /**
     * Registra a matrícula/nome de quem está usando um crachá provisório
     * hoje, e devolve os dados completos do colaborador (Logix).
     *
     * @return array{situacao:string, matricula:string, nome:string, centro_custo:?string, unidade_funcional:?string, cargo:?string, cracha_provisorio:bool}
     */
    public function registrarUsoCrachaProvisorio(string $numeroCracha, string $matricula, string $nome): array
    {
        $existente = CrachaProvisorio::selectOne()->whereEquals('numero_cracha', $numeroCracha)->finish();
        $dados = [
            'status'        => 'em_uso',
            'matricula_uso' => trim($matricula),
            'nome_uso'      => trim($nome),
            'data_uso'      => date('Y-m-d'),
            'hora_uso'      => date('H:i:s'),
            'sincronizado'  => 0,
            'updated_at'    => date('Y-m-d H:i:s'),
        ];
        if ($existente) {
            CrachaProvisorio::update($dados)->whereEquals('uuid', $existente->uuid)->finish();
        } else {
            $dados['numero_cracha'] = $numeroCracha;
            CrachaProvisorio::create($dados);
        }

        $colaborador = $this->buscarColaboradorNoLogix(trim($matricula)) ?? [
            'matricula' => trim($matricula), 'nome' => trim($nome),
            'centro_custo' => null, 'unidade_funcional' => null, 'cargo' => null,
        ];
        $colaborador['situacao'] = 'identificado';
        $colaborador['cracha_provisorio'] = true;
        return $colaborador;
    }

    /**
     * Consulta o Foracesso para obter a matrícula a partir do número do crachá.
     *
     * TODO: substituir pela query real assim que ela for enviada.
     */
    private function buscarMatriculaNoForacesso(string $cracha): ?string
    {
        $db = Database::get('foracesso');
        // $stmt = $db->prepare("SELECT matricula FROM <tabela_foracesso> WHERE cracha = ?");
        // $stmt->execute([$cracha]);
        // $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        // return $row['matricula'] ?? null;
        return null;
    }

    /**
     * Consulta os dados do colaborador (nome, centro de custo, unidade
     * funcional, cargo) no Logix a partir da matrícula.
     *
     * TODO: substituir pela query real assim que ela for enviada.
     */
    private function buscarColaboradorNoLogix(string $matricula): ?array
    {
        $db = Database::get('informix');
        // $stmt = $db->prepare("SELECT ... FROM <tabela_logix> WHERE matricula = ?");
        // $stmt->execute([$matricula]);
        // $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        // if (!$row) return null;
        // return [
        //     'matricula'         => $row['matricula'],
        //     'nome'              => $row['nome'],
        //     'centro_custo'      => $row['centro_custo'],
        //     'unidade_funcional' => $row['unidade_funcional'],
        //     'cargo'             => $row['cargo'],
        // ];
        return null;
    }

    // ===================== Itens disponíveis ===============================

    /** @return array<int, object> */
    public function itensPorTipo(string $tipo): array
    {
        return Item::select()->whereEquals('tipo', $tipo)->andWhereIsNull('deleted_at')->order('descricao', 'ASC')->finish() ?: [];
    }

    // ===================== Regra de reserva de EPI (MX_CARGO_EPI) ==========

    /**
     * Consulta a tabela MX_CARGO_EPI para identificar os EPIs aplicáveis ao
     * colaborador. 1ª validação: matrícula + unidade funcional + cargo.
     * 2ª validação (fallback): unidade funcional + cargo.
     *
     * TODO: substituir pelas queries reais assim que elas forem enviadas.
     *
     * @return array{regra:string, codigos:array<int,string>}|null 'regra' é 'prioridade_1' ou 'prioridade_2'.
     */
    public function regraCargoEpi(string $matricula, string $unidadeFuncional, string $cargo): ?array
    {
        $db = Database::get('informix');

        // 1ª validação — matrícula + unidade funcional + cargo
        // $stmt = $db->prepare("SELECT codigo_epi FROM MX_CARGO_EPI WHERE matricula = ? AND unidade_funcional = ? AND cargo = ?");
        // $stmt->execute([$matricula, $unidadeFuncional, $cargo]);
        // $codigos = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        // if ($codigos) return ['regra' => 'prioridade_1', 'codigos' => $codigos];

        // 2ª validação — unidade funcional + cargo (configuração padrão)
        // $stmt = $db->prepare("SELECT codigo_epi FROM MX_CARGO_EPI WHERE unidade_funcional = ? AND cargo = ? AND matricula IS NULL");
        // $stmt->execute([$unidadeFuncional, $cargo]);
        // $codigos = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        // if ($codigos) return ['regra' => 'prioridade_2', 'codigos' => $codigos];

        return null;
    }

    // ===================== Registro da requisição ===========================

    private function proximoNumero(): string
    {
        $ultima = Requisicao::select()->order('id', 'DESC')->limit(1)->finish();
        $seq = 1;
        if ($ultima) {
            $seq = ((int) preg_replace('/\D/', '', (string) $ultima[0]->numero)) + 1;
        }
        return str_pad((string) $seq, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Registra a requisição (cabeçalho + itens).
     *
     * @param array{matricula:string, nome:string, centro_custo:?string, unidade_funcional:?string, cargo:?string, lider_matricula:?string, projeto:?string, cracha_numero:?string, cracha_provisorio:bool, regra_utilizada:?string} $colaborador
     * @param array<int, array{item_id:?int, item_tipo:string, item_codigo:string, item_descricao:string, quantidade:int}> $itens
     */
    public function registrar(array $colaborador, array $itens): object
    {
        $requisicao = Requisicao::create([
            'numero'             => $this->proximoNumero(),
            'matricula'          => $colaborador['matricula'],
            'nome_colaborador'   => $colaborador['nome'],
            'centro_custo'       => $colaborador['centro_custo'] ?? null,
            'unidade_funcional'  => $colaborador['unidade_funcional'] ?? null,
            'cargo'              => $colaborador['cargo'] ?? null,
            'lider_matricula'    => $colaborador['lider_matricula'] ?? null,
            'projeto'            => $colaborador['projeto'] ?? null,
            'cracha_numero'      => $colaborador['cracha_numero'] ?? null,
            'cracha_provisorio'  => !empty($colaborador['cracha_provisorio']) ? 1 : 0,
            'regra_utilizada'    => $colaborador['regra_utilizada'] ?? null,
            'data_solicitacao'   => date('Y-m-d'),
            'hora_solicitacao'   => date('H:i:s'),
        ]);

        $requisicaoId = is_object($requisicao) ? ($requisicao->id ?? null) : ($requisicao['id'] ?? null);

        foreach ($itens as $item) {
            RequisicaoItem::insert([
                'requisicao_id'         => $requisicaoId,
                'item_id'               => $item['item_id'] ?? null,
                'item_tipo'             => $item['item_tipo'],
                'item_codigo'           => $item['item_codigo'],
                'item_descricao'        => $item['item_descricao'],
                'quantidade_solicitada' => $item['quantidade'] ?? 1,
            ])->finish();
        }

        return (object) ['id' => $requisicaoId, 'numero' => $requisicao->numero ?? null];
    }
}
