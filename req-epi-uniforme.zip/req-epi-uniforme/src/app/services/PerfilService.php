<?php

namespace src\app\services;

use src\app\database\entities\Perfil;
use src\app\database\entities\PerfilPermissao;
use src\app\database\entities\UsuarioPerfil;

class PerfilService
{
    /** @return array<int, object> */
    public function listAll(): array
    {
        return Perfil::select()->whereIsNull('deleted_at')->order('nome', 'ASC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return Perfil::getByUuid($uuid);
    }

    public function existeNome(string $nome, ?string $ignoreUuid = null): bool
    {
        $achados = Perfil::select()->whereEquals('nome', $nome)->andWhereIsNull('deleted_at')->finish() ?: [];
        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) return true;
        }
        return false;
    }

    /**
     * @param array<string, mixed> $d  (nome, descricao, ver[modulo], editar[modulo])
     */
    public function store(array $d): void
    {
        $novo = Perfil::create([
            'nome'      => trim((string) ($d['nome'] ?? '')),
            'descricao' => trim((string) ($d['descricao'] ?? '')),
        ]);
        $id = is_object($novo) ? ($novo->id ?? null) : ($novo['id'] ?? null);
        if ($id) $this->salvarPermissoes((int) $id, $d);
    }

    public function update(string $uuid, array $d): void
    {
        Perfil::update([
            'nome'       => trim((string) ($d['nome'] ?? '')),
            'descricao'  => trim((string) ($d['descricao'] ?? '')),
            'updated_at' => date('Y-m-d H:i:s'),
        ])->whereEquals('uuid', $uuid)->finish();

        $perfil = $this->find($uuid);
        if ($perfil) {
            PerfilPermissao::delete()->where('perfil_id', '=', $perfil->id)->finish();
            $this->salvarPermissoes((int) $perfil->id, $d);
        }
    }

    private function salvarPermissoes(int $perfilId, array $d): void
    {
        $ver    = (array) ($d['ver'] ?? []);
        $editar = (array) ($d['editar'] ?? []);
        foreach (PermissaoService::chaves() as $modulo) {
            $podeVer    = !empty($ver[$modulo]) ? 1 : 0;
            $podeEditar = !empty($editar[$modulo]) ? 1 : 0;
            // Editar implica ver.
            if ($podeEditar) $podeVer = 1;
            PerfilPermissao::insert([
                'perfil_id'   => $perfilId,
                'modulo'      => $modulo,
                'pode_ver'    => $podeVer,
                'pode_editar' => $podeEditar,
            ])->finish();
        }
        PermissaoService::limparCache();
    }

    public function delete(string $uuid): bool
    {
        $perfil = $this->find($uuid);
        if (!$perfil) return false;
        // Não exclui se houver usuários vinculados.
        if ($this->temUsuarios((int) $perfil->id)) return false;
        Perfil::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    /** @return array<string, array{ver:bool, editar:bool}> */
    public function permissoesDo(int $perfilId): array
    {
        $rows = PerfilPermissao::select()->whereEquals('perfil_id', $perfilId)->finish() ?: [];
        $map = [];
        foreach ($rows as $r) {
            $map[$r->modulo] = ['ver' => (bool) $r->pode_ver, 'editar' => (bool) $r->pode_editar];
        }
        return $map;
    }

    // ===================== Usuários (matrícula → perfil) =================

    /** @return array<int, object> */
    public function usuarios(): array
    {
        $rows = UsuarioPerfil::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
        foreach ($rows as $r) {
            $p = Perfil::getById((int) $r->perfil_id);
            $r->perfil_nome = $p ? $p->nome : '—';
        }
        return $rows;
    }

    public function temUsuarios(int $perfilId): bool
    {
        $rows = UsuarioPerfil::select()->whereEquals('perfil_id', $perfilId)->andWhereIsNull('deleted_at')->finish() ?: [];
        return count($rows) > 0;
    }

    /**
     * Vincula (ou revincula) uma matrícula a um perfil.
     */
    public function vincularUsuario(string $matricula, string $nome, int $perfilId): void
    {
        $matricula = trim($matricula);
        $existente = UsuarioPerfil::selectOne()->whereEquals('matricula', $matricula)->andWhereIsNull('deleted_at')->finish();
        if ($existente) {
            UsuarioPerfil::update([
                'perfil_id'  => $perfilId,
                'nome'       => trim($nome),
                'updated_at' => date('Y-m-d H:i:s'),
            ])->whereEquals('uuid', $existente->uuid)->finish();
        } else {
            UsuarioPerfil::create([
                'matricula' => $matricula,
                'nome'      => trim($nome),
                'perfil_id' => $perfilId,
            ]);
        }
        PermissaoService::limparCache();
    }

    public function desvincularUsuario(string $uuid): void
    {
        UsuarioPerfil::softDelete()->whereEquals('uuid', $uuid)->finish();
        PermissaoService::limparCache();
    }
}
