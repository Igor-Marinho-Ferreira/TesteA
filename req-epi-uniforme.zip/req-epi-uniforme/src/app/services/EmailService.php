<?php

namespace src\app\services;

use src\support\Mailer;

/**
 * Disparo de e-mails do sistema.
 *
 * Enquanto o projeto está em desenvolvimento, TODOS os e-mails são enviados
 * para o endereço padrão abaixo (conforme solicitado). Para voltar ao
 * comportamento normal, basta ajustar/parametrizar DESTINO_PADRAO.
 *
 * O envio é tolerante a falhas: se o servidor de e-mail não estiver
 * disponível (ex.: ambiente local), o método apenas retorna false, sem
 * interromper o fluxo da aplicação.
 */
class EmailService
{
    /** Destinatário único enquanto em desenvolvimento. */
    public const DESTINO_PADRAO = 'igor.ferreira@gbmx.com.br';

    /**
     * Envia um e-mail com corpo já montado no template padrão.
     *
     * @param string               $assunto
     * @param string               $conteudoHtml  HTML do miolo (sem <html>/<body>)
     * @param string|array|null     $para          destinatário(s); null = padrão
     */
    public static function enviar(string $assunto, string $conteudoHtml, string|array|null $para = null): bool
    {
        $destino = $para ?? self::DESTINO_PADRAO;

        try {
            $mailer = new Mailer();
            $mailer->setAddressees($destino)
                ->setSubject($assunto)
                ->setBody(self::template($assunto, $conteudoHtml));
            return $mailer->fire();
        } catch (\Throwable $e) {
            // Sem servidor de e-mail (ex.: local) — não interrompe o fluxo.
            error_log('[EmailService] falha ao enviar: ' . $e->getMessage());
            return false;
        }
    }

    /** Envelope HTML padrão (identidade GBMX). */
    private static function template(string $titulo, string $conteudo): string
    {
        return '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"></head>'
            . '<body style="margin:0;background:#f1f5f9;font-family:Segoe UI,Arial,sans-serif;color:#1f2937;">'
            . '<div style="max-width:600px;margin:24px auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;">'
            . '<div style="background:#008E4B;color:#fff;padding:16px 24px;font-size:16px;font-weight:700;">'
            . 'Requisição de EPIs e Uniformes</div>'
            . '<div style="padding:24px;line-height:1.55;font-size:14px;">'
            . '<h2 style="color:#008E4B;font-size:18px;margin:0 0 12px;">' . htmlspecialchars($titulo) . '</h2>'
            . $conteudo
            . '</div>'
            . '<div style="padding:14px 24px;background:#f8fafc;color:#94a3b8;font-size:12px;border-top:1px solid #eef1f5;">'
            . 'Mensagem automática — não responder. GBMX (Greenbrier Maxion).</div>'
            . '</div></body></html>';
    }
}
