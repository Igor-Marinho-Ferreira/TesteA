<?php

namespace src\app\services;

use src\app\database\entities\Projeto;
use src\traits\CadastroSimples;

class ProjetoService
{
    use CadastroSimples;

    private function entity(): string { return Projeto::class; }
    private function campoUnico(): string { return 'projeto'; }
}
