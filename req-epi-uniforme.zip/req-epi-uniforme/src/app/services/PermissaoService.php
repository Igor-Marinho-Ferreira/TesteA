<?php

namespace src\app\services;

use src\app\database\entities\Perfil;
use src\app\database\entities\PerfilPermissao;
use src\app\database\entities\UsuarioPerfil;

/**
 * Controle de acesso por perfil.
 *
 * - Cada módulo tem uma chave (ex.: 'junta', 'plano', 'checklist').
 * - Um perfil define, por módulo, se o usuário VÊ e se pode EDITAR.
 * - Uma matrícula é vinculada a um perfil.
 *
 * Regra padrão: usuário SEM perfil vinculado vê tudo e edita tudo
 * (perfil de administrador/desenvolvedor). Assim, só quem tem um perfil
 * restrito (ex.: a matrícula da demo do sprint) fica limitado.
 */
class PermissaoService
{
    /** @var array<string, array{ver:bool, editar:bool}>|null Cache das permissões do usuário atual. */
    private static ?array $cache = null;
    private static bool $cacheCarregado = false;

    /**
     * Registro central dos módulos, agrupados como no menu.
     * grupo => [ chave => [label, rota, icone, cor, desc] ]
     *
     * @return array<string, array<string, array{label:string, rota:string, icone:string, cor:string, desc:string}>>
     */
    public static function modulos(): array
    {
        return [
            'Ajuda' => [
                'manual' => ['label' => 'Manual do Sistema', 'rota' => 'manual.index', 'icone' => 'ph-book-open', 'cor' => 'slate', 'desc' => 'Como o processo e cada tela funcionam.'],
            ],
            'Requisição de EPIs e Uniformes' => [
                'requisicao' => ['label' => 'Requisitar EPI / Uniforme', 'rota' => 'requisicao.index', 'icone' => 'ph-identification-card', 'cor' => 'green', 'desc' => 'Tela do operador — leitura de crachá e seleção dos itens.'],
                'relatorio'  => ['label' => 'Relatório de Requisições', 'rota' => 'relatorio.index', 'icone' => 'ph-chart-bar', 'cor' => 'blue', 'desc' => 'Histórico, filtros por período/matrícula e export Excel.'],
            ],
            'Parametrização' => [
                'item'    => ['label' => 'EPIs e Uniformes', 'rota' => 'item.index', 'icone' => 'ph-t-shirt', 'cor' => 'amber', 'desc' => 'Cadastro dos itens requisitáveis (validados no Logix).'],
                'lider'   => ['label' => 'Líderes', 'rota' => 'lider.index', 'icone' => 'ph-user-gear', 'cor' => 'violet', 'desc' => 'Cadastro de líderes (dados do Sênior).'],
                'projeto' => ['label' => 'Projetos', 'rota' => 'projeto.index', 'icone' => 'ph-folder-simple', 'cor' => 'blue', 'desc' => 'Cadastro de projetos.'],
            ],
            'Administração' => [
                'perfil' => ['label' => 'Perfis de Acesso', 'rota' => 'perfil.index', 'icone' => 'ph-user-gear', 'cor' => 'slate', 'desc' => 'Controle do que cada pessoa vê e edita.'],
            ],
        ];
    }

    /** Lista plana de chaves de módulo. @return array<int, string> */
    public static function chaves(): array
    {
        $out = [];
        foreach (self::modulos() as $grupo => $itens) {
            foreach ($itens as $chave => $meta) $out[] = $chave;
        }
        return $out;
    }

    /** Rótulo de um módulo. */
    public static function label(string $modulo): string
    {
        foreach (self::modulos() as $itens) {
            if (isset($itens[$modulo])) return $itens[$modulo]['label'];
        }
        return $modulo;
    }

    /**
     * Perfil vinculado ao usuário logado (ou null se não houver).
     */
    public static function perfilDoUsuario(): ?object
    {
        $u = user();
        $mat = $u->matricula ?? null;
        if (!$mat) return null;

        try {
            $up = UsuarioPerfil::selectOne()
                ->whereEquals('matricula', (string) $mat)
                ->andWhereIsNull('deleted_at')
                ->finish();
            if (!$up) return null;

            return Perfil::getById((int) $up->perfil_id) ?: null;
        } catch (\Throwable $e) {
            // Tabelas de perfil ainda não criadas: trata como acesso total.
            return null;
        }
    }

    /**
     * Mapa de permissões do usuário atual: modulo => [ver, editar].
     * Retorna null quando o usuário NÃO tem perfil (acesso total).
     *
     * @return array<string, array{ver:bool, editar:bool}>|null
     */
    public static function permissoes(): ?array
    {
        if (self::$cacheCarregado) return self::$cache;
        self::$cacheCarregado = true;

        $perfil = self::perfilDoUsuario();
        if (!$perfil) {
            self::$cache = null; // sem perfil = acesso total
            return null;
        }

        try {
            $rows = PerfilPermissao::select()->whereEquals('perfil_id', (int) $perfil->id)->finish() ?: [];
        } catch (\Throwable $e) {
            self::$cache = null;
            return null;
        }
        $map = [];
        foreach ($rows as $r) {
            $map[$r->modulo] = ['ver' => (bool) $r->pode_ver, 'editar' => (bool) $r->pode_editar];
        }
        self::$cache = $map;
        return $map;
    }

    /** O usuário atual pode VER o módulo? (sem perfil = vê tudo) */
    public static function podeVer(string $modulo): bool
    {
        $p = self::permissoes();
        if ($p === null) return true;
        return $p[$modulo]['ver'] ?? false;
    }

    /** O usuário atual pode EDITAR o módulo? (sem perfil = edita tudo) */
    public static function podeEditar(string $modulo): bool
    {
        $p = self::permissoes();
        if ($p === null) return true;
        return $p[$modulo]['editar'] ?? false;
    }

    /** Limpa o cache (após alterar perfis). */
    public static function limparCache(): void
    {
        self::$cache = null;
        self::$cacheCarregado = false;
    }
}
