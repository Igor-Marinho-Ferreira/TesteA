# Escopo — Requisição de EPIs e Uniformes

## Contexto atual

- Requisições de EPI e uniformes são feitas hoje manualmente, por meio de **4 painéis
  físicos** distribuídos nos setores.
- Diariamente, o administrativo coleta essas requisições para registro/efetivação
  das reservas em dois sistemas:
  - **Tela MAX0431** — reservas de EPIs
  - **Tela MAX5740** — reservas de uniformes
- Existe um **BI** que consolida as requisições registradas na tela MAX0431.
- É necessário validar manualmente as folhas preenchidas pelos funcionários.

## Problemas identificados

- Deslocamento físico diário para coleta de papéis, interrompendo outras atividades.
- Acúmulo de requisições quando não é possível sair para coleta (alta demanda).
- Dependência de terceiros para coleta eventual — não resolve o problema estrutural.
- Perda de requisições (folhas físicas nos painéis).
- Acúmulo entre turnos, aumentando o volume de trabalho.
- Processo manual sujeito a erros e retrabalho.

## Objetivo do projeto

Modernizar o processo substituindo folhas/processos manuais por um sistema digital
com **identificação via leitor de crachá**, eliminando o deslocamento do
administrativo para coleta das solicitações. Deve:

- Registrar a solicitação com login via crachá.
- Garantir integridade, rastreabilidade e segurança dos dados.
- Gerar relatórios.

## Telas de parametrização

### Cadastro de EPI's e Uniformes

- **Tipo de Item** (select): Uniformes / EPIs.
- **Código do Item**: ao informar, busca automática no **Logix**.
- **Descrição do Item**: preenchida automaticamente a partir do código — sem edição manual.
- **Imagem do Item**: upload, exibida para facilitar identificação visual e reduzir erro de seleção.
- Regras: sem código duplicado; só itens válidos no Logix; manutenção respeita permissões de usuário.
- Alimenta o formulário de requisição.

### Cadastro de Líderes

- **Matrícula**: busca automática no Sênior.
- **Nome**: busca por nome, caso a matrícula não seja conhecida.
- Alimenta o formulário de requisição.

### Cadastro de Projeto

- **Projeto**: campo texto.

## Requisição de EPI's e Uniformes pelos Operadores

- Identificação do colaborador via leitura de crachá (leitor integrado ao sistema).
- Fluxo: colaborador aproxima o crachá → consulta automática nas bases **Foracesso**
  e **Logix** → dados carregados automaticamente (matrícula, nome, centro de custo) —
  campos não editáveis manualmente.
- Sistema pergunta Uniforme ou EPIs, exibindo a lista cadastrada (descrição + imagem).
- Colaborador seleciona um ou mais itens e confirma a requisição.
- Requisição registrada com: data e hora, dados do colaborador, itens solicitados e quantidade.

### Regra de reserva de EPI (`MX_CARGO_EPI`)

1. **1ª validação**: matrícula + unidade funcional + cargo.
2. **2ª validação** (fallback, se não houver registro para a combinação acima):
   unidade funcional + cargo (configuração padrão).

O sistema prioriza a configuração específica do colaborador e, na ausência dela,
aplica a configuração padrão da unidade funcional/cargo.

### Crachás provisórios

- Lista de crachás provisórios de origem **Foracesso**.
- Ao ser lido, se ainda não tiver registro de uso no dia, o sistema pede o registro
  do **nome de uso** naquele dia, gravando data e horário.
- Quando o sistema estiver online, integra a informação de data/horário em que o
  colaborador pegou o crachá de volta ao Foracesso.
- Identificação de cada crachá: número, tipo (provisório), status.

## Relatório de Requisição de EPIs e Uniformes

Histórico completo das solicitações, para controle, rastreabilidade e auditoria.

**Informações apresentadas**: matrícula, nome do colaborador, centro de custo,
unidade funcional, cargo, número da requisição, data/hora da solicitação, tipo
(EPI/Uniforme), código e descrição do item, quantidade solicitada/atendida, status
da requisição, última data requisitada.

**Dados de reserva de EPI**: qual regra foi usada (prioridade 1 — matrícula + unidade
funcional + cargo; prioridade 2 — unidade funcional + cargo), permitindo identificar
qual cadastro da `MX_CARGO_EPI` foi utilizado.

**Filtros**: período (data inicial e final), matrícula.

**Finalidade**: controle das entregas, rastreabilidade das solicitações, apoio a
auditorias de segurança e compliance, acompanhamento de consumo por
colaborador/setor/centro de custo, identificação de requisições feitas com crachás
provisórios, monitoramento da aderência às regras de fornecimento (`MX_CARGO_EPI`).

## Integrações

- **Logix / Foracesso / Sênior** — origem via **Informix** (queries a serem enviadas
  pelo cliente; pontos de extensão marcados como `TODO` nos services).
- **Banco de dados do projeto** — intranet (`dbType` = `intranet`), banco `bd_amsted`,
  prefixo de tabelas `epi_`.
