<?php

$http = $_SERVER["HTTP_HOST"] ?? null;

// if (!$http || !in_array($http, ['172.30.0.59', '172.30.0.94', '172.29.5.2'])) {
//     http_response_code(403);
//     die('Acesso negado. Requisições externas não são permitidas.');
// }

require_once __DIR__ . "/vendor/autoload.php";

ini_set('display_errors', true);
ini_set('display_startup_errors', true);
error_reporting(E_ALL);

initSessionIfNotStarted();
$dotenv = Dotenv\Dotenv::createMutable(__DIR__);
$dotenv->load();
src\core\Bootstrap::start();
