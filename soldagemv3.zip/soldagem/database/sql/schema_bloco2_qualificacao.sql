-- =====================================================================
-- SR-3297 — Checklist de Inspeção de Soldagem
-- BLOCO 2 — Parametrização de Qualificação de Soldadores
-- =====================================================================

-- 2.1.3.1 — Cadastro de Qualificação (processo de soldagem AWS)
CREATE TABLE IF NOT EXISTS sol_qualificacao (
    id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid               CHAR(36)        NOT NULL,
    qualificacao       VARCHAR(60)     NOT NULL,   -- ex: GMAW
    descricao          VARCHAR(160)    NULL,       -- ex: Gas Metal Arc Welding
    regra_especial     TINYINT(1)      NOT NULL DEFAULT 0,
    modo_transferencia VARCHAR(60)     NULL,       -- default CURTO-CIRCUITO quando regra_especial
    created_at         DATETIME        NULL,
    updated_at         DATETIME        NULL,
    deleted_at         DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_qualif_uuid (uuid),
    UNIQUE KEY uq_sol_qualif_nome (qualificacao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.3.2 — Cadastro de Posição de Qualificação (Ângulo/Topo)
CREATE TABLE IF NOT EXISTS sol_posicao_qualificacao (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    tipo        VARCHAR(10)     NOT NULL,   -- 1G..6G
    posicao     VARCHAR(40)     NOT NULL,   -- Plana, Horizontal, Vertical, Sobre cabeça, Múltiplas posições tubo
    progressao  VARCHAR(20)     NULL,       -- Ascendente / Descendente (apenas quando Vertical)
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_pos_uuid (uuid),
    UNIQUE KEY uq_sol_pos_tipo_posicao (tipo, posicao, progressao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.3.3 — Cadastro de Treinamentos
CREATE TABLE IF NOT EXISTS sol_treinamento (
    id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid         CHAR(36)        NOT NULL,
    treinamento  VARCHAR(120)    NOT NULL,   -- ex: AWS D15.1
    created_at   DATETIME        NULL,
    updated_at   DATETIME        NULL,
    deleted_at   DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_trein_uuid (uuid),
    UNIQUE KEY uq_sol_trein_nome (treinamento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.3.4 — Cadastro de Soldadores
CREATE TABLE IF NOT EXISTS sol_soldador (
    id                            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid                          CHAR(36)        NOT NULL,
    matricula                     VARCHAR(40)     NOT NULL,
    nome                          VARCHAR(160)    NULL,
    cargo                         VARCHAR(120)    NULL,
    sinete                        VARCHAR(40)     NOT NULL,
    performance                   VARCHAR(10)     NULL,  -- BAIXA / MÉDIA / ALTA
    data_qualificacao             DATE            NULL,
    data_ultima_qualificacao      DATE            NULL,
    data_requalificacao           DATE            NULL,  -- auto = última + 6 meses
    status                        VARCHAR(10)     NOT NULL DEFAULT 'ativo',       -- ativo / inativo
    status_qualificacao           VARCHAR(20)     NULL,  -- QUALIFICADO / REQUALIFICAR
    numero_registro_requalificacao VARCHAR(40)    NULL,
    created_at                    DATETIME        NULL,
    updated_at                    DATETIME        NULL,
    deleted_at                    DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_soldador_uuid (uuid),
    UNIQUE KEY uq_sol_soldador_sinete (sinete),
    KEY idx_sol_soldador_matricula (matricula),
    KEY idx_sol_soldador_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Treinamentos do soldador (N:N)
CREATE TABLE IF NOT EXISTS sol_soldador_treinamento (
    id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    soldador_id    BIGINT UNSIGNED NOT NULL,
    treinamento_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY idx_ss_trein_sold (soldador_id),
    CONSTRAINT fk_ss_trein_sold FOREIGN KEY (soldador_id) REFERENCES sol_soldador (id) ON DELETE CASCADE,
    CONSTRAINT fk_ss_trein_trein FOREIGN KEY (treinamento_id) REFERENCES sol_treinamento (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Processos + posições do soldador (N:N com posição)
CREATE TABLE IF NOT EXISTS sol_soldador_processo (
    id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    soldador_id    BIGINT UNSIGNED NOT NULL,
    qualificacao_id BIGINT UNSIGNED NOT NULL,  -- processo de soldagem
    posicao_id     BIGINT UNSIGNED NULL,
    PRIMARY KEY (id),
    KEY idx_ss_proc_sold (soldador_id),
    CONSTRAINT fk_ss_proc_sold FOREIGN KEY (soldador_id) REFERENCES sol_soldador (id) ON DELETE CASCADE,
    CONSTRAINT fk_ss_proc_qualif FOREIGN KEY (qualificacao_id) REFERENCES sol_qualificacao (id),
    CONSTRAINT fk_ss_proc_pos FOREIGN KEY (posicao_id) REFERENCES sol_posicao_qualificacao (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Histórico de requalificações do soldador
CREATE TABLE IF NOT EXISTS sol_soldador_requalificacao (
    id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    soldador_id  BIGINT UNSIGNED NOT NULL,
    data         DATE            NULL,
    processo     VARCHAR(120)    NULL,
    observacao   TEXT            NULL,
    created_at   DATETIME        NULL,
    PRIMARY KEY (id),
    KEY idx_ss_requal_sold (soldador_id),
    CONSTRAINT fk_ss_requal_sold FOREIGN KEY (soldador_id) REFERENCES sol_soldador (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.3.9 — Cadastro de Formulário de Qualificação (catálogo base do RQS)
CREATE TABLE IF NOT EXISTS sol_formulario_qualificacao (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid            CHAR(36)        NOT NULL,
    qualificacao_id BIGINT UNSIGNED NOT NULL,  -- processo (Cadastro de Qualificação)
    descricao       VARCHAR(200)    NULL,
    created_at      DATETIME        NULL,
    updated_at      DATETIME        NULL,
    deleted_at      DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_formqual_uuid (uuid),
    KEY idx_sol_formqual_qualif (qualificacao_id),
    CONSTRAINT fk_sol_formqual_qualif FOREIGN KEY (qualificacao_id) REFERENCES sol_qualificacao (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sol_formulario_qualificacao_posicao (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    formulario_id BIGINT UNSIGNED NOT NULL,
    posicao_id    BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY idx_fqp_form (formulario_id),
    CONSTRAINT fk_fqp_form FOREIGN KEY (formulario_id) REFERENCES sol_formulario_qualificacao (id) ON DELETE CASCADE,
    CONSTRAINT fk_fqp_pos FOREIGN KEY (posicao_id) REFERENCES sol_posicao_qualificacao (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.3.8 — Relatório de Ensaio Visual e Dimensional de Solda
CREATE TABLE IF NOT EXISTS sol_ensaio_visual (
    id                   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid                 CHAR(36)        NOT NULL,
    numero_relatorio     VARCHAR(20)     NOT NULL,   -- NN/AAAA
    equipamento          VARCHAR(200)    NULL,
    quantidade           INT             NULL,
    data                 DATE            NULL,
    desenho              VARCHAR(120)    NULL,
    revisao              VARCHAR(60)     NULL,
    documentos_referencia VARCHAR(200)   NULL,
    revisao_doc          VARCHAR(60)     NULL,
    criterio_aceitacao   VARCHAR(200)    NULL,       -- ex: AWS D15.1 ED.2019
    tipo_junta           VARCHAR(40)     NULL,       -- TOPO / ÂNGULO / ÂNGULO/TOPO
    material             VARCHAR(160)    NULL,       -- default ASTM A242
    dimensoes            VARCHAR(120)    NULL,       -- default 12,7x200x200mm
    metodo               VARCHAR(80)     NULL,       -- default DIRETO
    condicao_superficie  VARCHAR(200)    NULL,       -- CSV: Escovada,Esmerilhada,Usinado,Jateada
    inspecao_realizada_em VARCHAR(200)   NULL,       -- CSV: Chanfro,Bisel,Face,Raiz
    avaliacao_resultado  VARCHAR(20)     NULL,       -- Aprovado / Reprovado
    radiografia_resultado VARCHAR(120)   NULL,
    radiografia_interpretada_por VARCHAR(160) NULL,
    ensaio_por_nome      VARCHAR(160)    NULL,
    ensaio_por_matricula VARCHAR(40)     NULL,
    ensaio_data          DATETIME        NULL,
    observacoes          TEXT            NULL,
    created_at           DATETIME        NULL,
    updated_at           DATETIME        NULL,
    deleted_at           DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_ensaio_uuid (uuid),
    UNIQUE KEY uq_sol_ensaio_numero (numero_relatorio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sol_ensaio_visual_instrumento (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ensaio_id       BIGINT UNSIGNED NOT NULL,
    categoria       VARCHAR(30)     NOT NULL,   -- calibre_solda, trena, luximetro, outros
    descricao       VARCHAR(120)    NULL,
    tipo            VARCHAR(120)    NULL,
    cod_instrumento VARCHAR(120)    NULL,
    validade        VARCHAR(60)     NULL,
    PRIMARY KEY (id),
    KEY idx_evi_ensaio (ensaio_id),
    CONSTRAINT fk_evi_ensaio FOREIGN KEY (ensaio_id) REFERENCES sol_ensaio_visual (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ocorrências (descontinuidades) por linha do ensaio visual
CREATE TABLE IF NOT EXISTS sol_ensaio_visual_ocorrencia (
    id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ensaio_id         BIGINT UNSIGNED NOT NULL,
    eps               VARCHAR(80)     NULL,
    processo_soldagem VARCHAR(80)     NULL,
    sinete            VARCHAR(40)     NULL,
    junta             VARCHAR(60)     NULL,
    descontinuidades  VARCHAR(255)    NULL,   -- CSV dos códigos marcados: MD,TR,R,AA,PO,RE,SB,DI,CO,P,FF,FP,PS
    avaliacao         VARCHAR(20)     NULL,   -- Aprovado / Reprovado
    ordem             INT             NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_evo_ensaio (ensaio_id),
    CONSTRAINT fk_evo_ensaio FOREIGN KEY (ensaio_id) REFERENCES sol_ensaio_visual (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.3.10 — Registro de Qualificação de Soldadores (RQS / Welder Performance Qualification)
CREATE TABLE IF NOT EXISTS sol_rqs (
    id                     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid                   CHAR(36)        NOT NULL,
    certificado_numero     VARCHAR(20)     NOT NULL,   -- NN/AAAA
    soldador_id            BIGINT UNSIGNED NULL,
    eps_id                 BIGINT UNSIGNED NULL,
    processo_soldagem      VARCHAR(120)    NULL,
    tipo                   VARCHAR(80)     NULL,
    data_teste             DATE            NULL,
    -- variáveis para cada processo (Usado no teste / Faixa de qualificação) em JSON
    variaveis_usado        JSON            NULL,
    variaveis_faixa        JSON            NULL,
    -- exame visual
    exame_visual_aceitavel VARCHAR(10)     NULL,       -- Sim / Não
    examinado_por          VARCHAR(160)    NULL,
    examinado_data         DATE            NULL,
    -- solda em ângulo
    macrografia            VARCHAR(120)    NULL,
    tamanho_perna          VARCHAR(60)     NULL,
    concavidade_convexidade VARCHAR(60)    NULL,
    ensaio_fratura         VARCHAR(120)    NULL,
    comprimento_defeitos   VARCHAR(60)     NULL,
    porcentagem_defeitos   VARCHAR(60)     NULL,
    testes_mecanicos_por   VARCHAR(160)    NULL,
    relatorio_numero       VARCHAR(60)     NULL,
    radiografia_resultado  VARCHAR(120)    NULL,
    radiografia_interpretada_por VARCHAR(160) NULL,
    teste_soldagem_por     VARCHAR(160)    NULL,
    teste_soldagem_data    DATE            NULL,
    companhia              VARCHAR(200)    NULL DEFAULT 'GREENBRIER MAXION EQUIP. SERV. FERR. S/A',
    aprovacao_por          VARCHAR(160)    NULL,
    aprovacao_data         DATE            NULL,
    etapa                  VARCHAR(20)     NOT NULL DEFAULT 'escola',  -- escola / engenharia
    status                 VARCHAR(20)     NOT NULL DEFAULT 'em_andamento',
    created_at             DATETIME        NULL,
    updated_at             DATETIME        NULL,
    deleted_at             DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_rqs_uuid (uuid),
    UNIQUE KEY uq_sol_rqs_cert (certificado_numero),
    KEY idx_sol_rqs_soldador (soldador_id),
    CONSTRAINT fk_sol_rqs_soldador FOREIGN KEY (soldador_id) REFERENCES sol_soldador (id),
    CONSTRAINT fk_sol_rqs_eps FOREIGN KEY (eps_id) REFERENCES sol_eps (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ensaio de dobramento guiado do RQS
CREATE TABLE IF NOT EXISTS sol_rqs_dobramento (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    rqs_id      BIGINT UNSIGNED NOT NULL,
    secao       VARCHAR(20)     NULL,   -- transversal / longitudinal
    amostra     VARCHAR(60)     NULL,
    tipo        VARCHAR(20)     NULL,   -- FACE / LATERAL / RAIZ / N/A
    resultado   VARCHAR(20)     NULL,   -- APROVADO / REPROVADO / N/A
    tempo       VARCHAR(40)     NULL,
    temperatura VARCHAR(40)     NULL,
    ordem       INT             NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_rqs_dob_rqs (rqs_id),
    CONSTRAINT fk_rqs_dob_rqs FOREIGN KEY (rqs_id) REFERENCES sol_rqs (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sol_rqs_etapa_log (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    rqs_id        BIGINT UNSIGNED NOT NULL,
    etapa         VARCHAR(20)     NOT NULL,
    observacao    TEXT            NULL,
    usuario_login VARCHAR(120)    NULL,
    usuario_nome  VARCHAR(160)    NULL,
    created_at    DATETIME        NULL,
    PRIMARY KEY (id),
    KEY idx_rqs_log_rqs (rqs_id),
    CONSTRAINT fk_rqs_log_rqs FOREIGN KEY (rqs_id) REFERENCES sol_rqs (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.3.7 — Estação MES x Qualificação AWS
CREATE TABLE IF NOT EXISTS sol_estacao_qualificacao (
    id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid               CHAR(36)        NOT NULL,
    linha_montagem     VARCHAR(120)    NULL,
    codigo_estacao_mes VARCHAR(120)    NULL,
    descricao_estacao  VARCHAR(200)    NULL,
    processo_solda_id  BIGINT UNSIGNED NULL,   -- Cadastro de Qualificação
    descricao_processo VARCHAR(200)    NULL,
    posicao_solda_id   BIGINT UNSIGNED NULL,   -- Cadastro de Posição de Qualificação
    ativo              TINYINT(1)      NOT NULL DEFAULT 1,
    created_at         DATETIME        NULL,
    updated_at         DATETIME        NULL,
    deleted_at         DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_estq_uuid (uuid),
    KEY idx_sol_estq_estacao (codigo_estacao_mes),
    CONSTRAINT fk_sol_estq_proc FOREIGN KEY (processo_solda_id) REFERENCES sol_qualificacao (id),
    CONSTRAINT fk_sol_estq_pos FOREIGN KEY (posicao_solda_id) REFERENCES sol_posicao_qualificacao (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.3.6 — Log de Validação de Continuidade de Certificação (integração MES)
CREATE TABLE IF NOT EXISTS sol_validacao_certificacao_log (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    soldador_id BIGINT UNSIGNED NULL,
    matricula   VARCHAR(40)     NULL,
    estacao     VARCHAR(120)    NULL,
    processo    VARCHAR(80)     NULL,
    posicao     VARCHAR(80)     NULL,
    data_login  DATETIME        NULL,
    resultado   VARCHAR(20)     NULL,   -- validado / bloqueado
    janela      VARCHAR(20)     NULL,   -- 30 / 40 / 60 dias
    created_at  DATETIME        NULL,
    PRIMARY KEY (id),
    KEY idx_sol_valc_sold (soldador_id),
    KEY idx_sol_valc_matricula (matricula)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
