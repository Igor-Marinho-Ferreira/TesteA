-- =====================================================================
-- SR-3297 — Rascunhos de formulário (server-side)
-- Guarda o estado parcial de qualquer formulário, por módulo + registro +
-- matrícula do usuário. Um rascunho por (modulo, referencia, matricula).
-- =====================================================================

CREATE TABLE IF NOT EXISTS sol_rascunho (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    modulo      VARCHAR(60)     NOT NULL,   -- ex.: plano, rqs, ensaio, checklist, soldador, eps
    referencia  VARCHAR(80)     NOT NULL,   -- uuid do registro em edição, ou 'novo'
    matricula   VARCHAR(40)     NOT NULL,   -- dono do rascunho
    payload     LONGTEXT        NULL,       -- JSON com os campos do formulário
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_rascunho_uuid (uuid),
    UNIQUE KEY uq_rascunho_chave (modulo, referencia, matricula),
    KEY idx_rascunho_owner (matricula)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
