-- =====================================================================
-- SR-3297 — Ajustes Gás e EPS (para bancos JÁ criados)
-- =====================================================================

-- ----- GÁS: composição/percentual viram campo de repetição --------------
-- Remove a UNIQUE do combo antigo (ignore o erro se já não existir).
ALTER TABLE sol_gas DROP INDEX uq_sol_gas_nome;
ALTER TABLE sol_gas ADD INDEX idx_sol_gas_nome (gas);

-- Nova tabela de componentes (composição + percentual).
CREATE TABLE IF NOT EXISTS sol_gas_componente (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    gas_id      BIGINT UNSIGNED NOT NULL,
    composicao  VARCHAR(120)    NULL,
    percentual  DECIMAL(6,2)    NULL,
    ordem       INT             NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_gas_comp_gas (gas_id),
    CONSTRAINT fk_gas_comp_gas FOREIGN KEY (gas_id) REFERENCES sol_gas (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Migra os dados antigos (se existirem as colunas) para o 1º componente.
-- (Rode apenas se sol_gas ainda tiver composicao/percentual.)
-- INSERT INTO sol_gas_componente (gas_id, composicao, percentual, ordem)
-- SELECT id, composicao, percentual, 0 FROM sol_gas
-- WHERE composicao IS NOT NULL OR percentual IS NOT NULL;

-- ----- EPS: coluna juntas ------------------------------------------------
ALTER TABLE sol_eps ADD COLUMN juntas VARCHAR(255) NULL AFTER codigo;
