-- =====================================================================
-- SR-3297 — Checklist de Inspeção de Soldagem
-- BLOCO 1 — Parametrização do Plano de Soldagem
-- Prefixo de tabelas: sol_
-- =====================================================================

-- 1.1.1.2 — Cadastro de Juntas
CREATE TABLE IF NOT EXISTS sol_junta (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    junta       VARCHAR(60)     NOT NULL,
    descricao   VARCHAR(200)    NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_junta_uuid (uuid),
    KEY idx_sol_junta_junta (junta)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.1.1.3 — Cadastro de Metal Base (Material)
CREATE TABLE IF NOT EXISTS sol_metal_base (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    metal_base  VARCHAR(120)    NOT NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_metal_base_uuid (uuid),
    UNIQUE KEY uq_sol_metal_base_nome (metal_base)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.1.1.4 — Cadastro de Gás (um gás com uma ou mais composições/percentuais)
CREATE TABLE IF NOT EXISTS sol_gas (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    gas         VARCHAR(120)    NOT NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_gas_uuid (uuid),
    KEY idx_sol_gas_nome (gas)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Componentes do gás (composição + percentual) — campo de repetição
CREATE TABLE IF NOT EXISTS sol_gas_componente (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    gas_id      BIGINT UNSIGNED NOT NULL,
    composicao  VARCHAR(120)    NULL,
    percentual  DECIMAL(6,2)    NULL,
    ordem       INT             NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_gas_comp_gas (gas_id),
    CONSTRAINT fk_gas_comp_gas FOREIGN KEY (gas_id) REFERENCES sol_gas (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cadastro de Desenho (usado pelo Plano de Soldagem — Detalhe da Junta puxa a imagem)
CREATE TABLE IF NOT EXISTS sol_desenho (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    numero      VARCHAR(80)     NOT NULL,
    imagem      VARCHAR(255)    NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_desenho_uuid (uuid),
    UNIQUE KEY uq_sol_desenho_numero (numero)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.1.1.5 — Upload de Informações da EPS (Especificação do Processo de Soldagem)
CREATE TABLE IF NOT EXISTS sol_eps (
    id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid               CHAR(36)        NOT NULL,
    numero_documento   VARCHAR(80)     NOT NULL,
    numero_rqps        VARCHAR(80)     NOT NULL,
    status             VARCHAR(40)     NULL,          -- ATIVA, QUALIFICAÇÃO
    codigo             VARCHAR(80)     NULL,          -- Código de Soldagem
    juntas             VARCHAR(255)    NULL,          -- juntas vinculadas (CSV)
    metal_base         VARCHAR(160)    NULL,
    faixa_espessura    VARCHAR(60)     NULL,          -- ex: 3,0 - 16,0
    tipo_junta         VARCHAR(40)     NULL,          -- TOPO, ÂNGULO, ÂNGULO/TOPO
    penetracao         VARCHAR(40)     NULL,
    cobre_junta        VARCHAR(40)     NULL,          -- backing: Com / Sem / Ambos
    processo_soldagem  VARCHAR(80)     NULL,
    tipo               VARCHAR(80)     NULL,          -- Semi-Automático, Automático...
    gas_protecao       VARCHAR(80)     NULL,
    metal_adicao       VARCHAR(120)    NULL,
    ttat               TINYINT(1)      NOT NULL DEFAULT 0,
    bitola             VARCHAR(40)     NULL,
    mb01               VARCHAR(120)    NULL,          -- Range: Mb (01)
    mb02               VARCHAR(120)    NULL,          -- Range: Mb (02)
    tensao             VARCHAR(60)     NULL,          -- ex: 28 - 32
    corrente           VARCHAR(60)     NULL,          -- ex: 170 - 240
    created_at         DATETIME        NULL,
    updated_at         DATETIME        NULL,
    deleted_at         DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_eps_uuid (uuid),
    UNIQUE KEY uq_sol_eps_documento (numero_documento),
    UNIQUE KEY uq_sol_eps_rqps (numero_rqps)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.1.1.7 — Cadastro de Responsáveis pelo Formulário de Registro do Plano de Soldagem
CREATE TABLE IF NOT EXISTS sol_plano_responsavel (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid            CHAR(36)        NOT NULL,
    etapa           VARCHAR(20)     NOT NULL,   -- elaborado, verificado, aprovado
    nome_responsavel VARCHAR(160)   NOT NULL,   -- usuário cadastrado
    matricula       VARCHAR(40)     NULL,
    cargo           VARCHAR(120)    NULL,
    departamento    VARCHAR(120)    NULL,
    created_at      DATETIME        NULL,
    updated_at      DATETIME        NULL,
    deleted_at      DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_plano_resp_uuid (uuid),
    KEY idx_sol_plano_resp_etapa (etapa)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.1.1.6 — Formulário de Registro do Plano de Soldagem (cabeçalho / etapa de fluxo)
CREATE TABLE IF NOT EXISTS sol_plano_soldagem (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid            CHAR(36)        NOT NULL,
    ps_numero       VARCHAR(20)     NOT NULL,   -- máscara N/YY
    rev             VARCHAR(20)     NULL,
    projeto         VARCHAR(160)    NULL,       -- Estágio (Safety Walk SR-1887)
    data            DATE            NULL,
    desenho_numero  VARCHAR(80)     NULL,
    titulo          VARCHAR(200)    NULL,
    etapa           VARCHAR(20)     NOT NULL DEFAULT 'elaborado', -- elaborado/verificado/aprovado
    status          VARCHAR(20)     NOT NULL DEFAULT 'em_andamento', -- em_andamento/aprovado/rejeitado
    created_at      DATETIME        NULL,
    updated_at      DATETIME        NULL,
    deleted_at      DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_plano_uuid (uuid),
    UNIQUE KEY uq_sol_plano_ps (ps_numero)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seção Metal Base do Plano (repetível)
CREATE TABLE IF NOT EXISTS sol_plano_metal_base (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    plano_id        BIGINT UNSIGNED NOT NULL,
    juntas          VARCHAR(160)    NULL,   -- uma ou mais juntas (separadas por vírgula)
    eps_referencia  VARCHAR(80)     NULL,
    processo        VARCHAR(80)     NULL,
    peca            INT             NULL,
    material        VARCHAR(160)    NULL,
    ordem           INT             NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_sol_plano_mb_plano (plano_id),
    CONSTRAINT fk_sol_plano_mb_plano FOREIGN KEY (plano_id) REFERENCES sol_plano_soldagem (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seção Detalhe da Junta (repetível)
CREATE TABLE IF NOT EXISTS sol_plano_detalhe_junta (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    plano_id    BIGINT UNSIGNED NOT NULL,
    imagem      VARCHAR(255)    NULL,   -- puxada do desenho
    posicao     VARCHAR(60)     NULL,   -- ex: F7
    junta       VARCHAR(60)     NULL,
    ordem       INT             NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_sol_plano_dj_plano (plano_id),
    CONSTRAINT fk_sol_plano_dj_plano FOREIGN KEY (plano_id) REFERENCES sol_plano_soldagem (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seção Parâmetros de Soldagem (repetível)
CREATE TABLE IF NOT EXISTS sol_plano_parametro (
    id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    plano_id         BIGINT UNSIGNED NOT NULL,
    junta            VARCHAR(60)     NULL,
    gas              VARCHAR(120)    NULL,
    vazao            VARCHAR(60)     NULL,   -- range ex: 15-20
    consumivel       VARCHAR(120)    NULL,   -- range ex: ER70S-6
    bitola           DECIMAL(6,2)    NULL,
    pol              VARCHAR(10)     NULL,   -- CCP / CCEN / CA
    tensao           VARCHAR(60)     NULL,   -- range
    corrente         VARCHAR(60)     NULL,   -- range
    vel_soldagem     VARCHAR(60)     NULL,   -- range
    temp_max_interp  VARCHAR(40)     NULL,
    ordem            INT             NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_sol_plano_param_plano (plano_id),
    CONSTRAINT fk_sol_plano_param_plano FOREIGN KEY (plano_id) REFERENCES sol_plano_soldagem (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Log de etapas do fluxo do Plano (Elaborado / Verificado / Aprovado) — rastreabilidade
CREATE TABLE IF NOT EXISTS sol_plano_etapa_log (
    id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    plano_id       BIGINT UNSIGNED NOT NULL,
    etapa          VARCHAR(20)     NOT NULL,   -- elaborado/verificado/aprovado
    resposta       VARCHAR(20)     NULL,       -- sim/nao, aprovar/rejeitar
    observacao     TEXT            NULL,
    usuario_login  VARCHAR(120)    NULL,
    usuario_nome   VARCHAR(160)    NULL,
    matricula      VARCHAR(40)     NULL,
    created_at     DATETIME        NULL,
    PRIMARY KEY (id),
    KEY idx_sol_plano_log_plano (plano_id),
    CONSTRAINT fk_sol_plano_log_plano FOREIGN KEY (plano_id) REFERENCES sol_plano_soldagem (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
