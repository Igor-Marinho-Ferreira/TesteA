-- =====================================================================
-- SR-3297 — Ajuste da tabela sol_junta (para bancos JÁ criados)
--   1) adiciona a coluna "descricao"
--   2) remove a UNIQUE do valor "junta" (o soft delete deixa deleted_at e a
--      UNIQUE bloqueava re-salvar um valor que havia sido excluído).
--      A não-duplicidade de registros ATIVOS é garantida pela aplicação.
-- =====================================================================

ALTER TABLE sol_junta ADD COLUMN descricao VARCHAR(200) NULL AFTER junta;

-- Remova a UNIQUE do valor (ignore o erro se ela já não existir).
ALTER TABLE sol_junta DROP INDEX uq_sol_junta_junta;
ALTER TABLE sol_junta ADD INDEX idx_sol_junta_junta (junta);
