-- =====================================================================
-- SR-3297 — Checklist de Inspeção de Soldagem
-- BLOCO 3 — Parametrização Checklist de Verificação do Processo de Soldagem
-- =====================================================================

-- 2.1.4.1 — Cadastro de Modelo do Vagão
CREATE TABLE IF NOT EXISTS sol_modelo_vagao (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    modelo      VARCHAR(120)    NOT NULL,   -- ex: HOPPER
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_modelo_uuid (uuid),
    UNIQUE KEY uq_sol_modelo_nome (modelo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.4.2 — Cadastro de Cliente
CREATE TABLE IF NOT EXISTS sol_cliente (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    cliente     VARCHAR(160)    NOT NULL,   -- ex: MRS
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_cliente_uuid (uuid),
    UNIQUE KEY uq_sol_cliente_nome (cliente)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.4.3 — Cadastro de Estágio de Soldagem (Safety Walk SR-1887)
CREATE TABLE IF NOT EXISTS sol_estagio_soldagem (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid        CHAR(36)        NOT NULL,
    estagio     VARCHAR(160)    NOT NULL,
    created_at  DATETIME        NULL,
    updated_at  DATETIME        NULL,
    deleted_at  DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_estagio_uuid (uuid),
    UNIQUE KEY uq_sol_estagio_nome (estagio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1.4.4 — Formulário de Checklist de Soldagem (cabeçalho)
CREATE TABLE IF NOT EXISTS sol_checklist (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid                CHAR(36)        NOT NULL,
    modelo_id           BIGINT UNSIGNED NULL,
    cliente_id          BIGINT UNSIGNED NULL,
    numero_viga_vagao   VARCHAR(80)     NULL,
    estagio_id          BIGINT UNSIGNED NULL,
    desenho_revisao     VARCHAR(120)    NULL,
    metal_base          VARCHAR(160)    NULL,
    matricula           VARCHAR(40)     NULL,
    nome                VARCHAR(160)    NULL,
    sinete              VARCHAR(40)     NULL,
    qualificacao        VARCHAR(120)    NULL,
    qualificacao_alerta VARCHAR(40)     NULL,   -- ok / a_vencer / vencida (notificação em tela)
    preenchido_por      VARCHAR(160)    NULL,
    matricula_preenchido VARCHAR(40)    NULL,
    data                DATE            NULL,
    status_verificacao  VARCHAR(20)     NULL,   -- Aprovado / Reprovado (automático x EPS)
    observacao          TEXT            NULL,
    created_at          DATETIME        NULL,
    updated_at          DATETIME        NULL,
    deleted_at          DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sol_checklist_uuid (uuid),
    KEY idx_sol_checklist_modelo (modelo_id),
    KEY idx_sol_checklist_cliente (cliente_id),
    KEY idx_sol_checklist_estagio (estagio_id),
    CONSTRAINT fk_sol_checklist_modelo FOREIGN KEY (modelo_id) REFERENCES sol_modelo_vagao (id),
    CONSTRAINT fk_sol_checklist_cliente FOREIGN KEY (cliente_id) REFERENCES sol_cliente (id),
    CONSTRAINT fk_sol_checklist_estagio FOREIGN KEY (estagio_id) REFERENCES sol_estagio_soldagem (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Parâmetros controlados do checklist (Encontrado x Especificado)
-- Campos: Nº EPS, Posição/Processo, Tensão(V), Corrente(A), Vazão de Gás(l/min),
--         Nº Máquina/Validade Calibração, Marca, Classificação do Arame,
--         Temperatura Interpasse, Fluxo
CREATE TABLE IF NOT EXISTS sol_checklist_parametro (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    checklist_id  BIGINT UNSIGNED NOT NULL,
    campo         VARCHAR(60)     NOT NULL,   -- chave do parâmetro
    encontrado    VARCHAR(200)    NULL,
    especificado  VARCHAR(200)    NULL,
    ordem         INT             NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_sol_chkparam_chk (checklist_id),
    CONSTRAINT fk_sol_chkparam_chk FOREIGN KEY (checklist_id) REFERENCES sol_checklist (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
