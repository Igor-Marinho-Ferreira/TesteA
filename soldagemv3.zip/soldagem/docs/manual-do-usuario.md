# Manual do Usuário — Checklist de Inspeção de Soldagem (SR-3297)

Sistema de digitalização do processo de inspeção de soldagem da GBMX (Greenbrier Maxion).
Substitui os formulários físicos por registro digital, com validação automática contra a EPS,
controle de qualificação de soldadores, fluxos de aprovação eletrônicos e disponibilização de
dados para Power BI.

---

## Sumário

1. [Visão geral](#1-visão-geral)
2. [Acesso e menu principal](#2-acesso-e-menu-principal)
3. [Como usar as telas (convenções)](#3-como-usar-as-telas-convenções)
4. [Bloco 1 — Plano de Soldagem](#4-bloco-1--plano-de-soldagem)
5. [Bloco 2 — Qualificação de Soldadores](#5-bloco-2--qualificação-de-soldadores)
6. [Bloco 3 — Checklist de Soldagem](#6-bloco-3--checklist-de-soldagem)
7. [Integrações & BI](#7-integrações--bi)
8. [Regras de negócio importantes](#8-regras-de-negócio-importantes)
9. [Glossário](#9-glossário)
10. [Apêndice — Instalação e banco de dados](#10-apêndice--instalação-e-banco-de-dados)

---

## 1. Visão geral

O sistema está organizado em **três blocos**, acessados pelo menu principal:

| Bloco | Finalidade |
|---|---|
| **1. Plano de Soldagem** | Parametrizar juntas, materiais, gases, desenhos, a EPS e registrar o Plano de Soldagem com fluxo de aprovação. |
| **2. Qualificação de Soldadores** | Cadastrar processos, posições, treinamentos e soldadores; emitir RQS e ensaio visual; validar a continuidade da certificação (MES). |
| **3. Checklist de Soldagem** | Cadastrar modelos de vagão, clientes e estágios; preencher o Checklist de Verificação do Processo. |

Além disso, há a seção **Integrações & BI** com a exportação de dados para Power BI.

**Fluxo típico de implantação dos dados** (sugestão de ordem de cadastro):
Juntas → Metal Base → Gás → Qualificação → Posição → Treinamentos → EPS → Soldadores →
Desenho → Plano de Soldagem → (Modelo/Cliente/Estágio) → Checklist.

---

## 2. Acesso e menu principal

Ao abrir o sistema, o **menu** apresenta cartões agrupados pelos três blocos. Clique em um
cartão para abrir a tela correspondente. O botão de **voltar** (seta no topo do cartão) retorna
ao menu.

Cada tela roda em desktop, tablet ou celular (o layout é responsivo).

---

## 3. Como usar as telas (convenções)

A maioria das telas de **cadastro** segue o mesmo padrão:

- **Formulário no topo** — preencha os campos e clique em **Registrar** (ou **Salvar
  alterações** ao editar). Campos com `*` são obrigatórios.
- **Busca/Filtro** — a caixa "Filtrar..." acima da tabela filtra os registros em tempo real
  (sem acento/maiúsculas).
- **Contador** — mostra quantos registros existem/estão filtrados.
- **Ações na linha:**
  - ✏️ **Editar** (lápis) — carrega o registro no formulário do topo.
  - 🗑️ **Excluir** (lixeira) — abre uma **confirmação** antes de apagar.
- **Bloqueios** — quando um registro já está sendo usado por outro módulo, o sistema **impede a
  edição/exclusão** e mostra uma mensagem explicando o motivo.

As mensagens de sucesso/erro aparecem como **notificações** no canto da tela.

---

## 4. Bloco 1 — Plano de Soldagem

### 4.1 Juntas
Cadastro simples das juntas de soldagem.
- **Campo:** Juntas (texto). Ex.: `J01`, `J02`.
- Não permite duplicar. Não permite editar/excluir se a junta já estiver em um Plano de Soldagem.

### 4.2 Metal Base (Material)
- **Campo:** Metal Base (texto). Ex.: `ASTM A36`, `SAE 1020`.
- Alimenta o Plano de Soldagem e o Checklist. Sem duplicidade; bloqueia edição/exclusão em uso.

### 4.3 Gás
- **Campos:** Gás, Composição, Percentual (%). Ex.: `Argônio`, `Mistura Ar+CO₂ (80/20)`.
- Duplicidade considera gás + composição + percentual.

### 4.4 Desenho
- **Campos:** Número do desenho, Imagem (PNG/JPG/PDF até 5 MB).
- A imagem é **reutilizada automaticamente** no "Detalhe da Junta" do Plano de Soldagem (quando o
  número do desenho é informado no plano).

### 4.5 Upload de Informações da EPS
A EPS (Especificação do Processo de Soldagem) pode ser cadastrada de duas formas:

**a) Importação em lote (Excel/CSV)**
- Formatos aceitos: **.xlsx** ou **.csv** (separador `;`).
- A **1ª linha deve conter o cabeçalho exatamente no layout** (o sistema mostra as colunas
  esperadas na tela). Se o cabeçalho não bater, o upload é bloqueado.
- Ordem das colunas: Número Documento · Número RQPS · Status · Código · MB (01) · MB (02) ·
  Faixa de Espessura [mm] · Tipo de Junta · Penetração · Cobre Junta (Backing) · Processo de
  Soldagem · Tipo · Gás de Proteção · Metal de adição · TTAT · Bitola [mm] · Tensão [V] ·
  Corrente [A].
- Não permite duplicar **Número Documento** nem **Número RQPS**. Linhas com esses campos vazios
  ou duplicados são ignoradas e reportadas ao final.

**b) Cadastro manual**
- Preencha os mesmos campos diretamente no formulário. Obrigatórios: Número Documento e Número RQPS.
- **Status** aceita `ATIVA` ou `QUALIFICAÇÃO`; **Tipo de Junta** aceita `TOPO`, `ÂNGULO`,
  `ÂNGULO/TOPO`; **Backing** aceita `Com`, `Sem`, `Ambos`.

> A EPS é a base da validação automática do Checklist e do RQS. Uma EPS vinculada a um RQS não
> pode ser editada/excluída.

### 4.6 Formulário do Plano de Soldagem
Registra o Plano de Soldagem em **quatro seções** e conduz o **fluxo de aprovação**.

**Seções do formulário (botão "Novo plano"):**
1. **Plano de Soldagem** — PS n.º (gerado automaticamente no formato `N/YY`), Rev, Projeto, Data
   (preenchida automaticamente, editável), Desenho n.º (escolha um desenho cadastrado), Título.
2. **Metal Base** (linhas dinâmicas) — Juntas, EPS de referência, Processo, Peça, Material.
   Use **Adicionar** para incluir mais linhas e o **×** para remover.
3. **Detalhe da Junta** (linhas dinâmicas) — Posição (ex.: `F7`), Junta. A **imagem** é puxada
   automaticamente do desenho selecionado.
4. **Parâmetros de Soldagem** (linhas dinâmicas) — Junta, Gás, Vazão, Consumível, Bitola, Pol
   (`CCP`/`CCEN`/`CA`), Tensão, Corrente, Vel. Soldagem, Temp. máx. interpasse.

**Fluxo de aprovação** (Elaborado → Verificado → Aprovado):
- Ao salvar, o plano fica na etapa **Elaborado**.
- **Verificar** (ícone ✔): responda "Relatório de plano de soldagem de acordo?" (Sim/Não) e
  registre observações. **Não** devolve o plano para Elaborado.
- **Aprovar** (ícone selo): a etapa final **Aprovar/Rejeitar**. Aprovado libera o plano; após a
  aprovação, **a edição fica bloqueada**.
- Todas as transições ficam registradas no **histórico do fluxo**.

> Regra: a verificação deve ser feita por um engenheiro **distinto** de quem elaborou.

### 4.7 Responsáveis do Plano
Define quem conduz cada etapa (Elaborado/Verificado/Aprovado).
- **Campos:** Etapa, Nome do Responsável, Matrícula, Cargo/Função, Departamento/Área.

---

## 5. Bloco 2 — Qualificação de Soldadores

### 5.1 Qualificação (Processo)
- **Campos:** Qualificação (ex.: `GMAW`), Descrição (ex.: `Gas Metal Arc Welding`), **Regra
  especial** (marcação).
- Ao marcar "Regra especial", aparece o campo **Modo de Transferência** (valor padrão
  `CURTO-CIRCUITO`).
- Sem duplicidade; bloqueia edição/exclusão se estiver em uso por um soldador/formulário.

### 5.2 Posição de Qualificação (Ângulo/Topo)
- **Tipo:** `1G` a `6G`. **Posição:** Plana, Horizontal, Vertical, Sobre cabeça, Múltiplas
  posições tubo.
- Se a posição for **Vertical**, aparece o campo **Progressão** (Ascendente/Descendente).

### 5.3 Treinamentos
- **Campo:** Treinamento (ex.: `AWS D15.1`).
- Alimenta o cadastro de Soldadores. Bloqueia edição/exclusão se referenciado por um soldador.

### 5.4 Soldadores
Cadastro central dos soldadores.
- **Identificação:** Matrícula, Nome, Cargo (lista sugerida: Soldador-Montador I/II/III,
  Soldador-Pintor I/II/III, Soldador Ferroviário I/II/III), Sinete (único).
- **Qualificação:** Performance (Baixa/Média/Alta), Data de qualificação, Data da última
  qualificação, **Data de requalificação** (calculada automaticamente: última + 6 meses),
  Status (Ativo/Inativo), Status da qualificação (Qualificado/Requalificar), Nº registro de
  requalificação (sequencial automático).
- **Vínculos (marcações):** Treinamentos, Processo de soldagem (qualificações) e Posições.
- Na listagem, a coluna **Requalificação** é destacada por cor conforme o vencimento
  (vermelho < 30 dias/vencida, amarelo < 40 dias, verde < 60 dias).

### 5.5 Formulário de Qualificação
Catálogo (Processo + Posições) que serve de base para o RQS.
- **Campos:** Processo (Qualificação), Descrição, Tipo e posição (marcações).

### 5.6 Estação MES × Qualificação AWS
Relaciona cada estação do MES ao processo e à posição de solda exigidos — base para a validação
de continuidade.
- **Campos:** Linha de Montagem, Código da Estação MES, Descrição da Estação, Processo de Solda
  (AWS), Descrição do Processo (preenchida automaticamente), Posição de Solda.
- **Exclusão** apenas **inativa** o vínculo (mantém rastreabilidade); é possível **reativar**.

### 5.7 RQS — Registro de Qualificação de Soldador
Formulário no padrão AWS D15.1, com **fluxo Escola → Engenharia**.
- **Cabeçalho:** Certificado (automático `NN/AAAA`), Soldador, EPS/WPS, Processo, Tipo, Data do
  Teste.
- **Variáveis para cada processo:** tabela com "Usado no teste" × "Faixa de qualificação".
- **Exame visual**, **Ensaio de dobramento guiado** (linhas dinâmicas), **Solda em ângulo /
  testes mecânicos**, radiografia e teste de soldagem.
- **Fluxo:** ao salvar, fica na etapa **Escola**. Use **Enviar para Engenharia** (avião) e
  depois **Aprovar** (selo) para concluir a qualificação.

### 5.8 Ensaio Visual e Dimensional de Solda
Relatório de inspeção visual/dimensional.
- **Documentos:** Nº Relatório (automático `NN/AAAA`), Equipamento, Quantidade, Desenho,
  Revisão, Documentos de referência, Critério de Aceitação.
- **Instrumentos utilizados:** Calibre de Solda, Trena, Luxímetro, Outros (Tipo, Cód., Validade).
- **Material ensaiado:** Tipo de junta, Material, Dimensões, Método.
- **Condição da superfície** e **Inspeção realizada em** (marcações).
- **Ocorrências (descontinuidades)** — linhas com EPS, Processo, Sinete, Junta, os códigos de
  descontinuidade (MD, TR, R, AA, PO, RE, SB, DI, CO, P, FF, FP, PS) e a avaliação.
- **Ensaio realizado por** é preenchido automaticamente (usuário logado, matrícula e data).

### 5.9 Relatório de Qualificação de Soldadores
Relatório consolidado com **filtros**: Todos, Vencimentos em 60/40/30 dias, Vencimentos em menos
de 30 dias, Vencidos, Qualificados, Requalificar, Funcionários ativos/inativos.
- Linhas destacadas por cor (vermelho/amarelo/verde) conforme o vencimento.
- Botão **Exportar Excel** gera a planilha com o filtro atual.

### 5.10 Validação de Certificação (MES)
Valida a **continuidade da qualificação** do soldador conforme a AWS (6 meses).
- Informe **Matrícula** + **Código da Estação** e clique em **Validar**.
- O sistema verifica: soldador ativo, vínculo ativo da estação, se o soldador possui o
  processo/posição exigidos e se a qualificação está **dentro dos 6 meses**.
- Resultado **Validado** ou **Bloqueado** (com o motivo), registrando o log e a **janela**
  (30/40/60 dias) de alerta preventivo.

> A leitura automática do MES (tela Critéria > Produção > Histórico Login) será conectada quando o
> acesso ao sistema MES estiver disponível. Por enquanto a tela permite validação por
> matrícula + estação.

---

## 6. Bloco 3 — Checklist de Soldagem

### 6.1 Modelos de Vagão
- **Campo:** Modelo (ex.: `HOPPER`). Alimenta o Checklist. Bloqueia edição/exclusão se em uso.

### 6.2 Clientes
- **Campo:** Cliente (ex.: `MRS`). Alimenta o Checklist.

### 6.3 Estágios de Soldagem
- **Campo:** Estágio. Alimenta o Checklist.

### 6.4 Formulário de Checklist de Soldagem
O coração do sistema — o Checklist de Verificação do Processo de Soldagem.
1. Clique em **Novo checklist**.
2. **Identificação:** Modelo, Cliente, Nº Viga/Vagão, Estágio, Desenho/Revisão, Metal Base e
   **Matrícula** do soldador. Ao digitar a matrícula e pressionar Enter, o sistema **busca o
   soldador** e preenche Nome, Sinete e Qualificação, além de exibir um **alerta** se a
   qualificação estiver vencida ou a vencer (< 30 dias).
3. **Parâmetros controlados** — para cada parâmetro (Nº EPS, Posição/Processo, Tensão, Corrente,
   Vazão de Gás, Nº Máquina/Validade Calibração, Marca, Classificação do Arame, Temperatura
   Interpasse, Fluxo), informe **Encontrado** e **Especificado (EPS)**.
4. **Status automático:** se qualquer valor Encontrado divergir do Especificado, o checklist é
   marcado **Reprovado**; caso contrário, **Aprovado**. O preenchimento por/matrícula/data são
   automáticos.

---

## 7. Integrações & BI

### 7.1 Power BI
Todas as telas disponibilizam dados para o Power BI. Na tela **Power BI** é possível **exportar
os datasets** em Excel: Soldadores, Checklist, EPS, Planos de Soldagem, RQS e Ensaios Visuais.

> O acesso ao Power BI é restrito aos usuários definidos no escopo; os demais devem solicitar
> acesso via serviço no Freshservice.

---

## 8. Regras de negócio importantes

- **Sem duplicidade** — cadastros base (Juntas, Metal Base, Gás, Qualificação, Treinamento,
  Modelo, Cliente, Estágio, EPS, Sinete de soldador) não aceitam valores repetidos.
- **Bloqueio de edição/exclusão em uso** — não é possível alterar/excluir um registro que já está
  referenciado por outro módulo (ex.: uma junta usada em um Plano, uma EPS usada em um RQS).
- **Requalificação de soldador** — a data de requalificação é sempre **última qualificação + 6
  meses**; os relatórios destacam vencimentos em 30/40/60 dias.
- **Continuidade AWS** — a qualificação vale enquanto houver evidência dentro de **6 meses**; as
  janelas 30/40/60 são alertas internos (não substituem os 6 meses).
- **Numeração automática** — PS do Plano (`N/YY`), Certificado do RQS e Nº do Ensaio Visual
  (`NN/AAAA`) são gerados automaticamente e **reiniciam a cada ano**.
- **Bloqueio pós-aprovação** — o Plano de Soldagem aprovado não pode mais ser editado.
- **Rastreabilidade** — usuário, data e hora são gravados automaticamente nos fluxos e nos
  registros (Plano, RQS, Ensaio, Checklist, Validação).

---

## 9. Glossário

| Termo | Significado |
|---|---|
| **EPS** | Especificação do Processo de Soldagem. |
| **RQS** | Registro de Qualificação de Soldador (Welder Performance Qualification Test Record). |
| **Sinete** | Código pessoal de identificação do soldador (número ou marca que identifica quem executou a solda). |
| **MES** | Manufacturing Execution System (sistema de execução da manufatura, onde ocorre o login nas estações). |
| **AWS D1.1 / D15.1** | Normas de soldagem aplicáveis (estrutural / ferroviária). |
| **Backing / Cobre Junta** | Elemento de apoio na raiz da solda (Com/Sem/Ambos). |
| **TTAT** | Tratamento Térmico Após a Soldagem. |
| **Descontinuidades** | MD-Mordedura, TR-Trinca, R-Respingo, AA-Abertura de arco, PO-Porosidade, RE-Reforço excessivo, SB-Sobreposição, DI-Deposição insuficiente, CO-Concavidade, P-Perfuração, FF-Falta de fusão, FP-Falta de penetração, PS-Perfil de solda. |

---

## 10. Apêndice — Instalação e banco de dados

**Requisitos:** PHP com MySQL, servidor Apache (com o rewrite do `.htaccess`). Em produção, as
conexões são lidas das configurações da intranet; em desenvolvimento, usa-se o MySQL local
(Docker `mysql-db`).

**Criação das tabelas** (prefixo `sol_`): execute os três scripts, na ordem:

```bash
mysql -h 127.0.0.1 -u root -proot ammx < database/sql/schema_bloco1_plano.sql
mysql -h 127.0.0.1 -u root -proot ammx < database/sql/schema_bloco2_qualificacao.sql
mysql -h 127.0.0.1 -u root -proot ammx < database/sql/schema_bloco3_checklist.sql
```

**Uploads:** os arquivos (imagens de desenho) são gravados em `public/uploads/`.

**Convenções técnicas:** arquitetura MVC própria; camada de dados via *Querio* (query builder);
telas em League/Plates. Detalhes para desenvolvedores em [`.claude/instructions.md`](../.claude/instructions.md)
e no [`README.md`](../README.md).

---

*Documento gerado para o projeto SR-3297 — Checklist de Inspeção de Soldagem (GBMX).*
