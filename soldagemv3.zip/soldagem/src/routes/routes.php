<?php

namespace src\routes;


use src\app\controllers\ArquivoController;
use src\app\controllers\ChecklistController;
use src\app\controllers\ClienteController;
use src\app\controllers\DesenhoController;
use src\app\controllers\EnsaioVisualController;
use src\app\controllers\EstagioSoldagemController;
use src\app\controllers\EpsController;
use src\app\controllers\EstacaoQualificacaoController;
use src\app\controllers\FormularioQualificacaoController;
use src\app\controllers\GasController;
use src\app\controllers\JuntaController;
use src\app\controllers\ManualController;
use src\app\controllers\MenuController;
use src\app\controllers\MetalBaseController;
use src\app\controllers\ModeloVagaoController;
use src\app\controllers\PerfilController;
use src\app\controllers\PlanoResponsavelController;
use src\app\controllers\PlanoSoldagemController;
use src\app\controllers\PosicaoQualificacaoController;
use src\app\controllers\PowerBiController;
use src\app\controllers\QualificacaoController;
use src\app\controllers\RascunhoController;
use src\app\controllers\RelatorioController;
use src\app\controllers\RqsController;
use src\app\controllers\SoldadorController;
use src\app\controllers\TreinamentoController;
use src\app\controllers\ValidacaoCertificacaoController;
use src\app\middlewares\IsLoggedMiddleware;
use src\core\Route;


// SR-3297 — Digitalização do Processo: Checklist de Inspeção de Soldagem

// Menu principal
Route::get('/', MenuController::class, 'index')
    ->name('menu')
    ->middlewares([IsLoggedMiddleware::class]);

// Rascunhos de formulário (server-side)
Route::get('/rascunho/obter', RascunhoController::class, 'obter')->name('rascunho.obter')->middlewares([IsLoggedMiddleware::class]);
Route::post('/rascunho/salvar', RascunhoController::class, 'salvar')->name('rascunho.salvar')->middlewares([IsLoggedMiddleware::class]);
Route::post('/rascunho/descartar', RascunhoController::class, 'descartar')->name('rascunho.descartar')->middlewares([IsLoggedMiddleware::class]);

// Servir arquivos do storage externo ({projeto}-storage)
Route::get('/arquivo', ArquivoController::class, 'download')
    ->name('arquivo')
    ->middlewares([IsLoggedMiddleware::class]);

// Manual do sistema (como o processo e cada tela funcionam)
Route::get('/manual', ManualController::class, 'index')
    ->name('manual.index')
    ->middlewares([IsLoggedMiddleware::class]);

// Perfis de Acesso (controle do que cada pessoa vê e edita)
Route::get('/perfis', PerfilController::class, 'index')->name('perfil.index')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/store', PerfilController::class, 'store')->name('perfil.store')->middlewares([IsLoggedMiddleware::class]);
Route::get('/perfis/{uuid}/editar', PerfilController::class, 'edit')->name('perfil.edit')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/update', PerfilController::class, 'update')->name('perfil.update')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/excluir', PerfilController::class, 'destroy')->name('perfil.destroy')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/vincular', PerfilController::class, 'vincular')->name('perfil.vincular')->middlewares([IsLoggedMiddleware::class]);
Route::post('/perfis/desvincular', PerfilController::class, 'desvincular')->name('perfil.desvincular')->middlewares([IsLoggedMiddleware::class]);


/**
 * Helper local: registra o CRUD padrão de um cadastro simples.
 * (index, store, edit, update, destroy)
 */
$crud = function (string $path, string $name, string $controller) {
    Route::get("/{$path}", $controller, 'index')->name("{$name}.index")->middlewares([IsLoggedMiddleware::class]);
    Route::post("/{$path}/store", $controller, 'store')->name("{$name}.store")->middlewares([IsLoggedMiddleware::class]);
    Route::get("/{$path}/{uuid}/editar", $controller, 'edit')->name("{$name}.edit")->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
    Route::post("/{$path}/update", $controller, 'update')->name("{$name}.update")->middlewares([IsLoggedMiddleware::class]);
    Route::post("/{$path}/excluir", $controller, 'destroy')->name("{$name}.destroy")->middlewares([IsLoggedMiddleware::class]);
};


// ── Bloco 1 — Parametrização do Plano de Soldagem ─────────────────────────
$crud('juntas',        'junta',      JuntaController::class);
$crud('metais-base',   'metal_base', MetalBaseController::class);
$crud('gases',         'gas',        GasController::class);
$crud('desenhos',      'desenho',    DesenhoController::class);
$crud('eps',           'eps',        EpsController::class);
Route::post('/eps/importar', EpsController::class, 'importar')->name('eps.importar')->middlewares([IsLoggedMiddleware::class]);
$crud('plano-responsaveis', 'plano_responsavel', PlanoResponsavelController::class);

// Formulário de Registro do Plano de Soldagem (1.1.1.6) — com fluxo de aprovação
Route::get('/plano', PlanoSoldagemController::class, 'index')->name('plano.index')->middlewares([IsLoggedMiddleware::class]);
Route::get('/plano/novo', PlanoSoldagemController::class, 'create')->name('plano.create')->middlewares([IsLoggedMiddleware::class]);
Route::post('/plano/store', PlanoSoldagemController::class, 'store')->name('plano.store')->middlewares([IsLoggedMiddleware::class]);
Route::get('/plano/{uuid}/editar', PlanoSoldagemController::class, 'edit')->name('plano.edit')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::get('/plano/{uuid}', PlanoSoldagemController::class, 'show')->name('plano.show')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::post('/plano/update', PlanoSoldagemController::class, 'update')->name('plano.update')->middlewares([IsLoggedMiddleware::class]);
Route::post('/plano/excluir', PlanoSoldagemController::class, 'destroy')->name('plano.destroy')->middlewares([IsLoggedMiddleware::class]);
Route::get('/plano/{uuid}/verificar', PlanoSoldagemController::class, 'verificarForm')->name('plano.verificar_form')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::post('/plano/verificar', PlanoSoldagemController::class, 'verificar')->name('plano.verificar')->middlewares([IsLoggedMiddleware::class]);
Route::get('/plano/{uuid}/aprovar', PlanoSoldagemController::class, 'aprovarForm')->name('plano.aprovar_form')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::post('/plano/aprovar', PlanoSoldagemController::class, 'aprovar')->name('plano.aprovar')->middlewares([IsLoggedMiddleware::class]);

// ── Bloco 2 — Parametrização de Qualificação de Soldadores ────────────────
$crud('qualificacoes',         'qualificacao',         QualificacaoController::class);
$crud('posicoes-qualificacao', 'posicao_qualificacao', PosicaoQualificacaoController::class);
$crud('treinamentos',          'treinamento',          TreinamentoController::class);
$crud('soldadores',            'soldador',             SoldadorController::class);
$crud('estacao-qualificacao',  'estacao_qualificacao', EstacaoQualificacaoController::class);
Route::get('/estacao-qualificacao/{uuid}/ativar', EstacaoQualificacaoController::class, 'ativar')->name('estacao_qualificacao.ativar')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
$crud('formularios-qualificacao', 'formulario_qualificacao', FormularioQualificacaoController::class);

// Relatório de Ensaio Visual e Dimensional de Solda (2.1.3.8)
Route::get('/ensaio', EnsaioVisualController::class, 'index')->name('ensaio.index')->middlewares([IsLoggedMiddleware::class]);
Route::get('/ensaio/novo', EnsaioVisualController::class, 'create')->name('ensaio.create')->middlewares([IsLoggedMiddleware::class]);
Route::post('/ensaio/store', EnsaioVisualController::class, 'store')->name('ensaio.store')->middlewares([IsLoggedMiddleware::class]);
Route::get('/ensaio/{uuid}/editar', EnsaioVisualController::class, 'edit')->name('ensaio.edit')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::post('/ensaio/update', EnsaioVisualController::class, 'update')->name('ensaio.update')->middlewares([IsLoggedMiddleware::class]);
Route::post('/ensaio/excluir', EnsaioVisualController::class, 'destroy')->name('ensaio.destroy')->middlewares([IsLoggedMiddleware::class]);

// Registro de Qualificação de Soldadores — RQS (2.1.3.10) com fluxo Escola → Engenharia
Route::get('/rqs', RqsController::class, 'index')->name('rqs.index')->middlewares([IsLoggedMiddleware::class]);
Route::get('/rqs/novo', RqsController::class, 'create')->name('rqs.create')->middlewares([IsLoggedMiddleware::class]);
Route::post('/rqs/store', RqsController::class, 'store')->name('rqs.store')->middlewares([IsLoggedMiddleware::class]);
Route::get('/rqs/{uuid}/editar', RqsController::class, 'edit')->name('rqs.edit')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::post('/rqs/update', RqsController::class, 'update')->name('rqs.update')->middlewares([IsLoggedMiddleware::class]);
Route::post('/rqs/excluir', RqsController::class, 'destroy')->name('rqs.destroy')->middlewares([IsLoggedMiddleware::class]);
Route::get('/rqs/{uuid}/enviar', RqsController::class, 'enviar')->name('rqs.enviar')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::get('/rqs/{uuid}/aprovar', RqsController::class, 'aprovar')->name('rqs.aprovar')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);

// Relatório de Qualificação de Soldadores (2.1.3.5)
Route::get('/relatorio/qualificacao', RelatorioController::class, 'qualificacaoSoldadores')->name('relatorio.qualificacao')->middlewares([IsLoggedMiddleware::class]);
Route::get('/relatorio/qualificacao/excel', RelatorioController::class, 'qualificacaoExcel')->name('relatorio.qualificacao.excel')->middlewares([IsLoggedMiddleware::class]);

// Validação de Continuidade da Certificação (2.1.3.6) — integração MES
Route::get('/validacao', ValidacaoCertificacaoController::class, 'index')->name('validacao.index')->middlewares([IsLoggedMiddleware::class]);
Route::post('/validacao/validar', ValidacaoCertificacaoController::class, 'validar')->name('validacao.validar')->middlewares([IsLoggedMiddleware::class]);

// Power BI (2.1.4.7) — disponibilização dos dados
Route::get('/power-bi', PowerBiController::class, 'index')->name('powerbi.index')->middlewares([IsLoggedMiddleware::class]);
Route::get('/power-bi/{dataset}/exportar', PowerBiController::class, 'exportar')->name('powerbi.exportar')->whereString('dataset')->middlewares([IsLoggedMiddleware::class]);

// ── Bloco 3 — Parametrização Checklist de Verificação do Processo ─────────
$crud('modelos-vagao',    'modelo_vagao',     ModeloVagaoController::class);
$crud('clientes',         'cliente',          ClienteController::class);
$crud('estagios-soldagem', 'estagio_soldagem', EstagioSoldagemController::class);

// Formulário de Checklist de Soldagem (2.1.4.4)
Route::get('/checklist', ChecklistController::class, 'index')->name('checklist.index')->middlewares([IsLoggedMiddleware::class]);
Route::get('/checklist/novo', ChecklistController::class, 'create')->name('checklist.create')->middlewares([IsLoggedMiddleware::class]);
Route::get('/checklist/soldador', ChecklistController::class, 'buscarSoldador')->name('checklist.soldador')->middlewares([IsLoggedMiddleware::class]);
Route::post('/checklist/store', ChecklistController::class, 'store')->name('checklist.store')->middlewares([IsLoggedMiddleware::class]);
Route::get('/checklist/{uuid}/editar', ChecklistController::class, 'edit')->name('checklist.edit')->whereUuid('uuid')->middlewares([IsLoggedMiddleware::class]);
Route::post('/checklist/update', ChecklistController::class, 'update')->name('checklist.update')->middlewares([IsLoggedMiddleware::class]);
Route::post('/checklist/excluir', ChecklistController::class, 'destroy')->name('checklist.destroy')->middlewares([IsLoggedMiddleware::class]);


// ─────────────────────────────────────────────────────────────────────────
// Módulos ainda em construção (próximas fases):
//   Bloco 1: Upload EPS · Formulário do Plano de Soldagem · Responsáveis
//   Bloco 2: Soldadores · RQS · Ensaio Visual · Estação MES×AWS · Validação MES · Relatório
//   Bloco 3: Formulário de Checklist de Soldagem
//   + Power BI (ETL)
// ─────────────────────────────────────────────────────────────────────────
