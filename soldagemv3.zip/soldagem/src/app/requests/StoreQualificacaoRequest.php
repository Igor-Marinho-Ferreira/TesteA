<?php

namespace src\app\requests;

class StoreQualificacaoRequest extends Request
{
    protected array $rules = [
        'qualificacao' => 'required|maxLen:60',
        'descricao'    => 'required|maxLen:160',
    ];
}
