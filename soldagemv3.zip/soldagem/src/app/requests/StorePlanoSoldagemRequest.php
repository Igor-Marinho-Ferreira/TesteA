<?php

namespace src\app\requests;

class StorePlanoSoldagemRequest extends Request
{
    protected array $rules = [
        'ps_numero' => 'required|maxLen:20',
    ];
}
