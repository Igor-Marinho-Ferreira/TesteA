<?php

namespace src\app\requests;

class StoreJuntaRequest extends Request
{
    protected array $rules = [
        'junta' => 'required|maxLen:60',
    ];
}
