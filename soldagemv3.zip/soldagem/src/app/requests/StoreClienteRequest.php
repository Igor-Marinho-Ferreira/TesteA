<?php

namespace src\app\requests;

class StoreClienteRequest extends Request
{
    protected array $rules = [
        'cliente' => 'required|maxLen:160',
    ];
}
