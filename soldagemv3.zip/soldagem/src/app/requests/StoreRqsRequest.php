<?php

namespace src\app\requests;

class StoreRqsRequest extends Request
{
    protected array $rules = [
        'soldador_id' => 'required',
    ];
}
