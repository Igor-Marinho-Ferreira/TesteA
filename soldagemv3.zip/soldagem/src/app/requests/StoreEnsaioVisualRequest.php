<?php

namespace src\app\requests;

class StoreEnsaioVisualRequest extends Request
{
    protected array $rules = [
        'tipo_junta' => 'required',
    ];
}
