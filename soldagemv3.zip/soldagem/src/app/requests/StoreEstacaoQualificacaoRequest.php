<?php

namespace src\app\requests;

class StoreEstacaoQualificacaoRequest extends Request
{
    protected array $rules = [
        'codigo_estacao_mes' => 'required|maxLen:120',
        'processo_solda_id'  => 'required',
        'posicao_solda_id'   => 'required',
    ];
}
