<?php

namespace src\app\requests;

class StoreEstagioSoldagemRequest extends Request
{
    protected array $rules = [
        'estagio' => 'required|maxLen:160',
    ];
}
