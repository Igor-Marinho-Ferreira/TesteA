<?php

namespace src\app\requests;

class StoreChecklistRequest extends Request
{
    protected array $rules = [
        'matricula' => 'required|maxLen:40',
    ];
}
