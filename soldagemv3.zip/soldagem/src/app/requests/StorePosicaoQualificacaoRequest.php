<?php

namespace src\app\requests;

class StorePosicaoQualificacaoRequest extends Request
{
    protected array $rules = [
        'tipo'    => 'required|maxLen:10',
        'posicao' => 'required|maxLen:40',
    ];
}
