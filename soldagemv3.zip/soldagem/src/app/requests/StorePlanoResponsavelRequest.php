<?php

namespace src\app\requests;

class StorePlanoResponsavelRequest extends Request
{
    protected array $rules = [
        'etapa'            => 'required',
        'nome_responsavel' => 'required|maxLen:160',
    ];
}
