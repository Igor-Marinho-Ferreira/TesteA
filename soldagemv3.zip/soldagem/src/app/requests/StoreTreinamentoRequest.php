<?php

namespace src\app\requests;

class StoreTreinamentoRequest extends Request
{
    protected array $rules = [
        'treinamento' => 'required|maxLen:120',
    ];
}
