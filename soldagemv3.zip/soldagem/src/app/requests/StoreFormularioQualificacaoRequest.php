<?php

namespace src\app\requests;

class StoreFormularioQualificacaoRequest extends Request
{
    protected array $rules = [
        'qualificacao_id' => 'required',
    ];
}
