<?php

namespace src\app\requests;

class StoreGasRequest extends Request
{
    protected array $rules = [
        'gas' => 'required|maxLen:120',
    ];
}
