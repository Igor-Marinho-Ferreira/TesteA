<?php

namespace src\app\requests;

class StoreModeloVagaoRequest extends Request
{
    protected array $rules = [
        'modelo' => 'required|maxLen:120',
    ];
}
