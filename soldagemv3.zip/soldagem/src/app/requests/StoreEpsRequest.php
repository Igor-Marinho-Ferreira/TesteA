<?php

namespace src\app\requests;

class StoreEpsRequest extends Request
{
    protected array $rules = [
        'numero_documento' => 'required|maxLen:80',
        'numero_rqps'      => 'required|maxLen:80',
    ];
}
