<?php

namespace src\app\requests;

class StoreSoldadorRequest extends Request
{
    protected array $rules = [
        'matricula' => 'required|maxLen:40',
        'sinete'    => 'required|maxLen:40',
    ];
}
