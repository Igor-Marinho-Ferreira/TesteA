<?php

namespace src\app\requests;

class StoreMetalBaseRequest extends Request
{
    protected array $rules = [
        'metal_base' => 'required|maxLen:120',
    ];
}
