<?php

namespace src\app\requests;

class StoreDesenhoRequest extends Request
{
    protected array $rules = [
        'numero' => 'required|maxLen:80',
    ];
}
