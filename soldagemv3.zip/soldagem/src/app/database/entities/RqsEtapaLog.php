<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class RqsEtapaLog extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_rqs_etapa_log';
    protected static string $dbType = 'intranet';
}
