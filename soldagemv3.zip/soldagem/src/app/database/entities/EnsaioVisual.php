<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class EnsaioVisual extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_ensaio_visual';
    protected static string $dbType = 'intranet';
}
