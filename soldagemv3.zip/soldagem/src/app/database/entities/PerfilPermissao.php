<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PerfilPermissao extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_perfil_permissao';
    protected static string $dbType = 'intranet';
}
