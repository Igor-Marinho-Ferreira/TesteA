<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Qualificacao extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_qualificacao';
    protected static string $dbType = 'intranet';
}
