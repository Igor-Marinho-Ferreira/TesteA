<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Treinamento extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_treinamento';
    protected static string $dbType = 'intranet';
}
