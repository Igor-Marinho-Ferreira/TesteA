<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Gas extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_gas';
    protected static string $dbType = 'intranet';
}
