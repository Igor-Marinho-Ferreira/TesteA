<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PlanoParametro extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_plano_parametro';
    protected static string $dbType = 'intranet';
}
