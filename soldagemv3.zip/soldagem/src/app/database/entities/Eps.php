<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Eps extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_eps';
    protected static string $dbType = 'intranet';
}
