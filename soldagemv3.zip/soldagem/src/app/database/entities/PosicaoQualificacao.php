<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PosicaoQualificacao extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_posicao_qualificacao';
    protected static string $dbType = 'intranet';
}
