<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PlanoResponsavel extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_plano_responsavel';
    protected static string $dbType = 'intranet';
}
