<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Checklist extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_checklist';
    protected static string $dbType = 'intranet';
}
