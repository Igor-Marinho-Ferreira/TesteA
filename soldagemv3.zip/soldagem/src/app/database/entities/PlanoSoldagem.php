<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PlanoSoldagem extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_plano_soldagem';
    protected static string $dbType = 'intranet';
}
