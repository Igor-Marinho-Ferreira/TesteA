<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class SoldadorProcesso extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_soldador_processo';
    protected static string $dbType = 'intranet';
}
