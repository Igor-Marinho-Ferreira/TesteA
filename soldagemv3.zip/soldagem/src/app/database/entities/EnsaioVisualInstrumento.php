<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class EnsaioVisualInstrumento extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_ensaio_visual_instrumento';
    protected static string $dbType = 'intranet';
}
