<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class FormularioQualificacao extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_formulario_qualificacao';
    protected static string $dbType = 'intranet';
}
