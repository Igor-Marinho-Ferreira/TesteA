<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class FormularioQualificacaoPosicao extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_formulario_qualificacao_posicao';
    protected static string $dbType = 'intranet';
}
