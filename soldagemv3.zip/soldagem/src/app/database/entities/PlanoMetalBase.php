<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PlanoMetalBase extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_plano_metal_base';
    protected static string $dbType = 'intranet';
}
