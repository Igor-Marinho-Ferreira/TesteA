<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class EnsaioVisualOcorrencia extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_ensaio_visual_ocorrencia';
    protected static string $dbType = 'intranet';
}
