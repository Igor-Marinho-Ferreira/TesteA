<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class ValidacaoCertificacaoLog extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_validacao_certificacao_log';
    protected static string $dbType = 'intranet';
}
