<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Desenho extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_desenho';
    protected static string $dbType = 'intranet';
}
