<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Soldador extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_soldador';
    protected static string $dbType = 'intranet';
}
