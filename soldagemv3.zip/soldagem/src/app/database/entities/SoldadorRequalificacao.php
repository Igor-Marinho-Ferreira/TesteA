<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class SoldadorRequalificacao extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_soldador_requalificacao';
    protected static string $dbType = 'intranet';
}
