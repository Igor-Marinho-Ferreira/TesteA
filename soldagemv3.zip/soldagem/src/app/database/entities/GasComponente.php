<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class GasComponente extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_gas_componente';
    protected static string $dbType = 'intranet';
}
