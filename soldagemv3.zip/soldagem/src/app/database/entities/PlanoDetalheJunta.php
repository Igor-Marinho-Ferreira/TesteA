<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PlanoDetalheJunta extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_plano_detalhe_junta';
    protected static string $dbType = 'intranet';
}
