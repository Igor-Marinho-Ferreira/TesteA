<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class EstagioSoldagem extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_estagio_soldagem';
    protected static string $dbType = 'intranet';
}
