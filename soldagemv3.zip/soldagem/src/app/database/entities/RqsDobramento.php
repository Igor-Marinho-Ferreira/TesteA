<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class RqsDobramento extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_rqs_dobramento';
    protected static string $dbType = 'intranet';
}
