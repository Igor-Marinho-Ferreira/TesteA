<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class PlanoEtapaLog extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_plano_etapa_log';
    protected static string $dbType = 'intranet';
}
