<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Cliente extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_cliente';
    protected static string $dbType = 'intranet';
}
