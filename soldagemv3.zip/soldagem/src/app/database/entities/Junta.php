<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Junta extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_junta';
    protected static string $dbType = 'intranet';
}
