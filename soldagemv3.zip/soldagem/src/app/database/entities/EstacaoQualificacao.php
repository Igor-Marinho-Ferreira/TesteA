<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class EstacaoQualificacao extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_estacao_qualificacao';
    protected static string $dbType = 'intranet';
}
