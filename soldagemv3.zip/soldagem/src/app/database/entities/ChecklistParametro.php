<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class ChecklistParametro extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_checklist_parametro';
    protected static string $dbType = 'intranet';
}
