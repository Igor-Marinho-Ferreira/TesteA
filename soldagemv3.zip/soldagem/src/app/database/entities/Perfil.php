<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Perfil extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_perfil';
    protected static string $dbType = 'intranet';
}
