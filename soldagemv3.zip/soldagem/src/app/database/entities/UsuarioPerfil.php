<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class UsuarioPerfil extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_usuario_perfil';
    protected static string $dbType = 'intranet';
}
