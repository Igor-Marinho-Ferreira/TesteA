<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class SoldadorTreinamento extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_soldador_treinamento';
    protected static string $dbType = 'intranet';
}
