<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Rqs extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_rqs';
    protected static string $dbType = 'intranet';
}
