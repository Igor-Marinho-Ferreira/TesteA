<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Rascunho extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_rascunho';
    protected static string $dbType = 'intranet';
}
