<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class ModeloVagao extends Querio
{
    protected static string $table  = 'checklist_soldagem.sol_modelo_vagao';
    protected static string $dbType = 'intranet';
}
