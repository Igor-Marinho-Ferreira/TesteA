<?php
use src\app\services\ChecklistService;

$this->layout('templates/base', [
    'webTitle'  => 'Checklist de Soldagem',
    'cardTitle' => 'Formulário de Checklist de Soldagem',
    'backTo'    => route('checklist.index'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('checklist.update') : route('checklist.store');
$parametros = $parametros ?? [];
$v = fn(string $c) => htmlspecialchars((string) ($editing->$c ?? ''));
$selId = fn(string $c, $id) => (int) ($editing->$c ?? 0) === (int) $id ? 'selected' : '';
?>

<form action="<?= $action ?>" method="POST" data-soldador-url="<?= route('checklist.soldador') ?>" data-rascunho="checklist-<?= $isEditing ? htmlspecialchars((string) $editing->uuid) : 'novo' ?>">
    <?php if ($isEditing) { ?>
        <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
    <?php } ?>

    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--blue"><i class="ph ph-clipboard-text"></i> Identificação</div>
        <div class="row g-3">
            <div class="col-12 col-md-3">
                <label class="form-label">Modelo</label>
                <select name="modelo_id" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach ($modelos as $m) { ?><option value="<?= $m->id ?>" <?= $selId('modelo_id', $m->id) ?>><?= htmlspecialchars((string) $m->modelo) ?></option><?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Cliente</label>
                <select name="cliente_id" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach ($clientes as $c) { ?><option value="<?= $c->id ?>" <?= $selId('cliente_id', $c->id) ?>><?= htmlspecialchars((string) $c->cliente) ?></option><?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Nº Viga / Nº Vagão</label>
                <input type="text" name="numero_viga_vagao" class="form-control" value="<?= $v('numero_viga_vagao') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Estágio de Soldagem</label>
                <select name="estagio_id" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach ($estagios as $e) { ?><option value="<?= $e->id ?>" <?= $selId('estagio_id', $e->id) ?>><?= htmlspecialchars((string) $e->estagio) ?></option><?php } ?>
                </select>
            </div>

            <div class="col-12 col-md-3">
                <label class="form-label">Desenho / Revisão</label>
                <input type="text" name="desenho_revisao" class="form-control" value="<?= $v('desenho_revisao') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Metal Base</label>
                <select name="metal_base" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach ($metais as $mb) { ?>
                        <option value="<?= htmlspecialchars((string) $mb->metal_base) ?>" <?= ($editing->metal_base ?? '') === $mb->metal_base ? 'selected' : '' ?>>
                            <?= htmlspecialchars((string) $mb->metal_base) ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label">Matrícula <span class="text-danger">*</span></label>
                <input type="text" name="matricula" id="chk-matricula" class="form-control <?= applyWrong('matricula') ?>" value="<?= $v('matricula') ?>" autocomplete="off" required>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Nome</label>
                <input type="text" name="nome" id="chk-nome" class="form-control" value="<?= $v('nome') ?>">
            </div>

            <div class="col-12 col-md-3">
                <label class="form-label">Sinete</label>
                <input type="text" name="sinete" id="chk-sinete" class="form-control" value="<?= $v('sinete') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Qualificação</label>
                <input type="text" name="qualificacao" id="chk-qualif" class="form-control" value="<?= $v('qualificacao') ?>">
            </div>
            <div class="col-12 col-md-6 d-flex align-items-end">
                <input type="hidden" name="qualificacao_alerta" id="chk-alerta" value="<?= htmlspecialchars((string) ($editing->qualificacao_alerta ?? 'ok')) ?>">
                <div id="chk-alerta-msg" class="w-100"></div>
            </div>
        </div>
    </div>

    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--amber"><i class="ph ph-sliders"></i> Parâmetros controlados (Encontrado × Especificado)</div>
        <div class="table-responsive">
            <table class="table at-table mb-0">
                <thead>
                    <tr><th style="width:34%">Parâmetro</th><th>Encontrado</th><th>Especificado (EPS)</th></tr>
                </thead>
                <tbody>
                    <?php foreach (ChecklistService::PARAMETROS as $chave => $label) {
                        $enc = $parametros[$chave]->encontrado ?? '';
                        $esp = $parametros[$chave]->especificado ?? '';
                        ?>
                        <tr>
                            <td class="fw-medium align-middle"><?= htmlspecialchars($label) ?></td>
                            <td><input type="text" name="encontrado[<?= $chave ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) $enc) ?>"></td>
                            <td><input type="text" name="especificado[<?= $chave ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) $esp) ?>"></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <small class="text-muted d-block mt-2">O status (Aprovado/Reprovado) é calculado automaticamente: divergência entre Encontrado e Especificado reprova.</small>
    </div>

    <div class="at-form-panel mb-4">
        <label class="form-label">Observações</label>
        <textarea name="observacao" class="form-control" rows="3"><?= htmlspecialchars((string) ($editing->observacao ?? '')) ?></textarea>
    </div>

    <div class="at-form-foot">
        <a href="<?= route('checklist.index') ?>" class="btn btn-light">Cancelar</a>
        <button type="button" class="btn btn-outline-secondary" data-salvar-rascunho><i class="ph ph-floppy-disk"></i> Salvar rascunho</button>
        <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar checklist' ?></button>
    </div>
</form>

<script>
(function () {
    var form = document.querySelector('form[data-soldador-url]');
    if (!form) return;
    var url = form.getAttribute('data-soldador-url');
    var mat = document.getElementById('chk-matricula');
    var alertaBox = document.getElementById('chk-alerta-msg');

    function buscar() {
        var m = (mat.value || '').trim();
        if (!m) return;
        fetch(url + '?matricula=' + encodeURIComponent(m))
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (d) {
                if (!d) { alertaBox.innerHTML = '<div class="text-muted small">Soldador não encontrado.</div>'; return; }
                document.getElementById('chk-nome').value = d.nome || '';
                document.getElementById('chk-sinete').value = d.sinete || '';
                document.getElementById('chk-qualif').value = d.qualificacao || '';
                document.getElementById('chk-alerta').value = d.alerta || 'ok';
                if (d.alerta === 'vencida') {
                    alertaBox.innerHTML = '<div class="alert alert-danger py-2 mb-0"><i class="ph ph-warning"></i> Qualificação <strong>vencida</strong>.</div>';
                } else if (d.alerta === 'a_vencer') {
                    alertaBox.innerHTML = '<div class="alert alert-warning py-2 mb-0"><i class="ph ph-warning-circle"></i> Qualificação <strong>a vencer</strong> (&lt; 30 dias).</div>';
                } else {
                    alertaBox.innerHTML = '<div class="text-success small"><i class="ph ph-check-circle"></i> Qualificação em dia.</div>';
                }
            })
            .catch(function () {});
    }
    mat.addEventListener('change', buscar);
    mat.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); buscar(); } });
})();
</script>
