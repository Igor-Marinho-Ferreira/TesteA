<?php
$this->layout('templates/base', [
    'webTitle'  => 'Checklist de Soldagem',
    'cardTitle' => 'Checklist de Verificação do Processo de Soldagem',
    'backTo'    => route('menu'),
]);
?>

<div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
    <a href="<?= route('checklist.create') ?>" class="btn btn-success"><i class="ph ph-plus"></i> Novo checklist</a>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..."
                data-filter-input="#tbl-chk" data-filter-count="#count-chk">
        </div>
        <span id="count-chk" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-chk" class="table table-hover at-table mb-0">
        <thead>
            <tr><th>Data</th><th>Modelo</th><th>Cliente</th><th>Nº Viga/Vagão</th><th>Estágio</th><th>Soldador</th><th>Status</th><th class="text-end">Ações</th></tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="8" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum checklist registrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="8" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td><?= $item->data ? dateAmericanToBrazilian($item->data) : '—' ?></td>
                        <td class="fw-medium"><?= htmlspecialchars((string) ($item->modelo_nome ?: '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->cliente_nome ?: '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->numero_viga_vagao ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->estagio_nome ?: '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->nome ?: $item->matricula)) ?></td>
                        <td>
                            <?php if (($item->status_verificacao ?? '') === 'Aprovado') { ?>
                                <span class="badge-tipo badge-status--ok">Aprovado</span>
                            <?php } elseif (($item->status_verificacao ?? '') === 'Reprovado') { ?>
                                <span class="badge-tipo badge-status--danger">Reprovado</span>
                            <?php } else { ?><span class="at-file-empty">—</span><?php } ?>
                        </td>
                        <td class="text-end at-actions">
                            <a href="<?= route('checklist.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('checklist.destroy') ?>" method="POST" class="d-inline js-confirm-delete"
                                data-confirm-text="Deseja realmente excluir este checklist?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
