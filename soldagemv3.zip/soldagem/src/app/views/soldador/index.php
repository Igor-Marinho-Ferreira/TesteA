<?php
use src\app\services\SoldadorService;

$this->layout('templates/base', [
    'webTitle'  => 'Soldadores',
    'cardTitle' => 'Cadastro de Soldadores',
    'backTo'    => route('menu'),
]);

/** @var \src\app\services\SoldadorService $service */
/** @var \src\app\services\PosicaoQualificacaoService $posService */
$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('soldador.update') : route('soldador.store');
$v = fn(string $c) => htmlspecialchars((string) (old($c) ?? ($editing->$c ?? '')));
$selTrein = $sel['treinamentos'] ?? [];
$selProc  = $sel['processos'] ?? [];
$selPos   = $sel['posicoes'] ?? [];
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-identification-card' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar soldador' : 'Novo soldador' ?></div>
            <div class="at-form-head__subtitle">Nome e cargo podem ser preenchidos após a matrícula (busca no Senior). A data de requalificação é gerada automaticamente (+6 meses da última).</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST" data-rascunho="soldador-<?= $isEditing ? htmlspecialchars((string) $editing->uuid) : 'novo' ?>">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>

        <div class="row g-3">
            <div class="col-12 col-md-3">
                <label class="form-label">Matrícula <span class="text-danger">*</span></label>
                <input type="text" name="matricula" class="form-control <?= applyWrong('matricula') ?>" value="<?= $v('matricula') ?>" required>
            </div>
            <div class="col-12 col-md-5">
                <label class="form-label">Nome do soldador</label>
                <input type="text" name="nome" class="form-control" value="<?= $v('nome') ?>">
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Cargo</label>
                <input type="text" name="cargo" class="form-control" list="cargos" value="<?= $v('cargo') ?>">
                <datalist id="cargos">
                    <?php foreach (SoldadorService::CARGOS as $cg) { ?><option value="<?= htmlspecialchars($cg) ?>"><?php } ?>
                </datalist>
            </div>

            <div class="col-12 col-md-3">
                <label class="form-label">Sinete <span class="text-danger">*</span></label>
                <input type="text" name="sinete" class="form-control <?= applyWrong('sinete') ?>" value="<?= $v('sinete') ?>" required>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Performance</label>
                <select name="performance" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach (SoldadorService::PERFORMANCE as $p) { ?>
                        <option value="<?= $p ?>" <?= ($editing->performance ?? '') === $p ? 'selected' : '' ?>><?= $p ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <?php foreach (SoldadorService::STATUS as $st) { ?>
                        <option value="<?= $st ?>" <?= ($editing->status ?? 'ativo') === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Status da qualificação</label>
                <select name="status_qualificacao" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach (SoldadorService::STATUS_QUALIFICACAO as $sq) { ?>
                        <option value="<?= $sq ?>" <?= ($editing->status_qualificacao ?? '') === $sq ? 'selected' : '' ?>><?= $sq ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="col-12 col-md-3">
                <label class="form-label">Data de qualificação</label>
                <input type="date" name="data_qualificacao" class="form-control" value="<?= $v('data_qualificacao') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Data da última qualificação</label>
                <input type="date" name="data_ultima_qualificacao" class="form-control" value="<?= $v('data_ultima_qualificacao') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Data de requalificação <small class="text-muted">(auto +6 meses)</small></label>
                <input type="date" class="form-control" value="<?= $v('data_requalificacao') ?>" disabled>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Nº registro de requalificação</label>
                <input type="text" class="form-control" value="<?= $v('numero_registro_requalificacao') ?>" disabled>
            </div>
        </div>

        <hr class="my-4">

        <div class="row g-4">
            <div class="col-12 col-md-4">
                <label class="form-label fw-bold">Treinamentos</label>
                <div class="d-flex flex-column gap-1">
                    <?php foreach ($treinamentos as $t) { ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="treinamentos[]" value="<?= $t->id ?>"
                                id="trein<?= $t->id ?>" <?= in_array((int) $t->id, $selTrein, true) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="trein<?= $t->id ?>"><?= htmlspecialchars((string) $t->treinamento) ?></label>
                        </div>
                    <?php } ?>
                    <?php if (empty($treinamentos)) { ?><small class="text-muted">Nenhum treinamento cadastrado.</small><?php } ?>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label fw-bold">Processo de soldagem (qualificação)</label>
                <div class="d-flex flex-column gap-1">
                    <?php foreach ($qualificacoes as $q) { ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="processos[]" value="<?= $q->id ?>"
                                id="proc<?= $q->id ?>" <?= in_array((int) $q->id, $selProc, true) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="proc<?= $q->id ?>"><?= htmlspecialchars((string) $q->qualificacao) ?></label>
                        </div>
                    <?php } ?>
                    <?php if (empty($qualificacoes)) { ?><small class="text-muted">Nenhuma qualificação cadastrada.</small><?php } ?>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label fw-bold">Posições</label>
                <div class="d-flex flex-column gap-1">
                    <?php foreach ($posicoes as $p) { ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="posicoes[]" value="<?= $p->id ?>"
                                id="pos<?= $p->id ?>" <?= in_array((int) $p->id, $selPos, true) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="pos<?= $p->id ?>"><?= htmlspecialchars($posService->label($p)) ?></label>
                        </div>
                    <?php } ?>
                    <?php if (empty($posicoes)) { ?><small class="text-muted">Nenhuma posição cadastrada.</small><?php } ?>
                </div>
            </div>
        </div>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('soldador.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="button" class="btn btn-outline-secondary" data-salvar-rascunho><i class="ph ph-floppy-disk"></i> Salvar rascunho</button>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Soldadores cadastrados</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar por nome, matrícula, status..."
                data-filter-input="#tbl-sold" data-filter-count="#count-sold">
        </div>
        <span id="count-sold" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-sold" class="table table-hover at-table mb-0">
        <thead>
            <tr><th>Matrícula</th><th>Nome</th><th>Cargo</th><th>Sinete</th><th>Status</th><th>Requalificação</th><th class="text-end">Ações</th></tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="7" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum soldador cadastrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="7" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) {
                    $dias = $service->diasParaVencer($item->data_requalificacao ?? null);
                    $cor  = $service->corVencimento($dias);
                    ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->matricula) ?></td>
                        <td><?= htmlspecialchars((string) ($item->nome ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->cargo ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) $item->sinete) ?></td>
                        <td>
                            <span class="badge-tipo <?= ($item->status ?? 'ativo') === 'ativo' ? 'badge-status--ok' : 'badge-status--muted' ?>">
                                <?= htmlspecialchars(ucfirst((string) ($item->status ?? 'ativo'))) ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($item->data_requalificacao) { ?>
                                <span class="badge-tipo badge-status--<?= $cor ?>">
                                    <?= dateAmericanToBrazilian($item->data_requalificacao) ?>
                                    <?php if ($dias !== null) { ?> · <?= $dias < 0 ? 'vencida' : $dias . 'd' ?><?php } ?>
                                </span>
                            <?php } else { ?>—<?php } ?>
                        </td>
                        <td class="text-end at-actions">
                            <a href="<?= route('soldador.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('soldador.destroy') ?>" method="POST" class="d-inline js-confirm-delete"
                                data-confirm-text="Deseja realmente excluir o soldador '<?= htmlspecialchars((string) ($item->nome ?: $item->matricula)) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
