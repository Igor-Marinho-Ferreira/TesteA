<?php
use src\app\services\RqsService;

$this->layout('templates/base', [
    'webTitle'  => 'RQS',
    'cardTitle' => 'Registro de Qualificação de Soldador (RQS)',
    'backTo'    => route('rqs.index'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('rqs.update') : route('rqs.store');
$usado = $usado ?? [];
$faixa = $faixa ?? [];
$dobramento = $dobramento ?? [];
$v = fn(string $c, $def = '') => htmlspecialchars((string) ($editing->$c ?? $def));
?>

<form action="<?= $action ?>" method="POST" data-rascunho="rqs-<?= $isEditing ? htmlspecialchars((string) $editing->uuid) : 'novo' ?>">
    <?php if ($isEditing) { ?><input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>"><?php } ?>

    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--blue"><i class="ph ph-certificate"></i> Registro — Certificado nº <span class="text-success"><?= htmlspecialchars((string) $proximo) ?></span></div>
        <div class="row g-3">
            <div class="col-12 col-md-4">
                <label class="form-label">Soldador <span class="text-danger">*</span></label>
                <select name="soldador_id" class="form-select" required>
                    <option value="">Selecione...</option>
                    <?php foreach ($soldadores as $s) { ?>
                        <option value="<?= $s->id ?>" <?= (int) ($editing->soldador_id ?? 0) === (int) $s->id ? 'selected' : '' ?>>
                            <?= htmlspecialchars((string) ($s->nome ?: $s->matricula)) ?> — <?= htmlspecialchars((string) $s->sinete) ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">EPS / WPS</label>
                <select name="eps_id" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach ($epsList as $e) { ?>
                        <option value="<?= $e->id ?>" <?= (int) ($editing->eps_id ?? 0) === (int) $e->id ? 'selected' : '' ?>><?= htmlspecialchars((string) $e->numero_documento) ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3"><label class="form-label">Processo de Soldagem</label><input type="text" name="processo_soldagem" id="rqs-processo" class="form-control" value="<?= $v('processo_soldagem') ?>"></div>
            <div class="col-6 col-md-2"><label class="form-label">Tipo</label><input type="text" name="tipo" class="form-control" value="<?= $v('tipo') ?>" placeholder="Semi-automático"></div>
            <div class="col-6 col-md-3"><label class="form-label">Data do Teste</label><input type="date" name="data_teste" class="form-control" value="<?= $v('data_teste') ?>"></div>
        </div>
    </div>

    <!-- Montagem a partir do Formulário de Qualificação -->
    <?php if (!empty($montagem)) { ?>
    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--green"><i class="ph ph-puzzle-piece"></i> Montar a partir de um Formulário de Qualificação</div>
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-6">
                <label class="form-label">Formulário de Qualificação</label>
                <select id="rqs-montagem" class="form-select">
                    <option value="">Selecione para pré-preencher…</option>
                    <?php foreach ($montagem as $m) { ?>
                        <option value="<?= $m['id'] ?>"
                            data-processo="<?= htmlspecialchars($m['processo']) ?>"
                            data-desc="<?= htmlspecialchars($m['descricao']) ?>"
                            data-posicoes="<?= htmlspecialchars($m['posicoes']) ?>">
                            <?= htmlspecialchars($m['processo']) ?><?= $m['descricao'] ? ' — ' . htmlspecialchars($m['descricao']) : '' ?>
                        </option>
                    <?php } ?>
                </select>
                <small class="text-muted">Traz o processo e as posições cadastrados; você complementa os campos em amarelo.</small>
            </div>
            <div class="col-12 col-md-6">
                <div id="rqs-montagem-info" class="text-muted small"></div>
            </div>
        </div>
    </div>
    <?php } ?>

    <!-- Variáveis para cada processo -->
    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--violet"><i class="ph ph-list"></i> Variáveis para cada processo</div>
        <div class="table-responsive">
            <table class="table at-table mb-0">
                <thead><tr><th style="width:34%">Variável</th><th>Usado no teste</th><th>Faixa de qualificação</th></tr></thead>
                <tbody>
                    <?php foreach (RqsService::VARIAVEIS as $k => $label) { ?>
                        <tr>
                            <td class="fw-medium align-middle"><?= htmlspecialchars($label) ?></td>
                            <td><input type="text" name="usado[<?= $k ?>]" id="usado-<?= $k ?>" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($usado[$k] ?? '')) ?>"></td>
                            <td><input type="text" name="faixa[<?= $k ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($faixa[$k] ?? '')) ?>"></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Exame visual -->
    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--green"><i class="ph ph-eye"></i> Exame visual</div>
        <div class="row g-3">
            <div class="col-12 col-md-3">
                <label class="form-label">Aceitável?</label>
                <select name="exame_visual_aceitavel" class="form-select">
                    <option value="">—</option>
                    <option value="Sim" <?= ($editing->exame_visual_aceitavel ?? '') === 'Sim' ? 'selected' : '' ?>>Sim</option>
                    <option value="Não" <?= ($editing->exame_visual_aceitavel ?? '') === 'Não' ? 'selected' : '' ?>>Não</option>
                </select>
            </div>
            <div class="col-12 col-md-6"><label class="form-label">Examinado por</label><input type="text" name="examinado_por" class="form-control" value="<?= $v('examinado_por') ?>"></div>
            <div class="col-12 col-md-3"><label class="form-label">Data</label><input type="date" name="examinado_data" class="form-control" value="<?= $v('examinado_data') ?>"></div>
        </div>
    </div>

    <!-- Ensaio de dobramento guiado -->
    <div class="at-form-panel mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div class="at-form-title at-accent--amber mb-0"><i class="ph ph-arrows-in-line-vertical"></i> Ensaio de dobramento guiado</div>
            <button type="button" class="btn btn-sm btn-outline-secondary" data-add-row="#dob-rows"><i class="ph ph-plus"></i> Adicionar</button>
        </div>
        <div class="table-responsive mt-2">
            <table class="table at-table mb-0">
                <thead><tr><th>Seção</th><th>Amostra</th><th>Tipo</th><th>Resultado</th><th>Tempo</th><th>Temperatura</th><th></th></tr></thead>
                <tbody id="dob-rows">
                    <?php $rows = $dobramento ?: [null]; foreach ($rows as $r) { ?>
                        <tr>
                            <td>
                                <select name="dob_secao[]" class="form-select form-select-sm">
                                    <option value=""></option>
                                    <?php foreach (RqsService::TIPO_SECAO as $sec) { ?><option value="<?= $sec ?>" <?= ($r->secao ?? '') === $sec ? 'selected' : '' ?>><?= ucfirst($sec) ?></option><?php } ?>
                                </select>
                            </td>
                            <td><input type="text" name="dob_amostra[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->amostra ?? '')) ?>"></td>
                            <td>
                                <select name="dob_tipo[]" class="form-select form-select-sm">
                                    <option value=""></option>
                                    <?php foreach (RqsService::TIPO_DOBRAMENTO as $t) { ?><option value="<?= $t ?>" <?= ($r->tipo ?? '') === $t ? 'selected' : '' ?>><?= $t ?></option><?php } ?>
                                </select>
                            </td>
                            <td>
                                <select name="dob_resultado[]" class="form-select form-select-sm">
                                    <option value=""></option>
                                    <?php foreach (RqsService::RESULTADO as $rz) { ?><option value="<?= $rz ?>" <?= ($r->resultado ?? '') === $rz ? 'selected' : '' ?>><?= $rz ?></option><?php } ?>
                                </select>
                            </td>
                            <td><input type="text" name="dob_tempo[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->tempo ?? '')) ?>"></td>
                            <td><input type="text" name="dob_temp[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->temperatura ?? '')) ?>"></td>
                            <td><button type="button" class="btn btn-sm btn-outline-danger" data-del-row><i class="ph ph-x"></i></button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Solda em ângulo + testes -->
    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--slate"><i class="ph ph-triangle"></i> Solda em ângulo / testes mecânicos</div>
        <div class="row g-3">
            <div class="col-6 col-md-3"><label class="form-label">Macrografia</label><input type="text" name="macrografia" class="form-control" value="<?= $v('macrografia') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Tamanho da perna</label><input type="text" name="tamanho_perna" class="form-control" value="<?= $v('tamanho_perna') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Concavidade/Convexidade</label><input type="text" name="concavidade_convexidade" class="form-control" value="<?= $v('concavidade_convexidade') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Ensaio de fratura</label><input type="text" name="ensaio_fratura" class="form-control" value="<?= $v('ensaio_fratura') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Comprimento defeitos</label><input type="text" name="comprimento_defeitos" class="form-control" value="<?= $v('comprimento_defeitos') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">% defeitos</label><input type="text" name="porcentagem_defeitos" class="form-control" value="<?= $v('porcentagem_defeitos') ?>"></div>
            <div class="col-12 col-md-6"><label class="form-label">Testes mecânicos realizados por</label><input type="text" name="testes_mecanicos_por" class="form-control" value="<?= $v('testes_mecanicos_por') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Relatório nº</label><input type="text" name="relatorio_numero" class="form-control" value="<?= $v('relatorio_numero') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Resultados de radiografia</label><input type="text" name="radiografia_resultado" class="form-control" value="<?= $v('radiografia_resultado') ?>"></div>
            <div class="col-12 col-md-6"><label class="form-label">Interpretada por</label><input type="text" name="radiografia_interpretada_por" class="form-control" value="<?= $v('radiografia_interpretada_por') ?>"></div>
            <div class="col-12 col-md-4"><label class="form-label">Teste de soldagem conduzido por</label><input type="text" name="teste_soldagem_por" class="form-control" value="<?= $v('teste_soldagem_por') ?>"></div>
            <div class="col-6 col-md-2"><label class="form-label">Data</label><input type="date" name="teste_soldagem_data" class="form-control" value="<?= $v('teste_soldagem_data') ?>"></div>
        </div>
        <small class="text-muted d-block mt-2">Companhia: <?= htmlspecialchars(RqsService::COMPANHIA) ?> · Aprovação pela Engenharia de Processos.</small>
    </div>

    <div class="at-form-foot">
        <a href="<?= route('rqs.index') ?>" class="btn btn-light">Cancelar</a>
        <button type="button" class="btn btn-outline-secondary" data-salvar-rascunho><i class="ph ph-floppy-disk"></i> Salvar rascunho</button>
        <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar RQS' ?></button>
    </div>
</form>

<script>
(function () {
    document.querySelectorAll('[data-add-row]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var tbody = document.querySelector(btn.getAttribute('data-add-row'));
            if (!tbody || !tbody.rows.length) return;
            var novo = tbody.rows[0].cloneNode(true);
            novo.querySelectorAll('input').forEach(function (i) { i.value = ''; });
            novo.querySelectorAll('select').forEach(function (s) { s.selectedIndex = 0; });
            tbody.appendChild(novo);
        });
    });
    document.addEventListener('click', function (e) {
        var b = e.target.closest('[data-del-row]');
        if (!b) return;
        var tr = b.closest('tr'), tbody = tr.parentNode;
        if (tbody.rows.length > 1) tr.remove();
    });

    // Montagem a partir do Formulário de Qualificação
    var mont = document.getElementById('rqs-montagem');
    if (mont) {
        mont.addEventListener('change', function () {
            var opt = mont.options[mont.selectedIndex];
            if (!opt || !opt.value) return;
            var processo = opt.getAttribute('data-processo') || '';
            var posicoes = opt.getAttribute('data-posicoes') || '';
            var desc = opt.getAttribute('data-desc') || '';

            var pProc = document.getElementById('rqs-processo');
            if (pProc && processo) pProc.value = processo;

            var pPos = document.getElementById('usado-posicao_soldagem');
            if (pPos && posicoes) pPos.value = posicoes;

            var info = document.getElementById('rqs-montagem-info');
            if (info) {
                info.innerHTML = '<i class="ph ph-check-circle text-success"></i> Processo <strong>' + processo + '</strong>'
                    + (desc ? ' (' + desc + ')' : '')
                    + (posicoes ? ' · Posições: ' + posicoes : '');
            }
        });
    }
})();
</script>
