<?php
$this->layout('templates/base', [
    'webTitle'  => 'RQS',
    'cardTitle' => 'Registro de Qualificação de Soldadores (RQS)',
    'backTo'    => route('menu'),
]);
?>

<div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
    <a href="<?= route('rqs.create') ?>" class="btn btn-success"><i class="ph ph-plus"></i> Novo RQS</a>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..." data-filter-input="#tbl-rqs" data-filter-count="#count-rqs">
        </div>
        <span id="count-rqs" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-rqs" class="table table-hover at-table mb-0">
        <thead><tr><th>Certificado</th><th>Soldador</th><th>Processo</th><th>Data Teste</th><th>Etapa</th><th>Status</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="7" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum RQS registrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="7" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) {
                    $etapaCor = $item->etapa === 'engenharia' ? 'warn' : 'muted';
                    ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->certificado_numero) ?></td>
                        <td><?= htmlspecialchars((string) $item->soldador_nome) ?></td>
                        <td><?= htmlspecialchars((string) ($item->processo_soldagem ?? '—')) ?></td>
                        <td><?= $item->data_teste ? dateAmericanToBrazilian($item->data_teste) : '—' ?></td>
                        <td><span class="badge-tipo badge-status--<?= $etapaCor ?>"><?= $item->etapa === 'engenharia' ? 'Engenharia' : 'Escola' ?></span></td>
                        <td>
                            <?php if ($item->status === 'aprovado') { ?><span class="badge-tipo badge-status--ok">Aprovado</span>
                            <?php } else { ?><span class="badge-tipo badge-status--muted">Em andamento</span><?php } ?>
                        </td>
                        <td class="text-end at-actions">
                            <a href="<?= route('rqs.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <?php if ($item->etapa === 'escola') { ?>
                                <a href="<?= route('rqs.enviar', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-warning" title="Enviar para Engenharia"><i class="ph ph-paper-plane-tilt"></i></a>
                            <?php } elseif ($item->etapa === 'engenharia' && $item->status !== 'aprovado') { ?>
                                <a href="<?= route('rqs.aprovar', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-success" title="Aprovar"><i class="ph ph-seal-check"></i></a>
                            <?php } ?>
                            <form action="<?= route('rqs.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Excluir o RQS '<?= htmlspecialchars((string) $item->certificado_numero) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
