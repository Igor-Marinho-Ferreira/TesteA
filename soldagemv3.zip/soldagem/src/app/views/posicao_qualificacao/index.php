<?php
use src\app\services\PosicaoQualificacaoService;

$this->layout('templates/base', [
    'webTitle'  => 'Posição de Qualificação',
    'cardTitle' => 'Cadastro de Posição de Qualificação (Ângulo/Topo)',
    'backTo'    => route('menu'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('posicao_qualificacao.update') : route('posicao_qualificacao.store');
$svc       = $service; // instância passada pelo controller (label + constantes)

$tipoSel   = old('tipo') ?? ($editing->tipo ?? '');
$posSel    = old('posicao') ?? ($editing->posicao ?? '');
$progSel   = old('progressao') ?? ($editing->progressao ?? '');
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-arrows-out-cardinal' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar posição' : 'Nova posição de qualificação' ?></div>
            <div class="at-form-head__subtitle">O tipo define a classificação (1G, 2G…). Progressão só se aplica à posição Vertical.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-3">
                <label class="form-label">Tipo <span class="text-danger">*</span></label>
                <select name="tipo" class="form-select <?= applyWrong('tipo') ?>" required>
                    <option value="" disabled <?= $tipoSel === '' ? 'selected' : '' ?>>Selecione...</option>
                    <?php foreach (PosicaoQualificacaoService::TIPOS as $t) { ?>
                        <option value="<?= $t ?>" <?= $tipoSel === $t ? 'selected' : '' ?>><?= $t ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Posição <span class="text-danger">*</span></label>
                <select name="posicao" id="pos-sel" class="form-select <?= applyWrong('posicao') ?>" required
                    onchange="document.getElementById('prog-wrap').style.display=this.value==='Vertical'?'block':'none'">
                    <option value="" disabled <?= $posSel === '' ? 'selected' : '' ?>>Selecione...</option>
                    <?php foreach (PosicaoQualificacaoService::POSICOES as $p) { ?>
                        <option value="<?= htmlspecialchars($p) ?>" <?= $posSel === $p ? 'selected' : '' ?>><?= htmlspecialchars($p) ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-4" id="prog-wrap" style="display:<?= $posSel === 'Vertical' ? 'block' : 'none' ?>;">
                <label class="form-label">Progressão de Soldagem</label>
                <select name="progressao" class="form-select">
                    <option value="">Sem progressão</option>
                    <?php foreach (PosicaoQualificacaoService::PROGRESSOES as $pr) { ?>
                        <option value="<?= $pr ?>" <?= $progSel === $pr ? 'selected' : '' ?>><?= $pr ?></option>
                    <?php } ?>
                </select>
            </div>
        </div>
        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('posicao_qualificacao.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success">
                <i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?>
            </button>
        </div>
    </form>
</div>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Posições cadastradas</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..."
                data-filter-input="#tbl-pos" data-filter-count="#count-pos">
        </div>
        <span id="count-pos" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-pos" class="table table-hover at-table mb-0">
        <thead>
            <tr><th>Tipo</th><th>Posição</th><th>Progressão</th><th class="text-end">Ações</th></tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="4" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhuma posição cadastrada ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="4" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->tipo) ?></td>
                        <td><?= htmlspecialchars((string) $item->posicao) ?></td>
                        <td><?= !empty($item->progressao) ? htmlspecialchars((string) $item->progressao) : '—' ?></td>
                        <td class="text-end at-actions">
                            <a href="<?= route('posicao_qualificacao.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('posicao_qualificacao.destroy') ?>" method="POST" class="d-inline js-confirm-delete"
                                data-confirm-text="Deseja realmente excluir esta posição?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
