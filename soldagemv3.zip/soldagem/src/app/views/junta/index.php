<?php
$this->layout('templates/base', [
    'webTitle'  => 'Juntas',
    'cardTitle' => 'Cadastro de Juntas',
    'backTo'    => route('menu'),
]);

$editing    = $editing ?? null;
$isEditing  = (bool) $editing;
$action     = $isEditing ? route('junta.update') : route('junta.store');
$podeEditar = \src\app\services\PermissaoService::podeEditar('junta');
?>

<?php if ($podeEditar) { ?>
<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-git-merge' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar junta' : 'Nova junta' ?></div>
            <div class="at-form-head__subtitle">A junta é sempre salva em MAIÚSCULAS. Ex.: J01, J02.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-3">
                <label class="form-label">Junta <span class="text-danger">*</span></label>
                <input type="text" name="junta" class="form-control text-uppercase <?= applyWrong('junta') ?>"
                    value="<?= htmlspecialchars((string) (old('junta') ?? ($editing->junta ?? ''))) ?>"
                    autocomplete="off" placeholder="Ex.: J01" style="text-transform:uppercase" required>
                <div class="invalid-feedback"><?= applyWrongText('junta') ?></div>
            </div>
            <div class="col-12 col-md-7">
                <label class="form-label">Descrição</label>
                <input type="text" name="descricao" class="form-control text-uppercase"
                    value="<?= htmlspecialchars((string) (old('descricao') ?? ($editing->descricao ?? ''))) ?>"
                    autocomplete="off" placeholder="Descrição da junta (opcional)" style="text-transform:uppercase">
            </div>
        </div>
        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('junta.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>
<?php } ?>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Juntas cadastradas</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..." data-filter-input="#tbl-junta" data-filter-count="#count-junta">
        </div>
        <span id="count-junta" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-junta" class="table table-hover at-table mb-0">
        <thead><tr><th>Junta</th><th>Descrição</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="3" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhuma junta cadastrada ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="3" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->junta) ?></td>
                        <td><?= htmlspecialchars((string) ($item->descricao ?? '—')) ?: '—' ?></td>
                        <td class="text-end at-actions">
                            <?php if ($podeEditar) { ?>
                            <a href="<?= route('junta.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('junta.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Deseja realmente excluir a junta '<?= htmlspecialchars((string) $item->junta) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                            <?php } else { ?><span class="text-muted small">—</span><?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
