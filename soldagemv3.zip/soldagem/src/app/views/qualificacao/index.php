<?php
$this->layout('templates/base', [
    'webTitle'  => 'Qualificação',
    'cardTitle' => 'Cadastro de Qualificação',
    'backTo'    => route('menu'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('qualificacao.update') : route('qualificacao.store');
$regra     = (bool) (old('regra_especial') ?? ($editing->regra_especial ?? false));
$modo      = old('modo_transferencia') ?? ($editing->modo_transferencia ?? 'CURTO-CIRCUITO');
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-medal' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar qualificação' : 'Nova qualificação' ?></div>
            <div class="at-form-head__subtitle">Processo de soldagem AWS. Ex.: GMAW — Gas Metal Arc Welding.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-3">
                <label class="form-label">Qualificação <span class="text-danger">*</span></label>
                <input type="text" name="qualificacao" class="form-control <?= applyWrong('qualificacao') ?>"
                    value="<?= htmlspecialchars((string) (old('qualificacao') ?? ($editing->qualificacao ?? ''))) ?>"
                    autocomplete="off" placeholder="Ex.: GMAW" required>
                <div class="invalid-feedback"><?= applyWrongText('qualificacao') ?></div>
            </div>
            <div class="col-12 col-md-6">
                <label class="form-label">Descrição <span class="text-danger">*</span></label>
                <input type="text" name="descricao" class="form-control <?= applyWrong('descricao') ?>"
                    value="<?= htmlspecialchars((string) (old('descricao') ?? ($editing->descricao ?? ''))) ?>"
                    autocomplete="off" placeholder="Ex.: Gas Metal Arc Welding" required>
                <div class="invalid-feedback"><?= applyWrongText('descricao') ?></div>
            </div>
            <div class="col-12 col-md-3">
                <div class="form-check mt-2">
                    <input class="form-check-input" type="checkbox" name="regra_especial" id="regra_especial"
                        value="1" <?= $regra ? 'checked' : '' ?> onchange="document.getElementById('modo-wrap').style.display=this.checked?'block':'none'">
                    <label class="form-check-label" for="regra_especial">Regra especial</label>
                </div>
            </div>
        </div>

        <div class="row g-3 mt-1" id="modo-wrap" style="display:<?= $regra ? 'block' : 'none' ?>;">
            <div class="col-12 col-md-4">
                <label class="form-label">Modo de Transferência</label>
                <input type="text" name="modo_transferencia" class="form-control"
                    value="<?= htmlspecialchars((string) $modo) ?>" placeholder="CURTO-CIRCUITO">
                <small class="text-muted">Valor padrão: CURTO-CIRCUITO.</small>
            </div>
        </div>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('qualificacao.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success">
                <i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?>
            </button>
        </div>
    </form>
</div>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Qualificações cadastradas</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..."
                data-filter-input="#tbl-qualif" data-filter-count="#count-qualif">
        </div>
        <span id="count-qualif" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-qualif" class="table table-hover at-table mb-0">
        <thead>
            <tr><th>Qualificação</th><th>Descrição</th><th>Regra especial</th><th class="text-end">Ações</th></tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="4" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhuma qualificação cadastrada ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="4" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->qualificacao) ?></td>
                        <td><?= htmlspecialchars((string) ($item->descricao ?? '—')) ?></td>
                        <td>
                            <?php if ($item->regra_especial) { ?>
                                <span class="badge-tipo badge-status--warn"><?= htmlspecialchars((string) $item->modo_transferencia) ?></span>
                            <?php } else { ?><span class="at-file-empty">—</span><?php } ?>
                        </td>
                        <td class="text-end at-actions">
                            <a href="<?= route('qualificacao.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('qualificacao.destroy') ?>" method="POST" class="d-inline js-confirm-delete"
                                data-confirm-text="Deseja realmente excluir a qualificação '<?= htmlspecialchars((string) $item->qualificacao) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
