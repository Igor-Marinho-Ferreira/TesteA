<?php $this->layout('templates/base', [
    'webTitle'  => 'Modelos de Vagão',
    'cardTitle' => 'Cadastro de Modelo do Vagão',
    'backTo'    => route('menu'),
]) ?>

<?= $this->insert('partials/cadastro_simples', [
    'mod'         => 'modelo_vagao',
    'campo'       => 'modelo',
    'label'       => 'Modelo',
    'singular'    => 'modelo',
    'icon'        => 'ph-train',
    'placeholder' => 'Ex.: HOPPER',
    'itens'       => $itens,
    'editing'     => $editing ?? null,
]) ?>
