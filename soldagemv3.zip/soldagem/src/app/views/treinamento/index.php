<?php $this->layout('templates/base', [
    'webTitle'  => 'Treinamentos',
    'cardTitle' => 'Cadastro de Treinamentos',
    'backTo'    => route('menu'),
]) ?>

<?= $this->insert('partials/cadastro_simples', [
    'mod'         => 'treinamento',
    'campo'       => 'treinamento',
    'label'       => 'Treinamento',
    'singular'    => 'treinamento',
    'icon'        => 'ph-certificate',
    'placeholder' => 'Ex.: AWS D15.1',
    'itens'       => $itens,
    'editing'     => $editing ?? null,
]) ?>
