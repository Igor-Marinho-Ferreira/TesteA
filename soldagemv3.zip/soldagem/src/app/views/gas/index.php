<?php
$this->layout('templates/base', [
    'webTitle'  => 'Gás',
    'cardTitle' => 'Cadastro de Gás',
    'backTo'    => route('menu'),
]);

$editing     = $editing ?? null;
$isEditing   = (bool) $editing;
$action      = $isEditing ? route('gas.update') : route('gas.store');
$componentes = $componentes ?? [];
$podeEditar  = \src\app\services\PermissaoService::podeEditar('gas');
?>

<?php if ($podeEditar) { ?>
<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-wind' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar gás' : 'Novo gás' ?></div>
            <div class="at-form-head__subtitle">Um gás pode ter uma ou mais composições. Ex.: Argônio 80% + CO₂ 20%.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3">
            <div class="col-12 col-md-5">
                <label class="form-label">Gás <span class="text-danger">*</span></label>
                <input type="text" name="gas" class="form-control <?= applyWrong('gas') ?>"
                    value="<?= htmlspecialchars((string) (old('gas') ?? ($editing->gas ?? ''))) ?>"
                    autocomplete="off" placeholder="Ex.: Argônio / Mistura Ar+CO₂" required>
                <div class="invalid-feedback"><?= applyWrongText('gas') ?></div>
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-3">
            <label class="form-label fw-bold mb-0">Composições</label>
            <button type="button" class="btn btn-sm btn-outline-secondary" data-add-row="#gas-rows"><i class="ph ph-plus"></i> Adicionar</button>
        </div>
        <div class="table-responsive mt-2">
            <table class="table at-table mb-0">
                <thead><tr><th>Composição</th><th style="width:180px">Percentual (%)</th><th style="width:60px"></th></tr></thead>
                <tbody id="gas-rows">
                    <?php $rows = $componentes ?: [null]; foreach ($rows as $c) { ?>
                        <tr>
                            <td><input type="text" name="composicao[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($c->composicao ?? '')) ?>" placeholder="Ex.: Argônio"></td>
                            <td><input type="number" step="0.01" name="percentual[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($c->percentual ?? '')) ?>" placeholder="Ex.: 80"></td>
                            <td><button type="button" class="btn btn-sm btn-outline-danger" data-del-row><i class="ph ph-x"></i></button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('gas.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>
<?php } ?>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Gases cadastrados</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..." data-filter-input="#tbl-gas" data-filter-count="#count-gas">
        </div>
        <span id="count-gas" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-gas" class="table table-hover at-table mb-0">
        <thead><tr><th>Gás</th><th>Composições</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="3" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum gás cadastrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="3" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->gas) ?></td>
                        <td><?= htmlspecialchars((string) ($item->resumo ?: '—')) ?></td>
                        <td class="text-end at-actions">
                            <?php if ($podeEditar) { ?>
                            <a href="<?= route('gas.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('gas.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Deseja realmente excluir o gás '<?= htmlspecialchars((string) $item->gas) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                            <?php } else { ?><span class="text-muted small">—</span><?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>

<script>
(function () {
    document.querySelectorAll('[data-add-row]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var tbody = document.querySelector(btn.getAttribute('data-add-row'));
            if (!tbody || !tbody.rows.length) return;
            var novo = tbody.rows[0].cloneNode(true);
            novo.querySelectorAll('input').forEach(function (i) { i.value = ''; });
            tbody.appendChild(novo);
        });
    });
    document.addEventListener('click', function (e) {
        var b = e.target.closest('[data-del-row]');
        if (!b) return;
        var tr = b.closest('tr'), tbody = tr.parentNode;
        if (tbody.rows.length > 1) tr.remove();
        else tr.querySelectorAll('input').forEach(function (i) { i.value = ''; });
    });
})();
</script>
