<?php
use src\app\services\PlanoResponsavelService;

$this->layout('templates/base', [
    'webTitle'  => 'Responsáveis do Plano',
    'cardTitle' => 'Responsáveis pelo Formulário de Registro do Plano de Soldagem',
    'backTo'    => route('menu'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('plano_responsavel.update') : route('plano_responsavel.store');
$v = fn(string $c) => htmlspecialchars((string) (old($c) ?? ($editing->$c ?? '')));
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-users-three' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar responsável' : 'Novo responsável' ?></div>
            <div class="at-form-head__subtitle">Define quem conduz cada etapa (Elaborado, Verificado, Aprovado) do fluxo do Plano de Soldagem.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3">
            <div class="col-12 col-md-3">
                <label class="form-label">Etapa <span class="text-danger">*</span></label>
                <select name="etapa" class="form-select" required>
                    <option value="">Selecione...</option>
                    <?php foreach (PlanoResponsavelService::ETAPAS as $k => $lbl) { ?>
                        <option value="<?= $k ?>" <?= ($editing->etapa ?? '') === $k ? 'selected' : '' ?>><?= $lbl ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-5">
                <label class="form-label">Nome do Responsável <span class="text-danger">*</span></label>
                <input type="text" name="nome_responsavel" class="form-control <?= applyWrong('nome_responsavel') ?>" value="<?= $v('nome_responsavel') ?>" required>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Matrícula</label>
                <input type="text" name="matricula" class="form-control" value="<?= $v('matricula') ?>">
            </div>
            <div class="col-12 col-md-6">
                <label class="form-label">Cargo / Função</label>
                <input type="text" name="cargo" class="form-control" value="<?= $v('cargo') ?>">
            </div>
            <div class="col-12 col-md-6">
                <label class="form-label">Departamento / Área</label>
                <input type="text" name="departamento" class="form-control" value="<?= $v('departamento') ?>">
            </div>
        </div>
        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('plano_responsavel.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-hover at-table mb-0">
        <thead><tr><th>Etapa</th><th>Nome</th><th>Matrícula</th><th>Cargo</th><th>Departamento</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="6" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum responsável cadastrado ainda.</td></tr>
            <?php } else { ?>
                <?php foreach ($itens as $item) { ?>
                    <tr>
                        <td><span class="badge-tipo badge-status--muted"><?= htmlspecialchars(PlanoResponsavelService::ETAPAS[$item->etapa] ?? $item->etapa) ?></span></td>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->nome_responsavel) ?></td>
                        <td><?= htmlspecialchars((string) ($item->matricula ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->cargo ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->departamento ?? '—')) ?></td>
                        <td class="text-end at-actions">
                            <a href="<?= route('plano_responsavel.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('plano_responsavel.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Excluir este responsável?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
