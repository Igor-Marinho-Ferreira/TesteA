<?php
use src\app\controllers\RelatorioController;

$this->layout('templates/base', [
    'webTitle'  => 'Relatório de Qualificação',
    'cardTitle' => 'Relatório de Qualificação de Soldadores',
    'backTo'    => route('menu'),
]);

/** @var \src\app\services\SoldadorService $service */
$filtro = $filtro ?? 'todos';
?>

<form method="GET" class="row g-2 align-items-end mb-3">
    <div class="col-12 col-md-5">
        <label class="form-label">Filtro</label>
        <select name="filtro" class="form-select" onchange="this.form.submit()">
            <?php foreach (RelatorioController::FILTROS as $k => $lbl) { ?>
                <option value="<?= $k ?>" <?= $filtro === $k ? 'selected' : '' ?>><?= htmlspecialchars($lbl) ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="col-12 col-md-7 text-end">
        <span class="badge rounded-pill text-bg-light border me-2"><?= count($itens) ?> registro(s)</span>
        <a href="<?= route('relatorio.qualificacao.excel', [], ['filtro' => $filtro]) ?>" class="btn btn-outline-success">
            <i class="ph ph-file-xls"></i> Exportar Excel
        </a>
    </div>
</form>

<div class="d-flex gap-3 mb-2 small text-muted">
    <span><span class="badge-tipo badge-status--danger">&nbsp;</span> &lt; 30 dias / vencida</span>
    <span><span class="badge-tipo badge-status--warn">&nbsp;</span> &lt; 40 dias</span>
    <span><span class="badge-tipo badge-status--ok">&nbsp;</span> &lt; 60 dias</span>
</div>

<div class="table-responsive">
    <table class="table table-hover at-table mb-0">
        <thead>
            <tr>
                <th>Matrícula</th><th>Nome</th><th>Cargo</th><th>Sinete</th><th>Performance</th>
                <th>Qualificação</th><th>Última</th><th>Requalificação</th><th>Status</th><th>Status Qualif.</th><th>Nº Reg.</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="11" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum soldador para o filtro selecionado.</td></tr>
            <?php } else { ?>
                <?php foreach ($itens as $s) {
                    $dias = $service->diasParaVencer($s->data_requalificacao ?? null);
                    $cor  = $service->corVencimento($dias);
                    $bg   = ['danger' => 'table-danger', 'warn' => 'table-warning', 'ok' => 'table-success'][$cor] ?? '';
                    ?>
                    <tr class="<?= $bg ?>">
                        <td class="fw-medium"><?= htmlspecialchars((string) $s->matricula) ?></td>
                        <td><?= htmlspecialchars((string) ($s->nome ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($s->cargo ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) $s->sinete) ?></td>
                        <td><?= htmlspecialchars((string) ($s->performance ?? '—')) ?></td>
                        <td><?= $s->data_qualificacao ? dateAmericanToBrazilian($s->data_qualificacao) : '—' ?></td>
                        <td><?= $s->data_ultima_qualificacao ? dateAmericanToBrazilian($s->data_ultima_qualificacao) : '—' ?></td>
                        <td>
                            <?= $s->data_requalificacao ? dateAmericanToBrazilian($s->data_requalificacao) : '—' ?>
                            <?php if ($dias !== null) { ?><br><small class="text-muted"><?= $dias < 0 ? 'vencida' : $dias . ' dias' ?></small><?php } ?>
                        </td>
                        <td><?= htmlspecialchars(ucfirst((string) ($s->status ?? '—'))) ?></td>
                        <td><?= htmlspecialchars((string) ($s->status_qualificacao ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($s->numero_registro_requalificacao ?? '—')) ?></td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>
