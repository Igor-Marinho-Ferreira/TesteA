<?php
$this->layout('templates/base', [
    'webTitle'  => 'Power BI',
    'cardTitle' => 'Disponibilização de Dados para Power BI',
    'backTo'    => route('menu'),
]);
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head">
        <span class="at-form-head__icon"><i class="ph ph-chart-donut"></i></span>
        <div>
            <div class="at-form-head__title">Datasets disponíveis</div>
            <div class="at-form-head__subtitle">
                Todas as telas disponibilizam informações para o Power BI. O acesso é restrito aos usuários descritos no escopo;
                demais usuários devem solicitar acesso via serviço no Freshservice. Abaixo, exportação dos datasets em Excel.
            </div>
        </div>
    </div>

    <div class="menu-list">
        <?php foreach ($datasets as $key => $label) { ?>
            <a href="<?= route('powerbi.exportar', ['dataset' => $key]) ?>" class="menu-card menu-card--green">
                <span class="menu-card__icon is-green"><i class="ph ph-file-xls"></i></span>
                <span class="menu-card__body">
                    <span class="menu-card__title"><?= htmlspecialchars($label) ?></span>
                    <span class="menu-card__desc">Exportar dataset de <?= htmlspecialchars(mb_strtolower($label)) ?> em Excel.</span>
                </span>
                <span class="menu-card__arrow"><i class="ph ph-download-simple"></i></span>
            </a>
        <?php } ?>
    </div>
</div>
