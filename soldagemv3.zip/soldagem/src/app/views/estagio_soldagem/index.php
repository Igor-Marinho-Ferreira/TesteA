<?php $this->layout('templates/base', [
    'webTitle'  => 'Estágios de Soldagem',
    'cardTitle' => 'Cadastro de Estágio de Soldagem',
    'backTo'    => route('menu'),
]) ?>

<?= $this->insert('partials/cadastro_simples', [
    'mod'         => 'estagio_soldagem',
    'campo'       => 'estagio',
    'label'       => 'Estágio de Soldagem',
    'singular'    => 'estágio',
    'icon'        => 'ph-flow-arrow',
    'placeholder' => 'Ex.: Montagem da Extremidade',
    'itens'       => $itens,
    'editing'     => $editing ?? null,
]) ?>
