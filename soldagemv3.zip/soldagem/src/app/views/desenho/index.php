<?php
$this->layout('templates/base', [
    'webTitle'  => 'Desenhos',
    'cardTitle' => 'Cadastro de Desenho',
    'backTo'    => route('menu'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('desenho.update') : route('desenho.store');
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-image-square' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar desenho' : 'Novo desenho' ?></div>
            <div class="at-form-head__subtitle">A imagem é reutilizada automaticamente no Detalhe da Junta do Plano de Soldagem.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-5">
                <label class="form-label">Número do desenho <span class="text-danger">*</span></label>
                <input type="text" name="numero" class="form-control <?= applyWrong('numero') ?>" value="<?= htmlspecialchars((string) (old('numero') ?? ($editing->numero ?? ''))) ?>" required placeholder="Ex.: 3003-51095-00-2">
            </div>
            <div class="col-12 col-md-5">
                <label class="form-label">Imagem (PNG/JPG/PDF)</label>
                <input type="file" name="imagem" class="form-control" accept=".png,.jpg,.jpeg,.pdf">
                <?php if ($isEditing && !empty($editing->imagem)) { ?>
                    <small class="text-muted">Arquivo atual: <a href="<?= route('arquivo', [], ['f' => $editing->imagem]) ?>" target="_blank">ver</a></small>
                <?php } ?>
            </div>
        </div>
        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('desenho.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Desenhos cadastrados</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..." data-filter-input="#tbl-des" data-filter-count="#count-des">
        </div>
        <span id="count-des" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-des" class="table table-hover at-table mb-0">
        <thead><tr><th>Número</th><th>Imagem</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="3" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum desenho cadastrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="3" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->numero) ?></td>
                        <td><?php if (!empty($item->imagem)) { ?><a class="at-file-link" href="<?= route('arquivo', [], ['f' => $item->imagem]) ?>" target="_blank"><i class="ph ph-paperclip"></i> ver</a><?php } else { ?><span class="at-file-empty">—</span><?php } ?></td>
                        <td class="text-end at-actions">
                            <a href="<?= route('desenho.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('desenho.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Excluir o desenho '<?= htmlspecialchars((string) $item->numero) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
