<?php
use src\app\services\EpsService;

$this->layout('templates/base', [
    'webTitle'  => 'Upload de Informações da EPS',
    'cardTitle' => 'Tela de Upload de Informações da EPS',
    'backTo'    => route('menu'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('eps.update') : route('eps.store');
$v = fn(string $c) => htmlspecialchars((string) (old($c) ?? ($editing->$c ?? '')));
?>

<!-- Upload em lote -->
<div class="at-form-panel mb-4">
    <div class="at-form-head">
        <span class="at-form-head__icon"><i class="ph ph-file-xls"></i></span>
        <div>
            <div class="at-form-head__title">Importar em lote (Excel / CSV)</div>
            <div class="at-form-head__subtitle">
                Formatos: <strong>.xlsx</strong> ou <strong>.csv</strong> (separador <code>;</code>).
                A 1ª linha deve conter o cabeçalho exatamente no layout. Não é permitido duplicar Número Documento/RQPS.
            </div>
        </div>
    </div>
    <form action="<?= route('eps.importar') ?>" method="POST" enctype="multipart/form-data">
        <div class="row g-3 align-items-end">
            <div class="col-12 col-md-8">
                <label class="form-label">Arquivo</label>
                <input type="file" name="arquivo" class="form-control" accept=".xlsx,.csv" required>
            </div>
            <div class="col-12 col-md-4 text-end">
                <button type="submit" class="btn btn-success w-100"><i class="ph ph-upload-simple"></i> Importar</button>
            </div>
        </div>
        <small class="text-muted d-block mt-2">
            Colunas esperadas: <?= htmlspecialchars(implode(' | ', EpsService::COLUNAS)) ?>
        </small>
    </form>
</div>

<!-- Cadastro manual -->
<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-file-plus' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar EPS' : 'Cadastro manual de EPS' ?></div>
            <div class="at-form-head__subtitle">Especificação do Processo de Soldagem.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST" data-rascunho="eps-<?= $isEditing ? htmlspecialchars((string) $editing->uuid) : 'novo' ?>">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3">
            <div class="col-12 col-md-3">
                <label class="form-label">Número Documento <span class="text-danger">*</span></label>
                <input type="text" name="numero_documento" class="form-control <?= applyWrong('numero_documento') ?>" value="<?= $v('numero_documento') ?>" required>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Número RQPS <span class="text-danger">*</span></label>
                <input type="text" name="numero_rqps" class="form-control <?= applyWrong('numero_rqps') ?>" value="<?= $v('numero_rqps') ?>" required>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach (EpsService::STATUS as $s) { ?>
                        <option value="<?= htmlspecialchars($s) ?>" <?= ($editing->status ?? '') === $s ? 'selected' : '' ?>><?= htmlspecialchars($s) ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Código de Soldagem</label>
                <input type="text" name="codigo" class="form-control" value="<?= $v('codigo') ?>">
            </div>
            <?php $juntasSel = $editing ? array_map('trim', explode(',', (string) ($editing->juntas ?? ''))) : []; ?>
            <div class="col-12 col-md-6">
                <label class="form-label">Juntas <small class="text-muted">(segure Ctrl para selecionar mais de uma)</small></label>
                <select name="juntas[]" class="form-select" multiple size="4">
                    <?php foreach (($juntas ?? []) as $jt) { ?>
                        <option value="<?= htmlspecialchars((string) $jt->junta) ?>" <?= in_array($jt->junta, $juntasSel, true) ? 'selected' : '' ?>>
                            <?= htmlspecialchars((string) $jt->junta) ?><?= !empty($jt->descricao) ? ' — ' . htmlspecialchars((string) $jt->descricao) : '' ?>
                        </option>
                    <?php } ?>
                </select>
                <?php if (empty($juntas)) { ?><small class="text-muted">Nenhuma junta cadastrada ainda.</small><?php } ?>
            </div>

            <div class="col-12 col-md-3">
                <label class="form-label">MB (01) / Metal Base</label>
                <input type="text" name="mb01" class="form-control" value="<?= $v('mb01') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">MB (02)</label>
                <input type="text" name="mb02" class="form-control" value="<?= $v('mb02') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Faixa de Espessura [mm]</label>
                <input type="text" name="faixa_espessura" class="form-control" value="<?= $v('faixa_espessura') ?>" placeholder="ex: 3,0 - 16,0">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Tipo de Junta</label>
                <select name="tipo_junta" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach (EpsService::TIPOS_JUNTA as $tj) { ?>
                        <option value="<?= htmlspecialchars($tj) ?>" <?= ($editing->tipo_junta ?? '') === $tj ? 'selected' : '' ?>><?= htmlspecialchars($tj) ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="col-12 col-md-3">
                <label class="form-label">Penetração</label>
                <input type="text" name="penetracao" class="form-control" value="<?= $v('penetracao') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Cobre Junta (Backing)</label>
                <select name="cobre_junta" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach (EpsService::BACKING as $b) { ?>
                        <option value="<?= htmlspecialchars($b) ?>" <?= ($editing->cobre_junta ?? '') === $b ? 'selected' : '' ?>><?= htmlspecialchars($b) ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Processo de Soldagem</label>
                <input type="text" name="processo_soldagem" class="form-control" value="<?= $v('processo_soldagem') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Tipo</label>
                <input type="text" name="tipo" class="form-control" value="<?= $v('tipo') ?>" placeholder="ex: Semi-Automático">
            </div>

            <div class="col-12 col-md-3">
                <label class="form-label">Gás de Proteção</label>
                <input type="text" name="gas_protecao" class="form-control" value="<?= $v('gas_protecao') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Metal de Adição</label>
                <input type="text" name="metal_adicao" class="form-control" value="<?= $v('metal_adicao') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Bitola [mm]</label>
                <input type="text" name="bitola" class="form-control" value="<?= $v('bitola') ?>">
            </div>
            <div class="col-12 col-md-3 d-flex align-items-center">
                <div class="form-check mt-4">
                    <input class="form-check-input" type="checkbox" name="ttat" id="ttat" value="1" <?= !empty($editing->ttat) ? 'checked' : '' ?>>
                    <label class="form-check-label" for="ttat">TTAT</label>
                </div>
            </div>

            <div class="col-12 col-md-3">
                <label class="form-label">Tensão [V]</label>
                <input type="text" name="tensao" class="form-control" value="<?= $v('tensao') ?>" placeholder="ex: 28 - 32">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Corrente [A]</label>
                <input type="text" name="corrente" class="form-control" value="<?= $v('corrente') ?>" placeholder="ex: 170 - 240">
            </div>
        </div>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('eps.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="button" class="btn btn-outline-secondary" data-salvar-rascunho><i class="ph ph-floppy-disk"></i> Salvar rascunho</button>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">EPS cadastradas</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..."
                data-filter-input="#tbl-eps" data-filter-count="#count-eps">
        </div>
        <span id="count-eps" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-eps" class="table table-hover at-table mb-0">
        <thead>
            <tr><th>Nº Documento</th><th>Nº RQPS</th><th>Status</th><th>Código</th><th>Processo</th><th>Tipo Junta</th><th class="text-end">Ações</th></tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="7" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhuma EPS cadastrada ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="7" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->numero_documento) ?></td>
                        <td><?= htmlspecialchars((string) $item->numero_rqps) ?></td>
                        <td><?php if ($item->status) { ?><span class="badge-tipo badge-status--ok"><?= htmlspecialchars((string) $item->status) ?></span><?php } else { ?>—<?php } ?></td>
                        <td><?= htmlspecialchars((string) ($item->codigo ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->processo_soldagem ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->tipo_junta ?? '—')) ?></td>
                        <td class="text-end at-actions">
                            <a href="<?= route('eps.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('eps.destroy') ?>" method="POST" class="d-inline js-confirm-delete"
                                data-confirm-text="Deseja realmente excluir a EPS '<?= htmlspecialchars((string) $item->numero_documento) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
