<?php
$this->layout('templates/base', [
    'webTitle'  => 'Estação MES × Qualificação AWS',
    'cardTitle' => 'Cadastro Estação MES × Qualificação AWS',
    'backTo'    => route('menu'),
]);

/** @var \src\app\services\EstacaoQualificacaoService $service */
/** @var \src\app\services\PosicaoQualificacaoService $posService */
$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('estacao_qualificacao.update') : route('estacao_qualificacao.store');
$v = fn(string $c) => htmlspecialchars((string) (old($c) ?? ($editing->$c ?? '')));
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-link' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar vínculo' : 'Novo vínculo Estação × Qualificação' ?></div>
            <div class="at-form-head__subtitle">Relaciona a estação do MES ao processo de solda (AWS) e à posição exigida — usado na validação de continuidade da certificação.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3">
            <div class="col-12 col-md-4">
                <label class="form-label">Linha de Montagem</label>
                <input type="text" name="linha_montagem" class="form-control" value="<?= $v('linha_montagem') ?>" placeholder="Ex.: LINHA_HTT_RUMO">
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Código da Estação MES <span class="text-danger">*</span></label>
                <input type="text" name="codigo_estacao_mes" class="form-control <?= applyWrong('codigo_estacao_mes') ?>" value="<?= $v('codigo_estacao_mes') ?>" placeholder="Ex.: HTT_RUMO_EST01.1" required>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Descrição da Estação</label>
                <input type="text" name="descricao_estacao" class="form-control" value="<?= $v('descricao_estacao') ?>">
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label">Processo de Solda (AWS) <span class="text-danger">*</span></label>
                <select name="processo_solda_id" class="form-select" data-fill-desc="#estq-desc" data-fill-force required>
                    <option value="">Selecione...</option>
                    <?php foreach ($qualificacoes as $q) { ?>
                        <option value="<?= $q->id ?>" data-desc="<?= htmlspecialchars((string) $q->descricao) ?>" <?= (int) ($editing->processo_solda_id ?? 0) === (int) $q->id ? 'selected' : '' ?>>
                            <?= htmlspecialchars((string) $q->qualificacao) ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Descrição do Processo <small class="text-muted">(auto)</small></label>
                <input type="text" name="descricao_processo" id="estq-desc" class="form-control" value="<?= $v('descricao_processo') ?>" placeholder="Preenchido pelo processo selecionado">
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Posição de Solda <span class="text-danger">*</span></label>
                <select name="posicao_solda_id" class="form-select" required>
                    <option value="">Selecione...</option>
                    <?php foreach ($posicoes as $p) { ?>
                        <option value="<?= $p->id ?>" <?= (int) ($editing->posicao_solda_id ?? 0) === (int) $p->id ? 'selected' : '' ?>>
                            <?= htmlspecialchars($posService->label($p)) ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
        </div>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('estacao_qualificacao.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Vínculos cadastrados</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar por estação, processo, posição..."
                data-filter-input="#tbl-estq" data-filter-count="#count-estq">
        </div>
        <span id="count-estq" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-estq" class="table table-hover at-table mb-0">
        <thead>
            <tr><th>Linha</th><th>Estação</th><th>Descrição</th><th>Processo</th><th>Posição</th><th>Status</th><th class="text-end">Ações</th></tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="7" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum vínculo cadastrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="7" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td><?= htmlspecialchars((string) ($item->linha_montagem ?? '—')) ?></td>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->codigo_estacao_mes) ?></td>
                        <td><?= htmlspecialchars((string) ($item->descricao_estacao ?? '—')) ?></td>
                        <td><?= htmlspecialchars($service->labelProcesso($item->processo_solda_id ? (int) $item->processo_solda_id : null)) ?></td>
                        <td><?= htmlspecialchars($service->labelPosicao($item->posicao_solda_id ? (int) $item->posicao_solda_id : null)) ?></td>
                        <td>
                            <?php if ((int) $item->ativo === 1) { ?>
                                <span class="badge-tipo badge-status--ok">Ativo</span>
                            <?php } else { ?>
                                <span class="badge-tipo badge-status--muted">Inativo</span>
                            <?php } ?>
                        </td>
                        <td class="text-end at-actions">
                            <a href="<?= route('estacao_qualificacao.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <?php if ((int) $item->ativo === 1) { ?>
                                <form action="<?= route('estacao_qualificacao.destroy') ?>" method="POST" class="d-inline js-confirm-delete"
                                    data-confirm-text="Inativar o vínculo da estação '<?= htmlspecialchars((string) $item->codigo_estacao_mes) ?>'?">
                                    <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Inativar"><i class="ph ph-prohibit"></i></button>
                                </form>
                            <?php } else { ?>
                                <a href="<?= route('estacao_qualificacao.ativar', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-success" title="Reativar"><i class="ph ph-check-circle"></i></a>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
