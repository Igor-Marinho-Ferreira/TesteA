<?php
$this->layout('templates/base', [
    'webTitle'  => 'Formulário de Qualificação',
    'cardTitle' => 'Cadastro de Formulário de Qualificação',
    'backTo'    => route('menu'),
]);

/** @var \src\app\services\PosicaoQualificacaoService $posService */
$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('formulario_qualificacao.update') : route('formulario_qualificacao.store');
$selPos    = $selPos ?? [];
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head <?= $isEditing ? 'at-form-head--edit' : '' ?>">
        <span class="at-form-head__icon"><i class="ph <?= $isEditing ? 'ph-pencil-simple' : 'ph-list-checks' ?>"></i></span>
        <div>
            <div class="at-form-head__title"><?= $isEditing ? 'Editar formulário' : 'Novo formulário de qualificação' ?></div>
            <div class="at-form-head__subtitle">Define o catálogo (processo + posições) que alimenta o Registro de Qualificação de Soldadores.</div>
        </div>
    </div>

    <form action="<?= $action ?>" method="POST">
        <?php if ($isEditing) { ?>
            <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
        <?php } ?>
        <div class="row g-3">
            <div class="col-12 col-md-4">
                <label class="form-label">Processo (Qualificação) <span class="text-danger">*</span></label>
                <select name="qualificacao_id" class="form-select" data-fill-desc="#fq-desc" data-fill-force required>
                    <option value="">Selecione...</option>
                    <?php foreach ($qualificacoes as $q) { ?>
                        <option value="<?= $q->id ?>" data-desc="<?= htmlspecialchars((string) $q->descricao) ?>"
                            <?= (int) ($editing->qualificacao_id ?? 0) === (int) $q->id ? 'selected' : '' ?>>
                            <?= htmlspecialchars((string) $q->qualificacao) ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-8">
                <label class="form-label">Descrição</label>
                <input type="text" name="descricao" id="fq-desc" class="form-control" value="<?= htmlspecialchars((string) ($editing->descricao ?? '')) ?>" placeholder="Ex.: Gas Metal Arc Welding">
            </div>
        </div>

        <div class="mt-3">
            <label class="form-label fw-bold">Tipo e posição</label>
            <div class="row g-1">
                <?php foreach ($posicoes as $p) { ?>
                    <div class="col-12 col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="posicoes[]" value="<?= $p->id ?>"
                                id="fpos<?= $p->id ?>" <?= in_array((int) $p->id, $selPos, true) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="fpos<?= $p->id ?>"><?= htmlspecialchars($posService->label($p)) ?></label>
                        </div>
                    </div>
                <?php } ?>
                <?php if (empty($posicoes)) { ?><small class="text-muted">Nenhuma posição cadastrada.</small><?php } ?>
            </div>
        </div>

        <div class="at-form-foot">
            <?php if ($isEditing) { ?><a href="<?= route('formulario_qualificacao.index') ?>" class="btn btn-light">Cancelar</a><?php } ?>
            <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar' ?></button>
        </div>
    </form>
</div>

<div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
    <h6 class="at-form-title mb-0">Formulários cadastrados</h6>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..."
                data-filter-input="#tbl-fq" data-filter-count="#count-fq">
        </div>
        <span id="count-fq" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-fq" class="table table-hover at-table mb-0">
        <thead>
            <tr><th>Processo</th><th>Descrição</th><th class="text-end">Ações</th></tr>
        </thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="3" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum formulário cadastrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="3" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->processo) ?></td>
                        <td><?= htmlspecialchars((string) ($item->descricao ?? '—')) ?></td>
                        <td class="text-end at-actions">
                            <a href="<?= route('formulario_qualificacao.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('formulario_qualificacao.destroy') ?>" method="POST" class="d-inline js-confirm-delete"
                                data-confirm-text="Deseja realmente excluir este formulário?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
