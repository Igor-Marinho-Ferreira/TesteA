<?php
$this->layout('templates/base', [
    'webTitle'  => 'Plano de Soldagem',
    'cardTitle' => 'Formulário de Registro do Plano de Soldagem',
    'backTo'    => route('menu'),
]);
/** @var \src\app\services\PlanoSoldagemService $service */
?>

<div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
    <a href="<?= route('plano.create') ?>" class="btn btn-success"><i class="ph ph-plus"></i> Novo plano</a>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..." data-filter-input="#tbl-plano" data-filter-count="#count-plano">
        </div>
        <span id="count-plano" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-plano" class="table table-hover at-table mb-0">
        <thead><tr><th>PS n.º</th><th>Rev</th><th>Título</th><th>Desenho</th><th>Data</th><th>Etapa</th><th>Status</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="8" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum plano registrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="8" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) {
                    $etapaCor = ['elaborado' => 'muted', 'verificado' => 'warn', 'aprovado' => 'ok'][$item->etapa] ?? 'muted';
                    ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->ps_numero) ?></td>
                        <td><?= htmlspecialchars((string) ($item->rev ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->titulo ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->desenho_numero ?? '—')) ?></td>
                        <td><?= $item->data ? dateAmericanToBrazilian($item->data) : '—' ?></td>
                        <td><span class="badge-tipo badge-status--<?= $etapaCor ?>"><?= htmlspecialchars($service->etapaLabel($item->etapa)) ?></span></td>
                        <td>
                            <?php if ($item->status === 'aprovado') { ?><span class="badge-tipo badge-status--ok">Aprovado</span>
                            <?php } elseif ($item->status === 'rejeitado') { ?><span class="badge-tipo badge-status--danger">Rejeitado</span>
                            <?php } else { ?><span class="badge-tipo badge-status--muted">Em andamento</span><?php } ?>
                        </td>
                        <td class="text-end at-actions">
                            <a href="<?= route('plano.show', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-secondary" title="Ver tudo"><i class="ph ph-eye"></i></a>
                            <?php if ($item->etapa === 'elaborado' && $item->status !== 'aprovado') { ?>
                                <a href="<?= route('plano.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                                <a href="<?= route('plano.verificar_form', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-warning" title="Verificar"><i class="ph ph-check-square"></i></a>
                            <?php } ?>
                            <?php if ($item->etapa === 'verificado') { ?>
                                <a href="<?= route('plano.aprovar_form', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-success" title="Aprovar"><i class="ph ph-seal-check"></i></a>
                            <?php } ?>
                            <form action="<?= route('plano.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Excluir o plano '<?= htmlspecialchars((string) $item->ps_numero) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
