<?php
$this->layout('templates/base', [
    'webTitle'  => 'Plano de Soldagem',
    'cardTitle' => 'Plano de Soldagem — PS n.º ' . htmlspecialchars((string) $plano->ps_numero),
    'backTo'    => route('plano.index'),
]);
/** @var \src\app\services\PlanoSoldagemService $service */
$etapaCor = ['elaborado' => 'muted', 'verificado' => 'warn', 'aprovado' => 'ok'][$plano->etapa] ?? 'muted';
?>

<!-- Cabeçalho -->
<div class="at-form-panel mb-4">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
        <div class="at-form-title at-accent--blue mb-0"><i class="ph ph-clipboard-text"></i> Plano de Soldagem</div>
        <div>
            <span class="badge-tipo badge-status--<?= $etapaCor ?>"><?= htmlspecialchars($service->etapaLabel($plano->etapa)) ?></span>
            <?php if ($plano->status === 'aprovado') { ?><span class="badge-tipo badge-status--ok">Aprovado</span>
            <?php } elseif ($plano->status === 'rejeitado') { ?><span class="badge-tipo badge-status--danger">Rejeitado</span>
            <?php } else { ?><span class="badge-tipo badge-status--muted">Em andamento</span><?php } ?>
        </div>
    </div>
    <div class="row g-3 mt-1">
        <div class="col-6 col-md-2"><small class="text-muted d-block">PS n.º</small><strong><?= htmlspecialchars((string) $plano->ps_numero) ?></strong></div>
        <div class="col-6 col-md-2"><small class="text-muted d-block">Rev</small><?= htmlspecialchars((string) ($plano->rev ?? '—')) ?></div>
        <div class="col-6 col-md-3"><small class="text-muted d-block">Projeto</small><?= htmlspecialchars((string) ($plano->projeto ?? '—')) ?></div>
        <div class="col-6 col-md-2"><small class="text-muted d-block">Data</small><?= $plano->data ? dateAmericanToBrazilian($plano->data) : '—' ?></div>
        <div class="col-6 col-md-3"><small class="text-muted d-block">Desenho n.º</small><?= htmlspecialchars((string) ($plano->desenho_numero ?? '—')) ?></div>
        <div class="col-12"><small class="text-muted d-block">Título</small><?= htmlspecialchars((string) ($plano->titulo ?? '—')) ?></div>
    </div>
</div>

<!-- Metal Base -->
<div class="at-form-panel mb-4">
    <div class="at-form-title at-accent--violet"><i class="ph ph-stack"></i> Metal Base</div>
    <div class="table-responsive">
        <table class="table at-table mb-0">
            <thead><tr><th>Juntas</th><th>EPS ref.</th><th>Processo</th><th>Peça</th><th>Material</th></tr></thead>
            <tbody>
                <?php if (empty($metalBase)) { ?><tr><td colspan="5" class="at-empty text-center">—</td></tr><?php } ?>
                <?php foreach ($metalBase as $m) { ?>
                    <tr>
                        <td class="fw-medium"><?= htmlspecialchars((string) ($m->juntas ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($m->eps_referencia ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($m->processo ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($m->peca ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($m->material ?? '')) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Detalhe da Junta -->
<div class="at-form-panel mb-4">
    <div class="at-form-title at-accent--slate"><i class="ph ph-git-merge"></i> Detalhe da Junta</div>
    <div class="table-responsive">
        <table class="table at-table mb-0">
            <thead><tr><th>Posição</th><th>Junta</th><th>Imagem</th></tr></thead>
            <tbody>
                <?php if (empty($detalhe)) { ?><tr><td colspan="3" class="at-empty text-center">—</td></tr><?php } ?>
                <?php foreach ($detalhe as $dj) { ?>
                    <tr>
                        <td class="fw-medium"><?= htmlspecialchars((string) ($dj->posicao ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($dj->junta ?? '')) ?></td>
                        <td><?php if (!empty($dj->imagem)) { ?><a class="at-file-link" href="<?= route('arquivo', [], ['f' => $dj->imagem]) ?>" target="_blank"><i class="ph ph-image"></i> ver</a><?php } else { ?>—<?php } ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Parâmetros de Soldagem -->
<div class="at-form-panel mb-4">
    <div class="at-form-title at-accent--amber"><i class="ph ph-sliders"></i> Parâmetros de Soldagem</div>
    <div class="table-responsive">
        <table class="table at-table mb-0" style="min-width:900px">
            <thead><tr><th>Junta</th><th>Gás</th><th>Vazão</th><th>Consumível</th><th>Bitola</th><th>Pol</th><th>Tensão</th><th>Corrente</th><th>Vel.</th><th>T.máx</th></tr></thead>
            <tbody>
                <?php if (empty($parametros)) { ?><tr><td colspan="10" class="at-empty text-center">—</td></tr><?php } ?>
                <?php foreach ($parametros as $p) { ?>
                    <tr>
                        <td class="fw-medium"><?= htmlspecialchars((string) ($p->junta ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->gas ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->vazao ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->consumivel ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->bitola ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->pol ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->tensao ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->corrente ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->vel_soldagem ?? '')) ?></td>
                        <td><?= htmlspecialchars((string) ($p->temp_max_interp ?? '')) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<?php $this->insert('plano/_historico', ['logs' => $logs, 'service' => $service]); ?>

<div class="at-form-foot">
    <a href="<?= route('plano.index') ?>" class="btn btn-light"><i class="ph ph-arrow-left"></i> Voltar</a>
    <?php if ($plano->status !== 'aprovado' && $plano->etapa === 'elaborado' && \src\app\services\PermissaoService::podeEditar('plano')) { ?>
        <a href="<?= route('plano.edit', ['uuid' => $plano->uuid]) ?>" class="btn btn-success"><i class="ph ph-pencil-simple"></i> Editar</a>
    <?php } ?>
</div>
