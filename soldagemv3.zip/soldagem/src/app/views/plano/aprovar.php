<?php
$this->layout('templates/base', [
    'webTitle'  => 'Aprovação do Plano',
    'cardTitle' => 'Aprovação do Plano de Soldagem',
    'backTo'    => route('plano.index'),
]);
/** @var \src\app\services\PlanoSoldagemService $service */
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head">
        <span class="at-form-head__icon"><i class="ph ph-seal-check"></i></span>
        <div>
            <div class="at-form-head__title">PS n.º <?= htmlspecialchars((string) $plano->ps_numero) ?> — <?= htmlspecialchars((string) ($plano->titulo ?? '')) ?></div>
            <div class="at-form-head__subtitle">Aprovação final libera o plano para vigência e uso operacional.</div>
        </div>
    </div>

    <form action="<?= route('plano.aprovar') ?>" method="POST">
        <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $plano->uuid) ?>">
        <div class="row g-3">
            <div class="col-12">
                <label class="form-label">Observação <span class="text-danger">*</span></label>
                <textarea name="observacao" class="form-control" rows="3" required></textarea>
            </div>
        </div>
        <div class="at-form-foot">
            <a href="<?= route('plano.index') ?>" class="btn btn-light">Cancelar</a>
            <button type="submit" name="acao" value="rejeitar" class="btn btn-outline-danger"><i class="ph ph-x-circle"></i> Rejeitar</button>
            <button type="submit" name="acao" value="aprovar" class="btn btn-success"><i class="ph ph-check-circle"></i> Aprovar</button>
        </div>
    </form>
</div>

<?php $this->insert('plano/_historico', ['logs' => $logs, 'service' => $service]); ?>
