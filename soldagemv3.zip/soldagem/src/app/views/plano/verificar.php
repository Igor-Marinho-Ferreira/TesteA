<?php
$this->layout('templates/base', [
    'webTitle'  => 'Verificação do Plano',
    'cardTitle' => 'Verificação do Plano de Soldagem',
    'backTo'    => route('plano.index'),
]);
/** @var \src\app\services\PlanoSoldagemService $service */
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head">
        <span class="at-form-head__icon"><i class="ph ph-check-square"></i></span>
        <div>
            <div class="at-form-head__title">PS n.º <?= htmlspecialchars((string) $plano->ps_numero) ?> — <?= htmlspecialchars((string) ($plano->titulo ?? '')) ?></div>
            <div class="at-form-head__subtitle">A etapa de verificação deve ser conduzida por engenheiro distinto de quem elaborou.</div>
        </div>
    </div>

    <form action="<?= route('plano.verificar') ?>" method="POST">
        <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $plano->uuid) ?>">
        <div class="row g-3">
            <div class="col-12 col-md-5">
                <label class="form-label">Relatório de plano de soldagem de acordo? <span class="text-danger">*</span></label>
                <select name="de_acordo" class="form-select" required>
                    <option value="">Selecione...</option>
                    <option value="sim">Sim</option>
                    <option value="nao">Não</option>
                </select>
                <small class="text-muted">Se "Não", o plano retorna para a etapa Elaborado.</small>
            </div>
            <div class="col-12">
                <label class="form-label">Observações <span class="text-danger">*</span></label>
                <textarea name="observacao" class="form-control" rows="3" required></textarea>
            </div>
        </div>
        <div class="at-form-foot">
            <a href="<?= route('plano.index') ?>" class="btn btn-light">Cancelar</a>
            <button type="submit" class="btn btn-success"><i class="ph ph-check"></i> Registrar verificação</button>
        </div>
    </form>
</div>

<?php $this->insert('plano/_historico', ['logs' => $logs, 'service' => $service]); ?>
