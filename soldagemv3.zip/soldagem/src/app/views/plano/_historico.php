<?php
/** @var array<int,object> $logs */
/** @var \src\app\services\PlanoSoldagemService $service */
$logs = $logs ?? [];
?>
<div class="at-form-panel">
    <div class="at-form-title at-accent--slate"><i class="ph ph-clock-counter-clockwise"></i> Histórico do fluxo</div>
    <?php if (empty($logs)) { ?>
        <p class="text-muted small mb-0">Sem registros de fluxo ainda.</p>
    <?php } else { ?>
        <div class="table-responsive">
            <table class="table at-table mb-0">
                <thead><tr><th>Etapa</th><th>Resposta</th><th>Observação</th><th>Usuário</th><th>Data</th></tr></thead>
                <tbody>
                    <?php foreach ($logs as $l) { ?>
                        <tr>
                            <td><span class="badge-tipo badge-status--muted"><?= htmlspecialchars($service->etapaLabel($l->etapa)) ?></span></td>
                            <td><?= htmlspecialchars((string) ($l->resposta ?? '—')) ?></td>
                            <td><?= htmlspecialchars((string) ($l->observacao ?? '—')) ?></td>
                            <td><?= htmlspecialchars((string) ($l->usuario_nome ?? '—')) ?></td>
                            <td><?= htmlspecialchars((string) ($l->created_at ?? '—')) ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    <?php } ?>
</div>
