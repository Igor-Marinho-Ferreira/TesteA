<?php
use src\app\services\PlanoSoldagemService;

$this->layout('templates/base', [
    'webTitle'  => 'Plano de Soldagem',
    'cardTitle' => 'Formulário de Registro do Plano de Soldagem',
    'backTo'    => route('plano.index'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('plano.update') : route('plano.store');
$mb  = $secoes['metalBase'] ?? [];
$dj  = $secoes['detalhe'] ?? [];
$pr  = $secoes['parametros'] ?? [];
$v = fn(string $c) => htmlspecialchars((string) ($editing->$c ?? ''));
?>

<form action="<?= $action ?>" method="POST" data-rascunho="plano-<?= $isEditing ? htmlspecialchars((string) $editing->uuid) : 'novo' ?>">
    <?php if ($isEditing) { ?>
        <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>">
    <?php } ?>

    <!-- Seção: Plano de Soldagem -->
    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--blue"><i class="ph ph-clipboard-text"></i> Plano de Soldagem</div>
        <div class="row g-3">
            <div class="col-6 col-md-2">
                <label class="form-label">PS n.º <span class="text-danger">*</span></label>
                <input type="text" name="ps_numero" class="form-control <?= applyWrong('ps_numero') ?>" value="<?= htmlspecialchars((string) ($editing->ps_numero ?? $psSugestao)) ?>" required>
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label">Rev</label>
                <input type="text" name="rev" class="form-control" value="<?= $v('rev') ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Projeto</label>
                <input type="text" name="projeto" class="form-control" value="<?= $v('projeto') ?>" placeholder="Estágio (Safety Walk)">
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label">Data</label>
                <input type="date" name="data" class="form-control" value="<?= htmlspecialchars((string) ($editing->data ?? date('Y-m-d'))) ?>">
            </div>
            <div class="col-6 col-md-3">
                <label class="form-label">Desenho n.º</label>
                <input type="text" name="desenho_numero" class="form-control" list="desenhos-list" value="<?= $v('desenho_numero') ?>">
                <datalist id="desenhos-list">
                    <?php foreach ($desenhos as $de) { ?><option value="<?= htmlspecialchars((string) $de->numero) ?>"><?php } ?>
                </datalist>
            </div>
            <div class="col-12 col-md-6">
                <label class="form-label">Título</label>
                <input type="text" name="titulo" class="form-control" value="<?= $v('titulo') ?>">
            </div>
        </div>
    </div>

    <!-- Seção: Metal Base (repetível) -->
    <div class="at-form-panel mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div class="at-form-title at-accent--violet mb-0"><i class="ph ph-stack"></i> Metal Base</div>
            <button type="button" class="btn btn-sm btn-outline-secondary" data-add-row="#mb-rows" data-template="#mb-tpl"><i class="ph ph-plus"></i> Adicionar</button>
        </div>
        <div class="table-responsive mt-2">
            <table class="table at-table mb-0">
                <thead><tr><th>Juntas</th><th>EPS ref.</th><th>Processo</th><th>Peça</th><th>Material</th><th></th></tr></thead>
                <tbody id="mb-rows">
                    <?php $rows = $mb ?: [null]; foreach ($rows as $r) { ?>
                        <tr>
                            <td><input type="text" name="mb_juntas[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->juntas ?? '')) ?>" placeholder="J01, J02"></td>
                            <td><input type="text" name="mb_eps[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->eps_referencia ?? '')) ?>"></td>
                            <td><input type="text" name="mb_processo[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->processo ?? '')) ?>"></td>
                            <td style="max-width:90px"><input type="number" name="mb_peca[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->peca ?? '')) ?>"></td>
                            <td><input type="text" name="mb_material[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->material ?? '')) ?>"></td>
                            <td><button type="button" class="btn btn-sm btn-outline-danger" data-del-row><i class="ph ph-x"></i></button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Seção: Detalhe da Junta (repetível) -->
    <div class="at-form-panel mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div class="at-form-title at-accent--slate mb-0"><i class="ph ph-git-merge"></i> Detalhe da Junta</div>
            <button type="button" class="btn btn-sm btn-outline-secondary" data-add-row="#dj-rows" data-template="#dj-tpl"><i class="ph ph-plus"></i> Adicionar</button>
        </div>
        <p class="text-muted small mt-1 mb-2">A imagem é puxada automaticamente do desenho selecionado acima.</p>
        <div class="table-responsive">
            <table class="table at-table mb-0">
                <thead><tr><th>Posição</th><th>Junta</th><th></th></tr></thead>
                <tbody id="dj-rows">
                    <?php $rows = $dj ?: [null]; foreach ($rows as $r) { ?>
                        <tr>
                            <td><input type="text" name="dj_posicao[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->posicao ?? '')) ?>" placeholder="Ex.: F7"></td>
                            <td><input type="text" name="dj_junta[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->junta ?? '')) ?>"></td>
                            <td><button type="button" class="btn btn-sm btn-outline-danger" data-del-row><i class="ph ph-x"></i></button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Seção: Parâmetros de Soldagem (repetível) -->
    <div class="at-form-panel mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div class="at-form-title at-accent--amber mb-0"><i class="ph ph-sliders"></i> Parâmetros de Soldagem</div>
            <button type="button" class="btn btn-sm btn-outline-secondary" data-add-row="#pr-rows" data-template="#pr-tpl"><i class="ph ph-plus"></i> Adicionar</button>
        </div>
        <div class="table-responsive mt-2">
            <table class="table at-table mb-0" style="min-width:960px">
                <thead><tr><th>Junta</th><th>Gás</th><th>Vazão</th><th>Consumível</th><th>Bitola</th><th>Pol</th><th>Tensão</th><th>Corrente</th><th>Vel.</th><th>T.máx</th><th></th></tr></thead>
                <tbody id="pr-rows">
                    <?php $rows = $pr ?: [null]; foreach ($rows as $r) { ?>
                        <tr>
                            <td><input type="text" name="pr_junta[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->junta ?? '')) ?>"></td>
                            <td><input type="text" name="pr_gas[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->gas ?? '')) ?>"></td>
                            <td><input type="text" name="pr_vazao[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->vazao ?? '')) ?>" placeholder="15-20"></td>
                            <td><input type="text" name="pr_consumivel[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->consumivel ?? '')) ?>"></td>
                            <td style="max-width:80px"><input type="text" name="pr_bitola[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->bitola ?? '')) ?>"></td>
                            <td style="max-width:90px">
                                <select name="pr_pol[]" class="form-select form-select-sm">
                                    <option value=""></option>
                                    <?php foreach (PlanoSoldagemService::POLARIDADES as $pol) { ?><option value="<?= $pol ?>" <?= ($r->pol ?? '') === $pol ? 'selected' : '' ?>><?= $pol ?></option><?php } ?>
                                </select>
                            </td>
                            <td><input type="text" name="pr_tensao[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->tensao ?? '')) ?>"></td>
                            <td><input type="text" name="pr_corrente[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->corrente ?? '')) ?>"></td>
                            <td><input type="text" name="pr_vel[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->vel_soldagem ?? '')) ?>"></td>
                            <td><input type="text" name="pr_temp[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->temp_max_interp ?? '')) ?>"></td>
                            <td><button type="button" class="btn btn-sm btn-outline-danger" data-del-row><i class="ph ph-x"></i></button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="at-form-foot">
        <a href="<?= route('plano.index') ?>" class="btn btn-light">Cancelar</a>
        <button type="button" class="btn btn-outline-secondary" data-salvar-rascunho><i class="ph ph-floppy-disk"></i> Salvar rascunho</button>
        <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Elaborar plano' ?></button>
    </div>
</form>

<script>
(function () {
    // Adiciona nova linha clonando a primeira linha da tbody (limpando valores)
    document.querySelectorAll('[data-add-row]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var tbody = document.querySelector(btn.getAttribute('data-add-row'));
            if (!tbody || !tbody.rows.length) return;
            var novo = tbody.rows[0].cloneNode(true);
            novo.querySelectorAll('input').forEach(function (i) { i.value = ''; });
            novo.querySelectorAll('select').forEach(function (s) { s.selectedIndex = 0; });
            tbody.appendChild(novo);
        });
    });
    // Remove linha (mantém ao menos uma)
    document.addEventListener('click', function (e) {
        var b = e.target.closest('[data-del-row]');
        if (!b) return;
        var tr = b.closest('tr');
        var tbody = tr.parentNode;
        if (tbody.rows.length > 1) tr.remove();
        else tr.querySelectorAll('input').forEach(function (i) { i.value = ''; });
    });
})();
</script>
