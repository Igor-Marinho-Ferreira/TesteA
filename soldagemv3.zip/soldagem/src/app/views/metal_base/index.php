<?php $this->layout('templates/base', [
    'webTitle'  => 'Metal Base',
    'cardTitle' => 'Cadastro de Metal Base (Material)',
    'backTo'    => route('menu'),
]) ?>

<?= $this->insert('partials/cadastro_simples', [
    'mod'         => 'metal_base',
    'campo'       => 'metal_base',
    'label'       => 'Metal Base',
    'singular'    => 'metal base',
    'icon'        => 'ph-stack',
    'placeholder' => 'Ex.: ASTM A36, SAE 1020',
    'maiusculo'   => true,
    'itens'       => $itens,
    'editing'     => $editing ?? null,
]) ?>
