<?php
$this->layout('templates/base', [
    'webTitle'  => 'Ensaio Visual e Dimensional',
    'cardTitle' => 'Relatório de Ensaio Visual e Dimensional de Solda',
    'backTo'    => route('menu'),
]);
?>

<div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
    <a href="<?= route('ensaio.create') ?>" class="btn btn-success"><i class="ph ph-plus"></i> Novo relatório</a>
    <div class="d-flex align-items-center gap-2">
        <div class="at-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="search" class="form-control form-control-sm" placeholder="Filtrar..." data-filter-input="#tbl-ens" data-filter-count="#count-ens">
        </div>
        <span id="count-ens" class="badge rounded-pill text-bg-light border"><?= count($itens) ?> registro(s)</span>
    </div>
</div>

<div class="table-responsive">
    <table id="tbl-ens" class="table table-hover at-table mb-0">
        <thead><tr><th>Nº Relatório</th><th>Data</th><th>Tipo Junta</th><th>Material</th><th>Avaliação</th><th class="text-end">Ações</th></tr></thead>
        <tbody>
            <?php if (empty($itens)) { ?>
                <tr><td colspan="6" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhum relatório registrado ainda.</td></tr>
            <?php } else { ?>
                <tr data-filter-empty style="display:none;"><td colspan="6" class="text-center at-empty py-3">Nenhum resultado para o filtro.</td></tr>
                <?php foreach ($itens as $item) { ?>
                    <tr data-row>
                        <td class="fw-medium"><?= htmlspecialchars((string) $item->numero_relatorio) ?></td>
                        <td><?= $item->data ? dateAmericanToBrazilian($item->data) : '—' ?></td>
                        <td><?= htmlspecialchars((string) ($item->tipo_junta ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($item->material ?? '—')) ?></td>
                        <td>
                            <?php if (($item->avaliacao_resultado ?? '') === 'Aprovado') { ?><span class="badge-tipo badge-status--ok">Aprovado</span>
                            <?php } elseif (($item->avaliacao_resultado ?? '') === 'Reprovado') { ?><span class="badge-tipo badge-status--danger">Reprovado</span>
                            <?php } else { ?>—<?php } ?>
                        </td>
                        <td class="text-end at-actions">
                            <a href="<?= route('ensaio.edit', ['uuid' => $item->uuid]) ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="ph ph-pencil-simple"></i></a>
                            <form action="<?= route('ensaio.destroy') ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-text="Excluir o relatório '<?= htmlspecialchars((string) $item->numero_relatorio) ?>'?">
                                <input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $item->uuid) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Excluir"><i class="ph ph-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/confirm_modal') ?>
