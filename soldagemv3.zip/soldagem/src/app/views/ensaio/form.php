<?php
use src\app\services\EnsaioVisualService;

$this->layout('templates/base', [
    'webTitle'  => 'Ensaio Visual e Dimensional',
    'cardTitle' => 'Relatório de Ensaio Visual e Dimensional de Solda',
    'backTo'    => route('ensaio.index'),
]);

$editing   = $editing ?? null;
$isEditing = (bool) $editing;
$action    = $isEditing ? route('ensaio.update') : route('ensaio.store');
$instrumentos = $instrumentos ?? [];
$ocorrencias  = $ocorrencias ?? [];
$v = fn(string $c, $def = '') => htmlspecialchars((string) ($editing->$c ?? $def));
$condSel = $editing ? explode(',', (string) ($editing->condicao_superficie ?? '')) : [];
$inspSel = $editing ? explode(',', (string) ($editing->inspecao_realizada_em ?? '')) : [];
?>

<form action="<?= $action ?>" method="POST" data-rascunho="ensaio-<?= $isEditing ? htmlspecialchars((string) $editing->uuid) : 'novo' ?>">
    <?php if ($isEditing) { ?><input type="hidden" name="uuid" value="<?= htmlspecialchars((string) $editing->uuid) ?>"><?php } ?>

    <!-- Documentos -->
    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--blue"><i class="ph ph-file-text"></i> Documentos — Nº Relatório: <span class="text-success"><?= htmlspecialchars((string) $proximo) ?></span></div>
        <div class="row g-3">
            <div class="col-12 col-md-4"><label class="form-label">Equipamento / Descrição</label><input type="text" name="equipamento" class="form-control" value="<?= $v('equipamento') ?>"></div>
            <div class="col-6 col-md-2"><label class="form-label">Quantidade (amostras)</label><input type="number" name="quantidade" class="form-control" value="<?= $v('quantidade') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Desenho</label><input type="text" name="desenho" class="form-control" value="<?= $v('desenho') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Revisão</label><input type="text" name="revisao" class="form-control" value="<?= $v('revisao') ?>"></div>
            <div class="col-12 col-md-5"><label class="form-label">Documentos de referência</label><input type="text" name="documentos_referencia" class="form-control" value="<?= $v('documentos_referencia') ?>"></div>
            <div class="col-6 col-md-3"><label class="form-label">Revisão (doc)</label><input type="text" name="revisao_doc" class="form-control" value="<?= $v('revisao_doc') ?>"></div>
            <div class="col-12 col-md-4"><label class="form-label">Critério de Aceitação</label><input type="text" name="criterio_aceitacao" class="form-control" value="<?= $v('criterio_aceitacao', 'AWS D15.1 ED.2019') ?>"></div>
        </div>
    </div>

    <!-- Instrumentos -->
    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--slate"><i class="ph ph-ruler"></i> Instrumentos utilizados</div>
        <div class="table-responsive">
            <table class="table at-table mb-0">
                <thead><tr><th>Instrumento</th><th>Tipo</th><th>Cód. Instrumento</th><th>Validade</th></tr></thead>
                <tbody>
                    <?php foreach (EnsaioVisualService::INSTRUMENTOS as $cat => $label) {
                        $i = $instrumentos[$cat] ?? null; ?>
                        <tr>
                            <td class="fw-medium align-middle"><?= htmlspecialchars($label) ?></td>
                            <td><input type="text" name="inst_tipo[<?= $cat ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($i->tipo ?? '')) ?>"></td>
                            <td><input type="text" name="inst_cod[<?= $cat ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($i->cod_instrumento ?? '')) ?>"></td>
                            <td><input type="text" name="inst_val[<?= $cat ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($i->validade ?? '')) ?>"></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Material ensaiado + condições -->
    <div class="at-form-panel mb-4">
        <div class="at-form-title at-accent--violet"><i class="ph ph-stack"></i> Material ensaiado</div>
        <div class="row g-3">
            <div class="col-12 col-md-3">
                <label class="form-label">Tipo de junta <span class="text-danger">*</span></label>
                <select name="tipo_junta" class="form-select" required>
                    <option value="">Selecione...</option>
                    <?php foreach (EnsaioVisualService::TIPOS_JUNTA as $tj) { ?><option value="<?= htmlspecialchars($tj) ?>" <?= ($editing->tipo_junta ?? '') === $tj ? 'selected' : '' ?>><?= htmlspecialchars($tj) ?></option><?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-3"><label class="form-label">Material</label><input type="text" name="material" class="form-control" value="<?= $v('material', 'ASTM A242') ?>"></div>
            <div class="col-12 col-md-3"><label class="form-label">Dimensões</label><input type="text" name="dimensoes" class="form-control" value="<?= $v('dimensoes', '12,7x200x200mm') ?>"></div>
            <div class="col-12 col-md-3"><label class="form-label">Método utilizado</label><input type="text" name="metodo" class="form-control" value="<?= $v('metodo', 'DIRETO') ?>"></div>
        </div>
        <div class="row g-3 mt-1">
            <div class="col-12 col-md-6">
                <label class="form-label">Condição da superfície</label>
                <div class="d-flex flex-wrap gap-3">
                    <?php foreach (EnsaioVisualService::CONDICAO_SUPERFICIE as $c) { ?>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="condicao_superficie[]" value="<?= htmlspecialchars($c) ?>" id="cond<?= md5($c) ?>" <?= in_array($c, $condSel, true) ? 'checked' : '' ?>><label class="form-check-label" for="cond<?= md5($c) ?>"><?= htmlspecialchars($c) ?></label></div>
                    <?php } ?>
                </div>
            </div>
            <div class="col-12 col-md-6">
                <label class="form-label">Inspeção realizada em</label>
                <div class="d-flex flex-wrap gap-3">
                    <?php foreach (EnsaioVisualService::INSPECAO_EM as $c) { ?>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="inspecao_realizada_em[]" value="<?= htmlspecialchars($c) ?>" id="insp<?= md5($c) ?>" <?= in_array($c, $inspSel, true) ? 'checked' : '' ?>><label class="form-check-label" for="insp<?= md5($c) ?>"><?= htmlspecialchars($c) ?></label></div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Ocorrências -->
    <div class="at-form-panel mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div class="at-form-title at-accent--amber mb-0"><i class="ph ph-warning"></i> Ocorrências (descontinuidades)</div>
            <button type="button" class="btn btn-sm btn-outline-secondary" data-add-oc><i class="ph ph-plus"></i> Adicionar</button>
        </div>
        <div class="table-responsive mt-2">
            <table class="table at-table mb-0" style="min-width:1100px">
                <thead>
                    <tr>
                        <th>EPS</th><th>Processo</th><th>Sinete</th><th>Junta</th>
                        <?php foreach (array_keys(EnsaioVisualService::DESCONTINUIDADES) as $cod) { ?><th title="<?= EnsaioVisualService::DESCONTINUIDADES[$cod] ?>"><?= $cod ?></th><?php } ?>
                        <th>Avaliação</th><th></th>
                    </tr>
                </thead>
                <tbody id="oc-rows">
                    <?php
                    $rows = $ocorrencias ?: [null];
                    foreach ($rows as $idx => $r) {
                        $descsSel = $r ? explode(',', (string) ($r->descontinuidades ?? '')) : [];
                        ?>
                        <tr>
                            <td><input type="text" name="oc_eps[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->eps ?? '')) ?>"></td>
                            <td><input type="text" name="oc_processo[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->processo_soldagem ?? '')) ?>"></td>
                            <td><input type="text" name="oc_sinete[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->sinete ?? '')) ?>"></td>
                            <td><input type="text" name="oc_junta[]" class="form-control form-control-sm" value="<?= htmlspecialchars((string) ($r->junta ?? '')) ?>"></td>
                            <?php foreach (array_keys(EnsaioVisualService::DESCONTINUIDADES) as $cod) { ?>
                                <td class="text-center"><input type="checkbox" name="oc_desc[<?= $idx ?>][]" value="<?= $cod ?>" <?= in_array($cod, $descsSel, true) ? 'checked' : '' ?>></td>
                            <?php } ?>
                            <td>
                                <select name="oc_aval[]" class="form-select form-select-sm">
                                    <option value=""></option>
                                    <?php foreach (EnsaioVisualService::AVALIACAO as $a) { ?><option value="<?= $a ?>" <?= ($r->avaliacao ?? '') === $a ? 'selected' : '' ?>><?= $a ?></option><?php } ?>
                                </select>
                            </td>
                            <td><button type="button" class="btn btn-sm btn-outline-danger" data-del-row><i class="ph ph-x"></i></button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <small class="text-muted d-block mt-2">
            Legenda: <?php $leg = []; foreach (EnsaioVisualService::DESCONTINUIDADES as $k => $v2) $leg[] = "$k = $v2"; echo htmlspecialchars(implode(' · ', $leg)); ?>
        </small>
    </div>

    <!-- Avaliação final -->
    <div class="at-form-panel mb-4">
        <div class="row g-3">
            <div class="col-12 col-md-3">
                <label class="form-label">Avaliação dos resultados</label>
                <select name="avaliacao_resultado" class="form-select">
                    <option value="">Selecione...</option>
                    <?php foreach (EnsaioVisualService::AVALIACAO as $a) { ?><option value="<?= $a ?>" <?= ($editing->avaliacao_resultado ?? '') === $a ? 'selected' : '' ?>><?= $a ?></option><?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-4"><label class="form-label">Resultados de radiografia</label><input type="text" name="radiografia_resultado" class="form-control" value="<?= $v('radiografia_resultado') ?>"></div>
            <div class="col-12 col-md-5"><label class="form-label">Interpretada por</label><input type="text" name="radiografia_interpretada_por" class="form-control" value="<?= $v('radiografia_interpretada_por') ?>"></div>
            <div class="col-12"><label class="form-label">Observações</label><textarea name="observacoes" class="form-control" rows="2"><?= htmlspecialchars((string) ($editing->observacoes ?? '')) ?></textarea></div>
        </div>
        <small class="text-muted d-block mt-2">Ensaio realizado por: preenchimento automático (usuário logado, matrícula e data).</small>
    </div>

    <div class="at-form-foot">
        <a href="<?= route('ensaio.index') ?>" class="btn btn-light">Cancelar</a>
        <button type="button" class="btn btn-outline-secondary" data-salvar-rascunho><i class="ph ph-floppy-disk"></i> Salvar rascunho</button>
        <button type="submit" class="btn btn-success"><i class="ph <?= $isEditing ? 'ph-check' : 'ph-plus' ?>"></i> <?= $isEditing ? 'Salvar alterações' : 'Registrar relatório' ?></button>
    </div>
</form>

<script>
(function () {
    var tbody = document.getElementById('oc-rows');
    document.querySelector('[data-add-oc]').addEventListener('click', function () {
        if (!tbody.rows.length) return;
        var novo = tbody.rows[0].cloneNode(true);
        // reindexa os checkboxes de descontinuidade
        var idx = tbody.rows.length;
        novo.querySelectorAll('input, select').forEach(function (el) {
            if (el.type === 'checkbox') { el.checked = false; el.name = el.name.replace(/oc_desc\[\d+\]/, 'oc_desc[' + idx + ']'); }
            else if (el.tagName === 'SELECT') el.selectedIndex = 0;
            else el.value = '';
        });
        tbody.appendChild(novo);
    });
    document.addEventListener('click', function (e) {
        var b = e.target.closest('[data-del-row]');
        if (!b) return;
        var tr = b.closest('tr');
        if (tbody.rows.length > 1) tr.remove();
    });
})();
</script>
