<?php
$this->layout('templates/base', [
    'webTitle'  => 'Validação de Certificação',
    'cardTitle' => 'Validação de Continuidade da Certificação (MES × AWS)',
    'backTo'    => route('menu'),
]);
?>

<div class="at-form-panel mb-4">
    <div class="at-form-head">
        <span class="at-form-head__icon"><i class="ph ph-shield-check"></i></span>
        <div>
            <div class="at-form-head__title">Validar soldador na estação</div>
            <div class="at-form-head__subtitle">
                Continuidade AWS D1.1 (4.2.3.2): a qualificação é válida com evidência do mesmo processo e posição
                dentro de 6 meses. Janelas de 30/40/60 dias são alertas preventivos.
                A leitura automática do MES (Histórico Login) entra quando o acesso estiver disponível.
            </div>
        </div>
    </div>

    <form action="<?= route('validacao.validar') ?>" method="POST" class="row g-3 align-items-end">
        <div class="col-12 col-md-4">
            <label class="form-label">Matrícula do soldador <span class="text-danger">*</span></label>
            <input type="text" name="matricula" class="form-control" required>
        </div>
        <div class="col-12 col-md-5">
            <label class="form-label">Código da Estação MES <span class="text-danger">*</span></label>
            <input type="text" name="estacao" class="form-control" placeholder="Ex.: HTT_RUMO_EST01.1" required>
        </div>
        <div class="col-12 col-md-3">
            <button type="submit" class="btn btn-success w-100"><i class="ph ph-play"></i> Validar</button>
        </div>
    </form>
</div>

<h6 class="at-form-title">Últimas validações</h6>
<div class="table-responsive">
    <table class="table table-hover at-table mb-0">
        <thead><tr><th>Data</th><th>Matrícula</th><th>Estação</th><th>Processo</th><th>Posição</th><th>Janela</th><th>Resultado</th></tr></thead>
        <tbody>
            <?php if (empty($logs)) { ?>
                <tr><td colspan="7" class="text-center at-empty"><i class="ph ph-tray" style="font-size:1.5rem;"></i><br>Nenhuma validação registrada ainda.</td></tr>
            <?php } else { ?>
                <?php foreach ($logs as $l) { ?>
                    <tr>
                        <td><?= htmlspecialchars((string) ($l->data_login ?? '—')) ?></td>
                        <td class="fw-medium"><?= htmlspecialchars((string) $l->matricula) ?></td>
                        <td><?= htmlspecialchars((string) ($l->estacao ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($l->processo ?? '—')) ?></td>
                        <td><?= htmlspecialchars((string) ($l->posicao ?? '—')) ?></td>
                        <td><?= $l->janela ? htmlspecialchars((string) $l->janela) . ' dias' : '—' ?></td>
                        <td>
                            <?php if ($l->resultado === 'validado') { ?>
                                <span class="badge-tipo badge-status--ok">Validado</span>
                            <?php } else { ?>
                                <span class="badge-tipo badge-status--danger">Bloqueado</span>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>
