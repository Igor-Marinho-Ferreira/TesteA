<?php
$this->layout('templates/base', [
    'webTitle'  => 'Manual do Sistema',
    'cardTitle' => 'Manual — Como o processo e cada tela funcionam',
    'backTo'    => route('menu'),
]);

// Helper para um item de accordion
$item = function (string $id, string $titulo, string $conteudoHtml, string $pai) {
    echo '<div class="accordion-item">'
        . '<h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#' . $id . '">' . $titulo . '</button></h2>'
        . '<div id="' . $id . '" class="accordion-collapse collapse" data-bs-parent="#' . $pai . '"><div class="accordion-body">' . $conteudoHtml . '</div></div>'
        . '</div>';
};
?>

<style>
    .manual-flow{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin:.5rem 0 1rem}
    .manual-flow .step{background:#e9f7ee;color:#1f8a4c;border:1px solid #cdeed9;border-radius:10px;padding:.4rem .7rem;font-weight:600;font-size:.85rem}
    .manual-flow .arrow{color:#94a3b8}
    .manual-lead{color:#475569}
    .accordion-button:not(.collapsed){background:#eaf3fc;color:#1f6fb8}
</style>

<p class="manual-lead">
    O sistema digitaliza a inspeção de soldagem em três blocos. A lógica é sempre a mesma:
    <strong>parametrizar</strong> as opções base → <strong>registrar</strong> os formulários →
    <strong>validar/aprovar</strong> → <strong>analisar</strong> (Power BI).
</p>

<div class="manual-flow">
    <span class="step">Cadastros base</span><span class="arrow">→</span>
    <span class="step">Plano / EPS</span><span class="arrow">→</span>
    <span class="step">Soldadores / RQS</span><span class="arrow">→</span>
    <span class="step">Checklist</span><span class="arrow">→</span>
    <span class="step">Power BI</span>
</div>

<div class="at-form-panel mb-4">
    <div class="at-form-title at-accent--slate"><i class="ph ph-info"></i> Como usar qualquer tela</div>
    <ul class="mb-0">
        <li><strong>Formulário no topo</strong>: preencha e clique em <em>Registrar</em> (ou <em>Salvar alterações</em> ao editar). Campos com <span class="text-danger">*</span> são obrigatórios.</li>
        <li><strong>Filtrar…</strong>: a busca acima da tabela filtra os registros em tempo real.</li>
        <li><strong>Ações</strong>: ✏️ editar carrega o registro no formulário; 🗑️ excluir pede confirmação.</li>
        <li><strong>Bloqueios</strong>: registros já usados por outra tela não podem ser editados/excluídos (o sistema avisa).</li>
        <li><strong>Notificações</strong>: mensagens de sucesso/erro aparecem no canto da tela.</li>
    </ul>
</div>

<!-- ===================== BLOCO 1 ===================== -->
<h6 class="at-form-title mt-4"><i class="ph ph-number-circle-one"></i> Bloco 1 — Plano de Soldagem</h6>
<div class="accordion mb-4" id="acc-b1">
    <?php
    $item('m-junta', 'Juntas', '<p>Cadastro simples da junta (ex.: <code>J01</code>). Alimenta o Plano de Soldagem. Não permite duplicar nem editar/excluir se já estiver em uso.</p>', 'acc-b1');
    $item('m-metal', 'Metal Base (Material)', '<p>Cadastro do material (ex.: <code>ASTM A36</code>). Alimenta o Plano e o Checklist.</p>', 'acc-b1');
    $item('m-gas', 'Gás', '<p>Gás + composição + percentual. Ex.: <code>Mistura Ar+CO₂ (80/20)</code>.</p>', 'acc-b1');
    $item('m-desenho', 'Desenhos', '<p>Número + imagem (PNG/JPG/PDF). A imagem é <strong>reutilizada automaticamente</strong> no Detalhe da Junta do Plano.</p>', 'acc-b1');
    $item('m-eps', 'Upload de Informações da EPS', '<p>A EPS é a “regra” (valores especificados). Duas formas:</p><ul><li><strong>Importação em lote</strong> (.xlsx/.csv separador <code>;</code>) — a 1ª linha deve ser o cabeçalho exato do layout; duplicidade de Nº Documento/RQPS é bloqueada.</li><li><strong>Cadastro manual</strong> — mesmos campos no formulário.</li></ul>', 'acc-b1');
    $item('m-plano', 'Formulário do Plano de Soldagem', '<p>Monta o plano em 4 seções (linhas dinâmicas): Plano, Metal Base, Detalhe da Junta e Parâmetros. O <strong>PS n.º</strong> é gerado sozinho (N/YY).</p><p><strong>Fluxo:</strong> Elaborado → <em>Verificar</em> (engenheiro distinto responde “de acordo? Sim/Não”) → <em>Aprovar</em> (aprova/rejeita). Após aprovado, a edição trava. Tudo fica no histórico.</p>', 'acc-b1');
    $item('m-plano-resp', 'Responsáveis do Plano', '<p>Define quem conduz cada etapa (Elaborado/Verificado/Aprovado).</p>', 'acc-b1');
    ?>
</div>

<!-- ===================== BLOCO 2 ===================== -->
<h6 class="at-form-title mt-4"><i class="ph ph-number-circle-two"></i> Bloco 2 — Qualificação de Soldadores</h6>
<div class="accordion mb-4" id="acc-b2">
    <?php
    $item('m-qualif', 'Qualificação (Processo)', '<p>Processo AWS (ex.: <code>GMAW</code>). “Regra especial” abre o campo Modo de Transferência (padrão <code>CURTO-CIRCUITO</code>).</p>', 'acc-b2');
    $item('m-posicao', 'Posição de Qualificação', '<p>Tipo (1G–6G) + Posição. Se a posição for <strong>Vertical</strong>, abre a Progressão (Ascendente/Descendente).</p>', 'acc-b2');
    $item('m-trein', 'Treinamentos', '<p>Ex.: <code>AWS D15.1</code>. Alimenta o cadastro de Soldadores.</p>', 'acc-b2');
    $item('m-sold', 'Soldadores', '<p>Amarra matrícula, sinete, cargo, treinamentos, processos e posições. A <strong>data de requalificação</strong> é calculada sozinha (última + 6 meses); a lista destaca vencimentos por cor.</p>', 'acc-b2');
    $item('m-formqual', 'Formulário de Qualificação', '<p>Catálogo (processo + posições) que serve de base para o RQS.</p>', 'acc-b2');
    $item('m-estacao', 'Estação MES × Qualificação AWS', '<p>Diz qual processo e posição cada estação do MES exige. Base da validação de continuidade. “Excluir” apenas inativa (rastreabilidade).</p>', 'acc-b2');
    $item('m-rqs', 'RQS — Registro de Qualificação', '<p>Formulário AWS D15.1: variáveis (usado × faixa), exame visual, dobramento, testes. Certificado gerado sozinho. <strong>Fluxo Escola → Engenharia</strong> (enviar → aprovar).</p>', 'acc-b2');
    $item('m-ensaio', 'Ensaio Visual e Dimensional', '<p>Instrumentos, material ensaiado, condição da superfície, ocorrências (descontinuidades MD…PS) e avaliação. Nº do relatório automático. “Ensaio realizado por” é preenchido sozinho.</p>', 'acc-b2');
    $item('m-rel', 'Relatório de Qualificação', '<p>Consolida soldadores com filtros (vencendo em 30/40/60 dias, vencidos, qualificados…), destaque por cor e <strong>exportação em Excel</strong>.</p>', 'acc-b2');
    $item('m-valid', 'Validação de Certificação (MES)', '<p>Dado matrícula + estação, confere se o soldador tem a qualificação e se está dentro dos <strong>6 meses (AWS)</strong>; responde Validado/Bloqueado e registra o log. A leitura automática do MES entra quando o acesso estiver disponível.</p>', 'acc-b2');
    ?>
</div>

<!-- ===================== BLOCO 3 ===================== -->
<h6 class="at-form-title mt-4"><i class="ph ph-number-circle-three"></i> Bloco 3 — Checklist de Soldagem</h6>
<div class="accordion mb-4" id="acc-b3">
    <?php
    $item('m-modelo', 'Modelos de Vagão', '<p>Ex.: <code>HOPPER</code>. Alimenta o Checklist.</p>', 'acc-b3');
    $item('m-cliente', 'Clientes', '<p>Ex.: <code>MRS</code>. Alimenta o Checklist.</p>', 'acc-b3');
    $item('m-estagio', 'Estágios de Soldagem', '<p>Alimenta o Checklist.</p>', 'acc-b3');
    $item('m-checklist', 'Formulário de Checklist', '<p>Digite a <strong>matrícula</strong> → o sistema busca o soldador e preenche nome/sinete/qualificação, avisando se está vencida. Preencha <strong>Encontrado × Especificado</strong>: se algo divergir da EPS, o status vira <strong>Reprovado</strong> automaticamente; senão, Aprovado.</p>', 'acc-b3');
    ?>
</div>

<!-- ===================== BI / ADMIN ===================== -->
<h6 class="at-form-title mt-4"><i class="ph ph-gear"></i> Integrações, BI e Administração</h6>
<div class="accordion mb-4" id="acc-b4">
    <?php
    $item('m-bi', 'Power BI', '<p>Exporta os datasets (Soldadores, Checklist, EPS, Planos, RQS, Ensaios) em Excel. Acesso restrito aos usuários do escopo.</p>', 'acc-b4');
    $item('m-perfil', 'Perfis de Acesso', '<p>Define, por módulo, se cada pessoa <strong>Vê</strong> a tela e se pode <strong>Editar</strong> ou apenas visualizar. Vincule uma matrícula a um perfil — o menu e os botões passam a respeitar isso. Útil para mostrar só o que já foi entregue no sprint.</p>', 'acc-b4');
    ?>
</div>
