<?php $this->layout('templates/base', [
    'webTitle'  => 'Clientes',
    'cardTitle' => 'Cadastro de Cliente',
    'backTo'    => route('menu'),
]) ?>

<?= $this->insert('partials/cadastro_simples', [
    'mod'         => 'cliente',
    'campo'       => 'cliente',
    'label'       => 'Cliente',
    'singular'    => 'cliente',
    'icon'        => 'ph-buildings',
    'placeholder' => 'Ex.: MRS',
    'itens'       => $itens,
    'editing'     => $editing ?? null,
]) ?>
