<?php

namespace src\app\controllers;

use src\app\services\SoldadorService;
use Shuchkin\SimpleXLSXGen;

class RelatorioController
{
    /** Filtros disponíveis no relatório de qualificação. */
    public const FILTROS = [
        'todos'        => 'Todos',
        'venc60'       => 'Vencimentos em 60 dias',
        'venc40'       => 'Vencimentos em 40 dias',
        'venc30'       => 'Vencimentos em 30 dias',
        'venc_menos30' => 'Vencimentos em menos de 30 dias',
        'vencidos'     => 'Vencidos',
        'qualificados' => 'Qualificados',
        'requalificar' => 'Requalificar',
        'ativos'       => 'Funcionários ativos',
        'inativos'     => 'Funcionários inativos',
    ];

    function __construct()
    {
    }

    function qualificacaoSoldadores(): mixed
    {
        $service = new SoldadorService;
        $filtro  = (string) (fromGet('filtro') ?? 'todos');
        if (!array_key_exists($filtro, self::FILTROS)) $filtro = 'todos';

        $itens = $this->aplicarFiltro($service, $filtro);
        return view('relatorio.qualificacao', compact('itens', 'filtro', 'service'));
    }

    function qualificacaoExcel(): mixed
    {
        $service = new SoldadorService;
        $filtro  = (string) (fromGet('filtro') ?? 'todos');
        if (!array_key_exists($filtro, self::FILTROS)) $filtro = 'todos';
        $itens = $this->aplicarFiltro($service, $filtro);

        $linhas = [[
            'Matrícula', 'Nome', 'Cargo', 'Sinete', 'Performance',
            'Data Qualificação', 'Última Qualificação', 'Requalificação',
            'Status', 'Status Qualificação', 'Nº Registro Requalificação',
        ]];
        foreach ($itens as $s) {
            $linhas[] = [
                (string) $s->matricula,
                (string) ($s->nome ?? ''),
                (string) ($s->cargo ?? ''),
                (string) $s->sinete,
                (string) ($s->performance ?? ''),
                (string) ($s->data_qualificacao ?? ''),
                (string) ($s->data_ultima_qualificacao ?? ''),
                (string) ($s->data_requalificacao ?? ''),
                (string) ($s->status ?? ''),
                (string) ($s->status_qualificacao ?? ''),
                (string) ($s->numero_registro_requalificacao ?? ''),
            ];
        }

        $xlsx = SimpleXLSXGen::fromArray($linhas);
        $xlsx->downloadAs('relatorio_qualificacao_soldadores.xlsx');
        die;
    }

    /**
     * @return array<int, object>
     */
    private function aplicarFiltro(SoldadorService $service, string $filtro): array
    {
        $todos = $service->listAll();
        if ($filtro === 'todos') return $todos;

        return array_values(array_filter($todos, function ($s) use ($service, $filtro) {
            $dias = $service->diasParaVencer($s->data_requalificacao ?? null);
            switch ($filtro) {
                case 'venc60':       return $dias !== null && $dias >= 0 && $dias < 60;
                case 'venc40':       return $dias !== null && $dias >= 0 && $dias < 40;
                case 'venc30':       return $dias !== null && $dias >= 0 && $dias < 30;
                case 'venc_menos30': return $dias !== null && $dias >= 0 && $dias < 30;
                case 'vencidos':     return $dias !== null && $dias < 0;
                case 'qualificados': return ($s->status_qualificacao ?? '') === 'QUALIFICADO';
                case 'requalificar': return ($s->status_qualificacao ?? '') === 'REQUALIFICAR';
                case 'ativos':       return ($s->status ?? 'ativo') === 'ativo';
                case 'inativos':     return ($s->status ?? '') === 'inativo';
                default:             return true;
            }
        }));
    }
}
