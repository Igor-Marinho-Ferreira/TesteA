<?php

namespace src\app\controllers;

use src\app\requests\StorePlanoSoldagemRequest;
use src\app\services\PlanoSoldagemService;
use src\app\services\JuntaService;
use src\app\services\MetalBaseService;
use src\app\services\GasService;
use src\app\services\QualificacaoService;
use src\app\services\DesenhoService;
use src\app\services\EpsService;

class PlanoSoldagemController
{
    function __construct()
    {
    }

    private function opcoes(): array
    {
        return [
            'juntas'        => (new JuntaService)->listAll(),
            'metais'        => (new MetalBaseService)->listAll(),
            'gases'         => (new GasService)->listAll(),
            'qualificacoes' => (new QualificacaoService)->listAll(),
            'desenhos'      => (new DesenhoService)->listAll(),
            'epsList'       => (new EpsService)->listAll(),
        ];
    }

    function index(): mixed
    {
        $service = new PlanoSoldagemService;
        $itens   = $service->listAll();
        return view('plano.list', compact('itens', 'service'));
    }

    /** Visualização completa do plano (somente leitura). */
    function show(string $uuid): mixed
    {
        $service = new PlanoSoldagemService;
        $plano   = $service->find($uuid);
        if (!$plano) {
            return redirect()->route('plano.index')->withError('Plano não encontrado.');
        }
        $metalBase  = $service->metalBaseDo((int) $plano->id);
        $detalhe    = $service->detalheDo((int) $plano->id);
        $parametros = $service->parametrosDo((int) $plano->id);
        $logs       = $service->logsDo((int) $plano->id);
        return view('plano.show', compact('plano', 'service', 'metalBase', 'detalhe', 'parametros', 'logs'));
    }

    function create(): mixed
    {
        $service = new PlanoSoldagemService;
        $editing = null;
        $secoes  = ['metalBase' => [], 'detalhe' => [], 'parametros' => []];
        $psSugestao = $service->proximoPsNumero();
        return view('plano.form', array_merge(compact('editing', 'service', 'secoes', 'psSugestao'), $this->opcoes()));
    }

    function store(StorePlanoSoldagemRequest $request): mixed
    {
        $request->execute();
        (new PlanoSoldagemService)->store($request->get());
        notification()->success('Plano de Soldagem elaborado com sucesso!');
        return redirect()->route('plano.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new PlanoSoldagemService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('plano.index')->withError('Plano não encontrado.');
        }
        if ($editing->status === 'aprovado') {
            return redirect()->route('plano.index')->withError('Plano aprovado: edição bloqueada.');
        }
        $secoes = [
            'metalBase'  => $service->metalBaseDo((int) $editing->id),
            'detalhe'    => $service->detalheDo((int) $editing->id),
            'parametros' => $service->parametrosDo((int) $editing->id),
        ];
        $psSugestao = $editing->ps_numero;
        return view('plano.form', array_merge(compact('editing', 'service', 'secoes', 'psSugestao'), $this->opcoes()));
    }

    function update(StorePlanoSoldagemRequest $request): mixed
    {
        $request->execute();
        $service = new PlanoSoldagemService;
        $uuid = (string) $request->input('uuid');
        $plano = $service->find($uuid);
        if (!$plano) {
            return redirect()->route('plano.index')->withError('Plano não encontrado.');
        }
        if ($plano->status === 'aprovado') {
            return redirect()->route('plano.index')->withError('Plano aprovado: edição bloqueada.');
        }
        $service->update($uuid, $request->get());
        notification()->success('Plano de Soldagem atualizado com sucesso!');
        return redirect()->route('plano.index');
    }

    function destroy(): mixed
    {
        $service = new PlanoSoldagemService;
        $uuid    = (string) request()->get('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('plano.index')->withError('Plano não encontrado.');
        }
        $service->delete($uuid);
        notification()->success('Plano excluído com sucesso!');
        return redirect()->route('plano.index');
    }

    // ---- Fluxo: Verificação ----------------------------------------------
    function verificarForm(string $uuid): mixed
    {
        $service = new PlanoSoldagemService;
        $plano   = $service->find($uuid);
        if (!$plano) {
            return redirect()->route('plano.index')->withError('Plano não encontrado.');
        }
        $logs = $service->logsDo((int) $plano->id);
        return view('plano.verificar', compact('plano', 'service', 'logs'));
    }

    function verificar(): mixed
    {
        $service = new PlanoSoldagemService;
        $uuid = (string) request()->get('uuid');
        $service->verificar($uuid, (string) request()->get('de_acordo'), (string) request()->get('observacao'));
        notification()->success('Verificação registrada.');
        return redirect()->route('plano.index');
    }

    // ---- Fluxo: Aprovação ------------------------------------------------
    function aprovarForm(string $uuid): mixed
    {
        $service = new PlanoSoldagemService;
        $plano   = $service->find($uuid);
        if (!$plano) {
            return redirect()->route('plano.index')->withError('Plano não encontrado.');
        }
        $logs = $service->logsDo((int) $plano->id);
        return view('plano.aprovar', compact('plano', 'service', 'logs'));
    }

    function aprovar(): mixed
    {
        $service = new PlanoSoldagemService;
        $uuid = (string) request()->get('uuid');
        $service->aprovar($uuid, (string) request()->get('acao'), (string) request()->get('observacao'));
        notification()->success('Aprovação registrada.');
        return redirect()->route('plano.index');
    }
}
