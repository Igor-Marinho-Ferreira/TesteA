<?php

namespace src\app\controllers;

use src\app\requests\StoreRqsRequest;
use src\app\services\RqsService;
use src\app\services\SoldadorService;
use src\app\services\EpsService;
use src\app\services\FormularioQualificacaoService;

class RqsController
{
    function __construct()
    {
    }

    private function opcoes(): array
    {
        return [
            'soldadores' => (new SoldadorService)->listAll(),
            'epsList'    => (new EpsService)->listAll(),
            'montagem'   => (new FormularioQualificacaoService)->paraMontagem(),
        ];
    }

    function index(): mixed
    {
        $service = new RqsService;
        $itens   = $service->listAll();
        return view('rqs.list', compact('itens', 'service'));
    }

    function create(): mixed
    {
        $service    = new RqsService;
        $editing    = null;
        $dobramento = [];
        $usado = [];
        $faixa = [];
        $proximo = $service->proximoCertificado();
        return view('rqs.form', array_merge(compact('editing', 'service', 'dobramento', 'usado', 'faixa', 'proximo'), $this->opcoes()));
    }

    function store(StoreRqsRequest $request): mixed
    {
        $request->execute();
        (new RqsService)->store($request->get());
        notification()->success('RQS registrado com sucesso!');
        return redirect()->route('rqs.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new RqsService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('rqs.index')->withError('RQS não encontrado.');
        }
        $dobramento = $service->dobramentoDo((int) $editing->id);
        $usado = $service->variaveis($editing->variaveis_usado ?? null);
        $faixa = $service->variaveis($editing->variaveis_faixa ?? null);
        $proximo = $editing->certificado_numero;
        return view('rqs.form', array_merge(compact('editing', 'service', 'dobramento', 'usado', 'faixa', 'proximo'), $this->opcoes()));
    }

    function update(StoreRqsRequest $request): mixed
    {
        $request->execute();
        $service = new RqsService;
        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('rqs.index')->withError('RQS não encontrado.');
        }
        $service->update($uuid, $request->get());
        notification()->success('RQS atualizado com sucesso!');
        return redirect()->route('rqs.index');
    }

    function destroy(): mixed
    {
        $service = new RqsService;
        $uuid    = (string) request()->get('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('rqs.index')->withError('RQS não encontrado.');
        }
        $service->delete($uuid);
        notification()->success('RQS excluído com sucesso!');
        return redirect()->route('rqs.index');
    }

    function enviar(string $uuid): mixed
    {
        (new RqsService)->enviarEngenharia($uuid);
        notification()->success('RQS enviado para a Engenharia de Processos.');
        return redirect()->route('rqs.index');
    }

    function aprovar(string $uuid): mixed
    {
        (new RqsService)->aprovar($uuid);
        notification()->success('RQS aprovado pela Engenharia.');
        return redirect()->route('rqs.index');
    }
}
