<?php

namespace src\app\controllers;

use src\app\requests\StoreEstacaoQualificacaoRequest;
use src\app\services\EstacaoQualificacaoService;
use src\app\services\QualificacaoService;
use src\app\services\PosicaoQualificacaoService;

class EstacaoQualificacaoController
{
    function __construct()
    {
    }

    private function opcoes(): array
    {
        return [
            'qualificacoes' => (new QualificacaoService)->listAll(),
            'posicoes'      => (new PosicaoQualificacaoService)->listAll(),
            'posService'    => new PosicaoQualificacaoService,
        ];
    }

    function index(): mixed
    {
        $service = new EstacaoQualificacaoService;
        $itens   = $service->listAll();
        $editing = null;
        return view('estacao_qualificacao.index', array_merge(compact('itens', 'editing', 'service'), $this->opcoes()));
    }

    function store(StoreEstacaoQualificacaoRequest $request): mixed
    {
        $request->execute();
        (new EstacaoQualificacaoService)->store($request->get());
        notification()->success('Vínculo Estação × Qualificação cadastrado com sucesso!');
        return redirect()->route('estacao_qualificacao.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new EstacaoQualificacaoService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('estacao_qualificacao.index')->withError('Vínculo não encontrado.');
        }
        $itens = $service->listAll();
        return view('estacao_qualificacao.index', array_merge(compact('itens', 'editing', 'service'), $this->opcoes()));
    }

    function update(StoreEstacaoQualificacaoRequest $request): mixed
    {
        $request->execute();
        $service = new EstacaoQualificacaoService;

        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('estacao_qualificacao.index')->withError('Vínculo não encontrado.');
        }
        $service->update($uuid, $request->get());
        notification()->success('Vínculo atualizado com sucesso!');
        return redirect()->route('estacao_qualificacao.index');
    }

    /** "Excluir" apenas inativa o vínculo (não há exclusão física). */
    function destroy(): mixed
    {
        $service = new EstacaoQualificacaoService;
        $uuid    = (string) request()->get('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('estacao_qualificacao.index')->withError('Vínculo não encontrado.');
        }
        $service->inativar($uuid);
        notification()->success('Vínculo inativado (mantido para rastreabilidade).');
        return redirect()->route('estacao_qualificacao.index');
    }

    function ativar(string $uuid): mixed
    {
        (new EstacaoQualificacaoService)->ativar($uuid);
        notification()->success('Vínculo reativado.');
        return redirect()->route('estacao_qualificacao.index');
    }
}
