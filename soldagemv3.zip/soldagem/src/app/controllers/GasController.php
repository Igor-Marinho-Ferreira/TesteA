<?php

namespace src\app\controllers;

use src\app\requests\StoreGasRequest;
use src\app\services\GasService;

class GasController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $service     = new GasService;
        $itens       = $service->listAll();
        $editing     = null;
        $componentes = [];
        return view('gas.index', compact('itens', 'editing', 'componentes'));
    }

    function store(StoreGasRequest $request): mixed
    {
        $service = new GasService;

        $request->execute();
        $gas = trim((string) $request->input('gas'));
        if ($service->existeDuplicado($gas)) {
            return redirect()->back()->withError('Já existe um gás com esse nome.');
        }

        $service->store($request->get());
        notification()->success('Gás cadastrado com sucesso!');
        return redirect()->route('gas.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new GasService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('gas.index')->withError('Gás não encontrado.');
        }
        $itens       = $service->listAll();
        $componentes = $service->componentesDo((int) $editing->id);
        return view('gas.index', compact('itens', 'editing', 'componentes'));
    }

    function update(StoreGasRequest $request): mixed
    {
        $service = new GasService;

        $request->execute();
        $uuid = (string) $request->input('uuid');
        $gas  = $service->find($uuid);
        if (!$gas) {
            return redirect()->route('gas.index')->withError('Gás não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('gas.index')->withError('Gás vinculado a um Plano de Soldagem: edição não permitida.');
        }

        $nome = trim((string) $request->input('gas'));
        if ($service->existeDuplicado($nome, $uuid)) {
            return redirect()->back()->withError('Já existe um gás com esse nome.');
        }

        $service->update($uuid, $request->get());
        notification()->success('Gás atualizado com sucesso!');
        return redirect()->route('gas.index');
    }

    function destroy(): mixed
    {
        $service = new GasService;
        $uuid    = (string) request()->get('uuid');

        $gas = $service->find($uuid);
        if (!$gas) {
            return redirect()->route('gas.index')->withError('Gás não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('gas.index')->withError('Gás vinculado a um Plano de Soldagem: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Gás excluído com sucesso!');
        return redirect()->route('gas.index');
    }
}
