<?php

namespace src\app\controllers;

use src\app\requests\StoreModeloVagaoRequest;
use src\app\services\ModeloVagaoService;

class ModeloVagaoController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new ModeloVagaoService)->listAll();
        $editing = null;
        return view('modelo_vagao.index', compact('itens', 'editing'));
    }

    function store(StoreModeloVagaoRequest $request): mixed
    {
        $request->execute();
        $service = new ModeloVagaoService;

        $valor = trim((string) $request->input('modelo'));
        if ($service->existeDuplicado($valor)) {
            return redirect()->back()->withError('Já existe um modelo com esse nome.');
        }

        $service->store(['modelo' => $valor]);
        notification()->success('Modelo cadastrado com sucesso!');
        return redirect()->route('modelo_vagao.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new ModeloVagaoService)->find($uuid);
        if (!$editing) {
            return redirect()->route('modelo_vagao.index')->withError('Modelo não encontrado.');
        }
        $itens = (new ModeloVagaoService)->listAll();
        return view('modelo_vagao.index', compact('itens', 'editing'));
    }

    function update(StoreModeloVagaoRequest $request): mixed
    {
        $request->execute();
        $service = new ModeloVagaoService;

        $uuid = (string) $request->input('uuid');
        $m    = $service->find($uuid);
        if (!$m) {
            return redirect()->route('modelo_vagao.index')->withError('Modelo não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('modelo_vagao.index')->withError('Modelo vinculado a um Checklist de Soldagem: edição não permitida.');
        }

        $valor = trim((string) $request->input('modelo'));
        if ($service->existeDuplicado($valor, $uuid)) {
            return redirect()->back()->withError('Já existe um modelo com esse nome.');
        }

        $service->update($uuid, ['modelo' => $valor]);
        notification()->success('Modelo atualizado com sucesso!');
        return redirect()->route('modelo_vagao.index');
    }

    function destroy(): mixed
    {
        $service = new ModeloVagaoService;
        $uuid    = (string) request()->get('uuid');

        $m = $service->find($uuid);
        if (!$m) {
            return redirect()->route('modelo_vagao.index')->withError('Modelo não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('modelo_vagao.index')->withError('Modelo vinculado a um Checklist de Soldagem: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Modelo excluído com sucesso!');
        return redirect()->route('modelo_vagao.index');
    }
}
