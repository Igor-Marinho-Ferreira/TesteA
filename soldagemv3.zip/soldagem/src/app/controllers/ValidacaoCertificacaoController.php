<?php

namespace src\app\controllers;

use src\app\services\ValidacaoCertificacaoService;

class ValidacaoCertificacaoController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $service = new ValidacaoCertificacaoService;
        $logs    = $service->logs();
        $resultado = null;
        return view('validacao.index', compact('logs', 'resultado'));
    }

    /** Simula/executa a validação de um soldador em uma estação. */
    function validar(): mixed
    {
        $matricula = trim((string) request()->get('matricula'));
        $estacao   = trim((string) request()->get('estacao'));

        if ($matricula === '' || $estacao === '') {
            return redirect()->route('validacao.index')->withError('Informe matrícula e estação.');
        }

        $service   = new ValidacaoCertificacaoService;
        $resultado = $service->validar($matricula, $estacao);

        if ($resultado['resultado'] === 'validado') {
            notification()->success('Validação: ' . $resultado['motivo']);
        } else {
            notification()->warning('Bloqueado: ' . $resultado['motivo']);
        }
        return redirect()->route('validacao.index');
    }
}
