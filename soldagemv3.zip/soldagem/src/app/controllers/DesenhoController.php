<?php

namespace src\app\controllers;

use src\app\requests\StoreDesenhoRequest;
use src\app\services\DesenhoService;

class DesenhoController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new DesenhoService)->listAll();
        $editing = null;
        return view('desenho.index', compact('itens', 'editing'));
    }

    function store(StoreDesenhoRequest $request): mixed
    {
        $request->execute();
        $service = new DesenhoService;

        if ($erro = $service->imagemError()) {
            return redirect()->back()->withError($erro);
        }
        $numero = trim((string) $request->input('numero'));
        if ($service->existeDuplicado($numero)) {
            return redirect()->back()->withError('Já existe um desenho com esse número.');
        }

        $service->store(['numero' => $numero]);
        notification()->success('Desenho cadastrado com sucesso!');
        return redirect()->route('desenho.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new DesenhoService)->find($uuid);
        if (!$editing) {
            return redirect()->route('desenho.index')->withError('Desenho não encontrado.');
        }
        $itens = (new DesenhoService)->listAll();
        return view('desenho.index', compact('itens', 'editing'));
    }

    function update(StoreDesenhoRequest $request): mixed
    {
        $request->execute();
        $service = new DesenhoService;

        $uuid = (string) $request->input('uuid');
        $d    = $service->find($uuid);
        if (!$d) {
            return redirect()->route('desenho.index')->withError('Desenho não encontrado.');
        }
        if ($erro = $service->imagemError()) {
            return redirect()->back()->withError($erro);
        }
        $numero = trim((string) $request->input('numero'));
        if ($service->existeDuplicado($numero, $uuid)) {
            return redirect()->back()->withError('Já existe um desenho com esse número.');
        }

        $service->update($uuid, ['numero' => $numero]);
        notification()->success('Desenho atualizado com sucesso!');
        return redirect()->route('desenho.index');
    }

    function destroy(): mixed
    {
        $service = new DesenhoService;
        $uuid    = (string) request()->get('uuid');
        $d = $service->find($uuid);
        if (!$d) {
            return redirect()->route('desenho.index')->withError('Desenho não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('desenho.index')->withError('Desenho vinculado a um Plano de Soldagem: exclusão não permitida.');
        }
        $service->delete($uuid);
        notification()->success('Desenho excluído com sucesso!');
        return redirect()->route('desenho.index');
    }
}
