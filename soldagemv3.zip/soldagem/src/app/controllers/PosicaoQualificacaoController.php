<?php

namespace src\app\controllers;

use src\app\requests\StorePosicaoQualificacaoRequest;
use src\app\services\PosicaoQualificacaoService;

class PosicaoQualificacaoController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $service = new PosicaoQualificacaoService;
        $itens   = $service->listAll();
        $editing = null;
        return view('posicao_qualificacao.index', compact('itens', 'editing', 'service'));
    }

    function store(StorePosicaoQualificacaoRequest $request): mixed
    {
        $request->execute();
        $service = new PosicaoQualificacaoService;

        $dados = $service->sanitize($request->get());
        if ($service->duplicadoCombo($dados['tipo'], $dados['posicao'], $dados['progressao'])) {
            return redirect()->back()->withError('Essa combinação de tipo e posição já está cadastrada.');
        }

        $service->store($dados);
        notification()->success('Posição de qualificação cadastrada com sucesso!');
        return redirect()->route('posicao_qualificacao.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new PosicaoQualificacaoService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('posicao_qualificacao.index')->withError('Posição não encontrada.');
        }
        $itens = $service->listAll();
        return view('posicao_qualificacao.index', compact('itens', 'editing', 'service'));
    }

    function update(StorePosicaoQualificacaoRequest $request): mixed
    {
        $request->execute();
        $service = new PosicaoQualificacaoService;

        $uuid = (string) $request->input('uuid');
        $p    = $service->find($uuid);
        if (!$p) {
            return redirect()->route('posicao_qualificacao.index')->withError('Posição não encontrada.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('posicao_qualificacao.index')->withError('Posição vinculada a soldador/formulário: edição não permitida.');
        }

        $dados = $service->sanitize($request->get());
        if ($service->duplicadoCombo($dados['tipo'], $dados['posicao'], $dados['progressao'], $uuid)) {
            return redirect()->back()->withError('Essa combinação de tipo e posição já está cadastrada.');
        }

        $service->update($uuid, $dados);
        notification()->success('Posição de qualificação atualizada com sucesso!');
        return redirect()->route('posicao_qualificacao.index');
    }

    function destroy(): mixed
    {
        $service = new PosicaoQualificacaoService;
        $uuid    = (string) request()->get('uuid');

        $p = $service->find($uuid);
        if (!$p) {
            return redirect()->route('posicao_qualificacao.index')->withError('Posição não encontrada.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('posicao_qualificacao.index')->withError('Posição vinculada a soldador/formulário: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Posição de qualificação excluída com sucesso!');
        return redirect()->route('posicao_qualificacao.index');
    }
}
