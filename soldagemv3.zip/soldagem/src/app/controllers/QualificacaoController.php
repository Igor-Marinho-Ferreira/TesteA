<?php

namespace src\app\controllers;

use src\app\requests\StoreQualificacaoRequest;
use src\app\services\QualificacaoService;

class QualificacaoController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new QualificacaoService)->listAll();
        $editing = null;
        return view('qualificacao.index', compact('itens', 'editing'));
    }

    function store(StoreQualificacaoRequest $request): mixed
    {
        $request->execute();
        $service = new QualificacaoService;

        $dados = $service->sanitize($request->get());
        if ($service->existeDuplicado($dados['qualificacao'])) {
            return redirect()->back()->withError('Já existe uma qualificação com esse nome.');
        }

        $service->store($dados);
        notification()->success('Qualificação cadastrada com sucesso!');
        return redirect()->route('qualificacao.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new QualificacaoService)->find($uuid);
        if (!$editing) {
            return redirect()->route('qualificacao.index')->withError('Qualificação não encontrada.');
        }
        $itens = (new QualificacaoService)->listAll();
        return view('qualificacao.index', compact('itens', 'editing'));
    }

    function update(StoreQualificacaoRequest $request): mixed
    {
        $request->execute();
        $service = new QualificacaoService;

        $uuid = (string) $request->input('uuid');
        $q    = $service->find($uuid);
        if (!$q) {
            return redirect()->route('qualificacao.index')->withError('Qualificação não encontrada.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('qualificacao.index')->withError('Qualificação vinculada a soldador/formulário: edição não permitida.');
        }

        $dados = $service->sanitize($request->get());
        if ($service->existeDuplicado($dados['qualificacao'], $uuid)) {
            return redirect()->back()->withError('Já existe uma qualificação com esse nome.');
        }

        $service->update($uuid, $dados);
        notification()->success('Qualificação atualizada com sucesso!');
        return redirect()->route('qualificacao.index');
    }

    function destroy(): mixed
    {
        $service = new QualificacaoService;
        $uuid    = (string) request()->get('uuid');

        $q = $service->find($uuid);
        if (!$q) {
            return redirect()->route('qualificacao.index')->withError('Qualificação não encontrada.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('qualificacao.index')->withError('Qualificação vinculada a soldador/formulário: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Qualificação excluída com sucesso!');
        return redirect()->route('qualificacao.index');
    }
}
