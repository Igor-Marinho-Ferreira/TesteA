<?php

namespace src\app\controllers;

use src\app\requests\StoreClienteRequest;
use src\app\services\ClienteService;

class ClienteController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new ClienteService)->listAll();
        $editing = null;
        return view('cliente.index', compact('itens', 'editing'));
    }

    function store(StoreClienteRequest $request): mixed
    {
        $request->execute();
        $service = new ClienteService;

        $valor = trim((string) $request->input('cliente'));
        if ($service->existeDuplicado($valor)) {
            return redirect()->back()->withError('Já existe um cliente com esse nome.');
        }

        $service->store(['cliente' => $valor]);
        notification()->success('Cliente cadastrado com sucesso!');
        return redirect()->route('cliente.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new ClienteService)->find($uuid);
        if (!$editing) {
            return redirect()->route('cliente.index')->withError('Cliente não encontrado.');
        }
        $itens = (new ClienteService)->listAll();
        return view('cliente.index', compact('itens', 'editing'));
    }

    function update(StoreClienteRequest $request): mixed
    {
        $request->execute();
        $service = new ClienteService;

        $uuid = (string) $request->input('uuid');
        $c    = $service->find($uuid);
        if (!$c) {
            return redirect()->route('cliente.index')->withError('Cliente não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('cliente.index')->withError('Cliente vinculado a um Checklist de Soldagem: edição não permitida.');
        }

        $valor = trim((string) $request->input('cliente'));
        if ($service->existeDuplicado($valor, $uuid)) {
            return redirect()->back()->withError('Já existe um cliente com esse nome.');
        }

        $service->update($uuid, ['cliente' => $valor]);
        notification()->success('Cliente atualizado com sucesso!');
        return redirect()->route('cliente.index');
    }

    function destroy(): mixed
    {
        $service = new ClienteService;
        $uuid    = (string) request()->get('uuid');

        $c = $service->find($uuid);
        if (!$c) {
            return redirect()->route('cliente.index')->withError('Cliente não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('cliente.index')->withError('Cliente vinculado a um Checklist de Soldagem: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Cliente excluído com sucesso!');
        return redirect()->route('cliente.index');
    }
}
