<?php

namespace src\app\controllers;

class MenuController
{
    /**
     * Tela de menu principal do Checklist de Inspeção de Soldagem.
     */
    function index(): mixed
    {
        return view('menu.index', ['usuario' => user()]);
    }
}
