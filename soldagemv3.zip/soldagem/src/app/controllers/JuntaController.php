<?php

namespace src\app\controllers;

use src\app\requests\StoreJuntaRequest;
use src\app\services\JuntaService;

class JuntaController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new JuntaService)->listAll();
        $editing = null;
        return view('junta.index', compact('itens', 'editing'));
    }

    function store(StoreJuntaRequest $request): mixed
    {
        $request->execute();
        $service = new JuntaService;

        $valor     = $service->normalizarJunta((string) $request->input('junta'));
        $descricao = $service->normalizarJunta((string) $request->input('descricao'));
        if ($service->existeDuplicado($valor)) {
            return redirect()->back()->withError('Já existe uma junta com esse nome.');
        }

        $service->store(['junta' => $valor, 'descricao' => $descricao ?: null]);
        notification()->success('Junta cadastrada com sucesso!');
        return redirect()->route('junta.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new JuntaService)->find($uuid);
        if (!$editing) {
            return redirect()->route('junta.index')->withError('Junta não encontrada.');
        }
        $itens = (new JuntaService)->listAll();
        return view('junta.index', compact('itens', 'editing'));
    }

    function update(StoreJuntaRequest $request): mixed
    {
        $request->execute();
        $service = new JuntaService;

        $uuid  = (string) $request->input('uuid');
        $junta = $service->find($uuid);
        if (!$junta) {
            return redirect()->route('junta.index')->withError('Junta não encontrada.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('junta.index')->withError('Junta vinculada a um Plano de Soldagem: edição não permitida.');
        }

        $valor     = $service->normalizarJunta((string) $request->input('junta'));
        $descricao = $service->normalizarJunta((string) $request->input('descricao'));
        if ($service->existeDuplicado($valor, $uuid)) {
            return redirect()->back()->withError('Já existe uma junta com esse nome.');
        }

        $service->update($uuid, ['junta' => $valor, 'descricao' => $descricao ?: null]);
        notification()->success('Junta atualizada com sucesso!');
        return redirect()->route('junta.index');
    }

    function destroy(): mixed
    {
        $service = new JuntaService;
        $uuid    = (string) request()->get('uuid');

        $junta = $service->find($uuid);
        if (!$junta) {
            return redirect()->route('junta.index')->withError('Junta não encontrada.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('junta.index')->withError('Junta vinculada a um Plano de Soldagem: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Junta excluída com sucesso!');
        return redirect()->route('junta.index');
    }
}
