<?php

namespace src\app\controllers;

use src\app\requests\StoreEstagioSoldagemRequest;
use src\app\services\EstagioSoldagemService;

class EstagioSoldagemController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new EstagioSoldagemService)->listAll();
        $editing = null;
        return view('estagio_soldagem.index', compact('itens', 'editing'));
    }

    function store(StoreEstagioSoldagemRequest $request): mixed
    {
        $request->execute();
        $service = new EstagioSoldagemService;

        $valor = trim((string) $request->input('estagio'));
        if ($service->existeDuplicado($valor)) {
            return redirect()->back()->withError('Já existe um estágio com esse nome.');
        }

        $service->store(['estagio' => $valor]);
        notification()->success('Estágio de soldagem cadastrado com sucesso!');
        return redirect()->route('estagio_soldagem.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new EstagioSoldagemService)->find($uuid);
        if (!$editing) {
            return redirect()->route('estagio_soldagem.index')->withError('Estágio não encontrado.');
        }
        $itens = (new EstagioSoldagemService)->listAll();
        return view('estagio_soldagem.index', compact('itens', 'editing'));
    }

    function update(StoreEstagioSoldagemRequest $request): mixed
    {
        $request->execute();
        $service = new EstagioSoldagemService;

        $uuid = (string) $request->input('uuid');
        $es   = $service->find($uuid);
        if (!$es) {
            return redirect()->route('estagio_soldagem.index')->withError('Estágio não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('estagio_soldagem.index')->withError('Estágio vinculado a um Checklist de Soldagem: edição não permitida.');
        }

        $valor = trim((string) $request->input('estagio'));
        if ($service->existeDuplicado($valor, $uuid)) {
            return redirect()->back()->withError('Já existe um estágio com esse nome.');
        }

        $service->update($uuid, ['estagio' => $valor]);
        notification()->success('Estágio de soldagem atualizado com sucesso!');
        return redirect()->route('estagio_soldagem.index');
    }

    function destroy(): mixed
    {
        $service = new EstagioSoldagemService;
        $uuid    = (string) request()->get('uuid');

        $es = $service->find($uuid);
        if (!$es) {
            return redirect()->route('estagio_soldagem.index')->withError('Estágio não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('estagio_soldagem.index')->withError('Estágio vinculado a um Checklist de Soldagem: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Estágio de soldagem excluído com sucesso!');
        return redirect()->route('estagio_soldagem.index');
    }
}
