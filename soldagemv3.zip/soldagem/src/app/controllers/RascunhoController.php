<?php

namespace src\app\controllers;

use src\app\services\RascunhoService;
use src\support\Json;

class RascunhoController
{
    function __construct()
    {
    }

    /** GET: retorna o rascunho salvo (payload) para (modulo, ref) do usuário. */
    function obter(): mixed
    {
        $modulo = trim((string) request()->get('modulo'));
        $ref    = trim((string) request()->get('ref'));
        $payload = (new RascunhoService)->obter($modulo, $ref);
        return Json::return(['payload' => $payload], 200);
    }

    /** POST: salva/atualiza o rascunho. */
    function salvar(): mixed
    {
        $modulo  = trim((string) request()->get('modulo'));
        $ref     = trim((string) request()->get('ref'));
        $payload = (string) (request()->get('payload') ?? '');
        $ok = (new RascunhoService)->salvar($modulo, $ref, $payload);
        return Json::return(['ok' => $ok], $ok ? 200 : 422);
    }

    /** POST: descarta o rascunho. */
    function descartar(): mixed
    {
        $modulo = trim((string) request()->get('modulo'));
        $ref    = trim((string) request()->get('ref'));
        $ok = (new RascunhoService)->descartar($modulo, $ref);
        return Json::return(['ok' => $ok], 200);
    }
}
