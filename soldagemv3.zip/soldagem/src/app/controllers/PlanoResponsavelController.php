<?php

namespace src\app\controllers;

use src\app\requests\StorePlanoResponsavelRequest;
use src\app\services\PlanoResponsavelService;

class PlanoResponsavelController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new PlanoResponsavelService)->listAll();
        $editing = null;
        return view('plano_responsavel.index', compact('itens', 'editing'));
    }

    function store(StorePlanoResponsavelRequest $request): mixed
    {
        $request->execute();
        (new PlanoResponsavelService)->store($request->get());
        notification()->success('Responsável cadastrado com sucesso!');
        return redirect()->route('plano_responsavel.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new PlanoResponsavelService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('plano_responsavel.index')->withError('Responsável não encontrado.');
        }
        $itens = $service->listAll();
        return view('plano_responsavel.index', compact('itens', 'editing'));
    }

    function update(StorePlanoResponsavelRequest $request): mixed
    {
        $request->execute();
        $service = new PlanoResponsavelService;
        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('plano_responsavel.index')->withError('Responsável não encontrado.');
        }
        $service->update($uuid, $request->get());
        notification()->success('Responsável atualizado com sucesso!');
        return redirect()->route('plano_responsavel.index');
    }

    function destroy(): mixed
    {
        $service = new PlanoResponsavelService;
        $uuid    = (string) request()->get('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('plano_responsavel.index')->withError('Responsável não encontrado.');
        }
        $service->delete($uuid);
        notification()->success('Responsável excluído com sucesso!');
        return redirect()->route('plano_responsavel.index');
    }
}
