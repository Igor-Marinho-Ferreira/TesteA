<?php

namespace src\app\controllers;

use src\app\requests\StoreEnsaioVisualRequest;
use src\app\services\EnsaioVisualService;
use src\app\services\EpsService;

class EnsaioVisualController
{
    function __construct()
    {
    }

    private function opcoes(): array
    {
        return ['epsList' => (new EpsService)->listAll()];
    }

    function index(): mixed
    {
        $service = new EnsaioVisualService;
        $itens   = $service->listAll();
        return view('ensaio.list', compact('itens', 'service'));
    }

    function create(): mixed
    {
        $service     = new EnsaioVisualService;
        $editing     = null;
        $instrumentos = [];
        $ocorrencias = [];
        $proximo     = $service->proximoNumero();
        return view('ensaio.form', array_merge(compact('editing', 'service', 'instrumentos', 'ocorrencias', 'proximo'), $this->opcoes()));
    }

    function store(StoreEnsaioVisualRequest $request): mixed
    {
        $request->execute();
        (new EnsaioVisualService)->store($request->get());
        notification()->success('Relatório de ensaio visual registrado com sucesso!');
        return redirect()->route('ensaio.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new EnsaioVisualService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('ensaio.index')->withError('Relatório não encontrado.');
        }
        $instrumentos = [];
        foreach ($service->instrumentosDo((int) $editing->id) as $i) {
            $instrumentos[$i->categoria] = $i;
        }
        $ocorrencias = $service->ocorrenciasDo((int) $editing->id);
        $proximo = $editing->numero_relatorio;
        return view('ensaio.form', array_merge(compact('editing', 'service', 'instrumentos', 'ocorrencias', 'proximo'), $this->opcoes()));
    }

    function update(StoreEnsaioVisualRequest $request): mixed
    {
        $request->execute();
        $service = new EnsaioVisualService;
        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('ensaio.index')->withError('Relatório não encontrado.');
        }
        $service->update($uuid, $request->get());
        notification()->success('Relatório de ensaio visual atualizado com sucesso!');
        return redirect()->route('ensaio.index');
    }

    function destroy(): mixed
    {
        $service = new EnsaioVisualService;
        $uuid    = (string) request()->get('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('ensaio.index')->withError('Relatório não encontrado.');
        }
        $service->delete($uuid);
        notification()->success('Relatório excluído com sucesso!');
        return redirect()->route('ensaio.index');
    }
}
