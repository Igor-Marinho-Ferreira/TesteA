<?php

namespace src\app\controllers;

use src\app\requests\StoreSoldadorRequest;
use src\app\services\SoldadorService;
use src\app\services\TreinamentoService;
use src\app\services\QualificacaoService;
use src\app\services\PosicaoQualificacaoService;

class SoldadorController
{
    function __construct()
    {
    }

    private function opcoes(): array
    {
        return [
            'treinamentos' => (new TreinamentoService)->listAll(),
            'qualificacoes' => (new QualificacaoService)->listAll(),
            'posicoes'     => (new PosicaoQualificacaoService)->listAll(),
            'posService'   => new PosicaoQualificacaoService,
        ];
    }

    function index(): mixed
    {
        $service = new SoldadorService;
        $itens   = $service->listAll();
        $editing = null;
        $sel     = ['treinamentos' => [], 'processos' => [], 'posicoes' => []];
        return view('soldador.index', array_merge(compact('itens', 'editing', 'service', 'sel'), $this->opcoes()));
    }

    function store(StoreSoldadorRequest $request): mixed
    {
        $request->execute();
        $service = new SoldadorService;

        if ($service->existeSinete(trim((string) $request->input('sinete')))) {
            return redirect()->back()->withError('Já existe um soldador com esse sinete.');
        }

        $service->store($request->get());
        notification()->success('Soldador cadastrado com sucesso!');
        return redirect()->route('soldador.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new SoldadorService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('soldador.index')->withError('Soldador não encontrado.');
        }
        $itens = $service->listAll();
        $vinc  = $service->vinculosDo((int) $editing->id);
        $sel   = [
            'treinamentos' => $service->treinamentosDo((int) $editing->id),
            'processos'    => $vinc['processos'],
            'posicoes'     => $vinc['posicoes'],
        ];
        return view('soldador.index', array_merge(compact('itens', 'editing', 'service', 'sel'), $this->opcoes()));
    }

    function update(StoreSoldadorRequest $request): mixed
    {
        $request->execute();
        $service = new SoldadorService;

        $uuid = (string) $request->input('uuid');
        $s    = $service->find($uuid);
        if (!$s) {
            return redirect()->route('soldador.index')->withError('Soldador não encontrado.');
        }
        if ($service->existeSinete(trim((string) $request->input('sinete')), $uuid)) {
            return redirect()->back()->withError('Já existe um soldador com esse sinete.');
        }

        $service->update($uuid, $request->get());
        notification()->success('Soldador atualizado com sucesso!');
        return redirect()->route('soldador.index');
    }

    function destroy(): mixed
    {
        $service = new SoldadorService;
        $uuid    = (string) request()->get('uuid');
        $s = $service->find($uuid);
        if (!$s) {
            return redirect()->route('soldador.index')->withError('Soldador não encontrado.');
        }
        $service->delete($uuid);
        notification()->success('Soldador excluído com sucesso!');
        return redirect()->route('soldador.index');
    }
}
