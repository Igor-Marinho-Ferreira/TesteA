<?php

namespace src\app\controllers;

use src\app\requests\StoreFormularioQualificacaoRequest;
use src\app\services\FormularioQualificacaoService;
use src\app\services\QualificacaoService;
use src\app\services\PosicaoQualificacaoService;

class FormularioQualificacaoController
{
    function __construct()
    {
    }

    private function opcoes(): array
    {
        return [
            'qualificacoes' => (new QualificacaoService)->listAll(),
            'posicoes'      => (new PosicaoQualificacaoService)->listAll(),
            'posService'    => new PosicaoQualificacaoService,
        ];
    }

    function index(): mixed
    {
        $service = new FormularioQualificacaoService;
        $itens   = $service->listAll();
        $editing = null;
        $selPos  = [];
        return view('formulario_qualificacao.index', array_merge(compact('itens', 'editing', 'selPos'), $this->opcoes()));
    }

    function store(StoreFormularioQualificacaoRequest $request): mixed
    {
        $request->execute();
        (new FormularioQualificacaoService)->store($request->get());
        notification()->success('Formulário de qualificação cadastrado com sucesso!');
        return redirect()->route('formulario_qualificacao.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new FormularioQualificacaoService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('formulario_qualificacao.index')->withError('Formulário não encontrado.');
        }
        $itens  = $service->listAll();
        $selPos = $service->posicoesDo((int) $editing->id);
        return view('formulario_qualificacao.index', array_merge(compact('itens', 'editing', 'selPos'), $this->opcoes()));
    }

    function update(StoreFormularioQualificacaoRequest $request): mixed
    {
        $request->execute();
        $service = new FormularioQualificacaoService;
        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('formulario_qualificacao.index')->withError('Formulário não encontrado.');
        }
        $service->update($uuid, $request->get());
        notification()->success('Formulário de qualificação atualizado com sucesso!');
        return redirect()->route('formulario_qualificacao.index');
    }

    function destroy(): mixed
    {
        $service = new FormularioQualificacaoService;
        $uuid    = (string) request()->get('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('formulario_qualificacao.index')->withError('Formulário não encontrado.');
        }
        $service->delete($uuid);
        notification()->success('Formulário de qualificação excluído com sucesso!');
        return redirect()->route('formulario_qualificacao.index');
    }
}
