<?php

namespace src\app\controllers;

use src\app\requests\StoreTreinamentoRequest;
use src\app\services\TreinamentoService;

class TreinamentoController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new TreinamentoService)->listAll();
        $editing = null;
        return view('treinamento.index', compact('itens', 'editing'));
    }

    function store(StoreTreinamentoRequest $request): mixed
    {
        $request->execute();
        $service = new TreinamentoService;

        $valor = trim((string) $request->input('treinamento'));
        if ($service->existeDuplicado($valor)) {
            return redirect()->back()->withError('Já existe um treinamento com esse nome.');
        }

        $service->store(['treinamento' => $valor]);
        notification()->success('Treinamento cadastrado com sucesso!');
        return redirect()->route('treinamento.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new TreinamentoService)->find($uuid);
        if (!$editing) {
            return redirect()->route('treinamento.index')->withError('Treinamento não encontrado.');
        }
        $itens = (new TreinamentoService)->listAll();
        return view('treinamento.index', compact('itens', 'editing'));
    }

    function update(StoreTreinamentoRequest $request): mixed
    {
        $request->execute();
        $service = new TreinamentoService;

        $uuid = (string) $request->input('uuid');
        $t    = $service->find($uuid);
        if (!$t) {
            return redirect()->route('treinamento.index')->withError('Treinamento não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('treinamento.index')->withError('Treinamento vinculado a um Registro de Qualificação: edição não permitida.');
        }

        $valor = trim((string) $request->input('treinamento'));
        if ($service->existeDuplicado($valor, $uuid)) {
            return redirect()->back()->withError('Já existe um treinamento com esse nome.');
        }

        $service->update($uuid, ['treinamento' => $valor]);
        notification()->success('Treinamento atualizado com sucesso!');
        return redirect()->route('treinamento.index');
    }

    function destroy(): mixed
    {
        $service = new TreinamentoService;
        $uuid    = (string) request()->get('uuid');

        $t = $service->find($uuid);
        if (!$t) {
            return redirect()->route('treinamento.index')->withError('Treinamento não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('treinamento.index')->withError('Treinamento vinculado a um Registro de Qualificação: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Treinamento excluído com sucesso!');
        return redirect()->route('treinamento.index');
    }
}
