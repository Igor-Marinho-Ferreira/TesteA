<?php

namespace src\app\controllers;

use src\app\requests\StoreMetalBaseRequest;
use src\app\services\MetalBaseService;

class MetalBaseController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new MetalBaseService)->listAll();
        $editing = null;
        return view('metal_base.index', compact('itens', 'editing'));
    }

    function store(StoreMetalBaseRequest $request): mixed
    {
        $request->execute();
        $service = new MetalBaseService;

        $valor = mb_strtoupper(trim((string) $request->input('metal_base')), 'UTF-8');
        if ($service->existeDuplicado($valor)) {
            return redirect()->back()->withError('Já existe um metal base com esse nome.');
        }

        $service->store(['metal_base' => $valor]);
        notification()->success('Metal base cadastrado com sucesso!');
        return redirect()->route('metal_base.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new MetalBaseService)->find($uuid);
        if (!$editing) {
            return redirect()->route('metal_base.index')->withError('Metal base não encontrado.');
        }
        $itens = (new MetalBaseService)->listAll();
        return view('metal_base.index', compact('itens', 'editing'));
    }

    function update(StoreMetalBaseRequest $request): mixed
    {
        $request->execute();
        $service = new MetalBaseService;

        $uuid = (string) $request->input('uuid');
        $mb   = $service->find($uuid);
        if (!$mb) {
            return redirect()->route('metal_base.index')->withError('Metal base não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('metal_base.index')->withError('Metal base vinculado a um Plano de Soldagem: edição não permitida.');
        }

        $valor = mb_strtoupper(trim((string) $request->input('metal_base')), 'UTF-8');
        if ($service->existeDuplicado($valor, $uuid)) {
            return redirect()->back()->withError('Já existe um metal base com esse nome.');
        }

        $service->update($uuid, ['metal_base' => $valor]);
        notification()->success('Metal base atualizado com sucesso!');
        return redirect()->route('metal_base.index');
    }

    function destroy(): mixed
    {
        $service = new MetalBaseService;
        $uuid    = (string) request()->get('uuid');

        $mb = $service->find($uuid);
        if (!$mb) {
            return redirect()->route('metal_base.index')->withError('Metal base não encontrado.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('metal_base.index')->withError('Metal base vinculado a um Plano de Soldagem: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('Metal base excluído com sucesso!');
        return redirect()->route('metal_base.index');
    }
}
