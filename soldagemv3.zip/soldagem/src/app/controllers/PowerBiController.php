<?php

namespace src\app\controllers;

use src\app\database\entities\Soldador;
use src\app\database\entities\Checklist;
use src\app\database\entities\Eps;
use src\app\database\entities\PlanoSoldagem;
use src\app\database\entities\Rqs;
use src\app\database\entities\EnsaioVisual;
use Shuchkin\SimpleXLSXGen;

class PowerBiController
{
    /** Datasets disponibilizados para Power BI. */
    private const DATASETS = [
        'soldadores' => 'Soldadores',
        'checklist'  => 'Checklist de Soldagem',
        'eps'        => 'EPS',
        'planos'     => 'Planos de Soldagem',
        'rqs'        => 'RQS',
        'ensaios'    => 'Ensaios Visuais',
    ];

    function __construct()
    {
    }

    function index(): mixed
    {
        $datasets = self::DATASETS;
        return view('powerbi.index', compact('datasets'));
    }

    /** Exporta um dataset em Excel (disponibilização para Power BI). */
    function exportar(string $dataset): mixed
    {
        if (!array_key_exists($dataset, self::DATASETS)) {
            return redirect()->route('powerbi.index')->withError('Dataset inválido.');
        }

        $rows = $this->dados($dataset);
        $xlsx = SimpleXLSXGen::fromArray($rows);
        $xlsx->downloadAs("powerbi_{$dataset}.xlsx");
        die;
    }

    /**
     * @return array<int, array<int, mixed>> matriz com cabeçalho na 1ª linha
     */
    private function dados(string $dataset): array
    {
        switch ($dataset) {
            case 'soldadores':
                $reg = Soldador::select()->whereIsNull('deleted_at')->finish() ?: [];
                $out = [['Matrícula', 'Nome', 'Cargo', 'Sinete', 'Performance', 'Data Qualif.', 'Última Qualif.', 'Requalificação', 'Status', 'Status Qualif.']];
                foreach ($reg as $r) $out[] = [$r->matricula, $r->nome, $r->cargo, $r->sinete, $r->performance, $r->data_qualificacao, $r->data_ultima_qualificacao, $r->data_requalificacao, $r->status, $r->status_qualificacao];
                return $out;

            case 'checklist':
                $reg = Checklist::select()->whereIsNull('deleted_at')->finish() ?: [];
                $out = [['Data', 'Nº Viga/Vagão', 'Metal Base', 'Matrícula', 'Nome', 'Sinete', 'Status Verificação']];
                foreach ($reg as $r) $out[] = [$r->data, $r->numero_viga_vagao, $r->metal_base, $r->matricula, $r->nome, $r->sinete, $r->status_verificacao];
                return $out;

            case 'eps':
                $reg = Eps::select()->whereIsNull('deleted_at')->finish() ?: [];
                $out = [['Nº Documento', 'Nº RQPS', 'Status', 'Código', 'Metal Base', 'Tipo Junta', 'Processo', 'Tensão', 'Corrente']];
                foreach ($reg as $r) $out[] = [$r->numero_documento, $r->numero_rqps, $r->status, $r->codigo, $r->metal_base, $r->tipo_junta, $r->processo_soldagem, $r->tensao, $r->corrente];
                return $out;

            case 'planos':
                $reg = PlanoSoldagem::select()->whereIsNull('deleted_at')->finish() ?: [];
                $out = [['PS n.º', 'Rev', 'Título', 'Desenho', 'Data', 'Etapa', 'Status']];
                foreach ($reg as $r) $out[] = [$r->ps_numero, $r->rev, $r->titulo, $r->desenho_numero, $r->data, $r->etapa, $r->status];
                return $out;

            case 'rqs':
                $reg = Rqs::select()->whereIsNull('deleted_at')->finish() ?: [];
                $out = [['Certificado', 'Processo', 'Tipo', 'Data Teste', 'Exame Visual', 'Etapa', 'Status']];
                foreach ($reg as $r) $out[] = [$r->certificado_numero, $r->processo_soldagem, $r->tipo, $r->data_teste, $r->exame_visual_aceitavel, $r->etapa, $r->status];
                return $out;

            case 'ensaios':
                $reg = EnsaioVisual::select()->whereIsNull('deleted_at')->finish() ?: [];
                $out = [['Nº Relatório', 'Data', 'Tipo Junta', 'Material', 'Avaliação']];
                foreach ($reg as $r) $out[] = [$r->numero_relatorio, $r->data, $r->tipo_junta, $r->material, $r->avaliacao_resultado];
                return $out;
        }
        return [['Sem dados']];
    }
}
