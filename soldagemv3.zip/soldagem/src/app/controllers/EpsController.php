<?php

namespace src\app\controllers;

use src\app\requests\StoreEpsRequest;
use src\app\services\EpsService;
use src\app\services\JuntaService;

class EpsController
{
    function __construct()
    {
    }

    function index(): mixed
    {
        $itens   = (new EpsService)->listAll();
        $editing = null;
        $juntas  = (new JuntaService)->listAll();
        return view('eps.index', compact('itens', 'editing', 'juntas'));
    }

    function store(StoreEpsRequest $request): mixed
    {
        $request->execute();
        $service = new EpsService;

        $doc  = trim((string) $request->input('numero_documento'));
        $rqps = trim((string) $request->input('numero_rqps'));
        if ($service->existeDuplicado($doc, $rqps)) {
            return redirect()->back()->withError('Já existe EPS com esse Número Documento ou Número RQPS.');
        }

        $service->store($request->get());
        notification()->success('EPS cadastrada com sucesso!');
        return redirect()->route('eps.index');
    }

    function edit(string $uuid): mixed
    {
        $editing = (new EpsService)->find($uuid);
        if (!$editing) {
            return redirect()->route('eps.index')->withError('EPS não encontrada.');
        }
        $itens  = (new EpsService)->listAll();
        $juntas = (new JuntaService)->listAll();
        return view('eps.index', compact('itens', 'editing', 'juntas'));
    }

    function update(StoreEpsRequest $request): mixed
    {
        $request->execute();
        $service = new EpsService;

        $uuid = (string) $request->input('uuid');
        $eps  = $service->find($uuid);
        if (!$eps) {
            return redirect()->route('eps.index')->withError('EPS não encontrada.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('eps.index')->withError('EPS vinculada a um RQS: edição não permitida.');
        }

        $doc  = trim((string) $request->input('numero_documento'));
        $rqps = trim((string) $request->input('numero_rqps'));
        if ($service->existeDuplicado($doc, $rqps, $uuid)) {
            return redirect()->back()->withError('Já existe EPS com esse Número Documento ou Número RQPS.');
        }

        $service->update($uuid, $request->get());
        notification()->success('EPS atualizada com sucesso!');
        return redirect()->route('eps.index');
    }

    function destroy(): mixed
    {
        $service = new EpsService;
        $uuid    = (string) request()->get('uuid');

        $eps = $service->find($uuid);
        if (!$eps) {
            return redirect()->route('eps.index')->withError('EPS não encontrada.');
        }
        if ($service->emUso($uuid)) {
            return redirect()->route('eps.index')->withError('EPS vinculada a um RQS: exclusão não permitida.');
        }

        $service->delete($uuid);
        notification()->success('EPS excluída com sucesso!');
        return redirect()->route('eps.index');
    }

    /**
     * Importação em lote via Excel (.xlsx) ou CSV (separador ";").
     */
    function importar(): mixed
    {
        $arquivo = $_FILES['arquivo'] ?? null;
        if (!$arquivo || ($arquivo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return redirect()->route('eps.index')->withError('Selecione um arquivo .xlsx ou .csv válido.');
        }

        $resultado = (new EpsService)->importar($arquivo['tmp_name'], (string) $arquivo['name']);

        if (!$resultado['ok'] && $resultado['inseridos'] === 0) {
            return redirect()->route('eps.index')->withError(implode(' ', $resultado['erros']));
        }

        $msg = "{$resultado['inseridos']} EPS importada(s) com sucesso.";
        if (!empty($resultado['erros'])) {
            $msg .= ' Observações: ' . implode(' ', array_slice($resultado['erros'], 0, 5));
            if (count($resultado['erros']) > 5) {
                $msg .= ' (+' . (count($resultado['erros']) - 5) . ' linha(s) ignorada(s))';
            }
        }
        notification()->success($msg);
        return redirect()->route('eps.index');
    }
}
