<?php

namespace src\app\controllers;

use src\app\requests\StoreChecklistRequest;
use src\app\services\ChecklistService;
use src\app\services\ModeloVagaoService;
use src\app\services\ClienteService;
use src\app\services\EstagioSoldagemService;
use src\app\services\MetalBaseService;
use src\app\services\EpsService;
use src\support\Json;

class ChecklistController
{
    function __construct()
    {
    }

    private function opcoes(): array
    {
        return [
            'modelos'  => (new ModeloVagaoService)->listAll(),
            'clientes' => (new ClienteService)->listAll(),
            'estagios' => (new EstagioSoldagemService)->listAll(),
            'metais'   => (new MetalBaseService)->listAll(),
            'epsList'  => (new EpsService)->listAll(),
        ];
    }

    function index(): mixed
    {
        $service = new ChecklistService;
        $itens   = $service->listAll();
        return view('checklist.list', compact('itens', 'service'));
    }

    function create(): mixed
    {
        $service   = new ChecklistService;
        $editing   = null;
        $parametros = [];
        return view('checklist.form', array_merge(compact('editing', 'service', 'parametros'), $this->opcoes()));
    }

    function store(StoreChecklistRequest $request): mixed
    {
        $request->execute();
        (new ChecklistService)->store($request->get());
        notification()->success('Checklist de soldagem registrado com sucesso!');
        return redirect()->route('checklist.index');
    }

    function edit(string $uuid): mixed
    {
        $service = new ChecklistService;
        $editing = $service->find($uuid);
        if (!$editing) {
            return redirect()->route('checklist.index')->withError('Checklist não encontrado.');
        }
        // parâmetros indexados por chave
        $parametros = [];
        foreach ($service->parametrosDo((int) $editing->id) as $p) {
            $parametros[$p->campo] = $p;
        }
        return view('checklist.form', array_merge(compact('editing', 'service', 'parametros'), $this->opcoes()));
    }

    function update(StoreChecklistRequest $request): mixed
    {
        $request->execute();
        $service = new ChecklistService;
        $uuid = (string) $request->input('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('checklist.index')->withError('Checklist não encontrado.');
        }
        $service->update($uuid, $request->get());
        notification()->success('Checklist de soldagem atualizado com sucesso!');
        return redirect()->route('checklist.index');
    }

    function destroy(): mixed
    {
        $service = new ChecklistService;
        $uuid    = (string) request()->get('uuid');
        if (!$service->find($uuid)) {
            return redirect()->route('checklist.index')->withError('Checklist não encontrado.');
        }
        $service->delete($uuid);
        notification()->success('Checklist excluído com sucesso!');
        return redirect()->route('checklist.index');
    }

    /**
     * AJAX: dados do soldador pela matrícula (nome, sinete, qualificação, alerta).
     */
    function buscarSoldador(): mixed
    {
        $matricula = (string) (request()->get('matricula') ?? '');
        $dados = (new ChecklistService)->dadosSoldador($matricula);
        return Json::return($dados ?: ['erro' => 'Soldador não encontrado'], $dados ? 200 : 404);
    }
}
