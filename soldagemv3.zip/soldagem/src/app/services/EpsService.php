<?php

namespace src\app\services;

use src\app\database\entities\Eps;
use src\app\database\entities\Rqs;

class EpsService
{
    /** Opções conhecidas (selects). */
    public const STATUS         = ['ATIVA', 'QUALIFICAÇÃO'];
    public const TIPOS_JUNTA    = ['TOPO', 'ÂNGULO', 'ÂNGULO/TOPO'];
    public const BACKING        = ['Com', 'Sem', 'Ambos'];

    /**
     * Cabeçalho obrigatório do arquivo de upload, na ordem exata (Figura 5).
     * A validação bloqueia o upload se o cabeçalho não bater.
     */
    public const COLUNAS = [
        'Número Documento',
        'Número RQPS',
        'Status',
        'Código',
        'MB (01)',
        'MB (02)',
        'Faixa de Espessura [mm]',
        'Tipo de Junta',
        'Penetração',
        'Cobre Junta (Backing)',
        'Processo de Soldagem',
        'Tipo',
        'Gás de Proteção',
        'Metal de adição',
        'TTAT',
        'Bitola [mm]',
        'Tensão [V]',
        'Corrente [A]',
    ];

    /** @return array<int, object> */
    public function listAll(): array
    {
        return Eps::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return Eps::getByUuid($uuid);
    }

    /** EPS por número de documento (usado no Plano/RQS). */
    public function findByDocumento(string $numeroDocumento): mixed
    {
        return Eps::selectOne()->whereEquals('numero_documento', $numeroDocumento)->andWhereIsNull('deleted_at')->finish();
    }

    /**
     * Duplicidade por Número Documento ou Número RQPS.
     */
    public function existeDuplicado(string $numeroDocumento, string $numeroRqps, ?string $ignoreUuid = null): bool
    {
        $achados = Eps::select()
            ->where('numero_documento', '=', $numeroDocumento)
            ->orWhere('numero_rqps', '=', $numeroRqps)
            ->finish() ?: [];
        foreach ($achados as $r) {
            if ($r->deleted_at === null && ($ignoreUuid === null || $r->uuid !== $ignoreUuid)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Normaliza os campos aceitos.
     * @param array<string, mixed> $d
     * @return array<string, mixed>
     */
    public function sanitize(array $d): array
    {
        return [
            'numero_documento'  => trim((string) ($d['numero_documento'] ?? '')),
            'numero_rqps'       => trim((string) ($d['numero_rqps'] ?? '')),
            'status'            => trim((string) ($d['status'] ?? '')),
            'codigo'            => trim((string) ($d['codigo'] ?? '')),
            'juntas'            => implode(', ', array_filter(array_map('trim', (array) ($d['juntas'] ?? [])))),
            'metal_base'        => trim((string) ($d['metal_base'] ?? ($d['mb01'] ?? ''))),
            'faixa_espessura'   => trim((string) ($d['faixa_espessura'] ?? '')),
            'tipo_junta'        => trim((string) ($d['tipo_junta'] ?? '')),
            'penetracao'        => trim((string) ($d['penetracao'] ?? '')),
            'cobre_junta'       => trim((string) ($d['cobre_junta'] ?? '')),
            'processo_soldagem' => trim((string) ($d['processo_soldagem'] ?? '')),
            'tipo'              => trim((string) ($d['tipo'] ?? '')),
            'gas_protecao'      => trim((string) ($d['gas_protecao'] ?? '')),
            'metal_adicao'      => trim((string) ($d['metal_adicao'] ?? '')),
            'ttat'              => !empty($d['ttat']) ? 1 : 0,
            'bitola'            => trim((string) ($d['bitola'] ?? '')),
            'mb01'              => trim((string) ($d['mb01'] ?? '')),
            'mb02'              => trim((string) ($d['mb02'] ?? '')),
            'tensao'            => trim((string) ($d['tensao'] ?? '')),
            'corrente'          => trim((string) ($d['corrente'] ?? '')),
        ];
    }

    public function store(array $data): bool|array|object
    {
        return Eps::create($this->sanitize($data));
    }

    public function update(string $uuid, array $data): mixed
    {
        $fields = $this->sanitize($data);
        $fields['updated_at'] = date('Y-m-d H:i:s');
        return Eps::update($fields)->whereEquals('uuid', $uuid)->finish();
    }

    public function delete(string $uuid): bool
    {
        Eps::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    /** Bloqueia edição/exclusão se a EPS estiver referenciada em um RQS. */
    public function emUso(string $uuid): bool
    {
        $eps = $this->find($uuid);
        if (!$eps) return false;
        $refs = Rqs::select()->whereEquals('eps_id', $eps->id)->andWhereIsNull('deleted_at')->finish() ?: [];
        return count($refs) > 0;
    }

    // ===================== IMPORTAÇÃO EM LOTE =============================

    /**
     * Importa um arquivo (.xlsx ou .csv) validando o cabeçalho e a duplicidade.
     *
     * @return array{ok:bool, inseridos:int, erros:array<int,string>}
     */
    public function importar(string $tmpPath, string $nomeOriginal): array
    {
        $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));

        try {
            if ($ext === 'csv') {
                $linhas = $this->lerCsv($tmpPath, ';');
            } elseif ($ext === 'xlsx') {
                $linhas = $this->lerXlsx($tmpPath);
            } else {
                return ['ok' => false, 'inseridos' => 0, 'erros' => ['Formato não permitido. Use .xlsx ou .csv.']];
            }
        } catch (\Throwable $e) {
            return ['ok' => false, 'inseridos' => 0, 'erros' => ['Falha ao ler o arquivo: ' . $e->getMessage()]];
        }

        if (empty($linhas)) {
            return ['ok' => false, 'inseridos' => 0, 'erros' => ['Arquivo vazio.']];
        }

        // 1ª linha = cabeçalho; deve ser idêntico ao layout.
        $cabecalho = array_map(fn($c) => $this->normalizarCabecalho((string) $c), array_shift($linhas));
        $esperado  = array_map(fn($c) => $this->normalizarCabecalho($c), self::COLUNAS);

        if ($cabecalho !== $esperado) {
            return [
                'ok' => false,
                'inseridos' => 0,
                'erros' => ['Cabeçalho inválido. As colunas devem seguir exatamente o layout: ' . implode(' | ', self::COLUNAS)],
            ];
        }

        $inseridos = 0;
        $erros = [];
        foreach ($linhas as $i => $linha) {
            $numLinha = $i + 2; // +1 header, +1 base 1
            if (count(array_filter($linha, fn($v) => trim((string) $v) !== '')) === 0) {
                continue; // linha vazia
            }
            [, $c] = [null, array_pad($linha, count(self::COLUNAS), '')];

            $dados = [
                'numero_documento'  => trim((string) $c[0]),
                'numero_rqps'       => trim((string) $c[1]),
                'status'            => trim((string) $c[2]),
                'codigo'            => trim((string) $c[3]),
                'mb01'              => trim((string) $c[4]),
                'mb02'              => trim((string) $c[5]),
                'metal_base'        => trim((string) $c[4]),
                'faixa_espessura'   => trim((string) $c[6]),
                'tipo_junta'        => trim((string) $c[7]),
                'penetracao'        => trim((string) $c[8]),
                'cobre_junta'       => trim((string) $c[9]),
                'processo_soldagem' => trim((string) $c[10]),
                'tipo'              => trim((string) $c[11]),
                'gas_protecao'      => trim((string) $c[12]),
                'metal_adicao'      => trim((string) $c[13]),
                'ttat'              => $this->boolCsv((string) $c[14]),
                'bitola'            => trim((string) $c[15]),
                'tensao'            => trim((string) $c[16]),
                'corrente'          => trim((string) $c[17]),
            ];

            if ($dados['numero_documento'] === '' || $dados['numero_rqps'] === '') {
                $erros[] = "Linha {$numLinha}: Número Documento e Número RQPS são obrigatórios.";
                continue;
            }
            if ($this->existeDuplicado($dados['numero_documento'], $dados['numero_rqps'])) {
                $erros[] = "Linha {$numLinha}: já existe EPS com o Número Documento '{$dados['numero_documento']}' ou RQPS '{$dados['numero_rqps']}'.";
                continue;
            }

            $this->store($dados);
            $inseridos++;
        }

        return ['ok' => $inseridos > 0, 'inseridos' => $inseridos, 'erros' => $erros];
    }

    private function boolCsv(string $v): int
    {
        $v = strtolower(trim($v));
        return in_array($v, ['1', 'sim', 's', 'true', 'x', 'yes'], true) ? 1 : 0;
    }

    private function normalizarCabecalho(string $s): string
    {
        $s = trim($s);
        $s = preg_replace('/\s+/', ' ', $s);
        return mb_strtolower($s, 'UTF-8');
    }

    /**
     * Lê um CSV em uma matriz de linhas.
     * @return array<int, array<int, string>>
     */
    private function lerCsv(string $path, string $sep = ';'): array
    {
        $linhas = [];
        if (($h = fopen($path, 'r')) !== false) {
            while (($row = fgetcsv($h, 0, $sep)) !== false) {
                $linhas[] = array_map(fn($v) => (string) $v, $row);
            }
            fclose($h);
        }
        // Remove BOM da primeira célula, se houver.
        if (isset($linhas[0][0])) {
            $linhas[0][0] = preg_replace('/^\xEF\xBB\xBF/', '', $linhas[0][0]);
        }
        return $linhas;
    }

    /**
     * Leitor mínimo de XLSX via ZipArchive + SimpleXML (sem dependência externa).
     * Lê a primeira planilha e resolve as sharedStrings.
     * @return array<int, array<int, string>>
     */
    private function lerXlsx(string $path): array
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new \RuntimeException('Extensão zip do PHP não disponível para ler .xlsx (use .csv).');
        }
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) {
            throw new \RuntimeException('Não foi possível abrir o .xlsx.');
        }

        // Shared strings
        $shared = [];
        $ssXml = $zip->getFromName('xl/sharedStrings.xml');
        if ($ssXml !== false) {
            $ss = simplexml_load_string($ssXml);
            if ($ss !== false) {
                foreach ($ss->si as $si) {
                    // texto simples ou com runs <r><t>
                    $txt = '';
                    if (isset($si->t)) {
                        $txt = (string) $si->t;
                    } else {
                        foreach ($si->r as $r) {
                            $txt .= (string) $r->t;
                        }
                    }
                    $shared[] = $txt;
                }
            }
        }

        // Primeira planilha
        $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
        $zip->close();
        if ($sheetXml === false) {
            throw new \RuntimeException('Planilha não encontrada no .xlsx.');
        }

        $xml = simplexml_load_string($sheetXml);
        $linhas = [];
        foreach ($xml->sheetData->row as $row) {
            $celulas = [];
            $colIdx = 0;
            foreach ($row->c as $c) {
                // Coluna real a partir da referência (ex.: C5 -> índice 2)
                $ref = (string) $c['r'];
                $col = $this->colToIndex(preg_replace('/\d+/', '', $ref));
                // preenche gaps
                while ($colIdx < $col) { $celulas[$colIdx] = ''; $colIdx++; }

                $val = '';
                $t = (string) $c['t'];
                if ($t === 's') {
                    $idx = (int) $c->v;
                    $val = $shared[$idx] ?? '';
                } elseif ($t === 'inlineStr') {
                    $val = (string) $c->is->t;
                } else {
                    $val = (string) $c->v;
                }
                $celulas[$colIdx] = $val;
                $colIdx++;
            }
            $linhas[] = $celulas;
        }
        return $linhas;
    }

    /** Converte referência de coluna (A, B, ..., AA) em índice 0-based. */
    private function colToIndex(string $letters): int
    {
        $letters = strtoupper($letters);
        $n = 0;
        for ($i = 0; $i < strlen($letters); $i++) {
            $n = $n * 26 + (ord($letters[$i]) - 64);
        }
        return $n - 1;
    }
}
