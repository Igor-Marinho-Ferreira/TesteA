<?php

namespace src\app\services;

use src\app\database\entities\Soldador;
use src\app\database\entities\SoldadorTreinamento;
use src\app\database\entities\SoldadorProcesso;
use src\app\database\entities\SoldadorRequalificacao;

class SoldadorService
{
    public const PERFORMANCE = ['BAIXA', 'MÉDIA', 'ALTA'];
    public const STATUS = ['ativo', 'inativo'];
    public const STATUS_QUALIFICACAO = ['QUALIFICADO', 'REQUALIFICAR'];

    /** Cargos base para soldadores recém contratados (busca diária no Senior). */
    public const CARGOS = [
        'SOLDADOR-MONTADOR I', 'SOLDADOR-MONTADOR II', 'SOLDADOR-MONTADOR III',
        'SOLDADOR-PINTOR I', 'SOLDADOR-PINTOR II', 'SOLDADOR-PINTOR III',
        'SOLDADOR FERROVIARIO I', 'SOLDADOR FERROVIARIO II', 'SOLDADOR FERROVIARIO III',
    ];

    /** @return array<int, object> */
    public function listAll(): array
    {
        return Soldador::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return Soldador::getByUuid($uuid);
    }

    public function findByMatricula(string $matricula): mixed
    {
        return Soldador::selectOne()->whereEquals('matricula', $matricula)->andWhereIsNull('deleted_at')->finish();
    }

    public function existeSinete(string $sinete, ?string $ignoreUuid = null): bool
    {
        $achados = Soldador::select()->whereEquals('sinete', $sinete)->andWhereIsNull('deleted_at')->finish() ?: [];
        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) return true;
        }
        return false;
    }

    /**
     * @param array<string, mixed> $d
     * @return array<string, mixed>
     */
    public function sanitize(array $d): array
    {
        $ultima = trim((string) ($d['data_ultima_qualificacao'] ?? '')) ?: null;
        return [
            'matricula'                     => trim((string) ($d['matricula'] ?? '')),
            'nome'                          => trim((string) ($d['nome'] ?? '')),
            'cargo'                         => trim((string) ($d['cargo'] ?? '')),
            'sinete'                        => trim((string) ($d['sinete'] ?? '')),
            'performance'                   => trim((string) ($d['performance'] ?? '')),
            'data_qualificacao'             => trim((string) ($d['data_qualificacao'] ?? '')) ?: null,
            'data_ultima_qualificacao'      => $ultima,
            'data_requalificacao'           => $ultima ? $this->maisSeisMeses($ultima) : null,
            'status'                        => trim((string) ($d['status'] ?? 'ativo')),
            'status_qualificacao'           => trim((string) ($d['status_qualificacao'] ?? '')),
            'numero_registro_requalificacao' => trim((string) ($d['numero_registro_requalificacao'] ?? '')) ?: $this->proximoRegistroRequalificacao(),
        ];
    }

    /** Data + 6 meses (data de requalificação automática). */
    public function maisSeisMeses(string $data): ?string
    {
        try {
            $d = new \DateTime($data);
            $d->modify('+6 months');
            return $d->format('Y-m-d');
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** Nº de registro de requalificação sequencial "por ponto". */
    public function proximoRegistroRequalificacao(): string
    {
        $todos = Soldador::select(['numero_registro_requalificacao'])->finish() ?: [];
        $max = 0;
        foreach ($todos as $r) {
            $n = (int) preg_replace('/\D/', '', (string) $r->numero_registro_requalificacao);
            if ($n > $max) $max = $n;
        }
        return (string) ($max + 1);
    }

    /**
     * Cria o soldador e seus vínculos (treinamentos, processos×posições).
     * @param array<string, mixed> $d
     */
    public function store(array $d): void
    {
        $novo = Soldador::create($this->sanitize($d));
        $id = is_object($novo) ? ($novo->id ?? null) : ($novo['id'] ?? null);
        if ($id) {
            $this->salvarVinculos((int) $id, $d);
        }
    }

    public function update(string $uuid, array $d): void
    {
        $fields = $this->sanitize($d);
        $fields['updated_at'] = date('Y-m-d H:i:s');
        Soldador::update($fields)->whereEquals('uuid', $uuid)->finish();

        $soldador = $this->find($uuid);
        if ($soldador) {
            // Recria os vínculos
            SoldadorTreinamento::delete()->where('soldador_id', '=', $soldador->id)->finish();
            SoldadorProcesso::delete()->where('soldador_id', '=', $soldador->id)->finish();
            $this->salvarVinculos((int) $soldador->id, $d);
        }
    }

    /**
     * @param array<string, mixed> $d
     */
    private function salvarVinculos(int $soldadorId, array $d): void
    {
        $treinamentos = (array) ($d['treinamentos'] ?? []);
        foreach ($treinamentos as $tid) {
            if ($tid === '' || $tid === null) continue;
            SoldadorTreinamento::insert(['soldador_id' => $soldadorId, 'treinamento_id' => (int) $tid])->finish();
        }

        // Combinações processo × posição (produto cartesiano dos selecionados)
        $processos = (array) ($d['processos'] ?? []);
        $posicoes  = (array) ($d['posicoes'] ?? []);
        if (empty($posicoes)) $posicoes = [null];
        foreach ($processos as $qid) {
            if ($qid === '' || $qid === null) continue;
            foreach ($posicoes as $pid) {
                SoldadorProcesso::insert([
                    'soldador_id'     => $soldadorId,
                    'qualificacao_id' => (int) $qid,
                    'posicao_id'      => ($pid !== null && $pid !== '') ? (int) $pid : null,
                ])->finish();
            }
        }
    }

    public function delete(string $uuid): bool
    {
        Soldador::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    /** @return array<int, int> ids de treinamentos vinculados */
    public function treinamentosDo(int $soldadorId): array
    {
        $rows = SoldadorTreinamento::select(['treinamento_id'])->whereEquals('soldador_id', $soldadorId)->finish() ?: [];
        return array_map(fn($r) => (int) $r->treinamento_id, $rows);
    }

    /** @return array{processos:array<int,int>, posicoes:array<int,int>} */
    public function vinculosDo(int $soldadorId): array
    {
        $rows = SoldadorProcesso::select()->whereEquals('soldador_id', $soldadorId)->finish() ?: [];
        $proc = [];
        $pos  = [];
        foreach ($rows as $r) {
            $proc[(int) $r->qualificacao_id] = (int) $r->qualificacao_id;
            if (!empty($r->posicao_id)) $pos[(int) $r->posicao_id] = (int) $r->posicao_id;
        }
        return ['processos' => array_values($proc), 'posicoes' => array_values($pos)];
    }

    /** @return array<int, object> histórico de requalificações */
    public function historicoRequalificacao(int $soldadorId): array
    {
        return SoldadorRequalificacao::select()->whereEquals('soldador_id', $soldadorId)->order('id', 'DESC')->finish() ?: [];
    }

    /**
     * Dias restantes até a requalificação (negativo = vencida). Null se não houver data.
     */
    public function diasParaVencer(?string $dataRequalificacao): ?int
    {
        if (!$dataRequalificacao) return null;
        try {
            $hoje = new \DateTime(date('Y-m-d'));
            $venc = new \DateTime($dataRequalificacao);
            return (int) $hoje->diff($venc)->format('%r%a');
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Classe de destaque conforme a janela de vencimento:
     *   vencida / <30d → danger ; <40d → warn ; <60d → ok(verde) ; senão muted
     */
    public function corVencimento(?int $dias): string
    {
        if ($dias === null) return 'muted';
        if ($dias < 30) return 'danger';
        if ($dias < 40) return 'warn';
        if ($dias < 60) return 'ok';
        return 'muted';
    }
}
