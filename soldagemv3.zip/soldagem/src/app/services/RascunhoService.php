<?php

namespace src\app\services;

use src\app\database\entities\Rascunho;

/**
 * Rascunhos de formulário (server-side), por módulo + referência + matrícula.
 * Um rascunho por combinação. Tolerante a falha (se a tabela não existir,
 * os métodos apenas retornam null/false, sem quebrar o fluxo).
 */
class RascunhoService
{
    private function matricula(): string
    {
        $u = user();
        return (string) ($u->matricula ?? '');
    }

    /** Retorna o payload (string JSON) do rascunho, ou null. */
    public function obter(string $modulo, string $referencia): ?string
    {
        try {
            $r = Rascunho::selectOne()
                ->whereEquals('modulo', $modulo)
                ->andWhereEquals('referencia', $referencia)
                ->andWhereEquals('matricula', $this->matricula())
                ->finish();
            return $r ? (string) $r->payload : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** Cria/atualiza o rascunho. */
    public function salvar(string $modulo, string $referencia, string $payload): bool
    {
        $matricula = $this->matricula();
        if ($modulo === '' || $referencia === '' || $matricula === '') return false;

        try {
            $existente = Rascunho::selectOne()
                ->whereEquals('modulo', $modulo)
                ->andWhereEquals('referencia', $referencia)
                ->andWhereEquals('matricula', $matricula)
                ->finish();

            if ($existente) {
                Rascunho::update(['payload' => $payload, 'updated_at' => date('Y-m-d H:i:s')])
                    ->whereEquals('uuid', $existente->uuid)->finish();
            } else {
                Rascunho::create([
                    'modulo'     => $modulo,
                    'referencia' => $referencia,
                    'matricula'  => $matricula,
                    'payload'    => $payload,
                ]);
            }
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Remove o rascunho. */
    public function descartar(string $modulo, string $referencia): bool
    {
        try {
            Rascunho::delete()
                ->where('modulo', '=', $modulo)
                ->andWhereEquals('referencia', $referencia)
                ->andWhereEquals('matricula', $this->matricula())
                ->finish();
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }
}
