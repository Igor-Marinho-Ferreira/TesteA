<?php

namespace src\app\services;

use src\app\database\entities\EstacaoQualificacao;
use src\app\database\entities\Qualificacao;
use src\app\database\entities\PosicaoQualificacao;

class EstacaoQualificacaoService
{
    /** @return array<int, object> */
    public function listAll(): array
    {
        return EstacaoQualificacao::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return EstacaoQualificacao::getByUuid($uuid);
    }

    /**
     * @param array<string, mixed> $d
     * @return array<string, mixed>
     */
    public function sanitize(array $d): array
    {
        $processoId = ($d['processo_solda_id'] ?? '') !== '' ? (int) $d['processo_solda_id'] : null;
        $descProc = trim((string) ($d['descricao_processo'] ?? ''));

        // Preenche automaticamente a descrição do processo a partir da qualificação.
        if ($processoId && $descProc === '') {
            $q = Qualificacao::getById($processoId);
            if ($q) $descProc = (string) $q->descricao;
        }

        return [
            'linha_montagem'     => trim((string) ($d['linha_montagem'] ?? '')),
            'codigo_estacao_mes' => trim((string) ($d['codigo_estacao_mes'] ?? '')),
            'descricao_estacao'  => trim((string) ($d['descricao_estacao'] ?? '')),
            'processo_solda_id'  => $processoId,
            'descricao_processo' => $descProc,
            'posicao_solda_id'   => ($d['posicao_solda_id'] ?? '') !== '' ? (int) $d['posicao_solda_id'] : null,
            'ativo'              => isset($d['ativo']) ? (int) (bool) $d['ativo'] : 1,
        ];
    }

    public function store(array $d): bool|array|object
    {
        return EstacaoQualificacao::create($this->sanitize($d));
    }

    public function update(string $uuid, array $d): mixed
    {
        $fields = $this->sanitize($d);
        $fields['updated_at'] = date('Y-m-d H:i:s');
        return EstacaoQualificacao::update($fields)->whereEquals('uuid', $uuid)->finish();
    }

    /** Não há exclusão física — apenas inativa o vínculo (rastreabilidade). */
    public function inativar(string $uuid): bool
    {
        EstacaoQualificacao::update(['ativo' => 0, 'updated_at' => date('Y-m-d H:i:s')])
            ->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    public function ativar(string $uuid): bool
    {
        EstacaoQualificacao::update(['ativo' => 1, 'updated_at' => date('Y-m-d H:i:s')])
            ->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    /**
     * Localiza o vínculo ativo de uma estação (usado na validação de certificação/MES).
     */
    public function findByEstacao(string $codigoEstacao): mixed
    {
        return EstacaoQualificacao::selectOne()
            ->whereEquals('codigo_estacao_mes', $codigoEstacao)
            ->andWhereEquals('ativo', 1)
            ->andWhereIsNull('deleted_at')
            ->finish();
    }

    public function labelProcesso(?int $id): string
    {
        if (!$id) return '—';
        $q = Qualificacao::getById($id);
        return $q ? (string) $q->qualificacao : '—';
    }

    public function labelPosicao(?int $id): string
    {
        if (!$id) return '—';
        $p = PosicaoQualificacao::getById($id);
        if (!$p) return '—';
        $txt = "{$p->tipo} - {$p->posicao}";
        if (!empty($p->progressao)) $txt .= " ({$p->progressao})";
        return $txt;
    }
}
