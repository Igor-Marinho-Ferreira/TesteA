<?php

namespace src\app\services;

use src\app\database\entities\PlanoResponsavel;

class PlanoResponsavelService
{
    public const ETAPAS = ['elaborado' => 'Elaborado', 'verificado' => 'Verificado', 'aprovado' => 'Aprovado'];

    /** @return array<int, object> */
    public function listAll(): array
    {
        return PlanoResponsavel::select()->whereIsNull('deleted_at')->order('etapa', 'ASC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return PlanoResponsavel::getByUuid($uuid);
    }

    /** Responsáveis de uma etapa (usado para direcionar o fluxo do Plano). */
    public function porEtapa(string $etapa): array
    {
        return PlanoResponsavel::select()->whereEquals('etapa', $etapa)->andWhereIsNull('deleted_at')->finish() ?: [];
    }

    /**
     * @param array<string, mixed> $d
     * @return array<string, mixed>
     */
    public function sanitize(array $d): array
    {
        return [
            'etapa'            => (string) ($d['etapa'] ?? ''),
            'nome_responsavel' => trim((string) ($d['nome_responsavel'] ?? '')),
            'matricula'        => trim((string) ($d['matricula'] ?? '')),
            'cargo'            => trim((string) ($d['cargo'] ?? '')),
            'departamento'     => trim((string) ($d['departamento'] ?? '')),
        ];
    }

    public function store(array $d): bool|array|object
    {
        return PlanoResponsavel::create($this->sanitize($d));
    }

    public function update(string $uuid, array $d): mixed
    {
        $fields = $this->sanitize($d);
        $fields['updated_at'] = date('Y-m-d H:i:s');
        return PlanoResponsavel::update($fields)->whereEquals('uuid', $uuid)->finish();
    }

    public function delete(string $uuid): bool
    {
        PlanoResponsavel::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }
}
