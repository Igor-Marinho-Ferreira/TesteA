<?php

namespace src\app\services;

use src\app\database\entities\Perfil;
use src\app\database\entities\PerfilPermissao;
use src\app\database\entities\UsuarioPerfil;

/**
 * Controle de acesso por perfil.
 *
 * - Cada módulo tem uma chave (ex.: 'junta', 'plano', 'checklist').
 * - Um perfil define, por módulo, se o usuário VÊ e se pode EDITAR.
 * - Uma matrícula é vinculada a um perfil.
 *
 * Regra padrão: usuário SEM perfil vinculado vê tudo e edita tudo
 * (perfil de administrador/desenvolvedor). Assim, só quem tem um perfil
 * restrito (ex.: a matrícula da demo do sprint) fica limitado.
 */
class PermissaoService
{
    /** @var array<string, array{ver:bool, editar:bool}>|null Cache das permissões do usuário atual. */
    private static ?array $cache = null;
    private static bool $cacheCarregado = false;

    /**
     * Registro central dos módulos, agrupados como no menu.
     * grupo => [ chave => [label, rota, icone, cor, desc] ]
     *
     * @return array<string, array<string, array{label:string, rota:string, icone:string, cor:string, desc:string}>>
     */
    public static function modulos(): array
    {
        return [
            'Ajuda' => [
                'manual' => ['label' => 'Manual do Sistema', 'rota' => 'manual.index', 'icone' => 'ph-book-open', 'cor' => 'slate', 'desc' => 'Como o processo e cada tela funcionam.'],
            ],
            'Plano de Soldagem' => [
                'junta'             => ['label' => 'Juntas', 'rota' => 'junta.index', 'icone' => 'ph-git-merge', 'cor' => 'blue', 'desc' => 'Cadastro das juntas de soldagem.'],
                'metal_base'        => ['label' => 'Metal Base (Material)', 'rota' => 'metal_base.index', 'icone' => 'ph-stack', 'cor' => 'violet', 'desc' => 'Cadastro dos materiais / metais base.'],
                'gas'               => ['label' => 'Gás', 'rota' => 'gas.index', 'icone' => 'ph-wind', 'cor' => 'green', 'desc' => 'Cadastro dos gases de proteção.'],
                'desenho'           => ['label' => 'Desenhos', 'rota' => 'desenho.index', 'icone' => 'ph-image-square', 'cor' => 'blue', 'desc' => 'Cadastro de desenhos (imagem do detalhe da junta).'],
                'eps'               => ['label' => 'Upload de Informações da EPS', 'rota' => 'eps.index', 'icone' => 'ph-file-xls', 'cor' => 'amber', 'desc' => 'Import da EPS via Excel/CSV e cadastro manual.'],
                'plano'             => ['label' => 'Formulário do Plano de Soldagem', 'rota' => 'plano.index', 'icone' => 'ph-clipboard-text', 'cor' => 'green', 'desc' => 'Registro do plano com fluxo de aprovação.'],
                'plano_responsavel' => ['label' => 'Responsáveis do Plano', 'rota' => 'plano_responsavel.index', 'icone' => 'ph-users-three', 'cor' => 'violet', 'desc' => 'Responsáveis por cada etapa do fluxo.'],
            ],
            'Qualificação de Soldadores' => [
                'qualificacao'           => ['label' => 'Qualificação (Processo)', 'rota' => 'qualificacao.index', 'icone' => 'ph-medal', 'cor' => 'blue', 'desc' => 'Processos de soldagem AWS.'],
                'posicao_qualificacao'   => ['label' => 'Posição de Qualificação', 'rota' => 'posicao_qualificacao.index', 'icone' => 'ph-arrows-out-cardinal', 'cor' => 'violet', 'desc' => 'Posições ângulo/topo (1G–6G).'],
                'treinamento'            => ['label' => 'Treinamentos', 'rota' => 'treinamento.index', 'icone' => 'ph-certificate', 'cor' => 'green', 'desc' => 'Cadastro dos treinamentos.'],
                'soldador'               => ['label' => 'Soldadores', 'rota' => 'soldador.index', 'icone' => 'ph-identification-card', 'cor' => 'amber', 'desc' => 'Cadastro de soldadores e requalificação.'],
                'formulario_qualificacao' => ['label' => 'Formulário de Qualificação', 'rota' => 'formulario_qualificacao.index', 'icone' => 'ph-list-checks', 'cor' => 'blue', 'desc' => 'Catálogo que alimenta o RQS.'],
                'estacao_qualificacao'   => ['label' => 'Estação MES × Qualificação', 'rota' => 'estacao_qualificacao.index', 'icone' => 'ph-link', 'cor' => 'violet', 'desc' => 'Vínculo estação ↔ processo ↔ posição.'],
                'rqs'                    => ['label' => 'RQS — Registro de Qualificação', 'rota' => 'rqs.index', 'icone' => 'ph-certificate', 'cor' => 'blue', 'desc' => 'Registro de qualificação de soldador.'],
                'ensaio'                 => ['label' => 'Ensaio Visual e Dimensional', 'rota' => 'ensaio.index', 'icone' => 'ph-magnifying-glass-plus', 'cor' => 'amber', 'desc' => 'Relatório de ensaio visual/dimensional.'],
                'relatorio'              => ['label' => 'Relatório de Qualificação', 'rota' => 'relatorio.qualificacao', 'icone' => 'ph-chart-bar', 'cor' => 'green', 'desc' => 'Relatório com filtros e export Excel.'],
                'validacao'              => ['label' => 'Validação de Certificação (MES)', 'rota' => 'validacao.index', 'icone' => 'ph-shield-check', 'cor' => 'violet', 'desc' => 'Continuidade AWS 6 meses e alertas.'],
            ],
            'Checklist de Soldagem' => [
                'modelo_vagao'     => ['label' => 'Modelos de Vagão', 'rota' => 'modelo_vagao.index', 'icone' => 'ph-train', 'cor' => 'blue', 'desc' => 'Cadastro de modelos de vagão.'],
                'cliente'          => ['label' => 'Clientes', 'rota' => 'cliente.index', 'icone' => 'ph-buildings', 'cor' => 'violet', 'desc' => 'Cadastro de clientes.'],
                'estagio_soldagem' => ['label' => 'Estágios de Soldagem', 'rota' => 'estagio_soldagem.index', 'icone' => 'ph-flow-arrow', 'cor' => 'green', 'desc' => 'Cadastro dos estágios do processo.'],
                'checklist'        => ['label' => 'Formulário de Checklist', 'rota' => 'checklist.index', 'icone' => 'ph-clipboard-text', 'cor' => 'amber', 'desc' => 'Checklist de verificação do processo.'],
            ],
            'Integrações & BI' => [
                'powerbi' => ['label' => 'Power BI', 'rota' => 'powerbi.index', 'icone' => 'ph-chart-donut', 'cor' => 'green', 'desc' => 'Disponibilização e exportação dos dados.'],
            ],
            'Administração' => [
                'perfil' => ['label' => 'Perfis de Acesso', 'rota' => 'perfil.index', 'icone' => 'ph-user-gear', 'cor' => 'slate', 'desc' => 'Controle do que cada pessoa vê e edita.'],
            ],
        ];
    }

    /** Lista plana de chaves de módulo. @return array<int, string> */
    public static function chaves(): array
    {
        $out = [];
        foreach (self::modulos() as $grupo => $itens) {
            foreach ($itens as $chave => $meta) $out[] = $chave;
        }
        return $out;
    }

    /** Rótulo de um módulo. */
    public static function label(string $modulo): string
    {
        foreach (self::modulos() as $itens) {
            if (isset($itens[$modulo])) return $itens[$modulo]['label'];
        }
        return $modulo;
    }

    /**
     * Perfil vinculado ao usuário logado (ou null se não houver).
     */
    public static function perfilDoUsuario(): ?object
    {
        $u = user();
        $mat = $u->matricula ?? null;
        if (!$mat) return null;

        try {
            $up = UsuarioPerfil::selectOne()
                ->whereEquals('matricula', (string) $mat)
                ->andWhereIsNull('deleted_at')
                ->finish();
            if (!$up) return null;

            return Perfil::getById((int) $up->perfil_id) ?: null;
        } catch (\Throwable $e) {
            // Tabelas de perfil ainda não criadas: trata como acesso total.
            return null;
        }
    }

    /**
     * Mapa de permissões do usuário atual: modulo => [ver, editar].
     * Retorna null quando o usuário NÃO tem perfil (acesso total).
     *
     * @return array<string, array{ver:bool, editar:bool}>|null
     */
    public static function permissoes(): ?array
    {
        if (self::$cacheCarregado) return self::$cache;
        self::$cacheCarregado = true;

        $perfil = self::perfilDoUsuario();
        if (!$perfil) {
            self::$cache = null; // sem perfil = acesso total
            return null;
        }

        try {
            $rows = PerfilPermissao::select()->whereEquals('perfil_id', (int) $perfil->id)->finish() ?: [];
        } catch (\Throwable $e) {
            self::$cache = null;
            return null;
        }
        $map = [];
        foreach ($rows as $r) {
            $map[$r->modulo] = ['ver' => (bool) $r->pode_ver, 'editar' => (bool) $r->pode_editar];
        }
        self::$cache = $map;
        return $map;
    }

    /** O usuário atual pode VER o módulo? (sem perfil = vê tudo) */
    public static function podeVer(string $modulo): bool
    {
        $p = self::permissoes();
        if ($p === null) return true;
        return $p[$modulo]['ver'] ?? false;
    }

    /** O usuário atual pode EDITAR o módulo? (sem perfil = edita tudo) */
    public static function podeEditar(string $modulo): bool
    {
        $p = self::permissoes();
        if ($p === null) return true;
        return $p[$modulo]['editar'] ?? false;
    }

    /** Limpa o cache (após alterar perfis). */
    public static function limparCache(): void
    {
        self::$cache = null;
        self::$cacheCarregado = false;
    }
}
