<?php

namespace src\app\services;

use src\app\database\entities\EnsaioVisual;
use src\app\database\entities\EnsaioVisualInstrumento;
use src\app\database\entities\EnsaioVisualOcorrencia;

class EnsaioVisualService
{
    public const TIPOS_JUNTA = ['TOPO', 'ÂNGULO', 'ÂNGULO/TOPO'];
    public const CONDICAO_SUPERFICIE = ['Escovada', 'Esmerilhada', 'Usinado', 'Jateada'];
    public const INSPECAO_EM = ['Chanfro', 'Bisel', 'Face', 'Raiz'];
    public const AVALIACAO = ['Aprovado', 'Reprovado'];

    /** Categorias de instrumentos (seção Instrumentos Utilizados). */
    public const INSTRUMENTOS = [
        'calibre_solda' => 'Calibre de Solda',
        'trena'         => 'Trena',
        'luximetro'     => 'Luxímetro',
        'outros'        => 'Outros',
    ];

    /** Códigos de descontinuidades (legenda). */
    public const DESCONTINUIDADES = [
        'MD' => 'Mordedura', 'TR' => 'Trinca', 'R' => 'Respingo', 'AA' => 'Abertura de arco',
        'PO' => 'Porosidade', 'RE' => 'Reforço excessivo', 'SB' => 'Sobreposição',
        'DI' => 'Deposição insuficiente', 'CO' => 'Concavidade', 'P' => 'Perfuração',
        'FF' => 'Falta de fusão', 'FP' => 'Falta de penetração', 'PS' => 'Perfil de solda',
    ];

    /** @return array<int, object> */
    public function listAll(): array
    {
        return EnsaioVisual::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return EnsaioVisual::getByUuid($uuid);
    }

    /** @return array<int, object> */
    public function instrumentosDo(int $ensaioId): array
    {
        return EnsaioVisualInstrumento::select()->whereEquals('ensaio_id', $ensaioId)->finish() ?: [];
    }

    /** @return array<int, object> */
    public function ocorrenciasDo(int $ensaioId): array
    {
        return EnsaioVisualOcorrencia::select()->whereEquals('ensaio_id', $ensaioId)->order('ordem', 'ASC')->finish() ?: [];
    }

    /** Próximo Nº de relatório NN/AAAA (reinicia a cada ano). */
    public function proximoNumero(): string
    {
        $ano = date('Y');
        $rows = EnsaioVisual::select(['numero_relatorio'])->finish() ?: [];
        $max = 0;
        foreach ($rows as $r) {
            if (preg_match('#^(\d+)/' . $ano . '$#', (string) $r->numero_relatorio, $m)) {
                $n = (int) $m[1];
                if ($n > $max) $max = $n;
            }
        }
        return str_pad((string) ($max + 1), 2, '0', STR_PAD_LEFT) . '/' . $ano;
    }

    public function store(array $d): void
    {
        $novo = EnsaioVisual::create($this->cabecalho($d, true));
        $id = is_object($novo) ? ($novo->id ?? null) : ($novo['id'] ?? null);
        if ($id) $this->salvarFilhos((int) $id, $d);
    }

    public function update(string $uuid, array $d): void
    {
        $fields = $this->cabecalho($d, false);
        $fields['updated_at'] = date('Y-m-d H:i:s');
        EnsaioVisual::update($fields)->whereEquals('uuid', $uuid)->finish();

        $ensaio = $this->find($uuid);
        if ($ensaio) {
            EnsaioVisualInstrumento::delete()->where('ensaio_id', '=', $ensaio->id)->finish();
            EnsaioVisualOcorrencia::delete()->where('ensaio_id', '=', $ensaio->id)->finish();
            $this->salvarFilhos((int) $ensaio->id, $d);
        }
    }

    /**
     * @param array<string,mixed> $d
     * @return array<string,mixed>
     */
    private function cabecalho(array $d, bool $novo): array
    {
        $u = user();
        $fields = [
            'equipamento'                 => trim((string) ($d['equipamento'] ?? '')),
            'quantidade'                  => ($d['quantidade'] ?? '') !== '' ? (int) $d['quantidade'] : null,
            'desenho'                     => trim((string) ($d['desenho'] ?? '')),
            'revisao'                     => trim((string) ($d['revisao'] ?? '')),
            'documentos_referencia'       => trim((string) ($d['documentos_referencia'] ?? '')),
            'revisao_doc'                 => trim((string) ($d['revisao_doc'] ?? '')),
            'criterio_aceitacao'          => trim((string) ($d['criterio_aceitacao'] ?? 'AWS D15.1 ED.2019')),
            'tipo_junta'                  => trim((string) ($d['tipo_junta'] ?? '')),
            'material'                    => trim((string) ($d['material'] ?? 'ASTM A242')),
            'dimensoes'                   => trim((string) ($d['dimensoes'] ?? '')),
            'metodo'                      => trim((string) ($d['metodo'] ?? 'DIRETO')),
            'condicao_superficie'         => implode(',', (array) ($d['condicao_superficie'] ?? [])),
            'inspecao_realizada_em'       => implode(',', (array) ($d['inspecao_realizada_em'] ?? [])),
            'avaliacao_resultado'         => trim((string) ($d['avaliacao_resultado'] ?? '')),
            'radiografia_resultado'       => trim((string) ($d['radiografia_resultado'] ?? '')),
            'radiografia_interpretada_por' => trim((string) ($d['radiografia_interpretada_por'] ?? '')),
            'observacoes'                 => trim((string) ($d['observacoes'] ?? '')),
        ];
        if ($novo) {
            $fields['numero_relatorio'] = $this->proximoNumero();
            $fields['data'] = date('Y-m-d');
            $fields['ensaio_por_nome'] = $u->nome ?? null;
            $fields['ensaio_por_matricula'] = $u->matricula ?? null;
            $fields['ensaio_data'] = date('Y-m-d H:i:s');
        }
        return $fields;
    }

    private function salvarFilhos(int $ensaioId, array $d): void
    {
        // Instrumentos (uma linha por categoria)
        foreach (self::INSTRUMENTOS as $cat => $label) {
            $tipo = trim((string) ($d["inst_tipo"][$cat] ?? ''));
            $cod  = trim((string) ($d["inst_cod"][$cat] ?? ''));
            $val  = trim((string) ($d["inst_val"][$cat] ?? ''));
            if ($tipo === '' && $cod === '' && $val === '') continue;
            EnsaioVisualInstrumento::insert([
                'ensaio_id'       => $ensaioId,
                'categoria'       => $cat,
                'descricao'       => $label,
                'tipo'            => $tipo,
                'cod_instrumento' => $cod,
                'validade'        => $val,
            ])->finish();
        }

        // Ocorrências (linhas repetíveis)
        $eps = (array) ($d['oc_eps'] ?? []);
        foreach ($eps as $i => $epsv) {
            $sinete = trim((string) ($d['oc_sinete'][$i] ?? ''));
            if (trim((string) $epsv) === '' && $sinete === '') continue;
            $descs = (array) ($d['oc_desc'][$i] ?? []);
            EnsaioVisualOcorrencia::insert([
                'ensaio_id'         => $ensaioId,
                'eps'               => trim((string) $epsv),
                'processo_soldagem' => trim((string) ($d['oc_processo'][$i] ?? '')),
                'sinete'            => $sinete,
                'junta'             => trim((string) ($d['oc_junta'][$i] ?? '')),
                'descontinuidades'  => implode(',', array_map('strval', $descs)),
                'avaliacao'         => trim((string) ($d['oc_aval'][$i] ?? '')),
                'ordem'             => $i,
            ])->finish();
        }
    }

    public function delete(string $uuid): bool
    {
        EnsaioVisual::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }
}
