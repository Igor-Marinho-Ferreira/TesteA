<?php

namespace src\app\services;

use src\app\database\entities\Junta;
use src\app\database\entities\PlanoMetalBase;
use src\traits\CadastroSimples;

class JuntaService
{
    use CadastroSimples;

    private function entity(): string { return Junta::class; }
    private function campoUnico(): string { return 'junta'; }

    /** Normaliza a junta: sem espaços nas pontas e SEMPRE em maiúsculas. */
    public function normalizarJunta(string $valor): string
    {
        return mb_strtoupper(trim($valor), 'UTF-8');
    }

    /**
     * Indica se a junta está referenciada em algum Plano de Soldagem
     * (bloqueia edição/exclusão conforme escopo).
     */
    public function emUso(string $uuid): bool
    {
        $junta = $this->find($uuid);
        if (!$junta) return false;
        $refs = PlanoMetalBase::select()
            ->where('juntas', 'LIKE', '%' . $junta->junta . '%')
            ->finish() ?: [];
        return count($refs) > 0;
    }
}
