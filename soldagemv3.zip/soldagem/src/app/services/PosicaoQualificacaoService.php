<?php

namespace src\app\services;

use src\app\database\entities\PosicaoQualificacao;
use src\app\database\entities\SoldadorProcesso;
use src\app\database\entities\FormularioQualificacaoPosicao;
use src\traits\CadastroSimples;

class PosicaoQualificacaoService
{
    use CadastroSimples;

    /** Opções fixas conforme escopo (2.1.3.2). */
    public const TIPOS = ['1G', '2G', '3G', '4G', '5G', '6G'];
    public const POSICOES = ['Plana', 'Horizontal', 'Vertical', 'Sobre cabeça', 'Múltiplas posições tubo'];
    public const PROGRESSOES = ['Ascendente', 'Descendente'];

    private function entity(): string { return PosicaoQualificacao::class; }
    private function campoUnico(): string { return 'tipo'; }

    /**
     * A progressão só é válida quando a posição é "Vertical".
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function sanitize(array $data): array
    {
        $posicao   = (string) ($data['posicao'] ?? '');
        $progressao = null;
        if ($posicao === 'Vertical' && !empty($data['progressao'])) {
            $progressao = (string) $data['progressao'];
        }
        return [
            'tipo'       => (string) ($data['tipo'] ?? ''),
            'posicao'    => $posicao,
            'progressao' => $progressao,
        ];
    }

    /**
     * Duplicidade considera tipo + posição + progressão.
     */
    public function duplicadoCombo(string $tipo, string $posicao, ?string $progressao, ?string $ignoreUuid = null): bool
    {
        $achados = PosicaoQualificacao::select()
            ->whereEquals('tipo', $tipo)
            ->andWhereEquals('posicao', $posicao)
            ->andWhereIsNull('deleted_at')
            ->finish() ?: [];

        foreach ($achados as $r) {
            if ((string) $r->progressao === (string) $progressao && ($ignoreUuid === null || $r->uuid !== $ignoreUuid)) {
                return true;
            }
        }
        return false;
    }

    public function emUso(string $uuid): bool
    {
        $p = $this->find($uuid);
        if (!$p) return false;

        $refProc = SoldadorProcesso::select()->whereEquals('posicao_id', $p->id)->finish() ?: [];
        if (count($refProc) > 0) return true;

        $refForm = FormularioQualificacaoPosicao::select()->whereEquals('posicao_id', $p->id)->finish() ?: [];
        return count($refForm) > 0;
    }

    /** Rótulo legível: "1G - Plana" ou "3G - Vertical (Ascendente)". */
    public function label(object $p): string
    {
        $txt = "{$p->tipo} - {$p->posicao}";
        if (!empty($p->progressao)) $txt .= " ({$p->progressao})";
        return $txt;
    }
}
