<?php

namespace src\app\services;

use src\app\database\entities\Checklist;
use src\app\database\entities\ChecklistParametro;
use src\app\database\entities\Soldador;
use src\app\database\entities\ModeloVagao;
use src\app\database\entities\Cliente;
use src\app\database\entities\EstagioSoldagem;

class ChecklistService
{
    /**
     * Parâmetros controlados do checklist (Encontrado × Especificado).
     * chave => rótulo.
     */
    public const PARAMETROS = [
        'nr_eps'                 => 'Nº EPS',
        'posicao_processo'       => 'Posição / Processo',
        'tensao'                 => 'Tensão (V)',
        'corrente'               => 'Corrente (A)',
        'vazao_gas'              => 'Vazão de Gás (l/min)',
        'maquina_calibracao'     => 'Nº Máquina / Validade Calibração',
        'marca'                  => 'Marca (Fabricante do Arame)',
        'classificacao_arame'    => 'Classificação do Arame',
        'temperatura_interpasse' => 'Temperatura Interpasse',
        'fluxo'                  => 'Fluxo',
    ];

    /** @return array<int, object> */
    public function listAll(): array
    {
        $rows = Checklist::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
        foreach ($rows as $r) {
            $r->modelo_nome  = $r->modelo_id ? (ModeloVagao::getById((int) $r->modelo_id)->modelo ?? '') : '';
            $r->cliente_nome = $r->cliente_id ? (Cliente::getById((int) $r->cliente_id)->cliente ?? '') : '';
            $r->estagio_nome = $r->estagio_id ? (EstagioSoldagem::getById((int) $r->estagio_id)->estagio ?? '') : '';
        }
        return $rows;
    }

    public function find(string $uuid): mixed
    {
        return Checklist::getByUuid($uuid);
    }

    /** @return array<int, object> parâmetros do checklist */
    public function parametrosDo(int $checklistId): array
    {
        return ChecklistParametro::select()->whereEquals('checklist_id', $checklistId)->order('ordem', 'ASC')->finish() ?: [];
    }

    /**
     * Cria o checklist e seus parâmetros. Calcula o status de verificação
     * automaticamente comparando Encontrado × Especificado.
     * @param array<string, mixed> $d
     */
    public function store(array $d): void
    {
        $status = $this->calcularStatus($d);
        $novo = Checklist::create($this->cabecalho($d, $status));
        $id = is_object($novo) ? ($novo->id ?? null) : ($novo['id'] ?? null);
        if ($id) $this->salvarParametros((int) $id, $d);
    }

    public function update(string $uuid, array $d): void
    {
        $status = $this->calcularStatus($d);
        $fields = $this->cabecalho($d, $status);
        $fields['updated_at'] = date('Y-m-d H:i:s');
        Checklist::update($fields)->whereEquals('uuid', $uuid)->finish();

        $chk = $this->find($uuid);
        if ($chk) {
            ChecklistParametro::delete()->where('checklist_id', '=', $chk->id)->finish();
            $this->salvarParametros((int) $chk->id, $d);
        }
    }

    public function delete(string $uuid): bool
    {
        Checklist::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    /**
     * @param array<string, mixed> $d
     * @return array<string, mixed>
     */
    private function cabecalho(array $d, string $status): array
    {
        $u = user();
        return [
            'modelo_id'           => ($d['modelo_id'] ?? '') !== '' ? (int) $d['modelo_id'] : null,
            'cliente_id'          => ($d['cliente_id'] ?? '') !== '' ? (int) $d['cliente_id'] : null,
            'numero_viga_vagao'   => trim((string) ($d['numero_viga_vagao'] ?? '')),
            'estagio_id'          => ($d['estagio_id'] ?? '') !== '' ? (int) $d['estagio_id'] : null,
            'desenho_revisao'     => trim((string) ($d['desenho_revisao'] ?? '')),
            'metal_base'          => trim((string) ($d['metal_base'] ?? '')),
            'matricula'           => trim((string) ($d['matricula'] ?? '')),
            'nome'                => trim((string) ($d['nome'] ?? '')),
            'sinete'              => trim((string) ($d['sinete'] ?? '')),
            'qualificacao'        => trim((string) ($d['qualificacao'] ?? '')),
            'qualificacao_alerta' => trim((string) ($d['qualificacao_alerta'] ?? 'ok')),
            'preenchido_por'      => $u->nome ?? null,
            'matricula_preenchido' => $u->matricula ?? null,
            'data'                => date('Y-m-d'),
            'status_verificacao'  => $status,
            'observacao'          => trim((string) ($d['observacao'] ?? '')),
        ];
    }

    private function salvarParametros(int $checklistId, array $d): void
    {
        $enc = (array) ($d['encontrado'] ?? []);
        $esp = (array) ($d['especificado'] ?? []);
        $ordem = 0;
        foreach (self::PARAMETROS as $chave => $label) {
            ChecklistParametro::insert([
                'checklist_id' => $checklistId,
                'campo'        => $chave,
                'encontrado'   => trim((string) ($enc[$chave] ?? '')),
                'especificado' => trim((string) ($esp[$chave] ?? '')),
                'ordem'        => $ordem++,
            ])->finish();
        }
    }

    /**
     * Status automático: Reprovado se algum parâmetro divergir da EPS
     * (Encontrado ≠ Especificado, ambos preenchidos); senão Aprovado.
     */
    public function calcularStatus(array $d): string
    {
        $enc = (array) ($d['encontrado'] ?? []);
        $esp = (array) ($d['especificado'] ?? []);
        foreach (self::PARAMETROS as $chave => $label) {
            $e = mb_strtolower(trim((string) ($enc[$chave] ?? '')));
            $s = mb_strtolower(trim((string) ($esp[$chave] ?? '')));
            if ($e !== '' && $s !== '' && $e !== $s) {
                return 'Reprovado';
            }
        }
        return 'Aprovado';
    }

    /**
     * Busca dados do soldador pela matrícula (nome, sinete, qualificação) e
     * calcula o alerta de vencimento da qualificação para exibir em tela.
     * @return array{nome:string, sinete:string, qualificacao:string, alerta:string}|null
     */
    public function dadosSoldador(string $matricula): ?array
    {
        $s = Soldador::selectOne()->whereEquals('matricula', $matricula)->andWhereIsNull('deleted_at')->finish();
        if (!$s) return null;

        $alerta = 'ok';
        if (!empty($s->data_requalificacao)) {
            $dias = (new SoldadorService)->diasParaVencer($s->data_requalificacao);
            if ($dias !== null) {
                if ($dias < 0) $alerta = 'vencida';
                elseif ($dias < 30) $alerta = 'a_vencer';
            }
        }
        return [
            'nome'         => (string) ($s->nome ?? ''),
            'sinete'       => (string) ($s->sinete ?? ''),
            'qualificacao' => (string) ($s->status_qualificacao ?? ''),
            'alerta'       => $alerta,
        ];
    }
}
