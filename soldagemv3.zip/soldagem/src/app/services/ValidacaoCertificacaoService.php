<?php

namespace src\app\services;

use src\app\database\entities\ValidacaoCertificacaoLog;
use src\app\database\entities\SoldadorProcesso;

/**
 * Validação de continuidade da qualificação do soldador (AWS D1.1 – 4.2.3.2).
 *
 * A qualificação é válida se houver evidência de execução do mesmo processo e
 * posição dentro de um período não superior a 6 meses. As janelas de 30/40/60
 * dias são controles internos (alerta preventivo), não substituem os 6 meses.
 *
 * OBS.: a integração real lê a tela do MES (Critéria > Produção > Histórico
 * Login). Aqui a validação usa a data de requalificação do soldador e o
 * vínculo Estação × Qualificação; a leitura do MES entra quando disponível.
 */
class ValidacaoCertificacaoService
{
    /** @return array<int, object> */
    public function logs(): array
    {
        return ValidacaoCertificacaoLog::select()->order('id', 'DESC')->limit(200)->finish() ?: [];
    }

    /**
     * Valida um soldador em uma estação e registra o log.
     *
     * @return array{resultado:string, motivo:string, janela:?string, dias:?int}
     */
    public function validar(string $matricula, string $codigoEstacao): array
    {
        $soldadorService = new SoldadorService;
        $estacaoService  = new EstacaoQualificacaoService;

        $soldador = $soldadorService->findByMatricula($matricula);
        $estacao  = $estacaoService->findByEstacao($codigoEstacao);

        $resultado = 'bloqueado';
        $motivo    = '';
        $janela    = null;
        $dias      = null;

        if (!$soldador) {
            $motivo = 'Soldador não encontrado.';
        } elseif (($soldador->status ?? 'ativo') !== 'ativo') {
            $motivo = 'Soldador inativo.';
        } elseif (!$estacao) {
            $motivo = 'Estação sem vínculo de qualificação ativo.';
        } else {
            $dias = $soldadorService->diasParaVencer($soldador->data_requalificacao ?? null);

            // Continuidade AWS: dentro de 6 meses (data_requalificacao não vencida).
            if ($dias === null) {
                $motivo = 'Sem data de requalificação registrada.';
            } elseif ($dias < 0) {
                $motivo = 'Qualificação vencida (fora dos 6 meses AWS).';
            } else {
                // Verifica se o soldador possui o processo e posição exigidos pela estação.
                $temVinculo = $this->soldadorTemVinculo(
                    (int) $soldador->id,
                    $estacao->processo_solda_id ? (int) $estacao->processo_solda_id : null,
                    $estacao->posicao_solda_id ? (int) $estacao->posicao_solda_id : null
                );
                if (!$temVinculo) {
                    $motivo = 'Soldador não qualificado para o processo/posição da estação.';
                } else {
                    $resultado = 'validado';
                    $motivo    = 'Qualificação válida e contínua.';
                }
                // Janela de alerta preventivo
                if ($dias < 30) $janela = '30';
                elseif ($dias < 40) $janela = '40';
                elseif ($dias < 60) $janela = '60';
            }
        }

        ValidacaoCertificacaoLog::create([
            'soldador_id' => $soldador->id ?? null,
            'matricula'   => $matricula,
            'estacao'     => $codigoEstacao,
            'processo'    => $estacao ? $estacaoService->labelProcesso($estacao->processo_solda_id ? (int) $estacao->processo_solda_id : null) : null,
            'posicao'     => $estacao ? $estacaoService->labelPosicao($estacao->posicao_solda_id ? (int) $estacao->posicao_solda_id : null) : null,
            'data_login'  => date('Y-m-d H:i:s'),
            'resultado'   => $resultado,
            'janela'      => $janela,
        ], false);

        if ($resultado === 'bloqueado') {
            EmailService::enviar(
                "Validação bloqueada — matrícula {$matricula}",
                "<p>A validação de continuidade da certificação foi <strong>bloqueada</strong>.</p>"
                . "<ul><li><strong>Matrícula:</strong> " . htmlspecialchars($matricula) . "</li>"
                . "<li><strong>Estação:</strong> " . htmlspecialchars($codigoEstacao) . "</li>"
                . "<li><strong>Motivo:</strong> " . htmlspecialchars($motivo) . "</li></ul>"
            );
        }

        return ['resultado' => $resultado, 'motivo' => $motivo, 'janela' => $janela, 'dias' => $dias];
    }

    private function soldadorTemVinculo(int $soldadorId, ?int $qualificacaoId, ?int $posicaoId): bool
    {
        if (!$qualificacaoId) return false;
        $rows = SoldadorProcesso::select()
            ->whereEquals('soldador_id', $soldadorId)
            ->andWhereEquals('qualificacao_id', $qualificacaoId)
            ->finish() ?: [];
        foreach ($rows as $r) {
            if ($posicaoId === null || (int) $r->posicao_id === $posicaoId) {
                return true;
            }
        }
        return false;
    }
}
