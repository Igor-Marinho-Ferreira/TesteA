<?php

namespace src\app\services;

use src\app\database\entities\Desenho;
use src\app\database\entities\PlanoSoldagem;

class DesenhoService
{
    private const DIR_REL = 'desenhos';
    private const ALLOWED = ['png', 'jpg', 'jpeg', 'pdf'];
    private const MAX_BYTES = 5_242_880; // 5 MB

    /** @return array<int, object> */
    public function listAll(): array
    {
        return Desenho::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return Desenho::getByUuid($uuid);
    }

    public function findByNumero(string $numero): mixed
    {
        return Desenho::selectOne()->whereEquals('numero', $numero)->andWhereIsNull('deleted_at')->finish();
    }

    public function existeDuplicado(string $numero, ?string $ignoreUuid = null): bool
    {
        $achados = Desenho::select()->whereEquals('numero', $numero)->andWhereIsNull('deleted_at')->finish() ?: [];
        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) return true;
        }
        return false;
    }

    /** Valida o arquivo enviado (opcional). Retorna erro ou null. */
    public function imagemError(): ?string
    {
        $f = $_FILES['imagem'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
        if ($f['error'] !== UPLOAD_ERR_OK) return 'Falha no envio da imagem.';
        if ($f['size'] > self::MAX_BYTES) return 'A imagem excede o tamanho máximo de 5 MB.';
        $ext = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, self::ALLOWED, true)) return 'Tipo inválido. Use PNG, JPG ou PDF.';
        return null;
    }

    private function moverImagem(): ?string
    {
        $f = $_FILES['imagem'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;

        $dirAbs = rtrim(path()->storage_server(''), '/') . '/' . self::DIR_REL;
        if (!is_dir($dirAbs)) mkdir($dirAbs, 0775, true);

        $ext  = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
        $nome = bin2hex(random_bytes(8)) . '.' . $ext;
        if (move_uploaded_file($f['tmp_name'], $dirAbs . '/' . $nome)) {
            return self::DIR_REL . '/' . $nome;
        }
        return null;
    }

    public function store(array $d): bool|array|object
    {
        $img = $this->moverImagem();
        return Desenho::create([
            'numero' => trim((string) ($d['numero'] ?? '')),
            'imagem' => $img,
        ]);
    }

    public function update(string $uuid, array $d): mixed
    {
        $fields = [
            'numero'     => trim((string) ($d['numero'] ?? '')),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        $img = $this->moverImagem();
        if ($img) $fields['imagem'] = $img;
        return Desenho::update($fields)->whereEquals('uuid', $uuid)->finish();
    }

    public function delete(string $uuid): bool
    {
        Desenho::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    public function emUso(string $uuid): bool
    {
        $d = $this->find($uuid);
        if (!$d) return false;
        $refs = PlanoSoldagem::select()->whereEquals('desenho_numero', $d->numero)->andWhereIsNull('deleted_at')->finish() ?: [];
        return count($refs) > 0;
    }
}
