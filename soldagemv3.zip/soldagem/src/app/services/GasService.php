<?php

namespace src\app\services;

use src\app\database\entities\Gas;
use src\app\database\entities\GasComponente;
use src\app\database\entities\PlanoParametro;

class GasService
{
    /** @return array<int, object> gases com resumo dos componentes */
    public function listAll(): array
    {
        $rows = Gas::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
        foreach ($rows as $r) {
            $comps = $this->componentesDo((int) $r->id);
            $r->componentes = $comps;
            $resumo = [];
            foreach ($comps as $c) {
                $resumo[] = trim(($c->composicao ?? '') . ($c->percentual !== null ? ' ' . rtrim(rtrim((string) $c->percentual, '0'), '.') . '%' : ''));
            }
            $r->resumo = implode(' + ', array_filter($resumo));
        }
        return $rows;
    }

    public function find(string $uuid): mixed
    {
        return Gas::getByUuid($uuid);
    }

    /** @return array<int, object> */
    public function componentesDo(int $gasId): array
    {
        return GasComponente::select()->whereEquals('gas_id', $gasId)->order('ordem', 'ASC')->finish() ?: [];
    }

    /** Duplicidade pelo nome do gás (ativos). */
    public function existeDuplicado(string $gas, ?string $ignoreUuid = null): bool
    {
        $achados = Gas::select()->whereEquals('gas', $gas)->andWhereIsNull('deleted_at')->finish() ?: [];
        foreach ($achados as $r) {
            if ($ignoreUuid === null || $r->uuid !== $ignoreUuid) return true;
        }
        return false;
    }

    /**
     * Cria o gás (restaurando um excluído com o mesmo nome, se houver) e salva
     * seus componentes.
     * @param array<string,mixed> $d  (gas, composicao[], percentual[])
     */
    public function store(array $d): void
    {
        $gas = trim((string) ($d['gas'] ?? ''));

        // Restore-on-recreate por nome.
        $existente = Gas::selectOne()->whereEquals('gas', $gas)->finish();
        if ($existente && $existente->deleted_at !== null) {
            Gas::update(['gas' => $gas, 'deleted_at' => null, 'updated_at' => date('Y-m-d H:i:s')])
                ->whereEquals('uuid', $existente->uuid)->finish();
            $id = (int) $existente->id;
        } else {
            $novo = Gas::create(['gas' => $gas]);
            $id = (int) (is_object($novo) ? ($novo->id ?? 0) : ($novo['id'] ?? 0));
        }

        if ($id) {
            GasComponente::delete()->where('gas_id', '=', $id)->finish();
            $this->salvarComponentes($id, $d);
        }
    }

    public function update(string $uuid, array $d): void
    {
        Gas::update(['gas' => trim((string) ($d['gas'] ?? '')), 'updated_at' => date('Y-m-d H:i:s')])
            ->whereEquals('uuid', $uuid)->finish();

        $gas = $this->find($uuid);
        if ($gas) {
            GasComponente::delete()->where('gas_id', '=', $gas->id)->finish();
            $this->salvarComponentes((int) $gas->id, $d);
        }
    }

    private function salvarComponentes(int $gasId, array $d): void
    {
        $comps = (array) ($d['composicao'] ?? []);
        $percs = (array) ($d['percentual'] ?? []);
        $ordem = 0;
        foreach ($comps as $i => $comp) {
            $comp = trim((string) $comp);
            $perc = trim((string) ($percs[$i] ?? ''));
            if ($comp === '' && $perc === '') continue;
            GasComponente::insert([
                'gas_id'     => $gasId,
                'composicao' => $comp !== '' ? $comp : null,
                'percentual' => $perc !== '' ? str_replace(',', '.', $perc) : null,
                'ordem'      => $ordem++,
            ])->finish();
        }
    }

    public function delete(string $uuid): bool
    {
        Gas::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    public function emUso(string $uuid): bool
    {
        $gas = $this->find($uuid);
        if (!$gas) return false;
        $refs = PlanoParametro::select()->where('gas', 'LIKE', '%' . $gas->gas . '%')->finish() ?: [];
        return count($refs) > 0;
    }
}
