<?php

namespace src\app\services;

use src\app\database\entities\PlanoSoldagem;
use src\app\database\entities\PlanoMetalBase;
use src\app\database\entities\PlanoDetalheJunta;
use src\app\database\entities\PlanoParametro;
use src\app\database\entities\PlanoEtapaLog;
use src\app\database\entities\Desenho;
use src\app\services\EmailService;

class PlanoSoldagemService
{
    public const POLARIDADES = ['CCP', 'CCEN', 'CA'];

    /** @return array<int, object> */
    public function listAll(): array
    {
        return PlanoSoldagem::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
    }

    public function find(string $uuid): mixed
    {
        return PlanoSoldagem::getByUuid($uuid);
    }

    /** @return array<int, object> */
    public function metalBaseDo(int $planoId): array
    {
        return PlanoMetalBase::select()->whereEquals('plano_id', $planoId)->order('ordem', 'ASC')->finish() ?: [];
    }

    /** @return array<int, object> */
    public function detalheDo(int $planoId): array
    {
        return PlanoDetalheJunta::select()->whereEquals('plano_id', $planoId)->order('ordem', 'ASC')->finish() ?: [];
    }

    /** @return array<int, object> */
    public function parametrosDo(int $planoId): array
    {
        return PlanoParametro::select()->whereEquals('plano_id', $planoId)->order('ordem', 'ASC')->finish() ?: [];
    }

    /** @return array<int, object> */
    public function logsDo(int $planoId): array
    {
        return PlanoEtapaLog::select()->whereEquals('plano_id', $planoId)->order('id', 'DESC')->finish() ?: [];
    }

    /** Próximo PS n.º no formato N/YY (incremental por ano). */
    public function proximoPsNumero(): string
    {
        $yy = date('y');
        $planos = PlanoSoldagem::select(['ps_numero'])->finish() ?: [];
        $max = 0;
        foreach ($planos as $p) {
            if (preg_match('#^(\d+)/' . $yy . '$#', (string) $p->ps_numero, $m)) {
                $n = (int) $m[1];
                if ($n > $max) $max = $n;
            }
        }
        return ($max + 1) . '/' . $yy;
    }

    /**
     * Cria o plano (etapa Elaborado) com todas as seções.
     * @param array<string, mixed> $d
     */
    public function store(array $d): void
    {
        $novo = PlanoSoldagem::create([
            'ps_numero'      => trim((string) ($d['ps_numero'] ?? $this->proximoPsNumero())),
            'rev'            => trim((string) ($d['rev'] ?? '')),
            'projeto'        => trim((string) ($d['projeto'] ?? '')),
            'data'           => trim((string) ($d['data'] ?? '')) ?: date('Y-m-d'),
            'desenho_numero' => trim((string) ($d['desenho_numero'] ?? '')),
            'titulo'         => trim((string) ($d['titulo'] ?? '')),
            'etapa'          => 'elaborado',
            'status'         => 'em_andamento',
        ]);
        $id = is_object($novo) ? ($novo->id ?? null) : ($novo['id'] ?? null);
        if ($id) {
            $this->salvarSecoes((int) $id, $d);
            $this->log((int) $id, 'elaborado', null, 'Plano elaborado.');
        }
    }

    public function update(string $uuid, array $d): void
    {
        PlanoSoldagem::update([
            'ps_numero'      => trim((string) ($d['ps_numero'] ?? '')),
            'rev'            => trim((string) ($d['rev'] ?? '')),
            'projeto'        => trim((string) ($d['projeto'] ?? '')),
            'data'           => trim((string) ($d['data'] ?? '')) ?: null,
            'desenho_numero' => trim((string) ($d['desenho_numero'] ?? '')),
            'titulo'         => trim((string) ($d['titulo'] ?? '')),
            'updated_at'     => date('Y-m-d H:i:s'),
        ])->whereEquals('uuid', $uuid)->finish();

        $plano = $this->find($uuid);
        if ($plano) {
            PlanoMetalBase::delete()->where('plano_id', '=', $plano->id)->finish();
            PlanoDetalheJunta::delete()->where('plano_id', '=', $plano->id)->finish();
            PlanoParametro::delete()->where('plano_id', '=', $plano->id)->finish();
            $this->salvarSecoes((int) $plano->id, $d);
        }
    }

    private function salvarSecoes(int $planoId, array $d): void
    {
        // Metal Base
        $juntas = (array) ($d['mb_juntas'] ?? []);
        foreach ($juntas as $i => $jt) {
            if (trim((string) $jt) === '' && trim((string) ($d['mb_material'][$i] ?? '')) === '') continue;
            PlanoMetalBase::insert([
                'plano_id'       => $planoId,
                'juntas'         => trim((string) $jt),
                'eps_referencia' => trim((string) ($d['mb_eps'][$i] ?? '')),
                'processo'       => trim((string) ($d['mb_processo'][$i] ?? '')),
                'peca'           => ($d['mb_peca'][$i] ?? '') !== '' ? (int) $d['mb_peca'][$i] : null,
                'material'       => trim((string) ($d['mb_material'][$i] ?? '')),
                'ordem'          => $i,
            ])->finish();
        }

        // Detalhe da Junta (imagem puxada do desenho, se houver)
        $imagemDesenho = null;
        $desNumero = trim((string) ($d['desenho_numero'] ?? ''));
        if ($desNumero !== '') {
            $des = Desenho::selectOne()->whereEquals('numero', $desNumero)->finish();
            if ($des) $imagemDesenho = $des->imagem;
        }
        $posicoes = (array) ($d['dj_posicao'] ?? []);
        foreach ($posicoes as $i => $pos) {
            if (trim((string) $pos) === '' && trim((string) ($d['dj_junta'][$i] ?? '')) === '') continue;
            PlanoDetalheJunta::insert([
                'plano_id' => $planoId,
                'imagem'   => $imagemDesenho,
                'posicao'  => trim((string) $pos),
                'junta'    => trim((string) ($d['dj_junta'][$i] ?? '')),
                'ordem'    => $i,
            ])->finish();
        }

        // Parâmetros de Soldagem
        $pjuntas = (array) ($d['pr_junta'] ?? []);
        foreach ($pjuntas as $i => $jt) {
            if (trim((string) $jt) === '' && trim((string) ($d['pr_gas'][$i] ?? '')) === '') continue;
            PlanoParametro::insert([
                'plano_id'        => $planoId,
                'junta'           => trim((string) $jt),
                'gas'             => trim((string) ($d['pr_gas'][$i] ?? '')),
                'vazao'           => trim((string) ($d['pr_vazao'][$i] ?? '')),
                'consumivel'      => trim((string) ($d['pr_consumivel'][$i] ?? '')),
                'bitola'          => ($d['pr_bitola'][$i] ?? '') !== '' ? str_replace(',', '.', (string) $d['pr_bitola'][$i]) : null,
                'pol'             => trim((string) ($d['pr_pol'][$i] ?? '')),
                'tensao'          => trim((string) ($d['pr_tensao'][$i] ?? '')),
                'corrente'        => trim((string) ($d['pr_corrente'][$i] ?? '')),
                'vel_soldagem'    => trim((string) ($d['pr_vel'][$i] ?? '')),
                'temp_max_interp' => trim((string) ($d['pr_temp'][$i] ?? '')),
                'ordem'           => $i,
            ])->finish();
        }
    }

    public function delete(string $uuid): bool
    {
        PlanoSoldagem::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    /**
     * Etapa Verificado: se "de acordo" = não, retorna para Elaborado.
     */
    public function verificar(string $uuid, string $deAcordo, string $observacao): void
    {
        $plano = $this->find($uuid);
        if (!$plano) return;

        if (strtolower($deAcordo) === 'sim') {
            PlanoSoldagem::update(['etapa' => 'verificado', 'updated_at' => date('Y-m-d H:i:s')])->whereEquals('uuid', $uuid)->finish();
            $this->log((int) $plano->id, 'verificado', 'sim', $observacao);
        } else {
            PlanoSoldagem::update(['etapa' => 'elaborado', 'updated_at' => date('Y-m-d H:i:s')])->whereEquals('uuid', $uuid)->finish();
            $this->log((int) $plano->id, 'verificado', 'nao', $observacao . ' (retornado para elaboração)');
        }
    }

    /**
     * Etapa Aprovado: aprovar libera o plano; rejeitar retorna para elaboração.
     */
    public function aprovar(string $uuid, string $acao, string $observacao): void
    {
        $plano = $this->find($uuid);
        if (!$plano) return;

        if (strtolower($acao) === 'aprovar') {
            PlanoSoldagem::update(['etapa' => 'aprovado', 'status' => 'aprovado', 'updated_at' => date('Y-m-d H:i:s')])->whereEquals('uuid', $uuid)->finish();
            $this->log((int) $plano->id, 'aprovado', 'aprovar', $observacao);
            EmailService::enviar(
                "Plano de Soldagem {$plano->ps_numero} aprovado",
                "<p>O Plano de Soldagem <strong>{$plano->ps_numero}</strong> — " . htmlspecialchars((string) ($plano->titulo ?? '')) . " foi <strong>aprovado</strong> e liberado para uso operacional.</p>"
                . ($observacao ? '<p><em>Observação:</em> ' . htmlspecialchars($observacao) . '</p>' : '')
            );
        } else {
            PlanoSoldagem::update(['etapa' => 'elaborado', 'status' => 'rejeitado', 'updated_at' => date('Y-m-d H:i:s')])->whereEquals('uuid', $uuid)->finish();
            $this->log((int) $plano->id, 'aprovado', 'rejeitar', $observacao . ' (rejeitado)');
        }
    }

    private function log(int $planoId, string $etapa, ?string $resposta, string $observacao): void
    {
        $u = user();
        PlanoEtapaLog::create([
            'plano_id'      => $planoId,
            'etapa'         => $etapa,
            'resposta'      => $resposta,
            'observacao'    => $observacao,
            'usuario_login' => $u->matricula ?? null,
            'usuario_nome'  => $u->nome ?? null,
            'matricula'     => $u->matricula ?? null,
        ], false);
    }

    public function etapaLabel(string $etapa): string
    {
        return ['elaborado' => 'Elaborado', 'verificado' => 'Verificado', 'aprovado' => 'Aprovado'][$etapa] ?? $etapa;
    }
}
