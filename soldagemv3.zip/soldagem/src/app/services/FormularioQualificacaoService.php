<?php

namespace src\app\services;

use src\app\database\entities\FormularioQualificacao;
use src\app\database\entities\FormularioQualificacaoPosicao;
use src\app\database\entities\Qualificacao;
use src\app\database\entities\PosicaoQualificacao;

class FormularioQualificacaoService
{
    /** @return array<int, object> */
    public function listAll(): array
    {
        $rows = FormularioQualificacao::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
        foreach ($rows as $r) {
            $q = Qualificacao::getById((int) $r->qualificacao_id);
            $r->processo = $q ? $q->qualificacao : '—';
        }
        return $rows;
    }

    public function find(string $uuid): mixed
    {
        return FormularioQualificacao::getByUuid($uuid);
    }

    public function store(array $d): void
    {
        $novo = FormularioQualificacao::create([
            'qualificacao_id' => (int) ($d['qualificacao_id'] ?? 0),
            'descricao'       => trim((string) ($d['descricao'] ?? '')),
        ]);
        $id = is_object($novo) ? ($novo->id ?? null) : ($novo['id'] ?? null);
        if ($id) $this->salvarPosicoes((int) $id, (array) ($d['posicoes'] ?? []));
    }

    public function update(string $uuid, array $d): void
    {
        FormularioQualificacao::update([
            'qualificacao_id' => (int) ($d['qualificacao_id'] ?? 0),
            'descricao'       => trim((string) ($d['descricao'] ?? '')),
            'updated_at'      => date('Y-m-d H:i:s'),
        ])->whereEquals('uuid', $uuid)->finish();

        $f = $this->find($uuid);
        if ($f) {
            FormularioQualificacaoPosicao::delete()->where('formulario_id', '=', $f->id)->finish();
            $this->salvarPosicoes((int) $f->id, (array) ($d['posicoes'] ?? []));
        }
    }

    private function salvarPosicoes(int $formularioId, array $posicoes): void
    {
        foreach ($posicoes as $pid) {
            if ($pid === '' || $pid === null) continue;
            FormularioQualificacaoPosicao::insert(['formulario_id' => $formularioId, 'posicao_id' => (int) $pid])->finish();
        }
    }

    public function delete(string $uuid): bool
    {
        FormularioQualificacao::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    /** @return array<int, int> ids de posições vinculadas */
    public function posicoesDo(int $formularioId): array
    {
        $rows = FormularioQualificacaoPosicao::select(['posicao_id'])->whereEquals('formulario_id', $formularioId)->finish() ?: [];
        return array_map(fn($r) => (int) $r->posicao_id, $rows);
    }

    /**
     * Formulários prontos para "montar" o RQS: cada item traz processo,
     * descrição e os rótulos das posições vinculadas.
     *
     * @return array<int, array{id:int, processo:string, descricao:string, posicoes:string}>
     */
    public function paraMontagem(): array
    {
        $out = [];
        foreach ($this->listAll() as $f) {
            $labels = [];
            foreach ($this->posicoesDo((int) $f->id) as $pid) {
                $p = PosicaoQualificacao::getById($pid);
                if ($p) {
                    $txt = "{$p->tipo} - {$p->posicao}";
                    if (!empty($p->progressao)) $txt .= " ({$p->progressao})";
                    $labels[] = $txt;
                }
            }
            $out[] = [
                'id'        => (int) $f->id,
                'processo'  => (string) $f->processo,
                'descricao' => (string) ($f->descricao ?? ''),
                'posicoes'  => implode(', ', $labels),
            ];
        }
        return $out;
    }
}
