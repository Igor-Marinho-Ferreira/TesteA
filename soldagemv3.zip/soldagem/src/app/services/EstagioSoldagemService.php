<?php

namespace src\app\services;

use src\app\database\entities\EstagioSoldagem;
use src\app\database\entities\Checklist;
use src\traits\CadastroSimples;

class EstagioSoldagemService
{
    use CadastroSimples;

    private function entity(): string { return EstagioSoldagem::class; }
    private function campoUnico(): string { return 'estagio'; }

    public function emUso(string $uuid): bool
    {
        $es = $this->find($uuid);
        if (!$es) return false;
        $refs = Checklist::select()->whereEquals('estagio_id', $es->id)->finish() ?: [];
        return count($refs) > 0;
    }
}
