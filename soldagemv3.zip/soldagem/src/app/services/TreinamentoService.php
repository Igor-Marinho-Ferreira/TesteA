<?php

namespace src\app\services;

use src\app\database\entities\Treinamento;
use src\app\database\entities\SoldadorTreinamento;
use src\traits\CadastroSimples;

class TreinamentoService
{
    use CadastroSimples;

    private function entity(): string { return Treinamento::class; }
    private function campoUnico(): string { return 'treinamento'; }

    /**
     * Bloqueia edição/exclusão se houver soldador referenciando o treinamento.
     */
    public function emUso(string $uuid): bool
    {
        $t = $this->find($uuid);
        if (!$t) return false;
        $refs = SoldadorTreinamento::select()
            ->whereEquals('treinamento_id', $t->id)
            ->finish() ?: [];
        return count($refs) > 0;
    }
}
