<?php

namespace src\app\services;

use src\app\database\entities\MetalBase;
use src\app\database\entities\PlanoMetalBase;
use src\traits\CadastroSimples;

class MetalBaseService
{
    use CadastroSimples;

    private function entity(): string { return MetalBase::class; }
    private function campoUnico(): string { return 'metal_base'; }

    public function emUso(string $uuid): bool
    {
        $mb = $this->find($uuid);
        if (!$mb) return false;
        $refs = PlanoMetalBase::select()
            ->whereEquals('material', $mb->metal_base)
            ->finish() ?: [];
        return count($refs) > 0;
    }
}
