<?php

namespace src\app\services;

use src\app\database\entities\Qualificacao;
use src\app\database\entities\SoldadorProcesso;
use src\app\database\entities\FormularioQualificacao;
use src\traits\CadastroSimples;

class QualificacaoService
{
    use CadastroSimples;

    public const MODO_TRANSFERENCIA_PADRAO = 'CURTO-CIRCUITO';

    private function entity(): string { return Qualificacao::class; }
    private function campoUnico(): string { return 'qualificacao'; }

    /**
     * Normaliza os campos de qualificação para persistência.
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function sanitize(array $data): array
    {
        $regraEspecial = !empty($data['regra_especial']) ? 1 : 0;

        return [
            'qualificacao'       => strtoupper(trim((string) ($data['qualificacao'] ?? ''))),
            'descricao'          => trim((string) ($data['descricao'] ?? '')),
            'regra_especial'     => $regraEspecial,
            'modo_transferencia' => $regraEspecial
                ? (trim((string) ($data['modo_transferencia'] ?? '')) ?: self::MODO_TRANSFERENCIA_PADRAO)
                : null,
        ];
    }

    /**
     * Autocomplete: qualificações cujo nome contém o termo digitado.
     * @return array<int, object>
     */
    public function autocomplete(string $termo): array
    {
        if (trim($termo) === '') return [];
        return Qualificacao::select()
            ->where('qualificacao', 'LIKE', '%' . $termo . '%')
            ->andWhereIsNull('deleted_at')
            ->finish() ?: [];
    }

    public function emUso(string $uuid): bool
    {
        $q = $this->find($uuid);
        if (!$q) return false;

        $refProc = SoldadorProcesso::select()->whereEquals('qualificacao_id', $q->id)->finish() ?: [];
        if (count($refProc) > 0) return true;

        $refForm = FormularioQualificacao::select()
            ->whereEquals('qualificacao_id', $q->id)
            ->andWhereIsNull('deleted_at')
            ->finish() ?: [];
        return count($refForm) > 0;
    }
}
