<?php

namespace src\app\services;

use src\app\database\entities\Cliente;
use src\app\database\entities\Checklist;
use src\traits\CadastroSimples;

class ClienteService
{
    use CadastroSimples;

    private function entity(): string { return Cliente::class; }
    private function campoUnico(): string { return 'cliente'; }

    public function emUso(string $uuid): bool
    {
        $c = $this->find($uuid);
        if (!$c) return false;
        $refs = Checklist::select()->whereEquals('cliente_id', $c->id)->finish() ?: [];
        return count($refs) > 0;
    }
}
