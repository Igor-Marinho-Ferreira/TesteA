<?php

namespace src\app\services;

use src\app\database\entities\ModeloVagao;
use src\app\database\entities\Checklist;
use src\traits\CadastroSimples;

class ModeloVagaoService
{
    use CadastroSimples;

    private function entity(): string { return ModeloVagao::class; }
    private function campoUnico(): string { return 'modelo'; }

    public function emUso(string $uuid): bool
    {
        $m = $this->find($uuid);
        if (!$m) return false;
        $refs = Checklist::select()->whereEquals('modelo_id', $m->id)->finish() ?: [];
        return count($refs) > 0;
    }
}
