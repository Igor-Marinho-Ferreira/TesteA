<?php

namespace src\app\services;

use src\app\database\entities\Rqs;
use src\app\database\entities\RqsDobramento;
use src\app\database\entities\RqsEtapaLog;
use src\app\database\entities\Soldador;
use src\app\database\entities\Eps;

class RqsService
{
    public const COMPANHIA = 'GREENBRIER MAXION EQUIP. SERV. FERR. S/A';

    /** Variáveis para cada processo (Usado no teste × Faixa de qualificação). */
    public const VARIAVEIS = [
        'metal_base'                => 'Metal Base',
        'espessura'                 => 'Espessura',
        'm_number'                  => 'M-Number',
        'diametro_tubo'             => 'Diâmetro do tubo',
        'backing'                   => 'Backing',
        'espec_metal_adicao'        => 'Especificação Metal de Adição AWS',
        'classificacao_aws'         => 'Classificação AWS',
        'n_f_number'                => 'Nº F Number',
        'tipo_gas_fluxo'            => 'Tipo de Gás / Fluxo',
        'espessura_solda'           => 'Espessura de Solda',
        'inserto_consumivel'        => 'Inserto Consumível',
        'posicao_soldagem'          => 'Posição de Soldagem',
        'solda_topo'                => 'Solda de Topo (chapa/tubo)',
        'solda_angulo'              => 'Solda em Ângulo (chapa/tubo)',
        'progressao'                => 'Progressão',
        'diametro_tubo_chanfro'     => 'Diâmetro do tubo (chanfro)',
        'diametro_tubo_filete'      => 'Diâmetro do tubo (filete)',
        'gas_protecao_raiz_gtaw'    => 'Gás Proteção da raiz (GTAW)',
        'modo_transferencia_gmaw'   => 'Modo de Transferência (GMAW)',
        'tipo_corrente_gtaw'        => 'Tipo de corrente / polaridade (GTAW)',
    ];

    public const TIPO_SECAO = ['transversal', 'longitudinal'];
    public const TIPO_DOBRAMENTO = ['FACE', 'LATERAL', 'RAIZ', 'N/A'];
    public const RESULTADO = ['APROVADO', 'REPROVADO', 'N/A'];

    /** @return array<int, object> */
    public function listAll(): array
    {
        $rows = Rqs::select()->whereIsNull('deleted_at')->order('id', 'DESC')->finish() ?: [];
        foreach ($rows as $r) {
            $s = $r->soldador_id ? Soldador::getById((int) $r->soldador_id) : null;
            $r->soldador_nome = $s ? ($s->nome ?: $s->matricula) : '—';
        }
        return $rows;
    }

    public function find(string $uuid): mixed
    {
        return Rqs::getByUuid($uuid);
    }

    /** @return array<int, object> */
    public function dobramentoDo(int $rqsId): array
    {
        return RqsDobramento::select()->whereEquals('rqs_id', $rqsId)->order('ordem', 'ASC')->finish() ?: [];
    }

    /** @return array<int, object> */
    public function logsDo(int $rqsId): array
    {
        return RqsEtapaLog::select()->whereEquals('rqs_id', $rqsId)->order('id', 'DESC')->finish() ?: [];
    }

    /** Próximo certificado NN/AAAA (reinicia a cada ano). */
    public function proximoCertificado(): string
    {
        $ano = date('Y');
        $rows = Rqs::select(['certificado_numero'])->finish() ?: [];
        $max = 0;
        foreach ($rows as $r) {
            if (preg_match('#^(\d+)/' . $ano . '$#', (string) $r->certificado_numero, $m)) {
                $n = (int) $m[1];
                if ($n > $max) $max = $n;
            }
        }
        return str_pad((string) ($max + 1), 2, '0', STR_PAD_LEFT) . '/' . $ano;
    }

    public function store(array $d): void
    {
        $novo = Rqs::create($this->cabecalho($d, true));
        $id = is_object($novo) ? ($novo->id ?? null) : ($novo['id'] ?? null);
        if ($id) {
            $this->salvarDobramento((int) $id, $d);
            $this->log((int) $id, 'escola', 'RQS elaborado (Escola de Solda).');
        }
    }

    public function update(string $uuid, array $d): void
    {
        $fields = $this->cabecalho($d, false);
        $fields['updated_at'] = date('Y-m-d H:i:s');
        Rqs::update($fields)->whereEquals('uuid', $uuid)->finish();

        $rqs = $this->find($uuid);
        if ($rqs) {
            RqsDobramento::delete()->where('rqs_id', '=', $rqs->id)->finish();
            $this->salvarDobramento((int) $rqs->id, $d);
        }
    }

    /**
     * @param array<string,mixed> $d
     * @return array<string,mixed>
     */
    private function cabecalho(array $d, bool $novo): array
    {
        // variáveis usado/faixa em JSON
        $usado = [];
        $faixa = [];
        foreach (self::VARIAVEIS as $k => $label) {
            $usado[$k] = trim((string) ($d['usado'][$k] ?? ''));
            $faixa[$k] = trim((string) ($d['faixa'][$k] ?? ''));
        }

        $fields = [
            'soldador_id'          => ($d['soldador_id'] ?? '') !== '' ? (int) $d['soldador_id'] : null,
            'eps_id'               => ($d['eps_id'] ?? '') !== '' ? (int) $d['eps_id'] : null,
            'processo_soldagem'    => trim((string) ($d['processo_soldagem'] ?? '')),
            'tipo'                 => trim((string) ($d['tipo'] ?? '')),
            'data_teste'           => trim((string) ($d['data_teste'] ?? '')) ?: null,
            'variaveis_usado'      => json_encode($usado, JSON_UNESCAPED_UNICODE),
            'variaveis_faixa'      => json_encode($faixa, JSON_UNESCAPED_UNICODE),
            'exame_visual_aceitavel' => trim((string) ($d['exame_visual_aceitavel'] ?? '')),
            'examinado_por'        => trim((string) ($d['examinado_por'] ?? '')),
            'examinado_data'       => trim((string) ($d['examinado_data'] ?? '')) ?: null,
            'macrografia'          => trim((string) ($d['macrografia'] ?? '')),
            'tamanho_perna'        => trim((string) ($d['tamanho_perna'] ?? '')),
            'concavidade_convexidade' => trim((string) ($d['concavidade_convexidade'] ?? '')),
            'ensaio_fratura'       => trim((string) ($d['ensaio_fratura'] ?? '')),
            'comprimento_defeitos' => trim((string) ($d['comprimento_defeitos'] ?? '')),
            'porcentagem_defeitos' => trim((string) ($d['porcentagem_defeitos'] ?? '')),
            'testes_mecanicos_por' => trim((string) ($d['testes_mecanicos_por'] ?? '')),
            'relatorio_numero'     => trim((string) ($d['relatorio_numero'] ?? '')),
            'radiografia_resultado' => trim((string) ($d['radiografia_resultado'] ?? '')),
            'radiografia_interpretada_por' => trim((string) ($d['radiografia_interpretada_por'] ?? '')),
            'teste_soldagem_por'   => trim((string) ($d['teste_soldagem_por'] ?? '')),
            'teste_soldagem_data'  => trim((string) ($d['teste_soldagem_data'] ?? '')) ?: null,
            'companhia'            => self::COMPANHIA,
            'aprovacao_por'        => trim((string) ($d['aprovacao_por'] ?? '')),
            'aprovacao_data'       => trim((string) ($d['aprovacao_data'] ?? '')) ?: null,
        ];
        if ($novo) {
            $fields['certificado_numero'] = $this->proximoCertificado();
            $fields['etapa']  = 'escola';
            $fields['status'] = 'em_andamento';
        }
        return $fields;
    }

    private function salvarDobramento(int $rqsId, array $d): void
    {
        $amostras = (array) ($d['dob_amostra'] ?? []);
        foreach ($amostras as $i => $am) {
            if (trim((string) $am) === '' && trim((string) ($d['dob_tipo'][$i] ?? '')) === '') continue;
            RqsDobramento::insert([
                'rqs_id'      => $rqsId,
                'secao'       => trim((string) ($d['dob_secao'][$i] ?? '')),
                'amostra'     => trim((string) $am),
                'tipo'        => trim((string) ($d['dob_tipo'][$i] ?? '')),
                'resultado'   => trim((string) ($d['dob_resultado'][$i] ?? '')),
                'tempo'       => trim((string) ($d['dob_tempo'][$i] ?? '')),
                'temperatura' => trim((string) ($d['dob_temp'][$i] ?? '')),
                'ordem'       => $i,
            ])->finish();
        }
    }

    public function delete(string $uuid): bool
    {
        Rqs::softDelete()->whereEquals('uuid', $uuid)->finish();
        return true;
    }

    /** Envia da Escola de Solda para a Engenharia de Processos. */
    public function enviarEngenharia(string $uuid, string $observacao = ''): void
    {
        $rqs = $this->find($uuid);
        if (!$rqs) return;
        Rqs::update(['etapa' => 'engenharia', 'updated_at' => date('Y-m-d H:i:s')])->whereEquals('uuid', $uuid)->finish();
        $this->log((int) $rqs->id, 'engenharia', $observacao ?: 'Enviado para aprovação da Engenharia.');
        EmailService::enviar(
            "RQS {$rqs->certificado_numero} aguardando aprovação da Engenharia",
            "<p>O RQS <strong>{$rqs->certificado_numero}</strong> foi enviado pela Escola de Solda e aguarda aprovação da Engenharia de Processos.</p>"
        );
    }

    /** Aprovação final da Engenharia (Fabrício Tarullo). */
    public function aprovar(string $uuid, string $observacao = ''): void
    {
        $rqs = $this->find($uuid);
        if (!$rqs) return;
        Rqs::update(['status' => 'aprovado', 'updated_at' => date('Y-m-d H:i:s')])->whereEquals('uuid', $uuid)->finish();
        $this->log((int) $rqs->id, 'engenharia', $observacao ?: 'RQS aprovado pela Engenharia.');
        EmailService::enviar(
            "RQS {$rqs->certificado_numero} aprovado",
            "<p>O RQS <strong>{$rqs->certificado_numero}</strong> foi <strong>aprovado</strong> pela Engenharia de Processos.</p>"
        );
    }

    private function log(int $rqsId, string $etapa, string $observacao): void
    {
        $u = user();
        RqsEtapaLog::create([
            'rqs_id'        => $rqsId,
            'etapa'         => $etapa,
            'observacao'    => $observacao,
            'usuario_login' => $u->matricula ?? null,
            'usuario_nome'  => $u->nome ?? null,
        ], false);
    }

    /** @return array<string,string> variáveis decodificadas */
    public function variaveis(?string $json): array
    {
        if (!$json) return [];
        $arr = json_decode($json, true);
        return is_array($arr) ? $arr : [];
    }
}
