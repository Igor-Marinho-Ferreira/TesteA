# 🔧 Checklist de Inspeção de Soldagem (SR-3297)

Digitalização do processo de **inspeção de soldagem** da GBMX (Greenbrier Maxion).
Substitui o checklist manual em papel por registro digital, integrando parametrização
do plano de soldagem, qualificação de soldadores e o checklist de verificação do
processo, com disponibilização dos dados para Power BI.

## 🎯 Visão Geral

O processo hoje é registrado em folhas físicas (checklist de inspeção, qualificação de
soldadores RQS, relatórios de laboratório). Este projeto digitaliza o fluxo em três
grandes blocos de parametrização + o formulário de checklist, mantendo rastreabilidade
e auditoria, e alimentando os relatórios gerenciais.

## ✨ Módulos (escopo SR-3297)

**Bloco 1 — Parametrização do Plano de Soldagem**
- Cadastro de Juntas
- Cadastro de Metal Base (Material)
- Cadastro de Gás
- Upload de Informações da EPS (import via Excel)
- Formulário de Registro do Plano de Soldagem
- Cadastro de Responsáveis pelo formulário do plano

**Bloco 2 — Parametrização de Qualificação de Soldadores**
- Cadastro de Qualificação, Posição (ângulo/topo), Treinamentos e Soldadores
- Relatório de Qualificação de Soldadores
- Validação de Certificação de Posições de Solda (integração com o MES)
- Cadastro Estação MES × Qualificação AWS
- Relatório de Ensaio Visual e Dimensional de Solda
- Formulário e Registro de Qualificação de Soldador
- Armazenar relatório gerado no WF de tarefas laboratoriais

**Bloco 3 — Checklist de Verificação do Processo de Soldagem**
- Cadastro de Modelo do Vagão
- Cadastro de Cliente
- Cadastro de Estágio de Soldagem
- **Formulário de Checklist de Soldagem**
- Alteração do WF do Centro de Treinamento de Soldagem

**+ Power BI** — disponibilização das informações via ETL.

> O detalhamento fino de campos e regras de cada tela está nos screenshots do escopo
> (documento SR-3297). As imagens são ilustrativas: o layout segue o padrão deste
> projeto (`templates/base` + `soldagem.css`).

## 🏗️ Arquitetura

Aplicação **PHP** com arquitetura **MVC** própria (o mesmo framework do projeto DDS,
reaproveitado). Convenções detalhadas em [`.claude/instructions.md`](.claude/instructions.md).

```
src/
├── app/
│   ├── controllers/      # Controladores da aplicação
│   ├── database/         # Database, Querio (query builder) e entities
│   ├── middlewares/      # Middlewares (ex.: IsLoggedMiddleware)
│   ├── requests/         # Form requests
│   └── views/            # Views e templates (League Plates)
├── core/                 # Núcleo (Router, Controller, Route, Bootstrap)
├── exceptions/           # Exceções (incl. mapeamento de erros PDO)
├── helpers/              # Funções auxiliares globais
├── routes/               # Definição de rotas
├── support/              # Suporte (View, Request, Validate, Mailer, Logger, etc.)
└── traits/               # Traits reutilizáveis
```

**Convenção de tabelas:** prefixo `sol_` (ex.: `sol_junta`, `sol_soldador`).

## 🛠️ Stack

- **Backend**: PHP (MVC próprio)
- **Banco**: MySQL (local via Docker `mysql-db`; intranet em produção)
- **Template Engine**: League Plates
- **Dependências**: Guzzle HTTP, SimplexLSXGen (Excel), PHPSecLib, PHPMailer, Symfony Console
- **Integrações**: MES (qualificação/estação), WF de tarefas laboratoriais, Power BI (ETL)

## 📝 Licença

MIT
