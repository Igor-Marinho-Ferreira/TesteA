# Alterações — 21/07/2026 (12ª rodada)

Três coisas: **descrição do item no Logix** nos perfis, **perfil INDUSTRIAL** no
cadastro de usuários, e o **carregamento da tabela** (o JS entrava depois da
tabela já pintada).

> ⚠️ **Sem migration.** Nada de banco novo. A busca do item apenas **lê** o
> Informix (Logix).

---

## 1. Perfis — código + descrição do item (busca no Logix/Informix)

Na tela **Cálculo de Peso › Perfis**:

- Além do **Código do item**, agora tem **Descrição do item**.
- Ao digitar o código e sair do campo (ou Enter), busca no **Logix/Informix**:
  `SELECT FIRST 1 den_item FROM item WHERE cod_item = ?` — `cod_item` é o código,
  `den_item` é a descrição. A descrição é preenchida sozinha (somente leitura).
- A lista de itens ganhou a coluna **Descrição do item**.

Detalhes técnicos:

- Serviço novo `src/app/services/LogixItemService.php` — usa a conexão `logix`
  (`Database::get('logix')`, Informix). **Defensivo**: sem código, item
  inexistente ou Informix fora do ar → devolve vazio; nunca quebra a tela.
- Endpoint AJAX `GET /dispositivos/cortes-item?codigo=...`
  (`CalculoPesoController::buscarItemView`, rota `dispositivos.cortes.item`),
  retorna JSON `{ encontrado, codigo, descricao }`.
- O JS mostra "buscando..." / "item não encontrado" / "Logix indisponível" ao
  lado do rótulo, conforme o caso.

> Se a tabela `item` do seu Informix tiver dono/owner ou nomes de coluna
> diferentes, é só ajustar a query em `LogixItemService::descricao()`.

**Arquivos:** `src/app/services/LogixItemService.php`,
`src/app/controllers/CalculoPesoController.php`, `src/routes/routes.php`,
`src/app/views/cortes/calculoPerfis.php`, `public/js/calculoPerfis.js`.

---

## 2. Perfil INDUSTRIAL no cadastro de usuários

O select de **PERFIL** (cadastro e edição de usuário) ganhou a opção
**Industrial**, ao lado de Comum / Líder de Projeto / Administrador / Projetista.

> Observação: hoje o **menu não filtra por perfil** — aquele controle
> (`authorization(...)`) está **comentado** em `menus/menu.php`, então todos veem
> todas as opções. O perfil já fica gravado no usuário; se quiser que o usuário
> **Industrial** enxergue **só** o que é da industrial, é um passo à parte
> (religar o gate do menu por perfil) — me avise que eu faço, com cuidado para
> não esconder telas de quem ainda está sem perfil.

**Arquivos:** `src/app/views/parametrizacao/usuario.php`,
`src/app/views/modals/editUsuario.php`.

---

## 3. Tabela "carregando" mas o JS entra depois

Causa: no `templates/base.php` os scripts das listas são carregados **no fim do
`<body>`**, ou seja, **depois** de a tabela já ter sido pintada — por isso dava
para ver a tabela crua antes de o DataTables montar.

Correção: o estado "carregando" (`dt-loading`) passou a vir **no HTML**
(server-side) nas quatro listas, e como o CSS está no `<head>`, a tabela já
nasce escondida — **sem depender de o JS rodar primeiro**. O JS só **remove** a
classe quando termina de montar.

Salvaguardas para nunca ficar em branco:

- **Failsafe CSS**: se a classe não for removida (ex.: script não carregou), a
  tabela se revela sozinha após ~6 s (`@keyframes` em `responsivo.css`).
- **`<noscript>`** no `base.php`: com JS desabilitado, revela na hora.

**Telas:** Acompanhar Solicitação de Projetos, Lista de Solicitações de Projetos,
Lista Industrial, Controle de Cortes.

**Arquivos:** `public/css/responsivo.css`, `src/app/views/templates/base.php`, e
as quatro views de lista (`solicitacao/listaSL`, `desenvolvimento/listaDesenvolvimento`,
`industrial/listaIndustrial`, `cortes/listaCortes`).

---

## Como testar

1. **Perfis:** digite um código de item que exista no Logix → a descrição
   preenche; adicione à lista e veja a coluna Descrição. Teste um código
   inexistente (deve avisar "item não encontrado") — a tela não quebra.
2. **Usuário:** cadastre/edite um usuário e escolha o perfil **Industrial**;
   confirme que salvou.
3. **Carga das listas:** abra as quatro telas — a tabela deve nascer já montada
   (sem “pulo”/reorganização depois).
