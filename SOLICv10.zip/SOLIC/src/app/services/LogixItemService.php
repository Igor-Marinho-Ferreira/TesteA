<?php

namespace src\app\services;

use PDO;
use src\app\database\Database;

/**
 * Consulta a descrição de um item no Logix (Informix), tabela `item`:
 *   cod_item -> código do item   |   den_item -> descrição.
 *
 * É de leitura e defensivo: qualquer falha (sem conexão, item inexistente,
 * Informix fora do ar) devolve null — nunca derruba a tela dos perfis, que
 * apenas deixa a descrição em branco.
 */
class LogixItemService
{
    public static function descricao(string $codItem): ?string
    {
        $codItem = trim($codItem);

        if ($codItem === '') {
            return null;
        }

        // Se o Informix nem está configurado no .env, evita o require quebrar.
        if (empty($_ENV['DB_FILE_INFORMIX'])) {
            return null;
        }

        try {
            $pdo = Database::get('logix');

            if (!$pdo) {
                return null;
            }

            // Informix: FIRST 1 limita o retorno a uma linha.
            $stmt = $pdo->prepare('SELECT FIRST 1 den_item FROM item WHERE cod_item = :cod');
            $stmt->execute([':cod' => $codItem]);

            $den = $stmt->fetchColumn();

            if ($den === false || $den === null) {
                return null;
            }

            $den = trim((string) $den);

            return $den !== '' ? $den : null;
        } catch (\Throwable $e) {
            error_log('Logix item: falha ao buscar "' . $codItem . '" — ' . $e->getMessage());
            return null;
        }
    }
}
