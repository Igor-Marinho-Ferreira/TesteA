<?php
$this->layout("templates/baseModal", [
  "headTitle" => "Editar usuário",
  "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
  "js" => [
    path()->js("usuario.js"),
    path()->js("controle.js"),
  ],
]);
?>
<?php $this->start('modalContent') ?>


    <form method="POST" action="<?= route('parametrizacao.usuario.update') ?>" id="formCadastroUsuario">
        <input type="hidden" class="form-control form-control-sm" id="inputId" name="id"
            value="<?= $usuario->id ?>" readonly>
        <div class="row mb-3">
            <div class="col-md-3">
                <label for="matricula" class="form-label">Matrícula <span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control form-control-sm" id="matricula" name="matricula"
                    value="<?= $usuario->matricula ?>" readonly>
            </div>
            <div class="col-md-4">
                <label for="inputNome" class="form-label">Nome <span class="text-danger">*</span></label>
                <input type="text" class="form-control form-control-sm" id="inputNome" name="nome"
                    value="<?= $usuario->nome ?>" readOnly>
            </div>
              <div class="col-md-4">
                <label for="inputEmail" class="form-label">Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control form-control-sm" id="inputEmail" name="email"
                    value="<?= $usuario->email ?>" readOnly>
            </div>
        </div>




        <div class="row mb-3">
          


            <div class="col-md-4">
                <label for="inputArea" class="form-label">Área</label>
                <input type="text" class="form-control form-control-sm" id="inputArea" name="area"
                    value="<?= $usuario->area ?>" readOnly>
            </div>

            <div class="col-md-4">
                <label for="selectPerfil" class="form-label">Perfil <span class="text-danger">*</span></label>
                <select class="form-select form-select-sm" id="selectPerfil" name="role" required>
                    <option value="">Selecione...</option>
                    <option value="COMUM" <?= isSelect($usuario->role, 'COMUM') ?>>Comum</option>
                    <option value="LIDER DE PROJETO" <?= isSelect($usuario->role, 'LIDER DE PROJETO') ?>>Líder
                        de Projeto</option>
                    <option value="ADMINISTRADOR" <?= isSelect($usuario->role, 'ADMINISTRADOR') ?>>Administrador</option>
                    <option value="PROJETISTA" <?= isSelect($usuario->role, 'PROJETISTA') ?>>Projetista</option>
                    <option value="INDUSTRIAL" <?= isSelect($usuario->role, 'INDUSTRIAL') ?>>Industrial</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="selectStatus" class="form-label">Status <span class="text-danger">*</span></label>
                <select class="form-select form-select-sm" id="selectStatus" name="status" required>
                    <option selected value="ATIVO">Ativo</option>
                    <option value="INATIVO">Inativo</option>
                </select>
            </div>
        </div>



        <div class="buttonsDiv d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-company" onclick="loading('show')">Registrar</button>
            <a class="btn btn-secondary" id="cancelForm" onclick="closeModal()">Cancelar</a>
        </div>
    </form>



</div>
<?php $this->stop() ?>


