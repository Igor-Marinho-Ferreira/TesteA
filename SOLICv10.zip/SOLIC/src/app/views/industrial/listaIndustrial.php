<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.menu"),
    "webTitle"  => "Dispositivos - Industrial",
    "cardTitle" => "LISTA INDUSTRIAL - CORTE E EXECUÇÃO",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
    "js" => [
        path()->js("listaIndustrial.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$formatarData = function ($data) {
    if (empty($data) || $data === '0000-00-00' || $data === '0000-00-00 00:00:00') {
        return '--';
    }
    try {
        return (new DateTime($data))->format('d/m/Y');
    } catch (Throwable $e) {
        return '--';
    }
};

// Valor para <input type="date"> (YYYY-MM-DD) ou vazio
$dataInput = function ($data) {
    if (empty($data) || $data === '0000-00-00' || $data === '0000-00-00 00:00:00') {
        return '';
    }
    try {
        return (new DateTime($data))->format('Y-m-d');
    } catch (Throwable $e) {
        return '';
    }
};

function getStatusClassInd($status)
{
    return match (strtoupper(trim((string) $status))) {
        'FINALIZADO', 'OK'                  => 'status-ok',
        'ANDAMENTO', 'EM ANDAMENTO'         => 'status-alerta',
        'PENDENTE', 'PARADO'                => 'status-espera',
        'AGUARDANDO', 'BACKLOG'             => 'status-backlog',
        'CANCELADO', 'PAUSADO', 'TERCEIRIZADO' => 'status-pausado',
        'REVISAR'                           => 'status-revisao',
        default                             => '',
    };
}
?>

<h5 style="text-align:center">TOTAL DE SOLICITAÇÕES: <?= (int) $qtdSL ?></h5>

<div class="container-fluid mb-4">
    <div class="d-flex flex-wrap gap-2">
        <a href="?status=PENDENTES" class="btn btn-sm status-espera flex-fill">EM ABERTO</a>
        <a href="?status=ANDAMENTO" class="btn btn-sm btn-info flex-fill">ANDAMENTO</a>
        <a href="?status=AGUARDANDO" class="btn btn-sm btn-secondary flex-fill">AGUARDANDO</a>
        <a href="?status=FINALIZADO" class="btn btn-sm btn-secondary flex-fill">FINALIZADO</a>
        <a href="?status=todos" class="btn btn-sm btn-secondary flex-fill">TODAS</a>
        <a href="?" class="btn btn-sm btn-light border flex-fill">LIMPAR FILTROS</a>
    </div>

    <div class="row pt-3 g-2">
        <div class="col-md-6">
            <label for="solicitante" class="form-label fs-7 fw-bold d-block mb-0">Solicitante:</label>
            <select class="form-select form-select-sm" id="solicitante" name="solicitante">
                <option value="">Selecione...</option>
                <?php foreach ($solicitantes as $solicitante) : ?>
                    <option value="<?= $h($solicitante->nome) ?>" <?= isSelect($solicitante->nome, $_GET['solicitante'] ?? '') ?>>
                        <?= $h($solicitante->nome) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-6">
            <label for="equipe" class="form-label fs-7 fw-bold d-block mb-0">Equipe:</label>
            <select class="form-select form-select-sm" id="equipe" name="equipe">
                <option value="">Selecione...</option>
                <?php foreach ($equipes as $eq) : ?>
                    <option value="<?= $h($eq) ?>" <?= isSelect($eq, $_GET['equipe'] ?? '') ?>>
                        <?= $h($eq) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
</div>

<?php /* dt-loading-shell evita o salto de layout na carga (ver responsivo.css) */ ?>
<div class="table-responsive dt-loading-shell dt-loading">
    <table id="listIndustrial">
        <thead>
            <tr>
                <th>SL</th>
                <th>DESCRIÇÃO</th>
                <th>SOLICITANTE</th>
                <th>COD Z</th>
                <th>N° SFP / CC</th>
                <th>VAGÃO</th>
                <th>STATUS</th>
                <th># PASTA</th>
                <th>DATA ENTREGA</th>
                <th>NATUREZA</th>
                <th>DESCRIÇÃO DO SERVIÇO</th>
                <th>CORTE</th>
                <th>EXECUÇÃO</th>
                <th>EQUIPE</th>
                <th>SETOR</th>
            </tr>
        </thead>

        <tbody class="tbody">
            <?php foreach ($solicitacoes as $solicitacao) : ?>
                <tr>
                    <td data-label="SL">
                        <strong>
                            <a href="<?= route('dispositivos.industrial.info', ['ref' => $solicitacao->ref]) ?>">
                                SL<?= $h($solicitacao->ref) ?>
                            </a>
                        </strong>
                    </td>
                    <td data-label="Descrição"><?= $h($solicitacao->descricao) ?></td>
                    <td data-label="Solicitante"><?= $h($solicitacao->solicitante) ?></td>
                    <td data-label="Cód Z"><?= $h($solicitacao->cod_z_formatado) ?></td>
                    <td data-label="N° SFP / CC"><?= $h($solicitacao->conta) ?></td>
                    <td data-label="Vagão"><?= $h($solicitacao->vagao) ?></td>

                    <td data-label="Status" class="<?= getStatusClassInd($solicitacao->status_geral) ?>">
                        <?= $h($solicitacao->status_geral) ?>
                    </td>

                    <?php /* 9ª rodada — campos do industrial editáveis inline (salvam ao sair do campo) */ ?>
                    <td data-label="# Pasta">
                        <input type="text" class="form-control form-control-sm campo-ind"
                               data-ref="<?= (int) $solicitacao->ref ?>" data-campo="n_pasta"
                               value="<?= $h($solicitacao->n_pasta ?? '') ?>" maxlength="60">
                    </td>
                    <td data-label="Data Entrega">
                        <input type="date" class="form-control form-control-sm campo-ind"
                               data-ref="<?= (int) $solicitacao->ref ?>" data-campo="data_entrega"
                               value="<?= $h($dataInput($solicitacao->data_entrega ?? null)) ?>">
                    </td>
                    <td data-label="Natureza">
                        <input type="text" class="form-control form-control-sm campo-ind"
                               data-ref="<?= (int) $solicitacao->ref ?>" data-campo="natureza"
                               value="<?= $h($solicitacao->natureza ?? '') ?>" maxlength="120">
                    </td>
                    <td data-label="Descrição do Serviço">
                        <input type="text" class="form-control form-control-sm campo-ind"
                               data-ref="<?= (int) $solicitacao->ref ?>" data-campo="descricaoservico"
                               value="<?= $h($solicitacao->descricaoservico ?? '') ?>" maxlength="255">
                    </td>

                    <td data-label="Corte" class="<?= getStatusClassInd($solicitacao->corte_status) ?>">
                        <?= $h($solicitacao->corte_status) ?>
                    </td>
                    <td data-label="Execução" class="<?= getStatusClassInd($solicitacao->exec_status) ?>">
                        <?= $h($solicitacao->exec_status) ?>
                    </td>

                    <td data-label="Equipe">
                        <input type="text" class="form-control form-control-sm campo-ind"
                               data-ref="<?= (int) $solicitacao->ref ?>" data-campo="equipeei"
                               value="<?= $h($solicitacao->equipeei ?? '') ?>" maxlength="60">
                    </td>
                    <td data-label="Setor">
                        <input type="text" class="form-control form-control-sm campo-ind"
                               data-ref="<?= (int) $solicitacao->ref ?>" data-campo="setor_pendencia"
                               value="<?= $h($solicitacao->setor_pendencia ?? '') ?>" maxlength="60">
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/dt'); ?>
