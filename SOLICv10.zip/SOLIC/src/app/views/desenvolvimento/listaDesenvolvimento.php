<?php
$this->layout("templates/base", [
    "backTo" => "http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/",
    "webTitle" => "Dispositivos - Solicitação de projetos",
    "cardTitle" => "LISTA DE SOLICITAÇÕES DE PROJETOS",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
    "js" => [
        path()->js("listaProjetos.js"),
    ],
]);



function getStatusClass($status)
{
    $status = trim($status);
    return match ($status) {
        'FINALIZADO', 'OK' => 'status-ok',
        'EM ANDAMENTO', 'ANDAMENTO', '[VALIDAÇÃO]', 'MODELO'       => 'status-alerta',
        'PENDENTE', 'PARADO', 'NÂO OK'          => 'status-espera',
        'BACKLOG', 'EM ANÁLISE', 'AGUARDANDO'          => 'status-backlog',
        'CANCELADO', 'PAUSADO', 'TERCEIRIZADO'          => 'status-pausado',
        'REVISAR' => 'status-revisao',
        default                         => '',
    };
}
?>

<h5 style="text-align:center">TOTAL DE SOLICITAÇÕES: <?= $qtdSL ?></h5>

<div class="container-fluid mb-4">
    <div class="d-flex flex-wrap gap-2">
        <a href="?status=projetos" class="btn btn-sm status-espera flex-fill">PROJETOS</a>
        <a href="?status=novos" class="btn btn-sm btn-info flex-fill">NOVOS</a>
        <a href="?status=todos" class="btn btn-sm btn-secondary flex-fill">TODAS SLs</a>
        <a href="?status=pendente&coluna=detalhamento_status" class="btn btn-sm btn-secondary flex-fill">DETALHAMENTO</a>
        <a href="?status=pendente&coluna=liberacao_status" class="btn btn-sm btn-secondary flex-fill">LIBERAÇÃO</a>
        <a href="?" class="btn btn-sm btn-light border flex-fill">LIMPAR FILTROS</a>
    </div>

    <div class="row pt-3 g-2">
        <div class="col-md-6">
            <label for="solicitante" class="form-label fs-7 fw-bold d-block mb-0">Solicitante:</label>
            <div class="d-flex gap-2">
                <select class="form-select form-select-sm" id="solicitante" name="solicitante" required>
                    <option value="" <?= empty($_GET['solicitante']) ? 'selected' : '' ?>>Selecione...</option>
                    <?php foreach ($solicitantes as $solicitante) : ?>
                        <option value="<?= $solicitante->nome ?>" <?= isSelect($solicitante->nome, $_GET['solicitante'] ?? '') ?>>
                            <?= $solicitante->nome ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="col-md-6">
            <label for="projetista" class="form-label fs-7 fw-bold d-block mb-0">Projetista:</label>
            <div class="d-flex gap-2">
                <select class="form-select form-select-sm" id="projetista" name="projetista" required>
                    <option value="" <?= empty($projetista->nome) ? 'selected' : '' ?>>Selecione...</option>
                    <?php foreach ($projetistas as $projetista) : ?>
                        <option value="<?= $projetista->nome ?>" <?= isSelect($projetista->nome, $_GET['projetista'] ?? '') ?>>
                            <?= $projetista->nome ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>
</div>

<?php /* dt-loading-shell reserva a altura e evita o salto de layout na carga (ver responsivo.css) */ ?>
<div class="table-responsive dt-loading-shell dt-loading">
    <table id="list">
        <thead>
            <tr>
                <th>N° SL</th>
                <th>DESCRIÇÃO</th>
                <th>SOLICITANTE</th>
                <th>CÓD Z</th>
                <th>LOCAL</th>
                <th>VAGÃO | LOTE</th>
                <th>CLASSE</th>
                <th>PROJETISTA</th>
                <th>CONCEITO</th>
                <th>PROJETISTA</th>
                <th>DETALHAMENTO</th>
                <th>LIBERAÇÃO</th>
                <th>AQUISIÇÃO</th>
                <th>CORTE</th>
                <th>EXECUÇÃO</th>
                <th>TRYOUT</th>
            </tr>
        </thead>
        <tbody class="tbody">
            <?php foreach ($solicitacoes as $solicitacao) : ?>
                <tr>
                    <td data-label="N° SL"><strong><a href="<?= route("dispositivos.desenvolvimento.info", ['ref' => $solicitacao->ref]) ?>">SL<?= $solicitacao->ref ?></a></strong></td>
                    <td data-label="Descrição"><?= $solicitacao->descricao ?></td>
                    <td data-label="Solicitante"><?= $solicitacao->solicitante ?></td>

                    <td data-label="Cód Z"><?= $solicitacao->cod_z_formatado ?></td>

                    <td data-label="Local"><?= $solicitacao->aplicacao ?></td>
                    <td data-label="Vagão | Lote"><?= $solicitacao->vagao ?> | <?= $solicitacao->lote ?></td>
                    <td data-label="Classe"><?= $solicitacao->classe ?></td>
                    <td data-label="Projetista"><?= $solicitacao->conceito_proj ?></td>

                    <td data-label="Conceito" class="<?= getStatusClass($solicitacao->conceito_status) ?>"><?= $solicitacao->conceito_status ?></td>
                    <td data-label="Projetista"><?= $solicitacao->detalhamento_proj ?></td>
                    <td data-label="Detalhamento" class="<?= getStatusClass($solicitacao->detalhamento_status) ?>"><?= $solicitacao->detalhamento_status ?></td>
                    <td data-label="Liberação" class="<?= getStatusClass($solicitacao->liberacao_status) ?>"><?= $solicitacao->liberacao_status ?></td>
                    <td data-label="Aquisição" class="<?= getStatusClass($solicitacao->aquisicao_status) ?>"><?= $solicitacao->aquisicao_status ?></td>
                    <td data-label="Corte" class="<?= getStatusClass($solicitacao->corte_status) ?>"><?= $solicitacao->corte_status ?></td>
                    <td data-label="Execução" class="<?= getStatusClass($solicitacao->exec_status) ?>"><?= $solicitacao->exec_status ?></td>
                    <td data-label="Tryout" class="<?= getStatusClass($solicitacao->tryout_status) ?>"><?= $solicitacao->tryout_status ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="row g-2 mt-3 justify-content-end">
    <div class="col-auto"><a href="?status=pendente&coluna=aquisicao_status" class="btn btn-sm btn-secondary px-4">AQUISIÇÃO</a></div>
    <div class="col-auto"><a href="?status=EM ANÁLISE&coluna=conceito_status" class="btn btn-sm btn-secondary px-4">EM ANÁLISE</a></div>
    <div class="col-auto"><a href="?status=pendente&coluna=corte_status" class="btn btn-sm btn-secondary px-4">CORTE</a></div>
    <div class="col-auto"><a href="?status=pendente&coluna=exec_status" class="btn btn-sm btn-secondary px-4">EXECUÇÃO</a></div>
    <div class="col-auto"><a href="?status=pendente&coluna=tryout_status" class="btn btn-sm btn-secondary px-4">TRYOUT</a></div>
</div>


<?= $this->insert('templates/dt'); ?>