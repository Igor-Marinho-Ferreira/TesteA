<?php $t = time(); ?>
<!doctype html>
<html lang="pt-BR">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $webTitle ?? 'Web Title Default' ?></title>
    <link rel="stylesheet" href="<?= path()->css("/bs5.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/app.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/table.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/notification.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/sidebar.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/table-responsive.css?t={$t}") ?>">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/regular/style.css" />
    <?php /* responsivo.css carrega por ultimo para sobrescrever alturas/larguras fixas */ ?>
    <link rel="stylesheet" href="<?= path()->css("/responsivo.css?t={$t}") ?>">
    <?php /* Sem JS o esqueleto nunca é removido: revela a tabela para não ficar em branco */ ?>
    <noscript>
        <style>
            .dt-loading-shell.dt-loading table,
            .dt-loading-shell.dt-loading .dt-container {
                visibility: visible !important;
            }
        </style>
    </noscript>
    <?= $this->insert('templates/styles', ['styles' => $styles ?? []]) ?>

    <script src="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@10.2.9/dist/autoComplete.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@10.2.7/dist/css/autoComplete.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>


<body class="<?= $_ENV['APP_COMPANY'] ?>">

    <div class="container mt-4">
        <ul class="notificationsToasts"></ul>
        <div class="card mb-4">
            <div class="card-header">
                <div class="name-and-logo">
                    <span class="d-flex align-items-center">
                        <?php if (isset($backTo)) { ?><a href="<?= $backTo ?>" class="d-flex text-decoration-none text-dark me-3"><i class="ph ph-arrow-left"></i></a><?php } ?><?= $cardTitle ?? null ?></span>
                    <img class="logoEmpresa" src="<?= path()->images("/GBM_Logo_CMYK.jpg"); ?>" alt="Logo Empresa">
                </div>
            </div>
            <div class="card-body">
                <?= $this->section("content"); ?>
            </div>
        </div>

        <dialog id="myAppModal" class="myAppModal"></dialog>
        <?= $this->section("series"); ?>
    </div>


    <?= $this->insert('templates/loading'); ?>

    <script src="<?= path()->js("/bs5.js?t={$t}") ?>"></script>
    <script src="<?= path()->js("/init.js?t={$t}"); ?>"></script>
    <script src="<?= path()->js("/notification.js?t={$t}"); ?>"></script>
    <?= $this->insert('templates/js', ['js' => $js ?? []]) ?>
    <?php enableNotifications(); ?>
    <?php forgetSessions(['old', 'zarkify', 'isWrong']); ?>
</body>

</html>