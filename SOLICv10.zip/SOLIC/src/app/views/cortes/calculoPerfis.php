<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.cortes.calculoPeso"),
    "webTitle"  => "Dispositivos - Peso de Perfis",
    "cardTitle" => "CÁLCULO DE PESO - PERFIS",
    "styles"    => [
        path()->css("cortes.css")
    ],
    "js" => [
        path()->js("calculoPerfis.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$perfis = $perfis ?? [];
$tipos  = $tipos ?? [];
$pronta = !empty($tabelaPronta);

// Perfis para o JS: id => {tipo, descricao, peso_por_metro}
$perfilMap = [];
foreach ($perfis as $p) {
    $perfilMap[(string) $p->id] = [
        'tipo'      => $p->tipo,
        'descricao' => $p->descricao,
        'kgm'       => (float) $p->peso_por_metro,
    ];
}
?>

<?php if (!$pronta) : ?>
    <div class="alert alert-warning fs-7" role="alert">
        <i class="bi bi-database-exclamation me-1"></i>
        Cadastro de perfis indisponível: rode a migration
        <code>database/migrations/2026-07-21f-calculo-peso.sql</code>.
    </div>
<?php elseif (empty($perfis)) : ?>
    <div class="alert alert-info fs-7" role="alert">
        <i class="bi bi-info-circle me-1"></i>
        Nenhum perfil cadastrado. Cadastre os perfis (com o peso por metro) em
        <a href="<?= route('parametrizacao.perfis') ?>">Parametrização &rsaquo; Perfis</a>.
    </div>
<?php endif; ?>

<div class="box-corte" data-perfis='<?= $h(json_encode($perfilMap, JSON_UNESCAPED_UNICODE)) ?>' id="painelPerfil">
    <div class="row g-3 align-items-end">
        <div class="col-md-3">
            <label class="rotulo-corte d-block mb-1">Código do item</label>
            <input type="text" class="form-control form-control-sm" id="perfilCodigo"
                   placeholder="Ex.: 1234567" maxlength="60" autocomplete="off">
        </div>

        <div class="col-md-9">
            <label class="rotulo-corte d-block mb-1">
                Descrição do item
                <small class="text-muted fw-normal" id="perfilDescStatus"></small>
            </label>
            <input type="text" class="form-control form-control-sm" id="perfilDescricao"
                   placeholder="Preenchida automaticamente pelo código (Logix)" readonly>
        </div>
    </div>

    <div class="row g-3 align-items-end mt-1">
        <div class="col-md-5">
            <label class="rotulo-corte d-block mb-1">Perfil</label>
            <select class="form-select form-select-sm" id="perfilSelect" <?= empty($perfis) ? 'disabled' : '' ?>>
                <option value="">Selecione...</option>
                <?php foreach ($perfis as $p) : ?>
                    <option value="<?= $h($p->id) ?>">
                        <?= $h($tipos[$p->tipo] ?? $p->tipo) ?><?= $p->descricao ? ' — ' . $h($p->descricao) : '' ?>
                        (<?= $h(number_format((float) $p->peso_por_metro, 3, ',', '.')) ?> kg/m)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-6 col-md-2">
            <label class="rotulo-corte d-block mb-1">Comprimento (mm)</label>
            <input type="number" class="form-control form-control-sm" id="perfilComp" value="1000" min="0">
        </div>

        <div class="col-6 col-md-2">
            <label class="rotulo-corte d-block mb-1">Qtde</label>
            <input type="number" class="form-control form-control-sm" id="perfilQtde" value="1" min="1">
        </div>

        <div class="col-md-3 d-grid gap-1">
            <button type="button" class="btn btn-outline-primary btn-sm" id="btnCalcularPerfil">Calcular</button>
            <button type="button" class="btn btn-primary btn-sm" id="btnAddPerfil" <?= empty($perfis) ? 'disabled' : '' ?>>
                <i class="bi bi-plus-lg me-1"></i>Adicionar
            </button>
        </div>
    </div>

    <hr>

    <div class="row g-2 fs-8">
        <div class="col-md-3">Peso por metro (kg/m): <strong id="perfilKgm">—</strong></div>
        <div class="col-md-3">Comprimento total (m): <strong id="perfilCompTotal">—</strong></div>
        <div class="col-md-3">Peso unitário (kg): <strong id="perfilPesoUnit">—</strong></div>
        <div class="col-md-3">Peso total (kg): <strong class="text-danger" id="perfilPesoTotal">—</strong></div>
    </div>
</div>

<?php /* ------------------- LISTA DE PERFIS (acumulador) ------------------- */ ?>
<div class="grupo-espessura mt-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center py-2 px-2 cabecalho-espessura">
        <span class="fw-bold">Itens adicionados</span>
        <span class="fs-8">
            Peso total: <strong class="text-danger"><span id="perfilTotalGeral">0,000</span> kg</strong>
        </span>
    </div>

    <div class="table-responsive">
        <table class="table table-sm tabela-planos align-middle mb-0" id="tabelaPerfis">
            <thead>
                <tr>
                    <th>Código do item</th>
                    <th>Descrição do item</th>
                    <th>Perfil</th>
                    <th class="text-end">Comp (mm)</th>
                    <th class="text-end">Qtde</th>
                    <th class="text-end">kg/m</th>
                    <th class="text-end">Peso unit (kg)</th>
                    <th class="text-end">Peso total (kg)</th>
                    <th class="text-center">—</th>
                </tr>
            </thead>
            <tbody id="corpoPerfis">
                <tr id="perfilVazio">
                    <td colspan="9" class="text-muted text-center py-3">
                        Nenhum item adicionado. Preencha acima e clique em <strong>Adicionar</strong>.
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <a href="<?= route('parametrizacao.perfis') ?>" class="btn btn-sm btn-outline-secondary">
        <i class="bi bi-gear me-1"></i> Cadastrar / editar perfis
    </a>
</div>
