<?php
$this->layout("templates/base", [
    "backTo" => "http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/",
    "webTitle" => "Dispositivos - Solicitação de projetos",
    "cardTitle" => "SISTEMA DE CONTROLE DE PROJETOS DE DISPOSITIVOS",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
    "js" => [
        path()->js("acompanhamento.js"),
    ],
]);

$nomeAtual = $_GET['nome'] ?? '';
$queryNome = $nomeAtual ? '&nome=' . urlencode($nomeAtual) : '';

function definirCor($status)
{
    $status = strtolower(trim($status));

    return match ($status) {
        'pen'     => '#CD6600',
        'par'     => '#CD6600',
        'ok'      => '#6E8B3D',
        'fin'      => '#008B45',
        'val'     => '#FFD700',
        'and'     => '#EEDD82',
        'bak' => '#008B8B',
        'can' => '#8B8B83',
        'psd' => '#8B8B83',
        'mod' => '#CD8500',
        'rev' => '#7d0000',
        default   => 'transparent',
    };
}
?>



<div class="row">
    <div class="col-md-7">
        <a class="btn btn-primary" href="<?= route('dispositivos.solicitacao') ?>">NOVA SL <i class="ph ph-list-plus"></i></a>
        <a href="?status=todos<?= $queryNome ?>" class="btn btn-secondary">TODAS SLs</a>
        <a href="?status=pendente<?= $queryNome ?>" class="btn btn-danger">PENDENTE</a>
        <a href="?status=validacao<?= $queryNome ?>" class="btn btn-warning">VALIDAÇÃO</a>
        <a href="?" class="btn btn-light">LIMPAR FILTROS</a>
    </div>
    <div class="col-md-7 pt-3">
        <label for="solicitante" class="form-label fs-7 fw-bold d-block mb-0">SOLICITANTE:</label>
        <div class="d-flex gap-2">
            <select class="form-select form-select-sm" id="solicitante" name="solicitante" required>
                <option value="" <?= empty($_GET['solicitante']) ? 'selected' : '' ?>>Selecione...</option>
                <?php foreach ($solicitantes as $solicitante) : ?>
                    <option value="<?= $solicitante->nome ?>" <?= isSelect($solicitante->nome, $_GET['solicitante'] ?? '') ?>>
                        <?= $solicitante->nome ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
</div>


<h3 class="pt-4">PROJETOS SOLICITADOS</h3>
<?php /* dt-loading-shell: esconde a tabela até o DataTables montar (evita o salto de layout na carga) */ ?>
<div class="table-responsive dt-loading-shell dt-loading">
<table id="list">
    <thead>
        <tr>
            <th>N° SL</th>
            <th>DESCRIÇÃO</th>
            <th>CÓD. PROJETO</th>
            <th>ABERTURA</th>
            <th>SOLICITANTE</th>
            <th>APLICAÇÃO</th>
            <th>VAGÃO</th>
            <th>LOTE</th>
            <th>3D</th>
            <th>DET</th>
            <th>LIB</th>
            <th>AQ</th>
            <th>PROC</th>
            <th>EXEC</th>
            <th>TRY</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($solicitacoes as $solicitacao) : ?>
            <tr>
                <td><a href="<?= route('dispositivos.acompanhamento.sl', ['ref' => $solicitacao->ref]) ?>">
                        SL<?= $solicitacao->ref ?>
                    </a></td>
                <td><?= $solicitacao->descricao ?></td>
                <td><?= $solicitacao->cod_z_formatado ?></td>
                <td data-order="<?= $solicitacao->data_solicitacao ?>">
                    <?= date('d/m/Y', strtotime($solicitacao->data_solicitacao)) ?>
                </td>
                <td><?= $solicitacao->solicitante ?></td>
                <td><?= $solicitacao->aplicacao ?></td>
                <td><?= $solicitacao->vagao ?></td>
                <td><?= $solicitacao->lote ?></td>
                <td style="background-color: <?= definirCor($solicitacao->conceito_status) ?>; color: white;">
                    <?= $solicitacao->conceito_status ?>
                </td>

                <td style="background-color: <?= definirCor($solicitacao->detalhamento_status) ?>; color: white;">
                    <?= $solicitacao->detalhamento_status ?>
                </td>

                <td style="background-color: <?= definirCor($solicitacao->liberacao_status) ?>; color: white;">
                    <?= $solicitacao->liberacao_status ?>
                </td>

                <td style="background-color: <?= definirCor($solicitacao->aquisicao_status) ?>; color: white;">
                    <?= $solicitacao->aquisicao_status ?>
                </td>

                <td style="background-color: <?= definirCor($solicitacao->corte_status) ?>; color: white;">
                    <?= $solicitacao->corte_status ?>
                </td>

                <td style="background-color: <?= definirCor($solicitacao->exec_status) ?>; color: white;">
                    <?= $solicitacao->exec_status ?>
                </td>

                <td style="background-color: <?= definirCor($solicitacao->tryout_status) ?>; color: white;">
                    <?= $solicitacao->tryout_status ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>


<?= $this->insert('templates/dt'); ?>