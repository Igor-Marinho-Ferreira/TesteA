<?php

namespace src\routes;

use src\app\controllers\AcompanhamentoController;
use src\app\controllers\UsuarioController;
use src\app\controllers\VagaoController;
use src\app\controllers\EstagioController;
use src\app\controllers\CalculoPesoController;
use src\app\controllers\ContaController;
use src\app\controllers\ControleCorteController;
use src\app\controllers\EspessuraController;
use src\app\controllers\ImportController;
use src\app\controllers\PerfilController;
use src\app\controllers\IndustrialController;
use src\app\controllers\ItensConsolidadoController;
use src\app\controllers\MenuController;
use src\app\controllers\SolicitacaoController;
use src\app\controllers\DesenvolvimentoController;
use src\core\Route;

//Quando tiver {id} -> whereInt(['id'])



//ROTA VBA, PEGANDO OS DADOS ATUALIZADOS
Route::get('/dispositivos/csvAtualizado/fila', SolicitacaoController::class,
    'trataCsv'
)
->name('dispositivos.atualizaCSV.fila');

//ROTA VBA, PEGANDO OS DADOS ATUALIZADOS
Route::get('/dispositivos/csvAtualizado/projetos', SolicitacaoController::class,
    'trataProjetosCSV'
)
->name('dispositivos.atualizaCSV.projeto');



// ROTA PARA IMPORTAR O EXCEL DO CAMINHO DEFINIDO NO .ENV PARA O MYSQL
Route::get(
    '/dispositivos/importar-excel/access',
    ImportController::class,
    'importarExcel'
)
    ->name('dispositivos.importar.excel');



//MENU
Route::get('/dispositivos', MenuController::class, 'menuView')
    ->name('dispositivos.menu');

Route::get('/dispositivos/parametrizacoes', MenuController::class, 'menuParametrizacaoView')
    ->name('dispositivos.menu.parametrizacao');


//SOLICITAÇÃO
Route::get('/dispositivos/solicitacoes', SolicitacaoController::class, 'solicitacaoView')
    ->name('dispositivos.solicitacao');

Route::get('/dispositivos/solicitacao/validacao/{ref}', SolicitacaoController::class, 'modalValidacao')
    ->name('dispositivos.solicitacao.validacao')
    ->whereInt(['ref']);


Route::get('/dispositivos/solicitacao/requisitos/{ref}', SolicitacaoController::class, 'modalRequisitos')
    ->name('dispositivos.solicitacao.requisitos')
    ->whereInt(['ref']);


Route::get('/dispositivos/solicitacao/anexos/{ref}', SolicitacaoController::class, 'modalAnexos')
    ->name('dispositivos.solicitacao.requisitos')
    ->whereInt(['ref']);

Route::get('dispositivos/solicitacao/cancelarSl/{ref}', SolicitacaoController::class, 'modalCancelarSl')
    ->name('dispositivos.solicitacao.cancelarSl')
    ->whereInt(['ref']);

Route::get('/dispositivos/solicitacoes/getProjectInfos', SolicitacaoController::class, 'getProjectInfos')
    ->name('dispositivos.solicitacao.getProjectInfos');

Route::get('dispositivos/solicitacao/getSolicRole', SolicitacaoController::class, 'getRole')
    ->name('dispositivos.solicitacao.getRole');


Route::get('dispositivos/solicitacao/modalConfirmZ', SolicitacaoController::class, 'modalConfirmZ')
    ->name('dispositivos.solicitacao.modalConfirmZ');

Route::post('/dispositivos/solicitacao/store', SolicitacaoController::class, 'storeSolicitacao')
    ->name('dispositivos.solicitacao.store');

//SALVAR VINDO DO VBA/ACCESS — gera o Ref no MySQL (cartório) com GET_LOCK
Route::post('/dispositivos/solicitacao/salvarVba', SolicitacaoController::class, 'salvarVba')
    ->name('dispositivos.solicitacao.salvarVba');

//UPLOAD do PDF da SL vindo do Access (corpo binário cru) -> storage + tabela anexos
Route::post('/dispositivos/solicitacao/uploadAnexoVba', SolicitacaoController::class, 'uploadAnexoVba')
    ->name('dispositivos.solicitacao.uploadAnexoVba');

//COMENTÁRIO (histórico) vindo do Access -> insere 1 linha na tabela historico
Route::post('/dispositivos/solicitacao/comentarVba', SolicitacaoController::class, 'comentarVba')
    ->name('dispositivos.solicitacao.comentarVba');

//ATUALIZAR STATUS (cancelar/tryout/validar) vindo do Access -> UPDATE fila
Route::post('/dispositivos/solicitacao/atualizarStatusVba', SolicitacaoController::class, 'atualizarStatusVba')
    ->name('dispositivos.solicitacao.atualizarStatusVba');

//MIGRAÇÃO INICIAL Access -> MySQL (carga única, upsert preservando o Ref)
Route::post('/dispositivos/solicitacao/migrarFila', SolicitacaoController::class, 'migrarFila')
    ->name('dispositivos.solicitacao.migrarFila');


Route::post('/dispositivos/historico/store/{ref}/{tipo}', SolicitacaoController::class, method: 'registraHistorico')
    ->name('dispositivos.historico.store')
    ->whereint(['ref'])
    ->whereString(['tipo']);



//VALIDAÇÃO
Route::post('/dispositivos/solicitacao/validacao/{ref}', SolicitacaoController::class, 'updateSituacao')
    ->name('dispositivos.validacao.store')
    ->whereInt(['ref']);




//DESENVOLVIMENTO
Route::get('/dispositivos/desenvolvimento/lista', DesenvolvimentoController::class, 'desenvolvimentoListaView')
    ->name('dispositivos.desenvolvimento.lista');

Route::post('/dispositivos/desenvolvimento/atualizaStatus', DesenvolvimentoController::class, 'atualizaStatus')
    ->name('dispositivos.desenvolvimento.atualizaStatus');

Route::get('/dispositivos/desenvolvimento/info/{ref}', DesenvolvimentoController::class, 'desenvolvimentoInfoView')
    ->name('dispositivos.desenvolvimento.info')
    ->whereInt(['ref']);

Route::post('/dispositivos/desenvolvimento/storeProjetista/{ref}/{tipo}', DesenvolvimentoController::class, 'storeProjetista')
    ->name('dispositivos.desenvolvimento.storeProjetista')
    ->whereint(['ref'])
    ->whereString(['tipo']);


Route::get('/dispositivos/desenvolvimento/gerarZ/{ref}', DesenvolvimentoController::class, 'gerarZ')
    ->name('dispositivos.desenvolvimento.gerarZ')
    ->whereint(['ref']);

Route::post('/dispositivos/desenvolvimento/associarZ/{ref}', DesenvolvimentoController::class, 'associarZ')
    ->name('dispositivos.desenvolvimento.associarZ')
    ->whereint(['ref']);

Route::get('/dispositivos/desenvolvimento/arquivos-solicitacao/{ref}', DesenvolvimentoController::class, 'arquivosSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivosSolicitacao')
    ->whereint(['ref']);

Route::post('/dispositivos/desenvolvimento/arquivos-solicitacao/{ref}/store', DesenvolvimentoController::class, 'storeArquivosSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivosSolicitacao.store')
    ->whereint(['ref']);

Route::get('/dispositivos/desenvolvimento/arquivo/{id}/visualizar', DesenvolvimentoController::class, 'visualizarArquivoSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivo.visualizar');

Route::get('/dispositivos/desenvolvimento/arquivo/{id}/download', DesenvolvimentoController::class, 'downloadArquivoSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivo.download');
    
Route::post('/dispositivos/desenvolvimento/imagem-projeto/{ref}/store', DesenvolvimentoController::class, 'storeImagemProjeto')
    ->name('dispositivos.desenvolvimento.imagemProjeto.store')
    ->whereint(['ref']);

// Access -> Web: recebe a imagem do projeto (frmaut.btnLoadImage) em binário cru.
// Parâmetros via query string: ?ref=NNN&nome=arquivo.jpg
Route::post('/dispositivos/desenvolvimento/uploadImagemVba', DesenvolvimentoController::class, 'uploadImagemVba')
    ->name('dispositivos.desenvolvimento.uploadImagemVba');

Route::post('/dispositivos/desenvolvimento/dxf/{ref}/store', DesenvolvimentoController::class, 'storePacoteDxf')
    ->name('dispositivos.desenvolvimento.dxf.store')
    ->whereint(['ref']);

// Cria as subpastas do VBA dentro do storage mapeado (APP_STORAGE_MAPPED). Rode 1x.
Route::get('/dispositivos/desenvolvimento/garantirStorageMapeado', DesenvolvimentoController::class, 'garantirStorageMapeado')
    ->name('dispositivos.desenvolvimento.garantirStorageMapeado');

// Access -> Web: recebe os feriados (planilha "Feriados") -> cria/popula a tabela feriados.
Route::post('/dispositivos/desenvolvimento/uploadFeriadosVba', DesenvolvimentoController::class, 'uploadFeriadosVba')
    ->name('dispositivos.desenvolvimento.uploadFeriadosVba');

// Cartório do número de DXF (GET_LOCK) — Access (ufdxf) pede o próximo Controle.
// ?floor=N opcional (MAX(Controle) atual do Access).
Route::get('/dispositivos/desenvolvimento/nextDxf', DesenvolvimentoController::class, 'nextDxf')
    ->name('dispositivos.desenvolvimento.nextDxf');

// Access -> Web: recebe UM pacote DXF (zip) do Access (ufdxf) em binário cru.
// ?ref=NNN&codigo=DX0001&nome=arquivo.zip
Route::post('/dispositivos/desenvolvimento/uploadDxfVba', DesenvolvimentoController::class, 'uploadDxfVba')
    ->name('dispositivos.desenvolvimento.uploadDxfVba');

// Web -> Access (pull): CSV dos pacotes DXF p/ o VBA upsertar em DXF_Control.
Route::get('/dispositivos/csvAtualizado/dxf', DesenvolvimentoController::class, 'csvDxf')
    ->name('dispositivos.atualizaCSV.dxf');

Route::post('/dispositivos/desenvolvimento/pdf/{ref}/store', DesenvolvimentoController::class, 'storeDesenhosPdf')
    ->name('dispositivos.desenvolvimento.pdf.store')
    ->whereint(['ref']);

// Access -> Web: recebe UM desenho PDF (frmaut.btn_pdf_novo) em binário cru.
// Parâmetros via query string: ?ref=NNN&codigo=XXX&nome=arquivo.pdf
Route::post('/dispositivos/desenvolvimento/uploadDesenhoPdfVba', DesenvolvimentoController::class, 'uploadDesenhoPdfVba')
    ->name('dispositivos.desenvolvimento.uploadDesenhoPdfVba');

// Web -> Access (pull): CSV dos desenhos PDF p/ o VBA upsertar em PDF_Control.
Route::get('/dispositivos/csvAtualizado/desenhosPdf', DesenvolvimentoController::class, 'csvDesenhosPdf')
    ->name('dispositivos.atualizaCSV.desenhosPdf');

Route::post('/dispositivos/desenvolvimento/itens-comprados-txt/{ref}/store', DesenvolvimentoController::class, 'storeItensCompradosTxt')
    ->name('dispositivos.desenvolvimento.itensCompradosTxt.store')
    ->whereint(['ref']);

// Access -> Web: recebe os itens de BOM (frm_bom.btnInserir) em lote (form-urlencoded).
Route::post('/dispositivos/desenvolvimento/uploadBomVba', DesenvolvimentoController::class, 'uploadBomVba')
    ->name('dispositivos.desenvolvimento.uploadBomVba');

Route::post('/dispositivos/desenvolvimento/uploadListaMateriaisVba', DesenvolvimentoController::class, 'uploadListaMateriaisVba')
    ->name('dispositivos.desenvolvimento.uploadListaMateriaisVba');
    
// Web -> Access (pull): CSV dos itens de BOM p/ o VBA upsertar em BOM_Control.
Route::get('/dispositivos/csvAtualizado/bom', DesenvolvimentoController::class, 'csvBom')
    ->name('dispositivos.atualizaCSV.bom');
    
Route::post('/dispositivos/desenvolvimento/arquivo/{id}/remover', DesenvolvimentoController::class, 'removerArquivoSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivo.remover');    
//ACOMPANHAMENTO SOLICITAÇÕES
Route::get(
    '/dispositivos/acompanhamento',
    AcompanhamentoController::class,
    'acompanhamentoView'
)
    ->name('dispositivos.acompanhamento');

Route::get(
    '/dispositivos/acompanhamento/{ref}',
    AcompanhamentoController::class,
    'acompanhamentoFormSL'
)
    ->name('dispositivos.acompanhamento.sl');


//AUTOCOMPLETE
Route::get('/dispositivos/autocomplete/', AcompanhamentoController::class, 'autocomplete')->name('dispositivos.acompanhamento.autocomplete');



//PARAMETRIZACAO USUARIOS
Route::get('/dispositivos/usuarios', UsuarioController::class, 'cadastroUsuarioView')
    ->name('parametrizacao.usuario');

Route::post('/dispositivos/usuarios/store', UsuarioController::class, 'storeUsuario')
    ->name('parametrizacao.usuario.store');

Route::post('/dispositivos/usuarios/update', UsuarioController::class, 'updateUsuario')
    ->name('parametrizacao.usuario.update');

Route::get('/dispositivos/usuarios/consulta', UsuarioController::class, 'consultaUsuario')
    ->name('parametrizacao.usuario.consulta');

Route::get('/dispositivos/usuarios/modalConfirm/{id}', UsuarioController::class, 'modalConfirm')
    ->name('parametrizacao.modal.usuario.delete')
    ->whereUuid(['id']);

Route::get('/dispositivos/usuarios/modalEdit/{id}', UsuarioController::class, 'modalEdit')
    ->name('parametrizacao.modal.usuario.edit')
    ->whereUuid(['id']);

Route::get('/dispositivos/usuarios/delete/{id}', UsuarioController::class, 'deleteUsuario')
    ->name('parametrizacao.usuario.delete')
    ->whereUuid(['id']);
    


//PARAMETRIZACAO VAGOES E LOTE

Route::get('/dispositivos/vagoes', VagaoController::class, 'cadastroVagaoView')
    ->name('parametrizacao.vagoes');

Route::post('/dispositivos/vagoes/store', VagaoController::class, 'storeVagao')
    ->name('parametrizacao.vagoes.store');

Route::post('/dispositivos/vagoes/update', VagaoController::class, 'updatevagao')
    ->name('parametrizacao.vagoes.update')
    ->whereUuid(['id']);


Route::get('/dispositivos/vagoes/destroy/{id}', VagaoController::class, 'modalConfirm')
    ->name('parametrizacao.modal.vagoes.delete')
    ->whereUuid(['id']);

Route::get('/dispositivos/vagoes/edit/{id}', VagaoController::class, 'modalEdit')
    ->name('parametrizacao.modal.vagoes.edit')
    ->whereUuid(['id']);

Route::get('/dispositivos/vagoes/delete/{id}', VagaoController::class, 'deletevagao')
    ->name('parametrizacao.vagoes.delete')
    ->whereUuid(['id']);



//PARAMETRIZACAO ESTAGIO

Route::get('/dispositivos/estagios', EstagioController::class, 'cadastroEstagioView')
    ->name('parametrizacao.estagios');

Route::post('/dispositivos/estagios/store', EstagioController::class, 'storeEstagio')
    ->name('parametrizacao.estagios.store');

Route::post('/dispositivos/estagios/update', EstagioController::class, 'updateEstagio')
    ->name('parametrizacao.estagios.update')
    ->whereUuid(['id']);


Route::get('/dispositivos/estagios/destroy/{id}', EstagioController::class, 'modalConfirm')
    ->name('parametrizacao.modal.estagios.delete')
    ->whereUuid(['id']);

Route::get('/dispositivos/estagios/edit/{id}', EstagioController::class, 'modalEdit')
    ->name('parametrizacao.modal.estagios.edit')
    ->whereUuid(['id']);

Route::get('/dispositivos/estagios/delete/{id}', EstagioController::class, 'deleteEstagio')
    ->name('parametrizacao.estagios.delete')
    ->whereUuid(['id']);


//PARAMETRIZACAO CONTAS

Route::get('/dispositivos/contas', ContaController::class, 'cadastroContaView')
    ->name('parametrizacao.contas');


Route::get('/dispositivos/contas/getLoteByVagao', ContaController::class, 'getLoteByVagao')
    ->name('parametrizacao.contas.getLote');


Route::get('dispositivos/contas/getDescricaoConta', ContaController::class, 'getDescricaoConta')
    ->name('parametrizacao.contas.getDescricao');

Route::post('/dispositivos/contas/store', ContaController::class, 'storeConta')
    ->name('parametrizacao.contas.store');

Route::post('/dispositivos/contas/update', ContaController::class, 'updateConta')
    ->name('parametrizacao.contas.update')
    ->whereUuid(['id']);


Route::get('/dispositivos/contas/destroy/{id}', ContaController::class, 'modalConfirm')
    ->name('parametrizacao.modal.contas.delete')
    ->whereUuid(['id']);

Route::get('/dispositivos/contas/edit/{id}', ContaController::class, 'modalEdit')
    ->name('parametrizacao.modal.contas.edit')
    ->whereUuid(['id']);

Route::get('/dispositivos/contas/delete/{id}', ContaController::class, 'deleteEstagio')
    ->name('parametrizacao.contas.delete')
    ->whereUuid(['id']);

// NOVO — Access -> Web: lista de usuários (Solicitantes: email+nome) p/ casar o autor por e-mail
Route::post('/dispositivos/solicitacao/uploadSolicitantesVba', SolicitacaoController::class, 'uploadSolicitantesVba')
    ->name('dispositivos.solicitacao.uploadSolicitantesVba');


/* ============================================================================
 *  LIBERAÇÃO DE SL + AQUISIÇÃO — adicionado em 2026-07-21
 *  Ver docs/doc-alteracoes/2026-07-21-responsivo-liberacao-aquisicao.md
 * ========================================================================== */

// Modal de liberação da SL (pede a consideração que vai para o chatbox)
Route::get('/dispositivos/desenvolvimento/liberacao/{ref}', DesenvolvimentoController::class, 'modalLiberacao')
    ->name('dispositivos.desenvolvimento.liberacao.modal')
    ->whereInt(['ref']);

// Confirma a liberação: liberacao_status = OK + histórico + roteia p/ aquisição
Route::post('/dispositivos/desenvolvimento/liberacao/{ref}', DesenvolvimentoController::class, 'storeLiberacao')
    ->name('dispositivos.desenvolvimento.liberacao.store')
    ->whereInt(['ref']);

// Salva o N° OC (digitado) de UM item comprado
Route::post('/dispositivos/desenvolvimento/aquisicao/item/{id}/store', DesenvolvimentoController::class, 'storeItemAquisicao')
    ->name('dispositivos.desenvolvimento.aquisicao.item.store')
    ->whereUuid(['id']);

// ROTINA (cron): consulta o Logix e preenche pedido + liquidação.
// Rota estática — o simpleRouter resolve antes das dinâmicas de aquisição.
// Protegida por APP_CRON_TOKEN (?token=...).
Route::get('/dispositivos/desenvolvimento/aquisicao/sincronizar-logix', DesenvolvimentoController::class, 'sincronizarLogix')
    ->name('dispositivos.desenvolvimento.aquisicao.sincronizarLogix');

// Resumo da liquidação (revalida o botão "Concluir aquisição" sem recarregar)
Route::get('/dispositivos/desenvolvimento/aquisicao/{ref}/resumo', DesenvolvimentoController::class, 'resumoAquisicao')
    ->name('dispositivos.desenvolvimento.aquisicao.resumo')
    ->whereInt(['ref']);

// Conclui a aquisição — exige TODOS os itens liquidados
Route::post('/dispositivos/desenvolvimento/aquisicao/{ref}/concluir', DesenvolvimentoController::class, 'concluirAquisicao')
    ->name('dispositivos.desenvolvimento.aquisicao.concluir')
    ->whereInt(['ref']);

// BYPASS de teste — conclui a aquisição sem liquidar (só matrículas autorizadas)
// 2026-07-21 (2ª rodada)
Route::post('/dispositivos/desenvolvimento/aquisicao/{ref}/concluir-bypass', DesenvolvimentoController::class, 'concluirAquisicaoBypass')
    ->name('dispositivos.desenvolvimento.aquisicao.concluirBypass')
    ->whereInt(['ref']);

// RETORNAR / CANCELAR SL a partir das etapas de aquisição/corte/execução
// 2026-07-21 (3ª rodada) — ambos pedem motivo (modal) que vai para o chatbox
Route::get('/dispositivos/desenvolvimento/motivo-etapa/{ref}', DesenvolvimentoController::class, 'modalMotivoEtapa')
    ->name('dispositivos.desenvolvimento.motivoEtapa')
    ->whereInt(['ref']);

Route::post('/dispositivos/desenvolvimento/retornar/{ref}', DesenvolvimentoController::class, 'retornarSl')
    ->name('dispositivos.desenvolvimento.retornar')
    ->whereInt(['ref']);

Route::post('/dispositivos/desenvolvimento/cancelar/{ref}', DesenvolvimentoController::class, 'cancelarSl')
    ->name('dispositivos.desenvolvimento.cancelar')
    ->whereInt(['ref']);


/* ============================================================================
 *  INDUSTRIAL — 2026-07-21 (4ª rodada)
 *  Corte e Execução saíram da automação e passaram para esta tela.
 * ========================================================================== */

Route::get('/dispositivos/industrial', IndustrialController::class, 'industrialListaView')
    ->name('dispositivos.industrial.lista');

Route::get('/dispositivos/industrial/info/{ref}', IndustrialController::class, 'industrialInfoView')
    ->name('dispositivos.industrial.info')
    ->whereInt(['ref']);

Route::post('/dispositivos/industrial/campos/{ref}', IndustrialController::class, 'salvarCamposIndustrial')
    ->name('dispositivos.industrial.campos')
    ->whereInt(['ref']);


/* ============================================================================
 *  CONTROLE DE CORTES DE PEÇAS — 2026-07-21 (5ª rodada)
 *  Traz para a web a tela "Dados do Projeto" que hoje vive no Access.
 * ========================================================================== */

Route::get('/dispositivos/cortes', ControleCorteController::class, 'listaCortesView')
    ->name('dispositivos.cortes.lista');

// Rota estática antes das dinâmicas de {codigo} — o simpleRouter resolve primeiro
Route::post('/dispositivos/cortes/plano/{id}/remover', ControleCorteController::class, 'removerPlano')
    ->name('dispositivos.cortes.plano.remover')
    ->whereUuid(['id']);

Route::get('/dispositivos/cortes/{codigo}', ControleCorteController::class, 'detalheCorteView')
    ->name('dispositivos.cortes.detalhe')
    ->whereString(['codigo']);

Route::post('/dispositivos/cortes/{codigo}/controle', ControleCorteController::class, 'salvarControle')
    ->name('dispositivos.cortes.controle')
    ->whereString(['codigo']);

Route::post('/dispositivos/cortes/{codigo}/plano', ControleCorteController::class, 'salvarPlano')
    ->name('dispositivos.cortes.plano')
    ->whereString(['codigo']);


// PARAMETRIZAÇÃO — espessuras dos planos de corte
Route::get('/dispositivos/espessuras', EspessuraController::class, 'cadastroEspessuraView')
    ->name('parametrizacao.espessuras');

Route::post('/dispositivos/espessuras/store', EspessuraController::class, 'storeEspessura')
    ->name('parametrizacao.espessuras.store');

Route::post('/dispositivos/espessuras/update', EspessuraController::class, 'updateEspessura')
    ->name('parametrizacao.espessuras.update');

Route::get('/dispositivos/espessuras/delete/{id}', EspessuraController::class, 'deleteEspessura')
    ->name('parametrizacao.espessuras.delete')
    ->whereUuid(['id']);


/* ============================================================================
 *  CÁLCULO DE PESO / CONSOLIDADO POR ESPESSURA — 2026-07-21 (6ª rodada)
 * ========================================================================== */

Route::get('/dispositivos/cortes-peso', CalculoPesoController::class, 'consolidadoView')
    ->name('dispositivos.cortes.calculoPeso');

Route::get('/dispositivos/cortes-perfis', CalculoPesoController::class, 'perfisView')
    ->name('dispositivos.cortes.perfis');

// Busca da descrição do item no Logix/Informix (tabela item) — AJAX dos perfis
Route::get('/dispositivos/cortes-item', CalculoPesoController::class, 'buscarItemView')
    ->name('dispositivos.cortes.item');

// Consolidado de itens comprados (BOM) por descrição — 2026-07-21 (7ª rodada)
Route::get('/dispositivos/itens-consolidado', ItensConsolidadoController::class, 'consolidadoItensView')
    ->name('dispositivos.itens.consolidado');

// PARAMETRIZAÇÃO — perfis lineares
Route::get('/dispositivos/perfis', PerfilController::class, 'cadastroPerfilView')
    ->name('parametrizacao.perfis');

Route::post('/dispositivos/perfis/store', PerfilController::class, 'storePerfil')
    ->name('parametrizacao.perfis.store');

Route::post('/dispositivos/perfis/update', PerfilController::class, 'updatePerfil')
    ->name('parametrizacao.perfis.update');

Route::get('/dispositivos/perfis/delete/{id}', PerfilController::class, 'deletePerfil')
    ->name('parametrizacao.perfis.delete')
    ->whereUuid(['id']);
