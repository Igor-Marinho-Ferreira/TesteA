<?php

namespace src\app\database\entities;

use DateTime;
use src\app\database\Querio;

class UniformWithdrawalRecord extends Querio
{
    protected static string $table = 'tuniform_withdrawal_records';
    protected static string $dbType = 'intranet';

    public static function createWithdrawal(array $data): string|bool
    {
        $uuid = self::uuid();

        $result = static::create([
            'uuid'                      => $uuid,

            'num_reserva'               => $data['num_reserva'] ?? '',
            'cod_item'                  => $data['cod_item'] ?? '',
            'den_item'                  => $data['den_item'] ?? '',

            'qtd_reservada'             => $data['qtd_reservada'] ?? null,
            'qtd_atendida'              => $data['qtd_atendida'] ?? null,
            'qtd_retirada'              => $data['qtd_retirada'] ?? null,
            'dias'                      => $data['dias'] ?? null,

            'reserva_num_matricula'     => $data['reserva_num_matricula'] ?? '',
            'reserva_nom_funcionario'   => $data['reserva_nom_funcionario'] ?? '',

            'cracha'                    => $data['cracha'] ?? '',
            'retirada_num_matricula'    => $data['retirada_num_matricula'] ?? '',
            'retirada_nom_funcionario'  => $data['retirada_nom_funcionario'] ?? '',

            'observacao'                => $data['observacao'] ?? null,

            'created_by'                => $data['created_by'] ?? null,
            'created_at'                => date('Y-m-d H:i:s'),
        ]);

        return $result ? $uuid : false;
    }

    public static function findByReservation(string $numReserva): array
    {
        return static::select(['*'])
            ->whereEquals('num_reserva', $numReserva)
            ->order('created_at', 'DESC')
            ->finish() ?: [];
    }

    public static function findByUuid(string $uuid): object|bool
    {
        return static::selectOne(['*'])
            ->whereEquals('uuid', $uuid)
            ->finish();
    }

    public static function findByReservationItemAndReservedEmployee(
        string $numReserva,
        string $codItem,
        string $reservaNumMatricula
    ): object|bool {
        return static::selectOne(['*'])
            ->whereEquals('num_reserva', $numReserva)
            ->andWhere('cod_item', '=', $codItem)
            ->andWhere('reserva_num_matricula', '=', $reservaNumMatricula)
            ->finish();
    }

    public static function deleteByUuid(string $uuid): bool
    {
        $result = static::deleteByColumn('uuid', '=', $uuid);

        return $result ? true : false;
    }

    public static function findWithdrawalsByDateRange(
        string $startDate = '',
        string $endDate = '',
        int $limit = 500
    ): array {
        $startDate = trim($startDate);
        $endDate = trim($endDate);

        $records = static::select(['*'])
            ->order('created_at', 'DESC')
            ->limit(5000)
            ->finish() ?: [];

        if ($startDate === '' && $endDate === '') {
            return array_slice($records, 0, $limit);
        }

        $start = self::makeDateStart($startDate);
        $end = self::makeDateEnd($endDate);

        $filtered = [];

        foreach ($records as $record) {
            $createdAt = self::getValue($record, ['created_at', 'CREATED_AT']);

            if ($createdAt === '') {
                continue;
            }

            $createdTimestamp = self::makeTimestamp($createdAt);

            if ($createdTimestamp === null) {
                continue;
            }

            if ($start !== null && $createdTimestamp < $start) {
                continue;
            }

            if ($end !== null && $createdTimestamp > $end) {
                continue;
            }

            $filtered[] = $record;

            if (count($filtered) >= $limit) {
                break;
            }
        }

        return $filtered;
    }

    private static function makeDateStart(string $date): ?int
    {
        $date = trim($date);

        if ($date === '') {
            return null;
        }

        $normalized = self::normalizeDate($date);

        if ($normalized === '') {
            return null;
        }

        return strtotime($normalized . ' 00:00:00') ?: null;
    }

    private static function makeDateEnd(string $date): ?int
    {
        $date = trim($date);

        if ($date === '') {
            return null;
        }

        $normalized = self::normalizeDate($date);

        if ($normalized === '') {
            return null;
        }

        return strtotime($normalized . ' 23:59:59') ?: null;
    }

    private static function normalizeDate(string $date): string
    {
        $date = trim($date);

        if ($date === '') {
            return '';
        }

        $formats = [
            'Y-m-d',
            'd/m/Y',
            'd-m-Y',
            'Y/m/d',
        ];

        foreach ($formats as $format) {
            $dateTime = DateTime::createFromFormat($format, $date);

            if ($dateTime && $dateTime->format($format) === $date) {
                return $dateTime->format('Y-m-d');
            }
        }

        return '';
    }

    private static function makeTimestamp(string $date): ?int
    {
        $date = trim($date);

        if ($date === '') {
            return null;
        }

        $timestamp = strtotime($date);

        return $timestamp !== false ? $timestamp : null;
    }

    private static function getValue(object|array $source, array $keys): string
    {
        foreach ($keys as $key) {
            if (is_object($source) && isset($source->{$key})) {
                return trim((string) $source->{$key});
            }

            if (is_array($source) && isset($source[$key])) {
                return trim((string) $source[$key]);
            }
        }

        return '';
    }

    private static function uuid(): string
    {
        $data = random_bytes(16);

        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}