<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Log extends Querio
{
    protected static string $table = 'tuniform_withdrawal_logs';
    protected static string $dbType = 'intranet';

    private const SCREEN_UNIFORM_WITHDRAWAL_REPORT = 'uniform-withdrawal-report';

    public static function create_log(
        string $created_by,
        string $screen_name,
        string $action,
        ?string $record_uuid = null,
        ?string $num_reserva = null
    ): bool {
        $data = [
            'uuid'        => self::uuid(),
            'created_by'  => $created_by,
            'screen_name' => $screen_name,
            'action'      => $action,
            'created_at'  => date('Y-m-d H:i:s'),
        ];

        if (!empty($record_uuid)) {
            $data['record_uuid'] = $record_uuid;
        }

        if (!empty($num_reserva)) {
            $data['num_reserva'] = $num_reserva;
        }

        $result = static::create($data);

        return $result ? true : false;
    }

    public static function getLogsByReservation(string $numReserva, int $limit = 500): array
    {
        return static::select(['*'])
            ->whereEquals('screen_name', self::SCREEN_UNIFORM_WITHDRAWAL_REPORT)
            ->andWhere('num_reserva', '=', $numReserva)
            ->order('created_at', 'DESC')
            ->limit($limit)
            ->finish() ?: [];
    }

    public static function getLogsByRecord(string $recordUuid, int $limit = 100): array
    {
        return static::select(['*'])
            ->whereEquals('record_uuid', $recordUuid)
            ->order('created_at', 'DESC')
            ->limit($limit)
            ->finish() ?: [];
    }

    public static function uniformWithdrawalCreated(
        string $created_by,
        array $data,
        ?string $record_uuid = null
    ): bool {
        $numReserva = self::emptyToDash($data['num_reserva'] ?? null);

        $action = 'Registrou retirada de uniforme. ' .
            self::formatWithdrawalData($data);

        return self::create_log(
            $created_by,
            self::SCREEN_UNIFORM_WITHDRAWAL_REPORT,
            $action,
            $record_uuid,
            $numReserva
        );
    }

    public static function uniformWithdrawalReversed(
        string $created_by,
        array $data,
        string $reason,
        ?string $record_uuid = null
    ): bool {
        $numReserva = self::emptyToDash($data['num_reserva'] ?? null);

        $action = 'Reverteu retirada de uniforme. ' .
            'Motivo: ' . self::emptyToDash($reason) . '. ' .
            self::formatWithdrawalData($data);

        return self::create_log(
            $created_by,
            self::SCREEN_UNIFORM_WITHDRAWAL_REPORT,
            $action,
            $record_uuid,
            $numReserva
        );
    }

    private static function formatWithdrawalData(array $data): string
    {
        return 'Reserva: ' . self::emptyToDash($data['num_reserva'] ?? null) . '. ' .
            'Item: ' . self::emptyToDash($data['cod_item'] ?? null) . '. ' .
            'Descrição: ' . self::emptyToDash($data['den_item'] ?? null) . '. ' .
            'Dias: ' . self::emptyToDash($data['dias'] ?? null) . '. ' .
            'Reserva para: ' .
                self::emptyToDash($data['reserva_num_matricula'] ?? null) .
                ' - ' .
                self::emptyToDash($data['reserva_nom_funcionario'] ?? null) . '. ' .
            'Retirada por: ' .
                self::emptyToDash($data['retirada_num_matricula'] ?? null) .
                ' - ' .
                self::emptyToDash($data['retirada_nom_funcionario'] ?? null) . '. ' .
            'Crachá: ' . self::emptyToDash($data['cracha'] ?? null) . '.';
    }

    private static function emptyToDash(mixed $value): string
    {
        $value = trim((string) $value);

        return $value !== '' ? $value : '-';
    }

    private static function uuid(): string
    {
        $data = random_bytes(16);

        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}