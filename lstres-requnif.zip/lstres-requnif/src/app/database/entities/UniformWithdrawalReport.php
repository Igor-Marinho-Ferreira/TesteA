<?php

namespace src\app\database\entities;

use PDO;
use Throwable;
use src\app\database\Database;

class UniformWithdrawalReport
{
    private const COMPANY_CODE = '40';

    public static function findByReservation(string $reservationNumber): array
    {
        $db = Database::get('informix');

        $reservationNumber = trim($reservationNumber);

        if ($reservationNumber === '') {
            return [];
        }

        self::prepareInformixSession($db);

        $suffix = self::makeTempSuffix();

        $tempT1 = 'u1_' . $suffix;
        $tempT2 = 'u2_' . $suffix;
        $tempT3 = 'u3_' . $suffix;
        $tempDias = 'ud_' . $suffix;

        try {
            self::dropTempTable($db, $tempT1);
            self::dropTempTable($db, $tempT2);
            self::dropTempTable($db, $tempT3);
            self::dropTempTable($db, $tempDias);

            $sqlTempT1 = "
                SELECT
                    a.num_reserva,
                    a.cod_item,
                    NVL(a.qtd_reservada, 0) AS qtd_reservada,
                    d.den_item,
                    c.num_matricula,
                    c.nom_funcionario
                FROM
                    estoque_loc_reser a,
                    estoq_loc_res_obs b,
                    funcionario c,
                    item d
                WHERE
                    a.cod_empresa = :cod_empresa
                    AND a.num_reserva = :num_reserva
                    AND b.cod_empresa = a.cod_empresa
                    AND b.num_reserva = a.num_reserva
                    AND c.cod_empresa = a.cod_empresa
                    AND c.num_matricula = substr(b.tex_observ, 1, 6)
                    AND d.cod_empresa = a.cod_empresa
                    AND d.cod_item = a.cod_item
                INTO TEMP {$tempT1} WITH NO LOG
            ";

            $stmtTempT1 = $db->prepare($sqlTempT1);
            $stmtTempT1->bindValue(':cod_empresa', self::COMPANY_CODE);
            $stmtTempT1->bindValue(':num_reserva', $reservationNumber);
            $stmtTempT1->execute();

            $sqlTempT2 = "
                SELECT
                    cod_item,
                    matricula,
                    dat_movto,
                    TODAY - dat_movto AS dias,
                    qtd_atendida
                FROM (
                    SELECT
                        a.cod_item,
                        substr(a.texto_observacao, 1, 6) AS matricula,
                        b.dat_movto,
                        NVL(a.qtd_atendida, 0) AS qtd_atendida,
                        ROW_NUMBER() OVER (
                            PARTITION BY
                                a.cod_item,
                                substr(a.texto_observacao, 1, 6)
                            ORDER BY
                                b.dat_movto DESC
                        ) AS rn
                    FROM
                        h_estoque_loc_reser a
                    JOIN h_estoque_trans b
                        ON b.cod_empresa = a.cod_empresa
                       AND b.num_docum = TO_CHAR(a.num_reserva)
                       AND b.cod_operacao = '15'
                    JOIN {$tempT1} c
                        ON a.texto_observacao = concat(c.num_matricula, '40')
                       AND a.cod_item = c.cod_item
                    WHERE
                        a.cod_empresa = '40'
                )
                WHERE rn = 1
                INTO TEMP {$tempT2} WITH NO LOG
            ";

            $db->exec($sqlTempT2);

            $sqlTempT3 = "
                SELECT
                    cod_item,
                    matricula,
                    dat_movto,
                    TODAY - dat_movto AS dias,
                    qtd_atendida
                FROM (
                    SELECT
                        a.cod_item,
                        substr(a.texto_observacao, 1, 6) AS matricula,
                        b.dat_movto,
                        NVL(a.qtd_atendida, 0) AS qtd_atendida,
                        ROW_NUMBER() OVER (
                            PARTITION BY
                                a.cod_item,
                                substr(a.texto_observacao, 1, 6)
                            ORDER BY
                                b.dat_movto DESC
                        ) AS rn
                    FROM
                        h_estoque_loc_reser a
                    JOIN estoque_trans b
                        ON b.cod_empresa = a.cod_empresa
                       AND b.num_docum = TO_CHAR(a.num_reserva)
                       AND b.cod_operacao = '15'
                    JOIN {$tempT1} c
                        ON a.texto_observacao = concat(c.num_matricula, '40')
                       AND a.cod_item = c.cod_item
                    WHERE
                        a.cod_empresa = '40'
                )
                WHERE rn = 1
                INTO TEMP {$tempT3} WITH NO LOG
            ";

            $db->exec($sqlTempT3);

            $sqlTempDias = "
                SELECT
                    cod_item,
                    matricula,
                    dat_movto,
                    dias,
                    qtd_atendida
                FROM (
                    SELECT
                        cod_item,
                        matricula,
                        dat_movto,
                        dias,
                        qtd_atendida,
                        ROW_NUMBER() OVER (
                            PARTITION BY cod_item, matricula
                            ORDER BY dat_movto DESC, dias ASC
                        ) AS rn
                    FROM (
                        SELECT * FROM {$tempT2}
                        UNION ALL
                        SELECT * FROM {$tempT3}
                    )
                )
                WHERE rn = 1
                INTO TEMP {$tempDias} WITH NO LOG
            ";

            $db->exec($sqlTempDias);

            $sqlFinal = "
                SELECT
                    {$tempT1}.num_reserva,
                    {$tempT1}.cod_item,
                    NVL({$tempT1}.qtd_reservada, 0) AS qtd_reservada,
                    NVL({$tempDias}.qtd_atendida, 0) AS qtd_atendida,
                    NVL({$tempT1}.qtd_reservada, 0) + NVL({$tempDias}.qtd_atendida, 0) AS qtd_retirada,
                    {$tempT1}.den_item,
                    {$tempT1}.num_matricula,
                    {$tempT1}.nom_funcionario,
                    {$tempDias}.dias
                FROM
                    {$tempT1},
                    OUTER {$tempDias}
                WHERE
                    {$tempT1}.num_matricula = {$tempDias}.matricula
                    AND {$tempT1}.cod_item = {$tempDias}.cod_item
                ORDER BY
                    {$tempT1}.cod_item,
                    {$tempT1}.num_matricula
            ";

            $stmt = $db->prepare($sqlFinal);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_OBJ);

            $records = $stmt->fetchAll() ?: [];

            self::dropTempTable($db, $tempT1);
            self::dropTempTable($db, $tempT2);
            self::dropTempTable($db, $tempT3);
            self::dropTempTable($db, $tempDias);

            return $records;
        } catch (Throwable $e) {
            self::dropTempTable($db, $tempT1);
            self::dropTempTable($db, $tempT2);
            self::dropTempTable($db, $tempT3);
            self::dropTempTable($db, $tempDias);

            return [];
        }
    }

    public static function findEmployee(string $type, string $value): object|bool
    {
        $db = Database::get('informix');

        $type = trim($type);
        $value = trim($value);

        if ($value === '') {
            return false;
        }

        self::prepareInformixSession($db);

        if ($type === 'matricula') {
            $where = "c.num_matricula = :value";
        } elseif ($type === 'cracha') {
            $where = "m.cod_mifare = :value";
        } else {
            return false;
        }

        $sql = "
            SELECT FIRST 1
                c.num_matricula,
                c.nom_funcionario,
                CAST(m.cod_mifare AS VARCHAR(60)) AS cracha
            FROM
                funcionario c
            LEFT JOIN mx_mifare m
                ON m.num_matricula = c.num_matricula
            WHERE
                c.cod_empresa = :cod_empresa
                AND {$where}
            ORDER BY
                c.nom_funcionario,
                m.cod_mifare
        ";

        try {
            $stmt = $db->prepare($sql);
            $stmt->bindValue(':cod_empresa', self::COMPANY_CODE);
            $stmt->bindValue(':value', $value);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_OBJ);

            return $stmt->fetch() ?: false;
        } catch (Throwable $e) {
            return false;
        }
    }

    public static function findWithdrawalRuleByItem(string $codItem): object|bool
    {
        $db = Database::get('informix');

        $codItem = trim($codItem);

        if ($codItem === '') {
            return false;
        }

        self::prepareInformixSession($db);

        $sql = "
            SELECT FIRST 1
                cod_item,
                qtd_max_retirada,
                dias_reposicao
            FROM
                mx_matseg
            WHERE
                cod_empresa = :cod_empresa
                AND ies_versao_atual = 'S'
                AND cod_item = :cod_item
        ";

        try {
            $stmt = $db->prepare($sql);
            $stmt->bindValue(':cod_empresa', self::COMPANY_CODE);
            $stmt->bindValue(':cod_item', $codItem);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_OBJ);

            return $stmt->fetch() ?: false;
        } catch (Throwable $e) {
            return false;
        }
    }

    private static function prepareInformixSession(PDO $db): void
    {
        try {
            $db->exec("SET ISOLATION TO DIRTY READ");
        } catch (Throwable $e) {
        }

        try {
            $db->exec("SET LOCK MODE TO WAIT 10");
        } catch (Throwable $e) {
        }
    }

    private static function makeTempSuffix(): string
    {
        return substr(str_replace('.', '', uniqid('', true)), -10);
    }

    private static function dropTempTable(PDO $db, string $tableName): void
    {
        try {
            $db->exec("DROP TABLE {$tableName}");
        } catch (Throwable $e) {
        }
    }
}