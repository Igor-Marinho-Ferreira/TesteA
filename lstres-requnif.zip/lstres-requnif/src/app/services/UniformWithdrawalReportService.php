<?php

namespace src\app\services;

use Exception;
use src\app\database\entities\Log;
use src\app\database\entities\UniformWithdrawalRecord;
use src\app\database\entities\UniformWithdrawalReport;

class UniformWithdrawalReportService
{
    private array $withdrawalRuleCache = [];

    public function searchReportByReservation(string $numReserva, string $userKey = ''): array
    {
        $numReserva = trim($numReserva);

        if ($numReserva === '') {
            throw new Exception('Informe o número da reserva.');
        }

        if (!preg_match('/^[0-9]+$/', $numReserva)) {
            throw new Exception('Informe um número de reserva válido.');
        }

        $records = UniformWithdrawalReport::findByReservation($numReserva);

        if (empty($records)) {
            return [];
        }

        $withdrawals = UniformWithdrawalRecord::findByReservation($numReserva);
        $withdrawalMap = $this->buildWithdrawalMap($withdrawals);

        foreach ($records as $record) {
            $codItem = $this->getValue($record, ['COD_ITEM', 'cod_item']);
            $reservaNumMatricula = $this->getValue($record, ['NUM_MATRICULA', 'num_matricula']);

            $dias = $this->normalizeNullableValue($this->getValue($record, [
                'DIAS',
                'dias'
            ]));

            $qtdReservada = $this->normalizeNullableValue($this->getValue($record, [
                'QTD_RESERVADA',
                'qtd_reservada'
            ]));

            $qtdAtendida = $this->normalizeNullableValue($this->getValue($record, [
                'QTD_ATENDIDA',
                'qtd_atendida'
            ]));

            $qtdRetirada = $this->normalizeNullableValue($this->getValue($record, [
                'QTD_RETIRADA',
                'qtd_retirada'
            ]));

            if ($qtdRetirada === null) {
                $qtdRetirada = $this->sumNullableNumbers($qtdReservada, $qtdAtendida);
            }

            $key = $this->makeKey($codItem, $reservaNumMatricula);

            $withdrawal = $withdrawalMap[$key] ?? null;

            $record->withdrawal_registered = $withdrawal ? true : false;

            $record->withdrawal_record_uuid = $withdrawal
                ? $this->getValue($withdrawal, ['uuid', 'UUID'])
                : '';

            $record->withdrawal_cracha = $withdrawal
                ? $this->getValue($withdrawal, ['cracha', 'CRACHA'])
                : '';

            $record->withdrawal_created_at = $withdrawal
                ? $this->getValue($withdrawal, ['created_at', 'CREATED_AT'])
                : '';

            $record->withdrawal_created_by = $withdrawal
                ? $this->getValue($withdrawal, ['created_by', 'CREATED_BY'])
                : '';

            $record->withdrawal_retirada_num_matricula = $withdrawal
                ? $this->getValue($withdrawal, ['retirada_num_matricula', 'RETIRADA_NUM_MATRICULA'])
                : '';

            $record->withdrawal_retirada_nom_funcionario = $withdrawal
                ? $this->getValue($withdrawal, ['retirada_nom_funcionario', 'RETIRADA_NOM_FUNCIONARIO'])
                : '';

            $record->withdrawal_dias = $withdrawal
                ? $this->getValue($withdrawal, ['dias', 'DIAS'])
                : '';

            $record->withdrawal_qtd_reservada = $withdrawal
                ? $this->getValue($withdrawal, ['qtd_reservada', 'QTD_RESERVADA'])
                : '';

            $record->qtd_atendida = $qtdAtendida;
            $record->qtd_retirada = $qtdRetirada;

            $blockReason = '';

            if (!$withdrawal) {
                $blockReason = $this->getWithdrawalRuleBlockReason(
                    $codItem,
                    $dias,
                    $qtdRetirada
                );
            }

            $record->withdrawal_blocked = $blockReason !== '';
            $record->withdrawal_block_reason = $blockReason;
        }

        return $records;
    }

    public function findEmployee(string $type, string $value, string $userKey = ''): object
    {
        $type = trim($type);
        $value = trim($value);

        if ($value === '') {
            throw new Exception('Informe o crachá ou a matrícula.');
        }

        if (!in_array($type, ['cracha', 'matricula'], true)) {
            throw new Exception('Tipo de consulta inválido.');
        }

        $employee = UniformWithdrawalReport::findEmployee($type, $value);

        if (!$employee) {
            throw new Exception('Funcionário não encontrado.');
        }

        return $employee;
    }

    public function storeWithdrawal(array $data): bool
    {
        $numReserva = trim((string) ($data['num_reserva'] ?? ''));
        $codItem = trim((string) ($data['cod_item'] ?? ''));

        $reservaNumMatricula = trim((string) ($data['reserva_num_matricula'] ?? ''));
        $reservaNomFuncionario = trim((string) ($data['reserva_nom_funcionario'] ?? ''));

        $cracha = trim((string) ($data['cracha'] ?? ''));
        $retiradaNumMatricula = trim((string) ($data['retirada_num_matricula'] ?? ''));
        $retiradaNomFuncionario = trim((string) ($data['retirada_nom_funcionario'] ?? ''));

        $observacao = trim((string) ($data['observacao'] ?? ''));
        $createdBy = trim((string) ($data['created_by'] ?? ''));

        if ($numReserva === '') {
            throw new Exception('Número da reserva não informado.');
        }

        if (!preg_match('/^[0-9]+$/', $numReserva)) {
            throw new Exception('Informe um número de reserva válido.');
        }

        if ($codItem === '') {
            throw new Exception('Item não informado.');
        }

        if ($reservaNumMatricula === '') {
            throw new Exception('Matrícula da reserva não informada.');
        }

        if ($cracha === '' && $retiradaNumMatricula === '') {
            throw new Exception('Informe o crachá ou a matrícula de quem está retirando.');
        }

        $reportRecord = $this->findReportRecordForWithdrawal(
            $numReserva,
            $codItem,
            $reservaNumMatricula
        );

        $denItem = $this->getValue($reportRecord, ['DEN_ITEM', 'den_item']);

        $dias = $this->normalizeNullableValue($this->getValue($reportRecord, [
            'DIAS',
            'dias'
        ]));

        $qtdReservada = $this->normalizeNullableValue($this->getValue($reportRecord, [
            'QTD_RESERVADA',
            'qtd_reservada'
        ]));

        $qtdAtendida = $this->normalizeNullableValue($this->getValue($reportRecord, [
            'QTD_ATENDIDA',
            'qtd_atendida'
        ]));

        $qtdRetirada = $this->normalizeNullableValue($this->getValue($reportRecord, [
            'QTD_RETIRADA',
            'qtd_retirada'
        ]));

        if ($qtdRetirada === null) {
            $qtdRetirada = $this->sumNullableNumbers($qtdReservada, $qtdAtendida);
        }

        $blockReason = $this->getWithdrawalRuleBlockReason($codItem, $dias, $qtdRetirada);

        if ($blockReason !== '' && $observacao === '') {
            throw new Exception('Este item está bloqueado pela regra de reposição. Informe uma observação para registrar a retirada.');
        }

        $reportReservaNomFuncionario = $this->getValue($reportRecord, [
            'NOM_FUNCIONARIO',
            'nom_funcionario'
        ]);

        if ($reportReservaNomFuncionario !== '') {
            $reservaNomFuncionario = $reportReservaNomFuncionario;
        }

        if ($reservaNomFuncionario === '') {
            throw new Exception('Funcionário da reserva não informado.');
        }

        $employee = null;

        if ($retiradaNumMatricula !== '') {
            $employee = UniformWithdrawalReport::findEmployee('matricula', $retiradaNumMatricula);
        } elseif ($cracha !== '') {
            $employee = UniformWithdrawalReport::findEmployee('cracha', $cracha);
        }

        if (!$employee) {
            throw new Exception('Funcionário da retirada não encontrado.');
        }

        $employeeCracha = $this->getValue($employee, ['CRACHA', 'cracha']);
        $employeeMatricula = $this->getValue($employee, ['NUM_MATRICULA', 'num_matricula']);
        $employeeNome = $this->getValue($employee, ['NOM_FUNCIONARIO', 'nom_funcionario']);

        if ($employeeMatricula === '' || $employeeNome === '') {
            throw new Exception('Funcionário da retirada inválido.');
        }

        if ($employeeMatricula !== $reservaNumMatricula) {
            throw new Exception(
                'A retirada só pode ser registrada pela pessoa da reserva: ' .
                $reservaNumMatricula . ' - ' . $reservaNomFuncionario . '.'
            );
        }

        if ($cracha === '' && $employeeCracha !== '') {
            $cracha = $employeeCracha;
        }

        $retiradaNumMatricula = $employeeMatricula;
        $retiradaNomFuncionario = $employeeNome;

        $alreadyExists = UniformWithdrawalRecord::findByReservationItemAndReservedEmployee(
            $numReserva,
            $codItem,
            $reservaNumMatricula
        );

        if ($alreadyExists) {
            throw new Exception('Essa retirada já foi registrada para este item e matrícula da reserva.');
        }

        $observacaoFinal = $observacao;

        if ($blockReason !== '') {
            $observacaoFinal = trim(
                $observacaoFinal .
                "\n\n[REGRA DE REPOSIÇÃO] " .
                $blockReason
            );
        }

        $recordUuid = UniformWithdrawalRecord::createWithdrawal([
            'num_reserva'              => $numReserva,
            'cod_item'                 => $codItem,
            'den_item'                 => $denItem,

            'qtd_reservada'            => $qtdReservada,
            'qtd_atendida'             => $qtdAtendida,
            'qtd_retirada'             => $qtdRetirada,
            'dias'                     => $dias,

            'reserva_num_matricula'    => $reservaNumMatricula,
            'reserva_nom_funcionario'  => $reservaNomFuncionario,

            'cracha'                   => $cracha,
            'retirada_num_matricula'   => $retiradaNumMatricula,
            'retirada_nom_funcionario' => $retiradaNomFuncionario,

            'observacao'               => $observacaoFinal !== '' ? $observacaoFinal : null,

            'created_by'               => $createdBy,
        ]);

        if ($recordUuid) {
            Log::uniformWithdrawalCreated($createdBy, [
                'num_reserva'              => $numReserva,
                'cod_item'                 => $codItem,
                'den_item'                 => $denItem,
                'qtd_reservada'            => $qtdReservada,
                'qtd_atendida'             => $qtdAtendida,
                'qtd_retirada'             => $qtdRetirada,
                'dias'                     => $dias,
                'reserva_num_matricula'    => $reservaNumMatricula,
                'reserva_nom_funcionario'  => $reservaNomFuncionario,
                'cracha'                   => $cracha,
                'retirada_num_matricula'   => $retiradaNumMatricula,
                'retirada_nom_funcionario' => $retiradaNomFuncionario,
                'observacao'               => $observacaoFinal,
                'bloqueado_regra'          => $blockReason !== '' ? 'SIM' : 'NÃO',
                'motivo_bloqueio_regra'    => $blockReason,
            ], $recordUuid);
        }

        return $recordUuid ? true : false;
    }

    public function reverseWithdrawal(string $recordUuid, string $reason, string $createdBy = ''): bool
    {
        $recordUuid = trim($recordUuid);
        $reason = trim($reason);
        $createdBy = trim($createdBy);

        if ($recordUuid === '') {
            throw new Exception('Registro da retirada não informado.');
        }

        if ($reason === '') {
            throw new Exception('Informe o motivo da reversão.');
        }

        $record = UniformWithdrawalRecord::findByUuid($recordUuid);

        if (!$record) {
            throw new Exception('Registro da retirada não encontrado.');
        }

        $data = [
            'num_reserva'              => $this->getValue($record, ['num_reserva', 'NUM_RESERVA']),
            'cod_item'                 => $this->getValue($record, ['cod_item', 'COD_ITEM']),
            'den_item'                 => $this->getValue($record, ['den_item', 'DEN_ITEM']),
            'qtd_reservada'            => $this->getValue($record, ['qtd_reservada', 'QTD_RESERVADA']),
            'qtd_atendida'             => $this->getValue($record, ['qtd_atendida', 'QTD_ATENDIDA']),
            'qtd_retirada'             => $this->getValue($record, ['qtd_retirada', 'QTD_RETIRADA']),
            'dias'                     => $this->getValue($record, ['dias', 'DIAS']),
            'reserva_num_matricula'    => $this->getValue($record, ['reserva_num_matricula', 'RESERVA_NUM_MATRICULA']),
            'reserva_nom_funcionario'  => $this->getValue($record, ['reserva_nom_funcionario', 'RESERVA_NOM_FUNCIONARIO']),
            'cracha'                   => $this->getValue($record, ['cracha', 'CRACHA']),
            'retirada_num_matricula'   => $this->getValue($record, ['retirada_num_matricula', 'RETIRADA_NUM_MATRICULA']),
            'retirada_nom_funcionario' => $this->getValue($record, ['retirada_nom_funcionario', 'RETIRADA_NOM_FUNCIONARIO']),
            'observacao'               => $this->getValue($record, ['observacao', 'OBSERVACAO']),
        ];

        $deleted = UniformWithdrawalRecord::deleteByUuid($recordUuid);

        if (!$deleted) {
            throw new Exception('Não foi possível reverter a retirada.');
        }

        Log::uniformWithdrawalReversed(
            $createdBy,
            $data,
            $reason,
            $recordUuid
        );

        return true;
    }

    public function getAuditByReservation(string $numReserva): array
    {
        $numReserva = trim($numReserva);

        if ($numReserva === '') {
            throw new Exception('Informe o número da reserva para consultar a auditoria.');
        }

        $records = UniformWithdrawalRecord::findByReservation($numReserva);
        $logs = Log::getLogsByReservation($numReserva, 500);

        return [
            'records' => $records ?: [],
            'logs'    => $logs ?: [],
        ];
    }

    public function listWithdrawals(string $startDate = '', string $endDate = ''): array
    {
        $startDate = trim($startDate);
        $endDate = trim($endDate);

        if ($startDate !== '' && !$this->isValidDate($startDate)) {
            throw new Exception('Data inicial inválida.');
        }

        if ($endDate !== '' && !$this->isValidDate($endDate)) {
            throw new Exception('Data final inválida.');
        }

        if ($startDate !== '' && $endDate !== '' && strtotime($startDate) > strtotime($endDate)) {
            throw new Exception('A data inicial não pode ser maior que a data final.');
        }

        return UniformWithdrawalRecord::findWithdrawalsByDateRange($startDate, $endDate);
    }

    private function findReportRecordForWithdrawal(
        string $numReserva,
        string $codItem,
        string $reservaNumMatricula
    ): object {
        $records = UniformWithdrawalReport::findByReservation($numReserva);

        foreach ($records as $record) {
            $reportCodItem = $this->getValue($record, ['COD_ITEM', 'cod_item']);
            $reportNumMatricula = $this->getValue($record, ['NUM_MATRICULA', 'num_matricula']);

            if (
                trim($reportCodItem) === trim($codItem) &&
                trim($reportNumMatricula) === trim($reservaNumMatricula)
            ) {
                return $record;
            }
        }

        throw new Exception(
            'Não foi possível localizar este item e matrícula no report da reserva. Atualize a consulta e tente novamente.'
        );
    }

    private function getWithdrawalRuleBlockReason(
        string $codItem,
        mixed $dias,
        mixed $qtdRetirada
    ): string {
        $codItem = trim($codItem);

        if ($codItem === '') {
            return '';
        }

        $rule = $this->findWithdrawalRuleByItem($codItem);

        if (!$rule) {
            return '';
        }

        $diasAtual = $this->toNumber($dias);
        $qtdRetiradaAtual = $this->toNumber($qtdRetirada);

        $diasReposicao = $this->toNumber($this->getValue($rule, [
            'DIAS_REPOSICAO',
            'dias_reposicao'
        ]));

        $qtdMaxRetirada = $this->toNumber($this->getValue($rule, [
            'QTD_MAX_RETIRADA',
            'qtd_max_retirada'
        ]));

        if (
            $diasAtual === null ||
            $qtdRetiradaAtual === null ||
            $diasReposicao === null ||
            $qtdMaxRetirada === null
        ) {
            return '';
        }

        $diasMenorQueReposicao = $diasAtual < $diasReposicao;
        $qtdMenorQueMaxima = $qtdRetiradaAtual < $qtdMaxRetirada;

        if ($diasMenorQueReposicao && !$qtdMenorQueMaxima) {
            return
                'Retirada bloqueada. O item ' . $codItem .
                ' possui apenas ' . $this->formatNumberForMessage($diasAtual) .
                ' dia(s) desde a última retirada, mas exige ' .
                $this->formatNumberForMessage($diasReposicao) .
                ' dia(s) para reposição. A quantidade total considerada foi ' .
                $this->formatNumberForMessage($qtdRetiradaAtual) .
                ', e a retirada só é permitida antes desse prazo quando a quantidade total for menor que ' .
                $this->formatNumberForMessage($qtdMaxRetirada) . '.';
        }

        return '';
    }

    private function findWithdrawalRuleByItem(string $codItem): object|bool
    {
        $codItem = trim($codItem);

        if ($codItem === '') {
            return false;
        }

        if (!array_key_exists($codItem, $this->withdrawalRuleCache)) {
            $this->withdrawalRuleCache[$codItem] = UniformWithdrawalReport::findWithdrawalRuleByItem($codItem);
        }

        return $this->withdrawalRuleCache[$codItem];
    }

    private function buildWithdrawalMap(array $withdrawals): array
    {
        $map = [];

        foreach ($withdrawals as $withdrawal) {
            $codItem = $this->getValue($withdrawal, ['cod_item', 'COD_ITEM']);
            $reservaNumMatricula = $this->getValue($withdrawal, [
                'reserva_num_matricula',
                'RESERVA_NUM_MATRICULA'
            ]);

            $key = $this->makeKey($codItem, $reservaNumMatricula);

            $map[$key] = $withdrawal;
        }

        return $map;
    }

    private function makeKey(string $codItem, string $reservaNumMatricula): string
    {
        return trim($codItem) . '|' . trim($reservaNumMatricula);
    }

    private function normalizeNullableValue(mixed $value): mixed
    {
        if ($value === null) {
            return null;
        }

        $value = trim((string) $value);

        if ($value === '') {
            return null;
        }

        return $value;
    }

    private function sumNullableNumbers(mixed $valueA, mixed $valueB): ?string
    {
        $numberA = $this->toNumber($valueA);
        $numberB = $this->toNumber($valueB);

        if ($numberA === null && $numberB === null) {
            return null;
        }

        return (string) (($numberA ?? 0) + ($numberB ?? 0));
    }

    private function toNumber(mixed $value): ?float
    {
        if ($value === null) {
            return null;
        }

        $value = trim((string) $value);

        if ($value === '') {
            return null;
        }

        $value = str_replace(' ', '', $value);

        if (str_contains($value, ',') && str_contains($value, '.')) {
            $value = str_replace('.', '', $value);
            $value = str_replace(',', '.', $value);
        } else {
            $value = str_replace(',', '.', $value);
        }

        return is_numeric($value) ? (float) $value : null;
    }

    private function formatNumberForMessage(float $value): string
    {
        if (floor($value) == $value) {
            return (string) ((int) $value);
        }

        return number_format($value, 3, ',', '.');
    }

    private function getValue(object|array $source, array $keys): string
    {
        foreach ($keys as $key) {
            if (is_object($source) && isset($source->{$key})) {
                return trim((string) $source->{$key});
            }

            if (is_array($source) && isset($source[$key])) {
                return trim((string) $source[$key]);
            }
        }

        return '';
    }

    private function isValidDate(string $date): bool
    {
        $format = 'Y-m-d';

        $dateTime = \DateTime::createFromFormat($format, $date);

        return $dateTime && $dateTime->format($format) === $date;
    }
}