<?php $t = time(); ?>
<!doctype html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $webTitle ?? 'Web Title Default' ?></title>

    <link rel="stylesheet" href="<?= path()->css("/bs5.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/app.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/notification.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/sidebar.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/table-responsive.css?t={$t}") ?>">
    <link rel="stylesheet" href="<?= path()->css("/back-to-message.css?t={$t}") ?>">

    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5/themes.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/regular/style.css" />

    <?= $this->insert('templates/styles', ['styles' => $styles ?? []]) ?>
</head>

<body class="<?= $_ENV['APP_COMPANY'] ?>">

    <div
        class="back-to-redirect-overlay"
        id="backToRedirectOverlay"
        aria-hidden="true"
    >
        <div class="back-to-redirect-modal">
            <div class="back-to-redirect-modal__icon-wrap">
                <div class="back-to-redirect-modal__icon">
                    <i class="ph ph-gear-six"></i>
                </div>
            </div>

            <div class="back-to-redirect-modal__header">
                <h3 id="backToRedirectTitle">Redirecionando...</h3>
                <p id="backToRedirectDescription">
                    Aguarde enquanto concluímos o processo.
                </p>
            </div>

            <div class="back-to-redirect-modal__status" id="backToRedirectStatus">
                <span class="back-to-redirect-modal__status-spinner"></span>
                <span id="backToRedirectStatusText">Preparando redirecionamento...</span>
            </div>

            <div class="back-to-redirect-modal__progress">
                <div class="back-to-redirect-modal__progress-bar" id="backToRedirectProgressBar"></div>
            </div>

            <div class="back-to-redirect-modal__note">
                <strong id="backToRedirectNoteTitle">Aguarde um instante.</strong>
                <p id="backToRedirectNoteText">
                    O redirecionamento será iniciado automaticamente assim que o processo terminar.
                </p>
            </div>

            <div class="back-to-redirect-modal__footer" id="backToRedirectFooter">
                Esta janela será fechada automaticamente após a conclusão.
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <ul class="notificationsToasts"></ul>

        <div class="card mb-4">
            <div class="card-header">
                <div class="name-and-logo">
                    <span class="d-flex align-items-center">
                        <?php if (isset($backTo)) : ?>
                            <a
                                href="<?= $backTo ?>"
                                class="d-flex text-decoration-none text-dark me-3 js-back-to-link"
                                data-back-to-url="<?= $backTo ?>"
                                data-back-to-title="<?= htmlspecialchars((string) ($backToMessageTitle ?? 'Redirecionando...'), ENT_QUOTES, 'UTF-8') ?>"
                                data-back-to-message="<?= htmlspecialchars((string) ($backToMessage ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                                data-back-to-time="<?= (int) ($backToMessageTime ?? 0) ?>"
                                data-back-to-status="<?= htmlspecialchars((string) ($backToMessageStatus ?? 'Preparando redirecionamento...'), ENT_QUOTES, 'UTF-8') ?>"
                                data-back-to-note-title="<?= htmlspecialchars((string) ($backToMessageNoteTitle ?? 'Aguarde um instante.'), ENT_QUOTES, 'UTF-8') ?>"
                                data-back-to-note="<?= htmlspecialchars((string) ($backToMessageNote ?? 'O redirecionamento será iniciado automaticamente assim que o processo terminar.'), ENT_QUOTES, 'UTF-8') ?>"
                                data-back-to-footer="<?= htmlspecialchars((string) ($backToMessageFooter ?? 'Esta janela será fechada automaticamente após a conclusão.'), ENT_QUOTES, 'UTF-8') ?>"
                            >
                                <i class="ph ph-arrow-left"></i>
                            </a>
                        <?php endif; ?>

                        <?= $cardTitle ?? null ?>
                    </span>

                    <img src="<?= path()->images("/gbmx.png"); ?>" alt="Logo Empresa">
                </div>
            </div>

            <div class="card-body">
                <?= $this->section("content"); ?>
            </div>
        </div>

        <?= $this->section("series"); ?>
    </div>

    <?= $this->insert('templates/loading'); ?>

    <script src="<?= path()->js("/bs5.js?t={$t}") ?>"></script>
    <script src="<?= path()->js("/init.js?t={$t}"); ?>"></script>
    <script src="<?= path()->js("/notification.js?t={$t}"); ?>"></script>
    <script src="<?= path()->js("/back-to-message.js?t={$t}") ?>"></script>

    <?= $this->insert('templates/js', ['js' => $js ?? []]) ?>

    <?php enableNotifications(); ?>
    <?php forgetSessions(['old', 'zarkify', 'isWrong']); ?>
</body>

</html>