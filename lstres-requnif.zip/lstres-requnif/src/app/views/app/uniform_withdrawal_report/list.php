<?php

$this->layout("templates/base", [
    "webTitle" => "📦 Relatório de retirada de uniforme",
    "cardTitle" => "📦 Relatório de retirada de uniforme",
    "styles" => [
        path()->css("app/uniform-withdrawal-report.css")
    ],
    "js" => [
        path()->js("app/uniform-withdrawal-report.js")
    ],
    "backToMessageTitle" => "Voltando ao inicio...",
    "backToMessage" => "Os dados desta tela já foram carregados. Aguarde enquanto redirecionamos você para o inicio.",
    "backToMessageTime" => 1200,
    "backToMessageStatus" => "Preparando retorno ao inicio...",
    "backToMessageNoteTitle" => "Aguarde um instante.",
    "backToMessageNote" => "O redirecionamento será realizado automaticamente assim que o processo for concluído.",
    "backToMessageFooter" => "A tela será atualizada automaticamente após a conclusão."
]);

$numReserva = trim((string) ($numReserva ?? ''));
$records = is_array($records ?? null) ? $records : [];
$totalRecords = count($records);

$toNumber = function (mixed $value): ?float {
    if ($value === null) {
        return null;
    }

    $value = trim((string) $value);

    if ($value === '') {
        return null;
    }

    $value = str_replace(' ', '', $value);

    if (str_contains($value, ',') && str_contains($value, '.')) {
        $value = str_replace('.', '', $value);
        $value = str_replace(',', '.', $value);
    } else {
        $value = str_replace(',', '.', $value);
    }

    return is_numeric($value) ? (float) $value : null;
};

$formatNumber = function (mixed $value) use ($toNumber): string {
    $number = $toNumber($value);

    if ($number === null) {
        return '';
    }

    if (floor($number) == $number) {
        return (string) ((int) $number);
    }

    return number_format($number, 3, ',', '.');
};

$sumNumbers = function (mixed $valueA, mixed $valueB) use ($toNumber): string {
    $numberA = $toNumber($valueA);
    $numberB = $toNumber($valueB);

    if ($numberA === null && $numberB === null) {
        return '';
    }

    return (string) (($numberA ?? 0) + ($numberB ?? 0));
};
?>

<div class="uniform-withdrawal-page" id="uniformWithdrawalPage">
    <div class="uniform-withdrawal-banner">
        <div class="uniform-withdrawal-banner__icon">
            <i class="ph ph-package"></i>
        </div>

        <div class="uniform-withdrawal-banner__content">
            <h3>Relatório de retirada de uniforme</h3>
            <p>
                Informe o número da reserva para carregar os itens disponíveis.
                Após o carregamento, utilize o filtro para localizar rapidamente o item, matrícula ou funcionário.
            </p>
        </div>
    </div>

    <div class="uniform-withdrawal-page-actions">
        <a
            href="<?= route('uniform_withdrawal_report.withdrawals') ?>"
            class="btn btn-outline-primary uniform-withdrawal-page-actions__button"
        >
            <i class="ph ph-list-checks me-1"></i>
            Ver retiradas realizadas
        </a>
    </div>

    <form
        method="GET"
        action="<?= route('uniform_withdrawal_report.index') ?>"
        class="uniform-withdrawal-search-form"
        id="uniformWithdrawalSearchForm"
    >
        <label class="uniform-withdrawal-field">
            <span>Número da reserva <strong>*</strong></span>
            <input
                type="text"
                class="form-control"
                id="uniformWithdrawalReservationInput"
                name="num_reserva"
                value="<?= htmlspecialchars($numReserva, ENT_QUOTES, 'UTF-8') ?>"
                placeholder="Digite o número da reserva"
                autocomplete="off"
                required
                autofocus
            >
        </label>

        <button type="submit" class="btn btn-primary uniform-withdrawal-search-form__button">
            Pesquisar <i class="ph ph-magnifying-glass ms-1"></i>
        </button>
    </form>

    <?php if ($numReserva !== ''): ?>
        <div class="uniform-withdrawal-result-header">
            <div>
                <h4>Resultado da reserva <?= htmlspecialchars($numReserva, ENT_QUOTES, 'UTF-8') ?></h4>
                <p>
                    <?php if ($totalRecords > 0): ?>
                        Foram encontrados <strong><?= $totalRecords ?></strong> registro(s).
                    <?php else: ?>
                        Nenhum registro encontrado para a reserva informada.
                    <?php endif; ?>
                </p>
            </div>

            <?php if ($totalRecords > 0): ?>
                <div class="uniform-withdrawal-result-header__filter">
                    <input
                        type="text"
                        class="form-control"
                        id="uniformWithdrawalTableSearch"
                        placeholder="🔍 Filtrar por item, descrição, status, matrícula ou nome..."
                    >
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if ($totalRecords > 0): ?>
        <div class="uniform-withdrawal-table-wrap" id="uniformWithdrawalTableWrap">
            <table class="uniform-withdrawal-table">
                <thead>
                    <tr>
                        <th>RESERVA</th>
                        <th>ITEM</th>
                        <th>DESCRIÇÃO</th>
                        <th>MATRÍCULA RESERVA</th>
                        <th>NOME RESERVA</th>
                        <th>DIAS</th>
                        <th>QTD. RESERVADA</th>
                        <th>STATUS</th>
                        <th>AÇÕES</th>
                    </tr>
                </thead>

                <tbody id="uniformWithdrawalTableBody">
                    <?php foreach ($records as $record): ?>
                        <?php
                            $rawNumReserva = (string) ($record->NUM_RESERVA ?? $record->num_reserva ?? '');
                            $rawCodItem = (string) ($record->COD_ITEM ?? $record->cod_item ?? '');
                            $rawDenItem = (string) ($record->DEN_ITEM ?? $record->den_item ?? '');

                            $rawQtdReservada = (string) ($record->QTD_RESERVADA ?? $record->qtd_reservada ?? '');
                            $rawQtdAtendida = (string) ($record->QTD_ATENDIDA ?? $record->qtd_atendida ?? '');
                            $rawQtdRetirada = (string) ($record->QTD_RETIRADA ?? $record->qtd_retirada ?? '');

                            if (trim($rawQtdRetirada) === '') {
                                $rawQtdRetirada = $sumNumbers($rawQtdReservada, $rawQtdAtendida);
                            }

                            $rawNumMatricula = (string) ($record->NUM_MATRICULA ?? $record->num_matricula ?? '');
                            $rawNomFuncionario = (string) ($record->NOM_FUNCIONARIO ?? $record->nom_funcionario ?? '');
                            $rawDias = (string) ($record->DIAS ?? $record->dias ?? '');

                            $withdrawalRegistered = (bool) ($record->withdrawal_registered ?? false);
                            $withdrawalBlocked = (bool) ($record->withdrawal_blocked ?? $record->WITHDRAWAL_BLOCKED ?? false);
                            $withdrawalBlockReason = (string) ($record->withdrawal_block_reason ?? $record->WITHDRAWAL_BLOCK_REASON ?? '');

                            if ($withdrawalBlocked && trim($withdrawalBlockReason) === '') {
                                $withdrawalBlockReason = 'Retirada bloqueada pela regra de reposição do item.';
                            }

                            $withdrawalCracha = (string) ($record->withdrawal_cracha ?? '');
                            $withdrawalCreatedAt = (string) ($record->withdrawal_created_at ?? '');
                            $withdrawalRecordUuid = (string) ($record->withdrawal_record_uuid ?? $record->WITHDRAWAL_RECORD_UUID ?? '');

                            $qtdReservadaFormatada = $formatNumber($rawQtdReservada);
                            $qtdAtendidaFormatada = $formatNumber($rawQtdAtendida);
                            $qtdRetiradaFormatada = $formatNumber($rawQtdRetirada);

                            $qtdTooltip = 'Qtd. reservada: ' . ($qtdReservadaFormatada !== '' ? $qtdReservadaFormatada : '0') .
                                ' | Qtd. atendida: ' . ($qtdAtendidaFormatada !== '' ? $qtdAtendidaFormatada : '0') .
                                ' | Total considerado: ' . ($qtdRetiradaFormatada !== '' ? $qtdRetiradaFormatada : '0');

                            $numReservaEsc = htmlspecialchars($rawNumReserva, ENT_QUOTES, 'UTF-8');
                            $codItemEsc = htmlspecialchars($rawCodItem, ENT_QUOTES, 'UTF-8');
                            $denItemEsc = htmlspecialchars($rawDenItem, ENT_QUOTES, 'UTF-8');

                            $qtdReservadaEsc = htmlspecialchars($rawQtdReservada, ENT_QUOTES, 'UTF-8');
                            $qtdAtendidaEsc = htmlspecialchars($rawQtdAtendida, ENT_QUOTES, 'UTF-8');
                            $qtdRetiradaEsc = htmlspecialchars($rawQtdRetirada, ENT_QUOTES, 'UTF-8');
                            $qtdRetiradaFormatadaEsc = htmlspecialchars($qtdRetiradaFormatada, ENT_QUOTES, 'UTF-8');
                            $qtdTooltipEsc = htmlspecialchars($qtdTooltip, ENT_QUOTES, 'UTF-8');

                            $numMatriculaEsc = htmlspecialchars($rawNumMatricula, ENT_QUOTES, 'UTF-8');
                            $nomFuncionarioEsc = htmlspecialchars($rawNomFuncionario, ENT_QUOTES, 'UTF-8');
                            $diasEsc = htmlspecialchars($rawDias, ENT_QUOTES, 'UTF-8');

                            $withdrawalCrachaEsc = htmlspecialchars($withdrawalCracha, ENT_QUOTES, 'UTF-8');
                            $withdrawalCreatedAtEsc = htmlspecialchars($withdrawalCreatedAt, ENT_QUOTES, 'UTF-8');
                            $withdrawalRecordUuidEsc = htmlspecialchars($withdrawalRecordUuid, ENT_QUOTES, 'UTF-8');
                            $withdrawalBlockReasonEsc = htmlspecialchars($withdrawalBlockReason, ENT_QUOTES, 'UTF-8');

                            $statusSearch = 'Pendente';

                            if ($withdrawalRegistered) {
                                $statusSearch = 'Retirado';
                            } elseif ($withdrawalBlocked) {
                                $statusSearch = 'Bloqueado ' . $withdrawalBlockReason;
                            }

                            $search = htmlspecialchars(
                                mb_strtolower(
                                    $rawNumReserva . ' ' .
                                    $rawCodItem . ' ' .
                                    $rawDenItem . ' ' .
                                    $rawNumMatricula . ' ' .
                                    $rawNomFuncionario . ' ' .
                                    $rawDias . ' ' .
                                    $rawQtdReservada . ' ' .
                                    $rawQtdAtendida . ' ' .
                                    $rawQtdRetirada . ' ' .
                                    $statusSearch
                                ),
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>

                        <tr
                            data-search="<?= $search ?>"
                            data-num-reserva="<?= $numReservaEsc ?>"
                            data-cod-item="<?= $codItemEsc ?>"
                            data-den-item="<?= $denItemEsc ?>"
                            data-num-matricula="<?= $numMatriculaEsc ?>"
                            data-nom-funcionario="<?= $nomFuncionarioEsc ?>"
                            data-dias="<?= $diasEsc ?>"
                            data-qtd-reservada="<?= $qtdReservadaEsc ?>"
                            data-qtd-atendida="<?= $qtdAtendidaEsc ?>"
                            data-qtd-retirada="<?= $qtdRetiradaEsc ?>"
                            data-qtd-tooltip="<?= $qtdTooltipEsc ?>"
                            data-withdrawal-blocked="<?= $withdrawalBlocked ? '1' : '0' ?>"
                            data-withdrawal-block-reason="<?= $withdrawalBlockReasonEsc ?>"
                        >
                            <td><?= $numReservaEsc ?></td>
                            <td class="uniform-withdrawal-table__strong"><?= $codItemEsc ?></td>
                            <td class="uniform-withdrawal-table__description"><?= $denItemEsc ?></td>
                            <td><?= $numMatriculaEsc ?></td>
                            <td class="uniform-withdrawal-table__name"><?= $nomFuncionarioEsc ?></td>
                            <td><?= $diasEsc !== '' ? $diasEsc : '-' ?></td>

                            <td title="<?= $qtdTooltipEsc ?>">
                                <?= $qtdRetiradaFormatadaEsc !== '' ? $qtdRetiradaFormatadaEsc : '-' ?>
                            </td>

                            <td>
                                <?php if ($withdrawalRegistered): ?>
                                    <span
                                        class="uniform-withdrawal-status uniform-withdrawal-status--success"
                                        title="Crachá: <?= $withdrawalCrachaEsc ?> | Data: <?= $withdrawalCreatedAtEsc ?>"
                                    >
                                        Retirado
                                    </span>
                                <?php elseif ($withdrawalBlocked): ?>
                                    <span
                                        class="uniform-withdrawal-status uniform-withdrawal-status--blocked"
                                        title="<?= $withdrawalBlockReasonEsc ?>"
                                    >
                                        Bloqueado
                                    </span>
                                <?php else: ?>
                                    <span class="uniform-withdrawal-status uniform-withdrawal-status--pending">
                                        Pendente
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if ($withdrawalRegistered): ?>
                                    <div class="uniform-withdrawal-actions">
                                        <button
                                            type="button"
                                            class="uniform-withdrawal-action uniform-withdrawal-action--reverse js-open-reversal"
                                            data-record-uuid="<?= $withdrawalRecordUuidEsc ?>"
                                            data-num-reserva="<?= $numReservaEsc ?>"
                                            data-cod-item="<?= $codItemEsc ?>"
                                            data-den-item="<?= $denItemEsc ?>"
                                            data-num-matricula="<?= $numMatriculaEsc ?>"
                                            data-nom-funcionario="<?= $nomFuncionarioEsc ?>"
                                            data-dias="<?= $diasEsc ?>"
                                            data-qtd-reservada="<?= $qtdReservadaEsc ?>"
                                            data-qtd-atendida="<?= $qtdAtendidaEsc ?>"
                                            data-qtd-retirada="<?= $qtdRetiradaEsc ?>"
                                            data-qtd-tooltip="<?= $qtdTooltipEsc ?>"
                                            title="Reverter retirada"
                                            <?= $withdrawalRecordUuidEsc === '' ? 'disabled' : '' ?>
                                        >
                                            <i class="ph ph-arrow-counter-clockwise"></i>
                                        </button>

                                        <button
                                            type="button"
                                            class="uniform-withdrawal-action uniform-withdrawal-action--audit js-open-audit"
                                            data-num-reserva="<?= $numReservaEsc ?>"
                                            title="Auditoria da reserva"
                                        >
                                            <i class="ph ph-clipboard-text"></i>
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <button
                                        type="button"
                                        class="uniform-withdrawal-action js-open-withdrawal"
                                        data-num-reserva="<?= $numReservaEsc ?>"
                                        data-cod-item="<?= $codItemEsc ?>"
                                        data-den-item="<?= $denItemEsc ?>"
                                        data-num-matricula="<?= $numMatriculaEsc ?>"
                                        data-nom-funcionario="<?= $nomFuncionarioEsc ?>"
                                        data-dias="<?= $diasEsc ?>"
                                        data-qtd-reservada="<?= $qtdReservadaEsc ?>"
                                        data-qtd-atendida="<?= $qtdAtendidaEsc ?>"
                                        data-qtd-retirada="<?= $qtdRetiradaEsc ?>"
                                        data-qtd-tooltip="<?= $qtdTooltipEsc ?>"
                                        data-withdrawal-blocked="<?= $withdrawalBlocked ? '1' : '0' ?>"
                                        data-withdrawal-block-reason="<?= $withdrawalBlockReasonEsc ?>"
                                        title="Registrar retirada"
                                    >
                                        <i class="ph ph-identification-card"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="uniform-withdrawal-empty" id="uniformWithdrawalSearchEmpty" style="display:none;">
            <i class="ph ph-magnifying-glass"></i>
            <p id="uniformWithdrawalSearchEmptyText">
                Nenhum registro encontrado para "<strong></strong>"
            </p>
        </div>
    <?php elseif ($numReserva !== ''): ?>
        <div class="uniform-withdrawal-empty">
            <i class="ph ph-folder-simple-minus"></i>
            <p>Nenhum registro encontrado para a reserva informada.</p>
        </div>
    <?php else: ?>
        <div class="uniform-withdrawal-empty">
            <i class="ph ph-magnifying-glass"></i>
            <p>Digite uma reserva para iniciar a pesquisa.</p>
        </div>
    <?php endif; ?>
</div>

<div class="uniform-withdrawal-backdrop" id="uniformWithdrawalBackdrop"></div>

<dialog id="dialog-uniform-withdrawal" popover>
    <form
        id="uniformWithdrawalForm"
        method="POST"
        action="<?= route('uniform_withdrawal_report.store') ?>"
        data-employee-url="<?= route('uniform_withdrawal_report.employee') ?>"
        data-audit-url="<?= route('uniform_withdrawal_report.audit_data') ?>"
        class="uniform-withdrawal-form-dialog"
    >
        <input type="hidden" name="num_reserva" id="withdrawalNumReservaHidden">
        <input type="hidden" name="cod_item" id="withdrawalCodItemHidden">
        <input type="hidden" name="den_item" id="withdrawalDenItemHidden">
        <input type="hidden" name="dias" id="withdrawalDiasHidden">
        <input type="hidden" name="qtd_reservada" id="withdrawalQtdReservadaHidden">

        <input type="hidden" name="reserva_num_matricula" id="withdrawalReservaNumMatriculaHidden">
        <input type="hidden" name="reserva_nom_funcionario" id="withdrawalReservaNomFuncionarioHidden">

        <input type="hidden" name="retirada_nom_funcionario" id="withdrawalRetiradaNomFuncionarioHidden">

        <div class="uniform-withdrawal-form-dialog__header">
            <div class="uniform-withdrawal-form-dialog__icon">
                <i class="ph ph-identification-card"></i>
            </div>

            <div class="uniform-withdrawal-form-dialog__header-text">
                <h3>Registrar retirada</h3>
                <p>
                    Confira os dados da reserva, informe o crachá ou a matrícula de quem está retirando
                    e preencha a observação quando necessário.
                </p>
            </div>
        </div>

        <div class="uniform-withdrawal-form-dialog__body">
            <div
                class="uniform-withdrawal-rule-warning"
                id="withdrawalRuleWarning"
                style="display:none;"
            >
                <strong>Regra de reposição:</strong>
                <span id="withdrawalRuleWarningText"></span>
            </div>

            <div class="uniform-withdrawal-selected-box">
                <div>
                    <span>Reserva</span>
                    <strong id="withdrawalNumReservaText">-</strong>
                </div>

                <div>
                    <span>Item</span>
                    <strong id="withdrawalCodItemText">-</strong>
                </div>

                <div class="uniform-withdrawal-selected-box__full">
                    <span>Descrição</span>
                    <strong id="withdrawalDenItemText">-</strong>
                </div>

                <div>
                    <span>Matrícula da reserva</span>
                    <strong id="withdrawalReservaNumMatriculaText">-</strong>
                </div>

                <div>
                    <span>Funcionário da reserva</span>
                    <strong id="withdrawalReservaNomFuncionarioText">-</strong>
                </div>

                <div>
                    <span>Dias</span>
                    <strong id="withdrawalDiasText">-</strong>
                </div>

                <div>
                    <span>Qtd. reservada</span>
                    <strong id="withdrawalQtdReservadaText">-</strong>
                </div>
            </div>

            <div class="uniform-withdrawal-reader-box">
                <div class="uniform-withdrawal-reader-box__header">
                    <i class="ph ph-user-check"></i>

                    <div>
                        <strong>Funcionário que está retirando</strong>
                        <p>
                            Informe o crachá ou a matrícula. O nome será preenchido automaticamente.
                        </p>
                    </div>
                </div>

                <div class="uniform-withdrawal-reader-box__grid">
                    <label class="uniform-withdrawal-field">
                        <span>Crachá</span>
                        <input
                            type="text"
                            class="form-control"
                            id="withdrawalCrachaInput"
                            name="cracha"
                            placeholder="Leia ou digite o crachá"
                            autocomplete="off"
                        >
                    </label>

                    <label class="uniform-withdrawal-field">
                        <span>Matrícula</span>
                        <input
                            type="text"
                            class="form-control"
                            id="withdrawalRetiradaNumMatriculaInput"
                            name="retirada_num_matricula"
                            placeholder="Digite a matrícula"
                            autocomplete="off"
                        >
                    </label>

                    <label class="uniform-withdrawal-field uniform-withdrawal-reader-box__full">
                        <span>Nome</span>
                        <input
                            type="text"
                            class="form-control"
                            id="withdrawalRetiradaNomFuncionarioInput"
                            placeholder="Nome será preenchido após a consulta"
                            readonly
                        >
                    </label>
                </div>

                <div class="uniform-withdrawal-reader-box__feedback" id="withdrawalEmployeeFeedback">
                    Digite o crachá ou a matrícula e pressione Enter para consultar.
                </div>
            </div>

            <label class="uniform-withdrawal-field">
                <span>Observações</span>
                <textarea
                    class="form-control uniform-withdrawal-textarea"
                    name="observacao"
                    id="withdrawalObservacaoInput"
                    placeholder="Digite uma observação sobre esta retirada, se necessário"
                ></textarea>
            </label>
        </div>

        <div class="uniform-withdrawal-form-dialog__actions">
            <button type="button" class="btn btn-secondary" id="uniformWithdrawalCancel">
                Cancelar
            </button>

            <button type="submit" class="btn btn-success" id="uniformWithdrawalSubmit">
                Confirmar retirada <i class="ph ph-check ms-1"></i>
            </button>
        </div>
    </form>
</dialog>

<dialog id="dialog-uniform-withdrawal-reversal" popover>
    <form
        id="uniformWithdrawalReversalForm"
        method="POST"
        action="<?= route('uniform_withdrawal_report.reverse') ?>"
        class="uniform-withdrawal-reversal-dialog"
    >
        <input type="hidden" name="record_uuid" id="reversalRecordUuidInput">
        <input type="hidden" name="num_reserva" id="reversalNumReservaInput">

        <div class="uniform-withdrawal-form-dialog__header">
            <div class="uniform-withdrawal-form-dialog__icon uniform-withdrawal-form-dialog__icon--danger">
                <i class="ph ph-arrow-counter-clockwise"></i>
            </div>

            <div class="uniform-withdrawal-form-dialog__header-text">
                <h3>Reverter retirada</h3>
                <p>
                    Confirme se deseja reverter a retirada selecionada. Essa ação ficará registrada na auditoria.
                </p>
            </div>
        </div>

        <div class="uniform-withdrawal-form-dialog__body">
            <div class="uniform-withdrawal-reversal-box">
                <span>Registro selecionado</span>
                <strong id="reversalSelectedText">-</strong>
            </div>

            <label class="uniform-withdrawal-field">
                <span>Motivo da reversão <strong>*</strong></span>
                <textarea
                    class="form-control uniform-withdrawal-textarea"
                    name="reason"
                    id="reversalReasonInput"
                    placeholder="Descreva o motivo da reversão"
                    required
                ></textarea>
            </label>
        </div>

        <div class="uniform-withdrawal-form-dialog__actions">
            <button type="button" class="btn btn-secondary" id="uniformWithdrawalReversalCancel">
                Cancelar
            </button>

            <button type="submit" class="btn btn-danger" id="uniformWithdrawalReversalSubmit">
                Reverter retirada <i class="ph ph-arrow-counter-clockwise ms-1"></i>
            </button>
        </div>
    </form>
</dialog>

<dialog id="dialog-uniform-withdrawal-audit" popover>
    <div class="uniform-withdrawal-audit-dialog">
        <div class="uniform-withdrawal-form-dialog__header">
            <div class="uniform-withdrawal-form-dialog__icon uniform-withdrawal-form-dialog__icon--audit">
                <i class="ph ph-clipboard-text"></i>
            </div>

            <div class="uniform-withdrawal-form-dialog__header-text">
                <h3>Auditoria da reserva</h3>
                <p>Histórico de retirada e reversão filtrado pelo número da reserva.</p>
            </div>
        </div>

        <div class="uniform-withdrawal-audit-dialog__body">
            <div class="uniform-withdrawal-audit-record" id="auditRecordBox">
                Carregando informações da reserva...
            </div>

            <div class="uniform-withdrawal-audit-list" id="auditLogList">
                Carregando auditoria...
            </div>
        </div>

        <div class="uniform-withdrawal-form-dialog__actions">
            <button type="button" class="btn btn-secondary" id="uniformWithdrawalAuditClose">
                Fechar
            </button>
        </div>
    </div>
</dialog>