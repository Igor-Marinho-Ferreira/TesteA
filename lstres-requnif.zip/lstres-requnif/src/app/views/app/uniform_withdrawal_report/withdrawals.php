<?php

$this->layout("templates/base", [
    "webTitle" => "📋 Retiradas realizadas",
    "cardTitle" => "📋 Retiradas realizadas",
    "styles" => [
        path()->css("app/uniform-withdrawal-report.css")
    ],
    "backTo" => route('uniform_withdrawal_report.index'),
    "backToMessageTitle" => "Voltando ao relatório...",
    "backToMessage" => "Aguarde enquanto redirecionamos você para o relatório de retirada de uniforme.",
    "backToMessageTime" => 1200,
    "backToMessageStatus" => "Preparando retorno...",
    "backToMessageNoteTitle" => "Aguarde um instante.",
    "backToMessageNote" => "O redirecionamento será realizado automaticamente.",
    "backToMessageFooter" => "A tela será atualizada automaticamente após a conclusão."
]);

$startDate = trim((string) ($startDate ?? ''));
$endDate = trim((string) ($endDate ?? ''));
$records = is_array($records ?? null) ? $records : [];
$totalRecords = count($records);
$searched = (bool) ($searched ?? false);

$exportParams = [];

if ($startDate !== '') {
    $exportParams['start_date'] = $startDate;
}

if ($endDate !== '') {
    $exportParams['end_date'] = $endDate;
}

$exportUrl = route('uniform_withdrawal_report.withdrawals_export');

if (!empty($exportParams)) {
    $exportUrl .= '?' . http_build_query($exportParams);
}
?>

<div class="uniform-withdrawal-page">
    <div class="uniform-withdrawal-banner">
        <div class="uniform-withdrawal-banner__icon">
            <i class="ph ph-list-checks"></i>
        </div>

        <div class="uniform-withdrawal-banner__content">
            <h3>Retiradas realizadas</h3>
            <p>
                Consulte as retiradas já registradas. Utilize os filtros de data para localizar os registros desejados.
            </p>
        </div>
    </div>

    <form
        method="GET"
        action="<?= route('uniform_withdrawal_report.withdrawals') ?>"
        class="uniform-withdrawal-search-form uniform-withdrawal-withdrawals-filter"
    >
        <label class="uniform-withdrawal-field">
            <span>Data inicial</span>
            <input
                type="date"
                class="form-control"
                name="start_date"
                value="<?= htmlspecialchars($startDate, ENT_QUOTES, 'UTF-8') ?>"
            >
        </label>

        <label class="uniform-withdrawal-field">
            <span>Data final</span>
            <input
                type="date"
                class="form-control"
                name="end_date"
                value="<?= htmlspecialchars($endDate, ENT_QUOTES, 'UTF-8') ?>"
            >
        </label>

        <button type="submit" class="btn btn-primary uniform-withdrawal-search-form__button">
            Filtrar <i class="ph ph-funnel ms-1"></i>
        </button>

        <a
            href="<?= route('uniform_withdrawal_report.withdrawals') ?>"
            class="btn btn-secondary uniform-withdrawal-search-form__button"
        >
            Limpar
        </a>
    </form>

    <div class="uniform-withdrawal-result-header uniform-withdrawal-result-header--withdrawals">
        <div>
            <h4>Resultado das retiradas</h4>
            <p>
                <?php if (!$searched): ?>
                    Informe uma data inicial, uma data final ou ambas para pesquisar.
                <?php elseif ($totalRecords > 0): ?>
                    Foram encontrados <strong><?= $totalRecords ?></strong> registro(s).
                <?php else: ?>
                    Nenhuma retirada encontrada para o filtro informado.
                <?php endif; ?>
            </p>
        </div>

        <div class="uniform-withdrawal-result-header__actions">
            <?php if ($searched && $totalRecords > 0): ?>
                <a
                    href="<?= htmlspecialchars($exportUrl, ENT_QUOTES, 'UTF-8') ?>"
                    class="btn btn-success"
                >
                    <i class="ph ph-file-xls me-1"></i>
                    Exportar Excel
                </a>
            <?php else: ?>
                <button
                    type="button"
                    class="btn btn-success"
                    disabled
                    title="Faça uma pesquisa com resultado para exportar"
                >
                    <i class="ph ph-file-xls me-1"></i>
                    Exportar Excel
                </button>
            <?php endif; ?>

            <a
                href="<?= route('uniform_withdrawal_report.index') ?>"
                class="btn btn-outline-primary"
            >
                <i class="ph ph-arrow-left me-1"></i>
                Voltar ao relatório
            </a>
        </div>
    </div>

    <?php if ($totalRecords > 0): ?>
        <div class="uniform-withdrawal-table-wrap">
            <table class="uniform-withdrawal-table uniform-withdrawal-table--withdrawals">
                <thead>
                    <tr>
                        <th>DATA</th>
                        <th>RESERVA</th>
                        <th>ITEM</th>
                        <th>DESCRIÇÃO</th>
                        <th>MATRÍCULA RESERVA</th>
                        <th>NOME RESERVA</th>
                        <th>RETIRADA POR</th>
                        <th>CRACHÁ</th>
                        <th>REGISTRADO POR</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($records as $record): ?>
                        <?php
                            $createdAt = htmlspecialchars((string) ($record->created_at ?? $record->CREATED_AT ?? ''), ENT_QUOTES, 'UTF-8');
                            $numReserva = htmlspecialchars((string) ($record->num_reserva ?? $record->NUM_RESERVA ?? ''), ENT_QUOTES, 'UTF-8');
                            $codItem = htmlspecialchars((string) ($record->cod_item ?? $record->COD_ITEM ?? ''), ENT_QUOTES, 'UTF-8');
                            $denItem = htmlspecialchars((string) ($record->den_item ?? $record->DEN_ITEM ?? ''), ENT_QUOTES, 'UTF-8');
                            $reservaMatricula = htmlspecialchars((string) ($record->reserva_num_matricula ?? $record->RESERVA_NUM_MATRICULA ?? ''), ENT_QUOTES, 'UTF-8');
                            $reservaNome = htmlspecialchars((string) ($record->reserva_nom_funcionario ?? $record->RESERVA_NOM_FUNCIONARIO ?? ''), ENT_QUOTES, 'UTF-8');
                            $retiradaMatricula = htmlspecialchars((string) ($record->retirada_num_matricula ?? $record->RETIRADA_NUM_MATRICULA ?? ''), ENT_QUOTES, 'UTF-8');
                            $retiradaNome = htmlspecialchars((string) ($record->retirada_nom_funcionario ?? $record->RETIRADA_NOM_FUNCIONARIO ?? ''), ENT_QUOTES, 'UTF-8');
                            $cracha = htmlspecialchars((string) ($record->cracha ?? $record->CRACHA ?? ''), ENT_QUOTES, 'UTF-8');
                            $createdBy = htmlspecialchars((string) ($record->created_by ?? $record->CREATED_BY ?? ''), ENT_QUOTES, 'UTF-8');
                        ?>

                        <tr>
                            <td><?= $createdAt !== '' ? $createdAt : '-' ?></td>
                            <td><?= $numReserva !== '' ? $numReserva : '-' ?></td>
                            <td class="uniform-withdrawal-table__strong">
                                <?= $codItem !== '' ? $codItem : '-' ?>
                            </td>
                            <td class="uniform-withdrawal-table__description">
                                <?= $denItem !== '' ? $denItem : '-' ?>
                            </td>
                            <td><?= $reservaMatricula !== '' ? $reservaMatricula : '-' ?></td>
                            <td class="uniform-withdrawal-table__name">
                                <?= $reservaNome !== '' ? $reservaNome : '-' ?>
                            </td>
                            <td class="uniform-withdrawal-table__name">
                                <?php if ($retiradaMatricula !== '' || $retiradaNome !== ''): ?>
                                    <?= $retiradaMatricula !== '' ? $retiradaMatricula : '-' ?>
                                    -
                                    <?= $retiradaNome !== '' ? $retiradaNome : '-' ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?= $cracha !== '' ? $cracha : '-' ?></td>
                            <td><?= $createdBy !== '' ? $createdBy : '-' ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php elseif ($searched): ?>
        <div class="uniform-withdrawal-empty">
            <i class="ph ph-folder-simple-minus"></i>
            <p>Nenhuma retirada encontrada para o filtro informado.</p>
        </div>
    <?php else: ?>
        <div class="uniform-withdrawal-empty">
            <i class="ph ph-calendar"></i>
            <p>Use os filtros de data para consultar as retiradas realizadas.</p>
        </div>
    <?php endif; ?>
</div>