<?php

namespace src\app\controllers;

use Exception;
use Shuchkin\SimpleXLSXGen;
use src\app\services\UniformWithdrawalReportService;
use src\support\Redirect;
use src\support\View;

class UniformWithdrawalReportController
{
    private UniformWithdrawalReportService $service;

    public function __construct()
    {
        $this->service = new UniformWithdrawalReportService();
    }

    public function index(): View
    {
        $numReserva = trim((string) request()->get('num_reserva'));
        $userKey = $this->getUserKey();

        $records = [];

        if ($numReserva !== '') {
            try {
                $records = $this->service->searchReportByReservation($numReserva, $userKey);
            } catch (Exception $e) {
                notification()->error($e->getMessage());
            }
        }

        return view('app.uniform_withdrawal_report.list', [
            'numReserva' => $numReserva,
            'records'    => $records,
        ]);
    }

    public function store(): Redirect
    {
        $userKey = $this->getUserKey();

        try {
            $data = [
                'num_reserva'              => (string) request()->get('num_reserva'),
                'cod_item'                 => (string) request()->get('cod_item'),

                'reserva_num_matricula'    => (string) request()->get('reserva_num_matricula'),
                'reserva_nom_funcionario'  => (string) request()->get('reserva_nom_funcionario'),

                'cracha'                   => (string) request()->get('cracha'),
                'retirada_num_matricula'   => (string) request()->get('retirada_num_matricula'),
                'retirada_nom_funcionario' => (string) request()->get('retirada_nom_funcionario'),

                'observacao'               => (string) request()->get('observacao'),

                'created_by'               => $userKey,
            ];

            $this->service->storeWithdrawal($data);

            notification()->success('Retirada registrada com sucesso.');
        } catch (Exception $e) {
            notification()->error($e->getMessage());
        }

        return redirect()->back();
    }

    public function reverse(): Redirect
    {
        $userKey = $this->getUserKey();

        try {
            $recordUuid = trim((string) request()->get('record_uuid'));
            $reason = trim((string) request()->get('reason'));

            $this->service->reverseWithdrawal($recordUuid, $reason, $userKey);

            notification()->success('Retirada revertida com sucesso.');
        } catch (Exception $e) {
            notification()->error($e->getMessage());
        }

        return redirect()->back();
    }

    public function auditData(): void
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $numReserva = trim((string) request()->get('num_reserva'));

            $audit = $this->service->getAuditByReservation($numReserva);

            echo json_encode([
                'success' => true,
                'data' => [
                    'num_reserva' => $numReserva,
                    'records'     => $audit['records'] ?? [],
                    'logs'        => $audit['logs'] ?? [],
                ],
            ], JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage(),
            ], JSON_UNESCAPED_UNICODE);
        }

        exit;
    }

    public function employee(): void
    {
        header('Content-Type: application/json; charset=utf-8');

        $userKey = $this->getUserKey();

        try {
            $type = trim((string) request()->get('type'));
            $value = trim((string) request()->get('value'));

            $employee = $this->service->findEmployee($type, $value, $userKey);

            echo json_encode([
                'success' => true,
                'data' => [
                    'cracha'          => $employee->CRACHA ?? $employee->cracha ?? '',
                    'num_matricula'   => $employee->NUM_MATRICULA ?? $employee->num_matricula ?? '',
                    'nom_funcionario' => $employee->NOM_FUNCIONARIO ?? $employee->nom_funcionario ?? '',
                ],
            ], JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage(),
            ], JSON_UNESCAPED_UNICODE);
        }

        exit;
    }

    public function withdrawals(): View
    {
        $startDate = trim((string) request()->get('start_date'));
        $endDate = trim((string) request()->get('end_date'));

        $records = [];
        $searched = false;

        if ($startDate !== '' || $endDate !== '') {
            $searched = true;

            try {
                $records = $this->service->listWithdrawals($startDate, $endDate);
            } catch (Exception $e) {
                notification()->error($e->getMessage());
            }
        }

        return view('app.uniform_withdrawal_report.withdrawals', [
            'startDate' => $startDate,
            'endDate'   => $endDate,
            'records'   => $records,
            'searched'  => $searched,
        ]);
    }

    public function exportWithdrawals()
    {
        $startDate = trim((string) request()->get('start_date'));
        $endDate = trim((string) request()->get('end_date'));

        if ($startDate === '' && $endDate === '') {
            notification()->warning('Informe uma data inicial, uma data final ou ambas para exportar.');

            return redirect()->route('uniform_withdrawal_report.withdrawals');
        }

        try {
            $records = $this->service->listWithdrawals($startDate, $endDate);

            if (empty($records)) {
                notification()->warning('Nenhuma retirada encontrada para exportar.');

                $url = route('uniform_withdrawal_report.withdrawals');

                $params = [];

                if ($startDate !== '') {
                    $params['start_date'] = $startDate;
                }

                if ($endDate !== '') {
                    $params['end_date'] = $endDate;
                }

                if (!empty($params)) {
                    $url .= '?' . http_build_query($params);
                }

                return redirect()->uri($url);
            }

            $rows = $this->buildWithdrawalsExportRows($records);

            $filename = 'retiradas_realizadas';

            if ($startDate !== '') {
                $filename .= '_de_' . $this->sanitizeFilenameDate($startDate);
            }

            if ($endDate !== '') {
                $filename .= '_ate_' . $this->sanitizeFilenameDate($endDate);
            }

            $filename .= '_' . date('Ymd_His') . '.xlsx';

            if (ob_get_length()) {
                ob_end_clean();
            }

            SimpleXLSXGen::fromArray($rows)->downloadAs($filename);
            exit;
        } catch (Exception $e) {
            notification()->error($e->getMessage());

            $url = route('uniform_withdrawal_report.withdrawals');

            $params = [];

            if ($startDate !== '') {
                $params['start_date'] = $startDate;
            }

            if ($endDate !== '') {
                $params['end_date'] = $endDate;
            }

            if (!empty($params)) {
                $url .= '?' . http_build_query($params);
            }

            return redirect()->uri($url);
        }
    }

    private function buildWithdrawalsExportRows(array $records): array
    {
        $rows = [];

        $rows[] = [
            'DATA',
            'RESERVA',
            'ITEM',
            'DESCRIÇÃO',
            'QTD. RESERVADA',
            'QTD. ATENDIDA',
            'QTD. RETIRADA',
            'DIAS',
            'MATRÍCULA RESERVA',
            'NOME RESERVA',
            'MATRÍCULA RETIRADA',
            'NOME RETIRADA',
            'CRACHÁ',
            'OBSERVAÇÃO',
            'REGISTRADO POR',
        ];

        foreach ($records as $record) {
            $rows[] = [
                $this->getRecordValue($record, ['created_at', 'CREATED_AT']),
                $this->getRecordValue($record, ['num_reserva', 'NUM_RESERVA']),
                $this->getRecordValue($record, ['cod_item', 'COD_ITEM']),
                $this->getRecordValue($record, ['den_item', 'DEN_ITEM']),
                $this->getRecordValue($record, ['qtd_reservada', 'QTD_RESERVADA']),
                $this->getRecordValue($record, ['qtd_atendida', 'QTD_ATENDIDA']),
                $this->getRecordValue($record, ['qtd_retirada', 'QTD_RETIRADA']),
                $this->getRecordValue($record, ['dias', 'DIAS']),
                $this->getRecordValue($record, ['reserva_num_matricula', 'RESERVA_NUM_MATRICULA']),
                $this->getRecordValue($record, ['reserva_nom_funcionario', 'RESERVA_NOM_FUNCIONARIO']),
                $this->getRecordValue($record, ['retirada_num_matricula', 'RETIRADA_NUM_MATRICULA']),
                $this->getRecordValue($record, ['retirada_nom_funcionario', 'RETIRADA_NOM_FUNCIONARIO']),
                $this->getRecordValue($record, ['cracha', 'CRACHA']),
                $this->getRecordValue($record, ['observacao', 'OBSERVACAO']),
                $this->getRecordValue($record, ['created_by', 'CREATED_BY']),
            ];
        }

        return $rows;
    }

    private function getRecordValue(object|array $record, array $keys): string
    {
        foreach ($keys as $key) {
            if (is_object($record) && isset($record->{$key})) {
                return trim((string) $record->{$key});
            }

            if (is_array($record) && isset($record[$key])) {
                return trim((string) $record[$key]);
            }
        }

        return '';
    }

    private function sanitizeFilenameDate(string $date): string
    {
        return preg_replace('/[^0-9]/', '', $date) ?: date('Ymd');
    }

    private function getUserKey(): string
    {
        return (string) (user()->matricula ?? user()->user_key ?? user()->key ?? '');
    }
}