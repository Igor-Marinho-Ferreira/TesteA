<?php

namespace src\routes;

use src\core\Route;
use src\app\controllers\UniformWithdrawalReportController;

Route::get('/uniform-withdrawal-report', UniformWithdrawalReportController::class, 'index')
    ->name('uniform_withdrawal_report.index');

Route::post('/uniform-withdrawal-report/store', UniformWithdrawalReportController::class, 'store')
    ->name('uniform_withdrawal_report.store');

Route::get('/uniform-withdrawal-report/employee', UniformWithdrawalReportController::class, 'employee')
    ->name('uniform_withdrawal_report.employee');

Route::post('/uniform-withdrawal-report/reverse', UniformWithdrawalReportController::class, 'reverse')
    ->name('uniform_withdrawal_report.reverse');

Route::get('/uniform-withdrawal-report/audit-data', UniformWithdrawalReportController::class, 'auditData')
    ->name('uniform_withdrawal_report.audit_data');

Route::get('/uniform-withdrawal-report/withdrawals', UniformWithdrawalReportController::class, 'withdrawals')
    ->name('uniform_withdrawal_report.withdrawals');

Route::get('/uniform-withdrawal-report/withdrawals/export', UniformWithdrawalReportController::class, 'exportWithdrawals')
    ->name('uniform_withdrawal_report.withdrawals_export');