<?php

namespace src\exceptions\app;

use Exception;
use src\traits\LogException;

class DuplicateExpenseAccountException extends Exception
{
    private string $entity = 'app';

    use LogException;

    function __construct(array $content = [])
    {
        $message = 'Conta despesa fornecida já está em uso';
        $code = 500;

        $this->log($message, $code, json_encode($content));
        parent::__construct($message, $code);
    }
}
