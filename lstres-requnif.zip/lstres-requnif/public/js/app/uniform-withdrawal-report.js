document.addEventListener('DOMContentLoaded', () => {
  const page = document.getElementById('uniformWithdrawalPage');
  const backdrop = document.getElementById('uniformWithdrawalBackdrop');

  const tableSearch = document.getElementById('uniformWithdrawalTableSearch');
  const tableBody = document.getElementById('uniformWithdrawalTableBody');
  const tableWrap = document.getElementById('uniformWithdrawalTableWrap');
  const searchEmptyState = document.getElementById('uniformWithdrawalSearchEmpty');
  const searchEmptyText = document.getElementById('uniformWithdrawalSearchEmptyText');

  const dialog = document.getElementById('dialog-uniform-withdrawal');
  const form = document.getElementById('uniformWithdrawalForm');
  const cancelButton = document.getElementById('uniformWithdrawalCancel');
  const submitButton = document.getElementById('uniformWithdrawalSubmit');

  const reversalDialog = document.getElementById('dialog-uniform-withdrawal-reversal');
  const reversalForm = document.getElementById('uniformWithdrawalReversalForm');
  const reversalCancelButton = document.getElementById('uniformWithdrawalReversalCancel');
  const reversalSubmitButton = document.getElementById('uniformWithdrawalReversalSubmit');

  const reversalRecordUuidInput = document.getElementById('reversalRecordUuidInput');
  const reversalNumReservaInput = document.getElementById('reversalNumReservaInput');
  const reversalReasonInput = document.getElementById('reversalReasonInput');
  const reversalSelectedText = document.getElementById('reversalSelectedText');

  const auditDialog = document.getElementById('dialog-uniform-withdrawal-audit');
  const auditCloseButton = document.getElementById('uniformWithdrawalAuditClose');
  const auditRecordBox = document.getElementById('auditRecordBox');
  const auditLogList = document.getElementById('auditLogList');

  const employeeUrl = form?.dataset.employeeUrl || '';
  const auditUrl = form?.dataset.auditUrl || '';

  const numReservaHidden = document.getElementById('withdrawalNumReservaHidden');
  const codItemHidden = document.getElementById('withdrawalCodItemHidden');
  const denItemHidden = document.getElementById('withdrawalDenItemHidden');
  const diasHidden = document.getElementById('withdrawalDiasHidden');
  const qtdReservadaHidden = document.getElementById('withdrawalQtdReservadaHidden');

  const reservaNumMatriculaHidden = document.getElementById('withdrawalReservaNumMatriculaHidden');
  const reservaNomFuncionarioHidden = document.getElementById('withdrawalReservaNomFuncionarioHidden');
  const retiradaNomFuncionarioHidden = document.getElementById('withdrawalRetiradaNomFuncionarioHidden');

  const numReservaText = document.getElementById('withdrawalNumReservaText');
  const codItemText = document.getElementById('withdrawalCodItemText');
  const denItemText = document.getElementById('withdrawalDenItemText');
  const reservaNumMatriculaText = document.getElementById('withdrawalReservaNumMatriculaText');
  const reservaNomFuncionarioText = document.getElementById('withdrawalReservaNomFuncionarioText');
  const diasText = document.getElementById('withdrawalDiasText');
  const qtdReservadaText = document.getElementById('withdrawalQtdReservadaText');

  const ruleWarning = document.getElementById('withdrawalRuleWarning');
  const ruleWarningText = document.getElementById('withdrawalRuleWarningText');
  const observacaoInput = document.getElementById('withdrawalObservacaoInput');

  const crachaInput = document.getElementById('withdrawalCrachaInput');
  const retiradaNumMatriculaInput = document.getElementById('withdrawalRetiradaNumMatriculaInput');
  const retiradaNomFuncionarioInput = document.getElementById('withdrawalRetiradaNomFuncionarioInput');
  const employeeFeedback = document.getElementById('withdrawalEmployeeFeedback');

  let lastEmployeeQuery = '';
  let isSearchingEmployee = false;

  let currentWithdrawalBlocked = false;
  let currentWithdrawalBlockReason = '';

  function getRows() {
    if (!tableBody) {
      return [];
    }

    return Array.from(tableBody.querySelectorAll('tr'));
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function updateSearchEmptyMessage(term) {
    if (!searchEmptyText) {
      return;
    }

    if (!term) {
      searchEmptyText.innerHTML = 'Nenhum registro encontrado.';
      return;
    }

    searchEmptyText.innerHTML = `Nenhum registro encontrado para "<strong>${escapeHtml(term)}</strong>"`;
  }

  function filterRows() {
    const term = String(tableSearch?.value || '').trim().toLowerCase();
    const rows = getRows();
    let visibleCount = 0;

    rows.forEach((row) => {
      const content = String(row.dataset.search || row.textContent || '').toLowerCase();
      const matches = term === '' || content.includes(term);

      row.classList.toggle('hidden', !matches);

      if (matches) {
        visibleCount += 1;
      }
    });

    const hasRows = rows.length > 0;
    const hasSearch = term !== '';
    const hasVisibleRows = visibleCount > 0;

    if (tableWrap) {
      tableWrap.style.display = hasRows && hasVisibleRows ? 'block' : 'none';
    }

    if (searchEmptyState) {
      searchEmptyState.style.display = hasSearch && !hasVisibleRows ? 'flex' : 'none';
    }

    updateSearchEmptyMessage(term);
  }

  function hasOpenDialog() {
    return (dialog && dialog.matches(':popover-open')) ||
      (reversalDialog && reversalDialog.matches(':popover-open')) ||
      (auditDialog && auditDialog.matches(':popover-open'));
  }

  function syncModalState() {
    const isOpen = hasOpenDialog();

    if (page) {
      page.classList.toggle('is-blurred', isOpen);
    }

    if (backdrop) {
      backdrop.classList.toggle('is-visible', isOpen);
    }
  }

  function hidePopoverWithCloseClass(targetDialog = dialog) {
    if (!targetDialog || typeof targetDialog.hidePopover !== 'function') {
      return;
    }

    if (!targetDialog.matches(':popover-open')) {
      return;
    }

    targetDialog.classList.add('closing');

    setTimeout(() => {
      targetDialog.hidePopover();
      targetDialog.classList.remove('closing');
      syncModalState();
    }, 180);
  }

  function setFeedback(message, type = '') {
    if (!employeeFeedback) {
      return;
    }

    employeeFeedback.textContent = message || '';

    employeeFeedback.classList.remove(
      'uniform-withdrawal-reader-box__feedback--success',
      'uniform-withdrawal-reader-box__feedback--error',
      'uniform-withdrawal-reader-box__feedback--loading'
    );

    if (type) {
      employeeFeedback.classList.add(`uniform-withdrawal-reader-box__feedback--${type}`);
    }
  }

  function setLoadingState(isLoading) {
    if (!form || !submitButton) {
      return;
    }

    form.classList.toggle('is-submitting', isLoading);

    if (cancelButton) {
      cancelButton.disabled = isLoading;
    }

    if (crachaInput) {
      crachaInput.readOnly = isLoading;
    }

    if (retiradaNumMatriculaInput) {
      retiradaNumMatriculaInput.readOnly = isLoading;
    }

    if (observacaoInput) {
      observacaoInput.readOnly = isLoading;
    }

    submitButton.disabled = isLoading;

    if (isLoading) {
      submitButton.innerHTML = 'Registrando <i class="ph ph-circle-notch uniform-withdrawal-loading-icon ms-1"></i>';
      return;
    }

    submitButton.innerHTML = 'Confirmar retirada <i class="ph ph-check ms-1"></i>';
  }

  function setReversalLoadingState(isLoading) {
    if (!reversalForm || !reversalSubmitButton) {
      return;
    }

    reversalForm.classList.toggle('is-submitting', isLoading);

    if (reversalCancelButton) {
      reversalCancelButton.disabled = isLoading;
    }

    if (reversalReasonInput) {
      reversalReasonInput.readOnly = isLoading;
    }

    reversalSubmitButton.disabled = isLoading;

    if (isLoading) {
      reversalSubmitButton.innerHTML = 'Revertendo <i class="ph ph-circle-notch uniform-withdrawal-loading-icon ms-1"></i>';
      return;
    }

    reversalSubmitButton.innerHTML = 'Reverter retirada <i class="ph ph-arrow-counter-clockwise ms-1"></i>';
  }

  function setEmployeeSearchState(isLoading) {
    isSearchingEmployee = isLoading;

    if (crachaInput) {
      crachaInput.classList.toggle('is-loading', isLoading);
    }

    if (retiradaNumMatriculaInput) {
      retiradaNumMatriculaInput.classList.toggle('is-loading', isLoading);
    }

    if (isLoading) {
      setFeedback('Consultando funcionário...', 'loading');
    }
  }

  function clearWithdrawalEmployee() {
    if (retiradaNomFuncionarioInput) {
      retiradaNomFuncionarioInput.value = '';
    }

    if (retiradaNomFuncionarioHidden) {
      retiradaNomFuncionarioHidden.value = '';
    }
  }

  function resetWithdrawalModal() {
    currentWithdrawalBlocked = false;
    currentWithdrawalBlockReason = '';

    if (numReservaHidden) numReservaHidden.value = '';
    if (codItemHidden) codItemHidden.value = '';
    if (denItemHidden) denItemHidden.value = '';
    if (diasHidden) diasHidden.value = '';
    if (qtdReservadaHidden) qtdReservadaHidden.value = '';

    if (reservaNumMatriculaHidden) reservaNumMatriculaHidden.value = '';
    if (reservaNomFuncionarioHidden) reservaNomFuncionarioHidden.value = '';
    if (retiradaNomFuncionarioHidden) retiradaNomFuncionarioHidden.value = '';

    if (numReservaText) numReservaText.textContent = '-';
    if (codItemText) codItemText.textContent = '-';
    if (denItemText) denItemText.textContent = '-';
    if (reservaNumMatriculaText) reservaNumMatriculaText.textContent = '-';
    if (reservaNomFuncionarioText) reservaNomFuncionarioText.textContent = '-';
    if (diasText) diasText.textContent = '-';

    if (qtdReservadaText) {
      qtdReservadaText.textContent = '-';
      qtdReservadaText.title = '';
    }

    if (ruleWarning) {
      ruleWarning.style.display = 'none';
    }

    if (ruleWarningText) {
      ruleWarningText.textContent = '';
    }

    if (observacaoInput) {
      observacaoInput.value = '';
      observacaoInput.readOnly = false;
      observacaoInput.required = false;
      observacaoInput.placeholder = 'Digite uma observação sobre esta retirada, se necessário';
    }

    if (crachaInput) crachaInput.value = '';
    if (retiradaNumMatriculaInput) retiradaNumMatriculaInput.value = '';
    if (retiradaNomFuncionarioInput) retiradaNomFuncionarioInput.value = '';

    lastEmployeeQuery = '';

    setFeedback('Digite o crachá ou a matrícula e pressione Enter para consultar.');
    setLoadingState(false);
    setEmployeeSearchState(false);
  }

  function resetReversalModal() {
    if (reversalRecordUuidInput) reversalRecordUuidInput.value = '';
    if (reversalNumReservaInput) reversalNumReservaInput.value = '';
    if (reversalReasonInput) reversalReasonInput.value = '';

    if (reversalSelectedText) {
      reversalSelectedText.textContent = '-';
    }

    setReversalLoadingState(false);
  }

  function resetAuditModal() {
    if (auditRecordBox) {
      auditRecordBox.innerHTML = 'Carregando informações da reserva...';
    }

    if (auditLogList) {
      auditLogList.innerHTML = 'Carregando auditoria...';
    }
  }

  function openWithdrawalModal(button) {
    if (!button || button.disabled) {
      return;
    }

    resetWithdrawalModal();

    const numReserva = button.getAttribute('data-num-reserva') || '';
    const codItem = button.getAttribute('data-cod-item') || '';
    const denItem = button.getAttribute('data-den-item') || '';
    const reservaNumMatricula = button.getAttribute('data-num-matricula') || '';
    const reservaNomFuncionario = button.getAttribute('data-nom-funcionario') || '';
    const dias = button.getAttribute('data-dias') || '';

    const qtdReservada = button.getAttribute('data-qtd-reservada') || '';
    const qtdAtendida = button.getAttribute('data-qtd-atendida') || '';
    const qtdRetirada = button.getAttribute('data-qtd-retirada') || '';
    const qtdTooltip = button.getAttribute('data-qtd-tooltip') || '';

    const isBlocked = button.getAttribute('data-withdrawal-blocked') === '1';
    const blockReason = button.getAttribute('data-withdrawal-block-reason') || '';

    currentWithdrawalBlocked = isBlocked;
    currentWithdrawalBlockReason = blockReason;

    const qtdConsiderada = qtdRetirada || qtdReservada;

    if (numReservaHidden) numReservaHidden.value = numReserva;
    if (codItemHidden) codItemHidden.value = codItem;
    if (denItemHidden) denItemHidden.value = denItem;
    if (diasHidden) diasHidden.value = dias;

    if (qtdReservadaHidden) {
      qtdReservadaHidden.value = qtdConsiderada;
    }

    if (reservaNumMatriculaHidden) reservaNumMatriculaHidden.value = reservaNumMatricula;
    if (reservaNomFuncionarioHidden) reservaNomFuncionarioHidden.value = reservaNomFuncionario;

    if (numReservaText) numReservaText.textContent = numReserva || '-';
    if (codItemText) codItemText.textContent = codItem || '-';
    if (denItemText) denItemText.textContent = denItem || '-';
    if (reservaNumMatriculaText) reservaNumMatriculaText.textContent = reservaNumMatricula || '-';
    if (reservaNomFuncionarioText) reservaNomFuncionarioText.textContent = reservaNomFuncionario || '-';
    if (diasText) diasText.textContent = dias || '-';

    if (qtdReservadaText) {
      qtdReservadaText.textContent = qtdConsiderada || '-';

      if (qtdTooltip) {
        qtdReservadaText.title = qtdTooltip;
      } else {
        qtdReservadaText.title = `Qtd. reservada: ${qtdReservada || '0'} | Qtd. atendida: ${qtdAtendida || '0'} | Total considerado: ${qtdConsiderada || '0'}`;
      }
    }

    if (observacaoInput) {
      observacaoInput.required = isBlocked;

      if (isBlocked) {
        observacaoInput.placeholder = 'Obrigatório: informe a justificativa para registrar uma retirada bloqueada pela regra.';
      } else {
        observacaoInput.placeholder = 'Digite uma observação sobre esta retirada, se necessário';
      }
    }

    if (isBlocked && blockReason) {
      if (ruleWarning) {
        ruleWarning.style.display = 'block';
      }

      if (ruleWarningText) {
        ruleWarningText.textContent = blockReason;
      }
    }

    if (dialog && typeof dialog.showPopover === 'function') {
      dialog.showPopover();
    }

    setTimeout(() => {
      syncModalState();

      if (isBlocked && observacaoInput) {
        observacaoInput.focus();
        return;
      }

      crachaInput?.focus();
    }, 50);
  }

  function openReversalModal(button) {
    resetReversalModal();

    const recordUuid = button.getAttribute('data-record-uuid') || '';
    const numReserva = button.getAttribute('data-num-reserva') || '';
    const codItem = button.getAttribute('data-cod-item') || '';
    const denItem = button.getAttribute('data-den-item') || '';
    const numMatricula = button.getAttribute('data-num-matricula') || '';
    const nomFuncionario = button.getAttribute('data-nom-funcionario') || '';
    const dias = button.getAttribute('data-dias') || '';

    const qtdReservada = button.getAttribute('data-qtd-reservada') || '';
    const qtdAtendida = button.getAttribute('data-qtd-atendida') || '';
    const qtdRetirada = button.getAttribute('data-qtd-retirada') || '';
    const qtdConsiderada = qtdRetirada || qtdReservada;

    if (reversalRecordUuidInput) reversalRecordUuidInput.value = recordUuid;
    if (reversalNumReservaInput) reversalNumReservaInput.value = numReserva;

    if (reversalSelectedText) {
      reversalSelectedText.textContent =
        `Reserva ${numReserva || '-'} | Item ${codItem || '-'} | ${denItem || '-'} | Dias ${dias || '-'} | ` +
        `Qtd. reservada ${qtdReservada || '-'} | Qtd. atendida ${qtdAtendida || '-'} | ` +
        `Total considerado ${qtdConsiderada || '-'} | ${numMatricula || '-'} - ${nomFuncionario || '-'}`;
    }

    if (reversalDialog && typeof reversalDialog.showPopover === 'function') {
      reversalDialog.showPopover();
    }

    setTimeout(() => {
      syncModalState();
      reversalReasonInput?.focus();
    }, 50);
  }

  function buildEmployeeSearchUrl(type, value) {
    const url = employeeUrl || '/uniform-withdrawal-report/employee';
    const separator = url.includes('?') ? '&' : '?';

    return `${url}${separator}type=${encodeURIComponent(type)}&value=${encodeURIComponent(value)}`;
  }

  function buildAuditUrl(numReserva) {
    const url = auditUrl || '/uniform-withdrawal-report/audit-data';
    const separator = url.includes('?') ? '&' : '?';

    return `${url}${separator}num_reserva=${encodeURIComponent(numReserva)}`;
  }

  async function findEmployeeByIdentifier(identifier, type) {
    const value = String(identifier || '').trim();

    if (!value || isSearchingEmployee) {
      return;
    }

    const queryKey = `${type}:${value}`;

    if (queryKey === lastEmployeeQuery && String(retiradaNomFuncionarioInput?.value || '').trim() !== '') {
      return;
    }

    lastEmployeeQuery = queryKey;
    clearWithdrawalEmployee();
    setEmployeeSearchState(true);

    try {
      const response = await fetch(buildEmployeeSearchUrl(type, value), {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        }
      });

      const result = await response.json();

      if (!result.success) {
        clearWithdrawalEmployee();
        setFeedback(result.message || 'Funcionário não encontrado.', 'error');

        if (type === 'cracha') {
          crachaInput?.focus();
        } else {
          retiradaNumMatriculaInput?.focus();
        }

        return;
      }

      const employee = result.data || {};

      if (crachaInput && employee.cracha) {
        crachaInput.value = employee.cracha;
      }

      if (retiradaNumMatriculaInput) {
        retiradaNumMatriculaInput.value = employee.num_matricula || '';
      }

      if (retiradaNomFuncionarioInput) {
        retiradaNomFuncionarioInput.value = employee.nom_funcionario || '';
      }

      if (retiradaNomFuncionarioHidden) {
        retiradaNomFuncionarioHidden.value = employee.nom_funcionario || '';
      }

      setFeedback('Funcionário encontrado com sucesso.', 'success');
    } catch (error) {
      console.error(error);
      clearWithdrawalEmployee();
      setFeedback('Não foi possível consultar o funcionário.', 'error');
    } finally {
      setEmployeeSearchState(false);
    }
  }

  function renderAuditRecords(numReserva, records) {
    if (!auditRecordBox) {
      return;
    }

    if (!Array.isArray(records) || records.length === 0) {
      auditRecordBox.innerHTML = `
        <div class="uniform-withdrawal-audit-record-title">
          Reserva ${escapeHtml(numReserva || '-')}
        </div>

        <div class="uniform-withdrawal-audit-record-muted">
          Nenhuma retirada ativa encontrada para esta reserva. Verifique o histórico abaixo.
        </div>
      `;
      return;
    }

    const itemsHtml = records.map((record) => {
      return `
        <div class="uniform-withdrawal-audit-record-item">
          <div class="uniform-withdrawal-audit-record-item__title">
            Item ${escapeHtml(record.cod_item || record.COD_ITEM || '-')}
          </div>

          <div class="uniform-withdrawal-audit-grid">
            <div>
              <span>Descrição</span>
              <strong>${escapeHtml(record.den_item || record.DEN_ITEM || '-')}</strong>
            </div>

            <div>
              <span>Dias</span>
              <strong>${escapeHtml(record.dias || record.DIAS || '-')}</strong>
            </div>

            <div>
              <span>Qtd. reservada</span>
              <strong>${escapeHtml(record.qtd_reservada || record.QTD_RESERVADA || '-')}</strong>
            </div>

            <div>
              <span>Qtd. atendida</span>
              <strong>${escapeHtml(record.qtd_atendida || record.QTD_ATENDIDA || '-')}</strong>
            </div>

            <div>
              <span>Total considerado</span>
              <strong>${escapeHtml(record.qtd_retirada || record.QTD_RETIRADA || '-')}</strong>
            </div>

            <div>
              <span>Reserva para</span>
              <strong>
                ${escapeHtml(record.reserva_num_matricula || record.RESERVA_NUM_MATRICULA || '-')}
                -
                ${escapeHtml(record.reserva_nom_funcionario || record.RESERVA_NOM_FUNCIONARIO || '-')}
              </strong>
            </div>

            <div>
              <span>Retirada por</span>
              <strong>
                ${escapeHtml(record.retirada_num_matricula || record.RETIRADA_NUM_MATRICULA || '-')}
                -
                ${escapeHtml(record.retirada_nom_funcionario || record.RETIRADA_NOM_FUNCIONARIO || '-')}
              </strong>
            </div>

            <div>
              <span>Crachá</span>
              <strong>${escapeHtml(record.cracha || record.CRACHA || '-')}</strong>
            </div>

            <div>
              <span>Observações</span>
              <strong>${escapeHtml(record.observacao || record.OBSERVACAO || '-')}</strong>
            </div>

            <div>
              <span>Registrado por</span>
              <strong>${escapeHtml(record.created_by || record.CREATED_BY || '-')}</strong>
            </div>

            <div>
              <span>Data</span>
              <strong>${escapeHtml(record.created_at || record.CREATED_AT || '-')}</strong>
            </div>
          </div>
        </div>
      `;
    }).join('');

    auditRecordBox.innerHTML = `
      <div class="uniform-withdrawal-audit-record-title">
        Reserva ${escapeHtml(numReserva || '-')}
      </div>

      ${itemsHtml}
    `;
  }

  function formatAuditAction(action) {
    const text = String(action || '-').trim();

    const parts = text
      .split('. ')
      .map((part) => part.trim())
      .filter((part) => part !== '');

    if (parts.length === 0) {
      return '<div>-</div>';
    }

    return parts.map((part, index) => {
      const cleanPart = part.endsWith('.') ? part.slice(0, -1) : part;

      if (index === 0) {
        return `
          <div class="uniform-withdrawal-audit-action-title">
            ${escapeHtml(cleanPart)}
          </div>
        `;
      }

      const separatorIndex = cleanPart.indexOf(':');

      if (separatorIndex === -1) {
        return `
          <div class="uniform-withdrawal-audit-action-line">
            ${escapeHtml(cleanPart)}
          </div>
        `;
      }

      const label = cleanPart.slice(0, separatorIndex).trim();
      const value = cleanPart.slice(separatorIndex + 1).trim();

      return `
        <div class="uniform-withdrawal-audit-action-line">
          <span>${escapeHtml(label)}:</span>
          <strong>${escapeHtml(value || '-')}</strong>
        </div>
      `;
    }).join('');
  }

  function getLogDateValue(log) {
    const date = log.created_at || log.CREATED_AT || '';

    const timestamp = Date.parse(String(date).replace(' ', 'T'));

    return Number.isNaN(timestamp) ? 0 : timestamp;
  }

  function sortAuditLogsByNewest(logs) {
    if (!Array.isArray(logs)) {
      return [];
    }

    return [...logs].sort((a, b) => getLogDateValue(b) - getLogDateValue(a));
  }

  function renderAuditLogs(numReserva, logs) {
    if (!auditLogList) {
      return;
    }

    const orderedLogs = sortAuditLogsByNewest(logs);

    const startInfo = `
      <div class="uniform-withdrawal-audit-start">
        <strong>Início do histórico:</strong>
        este histórico começa a partir dos registros salvos na tabela de logs para a reserva
        <strong>${escapeHtml(numReserva || '-')}</strong>.
        A ordenação está do log mais recente para o mais antigo.
      </div>
    `;

    if (!Array.isArray(orderedLogs) || orderedLogs.length === 0) {
      auditLogList.innerHTML = `
        ${startInfo}

        <div class="uniform-withdrawal-audit-item">
          <div class="uniform-withdrawal-audit-item__action">
            Nenhum log encontrado para esta reserva.
          </div>
        </div>
      `;
      return;
    }

    auditLogList.innerHTML = `
      ${startInfo}

      ${orderedLogs.map((log) => {
        const createdAt = log.created_at || log.CREATED_AT || '-';
        const createdBy = log.created_by || log.CREATED_BY || '-';
        const action = log.action || log.ACTION || '-';

        return `
          <div class="uniform-withdrawal-audit-item">
            <div class="uniform-withdrawal-audit-item__top">
              <div>
                <span class="uniform-withdrawal-audit-label">Data</span>
                <strong>${escapeHtml(createdAt)}</strong>
              </div>

              <div>
                <span class="uniform-withdrawal-audit-label">Usuário</span>
                <strong>${escapeHtml(createdBy)}</strong>
              </div>
            </div>

            <div class="uniform-withdrawal-audit-item__action">
              ${formatAuditAction(action)}
            </div>
          </div>
        `;
      }).join('')}
    `;
  }

  async function openAuditModal(button) {
    const numReserva = button.getAttribute('data-num-reserva') || '';

    if (!numReserva) {
      alert('Número da reserva não encontrado para auditoria.');
      return;
    }

    resetAuditModal();

    if (auditDialog && typeof auditDialog.showPopover === 'function') {
      auditDialog.showPopover();
    }

    syncModalState();

    try {
      const response = await fetch(buildAuditUrl(numReserva), {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        }
      });

      const result = await response.json();

      if (!result.success) {
        if (auditRecordBox) {
          auditRecordBox.innerHTML = escapeHtml(result.message || 'Não foi possível carregar a auditoria.');
        }

        if (auditLogList) {
          auditLogList.innerHTML = '';
        }

        return;
      }

      const data = result.data || {};

      renderAuditRecords(data.num_reserva || numReserva, data.records || []);
      renderAuditLogs(data.num_reserva || numReserva, data.logs || []);
    } catch (error) {
      console.error(error);

      if (auditRecordBox) {
        auditRecordBox.innerHTML = 'Não foi possível carregar a auditoria.';
      }

      if (auditLogList) {
        auditLogList.innerHTML = '';
      }
    }
  }

  if (dialog) {
    dialog.addEventListener('toggle', () => {
      setTimeout(syncModalState, 0);
    });
  }

  if (reversalDialog) {
    reversalDialog.addEventListener('toggle', () => {
      setTimeout(syncModalState, 0);
    });
  }

  if (auditDialog) {
    auditDialog.addEventListener('toggle', () => {
      setTimeout(syncModalState, 0);
    });
  }

  if (backdrop) {
    backdrop.addEventListener('click', () => {
      hidePopoverWithCloseClass(dialog);
      hidePopoverWithCloseClass(reversalDialog);
      hidePopoverWithCloseClass(auditDialog);
    });
  }

  if (tableSearch) {
    tableSearch.addEventListener('input', filterRows);
  }

  document.addEventListener('click', (event) => {
    const withdrawalButton = event.target.closest('.js-open-withdrawal');
    const reversalButton = event.target.closest('.js-open-reversal');
    const auditButton = event.target.closest('.js-open-audit');

    if (withdrawalButton) {
      openWithdrawalModal(withdrawalButton);
      return;
    }

    if (reversalButton) {
      openReversalModal(reversalButton);
      return;
    }

    if (auditButton) {
      openAuditModal(auditButton);
    }
  });

  if (cancelButton) {
    cancelButton.addEventListener('click', () => {
      setLoadingState(false);
      hidePopoverWithCloseClass(dialog);
    });
  }

  if (reversalCancelButton) {
    reversalCancelButton.addEventListener('click', () => {
      setReversalLoadingState(false);
      hidePopoverWithCloseClass(reversalDialog);
    });
  }

  if (auditCloseButton) {
    auditCloseButton.addEventListener('click', () => {
      hidePopoverWithCloseClass(auditDialog);
    });
  }

  if (crachaInput) {
    crachaInput.addEventListener('input', () => {
      clearWithdrawalEmployee();
      lastEmployeeQuery = '';
      setFeedback('Pressione Enter para consultar o crachá.');
    });

    crachaInput.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') {
        return;
      }

      event.preventDefault();
      findEmployeeByIdentifier(crachaInput.value, 'cracha');
    });

    crachaInput.addEventListener('blur', () => {
      const value = String(crachaInput.value || '').trim();

      if (value && !retiradaNomFuncionarioInput?.value) {
        findEmployeeByIdentifier(value, 'cracha');
      }
    });
  }

  if (retiradaNumMatriculaInput) {
    retiradaNumMatriculaInput.addEventListener('input', () => {
      clearWithdrawalEmployee();
      lastEmployeeQuery = '';
      setFeedback('Pressione Enter para consultar a matrícula.');
    });

    retiradaNumMatriculaInput.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') {
        return;
      }

      event.preventDefault();
      findEmployeeByIdentifier(retiradaNumMatriculaInput.value, 'matricula');
    });

    retiradaNumMatriculaInput.addEventListener('blur', () => {
      const value = String(retiradaNumMatriculaInput.value || '').trim();

      if (value && !retiradaNomFuncionarioInput?.value) {
        findEmployeeByIdentifier(value, 'matricula');
      }
    });
  }

  if (form) {
    form.addEventListener('submit', (event) => {
      const numReserva = String(numReservaHidden?.value || '').trim();
      const codItem = String(codItemHidden?.value || '').trim();

      const cracha = String(crachaInput?.value || '').trim();
      const retiradaNumMatricula = String(retiradaNumMatriculaInput?.value || '').trim();
      const retiradaNomFuncionario = String(retiradaNomFuncionarioInput?.value || '').trim();
      const observacao = String(observacaoInput?.value || '').trim();

      if (!numReserva || !codItem) {
        event.preventDefault();
        alert('Dados do registro inválidos. Feche a janela e selecione o item novamente.');
        return;
      }

      if (!cracha && !retiradaNumMatricula) {
        event.preventDefault();
        alert('Informe o crachá ou a matrícula antes de confirmar a retirada.');
        crachaInput?.focus();
        return;
      }

      if (!retiradaNumMatricula || !retiradaNomFuncionario) {
        event.preventDefault();
        alert('Consulte um funcionário válido antes de confirmar a retirada.');
        return;
      }

      if (currentWithdrawalBlocked && !observacao) {
        event.preventDefault();
        alert('Este item está bloqueado pela regra de reposição. Informe uma observação para registrar a retirada.');

        if (observacaoInput) {
          observacaoInput.required = true;
          observacaoInput.focus();
        }

        return;
      }

      if (crachaInput) {
        crachaInput.value = cracha;
      }

      if (retiradaNumMatriculaInput) {
        retiradaNumMatriculaInput.value = retiradaNumMatricula;
      }

      if (retiradaNomFuncionarioHidden) {
        retiradaNomFuncionarioHidden.value = retiradaNomFuncionario;
      }

      if (observacaoInput) {
        observacaoInput.value = observacao;
      }

      setLoadingState(true);
    });
  }

  if (reversalForm) {
    reversalForm.addEventListener('submit', (event) => {
      const recordUuid = String(reversalRecordUuidInput?.value || '').trim();
      const reason = String(reversalReasonInput?.value || '').trim();

      if (!recordUuid) {
        event.preventDefault();
        alert('Registro da retirada não encontrado.');
        return;
      }

      if (!reason) {
        event.preventDefault();
        alert('Informe o motivo da reversão.');
        reversalReasonInput?.focus();
        return;
      }

      reversalReasonInput.value = reason;
      setReversalLoadingState(true);
    });
  }

  setLoadingState(false);
  setReversalLoadingState(false);
  syncModalState();
  filterRows();
});