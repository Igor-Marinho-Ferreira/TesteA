document.addEventListener('DOMContentLoaded', () => {
  const backToLinks = document.querySelectorAll('.js-back-to-link');

  const overlay = document.getElementById('backToRedirectOverlay');
  const titleEl = document.getElementById('backToRedirectTitle');
  const descriptionEl = document.getElementById('backToRedirectDescription');
  const statusTextEl = document.getElementById('backToRedirectStatusText');
  const noteTitleEl = document.getElementById('backToRedirectNoteTitle');
  const noteTextEl = document.getElementById('backToRedirectNoteText');
  const footerEl = document.getElementById('backToRedirectFooter');
  const progressBar = document.getElementById('backToRedirectProgressBar');

  if (!backToLinks.length || !overlay) {
    return;
  }

  let redirectTimeout = null;
  let progressAnimationFrame = null;

  function stopProgressAnimation() {
    if (progressAnimationFrame) {
      cancelAnimationFrame(progressAnimationFrame);
      progressAnimationFrame = null;
    }
  }

  function animateProgress(duration) {
    if (!progressBar) {
      return;
    }

    stopProgressAnimation();

    const start = performance.now();

    function step(now) {
      const elapsed = now - start;
      const progress = Math.max(0, 1 - elapsed / duration);

      progressBar.style.transform = `scaleX(${progress})`;

      if (elapsed < duration) {
        progressAnimationFrame = requestAnimationFrame(step);
      }
    }

    progressBar.style.transform = 'scaleX(1)';
    progressAnimationFrame = requestAnimationFrame(step);
  }

  function showRedirectOverlay({
    title,
    message,
    status,
    noteTitle,
    note,
    footer,
    duration
  }) {
    if (titleEl) {
      titleEl.textContent = title || 'Redirecionando...';
    }

    if (descriptionEl) {
      descriptionEl.textContent = message || 'Aguarde enquanto concluímos o processo.';
    }

    if (statusTextEl) {
      statusTextEl.textContent = status || 'Preparando redirecionamento...';
    }

    if (noteTitleEl) {
      noteTitleEl.textContent = noteTitle || 'Aguarde um instante.';
    }

    if (noteTextEl) {
      noteTextEl.textContent = note || 'O redirecionamento será iniciado automaticamente assim que o processo terminar.';
    }

    if (footerEl) {
      footerEl.textContent = footer || 'Esta janela será fechada automaticamente após a conclusão.';
    }

    overlay.classList.add('is-visible');
    overlay.setAttribute('aria-hidden', 'false');

    animateProgress(duration);
  }

  function hideRedirectOverlay() {
    overlay.classList.remove('is-visible');
    overlay.setAttribute('aria-hidden', 'true');
    stopProgressAnimation();

    if (progressBar) {
      progressBar.style.transform = 'scaleX(1)';
    }
  }

  backToLinks.forEach((link) => {
    link.addEventListener('click', (event) => {
      const url = link.dataset.backToUrl || link.getAttribute('href') || '';
      const title = (link.dataset.backToTitle || '').trim();
      const message = (link.dataset.backToMessage || '').trim();
      const status = (link.dataset.backToStatus || '').trim();
      const noteTitle = (link.dataset.backToNoteTitle || '').trim();
      const note = (link.dataset.backToNote || '').trim();
      const footer = (link.dataset.backToFooter || '').trim();
      const duration = Number(link.dataset.backToTime || 0);

      if (!url) {
        return;
      }

      if (!message || !duration || duration <= 0) {
        return;
      }

      event.preventDefault();

      if (redirectTimeout) {
        clearTimeout(redirectTimeout);
      }

      showRedirectOverlay({
        title,
        message,
        status,
        noteTitle,
        note,
        footer,
        duration
      });

      redirectTimeout = setTimeout(() => {
        window.location.href = url;
      }, duration);
    });
  });

  window.addEventListener('pageshow', () => {
    hideRedirectOverlay();
  });
});