/* ============================================================================
 *  industrialForm.js — salva os campos do industrial (pasta, data de entrega,
 *  equipe, setor, natureza, descrição do serviço).
 *
 *  Aditivo: não altera nada de desenvolvimentoProj.js nem de
 *  liberacaoAquisicao.js, que também são carregados nesta tela.
 * ========================================================================== */

(function () {
    "use strict";

    function toast(tipo, mensagem) {
        if (typeof notificationsToast === "function") {
            notificationsToast(tipo, mensagem);
            return;
        }

        console[tipo === "error" ? "error" : "log"](mensagem);
    }

    function mostrarLoading(exibir) {
        if (typeof loading === "function") {
            loading(exibir ? "show" : "hide", true);
        }
    }

    const form = document.getElementById("formCamposIndustrial");

    if (!form) {
        return;
    }

    const aviso = document.getElementById("statusSalvarIndustrial");
    const botao = document.getElementById("btnSalvarIndustrial");

    /* Marca visualmente que há alteração não salva */
    let sujo = false;

    function marcarSujo() {
        sujo = true;

        if (aviso) {
            aviso.textContent = "Alterações não salvas";
            aviso.className = "text-warning fs-8";
        }
    }

    form.querySelectorAll("input").forEach(function (campo) {
        campo.addEventListener("input", marcarSujo);
        campo.addEventListener("change", marcarSujo);
    });

    /* Avisa se sair da página com alteração pendente */
    window.addEventListener("beforeunload", function (evento) {
        if (sujo) {
            evento.preventDefault();
            evento.returnValue = "";
        }
    });

    form.addEventListener("submit", async function (evento) {
        evento.preventDefault();

        const ref = form.dataset.ref;
        const corpo = {};

        form.querySelectorAll("input[name]").forEach(function (campo) {
            corpo[campo.name] = campo.value.trim();
        });

        if (botao) {
            botao.disabled = true;
        }

        mostrarLoading(true);

        try {
            const resposta = await fetch(
                route("dispositivos/industrial/campos/" + ref),
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: JSON.stringify(corpo)
                }
            );

            let dados = {};

            try {
                dados = await resposta.json();
            } catch (e) {
                dados = {};
            }

            if (!resposta.ok || dados.success === false) {
                toast("error", dados.message || "Não foi possível salvar.");
                return;
            }

            sujo = false;

            if (aviso) {
                aviso.textContent = "Salvo";
                aviso.className = "text-success fs-8";
            }

            toast("success", dados.message || "Dados salvos.");
        } catch (erro) {
            console.error("Erro ao salvar campos do industrial:", erro);
            toast("error", "Erro de conexão com o servidor.");
        } finally {
            mostrarLoading(false);

            if (botao) {
                botao.disabled = false;
            }
        }
    });
})();
