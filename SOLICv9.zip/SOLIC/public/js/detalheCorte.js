/* ============================================================================
 *  detalheCorte.js — tela "Dados do Projeto" (controle de corte)
 *
 *  Responsabilidades:
 *    1. Salvar o cabeçalho (status, prioridade, NEST, observações)
 *    2. Grade de planos de corte: adicionar, salvar linha, remover
 * ========================================================================== */

(function () {
    "use strict";

    /* ---------------------------------------------------------------- utils */

    function toast(tipo, mensagem) {
        if (typeof notificationsToast === "function") {
            notificationsToast(tipo, mensagem);
            return;
        }

        console[tipo === "error" ? "error" : "log"](mensagem);
    }

    function mostrarLoading(exibir) {
        if (typeof loading === "function") {
            loading(exibir ? "show" : "hide", true);
        }
    }

    async function postJson(url, corpo) {
        try {
            const resposta = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: JSON.stringify(corpo || {})
            });

            let dados = {};

            try {
                dados = await resposta.json();
            } catch (e) {
                dados = {};
            }

            return { ok: resposta.ok && dados.success !== false, dados: dados };
        } catch (erro) {
            console.error("Falha na requisicao:", erro);
            return { ok: false, dados: { message: "Erro de conexão com o servidor." } };
        }
    }

    const tabela = document.getElementById("tabelaPlanos");
    const codigo = tabela ? tabela.dataset.codigo : null;

    if (!codigo) {
        return;
    }

    /* ------------------------------- 1. cabeçalho ------------------------- */

    function atualizarResumo(resumo) {
        if (!resumo) {
            return;
        }

        const alvoCortados = document.getElementById("resumoCortados");
        const alvoTotal = document.getElementById("resumoTotal");

        if (alvoCortados) {
            alvoCortados.textContent = resumo.cortados;
        }

        if (alvoTotal) {
            alvoTotal.textContent = resumo.total;
        }
    }

    async function salvarControle(silencioso) {
        const statusMarcado = document.querySelector("input[name='status_corte']:checked");
        const nest = document.getElementById("nest");
        const prioridade = document.getElementById("prioridade");
        const observacoes = document.getElementById("observacoes");

        const corpo = {
            status_corte: statusMarcado ? statusMarcado.value : "",
            nest: nest ? nest.value.trim() : "",
            prioridade: prioridade ? prioridade.value : "",
            observacoes: observacoes ? observacoes.value.trim() : ""
        };

        const { ok, dados } = await postJson(
            route("dispositivos/cortes/" + codigo + "/controle"),
            corpo
        );

        if (!ok) {
            toast("error", dados.message || "Não foi possível salvar.");
            return false;
        }

        if (!silencioso) {
            toast("success", dados.message || "Dados salvos.");
        }

        return true;
    }

    const btnSalvarControle = document.getElementById("btnSalvarControle");

    if (btnSalvarControle) {
        btnSalvarControle.addEventListener("click", async function () {
            btnSalvarControle.disabled = true;
            mostrarLoading(true);

            await salvarControle(false);

            mostrarLoading(false);
            btnSalvarControle.disabled = false;
        });
    }

    /* Trocar o status grava na hora — é o gesto principal da tela */
    document.querySelectorAll("input[name='status_corte']").forEach(function (radio) {
        radio.addEventListener("change", async function () {
            mostrarLoading(true);
            const ok = await salvarControle(true);
            mostrarLoading(false);

            if (ok) {
                toast("success", "Status atualizado.");
            }
        });
    });

    /* ------------------------- 2. grade de planos ------------------------- */

    const corpoTabela = document.getElementById("corpoPlanos");

    function lerLinha(linha) {
        const valor = function (campo) {
            const el = linha.querySelector("[data-campo='" + campo + "']");

            if (!el) {
                return "";
            }

            return el.type === "checkbox" ? (el.checked ? "1" : "0") : el.value.trim();
        };

        return {
            id: linha.dataset.id || "",
            n_prog: valor("n_prog"),
            espessura: valor("espessura"),
            largura: valor("largura"),
            comprimento: valor("comprimento"),
            qtde: valor("qtde"),
            tempo: valor("tempo"),
            reserva: valor("reserva"),
            cortado: valor("cortado")
        };
    }

    async function salvarLinha(linha) {
        const corpo = lerLinha(linha);

        if (corpo.n_prog === "") {
            const campo = linha.querySelector("[data-campo='n_prog']");

            if (campo) {
                campo.classList.add("is-invalid");
                campo.focus();
            }

            toast("error", "Informe o N° Prog antes de salvar a linha.");
            return;
        }

        const campoProg = linha.querySelector("[data-campo='n_prog']");

        if (campoProg) {
            campoProg.classList.remove("is-invalid");
        }

        linha.classList.add("linha-salvando");

        const { ok, dados } = await postJson(
            route("dispositivos/cortes/" + codigo + "/plano"),
            corpo
        );

        linha.classList.remove("linha-salvando");

        if (!ok) {
            toast("error", dados.message || "Não foi possível salvar a linha.");
            return;
        }

        // Linha nova passa a ter id — o próximo save vira update
        if (dados.id) {
            linha.dataset.id = dados.id;
        }

        // Verde quando o corte está OK, como no formulário original
        const check = linha.querySelector("[data-campo='cortado']");
        linha.classList.toggle("linha-cortada", !!(check && check.checked));

        atualizarResumo(dados.resumo);
        toast("success", "Linha salva.");
    }

    async function removerLinha(linha) {
        const id = linha.dataset.id || "";

        // Linha ainda não gravada: some sem ir ao servidor
        if (id === "") {
            linha.remove();
            return;
        }

        if (!window.confirm("Remover esta linha do plano de corte?")) {
            return;
        }

        linha.classList.add("linha-salvando");

        const { ok, dados } = await postJson(
            route("dispositivos/cortes/plano/" + id + "/remover"),
            {}
        );

        linha.classList.remove("linha-salvando");

        if (!ok) {
            toast("error", dados.message || "Não foi possível remover.");
            return;
        }

        linha.remove();
        atualizarResumo(dados.resumo);
        toast("success", "Linha removida.");
    }

    /* Delegação: funciona também nas linhas criadas depois */
    document.addEventListener("click", function (evento) {
        if (!evento.target.closest) {
            return;
        }

        const btnSalvar = evento.target.closest(".btn-salvar-plano");

        if (btnSalvar && !btnSalvar.disabled) {
            evento.preventDefault();
            const linha = btnSalvar.closest("tr[data-id], tr");

            if (linha) {
                salvarLinha(linha);
            }

            return;
        }

        const btnRemover = evento.target.closest(".btn-remover-plano");

        if (btnRemover && !btnRemover.disabled) {
            evento.preventDefault();
            const linha = btnRemover.closest("tr");

            if (linha) {
                removerLinha(linha);
            }
        }
    });

    /* Marcar "Corte? OK" grava a linha na hora */
    document.addEventListener("change", function (evento) {
        const alvo = evento.target;

        if (!alvo || !alvo.matches || !alvo.matches("[data-campo='cortado']")) {
            return;
        }

        const linha = alvo.closest("tr");

        if (linha && (linha.dataset.id || "") !== "") {
            salvarLinha(linha);
        } else if (linha) {
            // Linha nova: só pinta; grava quando clicar em Salvar
            linha.classList.toggle("linha-cortada", alvo.checked);
        }
    });

    /* Enter dentro da linha salva */
    document.addEventListener("keydown", function (evento) {
        const alvo = evento.target;

        if (!alvo || !alvo.closest || evento.key !== "Enter") {
            return;
        }

        const linha = alvo.closest("#corpoPlanos tr");

        if (linha) {
            evento.preventDefault();
            salvarLinha(linha);
        }
    });

    /* ------------------------- adicionar linha nova ------------------------ */

    const btnAdicionar = document.getElementById("btnAdicionarPlano");

    if (btnAdicionar && corpoTabela) {
        btnAdicionar.addEventListener("click", function () {
            const modelo = corpoTabela.querySelector("tr");
            let nova;

            if (modelo) {
                // Clona a estrutura da última linha e limpa os valores
                nova = modelo.cloneNode(true);
                nova.dataset.id = "";
                nova.classList.remove("linha-cortada", "linha-salvando");

                nova.querySelectorAll("input, select").forEach(function (campo) {
                    campo.disabled = false;
                    campo.classList.remove("is-invalid");

                    if (campo.type === "checkbox") {
                        campo.checked = false;
                    } else {
                        campo.value = "";
                    }
                });

                nova.querySelectorAll("button").forEach(function (b) {
                    b.disabled = false;
                });
            } else {
                // Grade vazia: recarrega para o servidor montar a primeira linha
                window.location.reload();
                return;
            }

            corpoTabela.appendChild(nova);

            const primeiro = nova.querySelector("[data-campo='n_prog']");

            if (primeiro) {
                primeiro.focus();
            }
        });
    }
})();
