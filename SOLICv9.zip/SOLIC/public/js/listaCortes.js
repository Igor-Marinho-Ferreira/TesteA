/* ============================================================================
 *  listaCortes.js — lista do Controle de Cortes
 *  Mesmo tratamento de carga das outras listas: a tabela só aparece depois
 *  que o DataTables terminou de montar (evita o salto de layout).
 * ========================================================================== */

function marcarTabelaCarregando() {
    const shell = document.querySelector(".dt-loading-shell");

    if (shell) {
        shell.classList.add("dt-loading");
    }

    return shell;
}

function liberarTabelaCarregando(shell) {
    if (shell) {
        shell.classList.remove("dt-loading");
    }
}

const dtShell = marcarTabelaCarregando();

async function initTable() {
    let translate = await fetch(route("/public/js/dt/en.json"));
    translate = await translate.json();

    translate.searchPlaceholder = "EX: DX5064, Z3442 ou SL4790";
    translate.search = "Pesquisar DX, Código Z ou SL: _INPUT_";

    return new DataTable("#listCortes", {
        scrollX: true,
        autoWidth: false,
        pageLength: 15,
        order: [],
        lengthChange: false,
        pagingType: "simple_numbers",
        info: false,
        language: translate,
        columnDefs: [
            { width: "90px", targets: 0 },  // REF (DX)
            { width: "320px", targets: 1 }, // DESCRIÇÃO
            { width: "90px", targets: 2 },  // COD Z
            { width: "90px", targets: 3 },  // N SL
            { width: "120px", targets: 4 }, // PROJETO
            { width: "55px", targets: 5, orderable: false },  // IMG
            { width: "55px", targets: 6, orderable: false },  // DXF
            { width: "100px", targets: 7 }, // NEST
            { width: "110px", targets: 8 }, // PRIORIDADE
            { width: "150px", targets: 9 }, // STATUS CORTE
            { className: "dt-center", targets: "_all" },
            { targets: "_all", defaultContent: "" }
        ]
    });
}

/**
 * Espera a pintura OU um limite — requestAnimationFrame não dispara em aba
 * de segundo plano, e sem o limite a tabela ficaria invisível.
 */
function aguardarPintura(limiteMs) {
    return new Promise((resolve) => {
        let resolvido = false;

        const concluir = () => {
            if (!resolvido) {
                resolvido = true;
                resolve();
            }
        };

        requestAnimationFrame(() => requestAnimationFrame(concluir));
        setTimeout(concluir, limiteMs);
    });
}

initTable()
    .then(async (table) => {
        await aguardarPintura(600);

        if (table && typeof table.columns === "function") {
            table.columns.adjust();
        }
    })
    .catch((erro) => {
        console.error("Erro ao inicializar a tabela:", erro);
    })
    .finally(() => {
        liberarTabelaCarregando(dtShell);
    });

/* Filtro de prioridade */
const selectPrioridade = document.getElementById("prioridade");

if (selectPrioridade) {
    selectPrioridade.addEventListener("change", function () {
        const params = new URLSearchParams(window.location.search);
        params.set("prioridade", selectPrioridade.value);
        window.location.search = params.toString();
    });
}

/* Recalcula larguras ao redimensionar */
let redimensionamentoTimer = null;

window.addEventListener("resize", () => {
    clearTimeout(redimensionamentoTimer);

    redimensionamentoTimer = setTimeout(() => {
        if (window.DataTable && DataTable.tables) {
            DataTable.tables({ visible: true, api: true }).columns.adjust();
        }
    }, 180);
});
