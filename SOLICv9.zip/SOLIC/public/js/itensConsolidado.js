/* ============================================================================
 *  itensConsolidado.js — busca no consolidado de itens comprados por descrição.
 *  Filtra localmente as linhas e esconde os grupos que ficarem vazios.
 * ========================================================================== */

(function () {
    "use strict";

    const campo = document.getElementById("buscaItem");

    if (!campo) {
        return;
    }

    const grupos = Array.from(document.querySelectorAll(".grupo-item"));
    const semResultado = document.getElementById("semResultado");

    function filtrar() {
        const termo = campo.value.trim().toUpperCase();
        let algumVisivel = false;

        grupos.forEach(function (grupo) {
            const linhas = grupo.querySelectorAll(".linha-item");
            let visiveisNoGrupo = 0;

            linhas.forEach(function (linha) {
                const texto = linha.dataset.busca || "";
                const combina = termo === "" || texto.indexOf(termo) !== -1;
                linha.hidden = !combina;

                if (combina) {
                    visiveisNoGrupo++;
                }
            });

            const mostraGrupo = visiveisNoGrupo > 0;
            grupo.hidden = !mostraGrupo;

            if (mostraGrupo) {
                algumVisivel = true;
            }
        });

        if (semResultado) {
            semResultado.classList.toggle("d-none", algumVisivel || termo === "");
        }
    }

    let timer = null;

    campo.addEventListener("input", function () {
        clearTimeout(timer);
        timer = setTimeout(filtrar, 120);
    });
})();
