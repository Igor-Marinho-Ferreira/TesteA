/**
 * Marca a area da tabela como "carregando" de forma SINCRONA, antes de
 * qualquer await. O CSS (.dt-loading-shell.dt-loading) reserva a altura e
 * esconde a tabela com visibility:hidden ate o DataTables terminar de
 * montar, evitando que o layout salte e o usuario clique na linha errada.
 *
 * Se este script nao carregar, a classe nunca e adicionada e a tabela
 * aparece normalmente - a correcao nunca deixa a tela vazia.
 */
function marcarTabelaCarregando() {
    const shell = document.querySelector(".dt-loading-shell");

    if (shell) {
        shell.classList.add("dt-loading");
    }

    return shell;
}

function liberarTabelaCarregando(shell) {
    if (shell) {
        shell.classList.remove("dt-loading");
    }
}

const dtShell = marcarTabelaCarregando();

async function initTable() {
    let translate = await fetch(route('/public/js/dt/en.json'));
    translate = await translate.json();

    translate.searchPlaceholder = "EX: Z1000 ou SL4500";

    translate.search = "Pesquisar Código Z ou SL: _INPUT_";

    let table = new DataTable("#list", {
        scrollX: true,
        autoWidth: false,
        pageLength: 12,
        order: [],
        lengthChange: false,
        pagingType: "simple_numbers",
        info: false,
        language: translate,
        columnDefs: [
            { width: "80px", targets: 0 }, // SL
            { width: "300px", targets: 1 }, // DESCRIÇÃO
            { width: "250px", targets: 2 }, //SOLICITANTE
            { width: "90px", targets: 3 }, //COD Z
            { width: "140px", targets: 4 }, // LOCAL
            { width: "125px", targets: 5 }, // VAGAO LOTE
            { width: "150px", targets: 6 }, // CLASSE
            { width: "150px", targets: 7 }, // PROJETISTA
            { width: "120px", targets: 8 }, // CONCEITO
            { width: "150px", targets: 9 }, // PROJETISTA
            { width: "150px", targets: 10 },// DETALHAMENTO
            { width: "120px", targets: 11 },// LIBERAÇÃO
            { width: "120px", targets: 12 },// AQUISIÇÃO
            { width: "125px", targets: 13 },// CORTE
            { width: "120px", targets: 14 },// EXEC
            { width: "120px", targets: 15 },// TRYOUT
            { className: "dt-center", targets: "_all" },
            { targets: "_all", defaultContent: "" }
        ]
    });
    const searchInput = document.querySelector('.dt-search input');

    if (searchInput) {
        searchInput.setAttribute('title', 'Clique aqui para filtrar os resultados da tabela');
    }

    return table;
}

/**
 * Espera o navegador pintar o layout final (duplo requestAnimationFrame)
 * OU um limite de tempo - o que vier primeiro.
 *
 * O limite existe porque requestAnimationFrame NAO dispara em aba de segundo
 * plano (document.visibilityState === "hidden"). Sem ele, abrir a lista em
 * nova aba deixaria a tabela invisivel ate o usuario focar a aba.
 */
function aguardarPintura(limiteMs) {
    return new Promise((resolve) => {
        let resolvido = false;

        const concluir = () => {
            if (!resolvido) {
                resolvido = true;
                resolve();
            }
        };

        requestAnimationFrame(() => requestAnimationFrame(concluir));
        setTimeout(concluir, limiteMs);
    });
}

initTable()
    .then(async (table) => {
        await aguardarPintura(600);

        if (table && typeof table.columns === "function") {
            table.columns.adjust();
        }
    })
    .catch((error) => {
        console.error("Erro ao inicializar a tabela:", error);
    })
    .finally(() => {
        liberarTabelaCarregando(dtShell);
    });

/* Recalcula as larguras quando a janela muda de tamanho ou gira o aparelho. */
let redimensionamentoTimer = null;

window.addEventListener("resize", () => {
    clearTimeout(redimensionamentoTimer);

    redimensionamentoTimer = setTimeout(() => {
        if (window.DataTable && DataTable.tables) {
            DataTable.tables({ visible: true, api: true }).columns.adjust();
        }
    }, 180);
});

const selectSolicitante = document.getElementById('solicitante');
const selectProjetista = document.getElementById('projetista');

function filtrar() {
    const params = new URLSearchParams(window.location.search);

    params.set('solicitante', selectSolicitante.value);
    params.set('projetista', selectProjetista.value);

    window.location.search = params.toString();
}

selectSolicitante.addEventListener('change', filtrar);
selectProjetista.addEventListener('change', filtrar);


async function openModal(ref, tipo) {
    const modalElement = document.getElementById("myAppModal");
    let url = "";

    if (tipo === 'requisitos') {
        url = route(`dispositivos/solicitacao/requisitos/${ref}`);
    } else if (tipo === 'validacao') {
        url = route(`dispositivos/solicitacao/validacao/${ref}`);
    } else {
        url = route(`dispositivos/solicitacao/${tipo}/${ref}`);
    }

    try {
        const response = await fetch(url);

        if (!response.ok) {
            notificationsToast("error", "O conteúdo da modal não foi encontrado. Tente novamente.");
            return;
        }

        const data = await response.text();

        modalElement.innerHTML = data;
   
        modalElement.showModal();

    } catch (error) {
        console.error("Erro ao carregar modal:", error);
        notificationsToast("error", "Erro de conexão ao carregar os dados.");
    }
}


function closeModal(tipo) {
    const modalElement = document.getElementById("myAppModal");
    modalElement.close();
    if (tipo === 'aprovar') {
        notificationsToast("success", "Validação aprovada.");
    } else if (tipo === 'rejeitar') {
        notificationsToast("error", "Validação rejeitada.");
    }
}