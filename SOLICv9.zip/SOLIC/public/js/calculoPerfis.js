/* ============================================================================
 *  calculoPerfis.js — calculadora de peso dos perfis lineares
 *  Peso(kg) = peso_por_metro(kg/m) × comprimento(m) × quantidade
 *
 *  Além do cálculo avulso, mantém uma LISTA de itens (com o código do item),
 *  acumulando o peso total. Tudo no navegador — não grava no banco.
 * ========================================================================== */

(function () {
    "use strict";

    const painel = document.getElementById("painelPerfil");

    if (!painel) {
        return;
    }

    let perfis = {};

    try {
        perfis = JSON.parse(painel.dataset.perfis || "{}");
    } catch (e) {
        perfis = {};
    }

    const inputCodigo = document.getElementById("perfilCodigo");
    const select = document.getElementById("perfilSelect");
    const inputComp = document.getElementById("perfilComp");
    const inputQtde = document.getElementById("perfilQtde");
    const btnCalcular = document.getElementById("btnCalcularPerfil");
    const btnAdd = document.getElementById("btnAddPerfil");

    const corpo = document.getElementById("corpoPerfis");
    const linhaVazio = document.getElementById("perfilVazio");
    const totalGeralEl = document.getElementById("perfilTotalGeral");

    function numero(valor) {
        const limpo = String(valor).replace(",", ".").replace(/[^0-9.]/g, "");
        const n = parseFloat(limpo);
        return isNaN(n) ? 0 : n;
    }

    function fmt(valor, dec) {
        return Number(valor).toLocaleString("pt-BR", {
            minimumFractionDigits: dec,
            maximumFractionDigits: dec
        });
    }

    function avisar(mensagem) {
        if (typeof notificationsToast === "function") {
            notificationsToast("error", mensagem);
        } else {
            alert(mensagem);
        }
    }

    // Rótulo do perfil sem o sufixo "(x kg/m)" — para a coluna Perfil da lista
    function rotuloPerfil() {
        if (!select || select.selectedIndex < 0) {
            return "";
        }
        const texto = select.options[select.selectedIndex].text || "";
        return texto.split("(")[0].trim();
    }

    function calcularValores() {
        const perfil = perfis[select.value];

        if (!perfil) {
            return null;
        }

        const kgm = perfil.kgm;
        const compMm = numero(inputComp.value);
        const compM = compMm / 1000;
        const qtde = Math.max(1, Math.round(numero(inputQtde.value)));

        const pesoUnit = kgm * compM;
        const pesoTotal = pesoUnit * qtde;

        return { kgm, compMm, compM, qtde, pesoUnit, pesoTotal };
    }

    function calcular() {
        const r = calcularValores();

        if (!r) {
            document.getElementById("perfilKgm").textContent = "—";
            document.getElementById("perfilCompTotal").textContent = "—";
            document.getElementById("perfilPesoUnit").textContent = "—";
            document.getElementById("perfilPesoTotal").textContent = "—";
            return;
        }

        document.getElementById("perfilKgm").textContent = fmt(r.kgm, 3);
        document.getElementById("perfilCompTotal").textContent = fmt(r.compM * r.qtde, 3);
        document.getElementById("perfilPesoUnit").textContent = fmt(r.pesoUnit, 3);
        document.getElementById("perfilPesoTotal").textContent = fmt(r.pesoTotal, 3);
    }

    function recalcularTotal() {
        let total = 0;
        corpo.querySelectorAll("tr[data-peso]").forEach(function (tr) {
            total += parseFloat(tr.dataset.peso) || 0;
        });
        if (totalGeralEl) {
            totalGeralEl.textContent = fmt(total, 3);
        }
    }

    function esc(texto) {
        const div = document.createElement("div");
        div.textContent = texto;
        return div.innerHTML;
    }

    function adicionar() {
        const r = calcularValores();

        if (!r) {
            avisar("Selecione um perfil antes de adicionar.");
            return;
        }

        calcular(); // reflete o resultado avulso também

        const codigo = (inputCodigo.value || "").trim();

        const tr = document.createElement("tr");
        tr.dataset.peso = String(r.pesoTotal);
        tr.innerHTML =
            '<td>' + (codigo ? esc(codigo) : '<span class="text-muted">—</span>') + '</td>' +
            '<td class="text-start">' + esc(rotuloPerfil()) + '</td>' +
            '<td class="text-end">' + fmt(r.compMm, 0) + '</td>' +
            '<td class="text-end">' + r.qtde + '</td>' +
            '<td class="text-end">' + fmt(r.kgm, 3) + '</td>' +
            '<td class="text-end">' + fmt(r.pesoUnit, 3) + '</td>' +
            '<td class="text-end fw-bold text-danger">' + fmt(r.pesoTotal, 3) + '</td>' +
            '<td class="text-center">' +
                '<button type="button" class="btn btn-sm btn-outline-danger btn-remover-plano" title="Remover">&times;</button>' +
            '</td>';

        corpo.appendChild(tr);

        if (linhaVazio) {
            linhaVazio.hidden = true;
        }

        recalcularTotal();

        // Prepara para o próximo item: limpa só o código e volta o foco
        if (inputCodigo) {
            inputCodigo.value = "";
            inputCodigo.focus();
        }
    }

    if (btnCalcular) {
        btnCalcular.addEventListener("click", calcular);
    }

    if (btnAdd) {
        btnAdd.addEventListener("click", adicionar);
    }

    if (select) {
        select.addEventListener("change", calcular);
    }

    // Remoção por delegação
    if (corpo) {
        corpo.addEventListener("click", function (evento) {
            const btn = evento.target.closest(".btn-remover-plano");
            if (!btn) {
                return;
            }
            const tr = btn.closest("tr");
            if (tr) {
                tr.remove();
            }
            if (linhaVazio && corpo.querySelectorAll("tr[data-peso]").length === 0) {
                linhaVazio.hidden = false;
            }
            recalcularTotal();
        });
    }

    [inputCodigo, inputComp, inputQtde].forEach(function (campo) {
        if (campo) {
            campo.addEventListener("keydown", function (evento) {
                if (evento.key === "Enter") {
                    evento.preventDefault();
                    adicionar();
                }
            });
        }
    });
})();
