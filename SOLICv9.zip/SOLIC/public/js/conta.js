const vagao = getElement('selectVagao');
const selectLote = getElement('selectLote'); 

vagao.addEventListener('change', async () => {
    const valueVagao = vagao.value;

    selectLote.removeAttribute('disabled');

    let response;
    try {
        response = await fetch(route(`dispositivos/contas/getLoteByVagao?vagao=${valueVagao}`));

        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.statusText}`);
        }

        let result = await response.json();

        const lotes = result.data;

        if (lotes && Array.isArray(lotes)) {
            selectLote.innerHTML = '<option selected disabled value="">Selecione o lote...</option>';

            lotes.forEach(lote => {
                const option = document.createElement('option');

                option.value = lote.lote;
                option.textContent = lote.lote;

                selectLote.appendChild(option);
            });
        } else {
            console.warn('Resposta sem a propriedade "data" esperada ou não é um array.');
            selectLote.innerHTML = '<option selected disabled value="">Nenhum lote encontrado.</option>';
        }

    } catch (error) {
        console.error('Erro na requisição de lotes:', error);
        selectLote.setAttribute('disabled', 'disabled');
        selectLote.innerHTML = '<option selected disabled value="">Erro ao carregar lotes.</option>';
    }
});

const botaoCancelar = document.getElementById('cancelForm');

const form = document.getElementById('formCadastroConta');

botaoCancelar.addEventListener('click', function (event) {
    event.preventDefault();

    form.reset();
});



/**
 * Carrega o formulário de edição pelo UUID e abre a sidebar.
 *
 * @function openSidebar
 * @example
 * <!-- HTML -->
 * <button onclick="openSidebar('uuid')">
 *
 * @async
 * @param {string} uuid - Identificador único do item.
 * @returns {void}
 */
async function openModal(uuid, action) {
    let response;
    const modalElement = document.getElementById("myAppModal");

    if (action == 'delete') {
        response = await fetch(route(`dispositivos/contas/destroy/${uuid}`));
    } else {
        response = await fetch(route(`dispositivos/contas/edit/${uuid}`));
    }

    if (!response.ok) {
        notificationsToast("error", "O conteúdo da modal não foi encontrado. Tente novamente.");
        return;
    }

    let data = await response.text();

    modalElement.innerHTML = data;

    modalElement.showModal();
    
}


/**
 * Fecha a modal de edição.
 *
 * @returns {void}
 */
function closeModal(tipo) {
    const modalElement = document.getElementById("myAppModal");
    modalElement.close();
  
}

/**
 * Verifica se há parâmetro de exibição na URL e aciona o gatilho correspondente.
 *
 * @returns {void}
 */
function isShowing() {
    if (getQuery().with)
        document.getElementById(`trigger-${getQuery().with}`).click();
}

isShowing();

function confirmDelete() {
    let btnWarning = document.getElementById("btnConfirm");
    let btnDelete = document.getElementById("btnDelete");
    if (btnWarning) btnWarning.classList.remove("d-none");
    if (btnDelete) btnDelete.classList.add("d-none");
}

window.onload = function (e) {
    let loadingWrapper = document.getElementById("loading-wrapper");
    if (loadingWrapper) loadingWrapper.style.display = "none";

    console.log(loadingWrapper);
};

async function initTable() {
    let translate = await fetch(
        route('/public/js/dt/en.json')
    );
    translate = await translate.json();
    let table = new DataTable("#list", {
        pageLength: 12,
        lengthChange: false,
        pagingType: "simple_numbers",
        info: false,
        language: translate,
    });

    document.getElementById("btnActives").addEventListener("click", function () {
        table.column(6).search("^active$", true, false).draw();
    });

    // botão - todos
    document.getElementById("btnAll").addEventListener("click", function () {
        table.column(6).search("").draw();
    });
}

initTable();
