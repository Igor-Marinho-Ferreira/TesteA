
const radiosInput = document.querySelectorAll('.form-check-input');
const inputSafetyWalk = getElement('inputSafetyWalk');
const inputProjeto = getElement('cod_z');
const vagao = getElement('vagao');
const selectLote = getElement('lote');
const solicitante = getElement('solicitante');
const descricaoConta = getElement('descricao_conta');
const selectConta = getElement('conta_select');

const app = new (function () {

    this.containerRequisitos = document.getElementById("requisitoContainer");
    this.containerAnexos = document.getElementById("anexoContainer");

    this.form = document.getElementById("formCadastroSolicitacao");


    this.getNextIndex = (prefix) => {
        let idx = 0;
        while (document.getElementById(`${prefix}-${idx}`)) {
            idx++;
        }
        return idx;
    };

    this.addItemGenerico = (container, htmlItem, addSelector, deleteSelector) => {
        container.insertAdjacentHTML("beforeend", htmlItem);
        this.setEventsInButtonsRepeatAddItem(addSelector);
        this.setEventsInButtonsRepeatDeleteItem(deleteSelector);
    };

    this.addItemRequisito = () => {
        const idx = this.getNextIndex("item");

        const requisitosHTML = `
            <div class="repeat-div mt-3" id="item-${idx}">
                <div class="col-12">
                    <label for="requisito-${idx}" class="form-label fs-7 form-label fs-7-sm">Requisitos</label>
                    <textarea class="form-control form-control-sm" id="requisito-${idx}" rows="3" placeholder="Liste os requisitos" name="requisito[${idx}]" data-idx="${idx}"></textarea>
                </div>
                <div class="d-flex ms-3 gap-1">
                    <button type="button" class="btn btn-transparent text-success btn-requisitos-add p-0">
                        <i class="ph ph-plus"></i>
                    </button>
                    <button type="button" class="btn btn-transparent text-danger btn-requisitos-delete p-0" data-idx="${idx}">
                        <i class="ph ph-minus"></i>
                    </button>
                </div>
            </div>
        `;

        this.addItemGenerico(this.containerRequisitos, requisitosHTML, ".btn-requisitos-add", ".btn-requisitos-delete");
    };

    this.addItemAnexo = () => {
        const idx = this.getNextIndex("anexo-item");

        const anexoHTML = `
            <div class="repeat-anexo-div mt-3" id="anexo-item-${idx}">
                <div class="row g-2 align-items-end">
                    <div class="col-md-4">
                        <label for="anexo-${idx}" class="form-label fs-7">Anexo</label>
                        <input class="form-control form-control-sm" type="file" id="anexo-${idx}" name="anexo[${idx}]">
                    </div>
                    <div class="col-md-8">
                        <label for="anexoDescricao-${idx}" class="form-label fs-7">Descrição</label>
                        <input class="form-control form-control-sm" type="text" id="anexoDescricao-${idx}" name="anexoDescricao[${idx}]">
                    </div>
                    <div class="d-flex ms-3 gap-1">
                        <button type="button" class="btn btn-transparent text-success btn-anexos-add p-0">
                            <i class="ph ph-plus"></i>
                        </button>
                        <button type="button" class="btn btn-transparent text-danger btn-anexos-delete p-0" data-idx="${idx}">
                            <i class="ph ph-minus"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;

        this.addItemGenerico(this.containerAnexos, anexoHTML, ".btn-anexos-add", ".btn-anexos-delete");
    };

    this.getButtonsAddItem = (selector = ".btn-requisitos-add") => {
        return document.querySelectorAll(selector);
    };


    this.setEventsInButtonsRepeatAddItem = (selector = ".btn-requisitos-add") => {
        let buttons = this.getButtonsAddItem(selector);
        for (const button of buttons) {
            if (!button.hasAttribute("data-onclick-set")) {
                button.addEventListener("click", () => {
                    if (selector === ".btn-requisitos-add") {
                        this.addItemRequisito();
                    } else if (selector === ".btn-anexos-add") {
                        this.addItemAnexo();
                    }
                });
                button.setAttribute("data-onclick-set", "true");
            }
        }
    };

    this.deleteItem = (button) => {
        const repeatDiv = button.closest(".repeat-div, .repeat-anexo-div");
        if (!repeatDiv) return;

        const container = repeatDiv.parentElement;
        const totalItems = container.querySelectorAll(".repeat-div, .repeat-anexo-div").length;

        if (totalItems > 1) {
            repeatDiv.remove();
        } else {
            notificationsToast("warning", "Não foi possível remover. Deve haver pelo menos 1 item.");
        }
    };


    this.setEventsInButtonsRepeatDeleteItem = (selector = ".btn-requisitos-delete") => {
        let buttons = document.querySelectorAll(selector);
        for (const button of buttons) {
            if (!button.hasAttribute("data-onclick-set")) {
                button.addEventListener("click", () => {
                    this.deleteItem(button);
                });
                button.setAttribute("data-onclick-set", "true");
            }
        }
    };


    this.setInputMask = () => { };

    this.fire = () => {
        this.setEventsInButtonsRepeatAddItem(".btn-requisitos-add");
        this.setEventsInButtonsRepeatDeleteItem(".btn-requisitos-delete");

        this.setEventsInButtonsRepeatAddItem(".btn-anexos-add");
        this.setEventsInButtonsRepeatDeleteItem(".btn-anexos-delete");

        this.setInputMask();
    };

})();

app.fire();


//SELECIONAR RADIO, SE FOR SAFETY WALK MOSTRA CAMPO ESCONDIDO
radiosInput.forEach(radio => {
    radio.addEventListener("click", () => {
        if (radio.value === 'Notificacao' || radio.value === 'Safety Walk' || radio.value === 'ATA CIPA') {
            inputSafetyWalk.classList.remove('d-none');
            getElement('n_safety_walk').setAttribute('required', 'required');
        } else {
            inputSafetyWalk.classList.add('d-none');
            getElement('n_safety_walk').removeAttribute('required');
        }

        const selectElement = getElement('conta_select');
        const hiddenElement = getElement('conta');


        if (radio.value !== 'Projeto Linha') {
            const contaDespesa = '3231020503';
            selectElement.value = contaDespesa;
            descricaoConta.value = "CONTA DE DESPESAS";

            selectElement.setAttribute('disabled', 'disabled');
            hiddenElement.value = contaDespesa;
        } else {
            selectElement.removeAttribute('disabled');
            hiddenElement.value = '';
        }

    })
});



selectConta.addEventListener('change', async () => {
    const valueConta = selectConta.value;
    if (valueConta === '3231020503') {
        descricaoConta.value = "CONTA DE DESPESAS";
    } else {
        let response;
        try {
            response = await fetch(route(`dispositivos/contas/getDescricaoConta?conta=${valueConta}`));

            if (!response.ok) {
                throw new Error(`Erro na requisição: ${response.statusText}`);
            }

            let result = await response.json();
            const descricao = result.data;
            if (!descricao)
                descricaoConta.value = ''

            descricaoConta.value = descricao;


        } catch (error) {
            console.error('Erro na requisição de descrição de contas:', error);
            selectLote.setAttribute('disabled', 'disabled');
        }
    }
});


//REGRA DO Z
inputProjeto.addEventListener('input', function () {
    let valorAtual = this.value;
    let prefixo = 'Z';

    if (!valorAtual.startsWith(prefixo)) {
        valorAtual = prefixo + valorAtual.replace(prefixo, '');
    }

    let parteNumerica = valorAtual.substring(prefixo.length);
    let parteNumericaLimpa = parteNumerica.replace(/[^0-9]/g, '');

    let valorFinal = prefixo + parteNumericaLimpa;

    if (this.value !== valorFinal) {
        this.value = valorFinal;

        if (this.value.length > 0) {
            this.setSelectionRange(this.value.length, this.value.length);
        }
    }
});




//PEGAR OS LOTES CADASTRADOS PARA O VAGÃO SELECIONADO
vagao.addEventListener('change', async () => {
    const valueVagao = vagao.value;

    selectLote.removeAttribute('disabled');

    let response;
    try {
        response = await fetch(route(`dispositivos/contas/getLoteByVagao?vagao=${valueVagao}`));

        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.statusText}`);
        }

        let result = await response.json();

        const lotes = result.data;

        if (lotes && Array.isArray(lotes)) {
            selectLote.innerHTML = '<option selected disabled value="">Selecione o lote...</option>';

            lotes.forEach(lote => {
                const option = document.createElement('option');

                option.value = lote.lote;
                option.textContent = lote.lote;

                selectLote.appendChild(option);
            });
        } else {
            console.warn('Resposta sem a propriedade');
            selectLote.innerHTML = '<option selected disabled value="">Nenhum lote encontrado.</option>';
        }

    } catch (error) {
        console.error('Erro na requisição de lotes:', error);
        selectLote.setAttribute('disabled', 'disabled');
        selectLote.innerHTML = '<option selected disabled value="">Erro ao carregar lotes.</option>';
    }
});


//REQUISIÇÃO PARA PEGAR INFORMAÇÕES DE PROJETO POR NUMERO DO PROJETO DIGITADO
inputProjeto.addEventListener('blur', async () => {
    const numberProject = inputProjeto.value;

    if (!numberProject || numberProject.length <= 1) {
        setValueById('cod_z', '');
        return;
    }

    try {
        let response = await fetch(route(`dispositivos/solicitacoes/getProjectInfos?projectNumber=${numberProject}`));

        if (response.status === 404) {
            notificationsToast("info", "Projeto inexistente. Digite um número válido.");
            inputProjeto.value = "";
            return;
        }

        if (!response.ok) {
            throw new Error('Erro na requisição');
        }

        let data = await response.json();

        const zDescription = data.infos[0];
        const zProjectStatus = data.status;


        console.log(zProjectStatus);


        if (zProjectStatus.length > 0) {
            openModal(zProjectStatus)
        }


        if (!data) {
            notificationsToast("info", "Projeto sem descrição cadastrada.");
            inputProjeto.value = "";
        }



        notificationsToast("success", "Código Z encontrado.<br>" + zDescription);



    } catch (error) {
        console.error("Erro ao buscar projeto:", error);
        inputProjeto.value = "";
        setValueById('descricao', '');
        notificationsToast("error", "Erro ao buscar informações do projeto.");
    }
});



async function openModal(statusArray) {
    const modalElement = document.getElementById("myAppModal");
    let response = await fetch(route(`dispositivos/solicitacao/modalConfirmZ`));

    if (!response.ok) return;

    let htmlBase = await response.text();
    modalElement.innerHTML = htmlBase;

    if (statusArray.length > 0) {
        const zDisplay = modalElement.querySelector("#modal-cod-z-display");
        if (zDisplay) {
            zDisplay.textContent = `Z${statusArray[0].cod_z}`;
        }
    }


    const container = modalElement.querySelector("#container-sl-pendentes");

    if (container && statusArray.length > 0) {


        container.innerHTML = statusArray.map(item => {
            const projetista = item.conceito_proj ?? "—";
            const solicitante = item.solicitante ?? "Não identificado";

            return `
          <div class="card shadow border-0 mb-4">
        <div class="card-body border-start border-4 border-warning rounded-end">
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="text-uppercase text-muted small fw-bold">SL</label>
                            <h6 class="mb-0 text-dark">${item.ref}</h6>
                        </div>
                        <div class="col-6">
                            <label class="text-uppercase text-muted small fw-bold">Solicitante</label>
                            <h6 class="mb-0 text-dark">${item.solicitante}</h6>
                        </div>
                        <div class="col-12">
                            <hr class="my-2 opacity-25">
                            <label class="text-uppercase text-muted small fw-bold">Descrição</label>
                            <p class="mb-0 small">${item.descricao}</p>
                        </div>
                        <div class="col-6">
                            <label class="text-uppercase text-muted small fw-bold">Aplicação / Vagão</label>
                            <p class="mb-0 small">${item.aplicacao} - ${item.vagao}</p>
                        </div>
                       <div class="col-6">
                    <label class="text-uppercase text-muted small fw-bold">Projetista</label>
                    <p class="mb-0 small">${projetista}</p>
                </div>
                        <div class="col-4">
                            <label class="text-uppercase text-muted small fw-bold">Conceito/Modelagem</label>
                            <p class="mb-0 small">${item.conceito_status}</p>
                        </div>
                        <div class="col-4">
                            <label class="text-uppercase text-muted small fw-bold">Detalhamento</label>
                            <p class="mb-0 small">${item.detalhamento_status}</p>
                        </div>
                        <div class="col-4">
                            <label class="text-uppercase text-muted small fw-bold">Liberação</label>
                            <p class="mb-0 small">${item.liberacao_status}</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        }).join('');
    }

    modalElement.showModal();
}
/**
 * Fecha a modal de edição.
 *
 * @returns {void}
 */
function closeModal(clearField = false) {
    const modalElement = document.getElementById("myAppModal");
    modalElement.close();

    if (clearField)
        inputProjeto.value = "";
}





//PRECISO PEGAR O TIPO DO PERFIL DO SOLICITANTE, O QUE EU FAÇO?
async function getSolicRole() {

    const nomeSolic = solicitante.value;
    console.log(nomeSolic);
    try {
        let response = await fetch(route(`dispositivos/solicitacao/getSolicRole?solic=${nomeSolic}`))
        let data = await response.json();

        if (!response.ok)
            throw new Error(`Erro na Requisição: ${response.status} ${response.statusText}`);

        let role = data.role;


        if (!role) {
            getElement('inputRole').value = '';
        }
        getElement('inputRole').value = role;

        if (role == 'ADMINISTRADOR' || role == 'LIDER DE PROJETO') {
            const radioProducao = document.getElementById('radioProducao1');

            if (radioProducao) {
                radioProducao.removeAttribute('disabled');
            }
        }
    } catch (error) {
        console.error("Ocorreu um erro na requisição:", error.message);
    }
}



getSolicRole();


function getTodayDate() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

const dateInput = document.getElementById('data_necessidade');

const todayFormatted = getTodayDate();
dateInput.setAttribute('min', todayFormatted);

dateInput.addEventListener('blur', function () {
    if (this.validity.rangeUnderflow) {
        this.setCustomValidity('A data de necessidade não pode ser anterior à data de hoje.');

        this.classList.add('is-invalid');

        this.reportValidity();
    } else {
        this.setCustomValidity('');
        this.classList.remove('is-invalid');
    }
});