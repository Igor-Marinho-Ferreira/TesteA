/* ============================================================================
 *  calculoPeso.js — calculadora de peso teórico da chapa (2026-07-21, 6ª rodada)
 *
 *  Peso(kg) = Largura(m) × Comprimento(m) × Espessura(m) × Densidade × Qtde
 *  Tudo calculado no navegador — não há gravação.
 * ========================================================================== */

(function () {
    "use strict";

    const painel = document.getElementById("painelCalculadora");

    if (!painel) {
        return;
    }

    const btnAbrir = document.getElementById("btnCalculadora");
    const btnFechar = document.getElementById("fecharCalculadora");
    const btnCalcular = document.getElementById("btnCalcular");

    // Densidades cadastradas por espessura (texto) -> preenche ao digitar a esp.
    let densPorEspessura = {};

    try {
        densPorEspessura = JSON.parse(painel.dataset.dens || "{}");
    } catch (e) {
        densPorEspessura = {};
    }

    function abrir() {
        painel.classList.remove("d-none");
        painel.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }

    function fechar() {
        painel.classList.add("d-none");
    }

    if (btnAbrir) {
        btnAbrir.addEventListener("click", abrir);
    }

    if (btnFechar) {
        btnFechar.addEventListener("click", fechar);
    }

    // "4,75" ou "4.75" -> 4.75
    function numero(valor) {
        const limpo = String(valor).replace(",", ".").replace(/[^0-9.]/g, "");
        const n = parseFloat(limpo);
        return isNaN(n) ? 0 : n;
    }

    function fmt(valor, dec) {
        return Number(valor).toLocaleString("pt-BR", {
            minimumFractionDigits: dec,
            maximumFractionDigits: dec
        });
    }

    // Ao digitar a espessura, se houver densidade cadastrada, preenche o campo
    const inputEsp = document.getElementById("calcEsp");
    const inputDens = document.getElementById("calcDens");

    if (inputEsp && inputDens) {
        inputEsp.addEventListener("change", function () {
            const chave = inputEsp.value.trim();

            if (densPorEspessura[chave] !== undefined) {
                inputDens.value = densPorEspessura[chave];
            }
        });
    }

    function calcular() {
        const largMm = numero(document.getElementById("calcLarg").value);
        const compMm = numero(document.getElementById("calcComp").value);
        const espMm = numero(document.getElementById("calcEsp").value);
        const qtde = Math.max(1, Math.round(numero(document.getElementById("calcQtde").value)));
        const dens = numero(document.getElementById("calcDens").value);

        const largM = largMm / 1000;
        const compM = compMm / 1000;
        const espM = espMm / 1000;

        const areaUnit = largM * compM;              // m²
        const volUnit = areaUnit * espM;             // m³
        const pesoUnit = volUnit * dens;             // kg
        const pesoTotal = pesoUnit * qtde;

        document.getElementById("calcVol").textContent = fmt(volUnit, 6);
        document.getElementById("calcArea").textContent = fmt(areaUnit * qtde, 4);
        document.getElementById("calcPesoUnit").textContent = fmt(pesoUnit, 2);
        document.getElementById("calcPesoTotal").textContent = fmt(pesoTotal, 2);
    }

    if (btnCalcular) {
        btnCalcular.addEventListener("click", calcular);
    }

    // Enter em qualquer campo calcula
    painel.querySelectorAll("input").forEach(function (campo) {
        campo.addEventListener("keydown", function (evento) {
            if (evento.key === "Enter") {
                evento.preventDefault();
                calcular();
            }
        });
    });
})();
