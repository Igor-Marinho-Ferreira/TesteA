/* ============================================================================
 *  listaIndustrial.js — lista da tela Industrial
 *  Mesmo tratamento de carga do listaProjetos.js: a tabela só aparece depois
 *  que o DataTables terminou de montar, para o layout não saltar e o clique
 *  não cair na linha errada.
 * ========================================================================== */

function marcarTabelaCarregando() {
    const shell = document.querySelector(".dt-loading-shell");

    if (shell) {
        shell.classList.add("dt-loading");
    }

    return shell;
}

function liberarTabelaCarregando(shell) {
    if (shell) {
        shell.classList.remove("dt-loading");
    }
}

const dtShell = marcarTabelaCarregando();

async function initTable() {
    let translate = await fetch(route("/public/js/dt/en.json"));
    translate = await translate.json();

    translate.searchPlaceholder = "EX: Z1000 ou SL4500";
    translate.search = "Pesquisar Código Z ou SL: _INPUT_";

    return new DataTable("#listIndustrial", {
        scrollX: true,
        autoWidth: false,
        pageLength: 12,
        order: [],
        lengthChange: false,
        pagingType: "simple_numbers",
        info: false,
        language: translate,
        columnDefs: [
            { width: "80px", targets: 0 },  // SL
            { width: "260px", targets: 1 }, // DESCRIÇÃO
            { width: "200px", targets: 2 }, // SOLICITANTE
            { width: "90px", targets: 3 },  // COD Z
            { width: "110px", targets: 4 }, // N SFP / CC
            { width: "110px", targets: 5 }, // VAGÃO
            { width: "120px", targets: 6 }, // STATUS
            { width: "90px", targets: 7 },  // # PASTA
            { width: "120px", targets: 8 }, // DATA ENTREGA
            { width: "130px", targets: 9 }, // NATUREZA
            { width: "260px", targets: 10 },// DESCRIÇÃO DO SERVIÇO
            { width: "120px", targets: 11 },// CORTE
            { width: "120px", targets: 12 },// EXECUÇÃO
            { width: "130px", targets: 13 },// EQUIPE
            { width: "130px", targets: 14 },// SETOR
            { className: "dt-center", targets: "_all" },
            { targets: "_all", defaultContent: "" }
        ]
    });
}

/**
 * Espera a pintura do layout OU um limite de tempo — requestAnimationFrame
 * não dispara em aba de segundo plano, e sem o limite a tabela ficaria
 * invisível até o usuário focar a aba.
 */
function aguardarPintura(limiteMs) {
    return new Promise((resolve) => {
        let resolvido = false;

        const concluir = () => {
            if (!resolvido) {
                resolvido = true;
                resolve();
            }
        };

        requestAnimationFrame(() => requestAnimationFrame(concluir));
        setTimeout(concluir, limiteMs);
    });
}

initTable()
    .then(async (table) => {
        await aguardarPintura(600);

        if (table && typeof table.columns === "function") {
            table.columns.adjust();
        }
    })
    .catch((erro) => {
        console.error("Erro ao inicializar a tabela:", erro);
    })
    .finally(() => {
        liberarTabelaCarregando(dtShell);
    });

/* Filtros -------------------------------------------------------------- */

const selectSolicitante = document.getElementById("solicitante");
const selectEquipe = document.getElementById("equipe");

function filtrar() {
    const params = new URLSearchParams(window.location.search);

    if (selectSolicitante) {
        params.set("solicitante", selectSolicitante.value);
    }

    if (selectEquipe) {
        params.set("equipe", selectEquipe.value);
    }

    window.location.search = params.toString();
}

if (selectSolicitante) {
    selectSolicitante.addEventListener("change", filtrar);
}

if (selectEquipe) {
    selectEquipe.addEventListener("change", filtrar);
}

/* Recalcula larguras ao redimensionar / girar o aparelho */
let redimensionamentoTimer = null;

window.addEventListener("resize", () => {
    clearTimeout(redimensionamentoTimer);

    redimensionamentoTimer = setTimeout(() => {
        if (window.DataTable && DataTable.tables) {
            DataTable.tables({ visible: true, api: true }).columns.adjust();
        }
    }, 180);
});

/* ============================================================================
 *  Edição inline dos campos do industrial (9ª rodada)
 *  Salva ao sair do campo (blur) / trocar a data, só se o valor mudou.
 *  Usa o mesmo endpoint da tela de detalhe: campos/{ref} com o campo alterado.
 * ========================================================================== */

function toastLista(tipo, mensagem) {
    if (typeof notificationsToast === "function") {
        notificationsToast(tipo, mensagem);
    } else {
        console[tipo === "error" ? "error" : "log"](mensagem);
    }
}

async function salvarCampoInline(input) {
    const ref = input.dataset.ref;
    const campo = input.dataset.campo;
    const valor = input.value.trim();

    if (valor === (input.dataset.original || "")) {
        return; // nada mudou
    }

    input.classList.add("is-saving");
    input.disabled = true;

    try {
        const resposta = await fetch(route("dispositivos/industrial/campos/" + ref), {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest"
            },
            body: JSON.stringify({ [campo]: valor })
        });

        let dados = {};
        try { dados = await resposta.json(); } catch (e) { dados = {}; }

        if (!resposta.ok || dados.success === false) {
            input.value = input.dataset.original || "";
            toastLista("error", dados.message || "Não foi possível salvar.");
            return;
        }

        input.dataset.original = valor;
        input.classList.add("is-valid");
        setTimeout(() => input.classList.remove("is-valid"), 1200);
    } catch (erro) {
        console.error("Erro ao salvar campo inline:", erro);
        input.value = input.dataset.original || "";
        toastLista("error", "Erro de conexão ao salvar.");
    } finally {
        input.classList.remove("is-saving");
        input.disabled = false;
    }
}

/* Delegação: funciona em todas as páginas do DataTables (a paginação
   remove/insere as linhas do DOM, então listeners diretos não bastam). */
function alvoCampo(evento) {
    return evento.target && evento.target.closest ? evento.target.closest(".campo-ind") : null;
}

// Captura o valor atual ao entrar no campo (base para comparar na saída)
document.addEventListener("focusin", function (evento) {
    const input = alvoCampo(evento);
    if (input) {
        input.dataset.original = input.value.trim();
    }
});

// Salva ao sair do campo
document.addEventListener("focusout", function (evento) {
    const input = alvoCampo(evento);
    if (input) {
        salvarCampoInline(input);
    }
});

// Data salva na troca; Enter confirma
document.addEventListener("change", function (evento) {
    const input = alvoCampo(evento);
    if (input && input.type === "date") {
        salvarCampoInline(input);
    }
});

document.addEventListener("keydown", function (evento) {
    const input = alvoCampo(evento);
    if (input && evento.key === "Enter") {
        evento.preventDefault();
        input.blur();
    }
});
