let arquivosItensCompradosAcumulados = [];

function gerenciarMudancaStatus(selectElement) {
    loading("show", true);
    updateStatusStyle(selectElement);

    const dados = {
        id: selectElement.getAttribute("data-id"),
        coluna: selectElement.getAttribute("data-coluna"),
        valor: selectElement.value
    };

    fetch(route("dispositivos/desenvolvimento/atualizaStatus"), {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Requested-With": "XMLHttpRequest"
        },
        body: JSON.stringify(dados)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro na rede");
            }

            return response.json();
        })
        .then(data => {
            if (data.success || data.status === "success") {
                notificationsToast("success", "Status alterado com sucesso!");

                setTimeout(() => {
                    loading("show", true);
                    window.location.reload();
                }, 1500);
            } else {
                loading("hide", true);
                notificationsToast("error", data.message || "Falha ao alterar status");
            }
        })
        .catch(error => {
            console.error("Erro na requisição:", error);
            loading("hide", true);
            notificationsToast("error", "Erro de conexão com o servidor");
        });
}

function loading(state, ignoreForm) {
    const loadingWrapper = document.getElementById("loading-wrapper");

    if (!loadingWrapper) {
        return;
    }

    if (ignoreForm) {
        loadingWrapper.style.display = state === "show" ? "flex" : "none";
        return;
    }

    if (typeof validateForm === "function" && validateForm("formMenu")) {
        loadingWrapper.style.display = state === "show" ? "flex" : "none";
    }
}

function updateStatusStyle(selectElement) {
    const statusClasses = [
        "status-ok",
        "status-alerta",
        "status-espera",
        "status-revisao",
        "status-backlog",
        "status-pausado"
    ];

    selectElement.classList.remove(...statusClasses);

    const selectedOption = selectElement.options[selectElement.selectedIndex];
    const newClass = selectedOption ? selectedOption.getAttribute("data-class") : "";

    if (newClass) {
        selectElement.classList.add(newClass);
    }
}

async function openModal(ref, tipo) {
    const modalElement = document.getElementById("myAppModal");

    if (!modalElement) {
        notificationsToast("error", "Modal principal não encontrada.");
        return;
    }

    let url = "";

    modalElement.classList.remove("modal-arquivos-container");

    if (tipo === "requisitos") {
        url = route(`dispositivos/solicitacao/requisitos/${ref}`);
    } else if (tipo === "anexos") {
        url = route(`dispositivos/solicitacao/anexos/${ref}`);
    } else if (tipo === "arquivos_solicitacao") {
        url = route(`dispositivos/desenvolvimento/arquivos-solicitacao/${ref}`);
        modalElement.classList.add("modal-arquivos-container");
    }

    if (!url) {
        notificationsToast("error", "Tipo de modal inválido.");
        return;
    }

    try {
        const response = await fetch(url, {
            method: "GET",
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        });

        if (!response.ok) {
            modalElement.classList.remove("modal-arquivos-container");
            notificationsToast("error", "O conteúdo da modal não foi encontrado. Tente novamente.");
            return;
        }

        const data = await response.text();

        if (modalElement.open) {
            modalElement.close();
        }

        modalElement.innerHTML = data;
        modalElement.showModal();

        if (tipo === "arquivos_solicitacao") {
            inicializarFluxoArquivosSolicitacao();
        }

    } catch (error) {
        modalElement.classList.remove("modal-arquivos-container");

        console.error("Erro ao carregar modal:", error);
        notificationsToast("error", "Erro de conexão ao carregar os dados.");
    }
}

function closeModal(tipo) {
    const modalElement = document.getElementById("myAppModal");

    if (!modalElement) {
        return;
    }

    modalElement.classList.remove("modal-arquivos-container");

    if (modalElement.open) {
        modalElement.close();
    }

    if (tipo === "aprovar") {
        notificationsToast("success", "Validação aprovada.");
    } else if (tipo === "rejeitar") {
        notificationsToast("error", "Validação rejeitada.");
    }
}

function acionarInputArquivo(inputId) {
    const input = document.getElementById(inputId);

    if (!input) {
        notificationsToast("error", "Campo de arquivo não encontrado.");
        return;
    }

    if (input.disabled) {
        notificationsToast("info", "Preencha a etapa anterior antes de continuar.");
        return;
    }

    input.click();
}

function previewImagemProjeto(input) {
    const preview = document.getElementById("previewImagemSolicitacao");

    if (!preview || !input.files || input.files.length === 0) {
        return;
    }

    const arquivo = input.files[0];

    if (!arquivo.type.startsWith("image/")) {
        notificationsToast("error", "Selecione uma imagem válida.");
        input.value = "";
        return;
    }

    const reader = new FileReader();

    reader.onload = function (event) {
        preview.src = event.target.result;
    };

    reader.readAsDataURL(arquivo);
}

function preencherNomeArquivo(input, campoTextoId) {
    const campoTexto = document.getElementById(campoTextoId);

    if (!campoTexto) {
        return;
    }

    if (!input.files || input.files.length === 0) {
        campoTexto.value = "";
        return;
    }

    const arquivos = Array.from(input.files).map(file => file.name);

    if (arquivos.length === 1) {
        campoTexto.value = arquivos[0];
        return;
    }

    campoTexto.value = arquivos.length + " arquivos selecionados: " + arquivos.join(", ");
}

function listarDesenhosPdf(input) {
    const tbody = document.getElementById("tbodyDesenhosPdf");

    if (!tbody) {
        return;
    }

    tbody.innerHTML = "";

    if (!input.files || input.files.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td class="text-center text-muted py-4">
                    Nenhum desenho informado.
                </td>
            </tr>
        `;
        return;
    }

    Array.from(input.files).forEach(function (file) {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${escapeHtml(file.name)}</td>
        `;

        tbody.appendChild(tr);
    });
}

function limparTabelaItensComprados(texto) {
    const tbody = document.getElementById("tbodyItensComprados");

    if (!tbody) {
        return;
    }

    tbody.innerHTML = `
        <tr>
            <td colspan="5" class="text-center text-muted py-4">
                ${escapeHtml(texto || "Nenhum item comprado informado.")}
            </td>
        </tr>
    `;
}

function controlarItensComprados(marcado) {
    const inputItensCompradosTxt = document.getElementById("itens_comprados_txt");
    const nomeItensCompradosTxt = document.getElementById("nome_itens_comprados_txt");

    if (marcado) {
        arquivosItensCompradosAcumulados = [];

        if (inputItensCompradosTxt) {
            inputItensCompradosTxt.value = "";
        }

        if (nomeItensCompradosTxt) {
            nomeItensCompradosTxt.value = "";
        }

        sincronizarInputItensComprados();
        renderizarListaTxtItensComprados();
        limparTabelaItensComprados("Nenhum item comprado.");
        return;
    }

    limparTabelaItensComprados("Nenhum item comprado informado.");
}

function adicionarArquivosTxtItensComprados(input, callbackDepoisDeLer) {
    if (!input || !input.files || input.files.length === 0) {
        return;
    }

    const novosArquivos = Array.from(input.files);

    let adicionados = 0;
    let duplicados = 0;
    let invalidos = 0;

    novosArquivos.forEach(function (arquivo) {
        if (!arquivo.name.toLowerCase().endsWith(".txt")) {
            invalidos++;
            return;
        }

        const jaExiste = arquivosItensCompradosAcumulados.some(function (arquivoExistente) {
            return gerarChaveArquivo(arquivoExistente) === gerarChaveArquivo(arquivo);
        });

        if (jaExiste) {
            duplicados++;
            return;
        }

        arquivosItensCompradosAcumulados.push(arquivo);
        adicionados++;
    });

    if (invalidos > 0) {
        notificationsToast("error", "Selecione apenas arquivos TXT para os itens comprados.");
    }

    if (duplicados > 0) {
        notificationsToast("info", "Um ou mais TXTs já estavam adicionados e foram ignorados.");
    }

    if (adicionados > 0) {
        notificationsToast("success", adicionados + " TXT(s) adicionado(s) com sucesso.");
    }

    sincronizarInputItensComprados();
    preencherNomeItensCompradosTxt();
    renderizarListaTxtItensComprados();

    if (arquivosItensCompradosAcumulados.length === 0) {
        limparTabelaItensComprados();

        if (typeof callbackDepoisDeLer === "function") {
            callbackDepoisDeLer();
        }

        return;
    }

    lerTxtItensCompradosAcumulados(callbackDepoisDeLer);
}

function gerarChaveArquivo(arquivo) {
    return [
        arquivo.name,
        arquivo.size,
        arquivo.lastModified
    ].join("__");
}

function sincronizarInputItensComprados() {
    const inputItensCompradosTxt = document.getElementById("itens_comprados_txt");

    if (!inputItensCompradosTxt) {
        return;
    }

    const dataTransfer = new DataTransfer();

    arquivosItensCompradosAcumulados.forEach(function (arquivo) {
        dataTransfer.items.add(arquivo);
    });

    inputItensCompradosTxt.files = dataTransfer.files;
}

function preencherNomeItensCompradosTxt() {
    const campoTexto = document.getElementById("nome_itens_comprados_txt");

    if (!campoTexto) {
        return;
    }

    if (arquivosItensCompradosAcumulados.length === 0) {
        campoTexto.value = "";
        campoTexto.placeholder = "Nenhum TXT selecionado";
        return;
    }

    if (arquivosItensCompradosAcumulados.length === 1) {
        campoTexto.value = arquivosItensCompradosAcumulados[0].name;
        return;
    }

    campoTexto.value = arquivosItensCompradosAcumulados.length + " TXTs selecionados";
}

function renderizarListaTxtItensComprados() {
    const container = document.getElementById("lista_itens_comprados_txt");
    const btnLimpar = document.getElementById("btn_limpar_itens_comprados_txt");

    if (!container) {
        return;
    }

    if (arquivosItensCompradosAcumulados.length === 0) {
        container.innerHTML = `
            <div class="text-muted">
                Nenhum TXT adicionado.
            </div>
        `;

        if (btnLimpar) {
            btnLimpar.setAttribute("disabled", "disabled");
            btnLimpar.setAttribute("title", "Nenhum TXT adicionado.");
        }

        return;
    }

    container.innerHTML = `
        <div class="border rounded p-2 bg-light">
            <div class="fw-bold text-muted mb-1">
                TXTs adicionados:
            </div>

            ${arquivosItensCompradosAcumulados.map(function (arquivo, index) {
                return `
                    <div class="d-flex align-items-center justify-content-between gap-2 border-bottom py-1">
                        <span class="text-truncate" title="${escapeAttr(arquivo.name)}">
                            ${index + 1}. ${escapeHtml(arquivo.name)}
                        </span>

                        <button 
                            type="button"
                            class="btn btn-sm btn-outline-danger py-0 px-2"
                            onclick="removerTxtItensComprados(${index})"
                            title="Remover este TXT"
                        >
                            Remover
                        </button>
                    </div>
                `;
            }).join("")}
        </div>
    `;

    if (btnLimpar) {
        btnLimpar.removeAttribute("disabled");
        btnLimpar.setAttribute("title", "Remover todos os TXTs selecionados.");
    }
}

function removerTxtItensComprados(index) {
    if (index < 0 || index >= arquivosItensCompradosAcumulados.length) {
        return;
    }

    arquivosItensCompradosAcumulados.splice(index, 1);

    sincronizarInputItensComprados();
    preencherNomeItensCompradosTxt();
    renderizarListaTxtItensComprados();

    if (arquivosItensCompradosAcumulados.length === 0) {
        limparTabelaItensComprados();
    } else {
        lerTxtItensCompradosAcumulados();
    }

    atualizarFluxoArquivosSolicitacaoGlobal();
}

function limparTodosTxtItensComprados() {
    arquivosItensCompradosAcumulados = [];

    sincronizarInputItensComprados();
    preencherNomeItensCompradosTxt();
    renderizarListaTxtItensComprados();
    limparTabelaItensComprados();

    atualizarFluxoArquivosSolicitacaoGlobal();
}

function lerArquivoTextoComEncoding(arquivo) {
    return new Promise(function (resolve, reject) {
        const reader = new FileReader();

        reader.onload = function (event) {
            try {
                const buffer = event.target.result;

                let textoUtf8 = "";
                let textoWindows1252 = "";

                try {
                    textoUtf8 = new TextDecoder("utf-8").decode(buffer);
                } catch (error) {
                    textoUtf8 = "";
                }

                try {
                    textoWindows1252 = new TextDecoder("windows-1252").decode(buffer);
                } catch (error) {
                    textoWindows1252 = "";
                }

                if (textoUtf8.includes("�") && textoWindows1252) {
                    resolve(textoWindows1252);
                    return;
                }

                resolve(textoUtf8 || textoWindows1252);
            } catch (error) {
                reject(error);
            }
        };

        reader.onerror = function () {
            reject(reader.error);
        };

        reader.readAsArrayBuffer(arquivo);
    });
}

function lerTxtItensCompradosAcumulados(callbackDepoisDeLer) {
    if (arquivosItensCompradosAcumulados.length === 0) {
        limparTabelaItensComprados();

        if (typeof callbackDepoisDeLer === "function") {
            callbackDepoisDeLer();
        }

        return;
    }

    Promise.all(
        arquivosItensCompradosAcumulados.map(function (arquivo) {
            return lerArquivoTextoComEncoding(arquivo).then(function (conteudo) {
                return {
                    nomeArquivo: arquivo.name,
                    conteudo: conteudo || ""
                };
            });
        })
    )
        .then(function (resultados) {
            const itens = [];

            resultados.forEach(function (resultado) {
                const linhas = resultado.conteudo
                    .split(/\r?\n/)
                    .map(linha => linha.trim())
                    .filter(linha => linha !== "");

                linhas.forEach(function (linha) {
                    const item = parseLinhaItemComprado(linha);
                    item.arquivo_origem = resultado.nomeArquivo;
                    itens.push(item);
                });
            });

            if (itens.length === 0) {
                notificationsToast("info", "O(s) arquivo(s) TXT não possui(em) itens.");
                limparTabelaItensComprados();

                if (typeof callbackDepoisDeLer === "function") {
                    callbackDepoisDeLer();
                }

                return;
            }

            renderizarItensComprados(itens);

            if (typeof callbackDepoisDeLer === "function") {
                callbackDepoisDeLer();
            }
        })
        .catch(function () {
            notificationsToast("error", "Erro ao ler o(s) arquivo(s) TXT de itens comprados.");
            limparTabelaItensComprados();

            if (typeof callbackDepoisDeLer === "function") {
                callbackDepoisDeLer();
            }
        });
}

function parseLinhaItemComprado(linha) {
    const partes = linha
        .replace(/\u00A0/g, " ")
        .split(/\t+|\s{2,}/)
        .map(parte => parte.trim())
        .filter(parte => parte !== "");

    const item = {
        codigo: "",
        rev: "",
        descricao: "",
        qtde: "",
        tipo: ""
    };

    if (partes.length === 0) {
        return item;
    }

    item.codigo = partes[0] || "";
    item.rev = partes.length > 1 ? partes[1] : "";

    const indiceQuantidade = partes.findIndex(function (parte, index) {
        return index > 1 && ehNumeroQuantidade(parte);
    });

    if (indiceQuantidade > -1) {
        item.descricao = partes.slice(2, indiceQuantidade).join(" ");
        item.qtde = partes[indiceQuantidade] || "";
        item.tipo = partes.slice(indiceQuantidade + 1).join(" ");
    } else {
        item.descricao = partes.slice(2).join(" ");
    }

    return item;
}

function ehNumeroQuantidade(valor) {
    const texto = String(valor || "").trim();

    if (!texto) {
        return false;
    }

    return /^-?\d+([,.]\d+)?$/.test(texto) || /^-?\d{1,3}(\.\d{3})+([,.]\d+)?$/.test(texto);
}

function renderizarItensComprados(itens) {
    const tbody = document.getElementById("tbodyItensComprados");

    if (!tbody) {
        return;
    }

    tbody.innerHTML = "";

    if (!itens || itens.length === 0) {
        limparTabelaItensComprados();
        return;
    }

    itens.forEach(function (item, index) {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td class="text-break" style="white-space: normal;">
                ${escapeHtml(item.codigo)}
                <input type="hidden" name="itens_comprados[${index}][codigo]" value="${escapeAttr(item.codigo)}">
            </td>

            <td class="text-break" style="white-space: normal;">
                ${escapeHtml(item.rev)}
                <input type="hidden" name="itens_comprados[${index}][rev]" value="${escapeAttr(item.rev)}">
            </td>

            <td class="text-break text-start" style="white-space: normal;">
                ${escapeHtml(item.descricao)}
                <input type="hidden" name="itens_comprados[${index}][descricao]" value="${escapeAttr(item.descricao)}">
            </td>

            <td class="text-break" style="white-space: normal;">
                ${escapeHtml(item.qtde)}
                <input type="hidden" name="itens_comprados[${index}][qtde]" value="${escapeAttr(item.qtde)}">
            </td>

            <td class="text-break text-start" style="white-space: normal;">
                ${escapeHtml(item.tipo)}
                <input type="hidden" name="itens_comprados[${index}][tipo]" value="${escapeAttr(item.tipo)}">
                <input type="hidden" name="itens_comprados[${index}][arquivo_origem]" value="${escapeAttr(item.arquivo_origem || "")}">
            </td>
        `;

        tbody.appendChild(tr);
    });
}

function adicionarLinhaItemComprado() {
    notificationsToast("info", "Os itens comprados devem ser carregados por arquivo TXT.");
}

function habilitarEdicaoItensComprados() {
    notificationsToast("info", "A lista de itens comprados não pode ser editada manualmente.");
}

function inicializarFluxoArquivosSolicitacao() {
    arquivosItensCompradosAcumulados = [];

    const inputImagem = document.getElementById("imagem_projeto");
    const inputPacoteDxf = document.getElementById("pacote_dxf");
    const inputItensCompradosTxt = document.getElementById("itens_comprados_txt");
    const inputListaMateriais = document.getElementById("lista_materiais");
    const inputDesenhosPdf = document.getElementById("desenhos_pdf");

    const checkSemDxf = document.getElementById("sem_arquivos_dxf");
    const checkNenhumItemComprado = document.getElementById("nenhum_item_comprado");

    const btnImagem = document.getElementById("btn_imagem_projeto");
    const btnPacoteDxf = document.getElementById("btn_pacote_dxf");
    const btnItensCompradosTxt = document.getElementById("btn_itens_comprados_txt");
    const btnLimparTxtItens = document.getElementById("btn_limpar_itens_comprados_txt");
    const btnListaMateriais = document.getElementById("btn_lista_materiais");
    const btnDesenhosPdf = document.getElementById("btn_desenhos_pdf");
    const btnCarregarDados = document.getElementById("btn_carregar_dados");

    if (
        !inputImagem ||
        !inputPacoteDxf ||
        !inputItensCompradosTxt ||
        !inputListaMateriais ||
        !inputDesenhosPdf
    ) {
        return;
    }

    window.atualizarFluxoArquivosSolicitacaoGlobal = atualizarFluxoArquivosSolicitacao;

    renderizarListaTxtItensComprados();
    atualizarFluxoArquivosSolicitacao();

    inputImagem.addEventListener("change", function () {
        if (inputImagem.files && inputImagem.files.length > 0) {
            inputImagem.setAttribute("data-existe", "1");
        }

        previewImagemProjeto(inputImagem);
        atualizarFluxoArquivosSolicitacao();
    });

    inputPacoteDxf.addEventListener("change", function () {
        if (inputPacoteDxf.files && inputPacoteDxf.files.length > 0) {
            inputPacoteDxf.setAttribute("data-existe", "1");
        }

        preencherNomeArquivo(inputPacoteDxf, "nome_pacote_dxf");
        atualizarFluxoArquivosSolicitacao();
    });

    inputItensCompradosTxt.addEventListener("change", function () {
        if (checkNenhumItemComprado) {
            checkNenhumItemComprado.checked = false;
        }

        if (inputItensCompradosTxt.files && inputItensCompradosTxt.files.length > 0) {
            inputItensCompradosTxt.setAttribute("data-existe", "1");
        }

        adicionarArquivosTxtItensComprados(inputItensCompradosTxt, atualizarFluxoArquivosSolicitacao);
    });

    inputListaMateriais.addEventListener("change", function () {
        if (inputListaMateriais.files && inputListaMateriais.files.length > 0) {
            inputListaMateriais.setAttribute("data-existe", "1");
        }

        preencherNomeArquivo(inputListaMateriais, "nome_lista_materiais");
        atualizarFluxoArquivosSolicitacao();
    });

    inputDesenhosPdf.addEventListener("change", function () {
        if (inputDesenhosPdf.files && inputDesenhosPdf.files.length > 0) {
            inputDesenhosPdf.setAttribute("data-existe", "1");
        }

        listarDesenhosPdf(inputDesenhosPdf);
        atualizarFluxoArquivosSolicitacao();
    });

    if (checkSemDxf) {
        checkSemDxf.addEventListener("change", function () {
            if (this.checked) {
                inputPacoteDxf.value = "";
                inputPacoteDxf.setAttribute("data-existe", "0");

                const nomePacoteDxf = document.getElementById("nome_pacote_dxf");

                if (nomePacoteDxf) {
                    nomePacoteDxf.value = "";
                }
            }

            atualizarFluxoArquivosSolicitacao();
        });
    }

    if (checkNenhumItemComprado) {
        checkNenhumItemComprado.addEventListener("change", function () {
            if (this.checked) {
                inputItensCompradosTxt.setAttribute("data-existe", "0");
            }

            controlarItensComprados(this.checked);
            atualizarFluxoArquivosSolicitacao();
        });
    }

    function atualizarFluxoArquivosSolicitacao() {
        const imagemExistente = inputImagem.getAttribute("data-existe") === "1";
        const dxfExistente = inputPacoteDxf.getAttribute("data-existe") === "1";
        const txtItensExistente = inputItensCompradosTxt.getAttribute("data-existe") === "1";
        const listaMateriaisExistente = inputListaMateriais.getAttribute("data-existe") === "1";
        const desenhosPdfExistente = inputDesenhosPdf.getAttribute("data-existe") === "1";

        const imagemInformada = imagemExistente || (inputImagem.files && inputImagem.files.length > 0);

        const semDxfMarcado = checkSemDxf && checkSemDxf.checked;
        const pacoteDxfInformado = dxfExistente || (inputPacoteDxf.files && inputPacoteDxf.files.length > 0);
        const dxfResolvido = semDxfMarcado || pacoteDxfInformado;

        const nenhumItemMarcado = checkNenhumItemComprado && checkNenhumItemComprado.checked;
        const txtItensInformado = txtItensExistente || arquivosItensCompradosAcumulados.length > 0;
        const itensCompradosResolvido = nenhumItemMarcado || txtItensInformado;

        const listaMateriaisInformada = listaMateriaisExistente || (inputListaMateriais.files && inputListaMateriais.files.length > 0);
        const desenhosPdfInformados = desenhosPdfExistente || (inputDesenhosPdf.files && inputDesenhosPdf.files.length > 0);

        bloquearOuLiberar(
            btnImagem,
            false,
            "Insira a imagem do projeto."
        );

        bloquearOuLiberar(
            checkSemDxf,
            !imagemInformada,
            "Primeiro insira a imagem do projeto."
        );

        bloquearOuLiberar(
            btnPacoteDxf,
            !imagemInformada || semDxfMarcado,
            semDxfMarcado
                ? "Marcado como sem arquivos DXF."
                : "Primeiro insira a imagem do projeto."
        );

        bloquearOuLiberar(
            btnItensCompradosTxt,
            !imagemInformada || !dxfResolvido || nenhumItemMarcado,
            nenhumItemMarcado
                ? "Marcado como nenhum item comprado."
                : "Primeiro informe o pacote DXF ou marque Sem arquivos DXF."
        );

        bloquearOuLiberar(
            checkNenhumItemComprado,
            !imagemInformada || !dxfResolvido,
            "Primeiro informe o pacote DXF ou marque Sem arquivos DXF."
        );

        bloquearOuLiberar(
            btnLimparTxtItens,
            arquivosItensCompradosAcumulados.length === 0,
            "Nenhum TXT adicionado nesta abertura da modal."
        );

        bloquearOuLiberar(
            btnListaMateriais,
            !imagemInformada || !dxfResolvido || !itensCompradosResolvido,
            "Primeiro insira o TXT de itens comprados ou marque Nenhum Item Comprado."
        );

        bloquearOuLiberar(
            btnDesenhosPdf,
            !imagemInformada || !dxfResolvido || !itensCompradosResolvido || !listaMateriaisInformada,
            "Primeiro insira a lista de materiais."
        );

        bloquearOuLiberar(
            btnCarregarDados,
            !imagemInformada ||
            !dxfResolvido ||
            !itensCompradosResolvido ||
            !listaMateriaisInformada ||
            !desenhosPdfInformados,
            "Primeiro complete a sequência: imagem, DXF, itens comprados, lista de materiais e desenhos PDF."
        );
    }

    function bloquearOuLiberar(elemento, bloquear, mensagem) {
        if (!elemento) {
            return;
        }

        if (bloquear) {
            elemento.setAttribute("disabled", "disabled");
            elemento.setAttribute("title", mensagem || "Preencha a etapa anterior.");
            elemento.classList.add("disabled");

            if (elemento.tagName === "LABEL") {
                elemento.style.pointerEvents = "none";
                elemento.style.opacity = "0.65";
                elemento.style.cursor = "not-allowed";
            }

            return;
        }

        elemento.removeAttribute("disabled");
        elemento.setAttribute("title", "");
        elemento.classList.remove("disabled");

        if (elemento.tagName === "LABEL") {
            elemento.style.pointerEvents = "auto";
            elemento.style.opacity = "1";
            elemento.style.cursor = "pointer";
        }
    }
}

function escapeHtml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function escapeAttr(value) {
    return escapeHtml(value);
}

function atualizaBotaoAssociar() {
    const inputProjeto = document.getElementById("cod_z");
    const btnAssociar = document.getElementById("botaoAssociar");

    if (!inputProjeto || !btnAssociar) {
        return;
    }

    const valorOriginal = inputProjeto.getAttribute("data-valor-original") ?? "";
    const valorAtual = inputProjeto.value.trim();

    if (valorAtual !== valorOriginal && valorAtual !== "") {
        btnAssociar.removeAttribute("disabled");
        btnAssociar.classList.replace("btn-outline-secondary", "btn-primary");
        btnAssociar.classList.replace("btn-outline-primary", "btn-primary");
    } else {
        btnAssociar.setAttribute("disabled", "disabled");
        btnAssociar.classList.replace("btn-primary", "btn-outline-secondary");
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const inputProjeto = document.getElementById("cod_z");
    const btnAssociar = document.getElementById("botaoAssociar");

    if (inputProjeto) {
        inputProjeto.setAttribute("data-valor-original", inputProjeto.value || "");

        inputProjeto.addEventListener("blur", async function () {
            const valorOriginal = inputProjeto.getAttribute("data-valor-original") ?? "";
            const numberProject = inputProjeto.value.trim();

            if (!numberProject || numberProject.length <= 1) {
                atualizaBotaoAssociar();
                return;
            }

            if (numberProject === valorOriginal) {
                atualizaBotaoAssociar();
                return;
            }

            try {
                const response = await fetch(
                    route(`dispositivos/solicitacoes/getProjectInfos?projectNumber=${numberProject}`)
                );

                if (response.status === 404) {
                    notificationsToast("info", "Projeto inexistente. Digite um número válido ou gere um novo Z.");
                    inputProjeto.value = valorOriginal;
                    atualizaBotaoAssociar();
                    return;
                }

                if (!response.ok) {
                    throw new Error("Erro na requisição");
                }

                const data = await response.json();

                if (!data) {
                    notificationsToast("info", "Projeto sem descrição cadastrada.");
                    inputProjeto.value = valorOriginal;
                    atualizaBotaoAssociar();
                    return;
                }

                const zDescription = data.infos ? data.infos[0] : "";
                const zProjectStatus = data.status;
                const inputRev = document.getElementById("qtdRev");

                notificationsToast("success", "Código Z encontrado.<br>" + zDescription);

                if (inputRev) {
                    const qtd = zProjectStatus && zProjectStatus.length > 0
                        ? zProjectStatus[0].qtdRev
                        : 0;

                    inputRev.value = qtd;
                }

                atualizaBotaoAssociar();

            } catch (error) {
                console.error("Erro ao buscar projeto:", error);

                inputProjeto.value = "";

                if (typeof setValueById === "function") {
                    setValueById("descricao", "");
                }

                notificationsToast("error", "Erro ao buscar informações do projeto.");
            }
        });
    }

    const checkNovaRev = document.getElementById("novaRev");
    const inputRev = document.getElementById("qtdRev");

    if (checkNovaRev && inputRev && inputProjeto && btnAssociar) {
        const valorOriginal = inputProjeto.getAttribute("data-valor-original") ?? inputProjeto.value ?? "";
        const valorRevOriginal = inputRev.value || 0;

        checkNovaRev.addEventListener("change", function () {
            if (this.checked) {
                inputProjeto.value = valorOriginal;

                btnAssociar.removeAttribute("disabled");
                btnAssociar.classList.replace("btn-outline-secondary", "btn-success");
                btnAssociar.classList.replace("btn-outline-primary", "btn-success");
                btnAssociar.classList.replace("btn-primary", "btn-success");

                btnAssociar.innerHTML = '<i class="fas fa-plus-circle me-1"></i> Nova Rev';

                inputRev.classList.add("is-valid", "fw-bold", "text-success");

                const revNumerica = parseInt(valorRevOriginal, 10);

                inputRev.value = !isNaN(revNumerica) ? revNumerica + 1 : 1;

                return;
            }

            inputRev.value = valorRevOriginal;
            inputRev.classList.remove("is-valid", "fw-bold", "text-success");

            btnAssociar.classList.remove("btn-success");
            btnAssociar.classList.add("btn-outline-secondary");

            btnAssociar.innerHTML = '<i class="fas fa-link"></i> Associar';

            atualizaBotaoAssociar();
        });
    }

    const btnCarregarAnexos = document.getElementById("btnCarregarAnexos");

    if (btnCarregarAnexos) {
        const liberado = btnCarregarAnexos.getAttribute("data-liberado") === "1";

        if (!liberado) {
            btnCarregarAnexos.setAttribute("disabled", "disabled");
            btnCarregarAnexos.classList.remove("btn-primary");
            btnCarregarAnexos.classList.add("btn-secondary");
        }
    }
});

window.acionarInputArquivo = acionarInputArquivo;
window.openModal = openModal;
window.closeModal = closeModal;
window.adicionarLinhaItemComprado = adicionarLinhaItemComprado;
window.habilitarEdicaoItensComprados = habilitarEdicaoItensComprados;
window.removerTxtItensComprados = removerTxtItensComprados;
window.limparTodosTxtItensComprados = limparTodosTxtItensComprados;

window.formRemocaoArquivoSelecionado = null;

window.abrirConfirmacaoRemoverArquivo = function (botao) {
    if (!botao) {
        return;
    }

    window.formRemocaoArquivoSelecionado = botao.dataset.formId || null;

    const nomeArquivo = botao.dataset.nomeArquivo || 'arquivo selecionado';
    const tipoArquivo = botao.dataset.tipoArquivo || 'Arquivo';

    const backdrop = document.getElementById('confirmacaoRemoverArquivoBackdrop');
    const nome = document.getElementById('confirmacaoRemoverNomeArquivo');
    const tipo = document.getElementById('confirmacaoRemoverTipoArquivo');

    if (nome) {
        nome.textContent = nomeArquivo;
    }

    if (tipo) {
        tipo.textContent = tipoArquivo;
    }

    if (backdrop) {
        backdrop.classList.remove('d-none');
    }
};

window.fecharConfirmacaoRemoverArquivo = function () {
    const backdrop = document.getElementById('confirmacaoRemoverArquivoBackdrop');

    if (backdrop) {
        backdrop.classList.add('d-none');
    }

    window.formRemocaoArquivoSelecionado = null;
};

window.confirmarRemocaoArquivo = function () {
    if (!window.formRemocaoArquivoSelecionado) {
        window.fecharConfirmacaoRemoverArquivo();
        return;
    }

    const form = document.getElementById(window.formRemocaoArquivoSelecionado);

    if (!form) {
        window.fecharConfirmacaoRemoverArquivo();
        return;
    }

    if (typeof loading === 'function') {
        loading('show', true);
    }

    form.submit();
};