/* ============================================================================
 *  liberacaoAquisicao.js
 *  ---------------------------------------------------------------------------
 *  Arquivo ADITIVO. Carregado DEPOIS de desenvolvimentoProj.js.
 *
 *  Nao edita nenhuma funcao existente: onde precisa mudar comportamento antigo
 *  (gerenciarMudancaStatus) ele embrulha a funcao original e delega para ela
 *  em todos os casos que nao interessam a este modulo.
 *
 *  Responsabilidades:
 *    1. Botao "Liberar SL" e select de Liberacao -> abrem a modal de liberacao
 *    2. Envio da modal de liberacao
 *    3. Aquisicao: pesquisa, edicao inline de N OC / Pedido / Liquidado
 *    4. Conclusao da aquisicao (exige tudo liquidado)
 * ========================================================================== */

(function () {
    "use strict";

    /* ---------------------------------------------------------------- utils */

    function toast(tipo, mensagem) {
        if (typeof notificationsToast === "function") {
            notificationsToast(tipo, mensagem);
            return;
        }

        // Fallback caso o modulo de notificacao nao esteja na pagina
        console[tipo === "error" ? "error" : "log"](mensagem);
    }

    function mostrarLoading(exibir) {
        if (typeof loading === "function") {
            loading(exibir ? "show" : "hide", true);
        }
    }

    function fecharModal() {
        if (typeof closeModal === "function") {
            closeModal();
            return;
        }

        const modal = document.getElementById("myAppModal");

        if (modal && modal.open) {
            modal.close();
        }
    }

    /**
     * POST em JSON com tratamento de erro unificado.
     * Devolve sempre { ok, dados } - nunca lanca.
     */
    async function postJson(url, corpo) {
        try {
            const resposta = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: JSON.stringify(corpo || {})
            });

            let dados = {};

            try {
                dados = await resposta.json();
            } catch (e) {
                dados = {};
            }

            return { ok: resposta.ok && dados.success !== false, dados: dados };
        } catch (erro) {
            console.error("Falha na requisicao:", erro);

            return {
                ok: false,
                dados: { message: "Erro de conexão com o servidor." }
            };
        }
    }

    /* ------------------------------------------------- 1. abrir a modal */

    async function abrirModalLiberacao(ref) {
        const modal = document.getElementById("myAppModal");

        if (!modal) {
            toast("error", "Modal principal não encontrada.");
            return;
        }

        modal.classList.remove("modal-arquivos-container");
        mostrarLoading(true);

        try {
            const resposta = await fetch(
                route("dispositivos/desenvolvimento/liberacao/" + ref),
                { headers: { "X-Requested-With": "XMLHttpRequest" } }
            );

            if (!resposta.ok) {
                toast("error", "Não foi possível abrir a liberação.");
                return;
            }

            modal.innerHTML = await resposta.text();
            modal.showModal();

            const campo = document.getElementById("mensagemLiberacao");

            if (campo) {
                campo.focus();
            }
        } catch (erro) {
            console.error("Erro ao abrir modal de liberacao:", erro);
            toast("error", "Erro de conexão ao carregar a liberação.");
        } finally {
            mostrarLoading(false);
        }
    }

    // Exposta no escopo global: o botao "Liberar SL" chama por onclick
    window.abrirModalLiberacao = abrirModalLiberacao;

    /* ------------- 1b. modal de motivo (retornar / cancelar) ------------- */

    async function abrirModalMotivo(ref, acao) {
        const modal = document.getElementById("myAppModal");

        if (!modal) {
            toast("error", "Modal principal não encontrada.");
            return;
        }

        modal.classList.remove("modal-arquivos-container");
        mostrarLoading(true);

        try {
            const resposta = await fetch(
                route("dispositivos/desenvolvimento/motivo-etapa/" + ref) +
                    "?acao=" + encodeURIComponent(acao),
                { headers: { "X-Requested-With": "XMLHttpRequest" } }
            );

            if (!resposta.ok) {
                toast("error", "Não foi possível abrir a janela.");
                return;
            }

            modal.innerHTML = await resposta.text();
            modal.showModal();

            const campo = document.getElementById("mensagemMotivoEtapa");

            if (campo) {
                campo.focus();
            }
        } catch (erro) {
            console.error("Erro ao abrir modal de motivo:", erro);
            toast("error", "Erro de conexão ao carregar a janela.");
        } finally {
            mostrarLoading(false);
        }
    }

    // Exposta no global: o botao "Retornar SL" chama por onclick
    window.abrirModalMotivo = abrirModalMotivo;

    /* Envio da modal de motivo (retornar/cancelar) — POST no data-url */
    document.addEventListener("submit", async function (evento) {
        const form = evento.target;

        if (!form || form.id !== "formMotivoEtapa") {
            return;
        }

        evento.preventDefault();

        const campo = form.querySelector("[name='mensagem']");
        const botao = form.querySelector("#btnConfirmarMotivoEtapa");
        const url = form.dataset.url;
        const mensagem = (campo && campo.value ? campo.value : "").trim();

        if (mensagem === "") {
            campo.classList.add("is-invalid");
            campo.focus();
            toast("error", "Descreva o motivo antes de confirmar.");
            return;
        }

        campo.classList.remove("is-invalid");

        if (botao) {
            botao.disabled = true;
        }

        mostrarLoading(true);

        const { ok, dados } = await postJson(url, { mensagem: mensagem });

        if (!ok) {
            mostrarLoading(false);

            if (botao) {
                botao.disabled = false;
            }

            toast("error", dados.message || "Não foi possível concluir a ação.");
            return;
        }

        fecharModal();
        toast("success", dados.message || "Feito.");

        setTimeout(function () {
            window.location.reload();
        }, 1200);
    });

    /* ------------- 2. interceptacao do select de status (Liberacao/Aquisicao) */

    const gerenciarOriginal = window.gerenciarMudancaStatus;

    /**
     * Liberacao -> OK  e  Aquisicao -> OK nao podem ser gravados direto:
     *   - Liberacao exige a consideracao digitada na modal
     *   - Aquisicao exige todos os itens liquidados
     * Qualquer outra combinacao segue pela funcao original, intacta.
     */
    window.gerenciarMudancaStatus = function (selectElement) {
        const coluna = selectElement.getAttribute("data-coluna");
        const ref = selectElement.getAttribute("data-id");
        const valor = (selectElement.value || "").toUpperCase();

        if (coluna === "liberacao_status" && valor === "OK") {
            // Desfaz a selecao visual: quem confirma e a modal
            selectElement.value = selectElement.dataset.valorAnterior || "PENDENTE";
            mostrarLoading(false);
            abrirModalLiberacao(ref);
            return;
        }

        if (coluna === "aquisicao_status" && valor === "OK") {
            selectElement.value = selectElement.dataset.valorAnterior || "PENDENTE";
            mostrarLoading(false);
            concluirAquisicao(ref);
            return;
        }

        // Corte/Execução -> CANCELADO: cancela a SL inteira (pede motivo na modal)
        if (
            (coluna === "corte_status" || coluna === "exec_status") &&
            valor === "CANCELADO"
        ) {
            selectElement.value = selectElement.dataset.valorAnterior || selectElement.value;
            mostrarLoading(false);
            abrirModalMotivo(ref, "cancelar");
            return;
        }

        if (typeof gerenciarOriginal === "function") {
            gerenciarOriginal(selectElement);
        }
    };

    // Guarda o valor anterior de cada select para conseguir reverter a selecao
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll(".select-status").forEach(function (select) {
            select.dataset.valorAnterior = select.value;

            select.addEventListener("focus", function () {
                select.dataset.valorAnterior = select.value;
            });
        });
    });

    /* ---------------------------------- 3. envio da modal de liberacao */

    document.addEventListener("submit", async function (evento) {
        const form = evento.target;

        if (!form || form.id !== "formLiberacaoSl") {
            return;
        }

        evento.preventDefault();

        const ref = form.dataset.ref;
        const campo = form.querySelector("[name='mensagem']");
        const botao = form.querySelector("#btnConfirmarLiberacao");
        const mensagem = (campo && campo.value ? campo.value : "").trim();

        if (mensagem === "") {
            campo.classList.add("is-invalid");
            campo.focus();
            toast("error", "Descreva a liberação antes de confirmar.");
            return;
        }

        campo.classList.remove("is-invalid");

        if (botao) {
            botao.disabled = true;
        }

        mostrarLoading(true);

        const { ok, dados } = await postJson(
            route("dispositivos/desenvolvimento/liberacao/" + ref),
            { mensagem: mensagem }
        );

        if (!ok) {
            mostrarLoading(false);

            if (botao) {
                botao.disabled = false;
            }

            toast("error", dados.message || "Não foi possível liberar a SL.");
            return;
        }

        fecharModal();
        toast("success", dados.message || "SL liberada.");

        setTimeout(function () {
            window.location.reload();
        }, 1200);
    });

    /* ------------------------------------------- 4. aquisicao: pesquisa */

    /**
     * Filtra as linhas de itens comprados por codigo, descricao, OC ou pedido.
     * A pesquisa e local (a lista de itens de uma SL e pequena) e serve para
     * o comprador achar rapido a linha que vai receber o numero do pedido.
     */
    function filtrarItens() {
        const campo = document.getElementById("pesquisaItemAquisicao");
        const corpo = document.getElementById("tbodyItensAquisicao");

        if (!campo || !corpo) {
            return;
        }

        const termo = campo.value.trim().toLowerCase();
        let visiveis = 0;

        corpo.querySelectorAll("tr[data-item-id]").forEach(function (linha) {
            const texto = (linha.dataset.busca || "").toLowerCase();
            const combina = termo === "" || texto.indexOf(termo) !== -1;

            linha.hidden = !combina;

            if (combina) {
                visiveis++;
            }
        });

        const vazio = document.getElementById("itensAquisicaoVazio");

        if (vazio) {
            vazio.hidden = visiveis !== 0;
        }
    }

    document.addEventListener("input", function (evento) {
        if (evento.target && evento.target.id === "pesquisaItemAquisicao") {
            filtrarItens();
        }
    });

    // Enter na pesquisa foca o campo de OC da primeira linha visivel
    document.addEventListener("keydown", function (evento) {
        if (
            !evento.target ||
            evento.target.id !== "pesquisaItemAquisicao" ||
            evento.key !== "Enter"
        ) {
            return;
        }

        evento.preventDefault();

        const primeira = document.querySelector(
            "#tbodyItensAquisicao tr[data-item-id]:not([hidden]) input[data-campo='n_oc']"
        );

        if (primeira) {
            primeira.focus();
            primeira.select();
        }
    });

    /* --------------------------------- 4b. aquisicao: salvar um item */

    function atualizarResumo(resumo, podeFinalizar) {
        const alvoTotal = document.getElementById("resumoTotalItens");
        const alvoLiquidados = document.getElementById("resumoLiquidados");
        const alvoPendentes = document.getElementById("resumoPendentes");
        const botao = document.getElementById("btnConcluirAquisicao");
        const barra = document.getElementById("barraLiquidacao");

        if (!resumo) {
            return;
        }

        if (alvoTotal) {
            alvoTotal.textContent = resumo.total;
        }

        if (alvoLiquidados) {
            alvoLiquidados.textContent = resumo.liquidados;
        }

        if (alvoPendentes) {
            alvoPendentes.textContent = resumo.pendentes;
        }

        if (barra && resumo.total > 0) {
            const percentual = Math.round((resumo.liquidados / resumo.total) * 100);
            barra.style.width = percentual + "%";
            barra.setAttribute("aria-valuenow", String(percentual));
            barra.textContent = percentual + "%";
        }

        if (botao) {
            botao.disabled = !podeFinalizar;
            botao.title = podeFinalizar
                ? "Todos os itens liquidados — pode concluir"
                : "Liquide todos os itens para concluir a aquisição";
        }
    }

    /**
     * Grava a OC digitada. Apenas a OC — o pedido e a liquidacao sao
     * preenchidos pela rotina de consulta ao Logix, nunca pela tela.
     */
    async function salvarOc(linha) {
        const id = linha.dataset.itemId;
        const inputOc = linha.querySelector("input[data-campo='n_oc']");
        const nOc = inputOc ? inputOc.value.trim() : "";

        linha.classList.add("linha-salvando");

        const { ok, dados } = await postJson(
            route("dispositivos/desenvolvimento/aquisicao/item/" + id + "/store"),
            { n_oc: nOc }
        );

        linha.classList.remove("linha-salvando");

        if (!ok) {
            // Devolve o campo ao ultimo valor confirmado pelo servidor
            if (inputOc) {
                inputOc.value = inputOc.dataset.valorOriginal || "";
            }

            toast("error", dados.message || "Não foi possível salvar a OC.");
            return;
        }

        // Trocar a OC invalida o pedido/liquidacao da OC anterior:
        // a tela reflete isso ate a rotina consultar de novo.
        const celulaPedido = linha.querySelector("[data-label='Pedido']");
        const selo = linha.querySelector("[data-selo-status]");

        if (celulaPedido) {
            celulaPedido.innerHTML = nOc === ""
                ? "--"
                : '<span class="text-muted fst-italic fs-8">aguardando Logix</span>';
        }

        if (selo) {
            selo.textContent = "Pendente";
            selo.className = "badge bg-secondary";
        }

        linha.dataset.busca = [
            linha.dataset.codigo || "",
            linha.dataset.descricao || "",
            nOc
        ].join(" ");

        atualizarResumo(dados.resumo, dados.podeFinalizar);
        toast("success", dados.message || "OC gravada.");
    }

    // Grava ao sair do campo, e so se o valor mudou
    document.addEventListener(
        "blur",
        function (evento) {
            const alvo = evento.target;

            if (!alvo || !alvo.matches || !alvo.matches("[data-campo='n_oc']")) {
                return;
            }

            const linha = alvo.closest("tr[data-item-id]");

            if (!linha) {
                return;
            }

            if (alvo.value.trim() === (alvo.dataset.valorOriginal || "")) {
                return;
            }

            alvo.dataset.valorOriginal = alvo.value.trim();
            salvarOc(linha);
        },
        true
    );

    // Enter confirma a OC sem precisar sair do campo
    document.addEventListener("keydown", function (evento) {
        const alvo = evento.target;

        if (!alvo || !alvo.matches || !alvo.matches("[data-campo='n_oc']")) {
            return;
        }

        if (evento.key === "Enter") {
            evento.preventDefault();
            alvo.blur();
        }
    });

    /* --------------------------------- 5. concluir a etapa de aquisicao */

    async function concluirAquisicao(ref) {
        mostrarLoading(true);

        const { ok, dados } = await postJson(
            route("dispositivos/desenvolvimento/aquisicao/" + ref + "/concluir"),
            {}
        );

        if (!ok) {
            mostrarLoading(false);

            if (dados.resumo) {
                atualizarResumo(dados.resumo, false);
            }

            toast("error", dados.message || "Não foi possível concluir a aquisição.");
            return;
        }

        toast("success", dados.message || "Aquisição concluída.");

        setTimeout(function () {
            window.location.reload();
        }, 1200);
    }

    window.concluirAquisicao = concluirAquisicao;

    document.addEventListener("click", function (evento) {
        const botao = evento.target.closest
            ? evento.target.closest("#btnConcluirAquisicao")
            : null;

        if (!botao || botao.disabled) {
            return;
        }

        evento.preventDefault();
        concluirAquisicao(botao.dataset.ref);
    });

    /* ------------- 5b. BYPASS de teste: concluir sem liquidar ------------- */

    async function bypassAquisicao(ref) {
        mostrarLoading(true);

        const { ok, dados } = await postJson(
            route("dispositivos/desenvolvimento/aquisicao/" + ref + "/concluir-bypass"),
            {}
        );

        if (!ok) {
            mostrarLoading(false);
            toast("error", dados.message || "Não foi possível pular a liquidação.");
            return;
        }

        toast("success", dados.message || "Aquisição concluída (teste).");

        setTimeout(function () {
            window.location.reload();
        }, 1200);
    }

    document.addEventListener("click", function (evento) {
        const botao = evento.target.closest
            ? evento.target.closest("#btnBypassAquisicao")
            : null;

        if (!botao || botao.disabled) {
            return;
        }

        evento.preventDefault();

        // Confirmação: é um atalho de teste que ignora a regra de liquidação
        const confirmar = window.confirm(
            "TESTE: concluir a aquisição desta SL SEM exigir a liquidação dos itens?\n\n" +
            "A ação fica registrada no histórico com a sua matrícula."
        );

        if (confirmar) {
            bypassAquisicao(botao.dataset.ref);
        }
    });

    /* Guarda o valor original das OCs no carregamento */
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll("[data-campo='n_oc']").forEach(function (input) {
            input.dataset.valorOriginal = input.value.trim();
        });

        filtrarItens();
    });
})();
