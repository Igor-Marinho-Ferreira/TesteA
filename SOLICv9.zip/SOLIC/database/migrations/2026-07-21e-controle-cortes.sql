-- ============================================================================
--  2026-07-21 (5ª rodada) - Controle de Cortes de Peças
--
--  Hoje a web só guarda o ARQUIVO do pacote DXF (solicitacao_anexo_arquivos,
--  tipo = 'PACOTE_DXF', codigo = 'DX0001'). Os metadados (prioridade, status
--  de corte, NEST, observações) e os PLANOS DE CORTE existem só no Access.
--  Estas tabelas trazem isso para a web.
--
--  Campos derivados (NÃO viram coluna):
--    Projeto    = vagao + '_' + lote  (da fila)
--    Projetista = detalhamento_proj ou conceito_proj (da fila)
--    Cod Z / SL / Descrição = da fila
--    IMG / DXF  = flags calculadas a partir dos anexos
--
--  Rodar UMA vez.
-- ============================================================================

-- 1) Controle por pacote DXF --------------------------------------------------
CREATE TABLE IF NOT EXISTS bd_device_request.dxf_controle (
    id             CHAR(36)     NOT NULL,
    codigo         VARCHAR(30)  NOT NULL,          -- DX5064
    ref            INT          NULL,              -- SL de origem
    descricao      VARCHAR(255) NULL,              -- sobrescreve a da SL, se preenchida
    nest           VARCHAR(60)  NULL,              -- digitado
    prioridade     VARCHAR(30)  NULL,              -- 01-Alta / 02-Média / 03-Baixa
    status_corte   VARCHAR(40)  NOT NULL DEFAULT 'AGUARDANDO',
    observacoes    TEXT         NULL,
    dxf_inserido_em DATETIME    NULL,
    created_at     DATETIME     NULL,
    created_by     VARCHAR(120) NULL,
    updated_at     DATETIME     NULL,
    updated_by     VARCHAR(120) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_dxf_controle_codigo (codigo),
    KEY idx_dxf_controle_ref (ref),
    KEY idx_dxf_controle_status (status_corte)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 2) Planos de corte (linhas da grade) ---------------------------------------
CREATE TABLE IF NOT EXISTS bd_device_request.dxf_planos_corte (
    id            CHAR(36)     NOT NULL,
    dxf_codigo    VARCHAR(30)  NOT NULL,           -- DX5064
    n_prog        VARCHAR(60)  NULL,               -- T04567.
    espessura     VARCHAR(30)  NULL,               -- 6,35 / 4,75 Xd  (texto: nem sempre é número)
    largura       INT          NULL,
    comprimento   INT          NULL,
    qtde          INT          NULL,
    tempo         TIME         NULL,               -- 00:25:00
    reserva       VARCHAR(60)  NULL,               -- 5788892
    cortado       TINYINT(1)   NOT NULL DEFAULT 0, -- coluna "Corte? OK"
    ordem         INT          NOT NULL DEFAULT 0,
    created_at    DATETIME     NULL,
    created_by    VARCHAR(120) NULL,
    updated_at    DATETIME     NULL,
    updated_by    VARCHAR(120) NULL,
    PRIMARY KEY (id),
    KEY idx_planos_dxf (dxf_codigo),
    KEY idx_planos_ordem (dxf_codigo, ordem)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 3) Parametrização das espessuras -------------------------------------------
CREATE TABLE IF NOT EXISTS bd_device_request.espessuras (
    id         CHAR(36)     NOT NULL,
    valor      VARCHAR(30)  NOT NULL,              -- 6,35 / 3,00 / 4,75 Xd / 9,50
    descricao  VARCHAR(120) NULL,
    created_at DATETIME     NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_espessuras_valor (valor)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Espessuras que aparecem na tela do Access (ponto de partida).
-- INSERT IGNORE: rodar de novo não duplica.
INSERT IGNORE INTO bd_device_request.espessuras (id, valor, created_at) VALUES
    (UUID(), '3,00',     NOW()),
    (UUID(), '4,75 Xd',  NOW()),
    (UUID(), '6,35',     NOW()),
    (UUID(), '9,50',     NOW());


-- ============================================================================
--  ROLLBACK
-- ----------------------------------------------------------------------------
--  DROP TABLE IF EXISTS bd_device_request.dxf_planos_corte;
--  DROP TABLE IF EXISTS bd_device_request.dxf_controle;
--  DROP TABLE IF EXISTS bd_device_request.espessuras;
-- ============================================================================
