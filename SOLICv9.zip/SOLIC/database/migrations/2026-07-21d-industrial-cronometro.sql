-- ============================================================================
--  2026-07-21 (4ª rodada) - Tela Industrial + cronômetro nas demais etapas
--
--  1) data_entrega  -> campo novo, preenchido pelo industrial
--  2) cronômetro (mesmo modelo de corte/execução) para AQUISIÇÃO e TRYOUT
--
--  Conceito e Detalhamento NÃO ganham colunas: o "tempo corrido" deles é
--  derivado das colunas que já existem (conceito_inicio/fim, detalhamento_
--  inicio/fim) e é exibido AO LADO do cálculo de dias úteis atual, que
--  continua intacto.
--
--  Só ALTER TABLE / ADD COLUMN. Rodar UMA vez.
-- ============================================================================

-- 1) Data de entrega (industrial) --------------------------------------------
ALTER TABLE bd_device_request.fila
    ADD COLUMN data_entrega DATE NULL;


-- 2) Cronômetro da AQUISIÇÃO --------------------------------------------------
--    aquisicao_data já existe e não é tocada (usada na sincronização Access).
ALTER TABLE bd_device_request.fila
    ADD COLUMN aquisicao_inicio      DATETIME NULL,
    ADD COLUMN aquisicao_fim         DATETIME NULL,
    ADD COLUMN aquisicao_tempo       INT      NOT NULL DEFAULT 0,
    ADD COLUMN aquisicao_retomado_em DATETIME NULL;


-- 3) Cronômetro do TRYOUT -----------------------------------------------------
--    tryout_data já existe e não é tocada.
ALTER TABLE bd_device_request.fila
    ADD COLUMN tryout_inicio      DATETIME NULL,
    ADD COLUMN tryout_fim         DATETIME NULL,
    ADD COLUMN tryout_tempo       INT      NOT NULL DEFAULT 0,
    ADD COLUMN tryout_retomado_em DATETIME NULL;


-- ============================================================================
--  ROLLBACK
-- ----------------------------------------------------------------------------
--  ALTER TABLE bd_device_request.fila
--      DROP COLUMN data_entrega,
--      DROP COLUMN aquisicao_inicio,
--      DROP COLUMN aquisicao_fim,
--      DROP COLUMN aquisicao_tempo,
--      DROP COLUMN aquisicao_retomado_em,
--      DROP COLUMN tryout_inicio,
--      DROP COLUMN tryout_fim,
--      DROP COLUMN tryout_tempo,
--      DROP COLUMN tryout_retomado_em;
-- ============================================================================
