-- ============================================================================
--  2026-07-21 (3ª rodada) - Cronometragem de Corte e Execução
--
--  Modelo: tempo decorrido REAL com pausa.
--    ANDAMENTO / TERCEIRIZADO  -> conta o tempo (retoma)
--    PARADO / AGUARDANDO       -> pausa (acumula o intervalo e para)
--    FINALIZADO                -> fecha o fim (acumula o último intervalo)
--    CANCELADO                 -> cancela a SL (não mexe no tempo)
--
--  Colunas por etapa:
--    {etapa}_inicio      -> 1ª vez que entrou em contagem
--    {etapa}_fim         -> quando finalizou
--    {etapa}_tempo       -> tempo acumulado em SEGUNDOS (só os intervalos ativos)
--    {etapa}_retomado_em -> início do intervalo ativo atual (NULL = pausado)
--
--  Só ALTER TABLE / ADD COLUMN. Rodar UMA vez.
-- ============================================================================

ALTER TABLE bd_device_request.fila
    ADD COLUMN corte_inicio      DATETIME NULL           AFTER corte_data,
    ADD COLUMN corte_fim         DATETIME NULL           AFTER corte_inicio,
    ADD COLUMN corte_tempo       INT      NOT NULL DEFAULT 0 AFTER corte_fim,
    ADD COLUMN corte_retomado_em DATETIME NULL           AFTER corte_tempo;

ALTER TABLE bd_device_request.fila
    ADD COLUMN exec_inicio      DATETIME NULL            AFTER exec_data,
    ADD COLUMN exec_fim         DATETIME NULL            AFTER exec_inicio,
    ADD COLUMN exec_tempo       INT      NOT NULL DEFAULT 0 AFTER exec_fim,
    ADD COLUMN exec_retomado_em DATETIME NULL            AFTER exec_tempo;


-- ============================================================================
--  ROLLBACK
-- ----------------------------------------------------------------------------
--  ALTER TABLE bd_device_request.fila
--      DROP COLUMN corte_inicio,
--      DROP COLUMN corte_fim,
--      DROP COLUMN corte_tempo,
--      DROP COLUMN corte_retomado_em,
--      DROP COLUMN exec_inicio,
--      DROP COLUMN exec_fim,
--      DROP COLUMN exec_tempo,
--      DROP COLUMN exec_retomado_em;
-- ============================================================================
