-- ============================================================================
--  2026-07-21 - Aquisicao / Liberacao de SL
--
--  n_oc            -> digitado manualmente pelo comprador
--  pedido          -> preenchido pela rotina de consulta ao Logix
--  liquidado       -> atualizado pela rotina de consulta ao Logix
--  sincronizado_em -> data/hora da ultima consulta ao Logix
--
--  Rodar UMA vez.
-- ============================================================================

ALTER TABLE bd_device_request.solicitacao_itens_comprados
    ADD COLUMN n_oc            VARCHAR(60)  NULL          AFTER tipo,
    ADD COLUMN pedido          VARCHAR(60)  NULL          AFTER n_oc,
    ADD COLUMN liquidado       TINYINT(1)   NOT NULL DEFAULT 0 AFTER pedido,
    ADD COLUMN liquidado_em    DATETIME     NULL          AFTER liquidado,
    ADD COLUMN sincronizado_em DATETIME     NULL          AFTER liquidado_em,
    ADD COLUMN updated_by      VARCHAR(120) NULL          AFTER sincronizado_em,
    ADD COLUMN updated_at      DATETIME     NULL          AFTER updated_by;

ALTER TABLE bd_device_request.solicitacao_itens_comprados
    ADD INDEX idx_itens_comprados_ref (ref);

ALTER TABLE bd_device_request.solicitacao_itens_comprados
    ADD INDEX idx_itens_comprados_n_oc (n_oc);


-- ============================================================================
--  ROLLBACK
-- ----------------------------------------------------------------------------
--  ALTER TABLE bd_device_request.solicitacao_itens_comprados
--      DROP COLUMN n_oc,
--      DROP COLUMN pedido,
--      DROP COLUMN liquidado,
--      DROP COLUMN liquidado_em,
--      DROP COLUMN sincronizado_em,
--      DROP COLUMN updated_by,
--      DROP COLUMN updated_at,
--      DROP INDEX idx_itens_comprados_ref,
--      DROP INDEX idx_itens_comprados_n_oc;
-- ============================================================================
