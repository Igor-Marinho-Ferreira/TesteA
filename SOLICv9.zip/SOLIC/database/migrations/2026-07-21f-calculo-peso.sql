-- ============================================================================
--  2026-07-21 (6ª rodada) - Cálculo de Peso / Consolidado por Espessura
--
--  1) espessuras: densidade + peso da chapa padrão (para a compra)
--  2) perfis: cadastro dos perfis lineares (Tubo, Viga W, Perfil U, ...) com
--     o peso por metro, alimentando a calculadora de perfis
--
--  O consolidado por espessura NÃO precisa de tabela nova: ele lê os planos
--  de corte já existentes (dxf_planos_corte, da 5ª rodada) e agrupa por
--  espessura, calculando área e peso teórico.
--
--  Só ALTER TABLE / ADD COLUMN / CREATE TABLE. Rodar UMA vez.
-- ============================================================================

-- 1) Espessuras: densidade e peso da chapa padrão -----------------------------
--    Idempotente via procedure (ADD COLUMN não aceita IF NOT EXISTS no MySQL).
DELIMITER //

DROP PROCEDURE IF EXISTS bd_device_request.sp_mig_calc_peso //

CREATE PROCEDURE bd_device_request.sp_mig_calc_peso()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = 'bd_device_request'
          AND TABLE_NAME   = 'espessuras'
          AND COLUMN_NAME  = 'densidade'
    ) THEN
        ALTER TABLE bd_device_request.espessuras
            ADD COLUMN densidade DECIMAL(10,2) NOT NULL DEFAULT 7860.00 AFTER descricao;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = 'bd_device_request'
          AND TABLE_NAME   = 'espessuras'
          AND COLUMN_NAME  = 'peso_chapa_padrao'
    ) THEN
        ALTER TABLE bd_device_request.espessuras
            ADD COLUMN peso_chapa_padrao DECIMAL(12,3) NULL AFTER densidade;
    END IF;
END //

DELIMITER ;

CALL bd_device_request.sp_mig_calc_peso();
DROP PROCEDURE IF EXISTS bd_device_request.sp_mig_calc_peso;


-- 2) Perfis lineares ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS bd_device_request.perfis (
    id             CHAR(36)      NOT NULL,
    tipo           VARCHAR(40)   NOT NULL,   -- TUBO_RET / VIGA_W / PERFIL_U / BARRA / FUSO / TUBO / CANTONEIRA / BR_CHATA / BR_QUADRADA
    descricao      VARCHAR(120)  NULL,       -- bitola / dimensão (ex.: 50x30x2)
    peso_por_metro DECIMAL(12,4) NOT NULL DEFAULT 0,  -- kg/m
    densidade      DECIMAL(10,2) NULL,       -- opcional, se o peso vier da geometria
    created_at     DATETIME      NULL,
    PRIMARY KEY (id),
    KEY idx_perfis_tipo (tipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================================
--  ROLLBACK
-- ----------------------------------------------------------------------------
--  ALTER TABLE bd_device_request.espessuras
--      DROP COLUMN densidade,
--      DROP COLUMN peso_chapa_padrao;
--  DROP TABLE IF EXISTS bd_device_request.perfis;
-- ============================================================================
