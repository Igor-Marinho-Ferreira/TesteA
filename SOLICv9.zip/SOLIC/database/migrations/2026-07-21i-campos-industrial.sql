-- ============================================================================
--  2026-07-21 (9ª rodada) - Garante os campos do INDUSTRIAL na tabela fila
--
--  Os campos # Pasta, Equipe, Setor, Natureza e Descrição do Serviço eram
--  lidos de forma defensiva (?? '') no código; se algum não existisse como
--  coluna, o UPDATE que salva os dados do industrial falhava por inteiro
--  (era o motivo de "não salvar"). data_entrega já veio na migration d, mas
--  entra aqui também com guarda, para o caso de a d não ter sido rodada.
--
--  Idempotente: ADD COLUMN só se não existir. Rodar UMA vez.
-- ============================================================================

DELIMITER //

DROP PROCEDURE IF EXISTS bd_device_request.sp_mig_campos_industrial //

CREATE PROCEDURE bd_device_request.sp_mig_campos_industrial()
BEGIN
    DECLARE add_col TEXT;

    -- n_pasta
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA='bd_device_request' AND TABLE_NAME='fila' AND COLUMN_NAME='n_pasta') THEN
        ALTER TABLE bd_device_request.fila ADD COLUMN n_pasta VARCHAR(60) NULL;
    END IF;

    -- natureza
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA='bd_device_request' AND TABLE_NAME='fila' AND COLUMN_NAME='natureza') THEN
        ALTER TABLE bd_device_request.fila ADD COLUMN natureza VARCHAR(120) NULL;
    END IF;

    -- descricaoservico
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA='bd_device_request' AND TABLE_NAME='fila' AND COLUMN_NAME='descricaoservico') THEN
        ALTER TABLE bd_device_request.fila ADD COLUMN descricaoservico VARCHAR(255) NULL;
    END IF;

    -- equipeei
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA='bd_device_request' AND TABLE_NAME='fila' AND COLUMN_NAME='equipeei') THEN
        ALTER TABLE bd_device_request.fila ADD COLUMN equipeei VARCHAR(60) NULL;
    END IF;

    -- setor_pendencia
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA='bd_device_request' AND TABLE_NAME='fila' AND COLUMN_NAME='setor_pendencia') THEN
        ALTER TABLE bd_device_request.fila ADD COLUMN setor_pendencia VARCHAR(60) NULL;
    END IF;

    -- data_entrega (defensivo — já criada na migration d)
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA='bd_device_request' AND TABLE_NAME='fila' AND COLUMN_NAME='data_entrega') THEN
        ALTER TABLE bd_device_request.fila ADD COLUMN data_entrega DATE NULL;
    END IF;
END //

DELIMITER ;

CALL bd_device_request.sp_mig_campos_industrial();
DROP PROCEDURE IF EXISTS bd_device_request.sp_mig_campos_industrial;

-- ============================================================================
--  ROLLBACK (só o que realmente não existia antes — avalie antes de rodar)
-- ----------------------------------------------------------------------------
--  ALTER TABLE bd_device_request.fila
--      DROP COLUMN n_pasta, DROP COLUMN natureza, DROP COLUMN descricaoservico,
--      DROP COLUMN equipeei, DROP COLUMN setor_pendencia;
-- ============================================================================
