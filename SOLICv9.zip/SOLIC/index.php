<?php

require_once __DIR__ . "/vendor/autoload.php";

/**
 * Em PHP mais novo, algumas libs antigas geram Deprecated.
 * Isso mantém erro real aparecendo, mas esconde Deprecated.
 */
ini_set('display_errors', true);
ini_set('display_startup_errors', true);
error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED);

initSessionIfNotStarted();

/**
 * Sessão fake para ambiente DEV.
 * Remover/comentar quando o SSO estiver funcionando.
 */
if (empty($_SESSION['usuarioLogin'])) {
    $_SESSION['access_token'] = 'fake-access-token-dev';
    $_SESSION['username']     = 'higor.silva';

    $_SESSION['usuarioID']    = '999999';
    $_SESSION['usuarioLogin'] = '999999';
    $_SESSION['usuarioNome']  = 'Teste';
    $_SESSION['usuarioSenha'] = '';

    $_SESSION['usuarioEmpresa']     = '40';
    $_SESSION['usuarioCorporativo'] = 'S';
    $_SESSION['usuarioCruzeiro']    = 'N';

    $_SESSION['paginaAtualID']             = null;
    $_SESSION['paginaAtualEndereco']       = null;
    $_SESSION['paginaAnteriorID']          = null;
    $_SESSION['paginaAnteriorEndereco']    = null;

    $_SESSION['user'] = [
        'empresa'      => '40',
        'codigo'       => '999999',
        'nome'         => 'Teste',
        'login'        => '999999',
        'matricula'    => '123456',
        'area'         => 'TI',
        'centro_custo' => '5138',
        'unidade'      => 'Sumaré',
        'ramal'        => '0000',
        'email'        => 'higor.dev@empresa.com.br',
    ];
}

$dotenv = Dotenv\Dotenv::createMutable(__DIR__);
$dotenv->load();

src\core\Bootstrap::start();