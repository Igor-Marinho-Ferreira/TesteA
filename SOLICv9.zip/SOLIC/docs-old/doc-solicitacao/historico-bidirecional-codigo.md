# Código completo — Histórico bidirecional

Companheiro de [historico-bidirecional.md](historico-bidirecional.md).

Índice:
1. PHP — `routes.php` (rota)
2. PHP — `SolicitacaoController::comentarVba`
3. VBA — `Funcoes` → `comentarMySQL`
4. VBA — `frmsol` → `btn_enviar_Click`
5. VBA — `sincronizarDoMySQL` (insert-only → upsert)

---

## 1. PHP — `src/routes/routes.php`

**Adicionado** após a rota `uploadAnexoVba`:

```php
//COMENTÁRIO (histórico) vindo do Access -> insere 1 linha na tabela historico   [ADICIONADO]
Route::post('/dispositivos/solicitacao/comentarVba', SolicitacaoController::class, 'comentarVba')
    ->name('dispositivos.solicitacao.comentarVba');
```

---

## 2. PHP — `SolicitacaoController::comentarVba`

Método novo:

```php
    /**
     * Recebe um comentário do Access e insere UMA linha em historico.
     * O texto completo é remontado por getAllTratado (não sobrescreve nada).
     * POST: ref, usuario, mensagem
     */
    function comentarVba()
    {
        $ref      = (int) (Request::input('ref') ?? 0);
        $usuario  = Request::input('usuario') ?? '';
        $mensagem = Request::input('mensagem') ?? '';

        if ($ref <= 0 || trim($mensagem) === '') {
            return Json::return(['error' => 'ref ou mensagem inválidos'], 400);
        }

        Historico::create([
            'ref'      => $ref,
            'usuario'  => $usuario,
            'mensagem' => $mensagem,
        ]);

        return Json::return(['ok' => true], 200);
    }
```

---

## 3. VBA — módulo `Funcoes` → `comentarMySQL`

Função nova:

```vba
' Envia um comentário para o histórico do web (tabela historico). Retorna True se OK.
Function comentarMySQL(ByVal ref As Long, ByVal usuario As String, ByVal mensagem As String) As Boolean
    Dim http As Object, url As String, body As String
    comentarMySQL = False
    If Trim(mensagem) = "" Then Exit Function

    url = urlBaseApp() & "/dispositivos/solicitacao/comentarVba"
    body = "ref=" & ref & "&usuario=" & enc(usuario) & "&mensagem=" & enc(mensagem)

    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send body

    If http.Status = 200 Then
        comentarMySQL = True
    Else
        MsgBox "Falha ao enviar comentário (" & http.Status & "): " & http.responseText, vbExclamation
    End If
End Function
```

> O `Funcoes` completo está em [sincronizacao-mysql-access-codigo.md](sincronizacao-mysql-access-codigo.md) (seção 2).

---

## 4. VBA — `frmsol` → `btn_enviar_Click`

### ANTES
```vba
Private Sub btn_enviar_Click()
msg_hist = frmsol.txt_historico.Text
msg = frmsol.txt_msg.Text
If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf
autor = frmsol.lbl_solic.Caption
cabec = "-- " & autor & " (" & ... & "):" & vbCrLf
hist = hist & cabec & msg
frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""
Dim SQL As String
ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text
SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)
End Sub
```

### DEPOIS
```vba
Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.lbl_solic.Caption
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)

comentarMySQL ref, autor, msg    ' [ADICIONADO] manda o comentário pro web (tabela historico)

End Sub
```

> O `frmsol` completo (com os caminhos `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\`) está em
> [anexos-mysql-access-codigo.md](anexos-mysql-access-codigo.md) (seção 3) + a linha acima.

---

## 5. VBA — `sincronizarDoMySQL` (insert-only → upsert)

A mudança: além de inserir os Refs novos, agora **atualiza o `Historico`** dos Refs existentes
(`FindFirst` + `Edit`). Sub completa:

```vba
' ===== MySQL -> Access: insere novos + ATUALIZA o histórico dos existentes =====
Sub sincronizarDoMySQL()
    Dim http As Object, csv As String
    Dim linhas() As String, cab() As String, campos() As String
    Dim i As Long, j As Long
    Dim db As Object, rs As Object, rsExist As Object
    Dim existentes As Object, ref As String, col As String, val As String
    Dim inseridos As Long, atualizados As Long
    Dim idxRef As Long, idxHist As Long, histTxt As String

    On Error GoTo ERRO

    ' 1) Baixa o CSV do MySQL
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/fila?t=" & Timer, False
    http.Send
    If http.Status <> 200 Then
        MsgBox "Erro ao buscar CSV (" & http.Status & ")", vbCritical
        Exit Sub
    End If

    csv = http.responseText
    If Len(csv) > 0 Then If AscW(Left(csv, 1)) = 65279 Then csv = Mid(csv, 2) ' remove BOM
    csv = Replace(csv, vbCrLf, vbLf)
    csv = Replace(csv, vbCr, vbLf)
    linhas = Split(csv, vbLf)
    If UBound(linhas) < 1 Then Exit Sub

    cab = Split(linhas(0), ";")

    ' índices das colunas Ref e Historico
    idxRef = -1: idxHist = -1
    For j = 0 To UBound(cab)
        If Trim(cab(j)) = "Ref" Then idxRef = j
        If Trim(cab(j)) = "Historico" Then idxHist = j
    Next j

    ' 2) Abre o Access via DAO
    Set db = OpenDatabase("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb")

    ' Refs que já existem
    Set existentes = CreateObject("Scripting.Dictionary")
    Set rsExist = db.OpenRecordset("SELECT Ref FROM Fila", 2)
    Do While Not rsExist.EOF
        existentes(CStr(rsExist.Fields(0).Value)) = True
        rsExist.MoveNext
    Loop
    rsExist.Close
    Set rsExist = Nothing

    ' 3) Recordset gravável da Fila
    Set rs = db.OpenRecordset("SELECT * FROM Fila", 2)

    inseridos = 0: atualizados = 0
    For i = 1 To UBound(linhas)
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")

            ref = ""
            If idxRef >= 0 And idxRef <= UBound(campos) Then ref = Trim(Replace(campos(idxRef), """", ""))

            If ref <> "" Then
                If Not existentes.Exists(ref) Then
                    ' ---- NOVO: insere todos os campos ----
                    rs.AddNew
                    For j = 0 To UBound(cab)
                        If j > UBound(campos) Then Exit For
                        col = Trim(cab(j))
                        val = Trim(Replace(campos(j), """", ""))
                        If col = "Historico" Then val = Replace(val, "[BR]", vbCrLf)
                        On Error Resume Next
                        If val = "" Then rs.Fields(col).Value = Null Else rs.Fields(col).Value = val
                        Err.Clear
                        On Error GoTo ERRO
                    Next j
                    rs.Update
                    existentes(ref) = True
                    inseridos = inseridos + 1
                Else
                    ' ---- EXISTENTE: atualiza só o Historico ----
                    If idxHist >= 0 And idxHist <= UBound(campos) Then
                        histTxt = Replace(Trim(Replace(campos(idxHist), """", "")), "[BR]", vbCrLf)
                        rs.FindFirst "Ref = " & ref
                        If Not rs.NoMatch Then
                            On Error Resume Next
                            rs.Edit
                            If histTxt = "" Then rs.Fields("Historico").Value = Null Else rs.Fields("Historico").Value = histTxt
                            rs.Update
                            Err.Clear
                            On Error GoTo ERRO
                            atualizados = atualizados + 1
                        End If
                    End If
                End If
            End If
        End If
    Next i

    rs.Close
    db.Close

    ' Reaplica o filtro atual para atualizar a lista na tela
    On Error Resume Next
    Select Case Range("I3").Value
        Case 1: filtro_01
        Case 2: filtro_02
        Case 3: filtro_03
        Case 4: filtro_04
        Case 5: filtro_05
        Case 6: filtro_06
        Case 7: lista_todos
        Case 0: lista_pendentes
        Case Else: lista_todos
    End Select
    On Error GoTo 0

    MsgBox "Sincronização concluída." & vbCrLf & _
           "Inseridos: " & inseridos & vbCrLf & _
           "Histórico atualizado: " & atualizados, vbInformation
    Exit Sub

ERRO:
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    If Not db Is Nothing Then db.Close
    MsgBox "Erro na sincronização: " & Err.Number & " - " & Err.Description, vbCritical
End Sub
```
