# Anexos: Access → MySQL (PDF da solicitação)

Documenta o envio do **PDF** anexado na criação da SL no **Access** para o **web (MySQL)**.
Faz par com [migracao-access-mysql.md](migracao-access-mysql.md) (dados) — aqui é a parte de **arquivos**.

> 📎 **Código completo:** [anexos-access-mysql-codigo.md](anexos-access-mysql-codigo.md).
> Próximo passo (a fazer): **MySQL → Access** (PDF criado na web aparecer na pasta do Access).

- **Servidor:** Debian `172.29.5.2`, base `bd_device_request`.
- **URL base:** `http://172.29.5.2/greenbrier/v2/solic_dispositivos`
- **Access (teste):** `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\` (pasta dos PDFs)

---

## 1. Contexto (como era)

No Access, ao criar uma SL com PDF (botão **Anexar** do `frm_novo`):
- O PDF é copiado para `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\` e, ao enviar, **renomeado** para `SL{ref}.pdf`
  (`ref` com 4 dígitos: `SL4001.pdf`).
- **Não há tabela de anexo no Access** — o arquivo é só disco, achado por convenção de nome.
- O PDF **não ia** para o web (o `salvarVba` mandava só os dados da SL).

---

## 2. Antes × Depois

| | ANTES | DEPOIS |
|---|---|---|
| PDF criado no Access ia pro web? | ❌ Não | ✅ Sim (upload por HTTP) |
| Onde fica no web | — | storage do servidor + tabela `anexos` |
| Como o web "registra" | — | `INSERT` em `bd_device_request.anexos` (`ref`, `anexo`=caminho, `descricao`) |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — rota + método `uploadAnexoVba`

- **Rota:** `POST /dispositivos/solicitacao/uploadAnexoVba` (`routes.php`).
- **Método** (`SolicitacaoController::uploadAnexoVba`):
  1. Lê `?ref=` e `?nome=` da querystring e o **corpo binário cru** (`php://input`).
  2. Salva o arquivo no storage do web (pasta por `ref`, sob `APP_UPLOADS_DIR`).
  3. Registra em `anexos` (`id` uuid, `ref`, `anexo`=caminho, `descricao`='PDF da solicitação (Access)').
  4. Retorna `{ "ok": true, "arquivo": "..." }`.

> ⚠️ Alterou o PHP local → **re-deploy** no servidor. Confirme que **`APP_UPLOADS_DIR`** no `.env`
> do servidor é uma pasta **gravável** pelo PHP (senão usa o fallback
> `/var/www/htdocs/greenbrier/v2/solic_dispositivos_files`).

### 3.2 VBA — `Funcoes` → `enviarPdfParaMySQL`

Função nova que lê os bytes do PDF (`ADODB.Stream` binário) e faz **POST** do binário cru
para a rota, com `ref` e `nome` na URL. Parâmetros **ByVal** (pra aceitar o `t_ref` Variant).

### 3.3 VBA — `frm_novo` → `btn_enviar_Click`

Depois de renomear o PDF para `.Files\SL{ref}.pdf`, chama `enviarPdfParaMySQL t_ref, caminho`
**dentro do `If lblFilePath.Caption <> ""`** (só quando há PDF anexado).

---

## 4. Fluxo

```
Access cria SL (com PDF)
   → salvarVba (dados)            → grava no MySQL (solicitacoes + fila + historico)
   → renomeia o PDF               → .Files\SL{ref}.pdf
   → enviarPdfParaMySQL           → POST binário → PHP salva no storage + registra em anexos
```

---

## 5. Passo a passo para testar

1. **Re-deploy** do `SolicitacaoController.php` (e `routes.php`) no servidor.
2. No Access, crie uma SL **anexando um PDF** (botão Anexar).
3. Confira no servidor o arquivo em `.../solic_dispositivos_files/{ref}/SL{ref}_*.pdf` e no banco:
   ```sql
   SELECT ref, anexo, descricao, created_at
     FROM bd_device_request.anexos ORDER BY created_at DESC LIMIT 5;
   ```

---

## 6. Troubleshooting

| Sintoma | Causa | Solução |
|---|---|---|
| `Tipo incompatível de argumento ByRef` | `t_ref` é Variant e a função recebia `As Long` ByRef | Parâmetros **ByVal**: `enviarPdfParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String)` |
| PHP salva no lugar errado / não grava | `APP_UPLOADS_DIR` ausente ou sem permissão | Definir `APP_UPLOADS_DIR` (pasta gravável) no `.env` do servidor |
| Não registrou em `anexos` | `ref` não existe em `fila` (FK) | A SL precisa ter sido criada (`salvarVba`) antes — ela é que cria a `fila` |

---

## 7. Limitações / próximos passos

- **Só o PDF da criação** (1 arquivo). Os anexos da fase de desenvolvimento (DXF, desenhos, etc.) são fluxo à parte.
- **Falta MySQL → Access** para arquivos (PDF criado na web aparecer na pasta do Access) — próximo passo.

---

## 8. Arquivos-chave

| Item | Caminho |
|---|---|
| Rota | `src/routes/routes.php` → `dispositivos/solicitacao/uploadAnexoVba` |
| Método | `SolicitacaoController::uploadAnexoVba` |
| Tabela | `bd_device_request.anexos` |
| VBA função | `Funcoes` → `enviarPdfParaMySQL` |
| VBA gatilho | `frm_novo` → `btn_enviar_Click` (dentro do `If lblFilePath.Caption <> ""`) |
