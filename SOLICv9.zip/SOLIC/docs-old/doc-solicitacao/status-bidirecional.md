# Status bidirecional Access ↔ MySQL

Segunda (e última) fatia do workflow: **mudança de status** nos dois sentidos
(cancelar, tryout OK/Não OK, validar, rejeitar). Continua a lógica do
[historico-bidirecional.md](historico-bidirecional.md).

> 📎 **Código 100% completo (antes/depois):** [status-bidirecional-codigo.md](status-bidirecional-codigo.md).

---

## 1. Conceito

**MySQL é a verdade.** Toda mudança de status sobe na hora (HTTP); o pull reflete de volta.
Não existe edição de campos da SL — só transições de status + comentários.

```
Access muda status (cancelar/tryout/validar/rejeitar)
   → UPDATE Fila (local) + atualizarStatusMySQL (POST) → MySQL
Web muda status → já grava no MySQL
sincronizarDoMySQL → atualiza os campos de status dos existentes
```

---

## 2. Antes × Depois

| | ANTES | DEPOIS |
|---|---|---|
| Status mudado no Access subia? | ❌ Não (só `UPDATE Fila` local) | ✅ Sim (`atualizarStatusVba`) |
| Status da web descia pro Access? | ❌ Não (upsert era só histórico) | ✅ Sim (upsert agora cobre os status) |
| Campos sincronizados no pull | `Historico` | `Historico` + `Conceito_St`, `Det_St`, `Liberacao_St`, `Corte_St`, `Exec_St`, `Aq_St`, `Tryout_St` |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — rota + `atualizarStatusVba`
- **Rota:** `POST /dispositivos/solicitacao/atualizarStatusVba`.
- **Método:** recebe `ref` + status; **whitelist** das colunas de status; `Acompanhamento::updateByRef`.

### 3.2 VBA — `Funcoes` → `atualizarStatusMySQL`
Função genérica: POST `ref` + um corpo `campo=valor&...` (valores via `enc()`). Cada botão monta o corpo.

### 3.3 VBA — `frmsol` (3 botões)
- `btnCancelarSol` → todos os status = CANCELADO.
- `btnTryout_OK` → `tryout_status=OK`.
- `btnTryout_NaoOK` (2 ramos) → `tryout_status=NÂO OK`.

### 3.4 VBA — `ufValidar` (2 botões)
- `btnValidar` → `detalhamento_status=PENDENTE` + comentário "VALIDAÇÃO".
- `btnRejeitar` → `detalhamento_status=PENDENTE` + `conceito_status=MODELO` + comentário "CONCEITO REJEITADO".

### 3.5 VBA — `sincronizarDoMySQL` (pull)
O upsert dos existentes passou a atualizar **histórico + status** (lista `colsUpd`).

---

## 4. Mapeamento status (Access → MySQL)

| Access (`Fila`) | MySQL (`fila`) |
|-----------------|----------------|
| `Conceito_St` | `conceito_status` |
| `Det_St` | `detalhamento_status` |
| `Liberacao_St` | `liberacao_status` |
| `Corte_St` | `corte_status` |
| `Exec_St` | `exec_status` |
| `Aq_St` | `aquisicao_status` |
| `Tryout_St` | `tryout_status` |

---

## 5. Passo a passo para testar

1. **Re-deploy** do `routes.php` + `SolicitacaoController.php`.
2. No Access, **cancele**/**tryout**/**valide**/**rejeite** uma SL.
3. Confira no MySQL:
   ```sql
   SELECT ref, conceito_status, detalhamento_status, tryout_status
     FROM bd_device_request.fila WHERE ref = <REF>;
   ```
4. Mude um status **pela web** e rode `sincronizarDoMySQL` → reflete no Access.

---

## 6. Limitações / escopo

- **`CKReq`** (string dos requisitos validados) **não** é sincronizado (não é status; web tem fluxo próprio).
  Para sincronizar: adicionar `ckreq` à whitelist da rota e ao `colsUpd` do pull.
- **Conflito real** só se a MESMA SL mudar status nos dois lados no mesmo segundo → vence o último a gravar no MySQL.

---

## 7. Arquivos-chave

| Item | Caminho |
|---|---|
| Rota | `src/routes/routes.php` → `dispositivos/solicitacao/atualizarStatusVba` |
| Método | `SolicitacaoController::atualizarStatusVba` |
| VBA função | `Funcoes` → `atualizarStatusMySQL` |
| VBA gatilhos | `frmsol` (cancelar/tryout) + `ufValidar` (validar/rejeitar) |
| VBA pull | `Funcoes` → `sincronizarDoMySQL` (upsert status) |
