# Histórico (comentários) bidirecional Access ↔ MySQL

Primeira fatia do sync de **workflow** (não edição de campos — esses não existem; só há criar,
cancelar, transições de status e comentários). Aqui: **comentários do histórico** nos dois sentidos.

> 📎 **Código completo:** [historico-bidirecional-codigo.md](historico-bidirecional-codigo.md).

- **Servidor:** Debian `172.29.5.2`, base `bd_device_request`.
- **Tabela:** `bd_device_request.historico` (uma linha por comentário).

---

## 1. Conceito

**MySQL é a verdade.** Comentário **acumula** (nunca sobrescreve), porque no MySQL o histórico é
uma **tabela** (1 linha por comentário, com `usuario`, `mensagem`, `created_at`).

```
Access comenta → POST → insere 1 linha em historico
Web comenta    → insere 1 linha em historico
sincronizarDoMySQL → reescreve o Historico (texto) do Access
                     com o histórico COMPLETO remontado (junta os dois lados)
```

A remontagem é feita por `Acompanhamento::getAllTratado()` (GROUP_CONCAT no formato
`-- usuário (d.m.Y - H:i): mensagem`), e desce no CSV (com `[BR]` preservando as quebras).

---

## 2. Antes × Depois

| | ANTES | DEPOIS |
|---|---|---|
| Comentário do Access ia pro web? | ❌ Não (só `UPDATE Fila SET Historico` local) | ✅ Sim (POST insere linha em `historico`) |
| Comentário da web aparecia no Access? | ❌ Não (sync era insert-only) | ✅ Sim (pull **atualiza** o histórico dos existentes) |
| Sync MySQL→Access | insert-only | **upsert** (insere novos + atualiza `Historico` dos existentes) |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — rota + `comentarVba`
- **Rota:** `POST /dispositivos/solicitacao/comentarVba`.
- **Método:** recebe `ref`, `usuario`, `mensagem` e faz `Historico::create([...])` (1 linha).
  Não sobrescreve nada; o texto completo é remontado depois pelo `getAllTratado`.

### 3.2 VBA — `Funcoes` → `comentarMySQL`
Função nova que faz POST do comentário (`ref`, `usuario`, `mensagem`). Ignora mensagem vazia.

### 3.3 VBA — `frmsol` → `btn_enviar_Click`
Depois do `UPDATE Fila SET Historico` local, chama `comentarMySQL ref, autor, msg`
(manda o comentário cru pro web).

### 3.4 VBA — `sincronizarDoMySQL` (insert-only → upsert)
- Para Ref **novo:** insere todos os campos (como antes).
- Para Ref **existente:** `FindFirst` + `Edit` e **atualiza só o `Historico`** com o texto remontado.
- O `MsgBox` final mostra "Inseridos" e "Histórico atualizado".

---

## 4. Fluxo

```
ACESSO comenta
   frmsol.btn_enviar → upQuery (local) + comentarMySQL → PHP insere linha em historico

WEB comenta
   → insere linha em historico

sincronizarDoMySQL (Access)
   novos  → insere
   existentes → atualiza o Historico (texto) com o histórico COMPLETO (os dois lados)
```

---

## 5. Passo a passo para testar

1. **Re-deploy** do `SolicitacaoController.php` + `routes.php`.
2. No Access, abra uma SL e **adicione um comentário** (`btn_enviar` do `frmsol`).
3. Confira:
   ```sql
   SELECT ref, usuario, mensagem, created_at
     FROM bd_device_request.historico ORDER BY created_at DESC LIMIT 5;
   ```
4. **Comente algo pela web** na mesma SL.
5. No Access, rode `sincronizarDoMySQL` → o `Historico` da SL deve mostrar **os dois** comentários.

---

## 6. Detalhe importante

- O upsert hoje mexe **só no `Historico`** — **não** toca nos status, de propósito: os status
  ainda não sobem do Access pro MySQL, então atualizá-los pelo pull reverteria mudanças locais.
  Quando fizermos a **fatia de status**, estendemos o upsert para os campos de status.

---

## 7. Troubleshooting

| Sintoma | Causa | Solução |
|---|---|---|
| Comentário não sobe | rota/método não deployados; `mensagem` vazia | Re-deploy; `comentarMySQL` ignora vazio |
| Comentário duplicado no Access | o texto local + o remontado | Não duplica: o pull **sobrescreve** o texto com o remontado (1x cada) |
| Pull não atualiza | `Ref` não bate / `FindFirst` sem match | Conferir que a SL existe no Access com o mesmo `Ref` |

---

## 8. Arquivos-chave

| Item | Caminho |
|---|---|
| Rota | `src/routes/routes.php` → `dispositivos/solicitacao/comentarVba` |
| Método | `SolicitacaoController::comentarVba` |
| Remontagem | `Acompanhamento::getAllTratado` (+ `$histAccess`/`[BR]` no `trataCsv`) |
| VBA função | `Funcoes` → `comentarMySQL` |
| VBA gatilho | `frmsol` → `btn_enviar_Click` |
| VBA pull | `Funcoes` → `sincronizarDoMySQL` (upsert) |
