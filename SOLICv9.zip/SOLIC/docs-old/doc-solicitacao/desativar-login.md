# Como desativamos o login do Excel/VBA (ambiente de teste)

No workbook **`Solicitação de Projeto_RevE1.xlsm`**, ao abrir, o `Workbook_Open`
chamava `frmLogin.Show` — um formulário de login **modal** que ainda **travava o
fechamento** (`UserForm_QueryClose`). Resultado: não dava pra usar a planilha nem
chegar no editor VBA sem uma senha válida do Access. Para o ambiente de teste
(`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE`) desativamos esse login.

> ⚠️ Isto é **só para o ambiente de teste**. Em produção o login deve voltar
> (seção 5).

---

## 1. Onde fica o login

| Item | Local |
|------|-------|
| Disparo | `EstaPastaDeTrabalho` → `Workbook_Open` → `frmLogin.Show` |
| Formulário | `frmLogin` (combo de nomes + senha, valida em `Solicitantes`) |
| Trava de fechar | `frmLogin` → `UserForm_QueryClose` |
| Usuário logado | gravado em `Sheets("Controle").Range("S1")` e `("D3")` |

---

## 2. Passo 1 — abrir o arquivo SEM disparar o login

Como o `Workbook_Open` mostra o login assim que o arquivo abre, primeiro precisamos
entrar sem dispará-lo. Duas formas:

**Opção A (mais simples):** segure **SHIFT** enquanto abre o arquivo — o Excel pula
o `Workbook_Open`.

**Opção B (pela Imediata):** abra um Excel **vazio** → `Alt+F11` → `Ctrl+G`
(janela Verificação Imediata) e rode:
```vba
Application.EnableEvents = False
Workbooks.Open "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\Solicitação de Projeto_RevE1.xlsm"
Application.EnableEvents = True
```
Com `EnableEvents = False` o Excel não executa o `Workbook_Open`, então o login
não aparece.

---

## 3. Passo 2 — comentar o `frmLogin.Show` e entrar direto

No editor VBA (`Alt+F11`) → **`EstaPastaDeTrabalho`** → `Workbook_Open`.
No final do procedimento:

### ANTES
```vba
    ' (carrega listas de VGs e Solicitantes...)

    frmLogin.Show
End Sub
```

### DEPOIS
```vba
    ' (carrega listas de VGs e Solicitantes...)

    'frmLogin.Show     ' login desativado (ambiente de teste)

    ' --- entra direto, sem login ---
    Sheets("Controle").Visible = True
    Sheets("PDF").Visible = True
    Sheets("Controle").Activate
    Sheets("Controle").Range("S1").Value = "Teste"
    Sheets("Controle").Range("D3").Value = "Teste"
    Call lista_pendentes
End Sub
```

O bloco novo faz o que o login fazia **depois** de autenticar: torna as planilhas
visíveis, ativa a `Controle` e grava o "usuário logado" — aqui fixo em **`"Teste"`**
(o resto do código que lê `S1`/`D3` continua funcionando normalmente).

---

## 4. Passo 3 (opcional) — liberar o fechamento do `frmLogin`

Caso o form ainda apareça em algum fluxo, o `QueryClose` não deve mais travar o X.

### ANTES (travava o fechar)
```vba
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    Cancel = True          ' impedia fechar o login pelo X
End Sub
```

### DEPOIS (permite fechar)
```vba
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = 0 Then Cancel = False
End Sub
```

Salve o workbook (mantendo `.xlsm`).

---

## 5. Como REATIVAR o login (produção)

1. Em `Workbook_Open`: **descomente** `frmLogin.Show` e **remova** o bloco
   `' --- entra direto, sem login ---`.
2. Em `frmLogin.UserForm_QueryClose`: volte a travar (`Cancel = True`) se for a regra.
3. Salve.

---

## 6. Observações

- O arquivo precisa estar em **Local Confiável** e **desbloqueado** (Mark-of-the-Web)
  pra rodar macro — ver as notas de ambiente em [00-doc-master.md](00-doc-master.md).
- O workbook **`Lista de Solicitações`** (Parte 2) **não tem login** no
  `Workbook_Open` — só este (`Solicitação`) tinha.
