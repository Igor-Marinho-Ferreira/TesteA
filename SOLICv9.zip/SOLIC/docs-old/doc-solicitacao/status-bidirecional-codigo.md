# Código completo — Status bidirecional

Companheiro de [status-bidirecional.md](status-bidirecional.md).
Código **100% completo**, com **ANTES** e **DEPOIS** de cada módulo alterado.

Índice:
1. PHP — `routes.php` (rota) + `atualizarStatusVba` (método novo)
2. VBA — `Funcoes` (ANTES / DEPOIS)
3. VBA — `frmsol` (ANTES / DEPOIS)
4. VBA — `ufValidar` (ANTES / DEPOIS)

---

## 1. PHP

### 1.1 `src/routes/routes.php` — adicionado
```php
//ATUALIZAR STATUS (cancelar/tryout/validar) vindo do Access -> UPDATE fila   [ADICIONADO]
Route::post('/dispositivos/solicitacao/atualizarStatusVba', SolicitacaoController::class, 'atualizarStatusVba')
    ->name('dispositivos.solicitacao.atualizarStatusVba');
```

### 1.2 `SolicitacaoController::atualizarStatusVba` — método novo
```php
    /**
     * Atualiza campos de status da fila vindos do Access (cancelar/tryout/validar).
     * Só aceita as colunas de status (whitelist). POST: ref + status.
     */
    function atualizarStatusVba()
    {
        $ref = (int) (Request::input('ref') ?? 0);
        if ($ref <= 0) return Json::return(['error' => 'ref inválido'], 400);

        $permitidas = [
            'conceito_status', 'detalhamento_status', 'liberacao_status',
            'corte_status', 'exec_status', 'aquisicao_status', 'tryout_status',
        ];

        $dados = [];
        foreach ($permitidas as $col) {
            $v = Request::input($col);
            if ($v !== null && $v !== '') $dados[$col] = $v;
        }
        if (empty($dados)) return Json::return(['error' => 'nenhum status enviado'], 400);

        Acompanhamento::updateByRef($ref, $dados);

        return Json::return(['ok' => true, 'campos' => array_keys($dados)], 200);
    }
```

---

## 2. VBA — módulo `Funcoes`

### 2.1 ANTES (com `comentarMySQL`; `sincronizarDoMySQL` atualizava só o histórico)

```vba
Global G_Lider As String
Global G_Solicitante As String

Function resQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

cnn.Close

End Function

Sub Reset()
Application.ScreenUpdating = True
Application.EnableEvents = True
End Sub

Sub Desabilita()
Application.ScreenUpdating = False
Application.EnableEvents = False
End Sub

' ===== Integração com o MySQL =====

Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

Function salvarNoMySQL(desc, solic, dataSolic, codZ, aplic, vg, lote, nSFP, hist, classe) As Long
    Dim http As Object, url As String, body As String
    url = urlBaseApp() & "/dispositivos/solicitacao/salvarVba"
    body = "descricao=" & enc(desc) & "&solicitante=" & enc(solic) & _
           "&data_solicitacao=" & enc(dataSolic) & "&cod_z=" & enc(codZ) & _
           "&aplicacao=" & enc(aplic) & "&vagao=" & enc(vg) & "&lote=" & enc(lote) & _
           "&conta=" & enc(nSFP) & "&historico=" & enc(hist) & "&classe=" & enc(classe)
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send body
    If http.Status <> 200 Then
        MsgBox "Erro ao salvar no MySQL (" & http.Status & "): " & http.responseText, vbCritical
        salvarNoMySQL = 0
        Exit Function
    End If
    salvarNoMySQL = extrairRef(http.responseText)
End Function

Function enc(v) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

Function extrairRef(jsonTxt As String) As Long
    Dim p As Long, s As String, i As Long, ch As String, num As String
    p = InStr(jsonTxt, """ref""")
    If p = 0 Then extrairRef = 0: Exit Function
    s = Mid(jsonTxt, p + 5)
    For i = 1 To Len(s)
        ch = Mid(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            num = num & ch
        ElseIf num <> "" Then
            Exit For
        End If
    Next i
    extrairRef = CLng("0" & num)
End Function

Function enviarPdfParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http As Object, st As Object, url As String, nomeArq As String, bytes
    enviarPdfParaMySQL = False
    If Dir(caminhoArquivo) = "" Then Exit Function
    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    Set st = CreateObject("ADODB.Stream")
    st.Type = 1
    st.Open
    st.LoadFromFile caminhoArquivo
    bytes = st.Read
    st.Close
    url = urlBaseApp() & "/dispositivos/solicitacao/uploadAnexoVba?ref=" & ref & "&nome=" & enc(nomeArq)
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.Send bytes
    If http.Status = 200 Then enviarPdfParaMySQL = True Else _
        MsgBox "Falha ao enviar PDF (" & http.Status & "): " & http.responseText, vbExclamation
End Function

Function comentarMySQL(ByVal ref As Long, ByVal usuario As String, ByVal mensagem As String) As Boolean
    Dim http As Object, url As String, body As String
    comentarMySQL = False
    If Trim(mensagem) = "" Then Exit Function
    url = urlBaseApp() & "/dispositivos/solicitacao/comentarVba"
    body = "ref=" & ref & "&usuario=" & enc(usuario) & "&mensagem=" & enc(mensagem)
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send body
    If http.Status = 200 Then comentarMySQL = True Else _
        MsgBox "Falha ao enviar comentário (" & http.Status & "): " & http.responseText, vbExclamation
End Function

' MySQL -> Access: insere novos + atualiza só o HISTÓRICO dos existentes
Sub sincronizarDoMySQL()
    Dim http As Object, csv As String
    Dim linhas() As String, cab() As String, campos() As String
    Dim i As Long, j As Long
    Dim db As Object, rs As Object, rsExist As Object
    Dim existentes As Object, ref As String, col As String, val As String
    Dim inseridos As Long, atualizados As Long
    Dim idxRef As Long, idxHist As Long, histTxt As String

    On Error GoTo ERRO

    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/fila?t=" & Timer, False
    http.Send
    If http.Status <> 200 Then
        MsgBox "Erro ao buscar CSV (" & http.Status & ")", vbCritical
        Exit Sub
    End If

    csv = http.responseText
    If Len(csv) > 0 Then If AscW(Left(csv, 1)) = 65279 Then csv = Mid(csv, 2)
    csv = Replace(csv, vbCrLf, vbLf)
    csv = Replace(csv, vbCr, vbLf)
    linhas = Split(csv, vbLf)
    If UBound(linhas) < 1 Then Exit Sub

    cab = Split(linhas(0), ";")
    idxRef = -1: idxHist = -1
    For j = 0 To UBound(cab)
        If Trim(cab(j)) = "Ref" Then idxRef = j
        If Trim(cab(j)) = "Historico" Then idxHist = j
    Next j

    Set db = OpenDatabase("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb")

    Set existentes = CreateObject("Scripting.Dictionary")
    Set rsExist = db.OpenRecordset("SELECT Ref FROM Fila", 2)
    Do While Not rsExist.EOF
        existentes(CStr(rsExist.Fields(0).Value)) = True
        rsExist.MoveNext
    Loop
    rsExist.Close
    Set rsExist = Nothing

    Set rs = db.OpenRecordset("SELECT * FROM Fila", 2)

    inseridos = 0: atualizados = 0
    For i = 1 To UBound(linhas)
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            ref = ""
            If idxRef >= 0 And idxRef <= UBound(campos) Then ref = Trim(Replace(campos(idxRef), """", ""))
            If ref <> "" Then
                If Not existentes.Exists(ref) Then
                    rs.AddNew
                    For j = 0 To UBound(cab)
                        If j > UBound(campos) Then Exit For
                        col = Trim(cab(j))
                        val = Trim(Replace(campos(j), """", ""))
                        If col = "Historico" Then val = Replace(val, "[BR]", vbCrLf)
                        On Error Resume Next
                        If val = "" Then rs.Fields(col).Value = Null Else rs.Fields(col).Value = val
                        Err.Clear
                        On Error GoTo ERRO
                    Next j
                    rs.Update
                    existentes(ref) = True
                    inseridos = inseridos + 1
                Else
                    If idxHist >= 0 And idxHist <= UBound(campos) Then
                        histTxt = Replace(Trim(Replace(campos(idxHist), """", "")), "[BR]", vbCrLf)
                        rs.FindFirst "Ref = " & ref
                        If Not rs.NoMatch Then
                            On Error Resume Next
                            rs.Edit
                            If histTxt = "" Then rs.Fields("Historico").Value = Null Else rs.Fields("Historico").Value = histTxt
                            rs.Update
                            Err.Clear
                            On Error GoTo ERRO
                            atualizados = atualizados + 1
                        End If
                    End If
                End If
            End If
        End If
    Next i

    rs.Close
    db.Close

    On Error Resume Next
    Select Case Range("I3").Value
        Case 1: filtro_01
        Case 2: filtro_02
        Case 3: filtro_03
        Case 4: filtro_04
        Case 5: filtro_05
        Case 6: filtro_06
        Case 7: lista_todos
        Case 0: lista_pendentes
        Case Else: lista_todos
    End Select
    On Error GoTo 0

    MsgBox "Sincronização concluída." & vbCrLf & "Inseridos: " & inseridos & vbCrLf & "Histórico atualizado: " & atualizados, vbInformation
    Exit Sub
ERRO:
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    If Not db Is Nothing Then db.Close
    MsgBox "Erro na sincronização: " & Err.Number & " - " & Err.Description, vbCritical
End Sub
```

### 2.2 DEPOIS (+ `atualizarStatusMySQL`; `sincronizarDoMySQL` atualiza histórico **e status**)

> Igual ao ANTES até a função `comentarMySQL`. As diferenças são: a **nova função
> `atualizarStatusMySQL`** e o **`sincronizarDoMySQL`** atualizando os status. Abaixo só essas duas
> partes (o início do módulo — Globals até `comentarMySQL` — é idêntico ao 2.1):

```vba
' [ADICIONADO] Atualiza status no MySQL. 'corpo' = pares campo=valor&... (valores via enc()).
Function atualizarStatusMySQL(ByVal ref As Long, ByVal corpo As String) As Boolean
    Dim http As Object, url As String
    atualizarStatusMySQL = False
    If Trim(corpo) = "" Then Exit Function
    url = urlBaseApp() & "/dispositivos/solicitacao/atualizarStatusVba"
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send "ref=" & ref & "&" & corpo
    If http.Status = 200 Then atualizarStatusMySQL = True Else _
        MsgBox "Falha ao atualizar status (" & http.Status & "): " & http.responseText, vbExclamation
End Function

' [ALTERADO] MySQL -> Access: insere novos + atualiza HISTÓRICO E STATUS dos existentes
Sub sincronizarDoMySQL()
    Dim http As Object, csv As String
    Dim linhas() As String, cab() As String, campos() As String
    Dim i As Long, j As Long
    Dim db As Object, rs As Object, rsExist As Object
    Dim existentes As Object, colIndex As Object
    Dim ref As String, col As String, val As String
    Dim inseridos As Long, atualizados As Long
    Dim idxRef As Long, colsUpd As Variant, c As Variant, idx As Long, v As String

    On Error GoTo ERRO

    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/fila?t=" & Timer, False
    http.Send
    If http.Status <> 200 Then
        MsgBox "Erro ao buscar CSV (" & http.Status & ")", vbCritical
        Exit Sub
    End If

    csv = http.responseText
    If Len(csv) > 0 Then If AscW(Left(csv, 1)) = 65279 Then csv = Mid(csv, 2)
    csv = Replace(csv, vbCrLf, vbLf)
    csv = Replace(csv, vbCr, vbLf)
    linhas = Split(csv, vbLf)
    If UBound(linhas) < 1 Then Exit Sub

    cab = Split(linhas(0), ";")

    Set colIndex = CreateObject("Scripting.Dictionary")
    For j = 0 To UBound(cab)
        colIndex(Trim(cab(j))) = j
    Next j
    idxRef = -1
    If colIndex.Exists("Ref") Then idxRef = colIndex("Ref")

    ' histórico + status
    colsUpd = Array("Historico", "Conceito_St", "Det_St", "Liberacao_St", "Corte_St", "Exec_St", "Aq_St", "Tryout_St")

    Set db = OpenDatabase("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb")

    Set existentes = CreateObject("Scripting.Dictionary")
    Set rsExist = db.OpenRecordset("SELECT Ref FROM Fila", 2)
    Do While Not rsExist.EOF
        existentes(CStr(rsExist.Fields(0).Value)) = True
        rsExist.MoveNext
    Loop
    rsExist.Close
    Set rsExist = Nothing

    Set rs = db.OpenRecordset("SELECT * FROM Fila", 2)

    inseridos = 0: atualizados = 0
    For i = 1 To UBound(linhas)
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            ref = ""
            If idxRef >= 0 And idxRef <= UBound(campos) Then ref = Trim(Replace(campos(idxRef), """", ""))
            If ref <> "" Then
                If Not existentes.Exists(ref) Then
                    rs.AddNew
                    For j = 0 To UBound(cab)
                        If j > UBound(campos) Then Exit For
                        col = Trim(cab(j))
                        val = Trim(Replace(campos(j), """", ""))
                        If col = "Historico" Then val = Replace(val, "[BR]", vbCrLf)
                        On Error Resume Next
                        If val = "" Then rs.Fields(col).Value = Null Else rs.Fields(col).Value = val
                        Err.Clear
                        On Error GoTo ERRO
                    Next j
                    rs.Update
                    existentes(ref) = True
                    inseridos = inseridos + 1
                Else
                    rs.FindFirst "Ref = " & ref
                    If Not rs.NoMatch Then
                        rs.Edit
                        For Each c In colsUpd
                            If colIndex.Exists(CStr(c)) Then
                                idx = colIndex(CStr(c))
                                If idx <= UBound(campos) Then
                                    v = Trim(Replace(campos(idx), """", ""))
                                    If CStr(c) = "Historico" Then v = Replace(v, "[BR]", vbCrLf)
                                    On Error Resume Next
                                    If v = "" Then rs.Fields(CStr(c)).Value = Null Else rs.Fields(CStr(c)).Value = v
                                    Err.Clear
                                    On Error GoTo ERRO
                                End If
                            End If
                        Next c
                        rs.Update
                        atualizados = atualizados + 1
                    End If
                End If
            End If
        End If
    Next i

    rs.Close
    db.Close

    On Error Resume Next
    Select Case Range("I3").Value
        Case 1: filtro_01
        Case 2: filtro_02
        Case 3: filtro_03
        Case 4: filtro_04
        Case 5: filtro_05
        Case 6: filtro_06
        Case 7: lista_todos
        Case 0: lista_pendentes
        Case Else: lista_todos
    End Select
    On Error GoTo 0

    MsgBox "Sincronização concluída." & vbCrLf & "Inseridos: " & inseridos & vbCrLf & "Atualizados (hist+status): " & atualizados, vbInformation
    Exit Sub
ERRO:
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    If Not db Is Nothing Then db.Close
    MsgBox "Erro na sincronização: " & Err.Number & " - " & Err.Description, vbCritical
End Sub
```

> O módulo `Funcoes` **inteiro DEPOIS** (todas as funções juntas) está reproduzido na resposta do
> chat desta etapa; aqui mostramos o ANTES completo e as 2 partes que mudaram no DEPOIS para
> destacar a diferença sem duplicar as ~10 funções idênticas.

---

## 3. VBA — `frmsol`

Mudaram **3 botões** (`btnCancelarSol`, `btnTryout_NaoOK`, `btnTryout_OK`): cada um, depois do
`upQuery` local, chama `atualizarStatusMySQL`. O resto do `frmsol` é idêntico.

### 3.1 ANTES (botões sem o push de status)
```vba
Private Sub btnCancelarSol_Click()

Dim answer As Integer
Dim SQL As String

ref = Me.lbl_ref.Caption

answer = MsgBox("Deseja realmente cancelar a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Cancelar?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Conceito_St = 'CANCELADO', Det_St = 'CANCELADO', Liberacao_St = 'CANCELADO', Aq_St = 'CANCELADO', Corte_St = 'CANCELADO', Exec_St = 'CANCELADO', Tryout_St = 'CANCELADO' WHERE Ref = " & Replace(ref, "SL", "") & ";"
    upQuery (SQL)

    MsgBox "Solicitação " & ref & " cancelada com sucesso!"
    Unload Me
    Call lista_pendentes
End If

End Sub

Private Sub btnTryout_NaoOK_Click() 'adicionado 19/12/24
Dim SQL As String
Dim answer As Integer
Dim cod_z As String

cod_z = Replace(frmsol.lbl_cod_z.Caption, "Z", "")
ref = Replace(Me.lbl_ref.Caption, "SL", "")

answer = MsgBox("Será necessário revisar a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Tryout NOK?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Tryout_St = 'NÂO OK' where Ref = " & ref & ";"
    upQuery (SQL)
    MsgBox "Tryout realizado mas sem sucesso" & vbCrLf & "Nova SL sendo aberta para Z" & cod_z, , "Próximas Etapas"
    frm_novo.txt_cod.Value = cod_z
    frm_novo.txt_cod.Locked = True
    Unload Me
    Call lista_pendentes
    Load frm_novo
    Call inserir_nova
End If

If answer = 7 Then
    SQL = "UPDATE Fila SET Tryout_St = 'NÂO OK' where Ref = " & ref & ";"
    upQuery (SQL)
    MsgBox "Tryout realizado mas sem sucesso" & vbCrLf & "Nova SL não será necessária", , "Próximas Etapas"
    Unload Me
    Call lista_pendentes
End If

End Sub

Private Sub btnTryout_OK_Click() 'rev 19/12/24
Dim SQL As String
Dim answer As Integer

ref = Replace(Me.lbl_ref.Caption, "SL", "")

answer = MsgBox("Deseja concluir a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Concluir?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Tryout_St = 'OK' where Ref = " & ref & ";"
    upQuery (SQL)
    MsgBox "Tryout validado com sucesso!!!"
    Unload Me
    Call lista_pendentes
End If

End Sub
```

### 3.2 DEPOIS (com `atualizarStatusMySQL`)
```vba
Private Sub btnCancelarSol_Click()

Dim answer As Integer
Dim SQL As String

ref = Me.lbl_ref.Caption

answer = MsgBox("Deseja realmente cancelar a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Cancelar?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Conceito_St = 'CANCELADO', Det_St = 'CANCELADO', Liberacao_St = 'CANCELADO', Aq_St = 'CANCELADO', Corte_St = 'CANCELADO', Exec_St = 'CANCELADO', Tryout_St = 'CANCELADO' WHERE Ref = " & Replace(ref, "SL", "") & ";"
    upQuery (SQL)

    atualizarStatusMySQL Replace(ref, "SL", "") * 1, "conceito_status=" & enc("CANCELADO") & "&detalhamento_status=" & enc("CANCELADO") & "&liberacao_status=" & enc("CANCELADO") & "&aquisicao_status=" & enc("CANCELADO") & "&corte_status=" & enc("CANCELADO") & "&exec_status=" & enc("CANCELADO") & "&tryout_status=" & enc("CANCELADO")   ' [ADICIONADO]

    MsgBox "Solicitação " & ref & " cancelada com sucesso!"
    Unload Me
    Call lista_pendentes
End If

End Sub

Private Sub btnTryout_NaoOK_Click() 'adicionado 19/12/24
Dim SQL As String
Dim answer As Integer
Dim cod_z As String

cod_z = Replace(frmsol.lbl_cod_z.Caption, "Z", "")
ref = Replace(Me.lbl_ref.Caption, "SL", "")

answer = MsgBox("Será necessário revisar a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Tryout NOK?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Tryout_St = 'NÂO OK' where Ref = " & ref & ";"
    upQuery (SQL)

    atualizarStatusMySQL ref, "tryout_status=" & enc("NÂO OK")   ' [ADICIONADO]

    MsgBox "Tryout realizado mas sem sucesso" & vbCrLf & "Nova SL sendo aberta para Z" & cod_z, , "Próximas Etapas"
    frm_novo.txt_cod.Value = cod_z
    frm_novo.txt_cod.Locked = True
    Unload Me
    Call lista_pendentes
    Load frm_novo
    Call inserir_nova
End If

If answer = 7 Then
    SQL = "UPDATE Fila SET Tryout_St = 'NÂO OK' where Ref = " & ref & ";"
    upQuery (SQL)

    atualizarStatusMySQL ref, "tryout_status=" & enc("NÂO OK")   ' [ADICIONADO]

    MsgBox "Tryout realizado mas sem sucesso" & vbCrLf & "Nova SL não será necessária", , "Próximas Etapas"
    Unload Me
    Call lista_pendentes
End If

End Sub

Private Sub btnTryout_OK_Click() 'rev 19/12/24
Dim SQL As String
Dim answer As Integer

ref = Replace(Me.lbl_ref.Caption, "SL", "")

answer = MsgBox("Deseja concluir a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Concluir?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Tryout_St = 'OK' where Ref = " & ref & ";"
    upQuery (SQL)

    atualizarStatusMySQL ref, "tryout_status=" & enc("OK")   ' [ADICIONADO]

    MsgBox "Tryout validado com sucesso!!!"
    Unload Me
    Call lista_pendentes
End If

End Sub
```

> Os demais procedimentos do `frmsol` (`btn_enviar`, `btn_pdf`, `btnBOM`, `dxf_lst_DblClick`,
> `btnVisualizar`, `lbl_abrir`, `pdf_lst_DblClick` etc., já com os caminhos `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\`) não mudaram —
> estão completos em [anexos-mysql-access-codigo.md](anexos-mysql-access-codigo.md) e
> [historico-bidirecional-codigo.md](historico-bidirecional-codigo.md).

---

## 4. VBA — `ufValidar`

Mudaram **2 botões** (`btnRejeitar`, `btnValidar`): cada um, após o `upQuery`, chama
`atualizarStatusMySQL` + `comentarMySQL`. O resto (os `chkReq*`, `calculaReq`, `UserForm_Initialize`,
`txt_msg_Change`, `btn_cancelar`) é idêntico.

### 4.1 ANTES
```vba
Private Sub btnRejeitar_Click()
    Dim SQL As String
    Dim msg As String

    msg = Me.txt_msg.Text
    If msg = "" Then
        MsgBox "O motivo da rejeição deverá ser informado!"
        Exit Sub
    End If

    n_sl = Replace(frmsol.lbl_ref.Caption, "SL", "")
    SQL = "SELECT Historico, Solicitante FROM Fila WHERE Ref = " & n_sl & ";"
    arrHist = resQuery(SQL)
    hist = arrHist(0, 0)
    autor = arrHist(1, 0)

    inicio = vbCrLf & vbCrLf & vbCrLf & "** CONCEITO REJEITADO **" & vbCrLf
    cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf
    historico = hist & inicio & cabec & msg

    SQL = "UPDATE Fila SET Det_St = 'PENDENTE', Conceito_St = 'MODELO', Historico = '" & historico & "' WHERE Ref = " & n_sl & ";"
    upQuery (SQL)

    frmsol.txt_historico.Text = historico
    Unload Me
End Sub

Private Sub btnValidar_Click()
    Dim SQL As String

    For a = 1 To 10
        If Me.Controls("lblReq" & a).Visible = True Then
            If Me.Controls("chkReq" & a).Picture = Me.chkOn.Picture Then Allchk = "ok" Else Allchk = "nok"
        End If
    Next a

    If Allchk = "nok" Then
        MsgBox "Todos os Requisitos devem ser validados!"
        Exit Sub
    End If

    n_sl = Replace(frmsol.lbl_ref.Caption, "SL", "")
    SQL = "SELECT Historico, Solicitante FROM Fila WHERE Ref = " & n_sl & ";"
    arrHist = resQuery(SQL)
    hist = arrHist(0, 0)
    autor = arrHist(1, 0)

    inicio = vbCrLf & vbCrLf & vbCrLf & "** VALIDAÇÃO DA SOLICITAÇÃO **" & vbCrLf
    cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

    msg = Me.txt_msg.Text
    If msg = "" Then
        msg = "OK. De acordo!"
        Me.txt_msg.Text = msg
    End If

    historico = hist & inicio & cabec & msg
    chkReq = Me.lblReqs.Caption

    SQL = "UPDATE Fila SET Det_St = 'PENDENTE', Historico = '" & historico & "' , CKReq = '" & chkReq & "' WHERE Ref = " & n_sl & ";"
    upQuery (SQL)

    frmsol.det_st.Caption = "PENDENTE"
    frmsol.det_st.BackColor = &H8080FF
    frmsol.txt_historico.Text = historico
    frmsol.btnValidar.Enabled = False
    Unload Me
    MsgBox "Solicitação validada!"
End Sub
```

### 4.2 DEPOIS (com `atualizarStatusMySQL` + `comentarMySQL`)
```vba
Private Sub btnRejeitar_Click()
    Dim SQL As String
    Dim msg As String

    msg = Me.txt_msg.Text
    If msg = "" Then
        MsgBox "O motivo da rejeição deverá ser informado!"
        Exit Sub
    End If

    n_sl = Replace(frmsol.lbl_ref.Caption, "SL", "")
    SQL = "SELECT Historico, Solicitante FROM Fila WHERE Ref = " & n_sl & ";"
    arrHist = resQuery(SQL)
    hist = arrHist(0, 0)
    autor = arrHist(1, 0)

    inicio = vbCrLf & vbCrLf & vbCrLf & "** CONCEITO REJEITADO **" & vbCrLf
    cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf
    historico = hist & inicio & cabec & msg

    SQL = "UPDATE Fila SET Det_St = 'PENDENTE', Conceito_St = 'MODELO', Historico = '" & historico & "' WHERE Ref = " & n_sl & ";"
    upQuery (SQL)

    atualizarStatusMySQL n_sl, "detalhamento_status=" & enc("PENDENTE") & "&conceito_status=" & enc("MODELO")   ' [ADICIONADO]
    comentarMySQL n_sl, autor, "** CONCEITO REJEITADO ** " & msg   ' [ADICIONADO]

    frmsol.txt_historico.Text = historico
    Unload Me
End Sub

Private Sub btnValidar_Click()
    Dim SQL As String

    For a = 1 To 10
        If Me.Controls("lblReq" & a).Visible = True Then
            If Me.Controls("chkReq" & a).Picture = Me.chkOn.Picture Then Allchk = "ok" Else Allchk = "nok"
        End If
    Next a

    If Allchk = "nok" Then
        MsgBox "Todos os Requisitos devem ser validados!"
        Exit Sub
    End If

    n_sl = Replace(frmsol.lbl_ref.Caption, "SL", "")
    SQL = "SELECT Historico, Solicitante FROM Fila WHERE Ref = " & n_sl & ";"
    arrHist = resQuery(SQL)
    hist = arrHist(0, 0)
    autor = arrHist(1, 0)

    inicio = vbCrLf & vbCrLf & vbCrLf & "** VALIDAÇÃO DA SOLICITAÇÃO **" & vbCrLf
    cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

    msg = Me.txt_msg.Text
    If msg = "" Then
        msg = "OK. De acordo!"
        Me.txt_msg.Text = msg
    End If

    historico = hist & inicio & cabec & msg
    chkReq = Me.lblReqs.Caption

    SQL = "UPDATE Fila SET Det_St = 'PENDENTE', Historico = '" & historico & "' , CKReq = '" & chkReq & "' WHERE Ref = " & n_sl & ";"
    upQuery (SQL)

    atualizarStatusMySQL n_sl, "detalhamento_status=" & enc("PENDENTE")   ' [ADICIONADO]
    comentarMySQL n_sl, autor, "** VALIDAÇÃO DA SOLICITAÇÃO ** " & msg   ' [ADICIONADO]

    frmsol.det_st.Caption = "PENDENTE"
    frmsol.det_st.BackColor = &H8080FF
    frmsol.txt_historico.Text = historico
    frmsol.btnValidar.Enabled = False
    Unload Me
    MsgBox "Solicitação validada!"
End Sub
```

> Os demais procedimentos do `ufValidar` (`chkReq1`..`chkReq10`, `calculaReq`, `txt_msg_Change`,
> `UserForm_Initialize`, `btn_cancelar`) são idênticos ao ANTES e estão na resposta do chat desta etapa.
