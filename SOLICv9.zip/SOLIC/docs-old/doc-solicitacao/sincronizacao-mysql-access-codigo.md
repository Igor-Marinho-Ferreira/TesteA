# Código completo — Sincronização MySQL → Access

Companheiro de [sincronizacao-mysql-access.md](sincronizacao-mysql-access.md).
Todo o código, **100% completo**, com **antes × depois** e marcações `[ADICIONADO]` / `[ALTERADO]`.

Índice:
1. PHP — `SolicitacaoController::trataCSV` (método completo: antes / depois)
2. VBA — `sincronizarDoMySQL` (Sub completa)

---

## 1. PHP — `src/app/controllers/SolicitacaoController.php` → `trataCSV`

A única mudança foi **preservar as quebras de linha do histórico** como token `[BR]`
(em vez de virar espaço), para o Access ficar multilinha. Foi adicionado o closure
`$histAccess` e trocado o uso no campo `Historico`.

### 1.1 ANTES — método `trataCSV` completo

```php
    public function trataCSV(){


        try {
            if (ob_get_level()) ob_end_clean();

            // 2. Força cabeçalhos de "Não Cachear" para o Navegador/VBA
            header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
            header("Cache-Control: post-check=0, pre-check=0", false);
            header("Pragma: no-cache");
            header("Expires: Wed, 11 Jan 1984 05:00:00 GMT");
            // set_time_limit(300); // 5 minutos
            ini_set('memory_limit', '512M');

            $solicitacoes = Acompanhamento::getAllTratado();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=Fila.csv');

            //abre o arquivo
            $file  = fopen('php://output', 'w');
            //trata utf-8
            fputs($file, "\xEF\xBB\xBF");

            //cabeçalhos do meu arquivo
            $cabecalhos = [
                'Ref', 'Descricao', 'Solicitante', 'Cod_Z', 'Aplicacao', 'Vagao', 'Conceito_P',
                'Conceito_St', 'Conceito_Ini', 'Conceito_Fim', 'Det_P', 'Det_St',
                'Det_Ini', 'Det_Fim', 'Liberacao_St', 'Liberacao_Data', 'Corte_St',
                'Corte_Data', 'Exec_St', 'Exec_Data', 'Tryout_St', 'Tryout_Data',
                'Data_Solicitacao', 'Historico', 'Lote', 'Prio', 'Classe', 'Aq_St',
                'Aq_Data', 'Tempo_Modelo', 'Tempo_Det', 'Tempo_Fila_Det', 'Tempo_Fila_Lib',
                'Executor_EI', 'Data_Inicio_EI', 'Data_Fim_EI', 'Status_EI', 'Recebido_EI',
                'RVD', 'Obs_Aquisicao', 'TAG', 'Pendencia', 'Responsavel', 'Setor_Pendencia',
                'N_Pasta', 'Requisitos', 'CK3D', 'CKDet', 'CKReq', 'TempoTarefa',
                'PrioTarefa', 'IniTarefa', 'complexidade', 'FimTarefa', 'EquipeEI',
                'Liberacao', 'Natureza', 'DescricaoServico', 'NumSfpCC'
            ];

            fputcsv($file, $cabecalhos, ';');


            $formatarData = function ($valor) {
                if (empty($valor) || $valor == '0000-00-00') return '';
                try {
                    $date = new \DateTime($valor);
                    return $date->format('d/m/Y');
                } catch (\Exception $e) {
                    return $valor;
                    }
                    };

            foreach ($solicitacoes as $solicitacao) {
                $limpar = function ($texto) {
                    if (empty($texto)) return '';
                    // Remove quebras de linha (Windows e Linux) e troca por espaço
                    $texto = str_replace(["\r\n", "\r", "\n"], " ", $texto);
                    // Remove pontos e vírgula para não confundir o delimitador do CSV
                    $texto = str_replace(";", ",", $texto);
                    return $texto;
                };


                $novoRegistro = [
                    $solicitacao->ref ?? '',
                    $limpar($solicitacao->descricao ?? ''),
                    $solicitacao->solicitante ?? '',
                    $solicitacao->cod_z ?? '',
                    $solicitacao->aplicacao ?? '',
                    $solicitacao->vagao ?? '',
                    $solicitacao->conceito_proj ?? '',
                    $solicitacao->conceito_status ?? 'PENDENTE',
                    $solicitacao->conceito_inicio ?? '',
                    $solicitacao->conceito_fim ?? '',
                    $solicitacao->detalhamento_proj ?? '',
                    $solicitacao->detalhamento_status ?? 'PENDENTE',
                    $solicitacao->detalhamento_inicio ?? '',
                    $solicitacao->detalhamento_fim ?? '',
                    $solicitacao->liberacao_status ?? 'PENDENTE',
                    $solicitacao->liberacao_data ?? '',
                    $solicitacao->corte_status ?? 'PARADO',
                    $solicitacao->corte_data ?? '',
                    $solicitacao->exec_status ?? 'PARADO',
                    $solicitacao->exec_data ?? '',
                    $solicitacao->tryout_status ?? 'PENDENTE',
                    $solicitacao->tryout_data ?? '',
                    $formatarData($solicitacao->data_solicitacao ?? ''),
                    $limpar($solicitacao->historico ?? ''),
                    $solicitacao->lote ?? '',
                    $solicitacao->prio ?? '99',
                    $solicitacao->classe ?? '',
                    $solicitacao->aquisicao_status ?? 'PENDENTE',
                    $solicitacao->aquisicao_data ?? '',
                    $solicitacao->tempo_modelo ?? '',
                    $solicitacao->tempo_det ?? '',
                    $solicitacao->tempo_fila_det ?? '',
                    $solicitacao->tempo_fila_lib ?? '',
                    $solicitacao->executor_ei ?? '',
                    $solicitacao->data_inicio_ei ?? '',
                    $solicitacao->data_fim_ei ?? '',
                    $solicitacao->status_ei ?? '',
                    $solicitacao->recebido_ei ?? '',
                    $solicitacao->rvd ?? '',
                    $solicitacao->obs_aquisicao ?? '',
                    $solicitacao->tag ?? '',
                    $solicitacao->pendencia ?? '',
                    $solicitacao->responsavel ?? '',
                    $solicitacao->setor_pendencia ?? '',
                    $solicitacao->n_pasta ?? '',
                    $solicitacao->requisitos ?? '',
                    $solicitacao->ck3d ?? '',
                    $solicitacao->ckdet ?? '',
                    $solicitacao->ckreq ?? '',
                    $solicitacao->tempotarefa ?? '',
                    $solicitacao->prio ?? '',
                    $solicitacao->initarefa ?? '',
                    $solicitacao->complexidade ?? '',
                    $solicitacao->fimtarefa ?? '',
                    $solicitacao->equipeei ?? '',
                    $solicitacao->liberacao ?? '',
                    $solicitacao->natureza ?? '',
                    $solicitacao->descricaoservico ?? '',
                    $solicitacao->conta ?? ''
                ];

                fputcsv($file, $novoRegistro, ';');
            }

            fclose($file);
            exit;
        } catch (\Exception $e) {
            return "Erro ao gerar CSV: " . $e->getMessage();
        }


    }
```

### 1.2 DEPOIS — método `trataCSV` completo (com `$histAccess`)

```php
    public function trataCSV(){


        try {
            if (ob_get_level()) ob_end_clean();

            // 2. Força cabeçalhos de "Não Cachear" para o Navegador/VBA
            header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
            header("Cache-Control: post-check=0, pre-check=0", false);
            header("Pragma: no-cache");
            header("Expires: Wed, 11 Jan 1984 05:00:00 GMT");
            // set_time_limit(300); // 5 minutos
            ini_set('memory_limit', '512M');

            $solicitacoes = Acompanhamento::getAllTratado();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=Fila.csv');

            //abre o arquivo
            $file  = fopen('php://output', 'w');
            //trata utf-8
            fputs($file, "\xEF\xBB\xBF");

            //cabeçalhos do meu arquivo
            $cabecalhos = [
                'Ref', 'Descricao', 'Solicitante', 'Cod_Z', 'Aplicacao', 'Vagao', 'Conceito_P',
                'Conceito_St', 'Conceito_Ini', 'Conceito_Fim', 'Det_P', 'Det_St',
                'Det_Ini', 'Det_Fim', 'Liberacao_St', 'Liberacao_Data', 'Corte_St',
                'Corte_Data', 'Exec_St', 'Exec_Data', 'Tryout_St', 'Tryout_Data',
                'Data_Solicitacao', 'Historico', 'Lote', 'Prio', 'Classe', 'Aq_St',
                'Aq_Data', 'Tempo_Modelo', 'Tempo_Det', 'Tempo_Fila_Det', 'Tempo_Fila_Lib',
                'Executor_EI', 'Data_Inicio_EI', 'Data_Fim_EI', 'Status_EI', 'Recebido_EI',
                'RVD', 'Obs_Aquisicao', 'TAG', 'Pendencia', 'Responsavel', 'Setor_Pendencia',
                'N_Pasta', 'Requisitos', 'CK3D', 'CKDet', 'CKReq', 'TempoTarefa',
                'PrioTarefa', 'IniTarefa', 'complexidade', 'FimTarefa', 'EquipeEI',
                'Liberacao', 'Natureza', 'DescricaoServico', 'NumSfpCC'
            ];

            fputcsv($file, $cabecalhos, ';');


            $formatarData = function ($valor) {
                if (empty($valor) || $valor == '0000-00-00') return '';
                try {
                    $date = new \DateTime($valor);
                    return $date->format('d/m/Y');
                } catch (\Exception $e) {
                    return $valor;
                    }
                    };

            foreach ($solicitacoes as $solicitacao) {
                $limpar = function ($texto) {
                    if (empty($texto)) return '';
                    // Remove quebras de linha (Windows e Linux) e troca por espaço
                    $texto = str_replace(["\r\n", "\r", "\n"], " ", $texto);
                    // Remove pontos e vírgula para não confundir o delimitador do CSV
                    $texto = str_replace(";", ",", $texto);
                    return $texto;
                };

                // [ADICIONADO] Para o HISTÓRICO: preserva as quebras como token [BR]
                // (o VBA troca [BR] por quebra de linha ao gravar no Access -> multilinha)
                $histAccess = function ($texto) {
                    if (empty($texto)) return '';
                    $texto = str_replace(["\r\n", "\r", "\n"], "[BR]", $texto);
                    $texto = str_replace(";", ",", $texto);
                    return $texto;
                };


                $novoRegistro = [
                    $solicitacao->ref ?? '',
                    $limpar($solicitacao->descricao ?? ''),
                    $solicitacao->solicitante ?? '',
                    $solicitacao->cod_z ?? '',
                    $solicitacao->aplicacao ?? '',
                    $solicitacao->vagao ?? '',
                    $solicitacao->conceito_proj ?? '',
                    $solicitacao->conceito_status ?? 'PENDENTE',
                    $solicitacao->conceito_inicio ?? '',
                    $solicitacao->conceito_fim ?? '',
                    $solicitacao->detalhamento_proj ?? '',
                    $solicitacao->detalhamento_status ?? 'PENDENTE',
                    $solicitacao->detalhamento_inicio ?? '',
                    $solicitacao->detalhamento_fim ?? '',
                    $solicitacao->liberacao_status ?? 'PENDENTE',
                    $solicitacao->liberacao_data ?? '',
                    $solicitacao->corte_status ?? 'PARADO',
                    $solicitacao->corte_data ?? '',
                    $solicitacao->exec_status ?? 'PARADO',
                    $solicitacao->exec_data ?? '',
                    $solicitacao->tryout_status ?? 'PENDENTE',
                    $solicitacao->tryout_data ?? '',
                    $formatarData($solicitacao->data_solicitacao ?? ''),
                    $histAccess($solicitacao->historico ?? ''),    // [ALTERADO] preserva quebras como [BR]
                    $solicitacao->lote ?? '',
                    $solicitacao->prio ?? '99',
                    $solicitacao->classe ?? '',
                    $solicitacao->aquisicao_status ?? 'PENDENTE',
                    $solicitacao->aquisicao_data ?? '',
                    $solicitacao->tempo_modelo ?? '',
                    $solicitacao->tempo_det ?? '',
                    $solicitacao->tempo_fila_det ?? '',
                    $solicitacao->tempo_fila_lib ?? '',
                    $solicitacao->executor_ei ?? '',
                    $solicitacao->data_inicio_ei ?? '',
                    $solicitacao->data_fim_ei ?? '',
                    $solicitacao->status_ei ?? '',
                    $solicitacao->recebido_ei ?? '',
                    $solicitacao->rvd ?? '',
                    $solicitacao->obs_aquisicao ?? '',
                    $solicitacao->tag ?? '',
                    $solicitacao->pendencia ?? '',
                    $solicitacao->responsavel ?? '',
                    $solicitacao->setor_pendencia ?? '',
                    $solicitacao->n_pasta ?? '',
                    $solicitacao->requisitos ?? '',
                    $solicitacao->ck3d ?? '',
                    $solicitacao->ckdet ?? '',
                    $solicitacao->ckreq ?? '',
                    $solicitacao->tempotarefa ?? '',
                    $solicitacao->prio ?? '',
                    $solicitacao->initarefa ?? '',
                    $solicitacao->complexidade ?? '',
                    $solicitacao->fimtarefa ?? '',
                    $solicitacao->equipeei ?? '',
                    $solicitacao->liberacao ?? '',
                    $solicitacao->natureza ?? '',
                    $solicitacao->descricaoservico ?? '',
                    $solicitacao->conta ?? ''
                ];

                fputcsv($file, $novoRegistro, ';');
            }

            fclose($file);
            exit;
        } catch (\Exception $e) {
            return "Erro ao gerar CSV: " . $e->getMessage();
        }


    }
```

> A fonte dos dados é `Acompanhamento::getAllTratado()`, que lê a `fila` e reconstrói o `historico`
> da tabela `historico` no formato `-- usuário (d.m.Y - H:i):\n mensagem` (GROUP_CONCAT).

---

## 2. VBA — módulo `Funcoes` (100% completo)

Módulo `Funcoes` inteiro. O que entra **nesta etapa** (MySQL → Access) é a Sub
`sincronizarDoMySQL` no final (marcada `[ADICIONADO]`); o restante já existia das etapas anteriores.

```vba
Global G_Lider As String
Global G_Solicitante As String

Function resQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

cnn.Close

End Function

Sub Reset()

Application.ScreenUpdating = True
Application.EnableEvents = True

End Sub

Sub Desabilita()

Application.ScreenUpdating = False
Application.EnableEvents = False

End Sub

' ===== NOVAS FUNÇÕES (integração com o MySQL) =====

' Base do PHP (servidor de teste)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Envia a solicitação ao MySQL e retorna o Ref gerado (0 = falhou)
Function salvarNoMySQL(desc, solic, dataSolic, codZ, aplic, vg, lote, nSFP, hist, classe) As Long
    Dim http As Object, url As String, body As String
    url = urlBaseApp() & "/dispositivos/solicitacao/salvarVba"

    body = "descricao=" & enc(desc) & _
           "&solicitante=" & enc(solic) & _
           "&data_solicitacao=" & enc(dataSolic) & _
           "&cod_z=" & enc(codZ) & _
           "&aplicacao=" & enc(aplic) & _
           "&vagao=" & enc(vg) & _
           "&lote=" & enc(lote) & _
           "&conta=" & enc(nSFP) & _
           "&historico=" & enc(hist) & _
           "&classe=" & enc(classe)

    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send body

    If http.Status <> 200 Then
        MsgBox "Erro ao salvar no MySQL (" & http.Status & "): " & http.responseText, vbCritical
        salvarNoMySQL = 0
        Exit Function
    End If

    salvarNoMySQL = extrairRef(http.responseText)   ' resposta: {"ref":4001}
End Function

' Escapa um valor para a URL/POST
Function enc(v) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Extrai o número do "ref" da resposta JSON
Function extrairRef(jsonTxt As String) As Long
    Dim p As Long, s As String, i As Long, ch As String, num As String
    p = InStr(jsonTxt, """ref""")
    If p = 0 Then extrairRef = 0: Exit Function
    s = Mid(jsonTxt, p + 5)
    For i = 1 To Len(s)
        ch = Mid(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            num = num & ch
        ElseIf num <> "" Then
            Exit For
        End If
    Next i
    extrairRef = CLng("0" & num)
End Function

' ===== [ADICIONADO] MySQL -> Access (insert-only) via DAO =====
Sub sincronizarDoMySQL()
    Dim http As Object, csv As String
    Dim linhas() As String, cab() As String, campos() As String
    Dim i As Long, j As Long
    Dim db As Object, rs As Object, rsExist As Object
    Dim existentes As Object, ref As String, col As String, val As String
    Dim inseridos As Long

    On Error GoTo ERRO

    ' 1) Baixa o CSV do MySQL
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/fila?t=" & Timer, False
    http.Send
    If http.Status <> 200 Then
        MsgBox "Erro ao buscar CSV (" & http.Status & ")", vbCritical
        Exit Sub
    End If

    csv = http.responseText
    If Len(csv) > 0 Then If AscW(Left(csv, 1)) = 65279 Then csv = Mid(csv, 2) ' remove BOM
    csv = Replace(csv, vbCrLf, vbLf)
    csv = Replace(csv, vbCr, vbLf)
    linhas = Split(csv, vbLf)
    If UBound(linhas) < 1 Then Exit Sub

    cab = Split(linhas(0), ";")

    ' 2) Abre o Access via DAO (grava de verdade)
    Set db = OpenDatabase("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb")

    ' Refs que já existem
    Set existentes = CreateObject("Scripting.Dictionary")
    Set rsExist = db.OpenRecordset("SELECT Ref FROM Fila", 2)   ' 2 = dbOpenDynaset
    Do While Not rsExist.EOF
        existentes(CStr(rsExist.Fields(0).Value)) = True
        rsExist.MoveNext
    Loop
    rsExist.Close
    Set rsExist = Nothing

    ' 3) Recordset gravável da Fila
    Set rs = db.OpenRecordset("SELECT * FROM Fila", 2)          ' 2 = dbOpenDynaset

    inseridos = 0
    For i = 1 To UBound(linhas)
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")

            ' acha o Ref
            ref = ""
            For j = 0 To UBound(cab)
                If Trim(cab(j)) = "Ref" And j <= UBound(campos) Then ref = Trim(Replace(campos(j), """", ""))
            Next j

            If ref <> "" And Not existentes.Exists(ref) Then
                rs.AddNew
                For j = 0 To UBound(cab)
                    If j > UBound(campos) Then Exit For
                    col = Trim(cab(j))
                    val = Trim(Replace(campos(j), """", ""))
                    If col = "Historico" Then val = Replace(val, "[BR]", vbCrLf)   ' volta multilinha
                    On Error Resume Next
                    If val = "" Then
                        rs.Fields(col).Value = Null
                    Else
                        rs.Fields(col).Value = val
                    End If
                    Err.Clear
                    On Error GoTo ERRO
                Next j
                rs.Update
                existentes(ref) = True
                inseridos = inseridos + 1
            End If
        End If
    Next i

    rs.Close
    db.Close

    ' Reaplica o filtro atual para atualizar a lista na tela
    On Error Resume Next
    Select Case Range("I3").Value
        Case 1: filtro_01
        Case 2: filtro_02
        Case 3: filtro_03
        Case 4: filtro_04
        Case 5: filtro_05
        Case 6: filtro_06
        Case 7: lista_todos
        Case 0: lista_pendentes
        Case Else: lista_todos
    End Select
    On Error GoTo 0

    MsgBox "Sincronização concluída. Novos do MySQL inseridos no Access: " & inseridos, vbInformation
    Exit Sub

ERRO:
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    If Not db Is Nothing Then db.Close
    MsgBox "Erro na sincronização: " & Err.Number & " - " & Err.Description, vbCritical
End Sub
```

> Depende de `urlBaseApp()` (módulo `Funcoes`) e da referência **DAO** marcada
> (*Ferramentas → Referências → "Microsoft Office 16.0 Access database engine Object Library"*).
