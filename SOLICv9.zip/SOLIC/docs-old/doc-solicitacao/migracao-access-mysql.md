# Migração Access → MySQL e criação de SL pelo Access

Documentação da etapa que liga o **Access (VBA)** ao **MySQL** do sistema `solic_dispositivos`.
Cobre: a carga inicial (migração) e o fluxo de "criar solicitação no Access gravando no MySQL".

> 📎 **Código completo (PHP + VBA antes/depois + migração):** veja [migracao-access-mysql-codigo.md](migracao-access-mysql-codigo.md).

- **Servidor PHP/MySQL:** Debian em `172.29.5.2` (MariaDB 10.3), base `bd_device_request`.
- **URL base do app:** `http://172.29.5.2/greenbrier/v2/solic_dispositivos`
- **Ambiente de teste local (Windows):** `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` (Local Confiável do Excel), banco Access em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb`.

---

## 1. Conceito (a "regra do número")

O **MySQL é o "cartório" único do número (Ref)**. Ninguém mais inventa número:

- **Web** → grava direto no MySQL (gera o Ref ali).
- **Access** → antes de gravar, **pergunta o Ref ao MySQL** via HTTP (`salvarVba`), recebe o número e usa **o mesmo** no Access.
- A geração do número é **atômica** no MySQL via `GET_LOCK` (sem precisar de `AUTO_INCREMENT`/`UNIQUE` no schema).

Resultado: numeração **contínua** e **sem colisão**, mesmo com Web e Access criando ao mesmo tempo.

---

## 2. Antes × Depois

### Geração do Ref

| | ANTES | DEPOIS |
|---|---|---|
| Quem gera o número | Access (`Ref` = AutoNumeração) **e** Web (`MAX+1`) — risco de colidir | **Só o MySQL** (cartório, com `GET_LOCK`) |
| Campo `Ref` no Access | Numeração Automática | **Número (Inteiro Longo)** — aceita o nº vindo do MySQL |
| Criar no Access | `INSERT` no Access → `SELECT MAX(Ref)` | `salvarNoMySQL()` (pega o Ref) → `INSERT` no Access com esse Ref |

### Dados no MySQL

| | ANTES | DEPOIS |
|---|---|---|
| Tabelas `solicitacoes` / `fila` | vazias (ou via rota antiga que não funcionava) | populadas pela **migração** + por cada criação |
| `created_at` (migrados) | — | usa a **data da solicitação** (não `NOW()`) |
| `data_solicitacao` (novos) | sem hora (`00:00:00`) | **com hora** (`DD/MM/YYYY HH:MM:SS`) |
| Tabela `historico` (timeline) | vazia | populada (texto do Access quebrado por entrada) |

---

## 3. O que foi feito, onde e como

### 3.1 Banco Access (uma vez)

- Tabela **`Fila`** → campo **`Ref`**: trocado de **Numeração Automática** para **Número / Inteiro Longo**
  (Modo Design no Access). Os valores existentes são preservados.

### 3.2 PHP (no servidor — `solic_dispositivos`)

**Arquivo:** `src/routes/routes.php` — rota nova:

```php
// SALVAR VINDO DO VBA/ACCESS — gera o Ref no MySQL (cartório) com GET_LOCK
Route::post('/dispositivos/solicitacao/salvarVba', SolicitacaoController::class, 'salvarVba')
    ->name('dispositivos.solicitacao.salvarVba');
```

**Arquivo:** `src/app/controllers/SolicitacaoController.php` — método `salvarVba` + helper `dataBR2SQL`:

- Pega **uma** conexão PDO (`Solicitacao::getPDO()`) e nela:
  1. `SELECT GET_LOCK('solic_ref', 10)` (serializa a emissão do número),
  2. `MAX(ref)+1`,
  3. `INSERT` em `solicitacoes` (reserva o Ref),
  4. `RELEASE_LOCK`.
- Depois grava em `fila` (`Solicitacao::storeFila`, que põe os status `PENDENTE`/`PARADO`).
- Grava a 1ª entrada da timeline em `historico` (`Historico::create`).
- Responde `{"ref": NNNN}`.
- `dataBR2SQL` aceita `DD/MM/YYYY` e `DD/MM/YYYY HH:MM:SS`; se já vier em formato SQL, passa direto.

> ⚠️ **Importante:** ao alterar o PHP localmente em `D:\SOLIC`, é preciso **re-deploy** no servidor `172.29.5.2`.

### 3.3 VBA — módulo `Funcoes`

Quatro funções novas (a base do app e o POST para o PHP):

```vba
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

Function salvarNoMySQL(desc, solic, dataSolic, codZ, aplic, vg, lote, nSFP, hist, classe) As Long
    ' POST para /dispositivos/solicitacao/salvarVba e retorna o Ref (0 = falhou)
    ' usa MSXML2.ServerXMLHTTP + application/x-www-form-urlencoded
End Function

Function enc(v) As String            ' Application.WorksheetFunction.EncodeURL
Function extrairRef(jsonTxt) As Long ' lê o número do "ref" no JSON de resposta
```

> Também padronizamos os caminhos do banco no VBA para `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb`
> e as pastas de arquivos para `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\`, `.img_sl\`, `.bom\` etc.

### 3.4 VBA — `frm_novo` → `btn_enviar_Click`

O miolo de gravar mudou de "INSERT no Access + MAX(Ref)" para:

```vba
data_solic = Format(Now, "DD/MM/YYYY")
Dim data_solic_sql As String
data_solic_sql = Format(Now, "DD/MM/YYYY HH:NN:SS")   ' com hora, só pro MySQL

' 1) Gera o Ref no MySQL (cartório) e já grava lá
t_ref = salvarNoMySQL(desc, solic, data_solic_sql, cod_z, aplic, vg, lote, nSFP, hist, classe)
If t_ref = 0 Then Exit Sub

' 2) Grava no Access com o MESMO Ref
SQL = "INSERT INTO Fila (Ref, Descricao, ...) VALUES (" & t_ref & ", '" & ... & "');"
upQuery (SQL)
```

### 3.5 VBA — macro de migração `MigrarFilaParaMySQL`

Gera o arquivo **`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\migracao.sql`** (UTF-8 **sem BOM**) com os INSERTs de:

1. `solicitacoes` (1 linha por `Fila`), `created_at` = data da solicitação;
2. `fila` (mesmas linhas + status), `created_at` = data da solicitação;
3. `historico` — quebra o texto `Fila.Historico` em entradas `-- nome (DD.MM.YYYY - HH:MM): msg` (1 INSERT por entrada; se não reconhecer o padrão, grava o texto inteiro como 1 entrada).

Helpers: `NovoGUID` (gera o `id` uuid), `sqlStr`/`sqlDate`/`sqlNum` (escape e formato), `cAtDe` (created_at a partir da data), `histToSql` (parse do histórico com `VBScript.RegExp`).

---

## 4. Mapeamento de colunas (Access `Fila` → MySQL)

| Access (`Fila`) | MySQL | Observação |
|---|---|---|
| `Ref` | `ref` | vem do MySQL (cartório) |
| `Descricao` | `descricao` | |
| `Solicitante` | `solicitante` | |
| `Data_Solicitacao` | `data_solicitacao` | `DD/MM/YYYY[ HH:MM:SS]` → `YYYY-MM-DD ...` |
| `Cod_Z` | `cod_z` | |
| `Aplicacao` | `aplicacao` | |
| `Vagao` | `vagao` | |
| `Lote` | `lote` | |
| `NumSfpCC` | `conta` | mapeamento legado (mantido como está) |
| `Historico` | `fila.historico` (texto) + tabela `historico` (timeline) | |
| `Classe` | `classe` | |
| `Conceito_P/St/Ini/Fim`, `Det_*`, `Liberacao_*`, `Corte_*`, `Exec_*`, `Tryout_*`, `Aq_*`, `Prio` | colunas equivalentes em `fila` | status preenchidos no insert |

---

## 5. PASSO A PASSO — rodar a migração de novo

> Use quando quiser recarregar a base do Access no MySQL do zero.

### 5.1 Pré-requisitos
- **Feche o Microsoft Access** (não pode estar com `DB_Projetos.accdb` aberto — senão dá `Erro 70: Permissão negada`).
  - Conferir: o arquivo `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.laccdb` **não** pode existir.
- Rode a macro **de dentro do `Solicitação de Projeto_RevE1.xlsm`** (que está em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE`, Local Confiável e já lê o Access). Rodar de uma planilha em branco (não confiável) causa `Erro 70` ao ler dados.

### 5.2 Gerar o arquivo
1. No Excel (do `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE`), abra o editor VBA (`Alt + F11`).
2. Rode a macro **`MigrarFilaParaMySQL`** (F5).
3. Deve aparecer **"OK! Gerado (sem BOM): K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\migracao.sql"**.
   - Se der erro, o MsgBox mostra a **etapa** e o **número** do erro.

### 5.3 Limpar o MySQL (ordem por causa das FKs)
No HeidiSQL (conectado em `172.29.5.2`):

```sql
DELETE FROM bd_device_request.historico;
DELETE FROM bd_device_request.fila;
DELETE FROM bd_device_request.solicitacoes;
```

### 5.4 Executar a migração
- HeidiSQL → **Arquivo → Executar arquivo SQL...** → `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\migracao.sql` → codificação **UTF-8**.
  (ou *Carregar arquivo SQL* e **F9**.)

### 5.5 Conferir
```sql
SELECT COUNT(*) FROM bd_device_request.solicitacoes;
SELECT COUNT(*) FROM bd_device_request.fila;
SELECT MAX(ref)  FROM bd_device_request.solicitacoes;     -- deve ser o último SL
SELECT COUNT(*) FROM bd_device_request.historico;
SELECT ref, usuario, mensagem, created_at
  FROM bd_device_request.historico ORDER BY ref DESC LIMIT 10;
```
- `COUNT` de `solicitacoes` e `fila` devem ser iguais e bater com o nº de linhas da `Fila` no Access.

---

## 6. PASSO A PASSO — testar a criação pelo Access

1. Garanta que o PHP (`routes.php` + `SolicitacaoController.php`) está **no servidor**.
2. No Access (via Excel), crie uma solicitação de teste.
3. Confira:
```sql
SELECT ref, descricao, solicitante, data_solicitacao, created_at
  FROM bd_device_request.solicitacoes ORDER BY ref DESC LIMIT 3;
SELECT ref, descricao FROM bd_device_request.fila ORDER BY ref DESC LIMIT 3;
SELECT ref, usuario, mensagem, created_at
  FROM bd_device_request.historico ORDER BY created_at DESC LIMIT 5;
```
- O número novo deve aparecer **igual** no Access e nas tabelas do MySQL,
  `data_solicitacao` com hora, e a timeline em `historico`.

---

## 7. Troubleshooting (erros que já apareceram)

| Sintoma | Causa | Solução |
|---|---|---|
| `Erro 70: Permissão negada` ao **ler** o Access | Access aberto (lock `.laccdb`) **ou** macro rodando de planilha não confiável | Feche o Access; rode de dentro do `.xlsm` em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` |
| `Erro 70` na etapa "Salvar arquivo" | `migracao.sql` aberto em outro programa | Feche o arquivo e rode de novo |
| `Sub ou Function não definida` | Faltam os helpers no módulo (`NovoGUID`, `sqlStr`...) | Cole o módulo **completo** (Sub + helpers juntos) |
| SQL `1062 Duplicate entry ... PRIMARY` | `id` (GUID) repetido (Randomize a cada chamada) | `NovoGUID` com `Static seeded` (semeia 1x) |
| SQL `1064 ... near '﻿USE ...'` | BOM do UTF-8 no início do arquivo | Gravar **sem BOM** (pular 3 bytes via ADODB.Stream binário) |
| "Conteúdo bloqueado" / "Risco de segurança" no Excel | Arquivo baixado da internet / pasta não confiável | `Unblock-File` + `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` como **Local Confiável** |
| Login aparece e trava | `frmLogin.Show` no `Workbook_Open` | Comentado no ambiente de teste (entra como "Teste") |

---

## 8. Arquivos-chave

| Item | Caminho |
|---|---|
| Rota | `src/routes/routes.php` |
| Controller | `src/app/controllers/SolicitacaoController.php` (`salvarVba`, `dataBR2SQL`) |
| Entidade | `src/app/database/entities/Solicitacao.php` (`storeFila`, `getNumSL`) |
| VBA Funções | módulo `Funcoes` (`urlBaseApp`, `salvarNoMySQL`, `enc`, `extrairRef`) |
| VBA Criação | form `frm_novo` → `btn_enviar_Click` |
| VBA Migração | macro `MigrarFilaParaMySQL` (+ helpers) |
| Arquivo gerado | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\migracao.sql` |
| Banco Access | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb` |
