# Código completo — Anexos: Access → MySQL (PDF)

Companheiro de [anexos-access-mysql.md](anexos-access-mysql.md). Todo o código novo desta etapa.

Índice:
1. PHP — `routes.php` (rota)
2. PHP — `SolicitacaoController::uploadAnexoVba` (método completo)
3. VBA — `Funcoes` → `enviarPdfParaMySQL` (função completa)
4. VBA — `frm_novo` → `btn_enviar_Click` (o gatilho)

---

## 1. PHP — `src/routes/routes.php`

**Adicionado** após a rota `salvarVba`:

```php
//SALVAR VINDO DO VBA/ACCESS — gera o Ref no MySQL (cartório) com GET_LOCK
Route::post('/dispositivos/solicitacao/salvarVba', SolicitacaoController::class, 'salvarVba')
    ->name('dispositivos.solicitacao.salvarVba');

//UPLOAD do PDF da SL vindo do Access (corpo binário cru) -> storage + tabela anexos   [ADICIONADO]
Route::post('/dispositivos/solicitacao/uploadAnexoVba', SolicitacaoController::class, 'uploadAnexoVba')
    ->name('dispositivos.solicitacao.uploadAnexoVba');
```

---

## 2. PHP — `SolicitacaoController::uploadAnexoVba`

Método novo (não existia). Colado após `dataBR2SQL`:

```php
    /**
     * Recebe o PDF da SL criada no Access (corpo binário cru), salva no storage
     * do web e registra na tabela anexos. Parâmetros: ?ref=NNN&nome=arquivo.pdf
     */
    function uploadAnexoVba()
    {
        $ref  = (int) (Request::query('ref') ?? 0);
        $nome = Request::query('nome') ?: ('SL' . $ref . '.pdf');
        if ($ref <= 0) return Json::return(['error' => 'ref inválido'], 400);

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        // Storage do web (cria a pasta por ref)
        $base = rtrim($_ENV['APP_UPLOADS_DIR'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') $base = '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files';
        $dir = $base . '/' . $ref;
        if (!is_dir($dir)) @mkdir($dir, 0777, true);

        $nomeSeguro = 'SL' . $ref . '_' . basename($nome);
        $destino    = $dir . '/' . $nomeSeguro;

        if (file_put_contents($destino, $conteudo) === false) {
            return Json::return(['error' => 'falha ao salvar o arquivo'], 500);
        }

        // Registra em anexos (FK ref -> fila, que já existe via salvarVba)
        $pdo = Solicitacao::getPDO();
        $pdo->prepare(
            "INSERT INTO bd_device_request.anexos (id, ref, anexo, descricao, created_at)
             VALUES (:id, :ref, :anexo, :descricao, :created_at)"
        )->execute([
            'id'         => \Ramsey\Uuid\Rfc4122\UuidV4::uuid4()->toString(),
            'ref'        => $ref,
            'anexo'      => $destino,
            'descricao'  => 'PDF da solicitação (Access)',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return Json::return(['ok' => true, 'arquivo' => $nomeSeguro], 200);
    }
```

> Usa imports já presentes no topo do controller: `Request`, `Json`, `Solicitacao`.

---

## 3. VBA — módulo `Funcoes` → `enviarPdfParaMySQL`

Função nova (parâmetros **ByVal** para aceitar o `t_ref` Variant):

```vba
' Envia um arquivo (PDF) para o web. Retorna True se OK.
Function enviarPdfParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http As Object, st As Object, url As String, nomeArq As String, bytes
    enviarPdfParaMySQL = False

    If Dir(caminhoArquivo) = "" Then Exit Function   ' arquivo não existe

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)

    ' lê os bytes do arquivo
    Set st = CreateObject("ADODB.Stream")
    st.Type = 1            ' adTypeBinary
    st.Open
    st.LoadFromFile caminhoArquivo
    bytes = st.Read
    st.Close

    url = urlBaseApp() & "/dispositivos/solicitacao/uploadAnexoVba?ref=" & ref & "&nome=" & enc(nomeArq)
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.Send bytes

    If http.Status = 200 Then
        enviarPdfParaMySQL = True
    Else
        MsgBox "Falha ao enviar PDF (" & http.Status & "): " & http.responseText, vbExclamation
    End If
End Function
```

> O módulo `Funcoes` completo está em
> [sincronizacao-mysql-access-codigo.md](sincronizacao-mysql-access-codigo.md) (seção 2) —
> esta função entra junto das demais (`urlBaseApp`, `salvarNoMySQL`, `enc`, `extrairRef`, `sincronizarDoMySQL`).

---

## 4. VBA — `frm_novo` → `btn_enviar_Click` (gatilho)

A chamada entra **dentro do bloco que renomeia o PDF** (só dispara quando há anexo):

```vba
        newFileName = "SL" & Format(t_ref, "0000") & ".pdf"
        If lblFilePath.Caption <> "" Then
            Name "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & Right(frm_novo.lblFilePath.Caption, Len(frm_novo.lblFilePath.Caption) - InStrRev(frm_novo.lblFilePath.Caption, "\")) As _
            "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & newFileName
            enviarPdfParaMySQL t_ref, "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & newFileName    ' [ADICIONADO] manda o PDF pro web
        End If
```

> O `frm_novo` completo está em
> [migracao-access-mysql-codigo.md](migracao-access-mysql-codigo.md) (seção 4, "DEPOIS") —
> mais a linha `enviarPdfParaMySQL` acima.
