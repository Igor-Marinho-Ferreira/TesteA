# Anexos: MySQL → Access (PDF/arquivos da criação)

Documenta o caminho inverso: quando a SL é criada na **web (MySQL)** com anexos, como o arquivo
chega na **pasta do Access** e como o Access **abre** esses arquivos.
Faz par com [anexos-access-mysql.md](anexos-access-mysql.md) (Access → MySQL).

> 📎 **Código completo:** [anexos-mysql-access-codigo.md](anexos-mysql-access-codigo.md).

- **Servidor:** Debian `172.29.5.2`, base `bd_device_request`.
- **Pasta mapeada (Debian):** `APP_ACCESS_DIR=/var/www/htdocs/greenbrier/v2/solic_dispositivos-excel`
- **Access (teste):** lê de `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\`, `.img_sl\`, `.bom\`, `.desenhos\`, `.img_z\`

---

## 1. Conceito

A web salva o anexo no storage dela (como hoje) **e copia** para a **pasta mapeada** (que está
montada/compartilhada com o Windows), na **convenção de nome do Access**. Aí o Access acha o arquivo
pela pasta + nome, sem transferir binário.

- **Cardinalidade:** Access abre **1 PDF** por SL (`SL{ref}.pdf`); a web aceita **N** arquivos.
  → o **1º PDF** vira `SL{ref}.pdf`; os **extras** vão para uma subpasta `SL{ref}/`.

---

## 2. Antes × Depois

| | ANTES | DEPOIS |
|---|---|---|
| Anexo criado na web ia pra pasta do Access? | ❌ Não | ✅ Sim (`copy()` na pasta mapeada) |
| Access abria o PDF da web? | ❌ Não (path antigo `K:\...`) | ✅ Sim (`frmsol` agora em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\`) |
| Nome no Access | — | `.Files/SL{ref}.pdf` (1º PDF) + `.Files/SL{ref}/` (extras) |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — `.env`
```
APP_ACCESS_DIR=/var/www/htdocs/greenbrier/v2/solic_dispositivos-excel
```
Caminho (no Debian) da pasta mapeada/compartilhada com o Windows. Os arquivos do Access
ficam em subpastas dela (`.Files`, `.img_sl`, …).

### 3.2 PHP — `SolicitacaoController`
- **Hook** no `storeSolicitacao`: depois de salvar os anexos, chama `copiarAnexosParaAccess(...)`.
- **`copiarAnexosParaAccess($ref, $anexos)`:**
  - Base = `APP_ACCESS_DIR` + `/.Files`.
  - 1º arquivo com extensão **pdf** → `.Files/SL{ref}.pdf` (`ref` com 4 dígitos: `SL4001`).
  - Demais → `.Files/SL{ref}/nome_original`.

### 3.3 VBA — `frmsol` (abrir os arquivos)
Os caminhos estavam apontando pro servidor antigo `K:\eng_ind\...`. Foram trocados para
`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\` (5 pontos): `.Files`, `.img_sl`, `.img_z`, `.bom`, `.desenhos`.
Sem isso, o `btnVisualizar` dava **"Arquivo não Encontrado!"**.

---

## 4. Fluxo

```
Web cria SL (N anexos)
   → storage + tabela anexos                 (uso do web)
   → copiarAnexosParaAccess:
        1º PDF  → {APP_ACCESS_DIR}/.Files/SL{ref}.pdf
        extras  → {APP_ACCESS_DIR}/.Files/SL{ref}/...
        (pasta mapeada = pasta do Access via mount/compartilhamento)

Access (frmsol):
   btnVisualizar → abre K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\SL{ref}.pdf
```

---

## 5. Passo a passo para testar

1. **Re-deploy** do `SolicitacaoController.php` + `.env` no servidor.
2. Garanta que `APP_ACCESS_DIR` está montado/ligado à pasta que o Access lê.
3. Crie uma SL **pela web com PDF** (e talvez um 2º arquivo).
4. Confira no servidor:
   ```
   {APP_ACCESS_DIR}/.Files/SL{ref}.pdf
   {APP_ACCESS_DIR}/.Files/SL{ref}/...        (extras)
   ```
5. No Access, traga a SL (`sincronizarDoMySQL`) e clique em **Visualizar** → o PDF abre.

---

## 6. Troubleshooting

| Sintoma | Causa | Solução |
|---|---|---|
| "Arquivo não Encontrado!" no Visualizar | `frmsol` apontava pra `K:\...` antigo | Trocar os caminhos do `frmsol` para `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\` |
| PDF não abre mesmo com path certo | Nome não casa (`SL41` vs `SL0041`) | `lbl_ref.Caption` precisa ser `SL` + 4 dígitos (igual ao salvo) |
| Nada é copiado pra pasta | `APP_ACCESS_DIR` vazio/sem permissão | Definir `APP_ACCESS_DIR` (pasta gravável) no `.env` do servidor |
| Cai no lugar errado (sem `.Files`) | A pasta mapeada já é o `.Files` | Ajustar para escrever na raiz do `APP_ACCESS_DIR` |

---

## 7. Limitações / próximos passos

- **Create-time** apenas. Anexos da fase de desenvolvimento (DXF, desenhos, cortes) são fluxo à parte.
- Access abre **1 PDF** (`SL{ref}.pdf`); os extras da web ficam guardados na subpasta, mas o VBA atual
  não os lista (poderia ser melhorado depois).

---

## 8. Arquivos-chave

| Item | Caminho |
|---|---|
| Config | `.env` → `APP_ACCESS_DIR` |
| Cópia web→Access | `SolicitacaoController::copiarAnexosParaAccess` (chamado em `storeSolicitacao`) |
| Abrir no Access | `frmsol` → `btnVisualizar`, `btnBOM`, `btn_pdf`, `lbl_abrir`, `pdf_lst_DblClick` |
