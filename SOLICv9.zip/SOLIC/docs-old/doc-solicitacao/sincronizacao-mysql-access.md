# Sincronização MySQL → Access (trazer SLs da web para o Access)

Documenta a volta do fluxo: quando uma SL é criada na **web (MySQL)**, como ela aparece no **Access**.
Par do documento [migracao-access-mysql.md](migracao-access-mysql.md) (que cobre Access → MySQL).

> 📎 **Código completo (PHP + VBA, antes/depois):** [sincronizacao-mysql-access-codigo.md](sincronizacao-mysql-access-codigo.md).

- **Servidor:** Debian `172.29.5.2` (MariaDB), base `bd_device_request`.
- **URL base:** `http://172.29.5.2/greenbrier/v2/solic_dispositivos`
- **Access (teste):** `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb`

---

## 1. Conceito

O Debian **não escreve no Access** (sem driver) nem empurra nada. Então o **Access puxa** do MySQL:

```
Web cria SL → grava no MySQL
        ↓
Access roda "sincronizarDoMySQL" (botão) → BAIXA o CSV do MySQL → insere o que falta
```

**Escopo atual: insert-only.** Traz para o Access os registros (Refs) que **ainda não existem** lá.
Não atualiza nem apaga linhas existentes — porque **edição** será tratada num passo separado
(decisão: edição acontece nos dois lados, exige Access→MySQL em tempo real + regra de conflito).

---

## 2. Antes × Depois

| | ANTES | DEPOIS |
|---|---|---|
| SL criada na web aparecia no Access? | ❌ Não (só Access→MySQL existia) | ✅ Sim, via `sincronizarDoMySQL` |
| Mecanismo | `ExecutaImportacao` antigo: `DELETE FROM Fila` + reinsere (destrutivo) | **insert-only** por Ref (não apaga nada) |
| Histórico no Access | achatado numa linha só (CSV trocava quebras por espaço) | **multilinha**, no padrão do Access (token `[BR]`) |
| Lista na tela | não atualizava | reaplica o filtro atual ao fim |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — `src/app/controllers/SolicitacaoController.php`

A rota `GET /dispositivos/csvAtualizado/fila` → `trataCsv` **já existia** e gera o CSV a partir do
`fila` do MySQL (com o histórico reconstruído da tabela `historico` via `getAllTratado`).
Os **cabeçalhos do CSV = nomes das colunas do Access** (1:1).

**Mudança feita:** o histórico passou a preservar as quebras de linha como token **`[BR]`**
(em vez de virar espaço), para chegar multilinha no Access. Adicionado o closure `$histAccess`
e trocado o uso no campo `Historico`.

> ⚠️ Alterou o PHP local em `D:\SOLIC` → **re-deploy** no servidor.

### 3.2 VBA — módulo `Funcoes` → `sincronizarDoMySQL`

Sub nova que:
1. Baixa o CSV (`MSXML2.ServerXMLHTTP`, GET) e remove o BOM.
2. Abre o Access via **DAO** (`OpenDatabase`) — grava de verdade no `.accdb`.
3. Carrega num `Dictionary` os **Refs já existentes** no Access.
4. Para cada linha do CSV cujo Ref **não existe**: `AddNew` + preenche por nome de coluna + `Update`.
   - No campo `Historico`, troca `[BR]` por quebra de linha (multilinha).
   - Cada atribuição tem `On Error Resume Next` (tipo incompatível → campo fica nulo, não derruba a linha).
5. Ao fim, **reaplica o filtro atual** (`Range("I3")` → `filtro_xx`/`lista_pendentes`/`lista_todos`)
   para a lista na tela mostrar os novos.

### 3.3 Botão na planilha

Um botão de Controle de Formulário com a macro `sincronizarDoMySQL` atribuída (ver seção 5).

---

## 4. Fluxo

```
PHP trataCsv (pronto, + [BR] no histórico)
        │  GET /dispositivos/csvAtualizado/fila
        ▼
VBA sincronizarDoMySQL  →  DAO  →  Access (insert-only, Refs que faltam)
        │
        └─ reaplica o filtro → lista atualiza na tela
```

---

## 5. Como criar o botão

1. Excel → aba **Desenvolvedor** (se não tiver: *Arquivo → Opções → Personalizar Faixa de Opções → marcar "Desenvolvedor"*).
2. **Inserir → Controles de Formulário → Botão**.
3. **Desenhe** o botão numa área livre.
4. Na janela **"Atribuir macro"**, escolha **`sincronizarDoMySQL`** → OK.
5. Botão direito no botão → **Editar Texto** → "Atualizar do MySQL".
6. Clique fora. Pronto.

> Para editar o botão depois, clique com o **botão direito** (clique normal dispara a macro).

---

## 6. Passo a passo para usar / testar

1. Garanta o **PHP no servidor** (re-deploy do `SolicitacaoController.php`).
2. Crie uma SL **pela web** (MySQL).
3. No Access, clique em **"Atualizar do MySQL"** (ou `Alt+F8` → `sincronizarDoMySQL`).
4. Deve aparecer "Novos inseridos: N", a SL surge na `Fila`, com histórico multilinha, e a lista atualiza.

Conferir no MySQL/HeidiSQL o que existe:
```sql
SELECT ref, descricao, solicitante FROM bd_device_request.fila ORDER BY ref DESC LIMIT 10;
```

---

## 7. Limitações / próximos passos

- **Insert-only:** edições feitas na web **não** descem para o Access (e vice-versa). Isso é proposital
  até implementarmos a **edição nos dois lados** (Access→MySQL em tempo real + regra de conflito).
- **Exclusões** não propagam (registro apagado num lado continua no outro).
- **Disparo manual** (botão). Automação por agendamento fica para depois.

---

## 8. Troubleshooting (erros que apareceram)

| Sintoma | Causa | Solução |
|---|---|---|
| `Operação não permitida nesse contexto` | Recordset ADODB abriu somente-leitura | Usar **DAO** (`OpenDatabase` + `OpenRecordset` dinaset) |
| "Diz que inseriu mas não aparece" | Cursor de cliente ADODB não commitava o `AddNew` | **DAO** grava direto no `.accdb` |
| `Sub ou Function não definida` no `OpenDatabase` | Falta a referência DAO | *Ferramentas → Referências →* marcar "Microsoft Office 16.0 Access database engine Object Library" |
| Histórico achatado numa linha | CSV trocava quebras por espaço | PHP grava `[BR]`; VBA troca `[BR]` por quebra de linha |
| Lista na tela não atualiza | faltava reaplicar o filtro | Ao fim, `Select Case Range("I3")` → `filtro_xx`/`lista_*` |

---

## 9. Arquivos-chave

| Item | Caminho |
|---|---|
| Rota CSV | `src/routes/routes.php` → `dispositivos/csvAtualizado/fila` |
| Geração do CSV | `SolicitacaoController::trataCSV` (+ `$histAccess`) |
| Fonte dos dados | `Acompanhamento::getAllTratado` (lê `fila` + reconstrói `historico`) |
| VBA | módulo `Funcoes` → `sincronizarDoMySQL` |
