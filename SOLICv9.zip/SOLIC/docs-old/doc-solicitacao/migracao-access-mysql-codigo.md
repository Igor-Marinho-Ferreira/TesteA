# Código completo — Migração Access → MySQL e criação de SL

Companheiro de [migracao-access-mysql.md](migracao-access-mysql.md).
Aqui está **todo o código, 100% completo**, com **antes × depois**. Nas versões "DEPOIS" o código
está **inteiro** (o que já existia + o que foi adicionado), com marcações
`[ADICIONADO]` / `[ALTERADO]` / `[REMOVIDO]`.

Índice:
0. Alteração no **Access** (campo `Ref`)
1. PHP — `routes.php`
2. PHP — `SolicitacaoController.php` (`salvarVba`, `dataBR2SQL`)
3. VBA — módulo `Funcoes` (antes / depois completo)
4. VBA — `frm_novo` (antes do trecho / depois completo)
5. VBA — macro de migração `MigrarFilaParaMySQL` (completa)

---

## 0. Alteração no Access (feita manualmente, uma vez)

Na base `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb`, tabela **`Fila`**, campo **`Ref`**:

- **ANTES:** Tipo de dados = **Numeração Automática** (o Access gerava o número sozinho).
- **DEPOIS:** Tipo de dados = **Número**, Tamanho do campo = **Inteiro Longo**.

**Por quê:** para o MySQL ser o "cartório" do número, o Access precisa **aceitar** o `Ref`
que mandamos (a Numeração Automática não deixa). Como a Numeração Automática já é um
Inteiro Longo por baixo, **os valores existentes são preservados** — só perde o auto-incremento.

**Como fazer:**
1. Backup do `.accdb`.
2. Feche formulários/consultas que usem a `Fila`.
3. (Se `Ref` estiver em Relacionamentos, remova a linha do relacionamento antes; recrie depois.)
4. Abra `Fila` em **Modo Design** → linha `Ref` → **Tipo de dados** = "Número" → **Tamanho do campo** = "Inteiro Longo".
5. Salve.

> Depois disso, **todo INSERT precisa informar o `Ref`** — é o que o novo `btn_enviar_Click` faz
> (com o número vindo do MySQL).

---

## 1. PHP — `src/routes/routes.php`

**Adicionado** logo após a rota `store`:

```php
Route::post('/dispositivos/solicitacao/store', SolicitacaoController::class, 'storeSolicitacao')
    ->name('dispositivos.solicitacao.store');

//SALVAR VINDO DO VBA/ACCESS — gera o Ref no MySQL (cartório) com GET_LOCK   [ADICIONADO]
Route::post('/dispositivos/solicitacao/salvarVba', SolicitacaoController::class, 'salvarVba')
    ->name('dispositivos.solicitacao.salvarVba');

//MIGRAÇÃO INICIAL Access -> MySQL (carga única, upsert preservando o Ref)   [ADICIONADO]
Route::post('/dispositivos/solicitacao/migrarFila', SolicitacaoController::class, 'migrarFila')
    ->name('dispositivos.solicitacao.migrarFila');
```

> A rota `migrarFila` é alternativa (carga via POST). A migração que usamos na prática é a
> macro VBA que gera `migracao.sql` + HeidiSQL (seção 5).

---

## 2. PHP — `src/app/controllers/SolicitacaoController.php`

**Métodos novos** (não existiam antes — portanto não há "ANTES"). Colados após `storeSolicitacao`:

```php
    /**
     * Recebe uma solicitação criada no Access (VBA), gera o Ref no MySQL
     * de forma atômica (GET_LOCK) e grava em solicitacoes + fila.
     * Devolve { "ref": NNNN } para o VBA usar no INSERT do Access.
     */
    function salvarVba()
    {
        $pdo = Solicitacao::getPDO();

        $dataSql = $this->dataBR2SQL(Request::input('data_solicitacao'));

        try {
            // Serializa a emissão do número NESTA conexão (evita Ref duplicado)
            $pdo->query("SELECT GET_LOCK('solic_ref', 10)")->fetchColumn();

            // Próximo Ref = MAX + 1
            $ref = (int) $pdo->query(
                "SELECT COALESCE(MAX(ref), 0) + 1 FROM bd_device_request.solicitacoes"
            )->fetchColumn();

            // Reserva o Ref já inserindo em solicitacoes (mesma conexão do lock)
            $stmt = $pdo->prepare(
                "INSERT INTO bd_device_request.solicitacoes
                 (id, ref, descricao, solicitante, data_solicitacao, cod_z, aplicacao, vagao, lote, conta, classe, escopo, created_at)
                 VALUES (:id, :ref, :descricao, :solicitante, :data_solicitacao, :cod_z, :aplicacao, :vagao, :lote, :conta, :classe, :escopo, :created_at)"
            );
            $stmt->execute([
                'id'               => \Ramsey\Uuid\Rfc4122\UuidV4::uuid4()->toString(),
                'ref'              => $ref,
                'descricao'        => Request::input('descricao'),
                'solicitante'      => Request::input('solicitante'),
                'data_solicitacao' => $dataSql,
                'cod_z'            => Request::input('cod_z'),
                'aplicacao'        => Request::input('aplicacao'),
                'vagao'            => Request::input('vagao'),
                'lote'             => Request::input('lote'),
                'conta'            => Request::input('conta'),
                'classe'           => Request::input('classe'),
                'escopo'           => Request::input('historico'),
                'created_at'       => date('Y-m-d H:i:s'),
            ]);
        } catch (\Exception $e) {
            $pdo->query("SELECT RELEASE_LOCK('solic_ref')")->fetchColumn();
            return Json::return(['error' => 'Falha ao gerar Ref: ' . $e->getMessage()], 500);
        }

        // Libera o lock assim que o Ref está reservado
        $pdo->query("SELECT RELEASE_LOCK('solic_ref')")->fetchColumn();

        // Grava na fila (status PENDENTE/PARADO via storeFila)
        Solicitacao::storeFila([
            'descricao'        => Request::input('descricao'),
            'solicitante'      => Request::input('solicitante'),
            'cod_z'            => Request::input('cod_z'),
            'aplicacao'        => Request::input('aplicacao'),
            'vagao'            => Request::input('vagao'),
            'lote'             => Request::input('lote'),
            'conta'            => Request::input('conta'),
            'classe'           => Request::input('classe'),
            'historico'        => Request::input('historico'),
            'data_solicitacao' => $dataSql,
            'prio'             => 99,
        ], $ref, 'bd_device_request.fila');

        // Histórico inicial (timeline) — mesma ideia do fluxo da web
        Historico::create([
            'ref'      => $ref,
            'usuario'  => Request::input('solicitante'),
            'mensagem' => Request::input('historico'),
        ]);

        return Json::return(['ref' => $ref], 200);
    }

    /**
     * Converte data do VBA para o MySQL.
     * Aceita 'DD/MM/YYYY' e 'DD/MM/YYYY HH:MM:SS'. Se já vier em
     * 'YYYY-MM-DD ...' (sem '/'), passa direto.
     */
    private function dataBR2SQL($valor)
    {
        if (empty($valor)) return null;
        $valor = trim($valor);
        $partes = explode(' ', $valor, 2);          // separa data e hora
        $d = explode('/', $partes[0]);
        if (count($d) !== 3) return $valor;          // já está em formato SQL
        $sql = sprintf('%04d-%02d-%02d', $d[2], $d[1], $d[0]);
        if (isset($partes[1]) && trim($partes[1]) !== '') $sql .= ' ' . trim($partes[1]);
        return $sql;
    }
```

> Imports usados (já existiam no topo): `use src\support\Request;`, `use src\support\Json;`,
> `use src\app\database\entities\Solicitacao;`, `use src\app\database\entities\Historico;`.

---

## 3. VBA — módulo `Funcoes`

### 3.1 ANTES (original)

```vba
Global G_Lider As String
Global G_Solicitante As String

Function resQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

cnn.Close

End Function

Sub Reset()
Application.ScreenUpdating = True
Application.EnableEvents = True
End Sub

Sub Desabilita()
Application.ScreenUpdating = False
Application.EnableEvents = False
End Sub
```

### 3.2 DEPOIS (módulo COMPLETO — original + 4 funções novas)

```vba
Global G_Lider As String
Global G_Solicitante As String

Function resQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

cnn.Close

End Function

Sub Reset()
Application.ScreenUpdating = True
Application.EnableEvents = True
End Sub

Sub Desabilita()
Application.ScreenUpdating = False
Application.EnableEvents = False
End Sub

' ============================================================
' [ADICIONADO] Integração com o MySQL
' ============================================================

' [ADICIONADO] Base do PHP (servidor de teste)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' [ADICIONADO] Envia a solicitação ao MySQL e retorna o Ref gerado (0 = falhou)
Function salvarNoMySQL(desc, solic, dataSolic, codZ, aplic, vg, lote, nSFP, hist, classe) As Long
    Dim http As Object, url As String, body As String
    url = urlBaseApp() & "/dispositivos/solicitacao/salvarVba"

    body = "descricao=" & enc(desc) & _
           "&solicitante=" & enc(solic) & _
           "&data_solicitacao=" & enc(dataSolic) & _
           "&cod_z=" & enc(codZ) & _
           "&aplicacao=" & enc(aplic) & _
           "&vagao=" & enc(vg) & _
           "&lote=" & enc(lote) & _
           "&conta=" & enc(nSFP) & _
           "&historico=" & enc(hist) & _
           "&classe=" & enc(classe)

    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send body

    If http.Status <> 200 Then
        MsgBox "Erro ao salvar no MySQL (" & http.Status & "): " & http.responseText, vbCritical
        salvarNoMySQL = 0
        Exit Function
    End If

    salvarNoMySQL = extrairRef(http.responseText)   ' resposta: {"ref":4001}
End Function

' [ADICIONADO] Escapa um valor para a URL/POST
Function enc(v) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' [ADICIONADO] Extrai o número do "ref" da resposta JSON
Function extrairRef(jsonTxt As String) As Long
    Dim p As Long, s As String, i As Long, ch As String, num As String
    p = InStr(jsonTxt, """ref""")
    If p = 0 Then extrairRef = 0: Exit Function
    s = Mid(jsonTxt, p + 5)
    For i = 1 To Len(s)
        ch = Mid(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            num = num & ch
        ElseIf num <> "" Then
            Exit For
        End If
    Next i
    extrairRef = CLng("0" & num)
End Function
```

---

## 4. VBA — `frm_novo`

As mudanças foram no `btn_enviar_Click` (e no caminho do `btnAnexar_Click`).
Abaixo o **módulo `frm_novo` COMPLETO** em duas versões: **ANTES** e **DEPOIS**.

### 4.1 ANTES — módulo `frm_novo` COMPLETO (original)

```vba
Dim newFileName As String
Dim oldFileName As String


Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_enviar_Click()

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        Dim SQL As String


        desc = UCase(frm_novo.txt_solicitacao.Text)
        solic = frm_novo.lbl_solic.Caption
        cod_z = frm_novo.txt_cod.Text
        cod_z = Replace(cod_z, "z", "Z")
        nSFP = frm_novo.cmbSFP.Text
        nSW = "SW" & frm_novo.txt_nSW.Text



        If IsNumeric(cod_z) Then cod_z = "Z" & Format(cod_z, "0000")


        aplic = frm_novo.cmb_aplic.Text
        vg = frm_novo.cmb_vg.Text
        lote = frm_novo.cmb_lote.Text

        classe = ""

        If frm_novo.opt_1 Then classe = frm_novo.opt_1.Caption
        If frm_novo.opt_1 Then desc = desc & " " & nSW
        If frm_novo.opt_2 Then classe = frm_novo.opt_2.Caption
        If frm_novo.opt_2 Then desc = desc & " " & nSW
        If frm_novo.opt_3 Then classe = frm_novo.opt_3.Caption
        If frm_novo.opt_3 Then desc = desc & " " & nSW
        If frm_novo.opt_4 Then classe = frm_novo.opt_4.Caption
        If frm_novo.opt_5 Then classe = frm_novo.opt_5.Caption
        If frm_novo.opt_6 Then classe = frm_novo.opt_6.Caption
        If frm_novo.opt_7 Then classe = frm_novo.opt_7.Caption
        If frm_novo.opt_8 Then classe = frm_novo.opt_8.Caption
        If frm_novo.opt_9 Then classe = frm_novo.opt_9.Caption

        If classe = "" Then classe = frm_novo.opt_4.Caption

        msg = frm_novo.txt_escopo.Text & vbCrLf
        qtd_requerida = frm_novo.txt_qtd.Text
        partNumber_ref = frm_novo.txt_partNumber.Text
        dicaLocal_ref = frm_novo.txt_dicaLocal.Text
            inicio = "** DADOS DE ENTRADA **" & vbCrLf
            cabec = "-- " & solic & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf
            qtd = "-- Quantidade Necessária: " & qtd_requerida & " --" & vbCrLf
            prtN = "-- Part Number de Referência: " & partNumber_ref & " --" & vbCrLf
            obsLocal = "-- Detalhes do Local: " & dicaLocal_ref & " --" & vbCrLf

            If chk_partNumber.Value = True And chk_dicaLocal.Value = True Then
                hist = inicio & cabec & msg & qtd & prtN & obsLocal
            ElseIf chk_partNumber.Value = True Then
                hist = inicio & cabec & msg & qtd & prtN
            ElseIf chk_dicaLocal.Value = True Then
                hist = inicio & cabec & msg & qtd & obsLocal
            Else
                hist = inicio & cabec & msg & qtd
            End If


            hist = Replace(hist, "'", "")

        data_solic = Format(Now, "DD/MM/YYYY")

        SQL = "INSERT INTO Fila (Descricao, Solicitante, Data_Solicitacao, Cod_Z, Aplicacao, Vagao, Lote, NumSfpCC, Historico, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St, Prio, Classe) VALUES ('"
        SQL = SQL & desc & "', '"
        SQL = SQL & solic & "', '"
        SQL = SQL & data_solic & "', '"
        SQL = SQL & cod_z & "', '"
        SQL = SQL & aplic & "', '"
        SQL = SQL & vg & "', '"
        SQL = SQL & lote & "', '"
        SQL = SQL & nSFP & "', '"
        SQL = SQL & hist & "' , 'PENDENTE', 'PENDENTE', 'PENDENTE', 'PENDENTE', 'PARADO', 'PARADO', 'PENDENTE', 99, '" & classe & "');"

        upQuery (SQL)


        SQL = "SELECT MAX(Ref) FROM Fila;"
        arrRes = resQuery(SQL)
        t_ref = arrRes(0, 0)
        newFileName = "SL" & Format(t_ref, "0000") & ".pdf"
        'Debug.Print newFileName
        If lblFilePath.Caption <> "" Then
            Name "K:\eng_ind\PROJETOS_Controle_bkp\Eng_Processos\Projeto_RevE\.Files\" & Right(frm_novo.lblFilePath.Caption, Len(frm_novo.lblFilePath.Caption) - InStrRev(frm_novo.lblFilePath.Caption, "\")) As _
            "K:\eng_ind\PROJETOS_Controle_bkp\Eng_Processos\Projeto_RevE\.Files\" & newFileName
        End If


        MsgBox "Solicitação inserida Ref.: SL" & Format(t_ref, "0000")

        Unload Me

        filtro = Range("I3").Value
        If filtro = 1 Then filtro_01
        If filtro = 2 Then filtro_02
        If filtro = 3 Then filtro_03
        If filtro = 4 Then filtro_04
        If filtro = 5 Then filtro_05
        If filtro = 6 Then filtro_06
        If filtro = 7 Then lista_todos
        If filtro = 0 Then lista_pendentes
    Else
        frm_novo.lblMissing.ForeColor = &HC0&
        'frm_novo.lblMissing.Font.Bold = True
    End If

End Sub


Private Sub btnAnexar_Click()

Dim fso As Object
Dim oldFileName As String

FilePath = Application.GetOpenFilename("Pdf Files (*.pdf),*.pdf", Title:="Selecione um arquivo .pdf")
lblFilePath.Caption = FilePath
oldFileName = Right(FilePath, Len(FilePath) - InStrRev(FilePath, "\"))
'Debug.Print oldFileName
destinationPath = "K:\eng_ind\PROJETOS_Controle_bkp\Eng_Processos\Projeto_RevE\.Files\" & t_ref & Mid(FilePath, InStrRev(FilePath, "\") + 1)
'Debug.Print destinationPath
Set fso = CreateObject("Scripting.FileSystemObject")
fso.CopyFile FilePath, destinationPath

End Sub

Private Sub chk_dicaLocal_Click()

    If chk_dicaLocal.Value = True Then
        txt_dicaLocal.Enabled = True
        txt_dicaLocal.SpecialEffect = fmSpecialEffectFlat
        txt_dicaLocal.BorderStyle = fmBorderStyleSingle
        chk_dicaLocal.Caption = "Obs. Local*:"
    Else
        txt_dicaLocal.Enabled = False
        txt_dicaLocal.SpecialEffect = fmSpecialEffectSunken
        txt_dicaLocal.BorderStyle = fmBorderStyleNone
        txt_dicaLocal.Text = ""
        chk_dicaLocal.Caption = "Obs. Local:"
    End If
End Sub

Private Sub chk_partNumber_Click()

    If chk_partNumber.Value = True Then
        txt_partNumber.Enabled = True
        txt_partNumber.SpecialEffect = fmSpecialEffectFlat
        txt_partNumber.BorderStyle = fmBorderStyleSingle
        chk_partNumber.Caption = "Part Number*:"
    Else
        txt_partNumber.Enabled = False
        txt_partNumber.SpecialEffect = fmSpecialEffectSunken
        txt_partNumber.BorderStyle = fmBorderStyleNone
        txt_partNumber.Text = ""
        chk_partNumber.Caption = "Part Number:"
    End If

End Sub

Private Sub cmb_vg_Change()

Dim SQL As String
'Combo Lote

vg = frm_novo.cmb_vg.Text
sfp = frm_novo.cmbSFP.Value

SQL = "SELECT DISTINCT Lote FROM dmAccounts WHERE Vagao = '" & vg & "'AND boValidade = true ORDER BY Lote;"


    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

End Sub

Private Sub cmbSFP_Change()

Dim SQL As String
nSFP = Me.cmbSFP.Text


'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true AND numSfpCC = '" & nSFP & "';"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a
    If cmb_vg.ListCount = 1 Then cmb_vg.ListIndex = 0 Else cmb_vg.ListIndex = -1
        End If


'Combo Lote

    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true AND numSfpCC = '" & nSFP & "';"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    If cmb_lote.ListCount = 1 Then cmb_lote.ListIndex = 0 Else cmb_lote.ListIndex = -1
    End If


Dim SQLSfp As String

    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    cmb_vg.Enabled = True
    cmb_lote.Enabled = True
End Sub



Private Sub lblMissing_Click()

End Sub

Private Sub opt_1_Click()   'notificação de segurança
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True

    Dim SQLSfp As String
    Dim SQL As String

    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True



End Sub

Private Sub opt_2_Click() 'SW
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True
End Sub

Private Sub opt_3_Click()   'CIPA
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True

    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True
End Sub

Private Sub opt_4_Click()
    cmbSFP.Visible = True
    lblSFP.Caption = ""
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    cmbSFP.Value = ""
    cmb_vg.Value = ""
    cmb_lote.Value = ""
    cmbSFP.Enabled = True
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_5_Click()

    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True

    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_6_Click()
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True

    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False
End Sub

Private Sub opt_7_Click()

    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_8_Click()

    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_9_Click()
    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False
End Sub


Private Sub txt_escopo_Change()
    frm_novo.cont.Caption = Format(Len(frm_novo.txt_escopo.Text), "000")

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        frm_novo.lblMissing.ForeColor = &H80000012
    End If

End Sub


Private Sub txt_qtd_Change()

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        frm_novo.lblMissing.ForeColor = &H80000012
    End If

End Sub

Private Sub txt_solicitacao_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    desc = frm_novo.txt_solicitacao.Text
    If desc <> "" Then frm_novo.txt_solicitacao.Text = UCase(frm_novo.txt_solicitacao.Text)
End Sub

Private Sub UserForm_Click()

End Sub
```

### 4.2 DEPOIS — módulo `frm_novo` COMPLETO

```vba
Dim newFileName As String
Dim oldFileName As String


Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_enviar_Click()

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        Dim SQL As String


        desc = UCase(frm_novo.txt_solicitacao.Text)
        solic = frm_novo.lbl_solic.Caption
        cod_z = frm_novo.txt_cod.Text
        cod_z = Replace(cod_z, "z", "Z")
        nSFP = frm_novo.cmbSFP.Text
        nSW = "SW" & frm_novo.txt_nSW.Text



        If IsNumeric(cod_z) Then cod_z = "Z" & Format(cod_z, "0000")


        aplic = frm_novo.cmb_aplic.Text
        vg = frm_novo.cmb_vg.Text
        lote = frm_novo.cmb_lote.Text

        classe = ""

        If frm_novo.opt_1 Then classe = frm_novo.opt_1.Caption
        If frm_novo.opt_1 Then desc = desc & " " & nSW
        If frm_novo.opt_2 Then classe = frm_novo.opt_2.Caption
        If frm_novo.opt_2 Then desc = desc & " " & nSW
        If frm_novo.opt_3 Then classe = frm_novo.opt_3.Caption
        If frm_novo.opt_3 Then desc = desc & " " & nSW
        If frm_novo.opt_4 Then classe = frm_novo.opt_4.Caption
        If frm_novo.opt_5 Then classe = frm_novo.opt_5.Caption
        If frm_novo.opt_6 Then classe = frm_novo.opt_6.Caption
        If frm_novo.opt_7 Then classe = frm_novo.opt_7.Caption
        If frm_novo.opt_8 Then classe = frm_novo.opt_8.Caption
        If frm_novo.opt_9 Then classe = frm_novo.opt_9.Caption

        If classe = "" Then classe = frm_novo.opt_4.Caption

        msg = frm_novo.txt_escopo.Text & vbCrLf
        qtd_requerida = frm_novo.txt_qtd.Text
        partNumber_ref = frm_novo.txt_partNumber.Text
        dicaLocal_ref = frm_novo.txt_dicaLocal.Text
            inicio = "** DADOS DE ENTRADA **" & vbCrLf
            cabec = "-- " & solic & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf
            qtd = "-- Quantidade Necessária: " & qtd_requerida & " --" & vbCrLf
            prtN = "-- Part Number de Referência: " & partNumber_ref & " --" & vbCrLf
            obsLocal = "-- Detalhes do Local: " & dicaLocal_ref & " --" & vbCrLf

            If chk_partNumber.Value = True And chk_dicaLocal.Value = True Then
                hist = inicio & cabec & msg & qtd & prtN & obsLocal
            ElseIf chk_partNumber.Value = True Then
                hist = inicio & cabec & msg & qtd & prtN
            ElseIf chk_dicaLocal.Value = True Then
                hist = inicio & cabec & msg & qtd & obsLocal
            Else
                hist = inicio & cabec & msg & qtd
            End If


            hist = Replace(hist, "'", "")

        data_solic = Format(Now, "DD/MM/YYYY")
        Dim data_solic_sql As String                         ' [ADICIONADO]
        data_solic_sql = Format(Now, "DD/MM/YYYY HH:NN:SS")   ' [ADICIONADO] com hora p/ o MySQL

        ' [ADICIONADO] 1) Gera o Ref no MySQL (cartório) e já grava lá
        t_ref = salvarNoMySQL(desc, solic, data_solic_sql, cod_z, aplic, vg, lote, nSFP, hist, classe)
        If t_ref = 0 Then Exit Sub   ' falhou no MySQL -> não grava no Access com número errado

        ' [ALTERADO] 2) Grava no Access usando o MESMO Ref (agora o INSERT inclui "Ref")
        SQL = "INSERT INTO Fila (Ref, Descricao, Solicitante, Data_Solicitacao, Cod_Z, Aplicacao, Vagao, Lote, NumSfpCC, Historico, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St, Prio, Classe) VALUES (" & t_ref & ", '"
        SQL = SQL & desc & "', '"
        SQL = SQL & solic & "', '"
        SQL = SQL & data_solic & "', '"
        SQL = SQL & cod_z & "', '"
        SQL = SQL & aplic & "', '"
        SQL = SQL & vg & "', '"
        SQL = SQL & lote & "', '"
        SQL = SQL & nSFP & "', '"
        SQL = SQL & hist & "' , 'PENDENTE', 'PENDENTE', 'PENDENTE', 'PENDENTE', 'PARADO', 'PARADO', 'PENDENTE', 99, '" & classe & "');"

        upQuery (SQL)

        ' [REMOVIDO] SQL = "SELECT MAX(Ref) FROM Fila;" / arrRes = resQuery(SQL) / t_ref = arrRes(0,0)
        '            -> t_ref agora vem do MySQL (salvarNoMySQL)

        newFileName = "SL" & Format(t_ref, "0000") & ".pdf"
        'Debug.Print newFileName
        If lblFilePath.Caption <> "" Then                    ' [ALTERADO] caminho -> K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE
            Name "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & Right(frm_novo.lblFilePath.Caption, Len(frm_novo.lblFilePath.Caption) - InStrRev(frm_novo.lblFilePath.Caption, "\")) As _
            "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & newFileName
        End If


        MsgBox "Solicitação inserida Ref.: SL" & Format(t_ref, "0000")

        Unload Me

        filtro = Range("I3").Value
        If filtro = 1 Then filtro_01
        If filtro = 2 Then filtro_02
        If filtro = 3 Then filtro_03
        If filtro = 4 Then filtro_04
        If filtro = 5 Then filtro_05
        If filtro = 6 Then filtro_06
        If filtro = 7 Then lista_todos
        If filtro = 0 Then lista_pendentes
    Else
        frm_novo.lblMissing.ForeColor = &HC0&
        'frm_novo.lblMissing.Font.Bold = True
    End If

End Sub


Private Sub btnAnexar_Click()

Dim fso As Object
Dim oldFileName As String

FilePath = Application.GetOpenFilename("Pdf Files (*.pdf),*.pdf", Title:="Selecione um arquivo .pdf")
lblFilePath.Caption = FilePath
oldFileName = Right(FilePath, Len(FilePath) - InStrRev(FilePath, "\"))
'Debug.Print oldFileName
destinationPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & t_ref & Mid(FilePath, InStrRev(FilePath, "\") + 1)  ' [ALTERADO] caminho
'Debug.Print destinationPath
Set fso = CreateObject("Scripting.FileSystemObject")
fso.CopyFile FilePath, destinationPath

End Sub

Private Sub chk_dicaLocal_Click()

    If chk_dicaLocal.Value = True Then
        txt_dicaLocal.Enabled = True
        txt_dicaLocal.SpecialEffect = fmSpecialEffectFlat
        txt_dicaLocal.BorderStyle = fmBorderStyleSingle
        chk_dicaLocal.Caption = "Obs. Local*:"
    Else
        txt_dicaLocal.Enabled = False
        txt_dicaLocal.SpecialEffect = fmSpecialEffectSunken
        txt_dicaLocal.BorderStyle = fmBorderStyleNone
        txt_dicaLocal.Text = ""
        chk_dicaLocal.Caption = "Obs. Local:"
    End If
End Sub

Private Sub chk_partNumber_Click()

    If chk_partNumber.Value = True Then
        txt_partNumber.Enabled = True
        txt_partNumber.SpecialEffect = fmSpecialEffectFlat
        txt_partNumber.BorderStyle = fmBorderStyleSingle
        chk_partNumber.Caption = "Part Number*:"
    Else
        txt_partNumber.Enabled = False
        txt_partNumber.SpecialEffect = fmSpecialEffectSunken
        txt_partNumber.BorderStyle = fmBorderStyleNone
        txt_partNumber.Text = ""
        chk_partNumber.Caption = "Part Number:"
    End If

End Sub

Private Sub cmb_vg_Change()

Dim SQL As String
'Combo Lote

vg = frm_novo.cmb_vg.Text
sfp = frm_novo.cmbSFP.Value

SQL = "SELECT DISTINCT Lote FROM dmAccounts WHERE Vagao = '" & vg & "'AND boValidade = true ORDER BY Lote;"


    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

End Sub

Private Sub cmbSFP_Change()

Dim SQL As String
nSFP = Me.cmbSFP.Text


'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true AND numSfpCC = '" & nSFP & "';"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a
    If cmb_vg.ListCount = 1 Then cmb_vg.ListIndex = 0 Else cmb_vg.ListIndex = -1
        End If


'Combo Lote

    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true AND numSfpCC = '" & nSFP & "';"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    If cmb_lote.ListCount = 1 Then cmb_lote.ListIndex = 0 Else cmb_lote.ListIndex = -1
    End If


Dim SQLSfp As String

    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    cmb_vg.Enabled = True
    cmb_lote.Enabled = True
End Sub



Private Sub lblMissing_Click()

End Sub

Private Sub opt_1_Click()   'notificação de segurança
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True

    Dim SQLSfp As String
    Dim SQL As String

    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True



End Sub

Private Sub opt_2_Click() 'SW
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True
End Sub

Private Sub opt_3_Click()   'CIPA
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True

    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True
End Sub

Private Sub opt_4_Click()
    cmbSFP.Visible = True
    lblSFP.Caption = ""
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    cmbSFP.Value = ""
    cmb_vg.Value = ""
    cmb_lote.Value = ""
    cmbSFP.Enabled = True
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_5_Click()

    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True

    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_6_Click()
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True

    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text

    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If

    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a

        End If


    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a

    End If

    cmbSFP.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False
End Sub

Private Sub opt_7_Click()

    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_8_Click()

    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_9_Click()
    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False
End Sub


Private Sub txt_escopo_Change()
    frm_novo.cont.Caption = Format(Len(frm_novo.txt_escopo.Text), "000")

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        frm_novo.lblMissing.ForeColor = &H80000012
    End If

End Sub


Private Sub txt_qtd_Change()

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        frm_novo.lblMissing.ForeColor = &H80000012
    End If

End Sub

Private Sub txt_solicitacao_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    desc = frm_novo.txt_solicitacao.Text
    If desc <> "" Then frm_novo.txt_solicitacao.Text = UCase(frm_novo.txt_solicitacao.Text)
End Sub

Private Sub UserForm_Click()

End Sub
```

---

## 5. VBA — macro de migração `MigrarFilaParaMySQL` (completa)

Gera `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\migracao.sql` (UTF-8 **sem BOM**) com `solicitacoes` + `fila` + `historico`.

```vba
Sub MigrarFilaParaMySQL()
    Dim cnn As Object, rst As Object, st As Object
    Dim etapa As String
    On Error GoTo ERRO

    etapa = "1) Conectar no Access"
    Set cnn = CreateObject("ADODB.Connection")
    cnn.Mode = 1   ' adModeRead = somente leitura (não cria .laccdb)
    cnn.Open "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb;"

    etapa = "2) Abrir Stream"
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open

    st.WriteText "USE bd_device_request;" & vbCrLf
    st.WriteText "SET FOREIGN_KEY_CHECKS=0;" & vbCrLf

    etapa = "3) Ler solicitacoes"
    Set rst = cnn.Execute("SELECT * FROM Fila ORDER BY Ref")
    Do While Not rst.EOF
        st.WriteText "INSERT INTO solicitacoes (id, ref, cod_z, descricao, solicitante, data_solicitacao, aplicacao, vagao, lote, conta, classe, escopo, created_at) VALUES (" & _
            "'" & NovoGUID() & "'," & sqlNum(rst("Ref")) & "," & sqlStr(rst("Cod_Z")) & "," & _
            sqlStr(rst("Descricao")) & "," & sqlStr(rst("Solicitante")) & "," & sqlDate(rst("Data_Solicitacao")) & "," & _
            sqlStr(rst("Aplicacao")) & "," & sqlStr(rst("Vagao")) & "," & sqlStr(rst("Lote")) & "," & _
            sqlStr(rst("NumSfpCC")) & "," & sqlStr(rst("Classe")) & "," & sqlStr(rst("Historico")) & "," & cAtDe(rst("Data_Solicitacao")) & ");" & vbCrLf
        rst.MoveNext
    Loop
    rst.Close

    etapa = "4) Ler fila"
    Set rst = cnn.Execute("SELECT * FROM Fila ORDER BY Ref")
    Do While Not rst.EOF
        st.WriteText "INSERT INTO fila (id, ref, cod_z, descricao, aquisicao_status, aquisicao_data, solicitante, data_solicitacao, aplicacao, vagao, lote, conta, historico, classe, conceito_proj, conceito_status, conceito_inicio, conceito_fim, detalhamento_proj, detalhamento_status, detalhamento_inicio, detalhamento_fim, liberacao_status, liberacao_data, corte_status, corte_data, exec_status, exec_data, tryout_status, tryout_data, prio, created_at) VALUES (" & _
            "'" & NovoGUID() & "'," & sqlNum(rst("Ref")) & "," & sqlStr(rst("Cod_Z")) & "," & sqlStr(rst("Descricao")) & "," & _
            sqlStr(rst("Aq_St")) & "," & sqlDate(rst("Aq_Data")) & "," & sqlStr(rst("Solicitante")) & "," & sqlDate(rst("Data_Solicitacao")) & "," & _
            sqlStr(rst("Aplicacao")) & "," & sqlStr(rst("Vagao")) & "," & sqlStr(rst("Lote")) & "," & sqlStr(rst("NumSfpCC")) & "," & _
            sqlStr(rst("Historico")) & "," & sqlStr(rst("Classe")) & "," & sqlStr(rst("Conceito_P")) & "," & sqlStr(rst("Conceito_St")) & "," & _
            sqlDate(rst("Conceito_Ini")) & "," & sqlDate(rst("Conceito_Fim")) & "," & sqlStr(rst("Det_P")) & "," & sqlStr(rst("Det_St")) & "," & _
            sqlDate(rst("Det_Ini")) & "," & sqlDate(rst("Det_Fim")) & "," & sqlStr(rst("Liberacao_St")) & "," & sqlDate(rst("Liberacao_Data")) & "," & _
            sqlStr(rst("Corte_St")) & "," & sqlDate(rst("Corte_Data")) & "," & sqlStr(rst("Exec_St")) & "," & sqlDate(rst("Exec_Data")) & "," & _
            sqlStr(rst("Tryout_St")) & "," & sqlDate(rst("Tryout_Data")) & "," & sqlNum(rst("Prio")) & "," & cAtDe(rst("Data_Solicitacao")) & ");" & vbCrLf
        rst.MoveNext
    Loop
    rst.Close

    etapa = "5) Ler historico"
    Set rst = cnn.Execute("SELECT Ref, Historico, Solicitante, Data_Solicitacao FROM Fila ORDER BY Ref")
    Do While Not rst.EOF
        st.WriteText histToSql(CLng(rst("Ref")), rst("Historico") & "", rst("Solicitante") & "", rst("Data_Solicitacao"))
        rst.MoveNext
    Loop
    rst.Close

    st.WriteText "SET FOREIGN_KEY_CHECKS=1;" & vbCrLf

    etapa = "6) Salvar arquivo .sql (sem BOM)"
    Dim bin As Object, conteudo
    st.Position = 0
    st.Type = 1            ' adTypeBinary
    st.Position = 3        ' pula o BOM (3 bytes: EF BB BF)
    conteudo = st.Read
    Set bin = CreateObject("ADODB.Stream")
    bin.Type = 1: bin.Open
    bin.Write conteudo
    bin.SaveToFile "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\migracao.sql", 2
    bin.Close

    st.Close
    cnn.Close
    MsgBox "OK! Gerado (sem BOM): K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\migracao.sql"
    Exit Sub

ERRO:
    On Error Resume Next
    If Not rst Is Nothing Then rst.Close
    If Not cnn Is Nothing Then cnn.Close
    If Not st Is Nothing Then st.Close
    MsgBox "Falhou na etapa [" & etapa & "]" & vbCrLf & _
           "Erro " & Err.Number & ": " & Err.Description, vbCritical
End Sub


' ===== Helpers da migração =====

' created_at a partir de uma data; se vazia, usa NOW()
Function cAtDe(v) As String
    If IsDate(v) Then cAtDe = "'" & Format(v, "yyyy-mm-dd hh:nn:ss") & "'" Else cAtDe = "NOW()"
End Function

' Quebra o texto do Historico em entradas "-- nome (DD.MM.YYYY - HH:MM): msg"
' e gera 1 INSERT por entrada. Se não reconhecer, grava o texto inteiro como 1 entrada.
Function histToSql(ref As Long, blob As String, solicitante As String, dataSolic As Variant) As String
    Dim re As Object, mm As Object, mt As Object
    Dim out As String, nome As String, dt As String, hr As String, msg As String, dataSql As String

    If Trim(blob) = "" Then
        histToSql = ""
        Exit Function
    End If

    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "--\s+([^()]+?)\s+\((\d{2}\.\d{2}\.\d{4})\s*-\s*(\d{2}:\d{2})\s*\):\s*([\s\S]*?)(?=--\s+[^()]+?\s+\(\d{2}\.\d{2}\.\d{4}|$)"

    Set mm = re.Execute(blob)

    If mm.Count = 0 Then
        out = "INSERT INTO historico (id, ref, usuario, mensagem, created_at) VALUES ('" & _
              NovoGUID() & "'," & ref & "," & sqlStr(solicitante) & "," & sqlStr(blob) & "," & cAtDe(dataSolic) & ");" & vbCrLf
        histToSql = out
        Exit Function
    End If

    out = ""
    For Each mt In mm
        nome = Trim(mt.SubMatches(0))
        dt = mt.SubMatches(1)                 ' DD.MM.YYYY
        hr = mt.SubMatches(2)                 ' HH:MM
        msg = Trim(mt.SubMatches(3))
        dataSql = Mid(dt, 7, 4) & "-" & Mid(dt, 4, 2) & "-" & Mid(dt, 1, 2) & " " & hr & ":00"
        out = out & "INSERT INTO historico (id, ref, usuario, mensagem, created_at) VALUES ('" & _
              NovoGUID() & "'," & ref & "," & sqlStr(nome) & "," & sqlStr(msg) & ",'" & dataSql & "');" & vbCrLf
    Next mt

    histToSql = out
End Function

' ===== Helpers genéricos =====

Function NovoGUID() As String
    Static seeded As Boolean
    Dim b(0 To 15) As Byte, i As Long, s As String
    If Not seeded Then Randomize: seeded = True
    For i = 0 To 15
        b(i) = Int(Rnd * 256)
    Next i
    s = ""
    For i = 0 To 15
        s = s & Right("0" & Hex(b(i)), 2)
        If i = 3 Or i = 5 Or i = 7 Or i = 9 Then s = s & "-"
    Next i
    NovoGUID = LCase(s)
End Function

Function sqlStr(v) As String
    Dim s As String
    If IsNull(v) Then sqlStr = "NULL": Exit Function
    s = CStr(v)
    If Trim(s) = "" Then sqlStr = "NULL": Exit Function
    s = Replace(s, "\", "\\")
    s = Replace(s, "'", "''")
    sqlStr = "'" & s & "'"
End Function

Function sqlDate(v) As String
    If IsNull(v) Then sqlDate = "NULL": Exit Function
    If CStr(v) = "" Then sqlDate = "NULL": Exit Function
    If IsDate(v) Then sqlDate = "'" & Format(v, "yyyy-mm-dd hh:nn:ss") & "'" Else sqlDate = "NULL"
End Function

Function sqlNum(v) As String
    If IsNull(v) Then sqlNum = "NULL": Exit Function
    If CStr(v) = "" Then sqlNum = "NULL": Exit Function
    sqlNum = CStr(CLng(v))
End Function
```
