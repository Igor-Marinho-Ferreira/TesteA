# 📒 Doc Master — Solicitação (sincronização Access ↔ MySQL)

Índice mestre da documentação do fluxo de **Solicitação** entre o sistema antigo (Excel/VBA + Access)
e o novo (PHP + MySQL). **Leia nesta ordem** — cada etapa assume a anterior.

> **Padrão da documentação:** todo doc de código (`*-codigo.md`) traz o código **100% completo**,
> com **ANTES** e **DEPOIS** dos módulos alterados (não só o trecho).

- **Servidor:** Debian `172.29.5.2` (MariaDB), base `bd_device_request`.
- **URL base:** `http://172.29.5.2/greenbrier/v2/solic_dispositivos`
- **Ambiente de teste:** `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` (Access + pastas de arquivo).

---

## Ordem de leitura

| # | Tema | Visão geral | Código (antes/depois) |
|---|------|-------------|------------------------|
| 1 | **Dados Access → MySQL** + migração inicial (criar SL, cartório do Ref, GET_LOCK) | [migracao-access-mysql.md](migracao-access-mysql.md) | [migracao-access-mysql-codigo.md](migracao-access-mysql-codigo.md) |
| 2 | **Dados MySQL → Access** (CSV → Access, insert + upsert) | [sincronizacao-mysql-access.md](sincronizacao-mysql-access.md) | [sincronizacao-mysql-access-codigo.md](sincronizacao-mysql-access-codigo.md) |
| 3 | **Anexo PDF Access → MySQL** (upload do PDF da criação) | [anexos-access-mysql.md](anexos-access-mysql.md) | [anexos-access-mysql-codigo.md](anexos-access-mysql-codigo.md) |
| 4 | **Anexos MySQL → Access** (web copia pra pasta + caminhos do frmsol) | [anexos-mysql-access.md](anexos-mysql-access.md) | [anexos-mysql-access-codigo.md](anexos-mysql-access-codigo.md) |
| 5 | **Histórico bidirecional** (comentários acumulam) | [historico-bidirecional.md](historico-bidirecional.md) | [historico-bidirecional-codigo.md](historico-bidirecional-codigo.md) |
| 6 | **Status bidirecional** (cancelar / tryout / validar / rejeitar) | [status-bidirecional.md](status-bidirecional.md) | [status-bidirecional-codigo.md](status-bidirecional-codigo.md) |

### Extras / ambiente
- [desativar-login.md](desativar-login.md) — passo a passo de como **desativamos o login** do Excel/VBA no ambiente de teste.

### Continuação
- **Parte 2 — Desenvolvimento (DXF e afins):** [../doc-desenvolvimento/00-doc-master.md](../doc-desenvolvimento/00-doc-master.md)

---

## Conceito que amarra tudo

**O MySQL é a fonte da verdade ("cartório").** Toda mudança (web ou Access) vai pro MySQL na hora;
o `sincronizarDoMySQL` reflete de volta pro Access. Isso dispensa comparar timestamps/fuso.

```
Access  →  (HTTP, tempo real)  →  MySQL  ←  (direto)  ←  Web
   ▲                                │
   └──── sincronizarDoMySQL (pull) ─┘
```

| Direção | Como |
|---------|------|
| Access → MySQL | rotas `salvarVba`, `uploadAnexoVba`, `comentarVba`, `atualizarStatusVba` (VBA faz POST) |
| MySQL → Access | `trataCsv` (CSV) + VBA `sincronizarDoMySQL` (DAO: insere novos, atualiza histórico+status dos existentes) |

---

## Estado atual (criação/solicitação)

✅ Criar SL · ✅ Migração inicial · ✅ Dados nos 2 sentidos · ✅ Anexo PDF nos 2 sentidos ·
✅ Histórico bidirecional · ✅ Status bidirecional (cancelar/tryout/validar/rejeitar)

**Confirmado:** não existe edição livre dos campos da SL — só workflow (criar, cancelar, status, comentar).

### Falta (fora do escopo "criação")
- Anexos da **fase de desenvolvimento** (DXF, desenhos, cortes, BOM).
- Sincronizar o `CKReq` (requisitos validados) — hoje fica só no Access.
- **Automatizar o disparo** das sincronizações (cron no Debian + Agendador no Windows).

---

## Rotas PHP criadas (resumo)

| Rota | Método | O que faz |
|------|--------|-----------|
| `/dispositivos/solicitacao/salvarVba` | POST | cria SL no MySQL (GET_LOCK) e devolve o Ref |
| `/dispositivos/solicitacao/uploadAnexoVba` | POST | recebe o PDF (binário) → storage + tabela anexos |
| `/dispositivos/solicitacao/comentarVba` | POST | insere 1 linha em `historico` |
| `/dispositivos/solicitacao/atualizarStatusVba` | POST | atualiza status da `fila` (whitelist) |
| `/dispositivos/csvAtualizado/fila` | GET | gera o CSV do `fila` (consumido pelo VBA) |
