# 📒 Doc Master — Desenvolvimento (Parte 2) · arquivos DXF e afins

Segunda parte da sincronização Access ↔ MySQL. Enquanto a **Parte 1**
([doc-solicitacao](../doc-solicitacao/00-doc-master.md)) cobre o ciclo da
*Solicitação* (criar, status, histórico, anexo da criação), esta **Parte 2**
cobre os **arquivos da fase de desenvolvimento** do workbook
**`Lista de Solicitações de Projeto_RevE.xlsm`**:

- 🖼️ **Imagem do projeto**
- 📐 **Pacote DXF** (cortes)
- 📄 **Desenhos PDF**
- 🧾 **BOM / itens comprados**

> **Padrão da documentação:** todo doc de código (`*-codigo.md`) traz o código
> com **ANTES** e **DEPOIS** completos. Os módulos VBA inteiros (já atualizados)
> ficam em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\*.txt`.

- **Servidor:** Debian `172.29.5.2` (MariaDB), base `bd_device_request`.
- **URL base:** `http://172.29.5.2/greenbrier/v2/solic_dispositivos`
- **Ambiente de teste:** `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` (Access + pastas de arquivo).
- **Controller web:** `DesenvolvimentoController.php` (espelha 1:1 os 4 tipos).

---

## Ordem de leitura

| # | Tema | Visão geral | Código (antes/depois) | Status |
|---|------|-------------|------------------------|--------|
| 1 | **Imagem do projeto** (Access ↔ Web) | [imagem-projeto.md](imagem-projeto.md) | [imagem-projeto-codigo.md](imagem-projeto-codigo.md) | ✅ feito |
| 2 | **Desenhos PDF** (vários por SL) | [desenhos-pdf.md](desenhos-pdf.md) | [desenhos-pdf-codigo.md](desenhos-pdf-codigo.md) | ✅ feito |
| 3 | **Pacote DXF** (cortes, numeração cartório) | [pacote-dxf.md](pacote-dxf.md) | [pacote-dxf-codigo.md](pacote-dxf-codigo.md) | ✅ feito |
| 4 | **BOM / itens comprados** | [bom-itens-comprados.md](bom-itens-comprados.md) | [bom-itens-comprados-codigo.md](bom-itens-comprados-codigo.md) | ✅ feito |

---

## Conceito que amarra tudo (igual à Parte 1)

**O MySQL é a fonte da verdade ("cartório").** Toda alteração (web ou Access)
vai pro MySQL na hora; o pull reflete de volta pro Access.

```
Access  →  (HTTP, tempo real)  →  MySQL  ←  (direto)  ←  Web
   ▲                                │
   └────────── pasta mapeada  ──────┘   (web copia o arquivo p/ o Access enxergar)
```

### Tabelas/pastas dos dois lados

| Tipo | Access (tabela / arquivo) | Web (tabela / storage) |
|------|---------------------------|------------------------|
| Imagem | arquivo `.img_sl\SL{ref}.jpg` (sem registro) | `solicitacao_anexo_arquivos` tipo `IMAGEM_PROJETO` + `.../{ref}/imagem/` |
| DXF | `DXF_Control` + arquivos | tipo `PACOTE_DXF` |
| Desenho | `PDF_Control` + PDFs | tipo `DESENHOS_PDF` |
| BOM | `BOM_Control` (+`OC_Control`) via TXT | tipo `ITENS_COMPRADOS_TXT` + `solicitacao_itens_comprados` |

---

## Rotas PHP criadas nesta parte

| Rota | Método | O que faz |
|------|--------|-----------|
| `/dispositivos/desenvolvimento/uploadImagemVba` | POST | recebe a imagem (binário) do Access → carga + arquivo + histórico |
| `/dispositivos/desenvolvimento/uploadDesenhoPdfVba` | POST | recebe 1 desenho PDF (binário) do Access → carga + arquivo `DESENHO_PDF` (codigo) + histórico |
| `/dispositivos/csvAtualizado/desenhosPdf` | GET | CSV dos desenhos PDF p/ o VBA upsertar em `PDF_Control` (pull) |
| `/dispositivos/desenvolvimento/nextDxf` | GET | cartório do número de DXF (GET_LOCK) — devolve `{controle, codigo}` |
| `/dispositivos/desenvolvimento/uploadDxfVba` | POST | recebe 1 pacote DXF (zip) do Access → carga + `PACOTE_DXF` (codigo) + histórico |
| `/dispositivos/csvAtualizado/dxf` | GET | CSV dos pacotes DXF p/ o VBA upsertar em `DXF_Control` (pull) |
| `/dispositivos/desenvolvimento/uploadBomVba` | POST | recebe o lote de itens de BOM do Access → `solicitacao_itens_comprados` (dedup) |
| `/dispositivos/csvAtualizado/bom` | GET | CSV dos itens de BOM p/ o VBA upsertar em `BOM_Control` (pull) |

| `/dispositivos/desenvolvimento/garantirStorageMapeado` | GET | cria as subpastas do VBA no storage-mapped (rode 1×) |

**Parte 2 (desenvolvimento) — todas as 4 fatias concluídas.** ✅ Imagem · ✅ Desenhos PDF · ✅ Pacote DXF · ✅ BOM/itens comprados

> 🗂️ **Arquitetura de arquivos (transversal):** [storage-mapped.md](storage-mapped.md) — o storage do web
> usa as pastas/nomes do Access e espelha tudo no `APP_STORAGE_MAPPED` (que você mapeia no Windows).

> 📦 **Bundle de código:** [ARQUIVOS-ALTERADOS.md](ARQUIVOS-ALTERADOS.md) — **todos** os arquivos alterados
> (PHP + VBA dos 2 workbooks), **100% completos**, num arquivo só. VBA pronto também em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\*.txt`.
