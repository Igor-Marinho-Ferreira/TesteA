# BOM / Itens comprados — Código 100% (ANTES / DEPOIS completos)

Fatia 4 (última) da Parte 2. Sincroniza as **linhas de BOM** (`BOM_Control` ↔
`solicitacao_itens_comprados`). Visão geral em [bom-itens-comprados.md](bom-itens-comprados.md).

> **Sem cartório / sem mudança de schema:** o `Controle` do `BOM_Control` é só PK
> interna (AutoNumber). A chave compartilhada é **Solicitacao + Codigo + Revisao**.
> Push em **lote** (form-urlencoded, dedup); pull via CSV + upsert.

| Artefato | Mudou |
|---|---|
| `routes.php` | +2 rotas (`uploadBomVba`, `csvAtualizado/bom`) |
| `DesenvolvimentoController` (novos) | `uploadBomVba`, `csvBom` |
| VBA `Funcoes` | +`enviarBomParaMySQL`, +`sincronizarBomDoMySQL` |
| VBA `frm_bom` | `btnInserir_Click` (acumula lote + push) |
| VBA `frmaut`/`frmsol` | `btn_bom_novo_Click` (caminho `.bom` `F:`→`D:`) |

---

## 1. PHP — `src/routes/routes.php` (bloco do BOM)

### ANTES
```php
Route::post('/dispositivos/desenvolvimento/itens-comprados-txt/{ref}/store', DesenvolvimentoController::class, 'storeItensCompradosTxt')
    ->name('dispositivos.desenvolvimento.itensCompradosTxt.store')
    ->whereint(['ref']);
```

### DEPOIS
```php
Route::post('/dispositivos/desenvolvimento/itens-comprados-txt/{ref}/store', DesenvolvimentoController::class, 'storeItensCompradosTxt')
    ->name('dispositivos.desenvolvimento.itensCompradosTxt.store')
    ->whereint(['ref']);

// Access -> Web: recebe os itens de BOM (frm_bom.btnInserir) em lote (form-urlencoded).
Route::post('/dispositivos/desenvolvimento/uploadBomVba', DesenvolvimentoController::class, 'uploadBomVba')
    ->name('dispositivos.desenvolvimento.uploadBomVba');

// Web -> Access (pull): CSV dos itens de BOM p/ o VBA upsertar em BOM_Control.
Route::get('/dispositivos/csvAtualizado/bom', DesenvolvimentoController::class, 'csvBom')
    ->name('dispositivos.atualizaCSV.bom');
```

---

## 2. PHP — métodos NOVOS (`uploadBomVba` + `csvBom`)

**ANTES: não existiam.**

### DEPOIS (100%)
```php
    /**
     * Access -> Web: recebe os itens de BOM (frm_bom.btnInserir) como UM lote.
     * POST form-urlencoded: ref + dados (linhas "codigo\trev\tdescricao\tqtde\ttipo"
     * separadas por \n). Insere em solicitacao_itens_comprados os que ainda não
     * existem (dedup por ref+codigo+rev). Sem trava de status — espelha o Access.
     */
    public function uploadBomVba()
    {
        $ref   = (int) (Request::input('ref') ?? 0);
        $dados = (string) (Request::input('dados') ?? '');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        // Parseia as linhas do lote (campos separados por TAB)
        $itens = [];
        foreach (preg_split('/\r\n|\r|\n/', $dados) as $linha) {
            if (trim($linha) === '') {
                continue;
            }
            $c = explode("\t", $linha);
            $codigo = trim($c[0] ?? '');
            if ($codigo === '') {
                continue;
            }
            $itens[] = [
                'codigo'     => $codigo,
                'rev'        => trim($c[1] ?? ''),
                'descricao'  => trim($c[2] ?? ''),
                'quantidade' => trim($c[3] ?? ''),
                'tipo'       => trim($c[4] ?? ''),
                'linha'      => $linha,
            ];
        }
        if (empty($itens)) {
            return Json::return(['ok' => true, 'inseridos' => 0], 200);
        }

        $usuarioLogado = 'ACCESS';
        $pdo = SolicitacaoItemComprado::getPDO();

        // Chaves já existentes (codigo|rev) desta SL, para dedup
        $stmt = $pdo->prepare("
            SELECT codigo, rev
            FROM bd_device_request.solicitacao_itens_comprados
            WHERE ref = :ref
        ");
        $stmt->execute([':ref' => $ref]);
        $existentes = [];
        foreach ($stmt->fetchAll(\PDO::FETCH_OBJ) as $r) {
            $existentes[strtoupper(trim((string) $r->codigo)) . '|' . strtoupper(trim((string) $r->rev))] = true;
        }

        $novos = [];
        foreach ($itens as $it) {
            $chave = strtoupper($it['codigo']) . '|' . strtoupper($it['rev']);
            if (!isset($existentes[$chave])) {
                $novos[] = $it;
                $existentes[$chave] = true; // evita duplicar dentro do próprio lote
            }
        }
        if (empty($novos)) {
            return Json::return(['ok' => true, 'inseridos' => 0], 200);
        }

        try {
            if (!$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);
            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da BOM.");
            }

            // Arquivo "marcador": a BOM veio do Access, não de um TXT físico
            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'ITENS_COMPRADOS_TXT',
                'codigo'        => null,
                'nome_original' => 'BOM (Access)',
                'nome_arquivo'  => '',
                'caminho'       => '',
                'mime_type'     => 'text/plain',
                'tamanho_bytes' => strlen($dados),
                'created_by'    => $usuarioLogado
            ]);
            $arquivoId = $saveArquivo['id'] ?? null;

            $inseridos = 0;
            foreach ($novos as $it) {
                SolicitacaoItemComprado::create([
                    'carga_id'       => $saveCarga['id'],
                    'arquivo_id'     => $arquivoId,
                    'ref'            => $ref,
                    'codigo'         => $it['codigo'],
                    'rev'            => $it['rev'],
                    'descricao'      => $it['descricao'],
                    'quantidade'     => $it['quantidade'],
                    'tipo'           => $it['tipo'],
                    'linha_original' => $it['linha'],
                    'created_by'     => $usuarioLogado
                ]);
                $inseridos++;
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$inseridos} item(ns) de BOM adicionado(s) (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo->inTransaction()) {
                $pdo->commit();
            }

            return Json::return(['ok' => true, 'inseridos' => $inseridos], 200);

        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Erro no uploadBomVba {$ref}: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar BOM'], 500);
        }
    }

    /**
     * Web -> Access (pull): CSV dos itens de BOM (solicitacao_itens_comprados) p/ o
     * VBA upsertar em BOM_Control.
     * Colunas: Solicitacao;Projeto;Codigo;Revisao;Descricao;Qtde;Tipo.
     */
    public function csvBom()
    {
        if (ob_get_level()) ob_end_clean();

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=Bom.csv');

        // Tira ';' e quebras dos campos livres (o VBA faz Split simples por ';')
        $limpar = function ($v) {
            return str_replace([';', "\r", "\n"], [',', ' ', ' '], (string) $v);
        };

        $pdo = SolicitacaoItemComprado::getPDO();
        $rows = $pdo->query("
            SELECT i.ref AS ref, i.codigo AS codigo, i.rev AS rev, i.descricao AS descricao,
                   i.quantidade AS qtde, i.tipo AS tipo, s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_itens_comprados i
            LEFT JOIN bd_device_request.solicitacoes s ON s.ref = i.ref
            ORDER BY i.ref, i.codigo
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');
        fputs($file, "\xEF\xBB\xBF");
        fputcsv($file, ['Solicitacao', 'Projeto', 'Codigo', 'Revisao', 'Descricao', 'Qtde', 'Tipo'], ';');

        foreach ($rows as $r) {
            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);
            fputcsv($file, [
                $sl,
                $limpar($r->cod_z),
                $limpar($r->codigo),
                $limpar($r->rev),
                $limpar($r->descricao),
                $limpar($r->qtde),
                $limpar($r->tipo),
            ], ';');
        }
        fclose($file);
        exit;
    }
```

---

## 3. VBA — módulo `Funcoes` (inteiro)

ANTES = pós-DXF; DEPOIS = +`enviarBomParaMySQL`, +`sincronizarBomDoMySQL`.

### ANTES (100%)
```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("D")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ChDir ("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
'==================== INTEGRACAO COM A WEB (MySQL) ====================
' Base da aplicacao web (mesma do workbook de Solicitacao)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Codifica um valor para querystring (UTF-8)
Public Function enc(ByVal v As Variant) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Access -> Web: envia a imagem do projeto (bytes) para a rota uploadImagemVba.
' ref = numero da SL (so o numero, sem "SL"); caminhoArquivo = .jpg local.
Public Function enviarImagemParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarImagemParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "Imagem nao encontrada para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadImagemVba?ref=" & ref & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarImagemParaMySQL = True
    Else
        MsgBox "Falha ao enviar imagem (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar imagem para a web:" & vbCrLf & Err.Description, vbCritical
End Function
' Access -> Web: envia UM desenho PDF (bytes) para a rota uploadDesenhoPdfVba.
' ref = numero da SL; codigo = nome do arquivo sem extensao; caminho = .pdf local.
Public Function enviarPdfDesenhoParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarPdfDesenhoParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "PDF nao encontrado para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDesenhoPdfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarPdfDesenhoParaMySQL = True
    Else
        MsgBox "Falha ao enviar PDF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar PDF para a web:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de desenhos PDF e faz upsert em PDF_Control.
' Os arquivos ja sao copiados pela web para .desenhos\ ; aqui so garantimos a
' linha em PDF_Control para o desenho aparecer na pdf_lst.
Public Sub sincronizarPdfsDoMySQL()
    Dim http        As Object
    Dim txt         As String
    Dim linhas()    As String
    Dim campos()    As String
    Dim i           As Long
    Dim sol         As String, proj As String, cod As String, rev As String
    Dim SQL         As String
    Dim ArrChk      As Variant
    Dim inseridos   As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/desenhosPdf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de PDFs (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM

    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                sol = Trim(campos(0))
                proj = Trim(campos(1))
                cod = Trim(campos(2))
                rev = Trim(campos(3))

                SQL = "SELECT Codigo FROM PDF_Control WHERE Codigo = '" & Replace(cod, "'", "''") & _
                      "' AND Solicitacao = '" & Replace(sol, "'", "''") & "';"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ('" & _
                          Replace(proj, "'", "''") & "','" & Replace(sol, "'", "''") & "','" & _
                          Replace(cod, "'", "''") & "','" & Replace(rev, "'", "''") & "');"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de PDFs concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar PDFs:" & vbCrLf & Err.Description, vbCritical
End Sub
' Cartorio do numero de DXF: pede o proximo Controle a web (GET_LOCK no servidor).
' floor = MAX(Controle) atual do Access (para o contador nao reiniciar/colidir).
Public Function pedirProximoDxf(ByVal floor As Long) As Long
    Dim http As Object
    Dim txt As String
    Dim p As Long
    Dim s As String
    Dim ch As String

    pedirProximoDxf = 0
    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/desenvolvimento/nextDxf?floor=" & floor, False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao pedir numero DXF (HTTP " & http.Status & ")", vbExclamation
        Exit Function
    End If

    ' Extrai o numero apos "controle": do JSON {"controle":N,"codigo":"DX000N"}
    txt = http.responseText
    p = InStr(txt, """controle""")
    If p = 0 Then Exit Function
    p = InStr(p, txt, ":") + 1
    s = ""
    Do While p <= Len(txt)
        ch = Mid(txt, p, 1)
        If ch >= "0" And ch <= "9" Then
            s = s & ch
        ElseIf s <> "" Then
            Exit Do
        End If
        p = p + 1
    Loop
    If s <> "" Then pedirProximoDxf = CLng(s)
    Exit Function
erro:
    MsgBox "Erro ao pedir numero DXF:" & vbCrLf & Err.Description, vbCritical
End Function

' Access -> Web: envia UM pacote DXF (zip) para a rota uploadDxfVba.
Public Function enviarDxfParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http As Object
    Dim stream As Object
    Dim dados() As Byte
    Dim url As String
    Dim nomeArq As String

    enviarDxfParaMySQL = False
    If Dir(caminhoArquivo) = "" Then
        MsgBox "Pacote DXF nao encontrado:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDxfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarDxfParaMySQL = True
    Else
        MsgBox "Falha ao enviar DXF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar DXF:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de DXF e faz upsert em DXF_Control (insere os que faltam).
' O Controle vem do MySQL (cartorio), por isso pode ser inserido explicito.
Public Sub sincronizarDxfsDoMySQL()
    Dim http As Object
    Dim txt As String
    Dim linhas() As String
    Dim campos() As String
    Dim i As Long
    Dim ctrl As String, sol As String, proj As String, desc As String
    Dim SQL As String
    Dim ArrChk As Variant
    Dim inseridos As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/dxf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de DXF (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM
    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                ctrl = Trim(campos(0))
                sol = Trim(campos(1))
                proj = Trim(campos(2))
                desc = Trim(campos(3))

                SQL = "SELECT Controle FROM DXF_Control WHERE Controle = " & Val(ctrl) & ";"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO DXF_Control (Controle, Solicitacao, Cod_Proj, Descricao, IMG, DXF) VALUES (" & _
                          Val(ctrl) & ",'" & Replace(sol, "'", "''") & "','" & Replace(proj, "'", "''") & "','" & _
                          Replace(desc, "'", "''") & "', TRUE, TRUE);"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de DXF concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar DXF:" & vbCrLf & Err.Description, vbCritical
End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("D")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ChDir ("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
'==================== INTEGRACAO COM A WEB (MySQL) ====================
' Base da aplicacao web (mesma do workbook de Solicitacao)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Codifica um valor para querystring (UTF-8)
Public Function enc(ByVal v As Variant) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Access -> Web: envia a imagem do projeto (bytes) para a rota uploadImagemVba.
' ref = numero da SL (so o numero, sem "SL"); caminhoArquivo = .jpg local.
Public Function enviarImagemParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarImagemParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "Imagem nao encontrada para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadImagemVba?ref=" & ref & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarImagemParaMySQL = True
    Else
        MsgBox "Falha ao enviar imagem (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar imagem para a web:" & vbCrLf & Err.Description, vbCritical
End Function
' Access -> Web: envia UM desenho PDF (bytes) para a rota uploadDesenhoPdfVba.
' ref = numero da SL; codigo = nome do arquivo sem extensao; caminho = .pdf local.
Public Function enviarPdfDesenhoParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarPdfDesenhoParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "PDF nao encontrado para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDesenhoPdfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarPdfDesenhoParaMySQL = True
    Else
        MsgBox "Falha ao enviar PDF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar PDF para a web:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de desenhos PDF e faz upsert em PDF_Control.
' Os arquivos ja sao copiados pela web para .desenhos\ ; aqui so garantimos a
' linha em PDF_Control para o desenho aparecer na pdf_lst.
Public Sub sincronizarPdfsDoMySQL()
    Dim http        As Object
    Dim txt         As String
    Dim linhas()    As String
    Dim campos()    As String
    Dim i           As Long
    Dim sol         As String, proj As String, cod As String, rev As String
    Dim SQL         As String
    Dim ArrChk      As Variant
    Dim inseridos   As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/desenhosPdf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de PDFs (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM

    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                sol = Trim(campos(0))
                proj = Trim(campos(1))
                cod = Trim(campos(2))
                rev = Trim(campos(3))

                SQL = "SELECT Codigo FROM PDF_Control WHERE Codigo = '" & Replace(cod, "'", "''") & _
                      "' AND Solicitacao = '" & Replace(sol, "'", "''") & "';"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ('" & _
                          Replace(proj, "'", "''") & "','" & Replace(sol, "'", "''") & "','" & _
                          Replace(cod, "'", "''") & "','" & Replace(rev, "'", "''") & "');"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de PDFs concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar PDFs:" & vbCrLf & Err.Description, vbCritical
End Sub
' Cartorio do numero de DXF: pede o proximo Controle a web (GET_LOCK no servidor).
' floor = MAX(Controle) atual do Access (para o contador nao reiniciar/colidir).
Public Function pedirProximoDxf(ByVal floor As Long) As Long
    Dim http As Object
    Dim txt As String
    Dim p As Long
    Dim s As String
    Dim ch As String

    pedirProximoDxf = 0
    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/desenvolvimento/nextDxf?floor=" & floor, False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao pedir numero DXF (HTTP " & http.Status & ")", vbExclamation
        Exit Function
    End If

    ' Extrai o numero apos "controle": do JSON {"controle":N,"codigo":"DX000N"}
    txt = http.responseText
    p = InStr(txt, """controle""")
    If p = 0 Then Exit Function
    p = InStr(p, txt, ":") + 1
    s = ""
    Do While p <= Len(txt)
        ch = Mid(txt, p, 1)
        If ch >= "0" And ch <= "9" Then
            s = s & ch
        ElseIf s <> "" Then
            Exit Do
        End If
        p = p + 1
    Loop
    If s <> "" Then pedirProximoDxf = CLng(s)
    Exit Function
erro:
    MsgBox "Erro ao pedir numero DXF:" & vbCrLf & Err.Description, vbCritical
End Function

' Access -> Web: envia UM pacote DXF (zip) para a rota uploadDxfVba.
Public Function enviarDxfParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http As Object
    Dim stream As Object
    Dim dados() As Byte
    Dim url As String
    Dim nomeArq As String

    enviarDxfParaMySQL = False
    If Dir(caminhoArquivo) = "" Then
        MsgBox "Pacote DXF nao encontrado:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDxfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarDxfParaMySQL = True
    Else
        MsgBox "Falha ao enviar DXF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar DXF:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de DXF e faz upsert em DXF_Control (insere os que faltam).
' O Controle vem do MySQL (cartorio), por isso pode ser inserido explicito.
Public Sub sincronizarDxfsDoMySQL()
    Dim http As Object
    Dim txt As String
    Dim linhas() As String
    Dim campos() As String
    Dim i As Long
    Dim ctrl As String, sol As String, proj As String, desc As String
    Dim SQL As String
    Dim ArrChk As Variant
    Dim inseridos As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/dxf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de DXF (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM
    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                ctrl = Trim(campos(0))
                sol = Trim(campos(1))
                proj = Trim(campos(2))
                desc = Trim(campos(3))

                SQL = "SELECT Controle FROM DXF_Control WHERE Controle = " & Val(ctrl) & ";"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO DXF_Control (Controle, Solicitacao, Cod_Proj, Descricao, IMG, DXF) VALUES (" & _
                          Val(ctrl) & ",'" & Replace(sol, "'", "''") & "','" & Replace(proj, "'", "''") & "','" & _
                          Replace(desc, "'", "''") & "', TRUE, TRUE);"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de DXF concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar DXF:" & vbCrLf & Err.Description, vbCritical
End Sub
' Access -> Web: envia os itens de BOM (lote) para a rota uploadBomVba.
' payload = linhas "codigo<TAB>rev<TAB>descricao<TAB>qtde<TAB>tipo" separadas por vbLf.
Public Function enviarBomParaMySQL(ByVal ref As Long, ByVal payload As String) As Boolean
    Dim http As Object
    Dim corpo As String

    enviarBomParaMySQL = False
    If Trim(payload) = "" Then Exit Function

    corpo = "ref=" & ref & "&dados=" & enc(payload)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", urlBaseApp() & "/dispositivos/desenvolvimento/uploadBomVba", False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.send corpo

    If http.Status = 200 Then
        enviarBomParaMySQL = True
    Else
        MsgBox "Falha ao enviar BOM (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar BOM:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de BOM e faz upsert em BOM_Control (insere os que faltam).
' Chave: Solicitacao + Codigo + Revisao. O Controle do BOM_Control continua AutoNumber.
Public Sub sincronizarBomDoMySQL()
    Dim http As Object
    Dim txt As String
    Dim linhas() As String
    Dim campos() As String
    Dim i As Long
    Dim sol As String, proj As String, cod As String, rev As String
    Dim desc As String, qtde As String, tipo As String
    Dim SQL As String
    Dim ArrChk As Variant
    Dim inseridos As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/bom", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de BOM (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM
    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 6 Then
                sol = Trim(campos(0))
                proj = Trim(campos(1))
                cod = Trim(campos(2))
                rev = Trim(campos(3))
                desc = Replace(Trim(campos(4)), "'", "")
                qtde = Trim(campos(5))
                tipo = Trim(campos(6))
                If Not IsNumeric(qtde) Then qtde = "0"
                qtde = Replace(qtde, ",", ".")

                SQL = "SELECT Codigo FROM BOM_Control WHERE Solicitacao = '" & Replace(sol, "'", "''") & _
                      "' AND Codigo = '" & Replace(cod, "'", "''") & "' AND Revisao = '" & Replace(rev, "'", "''") & "';"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO BOM_Control (Projeto, Solicitacao, Codigo, Revisao, Descricao, Qtde, Tipo) VALUES ('" & _
                          Replace(proj, "'", "''") & "','" & Replace(sol, "'", "''") & "','" & Replace(cod, "'", "''") & "','" & _
                          Replace(rev, "'", "''") & "','" & Replace(desc, "'", "''") & "'," & qtde & ",'" & Replace(tipo, "'", "''") & "');"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de BOM concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar BOM:" & vbCrLf & Err.Description, vbCritical
End Sub

```

---

## 4. VBA — `frm_bom` (módulo inteiro)

Mudou `btnInserir_Click` (modo Auto): acumula o lote e chama `enviarBomParaMySQL`.

### ANTES (100%)
```vb
Attribute VB_Name = "frm_bom"
Attribute VB_Base = "0{FE49C5EC-1872-43E2-AB72-1B47E3C07A99}{0EF9FC77-FC53-4FA2-8E55-13EB5B976F24}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False


Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_Click()
    
    Dim Arquivo As Integer
    Dim CaminhoArquivo As String
    Dim TextoArquivo As String
    Dim TextoProximaLinha As String
    Dim ContadorLinha As Long
    
    Dim N_ultimo As Integer
        
    'Configura a leitura do arquivo
    Arquivo = FreeFile
    CaminhoArquivo = OpenTXTDialog
    
    'Abre o arquivo para leitura
    Open CaminhoArquivo For Input As Arquivo
    i = 1
    'Lê o conteúdo do arquivo linha a linha
    Do While Not EOF(Arquivo)
        Line Input #Arquivo, txt
        
        cod = Trim(Left(txt, 20))
        rev = Trim(Mid(txt, 21, 5))
        desc = Replace(Trim(Mid(txt, 27, 100)), "'", "")
        qtde = Trim(Mid(txt, 128, 15))
        tipo = Trim(Mid(txt, 144, 30))
        If cod <> "" Then
            Me.Controls("cod" & i).Value = cod
            Me.Controls("rev" & i).Value = rev
            Me.Controls("desc" & i).Value = desc
            Me.Controls("qtde" & i).Value = Format(qtde, "0.00")
            Me.Controls("tipo" & i).Value = tipo
            i = i + 1
        End If
    Loop
       
    'Fecha o arquivo
    Close Arquivo
    
    If i = 1 Then
        Me.Controls("cod" & i).Value = "VAZIO"
    End If

End Sub

Private Sub btn_inserir_Click()

Dim li As ListItem

UF.bom_lst.ListItems.Clear

For i = 1 To 100
    If Me.Controls("cod" & i).Text <> "" And Me.Controls("cod" & i).Text <> "VAZIO" Then
        Set li = UF.bom_lst.ListItems.Add(, , Me.Controls("cod" & i).Text)
            li.ListSubItems.Add , , Me.Controls("rev" & i).Text
            li.ListSubItems.Add , , Me.Controls("desc" & i).Text
            li.ListSubItems.Add , , Me.Controls("qtde" & i).Text
            li.ListSubItems.Add , , Me.Controls("tipo" & i).Text
            
            lst_ok = 1
            
    End If
Next i
If Me.Controls("cod1").Text = "VAZIO" Then
    lst_ok = 1
End If

Unload Me

If lst_ok = 1 Then
    UF.btn_editar_bom.Enabled = True
    UF.btn_pdf.Enabled = True
    UF.btn_bom.BackColor = &H80FF80
    UF.btn_pdf.BackColor = &HC0C0FF
    UF.seta4.Enabled = True
End If
End Sub

Private Sub btnCancelar_Click()
Unload Me
End Sub


Private Sub btnCarregar_Click()
    Dim Arquivo As Integer
    Dim CaminhoArquivo As String
    Dim TextoArquivo As String
    Dim TextoProximaLinha As String
    Dim ContadorLinha As Long
    
    Dim N_ultimo As Integer
        
    'Configura a leitura do arquivo
    Arquivo = FreeFile
    CaminhoArquivo = OpenTXTDialog
    
    'Abre o arquivo para leitura
    Open CaminhoArquivo For Input As Arquivo
    i = 1
    'Lê o conteúdo do arquivo linha a linha
    Do While Not EOF(Arquivo)
        Line Input #Arquivo, txt
        
        cod = Trim(Left(txt, 20))
        rev = Trim(Mid(txt, 21, 5))
        desc = Replace(Trim(Mid(txt, 27, 100)), "'", "")
        qtde = Trim(Mid(txt, 128, 15))
        tipo = Trim(Mid(txt, 144, 30))
        If cod <> "" Then
            Me.Controls("cod" & i).Value = cod
            Me.Controls("rev" & i).Value = rev
            Me.Controls("desc" & i).Value = desc
            Me.Controls("qtde" & i).Value = Format(qtde, "0.00")
            Me.Controls("tipo" & i).Value = tipo
            i = i + 1
        End If
    Loop
       
    'Fecha o arquivo
    Close Arquivo
    
    If i = 1 Then
        Me.Controls("cod" & i).Value = "VAZIO"
    End If

End Sub

Private Sub btnInserir_Click()

    If Me.lblTipo.Caption = "Auto" Then
        
        t_cod_sl = Me.lbl_ref.Caption
        t_cod_z = Me.lblCodZ.Caption
        'Carrega Lista de Comprados
        For i = 1 To 100
            If Me.Controls("cod" & i).Text <> "" Then
                t_codigo = Me.Controls("cod" & i).Text
                t_rev = Me.Controls("rev" & i).Text
                t_desc_bom = Me.Controls("desc" & i).Text
                t_qtde = Me.Controls("qtde" & i).Text
                t_tipo = Me.Controls("tipo" & i).Text
                If Not IsNumeric(t_qtde) Then t_qtde = 0
                t_qtde = Replace(t_qtde, ",", ".")
            
                SQL = "INSERT INTO BOM_Control (Projeto, Solicitacao, Codigo, Revisao, Descricao, Qtde, Tipo) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo & "',"
                SQL = SQL & "'" & t_rev & "',"
                SQL = SQL & "'" & t_desc_bom & "',"
                SQL = SQL & t_qtde & ","
                SQL = SQL & "'" & t_tipo & "');"
            
                upQuery (SQL)
            End If
        Next i
        
        Unload Me
        Call CarregaBOMAut(t_cod_sl)
        
    Else
        Dim li As ListItem
        UF.bom_lst.ListItems.Clear
        For i = 1 To 100
            If Me.Controls("cod" & i).Text <> "" And Me.Controls("cod" & i).Text <> "VAZIO" Then
                Set li = UF.bom_lst.ListItems.Add(, , Me.Controls("cod" & i).Text)
                    li.ListSubItems.Add , , Me.Controls("rev" & i).Text
                    li.ListSubItems.Add , , Me.Controls("desc" & i).Text
                    li.ListSubItems.Add , , Me.Controls("qtde" & i).Text
                    li.ListSubItems.Add , , Me.Controls("tipo" & i).Text
                    lst_ok = 1
            End If
        Next i
        If Me.Controls("cod1").Text = "VAZIO" Then
            lst_ok = 1
        End If
        Unload Me
        
        If lst_ok = 1 Then
            UF.btn_editar_bom.Enabled = True
            UF.btn_pdf.Enabled = True
            UF.btn_bom.BackColor = &H80FF80
            UF.btn_pdf.BackColor = &HC0C0FF
            UF.seta4.Enabled = True
        End If
    End If
End Sub

Private Sub cod1_Change()
    If Me.cod1.Text <> "" Then
        Me.id2.Visible = True
        Me.cod2.Visible = True
        Me.rev2.Visible = True
        Me.desc2.Visible = True
        Me.qtde2.Visible = True
        Me.tipo2.Visible = True
    End If
End Sub
Private Sub cod2_Change()
    If Me.cod2.Text <> "" Then
        Me.id3.Visible = True
        Me.cod3.Visible = True
        Me.rev3.Visible = True
        Me.desc3.Visible = True
        Me.qtde3.Visible = True
        Me.tipo3.Visible = True
    End If
End Sub
Private Sub cod3_Change()
    If Me.cod3.Text <> "" Then
        Me.id4.Visible = True
        Me.cod4.Visible = True
        Me.rev4.Visible = True
        Me.desc4.Visible = True
        Me.qtde4.Visible = True
        Me.tipo4.Visible = True
    End If
End Sub
Private Sub cod4_Change()
    If Me.cod4.Text <> "" Then
        Me.id5.Visible = True
        Me.cod5.Visible = True
        Me.rev5.Visible = True
        Me.desc5.Visible = True
        Me.qtde5.Visible = True
        Me.tipo5.Visible = True
    End If
End Sub
Private Sub cod5_Change()
    If Me.cod5.Text <> "" Then
        Me.id6.Visible = True
        Me.cod6.Visible = True
        Me.rev6.Visible = True
        Me.desc6.Visible = True
        Me.qtde6.Visible = True
        Me.tipo6.Visible = True
    End If
End Sub
Private Sub cod6_Change()
    If Me.cod6.Text <> "" Then
        Me.id7.Visible = True
        Me.cod7.Visible = True
        Me.rev7.Visible = True
        Me.desc7.Visible = True
        Me.qtde7.Visible = True
        Me.tipo7.Visible = True
    End If
End Sub
Private Sub cod7_Change()
    If Me.cod7.Text <> "" Then
        Me.id8.Visible = True
        Me.cod8.Visible = True
        Me.rev8.Visible = True
        Me.desc8.Visible = True
        Me.qtde8.Visible = True
        Me.tipo8.Visible = True
    End If
End Sub
Private Sub cod8_Change()
    If Me.cod8.Text <> "" Then
        Me.id9.Visible = True
        Me.cod9.Visible = True
        Me.rev9.Visible = True
        Me.desc9.Visible = True
        Me.qtde9.Visible = True
        Me.tipo9.Visible = True
    End If
End Sub
Private Sub cod9_Change()
    If Me.cod9.Text <> "" Then
        Me.id10.Visible = True
        Me.cod10.Visible = True
        Me.rev10.Visible = True
        Me.desc10.Visible = True
        Me.qtde10.Visible = True
        Me.tipo10.Visible = True
    End If
End Sub
Private Sub cod10_Change()
    If Me.cod10.Text <> "" Then
        Me.id11.Visible = True
        Me.cod11.Visible = True
        Me.rev11.Visible = True
        Me.desc11.Visible = True
        Me.qtde11.Visible = True
        Me.tipo11.Visible = True
        Me.frm_lista.ScrollBars = fmScrollBarsVertical
        Me.frm_lista.ScrollHeight = 220 + 18
    End If
End Sub
Private Sub cod11_Change()
    If Me.cod11.Text <> "" Then
        Me.id12.Visible = True
        Me.cod12.Visible = True
        Me.rev12.Visible = True
        Me.desc12.Visible = True
        Me.qtde12.Visible = True
        Me.tipo12.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 36
    End If
End Sub
Private Sub cod12_Change()
    If Me.cod12.Text <> "" Then
        Me.id13.Visible = True
        Me.cod13.Visible = True
        Me.rev13.Visible = True
        Me.desc13.Visible = True
        Me.qtde13.Visible = True
        Me.tipo13.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 54
    End If
End Sub
Private Sub cod13_Change()
    If Me.cod13.Text <> "" Then
        Me.id14.Visible = True
        Me.cod14.Visible = True
        Me.rev14.Visible = True
        Me.desc14.Visible = True
        Me.qtde14.Visible = True
        Me.tipo14.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 72
    End If
End Sub

Private Sub cod14_Change()
    If Me.cod14.Text <> "" Then
        Me.id15.Visible = True
        Me.cod15.Visible = True
        Me.rev15.Visible = True
        Me.desc15.Visible = True
        Me.qtde15.Visible = True
        Me.tipo15.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 90
    End If
End Sub

Private Sub cod15_Change()
    If Me.cod15.Text <> "" Then
        Me.id16.Visible = True
        Me.cod16.Visible = True
        Me.rev16.Visible = True
        Me.desc16.Visible = True
        Me.qtde16.Visible = True
        Me.tipo16.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 108
    End If
End Sub

Private Sub cod16_Change()
    If Me.cod16.Text <> "" Then
        Me.id17.Visible = True
        Me.cod17.Visible = True
        Me.rev17.Visible = True
        Me.desc17.Visible = True
        Me.qtde17.Visible = True
        Me.tipo17.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 126
    End If
End Sub

Private Sub cod17_Change()
    If Me.cod17.Text <> "" Then
        Me.id18.Visible = True
        Me.cod18.Visible = True
        Me.rev18.Visible = True
        Me.desc18.Visible = True
        Me.qtde18.Visible = True
        Me.tipo18.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 144
    End If
End Sub

Private Sub cod18_Change()
    If Me.cod18.Text <> "" Then
        Me.id19.Visible = True
        Me.cod19.Visible = True
        Me.rev19.Visible = True
        Me.desc19.Visible = True
        Me.qtde19.Visible = True
        Me.tipo19.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 162
    End If
End Sub

Private Sub cod19_Change()
    If Me.cod19.Text <> "" Then
        Me.id20.Visible = True
        Me.cod20.Visible = True
        Me.rev20.Visible = True
        Me.desc20.Visible = True
        Me.qtde20.Visible = True
        Me.tipo20.Visible = True
        Me.frm_lista.ScrollHeight = 400
    End If
End Sub

Private Sub cod20_Change()
    If Me.cod20.Text <> "" Then
        Me.id21.Visible = True
        Me.cod21.Visible = True
        Me.rev21.Visible = True
        Me.desc21.Visible = True
        Me.qtde21.Visible = True
        Me.tipo21.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 18
    End If
End Sub

Private Sub cod21_Change()
    If Me.cod21.Text <> "" Then
        Me.id22.Visible = True
        Me.cod22.Visible = True
        Me.rev22.Visible = True
        Me.desc22.Visible = True
        Me.qtde22.Visible = True
        Me.tipo22.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 36
    End If
End Sub

Private Sub cod22_Change()
    If Me.cod22.Text <> "" Then
        Me.id23.Visible = True
        Me.cod23.Visible = True
        Me.rev23.Visible = True
        Me.desc23.Visible = True
        Me.qtde23.Visible = True
        Me.tipo23.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 54
    End If
End Sub

Private Sub cod23_Change()
    If Me.cod23.Text <> "" Then
        Me.id24.Visible = True
        Me.cod24.Visible = True
        Me.rev24.Visible = True
        Me.desc24.Visible = True
        Me.qtde24.Visible = True
        Me.tipo24.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 72
    End If
End Sub

Private Sub cod24_Change()
    If Me.cod24.Text <> "" Then
        Me.id25.Visible = True
        Me.cod25.Visible = True
        Me.rev25.Visible = True
        Me.desc25.Visible = True
        Me.qtde25.Visible = True
        Me.tipo25.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 90
    End If
End Sub

Private Sub cod25_Change()
    If Me.cod25.Text <> "" Then
        Me.id26.Visible = True
        Me.cod26.Visible = True
        Me.rev26.Visible = True
        Me.desc26.Visible = True
        Me.qtde26.Visible = True
        Me.tipo26.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 108
    End If
End Sub

Private Sub cod26_Change()
    If Me.cod26.Text <> "" Then
        Me.id27.Visible = True
        Me.cod27.Visible = True
        Me.rev27.Visible = True
        Me.desc27.Visible = True
        Me.qtde27.Visible = True
        Me.tipo27.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 126
    End If
End Sub

Private Sub cod27_Change()
    If Me.cod27.Text <> "" Then
        Me.id28.Visible = True
        Me.cod28.Visible = True
        Me.rev28.Visible = True
        Me.desc28.Visible = True
        Me.qtde28.Visible = True
        Me.tipo28.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 144
    End If
End Sub

Private Sub cod28_Change()
    If Me.cod28.Text <> "" Then
        Me.id29.Visible = True
        Me.cod29.Visible = True
        Me.rev29.Visible = True
        Me.desc29.Visible = True
        Me.qtde29.Visible = True
        Me.tipo29.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 162
    End If
End Sub

Private Sub cod29_Change()
    If Me.cod29.Text <> "" Then
        Me.id30.Visible = True
        Me.cod30.Visible = True
        Me.rev30.Visible = True
        Me.desc30.Visible = True
        Me.qtde30.Visible = True
        Me.tipo30.Visible = True
        Me.frm_lista.ScrollHeight = 580
    End If
End Sub

Private Sub cod30_Change()
    If Me.cod30.Text <> "" Then
        Me.id31.Visible = True
        Me.cod31.Visible = True
        Me.rev31.Visible = True
        Me.desc31.Visible = True
        Me.qtde31.Visible = True
        Me.tipo31.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 18
    End If
End Sub

Private Sub cod31_Change()
    If Me.cod31.Text <> "" Then
        Me.id32.Visible = True
        Me.cod32.Visible = True
        Me.rev32.Visible = True
        Me.desc32.Visible = True
        Me.qtde32.Visible = True
        Me.tipo32.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 36
    End If
End Sub

Private Sub cod32_Change()
    If Me.cod32.Text <> "" Then
        Me.id33.Visible = True
        Me.cod33.Visible = True
        Me.rev33.Visible = True
        Me.desc33.Visible = True
        Me.qtde33.Visible = True
        Me.tipo33.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 54
    End If
End Sub

Private Sub cod33_Change()
    If Me.cod33.Text <> "" Then
        Me.id34.Visible = True
        Me.cod34.Visible = True
        Me.rev34.Visible = True
        Me.desc34.Visible = True
        Me.qtde34.Visible = True
        Me.tipo34.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 72
    End If
End Sub

Private Sub cod34_Change()
    If Me.cod34.Text <> "" Then
        Me.id35.Visible = True
        Me.cod35.Visible = True
        Me.rev35.Visible = True
        Me.desc35.Visible = True
        Me.qtde35.Visible = True
        Me.tipo35.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 90
    End If
End Sub

Private Sub cod35_Change()
    If Me.cod35.Text <> "" Then
        Me.id36.Visible = True
        Me.cod36.Visible = True
        Me.rev36.Visible = True
        Me.desc36.Visible = True
        Me.qtde36.Visible = True
        Me.tipo36.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 108
    End If
End Sub

Private Sub cod36_Change()
    If Me.cod36.Text <> "" Then
        Me.id37.Visible = True
        Me.cod37.Visible = True
        Me.rev37.Visible = True
        Me.desc37.Visible = True
        Me.qtde37.Visible = True
        Me.tipo37.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 126
    End If
End Sub

Private Sub cod37_Change()
    If Me.cod37.Text <> "" Then
        Me.id38.Visible = True
        Me.cod38.Visible = True
        Me.rev38.Visible = True
        Me.desc38.Visible = True
        Me.qtde38.Visible = True
        Me.tipo38.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 144
    End If
End Sub

Private Sub cod38_Change()
    If Me.cod38.Text <> "" Then
        Me.id39.Visible = True
        Me.cod39.Visible = True
        Me.rev39.Visible = True
        Me.desc39.Visible = True
        Me.qtde39.Visible = True
        Me.tipo39.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 162
    End If
End Sub

Private Sub cod39_Change()
    If Me.cod39.Text <> "" Then
        Me.id40.Visible = True
        Me.cod40.Visible = True
        Me.rev40.Visible = True
        Me.desc40.Visible = True
        Me.qtde40.Visible = True
        Me.tipo40.Visible = True
        Me.frm_lista.ScrollHeight = 760
    End If
End Sub

Private Sub cod40_Change()
    If Me.cod40.Text <> "" Then
        Me.id41.Visible = True
        Me.cod41.Visible = True
        Me.rev41.Visible = True
        Me.desc41.Visible = True
        Me.qtde41.Visible = True
        Me.tipo41.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 18
    End If
End Sub

Private Sub cod41_Change()
    If Me.cod41.Text <> "" Then
        Me.id42.Visible = True
        Me.cod42.Visible = True
        Me.rev42.Visible = True
        Me.desc42.Visible = True
        Me.qtde42.Visible = True
        Me.tipo42.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 36
    End If
End Sub

Private Sub cod42_Change()
    If Me.cod42.Text <> "" Then
        Me.id43.Visible = True
        Me.cod43.Visible = True
        Me.rev43.Visible = True
        Me.desc43.Visible = True
        Me.qtde43.Visible = True
        Me.tipo43.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 54
    End If
End Sub

Private Sub cod43_Change()
    If Me.cod43.Text <> "" Then
        Me.id44.Visible = True
        Me.cod44.Visible = True
        Me.rev44.Visible = True
        Me.desc44.Visible = True
        Me.qtde44.Visible = True
        Me.tipo44.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 72
    End If
End Sub

Private Sub cod44_Change()
    If Me.cod44.Text <> "" Then
        Me.id45.Visible = True
        Me.cod45.Visible = True
        Me.rev45.Visible = True
        Me.desc45.Visible = True
        Me.qtde45.Visible = True
        Me.tipo45.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 90
    End If
End Sub

Private Sub cod45_Change()
    If Me.cod45.Text <> "" Then
        Me.id46.Visible = True
        Me.cod46.Visible = True
        Me.rev46.Visible = True
        Me.desc46.Visible = True
        Me.qtde46.Visible = True
        Me.tipo46.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 108
    End If
End Sub

Private Sub cod46_Change()
    If Me.cod46.Text <> "" Then
        Me.id47.Visible = True
        Me.cod47.Visible = True
        Me.rev47.Visible = True
        Me.desc47.Visible = True
        Me.qtde47.Visible = True
        Me.tipo47.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 126
    End If
End Sub

Private Sub cod47_Change()
    If Me.cod47.Text <> "" Then
        Me.id48.Visible = True
        Me.cod48.Visible = True
        Me.rev48.Visible = True
        Me.desc48.Visible = True
        Me.qtde48.Visible = True
        Me.tipo48.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 144
    End If
End Sub

Private Sub cod48_Change()
    If Me.cod48.Text <> "" Then
        Me.id49.Visible = True
        Me.cod49.Visible = True
        Me.rev49.Visible = True
        Me.desc49.Visible = True
        Me.qtde49.Visible = True
        Me.tipo49.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 162
    End If
End Sub

Private Sub cod49_Change()
    If Me.cod49.Text <> "" Then
        Me.id50.Visible = True
        Me.cod50.Visible = True
        Me.rev50.Visible = True
        Me.desc50.Visible = True
        Me.qtde50.Visible = True
        Me.tipo50.Visible = True
        Me.frm_lista.ScrollHeight = 940
    End If
End Sub

'############################################################################
Private Sub cod50_Change()
    If Me.cod50.Text <> "" Then
        Me.id51.Visible = True
        Me.cod51.Visible = True
        Me.rev51.Visible = True
        Me.desc51.Visible = True
        Me.qtde51.Visible = True
        Me.tipo51.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 18
    End If
End Sub

Private Sub cod51_Change()
    If Me.cod51.Text <> "" Then
        Me.id52.Visible = True
        Me.cod52.Visible = True
        Me.rev52.Visible = True
        Me.desc52.Visible = True
        Me.qtde52.Visible = True
        Me.tipo52.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 36
    End If
End Sub

Private Sub cod52_Change()
    If Me.cod52.Text <> "" Then
        Me.id53.Visible = True
        Me.cod53.Visible = True
        Me.rev53.Visible = True
        Me.desc53.Visible = True
        Me.qtde53.Visible = True
        Me.tipo53.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 54
    End If
End Sub

Private Sub cod53_Change()
    If Me.cod53.Text <> "" Then
        Me.id54.Visible = True
        Me.cod54.Visible = True
        Me.rev54.Visible = True
        Me.desc54.Visible = True
        Me.qtde54.Visible = True
        Me.tipo54.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 72
    End If
End Sub

Private Sub cod54_Change()
    If Me.cod54.Text <> "" Then
        Me.id55.Visible = True
        Me.cod55.Visible = True
        Me.rev55.Visible = True
        Me.desc55.Visible = True
        Me.qtde55.Visible = True
        Me.tipo55.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 90
    End If
End Sub

Private Sub cod55_Change()
    If Me.cod55.Text <> "" Then
        Me.id56.Visible = True
        Me.cod56.Visible = True
        Me.rev56.Visible = True
        Me.desc56.Visible = True
        Me.qtde56.Visible = True
        Me.tipo56.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 108
    End If
End Sub

Private Sub cod56_Change()
    If Me.cod56.Text <> "" Then
        Me.id57.Visible = True
        Me.cod57.Visible = True
        Me.rev57.Visible = True
        Me.desc57.Visible = True
        Me.qtde57.Visible = True
        Me.tipo57.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 126
    End If
End Sub

Private Sub cod57_Change()
    If Me.cod57.Text <> "" Then
        Me.id58.Visible = True
        Me.cod58.Visible = True
        Me.rev58.Visible = True
        Me.desc58.Visible = True
        Me.qtde58.Visible = True
        Me.tipo58.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 144
    End If
End Sub

Private Sub cod58_Change()
    If Me.cod58.Text <> "" Then
        Me.id59.Visible = True
        Me.cod59.Visible = True
        Me.rev59.Visible = True
        Me.desc59.Visible = True
        Me.qtde59.Visible = True
        Me.tipo59.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 162
    End If
End Sub

Private Sub cod59_Change()
    If Me.cod59.Text <> "" Then
        Me.id60.Visible = True
        Me.cod60.Visible = True
        Me.rev60.Visible = True
        Me.desc60.Visible = True
        Me.qtde60.Visible = True
        Me.tipo60.Visible = True
        Me.frm_lista.ScrollHeight = 1120
    End If
End Sub

'############################################################################
Private Sub cod60_Change()
    If Me.cod60.Text <> "" Then
        Me.id61.Visible = True
        Me.cod61.Visible = True
        Me.rev61.Visible = True
        Me.desc61.Visible = True
        Me.qtde61.Visible = True
        Me.tipo61.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 18
    End If
End Sub

Private Sub cod61_Change()
    If Me.cod61.Text <> "" Then
        Me.id62.Visible = True
        Me.cod62.Visible = True
        Me.rev62.Visible = True
        Me.desc62.Visible = True
        Me.qtde62.Visible = True
        Me.tipo62.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 36
    End If
End Sub

Private Sub cod62_Change()
    If Me.cod62.Text <> "" Then
        Me.id63.Visible = True
        Me.cod63.Visible = True
        Me.rev63.Visible = True
        Me.desc63.Visible = True
        Me.qtde63.Visible = True
        Me.tipo63.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 54
    End If
End Sub

Private Sub cod63_Change()
    If Me.cod63.Text <> "" Then
        Me.id64.Visible = True
        Me.cod64.Visible = True
        Me.rev64.Visible = True
        Me.desc64.Visible = True
        Me.qtde64.Visible = True
        Me.tipo64.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 72
    End If
End Sub

Private Sub cod64_Change()
    If Me.cod64.Text <> "" Then
        Me.id65.Visible = True
        Me.cod65.Visible = True
        Me.rev65.Visible = True
        Me.desc65.Visible = True
        Me.qtde65.Visible = True
        Me.tipo65.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 90
    End If
End Sub

Private Sub cod65_Change()
    If Me.cod65.Text <> "" Then
        Me.id66.Visible = True
        Me.cod66.Visible = True
        Me.rev66.Visible = True
        Me.desc66.Visible = True
        Me.qtde66.Visible = True
        Me.tipo66.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 108
    End If
End Sub

Private Sub cod66_Change()
    If Me.cod66.Text <> "" Then
        Me.id67.Visible = True
        Me.cod67.Visible = True
        Me.rev67.Visible = True
        Me.desc67.Visible = True
        Me.qtde67.Visible = True
        Me.tipo67.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 126
    End If
End Sub

Private Sub cod67_Change()
    If Me.cod67.Text <> "" Then
        Me.id68.Visible = True
        Me.cod68.Visible = True
        Me.rev68.Visible = True
        Me.desc68.Visible = True
        Me.qtde68.Visible = True
        Me.tipo68.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 144
    End If
End Sub

Private Sub cod68_Change()
    If Me.cod68.Text <> "" Then
        Me.id69.Visible = True
        Me.cod69.Visible = True
        Me.rev69.Visible = True
        Me.desc69.Visible = True
        Me.qtde69.Visible = True
        Me.tipo69.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 162
    End If
End Sub

Private Sub cod69_Change()
    If Me.cod69.Text <> "" Then
        Me.id70.Visible = True
        Me.cod70.Visible = True
        Me.rev70.Visible = True
        Me.desc70.Visible = True
        Me.qtde70.Visible = True
        Me.tipo70.Visible = True
        Me.frm_lista.ScrollHeight = 1300
    End If
End Sub

'############################################################################
Private Sub cod70_Change()
    If Me.cod70.Text <> "" Then
        Me.id71.Visible = True
        Me.cod71.Visible = True
        Me.rev71.Visible = True
        Me.desc71.Visible = True
        Me.qtde71.Visible = True
        Me.tipo71.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 18
    End If
End Sub

Private Sub cod71_Change()
    If Me.cod71.Text <> "" Then
        Me.id72.Visible = True
        Me.cod72.Visible = True
        Me.rev72.Visible = True
        Me.desc72.Visible = True
        Me.qtde72.Visible = True
        Me.tipo72.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 36
    End If
End Sub

Private Sub cod72_Change()
    If Me.cod72.Text <> "" Then
        Me.id73.Visible = True
        Me.cod73.Visible = True
        Me.rev73.Visible = True
        Me.desc73.Visible = True
        Me.qtde73.Visible = True
        Me.tipo73.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 54
    End If
End Sub

Private Sub cod73_Change()
    If Me.cod73.Text <> "" Then
        Me.id74.Visible = True
        Me.cod74.Visible = True
        Me.rev74.Visible = True
        Me.desc74.Visible = True
        Me.qtde74.Visible = True
        Me.tipo74.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 72
    End If
End Sub

Private Sub cod74_Change()
    If Me.cod74.Text <> "" Then
        Me.id75.Visible = True
        Me.cod75.Visible = True
        Me.rev75.Visible = True
        Me.desc75.Visible = True
        Me.qtde75.Visible = True
        Me.tipo75.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 90
    End If
End Sub

Private Sub cod75_Change()
    If Me.cod75.Text <> "" Then
        Me.id76.Visible = True
        Me.cod76.Visible = True
        Me.rev76.Visible = True
        Me.desc76.Visible = True
        Me.qtde76.Visible = True
        Me.tipo76.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 108
    End If
End Sub

Private Sub cod76_Change()
    If Me.cod76.Text <> "" Then
        Me.id77.Visible = True
        Me.cod77.Visible = True
        Me.rev77.Visible = True
        Me.desc77.Visible = True
        Me.qtde77.Visible = True
        Me.tipo77.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 126
    End If
End Sub

Private Sub cod77_Change()
    If Me.cod77.Text <> "" Then
        Me.id78.Visible = True
        Me.cod78.Visible = True
        Me.rev78.Visible = True
        Me.desc78.Visible = True
        Me.qtde78.Visible = True
        Me.tipo78.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 144
    End If
End Sub

Private Sub cod78_Change()
    If Me.cod78.Text <> "" Then
        Me.id79.Visible = True
        Me.cod79.Visible = True
        Me.rev79.Visible = True
        Me.desc79.Visible = True
        Me.qtde79.Visible = True
        Me.tipo79.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 162
    End If
End Sub

Private Sub cod79_Change()
    If Me.cod79.Text <> "" Then
        Me.id80.Visible = True
        Me.cod80.Visible = True
        Me.rev80.Visible = True
        Me.desc80.Visible = True
        Me.qtde80.Visible = True
        Me.tipo80.Visible = True
        Me.frm_lista.ScrollHeight = 1480
    End If
End Sub


'############################################################################
Private Sub cod80_Change()
    If Me.cod80.Text <> "" Then
        Me.id81.Visible = True
        Me.cod81.Visible = True
        Me.rev81.Visible = True
        Me.desc81.Visible = True
        Me.qtde81.Visible = True
        Me.tipo81.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 18
    End If
End Sub

Private Sub cod81_Change()
    If Me.cod81.Text <> "" Then
        Me.id82.Visible = True
        Me.cod82.Visible = True
        Me.rev82.Visible = True
        Me.desc82.Visible = True
        Me.qtde82.Visible = True
        Me.tipo82.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 36
    End If
End Sub

Private Sub cod82_Change()
    If Me.cod82.Text <> "" Then
        Me.id83.Visible = True
        Me.cod83.Visible = True
        Me.rev83.Visible = True
        Me.desc83.Visible = True
        Me.qtde83.Visible = True
        Me.tipo83.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 54
    End If
End Sub

Private Sub cod83_Change()
    If Me.cod83.Text <> "" Then
        Me.id84.Visible = True
        Me.cod84.Visible = True
        Me.rev84.Visible = True
        Me.desc84.Visible = True
        Me.qtde84.Visible = True
        Me.tipo84.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 72
    End If
End Sub

Private Sub cod84_Change()
    If Me.cod84.Text <> "" Then
        Me.id85.Visible = True
        Me.cod85.Visible = True
        Me.rev85.Visible = True
        Me.desc85.Visible = True
        Me.qtde85.Visible = True
        Me.tipo85.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 90
    End If
End Sub

Private Sub cod85_Change()
    If Me.cod85.Text <> "" Then
        Me.id86.Visible = True
        Me.cod86.Visible = True
        Me.rev86.Visible = True
        Me.desc86.Visible = True
        Me.qtde86.Visible = True
        Me.tipo86.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 108
    End If
End Sub

Private Sub cod86_Change()
    If Me.cod86.Text <> "" Then
        Me.id87.Visible = True
        Me.cod87.Visible = True
        Me.rev87.Visible = True
        Me.desc87.Visible = True
        Me.qtde87.Visible = True
        Me.tipo87.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 126
    End If
End Sub

Private Sub cod87_Change()
    If Me.cod87.Text <> "" Then
        Me.id88.Visible = True
        Me.cod88.Visible = True
        Me.rev88.Visible = True
        Me.desc88.Visible = True
        Me.qtde88.Visible = True
        Me.tipo88.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 144
    End If
End Sub

Private Sub cod88_Change()
    If Me.cod88.Text <> "" Then
        Me.id89.Visible = True
        Me.cod89.Visible = True
        Me.rev89.Visible = True
        Me.desc89.Visible = True
        Me.qtde89.Visible = True
        Me.tipo89.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 162
    End If
End Sub

Private Sub cod89_Change()
    If Me.cod89.Text <> "" Then
        Me.id90.Visible = True
        Me.cod90.Visible = True
        Me.rev90.Visible = True
        Me.desc90.Visible = True
        Me.qtde90.Visible = True
        Me.tipo90.Visible = True
        Me.frm_lista.ScrollHeight = 1660
    End If
End Sub

'############################################################################
Private Sub cod90_Change()
    If Me.cod90.Text <> "" Then
        Me.id91.Visible = True
        Me.cod91.Visible = True
        Me.rev91.Visible = True
        Me.desc91.Visible = True
        Me.qtde91.Visible = True
        Me.tipo91.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 18
    End If
End Sub

Private Sub cod91_Change()
    If Me.cod91.Text <> "" Then
        Me.id92.Visible = True
        Me.cod92.Visible = True
        Me.rev92.Visible = True
        Me.desc92.Visible = True
        Me.qtde92.Visible = True
        Me.tipo92.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 36
    End If
End Sub

Private Sub cod92_Change()
    If Me.cod92.Text <> "" Then
        Me.id93.Visible = True
        Me.cod93.Visible = True
        Me.rev93.Visible = True
        Me.desc93.Visible = True
        Me.qtde93.Visible = True
        Me.tipo93.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 54
    End If
End Sub

Private Sub cod93_Change()
    If Me.cod93.Text <> "" Then
        Me.id94.Visible = True
        Me.cod94.Visible = True
        Me.rev94.Visible = True
        Me.desc94.Visible = True
        Me.qtde94.Visible = True
        Me.tipo94.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 72
    End If
End Sub

Private Sub cod94_Change()
    If Me.cod94.Text <> "" Then
        Me.id95.Visible = True
        Me.cod95.Visible = True
        Me.rev95.Visible = True
        Me.desc95.Visible = True
        Me.qtde95.Visible = True
        Me.tipo95.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 90
    End If
End Sub

Private Sub cod95_Change()
    If Me.cod95.Text <> "" Then
        Me.id96.Visible = True
        Me.cod96.Visible = True
        Me.rev96.Visible = True
        Me.desc96.Visible = True
        Me.qtde96.Visible = True
        Me.tipo96.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 108
    End If
End Sub

Private Sub cod96_Change()
    If Me.cod96.Text <> "" Then
        Me.id97.Visible = True
        Me.cod97.Visible = True
        Me.rev97.Visible = True
        Me.desc97.Visible = True
        Me.qtde97.Visible = True
        Me.tipo97.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 126
    End If
End Sub

Private Sub cod97_Change()
    If Me.cod97.Text <> "" Then
        Me.id98.Visible = True
        Me.cod98.Visible = True
        Me.rev98.Visible = True
        Me.desc98.Visible = True
        Me.qtde98.Visible = True
        Me.tipo98.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 144
    End If
End Sub

Private Sub cod98_Change()
    If Me.cod98.Text <> "" Then
        Me.id99.Visible = True
        Me.cod99.Visible = True
        Me.rev99.Visible = True
        Me.desc99.Visible = True
        Me.qtde99.Visible = True
        Me.tipo99.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 162
    End If
End Sub

Private Sub cod99_Change()
    If Me.cod99.Text <> "" Then
        Me.id100.Visible = True
        Me.cod100.Visible = True
        Me.rev100.Visible = True
        Me.desc100.Visible = True
        Me.qtde100.Visible = True
        Me.tipo100.Visible = True
        Me.frm_lista.ScrollHeight = 1840
    End If
End Sub


Private Sub UserForm_Initialize()
For i = 1 To 100

Me.Controls("cod" & i).TabIndex = (i * 5) - 5
Me.Controls("rev" & i).TabIndex = (i * 5) - 4
Me.Controls("desc" & i).TabIndex = (i * 5) - 3
Me.Controls("qtde" & i).TabIndex = (i * 5) - 2
Me.Controls("tipo" & i).TabIndex = (i * 5) - 1

Next i
End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "frm_bom"
Attribute VB_Base = "0{FE49C5EC-1872-43E2-AB72-1B47E3C07A99}{0EF9FC77-FC53-4FA2-8E55-13EB5B976F24}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False


Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_Click()
    
    Dim Arquivo As Integer
    Dim CaminhoArquivo As String
    Dim TextoArquivo As String
    Dim TextoProximaLinha As String
    Dim ContadorLinha As Long
    
    Dim N_ultimo As Integer
        
    'Configura a leitura do arquivo
    Arquivo = FreeFile
    CaminhoArquivo = OpenTXTDialog
    
    'Abre o arquivo para leitura
    Open CaminhoArquivo For Input As Arquivo
    i = 1
    'Lê o conteúdo do arquivo linha a linha
    Do While Not EOF(Arquivo)
        Line Input #Arquivo, txt
        
        cod = Trim(Left(txt, 20))
        rev = Trim(Mid(txt, 21, 5))
        desc = Replace(Trim(Mid(txt, 27, 100)), "'", "")
        qtde = Trim(Mid(txt, 128, 15))
        tipo = Trim(Mid(txt, 144, 30))
        If cod <> "" Then
            Me.Controls("cod" & i).Value = cod
            Me.Controls("rev" & i).Value = rev
            Me.Controls("desc" & i).Value = desc
            Me.Controls("qtde" & i).Value = Format(qtde, "0.00")
            Me.Controls("tipo" & i).Value = tipo
            i = i + 1
        End If
    Loop
       
    'Fecha o arquivo
    Close Arquivo
    
    If i = 1 Then
        Me.Controls("cod" & i).Value = "VAZIO"
    End If

End Sub

Private Sub btn_inserir_Click()

Dim li As ListItem

UF.bom_lst.ListItems.Clear

For i = 1 To 100
    If Me.Controls("cod" & i).Text <> "" And Me.Controls("cod" & i).Text <> "VAZIO" Then
        Set li = UF.bom_lst.ListItems.Add(, , Me.Controls("cod" & i).Text)
            li.ListSubItems.Add , , Me.Controls("rev" & i).Text
            li.ListSubItems.Add , , Me.Controls("desc" & i).Text
            li.ListSubItems.Add , , Me.Controls("qtde" & i).Text
            li.ListSubItems.Add , , Me.Controls("tipo" & i).Text
            
            lst_ok = 1
            
    End If
Next i
If Me.Controls("cod1").Text = "VAZIO" Then
    lst_ok = 1
End If

Unload Me

If lst_ok = 1 Then
    UF.btn_editar_bom.Enabled = True
    UF.btn_pdf.Enabled = True
    UF.btn_bom.BackColor = &H80FF80
    UF.btn_pdf.BackColor = &HC0C0FF
    UF.seta4.Enabled = True
End If
End Sub

Private Sub btnCancelar_Click()
Unload Me
End Sub


Private Sub btnCarregar_Click()
    Dim Arquivo As Integer
    Dim CaminhoArquivo As String
    Dim TextoArquivo As String
    Dim TextoProximaLinha As String
    Dim ContadorLinha As Long
    
    Dim N_ultimo As Integer
        
    'Configura a leitura do arquivo
    Arquivo = FreeFile
    CaminhoArquivo = OpenTXTDialog
    
    'Abre o arquivo para leitura
    Open CaminhoArquivo For Input As Arquivo
    i = 1
    'Lê o conteúdo do arquivo linha a linha
    Do While Not EOF(Arquivo)
        Line Input #Arquivo, txt
        
        cod = Trim(Left(txt, 20))
        rev = Trim(Mid(txt, 21, 5))
        desc = Replace(Trim(Mid(txt, 27, 100)), "'", "")
        qtde = Trim(Mid(txt, 128, 15))
        tipo = Trim(Mid(txt, 144, 30))
        If cod <> "" Then
            Me.Controls("cod" & i).Value = cod
            Me.Controls("rev" & i).Value = rev
            Me.Controls("desc" & i).Value = desc
            Me.Controls("qtde" & i).Value = Format(qtde, "0.00")
            Me.Controls("tipo" & i).Value = tipo
            i = i + 1
        End If
    Loop
       
    'Fecha o arquivo
    Close Arquivo
    
    If i = 1 Then
        Me.Controls("cod" & i).Value = "VAZIO"
    End If

End Sub

Private Sub btnInserir_Click()

    Dim bomPayload As String

    If Me.lblTipo.Caption = "Auto" Then

        bomPayload = ""
        t_cod_sl = Me.lbl_ref.Caption
        t_cod_z = Me.lblCodZ.Caption
        'Carrega Lista de Comprados
        For i = 1 To 100
            If Me.Controls("cod" & i).Text <> "" Then
                t_codigo = Me.Controls("cod" & i).Text
                t_rev = Me.Controls("rev" & i).Text
                t_desc_bom = Me.Controls("desc" & i).Text
                t_qtde = Me.Controls("qtde" & i).Text
                t_tipo = Me.Controls("tipo" & i).Text
                If Not IsNumeric(t_qtde) Then t_qtde = 0
                t_qtde = Replace(t_qtde, ",", ".")

                SQL = "INSERT INTO BOM_Control (Projeto, Solicitacao, Codigo, Revisao, Descricao, Qtde, Tipo) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo & "',"
                SQL = SQL & "'" & t_rev & "',"
                SQL = SQL & "'" & t_desc_bom & "',"
                SQL = SQL & t_qtde & ","
                SQL = SQL & "'" & t_tipo & "');"

                upQuery (SQL)

                ' Acumula a linha p/ enviar pro MySQL/web (campos separados por TAB)
                bomPayload = bomPayload & t_codigo & vbTab & t_rev & vbTab & t_desc_bom & vbTab & t_qtde & vbTab & t_tipo & vbLf
            End If
        Next i

        ' Access -> Web: envia o lote de BOM
        enviarBomParaMySQL CLng(Replace(t_cod_sl, "SL", "")), bomPayload

        Unload Me
        Call CarregaBOMAut(t_cod_sl)

    Else
        Dim li As ListItem
        UF.bom_lst.ListItems.Clear
        For i = 1 To 100
            If Me.Controls("cod" & i).Text <> "" And Me.Controls("cod" & i).Text <> "VAZIO" Then
                Set li = UF.bom_lst.ListItems.Add(, , Me.Controls("cod" & i).Text)
                    li.ListSubItems.Add , , Me.Controls("rev" & i).Text
                    li.ListSubItems.Add , , Me.Controls("desc" & i).Text
                    li.ListSubItems.Add , , Me.Controls("qtde" & i).Text
                    li.ListSubItems.Add , , Me.Controls("tipo" & i).Text
                    lst_ok = 1
            End If
        Next i
        If Me.Controls("cod1").Text = "VAZIO" Then
            lst_ok = 1
        End If
        Unload Me

        If lst_ok = 1 Then
            UF.btn_editar_bom.Enabled = True
            UF.btn_pdf.Enabled = True
            UF.btn_bom.BackColor = &H80FF80
            UF.btn_pdf.BackColor = &HC0C0FF
            UF.seta4.Enabled = True
        End If
    End If
End Sub

Private Sub cod1_Change()
    If Me.cod1.Text <> "" Then
        Me.id2.Visible = True
        Me.cod2.Visible = True
        Me.rev2.Visible = True
        Me.desc2.Visible = True
        Me.qtde2.Visible = True
        Me.tipo2.Visible = True
    End If
End Sub
Private Sub cod2_Change()
    If Me.cod2.Text <> "" Then
        Me.id3.Visible = True
        Me.cod3.Visible = True
        Me.rev3.Visible = True
        Me.desc3.Visible = True
        Me.qtde3.Visible = True
        Me.tipo3.Visible = True
    End If
End Sub
Private Sub cod3_Change()
    If Me.cod3.Text <> "" Then
        Me.id4.Visible = True
        Me.cod4.Visible = True
        Me.rev4.Visible = True
        Me.desc4.Visible = True
        Me.qtde4.Visible = True
        Me.tipo4.Visible = True
    End If
End Sub
Private Sub cod4_Change()
    If Me.cod4.Text <> "" Then
        Me.id5.Visible = True
        Me.cod5.Visible = True
        Me.rev5.Visible = True
        Me.desc5.Visible = True
        Me.qtde5.Visible = True
        Me.tipo5.Visible = True
    End If
End Sub
Private Sub cod5_Change()
    If Me.cod5.Text <> "" Then
        Me.id6.Visible = True
        Me.cod6.Visible = True
        Me.rev6.Visible = True
        Me.desc6.Visible = True
        Me.qtde6.Visible = True
        Me.tipo6.Visible = True
    End If
End Sub
Private Sub cod6_Change()
    If Me.cod6.Text <> "" Then
        Me.id7.Visible = True
        Me.cod7.Visible = True
        Me.rev7.Visible = True
        Me.desc7.Visible = True
        Me.qtde7.Visible = True
        Me.tipo7.Visible = True
    End If
End Sub
Private Sub cod7_Change()
    If Me.cod7.Text <> "" Then
        Me.id8.Visible = True
        Me.cod8.Visible = True
        Me.rev8.Visible = True
        Me.desc8.Visible = True
        Me.qtde8.Visible = True
        Me.tipo8.Visible = True
    End If
End Sub
Private Sub cod8_Change()
    If Me.cod8.Text <> "" Then
        Me.id9.Visible = True
        Me.cod9.Visible = True
        Me.rev9.Visible = True
        Me.desc9.Visible = True
        Me.qtde9.Visible = True
        Me.tipo9.Visible = True
    End If
End Sub
Private Sub cod9_Change()
    If Me.cod9.Text <> "" Then
        Me.id10.Visible = True
        Me.cod10.Visible = True
        Me.rev10.Visible = True
        Me.desc10.Visible = True
        Me.qtde10.Visible = True
        Me.tipo10.Visible = True
    End If
End Sub
Private Sub cod10_Change()
    If Me.cod10.Text <> "" Then
        Me.id11.Visible = True
        Me.cod11.Visible = True
        Me.rev11.Visible = True
        Me.desc11.Visible = True
        Me.qtde11.Visible = True
        Me.tipo11.Visible = True
        Me.frm_lista.ScrollBars = fmScrollBarsVertical
        Me.frm_lista.ScrollHeight = 220 + 18
    End If
End Sub
Private Sub cod11_Change()
    If Me.cod11.Text <> "" Then
        Me.id12.Visible = True
        Me.cod12.Visible = True
        Me.rev12.Visible = True
        Me.desc12.Visible = True
        Me.qtde12.Visible = True
        Me.tipo12.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 36
    End If
End Sub
Private Sub cod12_Change()
    If Me.cod12.Text <> "" Then
        Me.id13.Visible = True
        Me.cod13.Visible = True
        Me.rev13.Visible = True
        Me.desc13.Visible = True
        Me.qtde13.Visible = True
        Me.tipo13.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 54
    End If
End Sub
Private Sub cod13_Change()
    If Me.cod13.Text <> "" Then
        Me.id14.Visible = True
        Me.cod14.Visible = True
        Me.rev14.Visible = True
        Me.desc14.Visible = True
        Me.qtde14.Visible = True
        Me.tipo14.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 72
    End If
End Sub

Private Sub cod14_Change()
    If Me.cod14.Text <> "" Then
        Me.id15.Visible = True
        Me.cod15.Visible = True
        Me.rev15.Visible = True
        Me.desc15.Visible = True
        Me.qtde15.Visible = True
        Me.tipo15.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 90
    End If
End Sub

Private Sub cod15_Change()
    If Me.cod15.Text <> "" Then
        Me.id16.Visible = True
        Me.cod16.Visible = True
        Me.rev16.Visible = True
        Me.desc16.Visible = True
        Me.qtde16.Visible = True
        Me.tipo16.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 108
    End If
End Sub

Private Sub cod16_Change()
    If Me.cod16.Text <> "" Then
        Me.id17.Visible = True
        Me.cod17.Visible = True
        Me.rev17.Visible = True
        Me.desc17.Visible = True
        Me.qtde17.Visible = True
        Me.tipo17.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 126
    End If
End Sub

Private Sub cod17_Change()
    If Me.cod17.Text <> "" Then
        Me.id18.Visible = True
        Me.cod18.Visible = True
        Me.rev18.Visible = True
        Me.desc18.Visible = True
        Me.qtde18.Visible = True
        Me.tipo18.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 144
    End If
End Sub

Private Sub cod18_Change()
    If Me.cod18.Text <> "" Then
        Me.id19.Visible = True
        Me.cod19.Visible = True
        Me.rev19.Visible = True
        Me.desc19.Visible = True
        Me.qtde19.Visible = True
        Me.tipo19.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 162
    End If
End Sub

Private Sub cod19_Change()
    If Me.cod19.Text <> "" Then
        Me.id20.Visible = True
        Me.cod20.Visible = True
        Me.rev20.Visible = True
        Me.desc20.Visible = True
        Me.qtde20.Visible = True
        Me.tipo20.Visible = True
        Me.frm_lista.ScrollHeight = 400
    End If
End Sub

Private Sub cod20_Change()
    If Me.cod20.Text <> "" Then
        Me.id21.Visible = True
        Me.cod21.Visible = True
        Me.rev21.Visible = True
        Me.desc21.Visible = True
        Me.qtde21.Visible = True
        Me.tipo21.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 18
    End If
End Sub

Private Sub cod21_Change()
    If Me.cod21.Text <> "" Then
        Me.id22.Visible = True
        Me.cod22.Visible = True
        Me.rev22.Visible = True
        Me.desc22.Visible = True
        Me.qtde22.Visible = True
        Me.tipo22.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 36
    End If
End Sub

Private Sub cod22_Change()
    If Me.cod22.Text <> "" Then
        Me.id23.Visible = True
        Me.cod23.Visible = True
        Me.rev23.Visible = True
        Me.desc23.Visible = True
        Me.qtde23.Visible = True
        Me.tipo23.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 54
    End If
End Sub

Private Sub cod23_Change()
    If Me.cod23.Text <> "" Then
        Me.id24.Visible = True
        Me.cod24.Visible = True
        Me.rev24.Visible = True
        Me.desc24.Visible = True
        Me.qtde24.Visible = True
        Me.tipo24.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 72
    End If
End Sub

Private Sub cod24_Change()
    If Me.cod24.Text <> "" Then
        Me.id25.Visible = True
        Me.cod25.Visible = True
        Me.rev25.Visible = True
        Me.desc25.Visible = True
        Me.qtde25.Visible = True
        Me.tipo25.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 90
    End If
End Sub

Private Sub cod25_Change()
    If Me.cod25.Text <> "" Then
        Me.id26.Visible = True
        Me.cod26.Visible = True
        Me.rev26.Visible = True
        Me.desc26.Visible = True
        Me.qtde26.Visible = True
        Me.tipo26.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 108
    End If
End Sub

Private Sub cod26_Change()
    If Me.cod26.Text <> "" Then
        Me.id27.Visible = True
        Me.cod27.Visible = True
        Me.rev27.Visible = True
        Me.desc27.Visible = True
        Me.qtde27.Visible = True
        Me.tipo27.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 126
    End If
End Sub

Private Sub cod27_Change()
    If Me.cod27.Text <> "" Then
        Me.id28.Visible = True
        Me.cod28.Visible = True
        Me.rev28.Visible = True
        Me.desc28.Visible = True
        Me.qtde28.Visible = True
        Me.tipo28.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 144
    End If
End Sub

Private Sub cod28_Change()
    If Me.cod28.Text <> "" Then
        Me.id29.Visible = True
        Me.cod29.Visible = True
        Me.rev29.Visible = True
        Me.desc29.Visible = True
        Me.qtde29.Visible = True
        Me.tipo29.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 162
    End If
End Sub

Private Sub cod29_Change()
    If Me.cod29.Text <> "" Then
        Me.id30.Visible = True
        Me.cod30.Visible = True
        Me.rev30.Visible = True
        Me.desc30.Visible = True
        Me.qtde30.Visible = True
        Me.tipo30.Visible = True
        Me.frm_lista.ScrollHeight = 580
    End If
End Sub

Private Sub cod30_Change()
    If Me.cod30.Text <> "" Then
        Me.id31.Visible = True
        Me.cod31.Visible = True
        Me.rev31.Visible = True
        Me.desc31.Visible = True
        Me.qtde31.Visible = True
        Me.tipo31.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 18
    End If
End Sub

Private Sub cod31_Change()
    If Me.cod31.Text <> "" Then
        Me.id32.Visible = True
        Me.cod32.Visible = True
        Me.rev32.Visible = True
        Me.desc32.Visible = True
        Me.qtde32.Visible = True
        Me.tipo32.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 36
    End If
End Sub

Private Sub cod32_Change()
    If Me.cod32.Text <> "" Then
        Me.id33.Visible = True
        Me.cod33.Visible = True
        Me.rev33.Visible = True
        Me.desc33.Visible = True
        Me.qtde33.Visible = True
        Me.tipo33.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 54
    End If
End Sub

Private Sub cod33_Change()
    If Me.cod33.Text <> "" Then
        Me.id34.Visible = True
        Me.cod34.Visible = True
        Me.rev34.Visible = True
        Me.desc34.Visible = True
        Me.qtde34.Visible = True
        Me.tipo34.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 72
    End If
End Sub

Private Sub cod34_Change()
    If Me.cod34.Text <> "" Then
        Me.id35.Visible = True
        Me.cod35.Visible = True
        Me.rev35.Visible = True
        Me.desc35.Visible = True
        Me.qtde35.Visible = True
        Me.tipo35.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 90
    End If
End Sub

Private Sub cod35_Change()
    If Me.cod35.Text <> "" Then
        Me.id36.Visible = True
        Me.cod36.Visible = True
        Me.rev36.Visible = True
        Me.desc36.Visible = True
        Me.qtde36.Visible = True
        Me.tipo36.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 108
    End If
End Sub

Private Sub cod36_Change()
    If Me.cod36.Text <> "" Then
        Me.id37.Visible = True
        Me.cod37.Visible = True
        Me.rev37.Visible = True
        Me.desc37.Visible = True
        Me.qtde37.Visible = True
        Me.tipo37.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 126
    End If
End Sub

Private Sub cod37_Change()
    If Me.cod37.Text <> "" Then
        Me.id38.Visible = True
        Me.cod38.Visible = True
        Me.rev38.Visible = True
        Me.desc38.Visible = True
        Me.qtde38.Visible = True
        Me.tipo38.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 144
    End If
End Sub

Private Sub cod38_Change()
    If Me.cod38.Text <> "" Then
        Me.id39.Visible = True
        Me.cod39.Visible = True
        Me.rev39.Visible = True
        Me.desc39.Visible = True
        Me.qtde39.Visible = True
        Me.tipo39.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 162
    End If
End Sub

Private Sub cod39_Change()
    If Me.cod39.Text <> "" Then
        Me.id40.Visible = True
        Me.cod40.Visible = True
        Me.rev40.Visible = True
        Me.desc40.Visible = True
        Me.qtde40.Visible = True
        Me.tipo40.Visible = True
        Me.frm_lista.ScrollHeight = 760
    End If
End Sub

Private Sub cod40_Change()
    If Me.cod40.Text <> "" Then
        Me.id41.Visible = True
        Me.cod41.Visible = True
        Me.rev41.Visible = True
        Me.desc41.Visible = True
        Me.qtde41.Visible = True
        Me.tipo41.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 18
    End If
End Sub

Private Sub cod41_Change()
    If Me.cod41.Text <> "" Then
        Me.id42.Visible = True
        Me.cod42.Visible = True
        Me.rev42.Visible = True
        Me.desc42.Visible = True
        Me.qtde42.Visible = True
        Me.tipo42.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 36
    End If
End Sub

Private Sub cod42_Change()
    If Me.cod42.Text <> "" Then
        Me.id43.Visible = True
        Me.cod43.Visible = True
        Me.rev43.Visible = True
        Me.desc43.Visible = True
        Me.qtde43.Visible = True
        Me.tipo43.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 54
    End If
End Sub

Private Sub cod43_Change()
    If Me.cod43.Text <> "" Then
        Me.id44.Visible = True
        Me.cod44.Visible = True
        Me.rev44.Visible = True
        Me.desc44.Visible = True
        Me.qtde44.Visible = True
        Me.tipo44.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 72
    End If
End Sub

Private Sub cod44_Change()
    If Me.cod44.Text <> "" Then
        Me.id45.Visible = True
        Me.cod45.Visible = True
        Me.rev45.Visible = True
        Me.desc45.Visible = True
        Me.qtde45.Visible = True
        Me.tipo45.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 90
    End If
End Sub

Private Sub cod45_Change()
    If Me.cod45.Text <> "" Then
        Me.id46.Visible = True
        Me.cod46.Visible = True
        Me.rev46.Visible = True
        Me.desc46.Visible = True
        Me.qtde46.Visible = True
        Me.tipo46.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 108
    End If
End Sub

Private Sub cod46_Change()
    If Me.cod46.Text <> "" Then
        Me.id47.Visible = True
        Me.cod47.Visible = True
        Me.rev47.Visible = True
        Me.desc47.Visible = True
        Me.qtde47.Visible = True
        Me.tipo47.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 126
    End If
End Sub

Private Sub cod47_Change()
    If Me.cod47.Text <> "" Then
        Me.id48.Visible = True
        Me.cod48.Visible = True
        Me.rev48.Visible = True
        Me.desc48.Visible = True
        Me.qtde48.Visible = True
        Me.tipo48.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 144
    End If
End Sub

Private Sub cod48_Change()
    If Me.cod48.Text <> "" Then
        Me.id49.Visible = True
        Me.cod49.Visible = True
        Me.rev49.Visible = True
        Me.desc49.Visible = True
        Me.qtde49.Visible = True
        Me.tipo49.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 162
    End If
End Sub

Private Sub cod49_Change()
    If Me.cod49.Text <> "" Then
        Me.id50.Visible = True
        Me.cod50.Visible = True
        Me.rev50.Visible = True
        Me.desc50.Visible = True
        Me.qtde50.Visible = True
        Me.tipo50.Visible = True
        Me.frm_lista.ScrollHeight = 940
    End If
End Sub

'############################################################################
Private Sub cod50_Change()
    If Me.cod50.Text <> "" Then
        Me.id51.Visible = True
        Me.cod51.Visible = True
        Me.rev51.Visible = True
        Me.desc51.Visible = True
        Me.qtde51.Visible = True
        Me.tipo51.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 18
    End If
End Sub

Private Sub cod51_Change()
    If Me.cod51.Text <> "" Then
        Me.id52.Visible = True
        Me.cod52.Visible = True
        Me.rev52.Visible = True
        Me.desc52.Visible = True
        Me.qtde52.Visible = True
        Me.tipo52.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 36
    End If
End Sub

Private Sub cod52_Change()
    If Me.cod52.Text <> "" Then
        Me.id53.Visible = True
        Me.cod53.Visible = True
        Me.rev53.Visible = True
        Me.desc53.Visible = True
        Me.qtde53.Visible = True
        Me.tipo53.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 54
    End If
End Sub

Private Sub cod53_Change()
    If Me.cod53.Text <> "" Then
        Me.id54.Visible = True
        Me.cod54.Visible = True
        Me.rev54.Visible = True
        Me.desc54.Visible = True
        Me.qtde54.Visible = True
        Me.tipo54.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 72
    End If
End Sub

Private Sub cod54_Change()
    If Me.cod54.Text <> "" Then
        Me.id55.Visible = True
        Me.cod55.Visible = True
        Me.rev55.Visible = True
        Me.desc55.Visible = True
        Me.qtde55.Visible = True
        Me.tipo55.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 90
    End If
End Sub

Private Sub cod55_Change()
    If Me.cod55.Text <> "" Then
        Me.id56.Visible = True
        Me.cod56.Visible = True
        Me.rev56.Visible = True
        Me.desc56.Visible = True
        Me.qtde56.Visible = True
        Me.tipo56.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 108
    End If
End Sub

Private Sub cod56_Change()
    If Me.cod56.Text <> "" Then
        Me.id57.Visible = True
        Me.cod57.Visible = True
        Me.rev57.Visible = True
        Me.desc57.Visible = True
        Me.qtde57.Visible = True
        Me.tipo57.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 126
    End If
End Sub

Private Sub cod57_Change()
    If Me.cod57.Text <> "" Then
        Me.id58.Visible = True
        Me.cod58.Visible = True
        Me.rev58.Visible = True
        Me.desc58.Visible = True
        Me.qtde58.Visible = True
        Me.tipo58.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 144
    End If
End Sub

Private Sub cod58_Change()
    If Me.cod58.Text <> "" Then
        Me.id59.Visible = True
        Me.cod59.Visible = True
        Me.rev59.Visible = True
        Me.desc59.Visible = True
        Me.qtde59.Visible = True
        Me.tipo59.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 162
    End If
End Sub

Private Sub cod59_Change()
    If Me.cod59.Text <> "" Then
        Me.id60.Visible = True
        Me.cod60.Visible = True
        Me.rev60.Visible = True
        Me.desc60.Visible = True
        Me.qtde60.Visible = True
        Me.tipo60.Visible = True
        Me.frm_lista.ScrollHeight = 1120
    End If
End Sub

'############################################################################
Private Sub cod60_Change()
    If Me.cod60.Text <> "" Then
        Me.id61.Visible = True
        Me.cod61.Visible = True
        Me.rev61.Visible = True
        Me.desc61.Visible = True
        Me.qtde61.Visible = True
        Me.tipo61.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 18
    End If
End Sub

Private Sub cod61_Change()
    If Me.cod61.Text <> "" Then
        Me.id62.Visible = True
        Me.cod62.Visible = True
        Me.rev62.Visible = True
        Me.desc62.Visible = True
        Me.qtde62.Visible = True
        Me.tipo62.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 36
    End If
End Sub

Private Sub cod62_Change()
    If Me.cod62.Text <> "" Then
        Me.id63.Visible = True
        Me.cod63.Visible = True
        Me.rev63.Visible = True
        Me.desc63.Visible = True
        Me.qtde63.Visible = True
        Me.tipo63.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 54
    End If
End Sub

Private Sub cod63_Change()
    If Me.cod63.Text <> "" Then
        Me.id64.Visible = True
        Me.cod64.Visible = True
        Me.rev64.Visible = True
        Me.desc64.Visible = True
        Me.qtde64.Visible = True
        Me.tipo64.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 72
    End If
End Sub

Private Sub cod64_Change()
    If Me.cod64.Text <> "" Then
        Me.id65.Visible = True
        Me.cod65.Visible = True
        Me.rev65.Visible = True
        Me.desc65.Visible = True
        Me.qtde65.Visible = True
        Me.tipo65.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 90
    End If
End Sub

Private Sub cod65_Change()
    If Me.cod65.Text <> "" Then
        Me.id66.Visible = True
        Me.cod66.Visible = True
        Me.rev66.Visible = True
        Me.desc66.Visible = True
        Me.qtde66.Visible = True
        Me.tipo66.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 108
    End If
End Sub

Private Sub cod66_Change()
    If Me.cod66.Text <> "" Then
        Me.id67.Visible = True
        Me.cod67.Visible = True
        Me.rev67.Visible = True
        Me.desc67.Visible = True
        Me.qtde67.Visible = True
        Me.tipo67.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 126
    End If
End Sub

Private Sub cod67_Change()
    If Me.cod67.Text <> "" Then
        Me.id68.Visible = True
        Me.cod68.Visible = True
        Me.rev68.Visible = True
        Me.desc68.Visible = True
        Me.qtde68.Visible = True
        Me.tipo68.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 144
    End If
End Sub

Private Sub cod68_Change()
    If Me.cod68.Text <> "" Then
        Me.id69.Visible = True
        Me.cod69.Visible = True
        Me.rev69.Visible = True
        Me.desc69.Visible = True
        Me.qtde69.Visible = True
        Me.tipo69.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 162
    End If
End Sub

Private Sub cod69_Change()
    If Me.cod69.Text <> "" Then
        Me.id70.Visible = True
        Me.cod70.Visible = True
        Me.rev70.Visible = True
        Me.desc70.Visible = True
        Me.qtde70.Visible = True
        Me.tipo70.Visible = True
        Me.frm_lista.ScrollHeight = 1300
    End If
End Sub

'############################################################################
Private Sub cod70_Change()
    If Me.cod70.Text <> "" Then
        Me.id71.Visible = True
        Me.cod71.Visible = True
        Me.rev71.Visible = True
        Me.desc71.Visible = True
        Me.qtde71.Visible = True
        Me.tipo71.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 18
    End If
End Sub

Private Sub cod71_Change()
    If Me.cod71.Text <> "" Then
        Me.id72.Visible = True
        Me.cod72.Visible = True
        Me.rev72.Visible = True
        Me.desc72.Visible = True
        Me.qtde72.Visible = True
        Me.tipo72.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 36
    End If
End Sub

Private Sub cod72_Change()
    If Me.cod72.Text <> "" Then
        Me.id73.Visible = True
        Me.cod73.Visible = True
        Me.rev73.Visible = True
        Me.desc73.Visible = True
        Me.qtde73.Visible = True
        Me.tipo73.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 54
    End If
End Sub

Private Sub cod73_Change()
    If Me.cod73.Text <> "" Then
        Me.id74.Visible = True
        Me.cod74.Visible = True
        Me.rev74.Visible = True
        Me.desc74.Visible = True
        Me.qtde74.Visible = True
        Me.tipo74.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 72
    End If
End Sub

Private Sub cod74_Change()
    If Me.cod74.Text <> "" Then
        Me.id75.Visible = True
        Me.cod75.Visible = True
        Me.rev75.Visible = True
        Me.desc75.Visible = True
        Me.qtde75.Visible = True
        Me.tipo75.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 90
    End If
End Sub

Private Sub cod75_Change()
    If Me.cod75.Text <> "" Then
        Me.id76.Visible = True
        Me.cod76.Visible = True
        Me.rev76.Visible = True
        Me.desc76.Visible = True
        Me.qtde76.Visible = True
        Me.tipo76.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 108
    End If
End Sub

Private Sub cod76_Change()
    If Me.cod76.Text <> "" Then
        Me.id77.Visible = True
        Me.cod77.Visible = True
        Me.rev77.Visible = True
        Me.desc77.Visible = True
        Me.qtde77.Visible = True
        Me.tipo77.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 126
    End If
End Sub

Private Sub cod77_Change()
    If Me.cod77.Text <> "" Then
        Me.id78.Visible = True
        Me.cod78.Visible = True
        Me.rev78.Visible = True
        Me.desc78.Visible = True
        Me.qtde78.Visible = True
        Me.tipo78.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 144
    End If
End Sub

Private Sub cod78_Change()
    If Me.cod78.Text <> "" Then
        Me.id79.Visible = True
        Me.cod79.Visible = True
        Me.rev79.Visible = True
        Me.desc79.Visible = True
        Me.qtde79.Visible = True
        Me.tipo79.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 162
    End If
End Sub

Private Sub cod79_Change()
    If Me.cod79.Text <> "" Then
        Me.id80.Visible = True
        Me.cod80.Visible = True
        Me.rev80.Visible = True
        Me.desc80.Visible = True
        Me.qtde80.Visible = True
        Me.tipo80.Visible = True
        Me.frm_lista.ScrollHeight = 1480
    End If
End Sub


'############################################################################
Private Sub cod80_Change()
    If Me.cod80.Text <> "" Then
        Me.id81.Visible = True
        Me.cod81.Visible = True
        Me.rev81.Visible = True
        Me.desc81.Visible = True
        Me.qtde81.Visible = True
        Me.tipo81.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 18
    End If
End Sub

Private Sub cod81_Change()
    If Me.cod81.Text <> "" Then
        Me.id82.Visible = True
        Me.cod82.Visible = True
        Me.rev82.Visible = True
        Me.desc82.Visible = True
        Me.qtde82.Visible = True
        Me.tipo82.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 36
    End If
End Sub

Private Sub cod82_Change()
    If Me.cod82.Text <> "" Then
        Me.id83.Visible = True
        Me.cod83.Visible = True
        Me.rev83.Visible = True
        Me.desc83.Visible = True
        Me.qtde83.Visible = True
        Me.tipo83.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 54
    End If
End Sub

Private Sub cod83_Change()
    If Me.cod83.Text <> "" Then
        Me.id84.Visible = True
        Me.cod84.Visible = True
        Me.rev84.Visible = True
        Me.desc84.Visible = True
        Me.qtde84.Visible = True
        Me.tipo84.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 72
    End If
End Sub

Private Sub cod84_Change()
    If Me.cod84.Text <> "" Then
        Me.id85.Visible = True
        Me.cod85.Visible = True
        Me.rev85.Visible = True
        Me.desc85.Visible = True
        Me.qtde85.Visible = True
        Me.tipo85.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 90
    End If
End Sub

Private Sub cod85_Change()
    If Me.cod85.Text <> "" Then
        Me.id86.Visible = True
        Me.cod86.Visible = True
        Me.rev86.Visible = True
        Me.desc86.Visible = True
        Me.qtde86.Visible = True
        Me.tipo86.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 108
    End If
End Sub

Private Sub cod86_Change()
    If Me.cod86.Text <> "" Then
        Me.id87.Visible = True
        Me.cod87.Visible = True
        Me.rev87.Visible = True
        Me.desc87.Visible = True
        Me.qtde87.Visible = True
        Me.tipo87.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 126
    End If
End Sub

Private Sub cod87_Change()
    If Me.cod87.Text <> "" Then
        Me.id88.Visible = True
        Me.cod88.Visible = True
        Me.rev88.Visible = True
        Me.desc88.Visible = True
        Me.qtde88.Visible = True
        Me.tipo88.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 144
    End If
End Sub

Private Sub cod88_Change()
    If Me.cod88.Text <> "" Then
        Me.id89.Visible = True
        Me.cod89.Visible = True
        Me.rev89.Visible = True
        Me.desc89.Visible = True
        Me.qtde89.Visible = True
        Me.tipo89.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 162
    End If
End Sub

Private Sub cod89_Change()
    If Me.cod89.Text <> "" Then
        Me.id90.Visible = True
        Me.cod90.Visible = True
        Me.rev90.Visible = True
        Me.desc90.Visible = True
        Me.qtde90.Visible = True
        Me.tipo90.Visible = True
        Me.frm_lista.ScrollHeight = 1660
    End If
End Sub

'############################################################################
Private Sub cod90_Change()
    If Me.cod90.Text <> "" Then
        Me.id91.Visible = True
        Me.cod91.Visible = True
        Me.rev91.Visible = True
        Me.desc91.Visible = True
        Me.qtde91.Visible = True
        Me.tipo91.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 18
    End If
End Sub

Private Sub cod91_Change()
    If Me.cod91.Text <> "" Then
        Me.id92.Visible = True
        Me.cod92.Visible = True
        Me.rev92.Visible = True
        Me.desc92.Visible = True
        Me.qtde92.Visible = True
        Me.tipo92.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 36
    End If
End Sub

Private Sub cod92_Change()
    If Me.cod92.Text <> "" Then
        Me.id93.Visible = True
        Me.cod93.Visible = True
        Me.rev93.Visible = True
        Me.desc93.Visible = True
        Me.qtde93.Visible = True
        Me.tipo93.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 54
    End If
End Sub

Private Sub cod93_Change()
    If Me.cod93.Text <> "" Then
        Me.id94.Visible = True
        Me.cod94.Visible = True
        Me.rev94.Visible = True
        Me.desc94.Visible = True
        Me.qtde94.Visible = True
        Me.tipo94.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 72
    End If
End Sub

Private Sub cod94_Change()
    If Me.cod94.Text <> "" Then
        Me.id95.Visible = True
        Me.cod95.Visible = True
        Me.rev95.Visible = True
        Me.desc95.Visible = True
        Me.qtde95.Visible = True
        Me.tipo95.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 90
    End If
End Sub

Private Sub cod95_Change()
    If Me.cod95.Text <> "" Then
        Me.id96.Visible = True
        Me.cod96.Visible = True
        Me.rev96.Visible = True
        Me.desc96.Visible = True
        Me.qtde96.Visible = True
        Me.tipo96.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 108
    End If
End Sub

Private Sub cod96_Change()
    If Me.cod96.Text <> "" Then
        Me.id97.Visible = True
        Me.cod97.Visible = True
        Me.rev97.Visible = True
        Me.desc97.Visible = True
        Me.qtde97.Visible = True
        Me.tipo97.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 126
    End If
End Sub

Private Sub cod97_Change()
    If Me.cod97.Text <> "" Then
        Me.id98.Visible = True
        Me.cod98.Visible = True
        Me.rev98.Visible = True
        Me.desc98.Visible = True
        Me.qtde98.Visible = True
        Me.tipo98.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 144
    End If
End Sub

Private Sub cod98_Change()
    If Me.cod98.Text <> "" Then
        Me.id99.Visible = True
        Me.cod99.Visible = True
        Me.rev99.Visible = True
        Me.desc99.Visible = True
        Me.qtde99.Visible = True
        Me.tipo99.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 162
    End If
End Sub

Private Sub cod99_Change()
    If Me.cod99.Text <> "" Then
        Me.id100.Visible = True
        Me.cod100.Visible = True
        Me.rev100.Visible = True
        Me.desc100.Visible = True
        Me.qtde100.Visible = True
        Me.tipo100.Visible = True
        Me.frm_lista.ScrollHeight = 1840
    End If
End Sub


Private Sub UserForm_Initialize()
For i = 1 To 100

Me.Controls("cod" & i).TabIndex = (i * 5) - 5
Me.Controls("rev" & i).TabIndex = (i * 5) - 4
Me.Controls("desc" & i).TabIndex = (i * 5) - 3
Me.Controls("qtde" & i).TabIndex = (i * 5) - 2
Me.Controls("tipo" & i).TabIndex = (i * 5) - 1

Next i
End Sub
```

---

## 5. VBA — `frmaut` / `frmsol` — `btn_bom_novo_Click` (só o procedimento que mudou)

Só o caminho `.bom` muda (`F:`→`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE`). Os módulos inteiros já estão em
`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\{frmaut,frmsol}.txt`.

### frmaut — ANTES
```vb
Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "F:\eng_ind\PROJETOS_Controle\Controle\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub
```
### frmaut — DEPOIS
```vb
Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub
```

### frmsol — ANTES
```vb
Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "F:\eng_ind\PROJETOS_Controle\Controle\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub
```
### frmsol — DEPOIS
```vb
Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub
```

