# Imagem do projeto — Código 100% (ANTES / DEPOIS completos)

Para **cada** artefato alterado: o **ANTES 100%** e o **DEPOIS 100%** — módulos
VBA inteiros e o método PHP inteiro, não só os trechos. Visão geral em
[imagem-projeto.md](imagem-projeto.md).

Módulos prontos pra colar também em arquivo: `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\*.txt`
(DEPOIS) e `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_original\*.txt` (ANTES).

> **Escopo:** só a fatia *imagem*. No `Funcoes`, **apenas o `AbreJPG`** virou `D:`;
> `AbreXLS/AbreZIP/AbrePDF/OpenTXTDialog` continuam `ChDrive("K")` (fatias DXF/PDF/BOM).

| Artefato | Mudou |
|---|---|
| `routes.php` | +1 rota (`uploadImagemVba`) |
| `storeImagemProjeto` | +1 chamada `copiarImagemParaAccess` |
| `DesenvolvimentoController` (novos) | `uploadImagemVba`, `copiarImagemParaAccess` |
| VBA `Funcoes` | `MyConn` (×2), `AbreJPG`, +3 funções HTTP |
| VBA `frmaut` | `btnLoadImage`, `lbl_abrir` |
| VBA `M_Abre_UF` | `Carrega_campos` (caminho da imagem) |

---

## 1. PHP — `src/routes/routes.php` (bloco de desenvolvimento)

### ANTES
```php
Route::post('/dispositivos/desenvolvimento/imagem-projeto/{ref}/store', DesenvolvimentoController::class, 'storeImagemProjeto')
    ->name('dispositivos.desenvolvimento.imagemProjeto.store')
    ->whereint(['ref']);
```

### DEPOIS
```php
Route::post('/dispositivos/desenvolvimento/imagem-projeto/{ref}/store', DesenvolvimentoController::class, 'storeImagemProjeto')
    ->name('dispositivos.desenvolvimento.imagemProjeto.store')
    ->whereint(['ref']);

// Access -> Web: recebe a imagem do projeto (frmaut.btnLoadImage) em binario cru.
// Parametros via query string: ?ref=NNN&nome=arquivo.jpg
Route::post('/dispositivos/desenvolvimento/uploadImagemVba', DesenvolvimentoController::class, 'uploadImagemVba')
    ->name('dispositivos.desenvolvimento.uploadImagemVba');
```

---

## 2. PHP — `DesenvolvimentoController::storeImagemProjeto` (método inteiro)

Única mudança: a chamada `copiarImagemParaAccess` após o commit (Web → Access).

### ANTES (método 100%)
```php
    public function storeImagemProjeto(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível alterar a imagem quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        if (empty($_FILES['imagem_projeto']) || !$this->arquivoValido($_FILES['imagem_projeto'])) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione uma imagem válida.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $arquivosCriadosFisicamente = [];

        try {
            $this->validarExtensaoArquivo($_FILES['imagem_projeto'], ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'], 'imagem');

            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da imagem.");
            }

            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO');

            $arquivoSalvo = $this->salvarArquivoSolicitacao(
                $saveCarga['id'],
                $ref,
                $_FILES['imagem_projeto'],
                'IMAGEM_PROJETO',
                "{$baseUploadDir}/imagem",
                "{$baseUploadPath}/imagem",
                $usuarioLogado
            );

            $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Imagem de visualização do projeto atualizada.',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Imagem atualizada com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar imagem da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao atualizar a imagem.");
        }
    }
```

### DEPOIS (método 100%)
```php
    public function storeImagemProjeto(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível alterar a imagem quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        if (empty($_FILES['imagem_projeto']) || !$this->arquivoValido($_FILES['imagem_projeto'])) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione uma imagem válida.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $arquivosCriadosFisicamente = [];

        try {
            $this->validarExtensaoArquivo($_FILES['imagem_projeto'], ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'], 'imagem');

            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da imagem.");
            }

            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO');

            $arquivoSalvo = $this->salvarArquivoSolicitacao(
                $saveCarga['id'],
                $ref,
                $_FILES['imagem_projeto'],
                'IMAGEM_PROJETO',
                "{$baseUploadDir}/imagem",
                "{$baseUploadPath}/imagem",
                $usuarioLogado
            );

            $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Imagem de visualização do projeto atualizada.',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            // Web -> Access: espelha a imagem na pasta mapeada (.img_sl/SL{ref}.jpg)
            $this->copiarImagemParaAccess($ref, $arquivoSalvo['caminho_fisico']);

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Imagem atualizada com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar imagem da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao atualizar a imagem.");
        }
    }
```

---

## 3. PHP — métodos NOVOS no `DesenvolvimentoController`

Inseridos após `storeImagemProjeto` (antes de `storePacoteDxf`). **ANTES: não existiam.**

### DEPOIS (100%)
```php
    /**
     * Access -> Web: recebe a imagem do projeto enviada pelo VBA
     * (frmaut.btnLoadImage) como corpo binário cru (php://input) e a registra
     * como IMAGEM_PROJETO usando a MESMA estrutura do storeImagemProjeto:
     * cria a carga, grava o arquivo em .../imagem/, registra em
     * solicitacao_anexo_arquivos e adiciona ao histórico. Substitui a imagem
     * anterior, se houver. SEM trava de status — espelha o que o Access já fez.
     * Parâmetros via query string: ?ref=NNN&nome=arquivo.jpg
     */
    public function uploadImagemVba()
    {
        $ref  = (int) (Request::query('ref') ?? 0);
        $nome = Request::query('nome') ?: ('SL' . $ref . '.jpg');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado = 'ACCESS';

        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da imagem.");
            }

            // Remove o registro da imagem anterior (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO');

            // Grava a partir dos BYTES (não há $_FILES no POST do VBA, então não
            // dá pra usar salvarArquivoSolicitacao/move_uploaded_file)
            $diretorioFisico   = "{$baseUploadDir}/imagem";
            $diretorioRelativo = "{$baseUploadPath}/imagem";
            if (!is_dir($diretorioFisico)) {
                mkdir($diretorioFisico, 0777, true);
            }

            $extensao   = strtolower(pathinfo($nome, PATHINFO_EXTENSION)) ?: 'jpg';
            $nomeSeguro = $this->gerarNomeArquivoSeguro((string) $ref, 'IMAGEM_PROJETO', $extensao);

            $caminhoFisico   = "{$diretorioFisico}/{$nomeSeguro}";
            $caminhoRelativo = "{$diretorioRelativo}/{$nomeSeguro}";

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar a imagem.");
            }
            $caminhoFisicoNovo = $caminhoFisico;

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'IMAGEM_PROJETO',
                'codigo'        => null,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'image/jpeg',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);

            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro da imagem.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Imagem de visualização do projeto atualizada (Access).',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }

            error_log("Erro no uploadImagemVba {$ref}: " . $e->getMessage());

            return Json::return(['error' => 'falha ao salvar imagem'], 500);
        }
    }

    /**
     * Web -> Access: copia a imagem salva pela web para a pasta mapeada que o
     * Access enxerga, com o nome que o VBA espera: .img_sl/SL{ref}.jpg
     * (ref com 4 dígitos — ver Carrega_campos/frmsol.img_sl no VBA).
     * Espelho do copiarAnexosParaAccess do SolicitacaoController.
     */
    private function copiarImagemParaAccess($ref, string $caminhoFisico): void
    {
        if (empty($caminhoFisico) || !is_file($caminhoFisico)) {
            return;
        }

        $base = rtrim($_ENV['APP_ACCESS_DIR'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') {
            return; // sem pasta mapeada configurada -> não faz nada
        }

        $imgDir = $base . '/.img_sl';
        if (!is_dir($imgDir)) {
            @mkdir($imgDir, 0777, true);
        }

        $nomeAccess = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT) . '.jpg'; // ex.: SL4001.jpg
        @copy($caminhoFisico, $imgDir . '/' . $nomeAccess);
    }
```

---

## 4. VBA — módulo `Funcoes` (inteiro)

### ANTES (100%)
```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "F:\eng_ind\PROJETOS_Controle\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "F:\eng_ind\PROJETOS_Controle\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ' ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("D")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ChDir ("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
'==================== INTEGRACAO COM A WEB (MySQL) ====================
' Base da aplicacao web (mesma do workbook de Solicitacao)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Codifica um valor para querystring (UTF-8)
Public Function enc(ByVal v As Variant) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Access -> Web: envia a imagem do projeto (bytes) para a rota uploadImagemVba.
' ref = numero da SL (so o numero, sem "SL"); caminhoArquivo = .jpg local.
Public Function enviarImagemParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarImagemParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "Imagem nao encontrada para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadImagemVba?ref=" & ref & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarImagemParaMySQL = True
    Else
        MsgBox "Falha ao enviar imagem (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar imagem para a web:" & vbCrLf & Err.Description, vbCritical
End Function

```

---

## 5. VBA — módulo `M_Abre_UF` (inteiro)

Mudou só 1 linha em `Carrega_campos` (caminho da imagem).

### ANTES (100%)
```vb
Attribute VB_Name = "M_Abre_UF"
Option Explicit

Sub Carrega_campos(ref)
Dim SQL             As String
Dim SQLz            As String
Dim ArrRes          As Variant
Dim a               As Integer
Dim ArrDesc         As Variant
Dim lib_st          As String
Dim caminho         As String


'Query de consulta para formulário
SQL = "SELECT Descricao, Data_Solicitacao, Solicitante, Aplicacao, Vagao, Lote, Historico,"
SQL = SQL & "Conceito_St, Conceito_Fim, "
SQL = SQL & "Det_St, Det_Fim, "
SQL = SQL & "Liberacao_St, Liberacao_Data, Aq_St, Aq_Data, Corte_St, Corte_Data, Exec_St, Exec_Data, Tryout_St, Tryout_Data, Cod_Z, Classe, "
SQL = SQL & "Tempo_Modelo, Tempo_Fila_Det, Tempo_Det, Tempo_Fila_Lib, Conceito_P, Conceito_Ini, Liberacao_Data, Liberacao_St, Executor_EI, Data_Inicio_EI, Data_Fim_EI, Status_EI "
SQL = SQL & " FROM Fila WHERE Ref = " & ref & ";"

ArrRes = resQuery(SQL)

If Not IsEmpty(ArrRes) Then
        a = 0
        frmsol.lbl_ref.Caption = "SL" & Format(ref, "0000")
        
        frmsol.lbl_desc = ArrRes(0, a)
        
        If IsNull(ArrRes(1, a)) Then frmsol.lbl_data = "" Else frmsol.lbl_data = ArrRes(1, a)
        If IsNull(ArrRes(2, a)) Then frmsol.lbl_solic = "" Else frmsol.lbl_solic = ArrRes(2, a)
        
        If IsNull(ArrRes(3, a)) Then frmsol.lbl_estagio = "" Else frmsol.lbl_estagio = ArrRes(3, a)
        If IsNull(ArrRes(4, a)) Then frmsol.lbl_vg = "" Else frmsol.lbl_vg = ArrRes(4, a)
        If IsNull(ArrRes(5, a)) Then frmsol.lbl_lote = "" Else frmsol.lbl_lote = ArrRes(5, a)
        If IsNull(ArrRes(6, a)) Then frmsol.txt_historico.Text = "" Else frmsol.txt_historico.Text = ArrRes(6, a)
        
        
        If IsNull(ArrRes(7, a)) Then frmsol.proj_st.Caption = "" Else frmsol.proj_st.Caption = ArrRes(7, a)
        If IsNull(ArrRes(8, a)) Then frmsol.proj_data.Caption = "" Else frmsol.proj_data.Caption = Format(ArrRes(8, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(8, a)) Then frmsol.dt_inicio.Caption = "" Else frmsol.dt_inicio.Caption = Format(ArrRes(8, a), "DD/MM/YY")
        
        
        If IsNull(ArrRes(9, a)) Then frmsol.det_st.Caption = "" Else frmsol.det_st.Caption = ArrRes(9, a)
        If IsNull(ArrRes(10, a)) Then frmsol.det_data.Caption = "" Else frmsol.det_data.Caption = Format(ArrRes(10, a), "DD.MM.YY | hh:mm")
        
        
        If IsNull(ArrRes(11, a)) Then frmsol.lib_st.Caption = "" Else frmsol.lib_st.Caption = ArrRes(11, a)
        If IsNull(ArrRes(12, a)) Then frmsol.lib_data.Caption = "" Else frmsol.lib_data.Caption = Format(ArrRes(12, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(12, a)) Then frmsol.dt_fim.Caption = "" Else frmsol.dt_fim.Caption = Format(ArrRes(12, a), "DD/MM/YY")
        
        If IsNull(ArrRes(13, a)) Then frmsol.aq_st.Caption = "" Else frmsol.aq_st.Caption = ArrRes(13, a)
        If IsNull(ArrRes(14, a)) Then frmsol.aq_data.Caption = "" Else frmsol.aq_data.Caption = Format(ArrRes(14, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(15, a)) Then frmsol.corte_st.Caption = "" Else frmsol.corte_st.Caption = ArrRes(15, a)
        If IsNull(ArrRes(16, a)) Then frmsol.corte_data.Caption = "" Else frmsol.corte_data.Caption = Format(ArrRes(16, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(17, a)) Then frmsol.exec_st.Caption = "" Else frmsol.exec_st.Caption = ArrRes(17, a)
        If IsNull(ArrRes(18, a)) Then frmsol.exec_data.Caption = "" Else frmsol.exec_data.Caption = Format(ArrRes(18, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(19, a)) Then frmsol.tryout_st.Caption = "" Else frmsol.tryout_st.Caption = ArrRes(19, a)
        If IsNull(ArrRes(20, a)) Then frmsol.tryout_data.Caption = "" Else frmsol.tryout_data.Caption = Format(ArrRes(20, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(21, a)) Then
            frmsol.lbl_codz.Caption = ""
            frmsol.lbl_cod_z.Caption = ""
        Else
            frmsol.lbl_cod_z.Caption = ArrRes(21, a)
            frmsol.lbl_codz.Caption = ArrRes(21, a)
            If ArrRes(21, a) <> "" Then
                SQLz = "SELECT Descricao FROM Projetos WHERE Controle = " & Replace(ArrRes(21, a), "Z", "") & ";"
                ArrDesc = resQuery(SQLz)
                If Not IsNull(ArrDesc(0, 0)) Then frmsol.lbl_descz.Caption = ArrDesc(0, 0)
            End If
        End If
              
        
        If IsNull(ArrRes(22, a)) Then frmsol.lbl_classe.Caption = "" Else frmsol.lbl_classe.Caption = ArrRes(22, a)
        
        'Horas
        If IsNull(ArrRes(23, a)) Then frmsol.lbl_proj_h.Caption = "" Else frmsol.lbl_proj_h.Caption = Format(ArrRes(23, a), "0.0h")
        If IsNull(ArrRes(24, a)) Then frmsol.lbl_fila_1.Caption = "" Else frmsol.lbl_fila_1.Caption = Format(ArrRes(24, a), "0.0h")
        If IsNull(ArrRes(25, a)) Then frmsol.lbl_det_h.Caption = "" Else frmsol.lbl_det_h.Caption = Format(ArrRes(25, a), "0.0h")
        If IsNull(ArrRes(26, a)) Then frmsol.lbl_fila_2.Caption = "" Else frmsol.lbl_fila_2.Caption = Format(ArrRes(26, a), "0.0h")
        
        If IsNull(ArrRes(27, a)) Then frmsol.lbl_projetista.Caption = "" Else frmsol.lbl_projetista.Caption = ArrRes(27, a)
        If IsNull(ArrRes(28, a)) Then frmsol.lbl_ini_proj.Caption = "" Else frmsol.lbl_ini_proj.Caption = ArrRes(28, a)
        If IsNull(ArrRes(29, a)) Then frmsol.lbl_fim_proj.Caption = "" Else frmsol.lbl_fim_proj.Caption = ArrRes(29, a)
        If IsNull(ArrRes(30, a)) Then frmsol.lbl_status_proj.Caption = "" Else frmsol.lbl_status_proj.Caption = ArrRes(30, a)
        
        If IsNull(ArrRes(31, a)) Then frmsol.lbl_executor.Caption = "" Else frmsol.lbl_executor.Caption = ArrRes(31, a)
        If IsNull(ArrRes(32, a)) Then frmsol.lbl_ini_exec.Caption = "" Else frmsol.lbl_ini_exec.Caption = ArrRes(32, a)
        If IsNull(ArrRes(33, a)) Then frmsol.lbl_fim_exec.Caption = "" Else frmsol.lbl_fim_exec.Caption = ArrRes(33, a)
        If IsNull(ArrRes(34, a)) Then frmsol.lbl_status_exec.Caption = "" Else frmsol.lbl_status_exec.Caption = ArrRes(34, a)
        
        
        If lib_st = "[VERIFICAÇÃO]" Then frmsol.btnLimparComprados.Enabled = True
        
        On Error Resume Next
        caminho = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\SL" & Format(ref, "0000") & ".jpg"
        On Error Resume Next
        frmsol.img_sl.Picture = LoadPicture(caminho)
        
        
End If

End Sub

Sub Formata_Campos()

    Dim azul                As String
    Dim vermelho            As String
    Dim vermelho_escuro     As String
    Dim azul_claro          As String
    Dim amarelo             As String
    Dim cinza_escuro        As String
    Dim cinza_claro         As String
    Dim verde               As String

    
    
        'Cores
        azul = &HC59452
        vermelho = &H8080FF
        vermelho_escuro = &HC0&
        azul_claro = &HFF8080
        amarelo = &H8080&
        cinza_escuro = &H808080
        cinza_claro = &HC0C0C0
        verde = &H8000&

        'Ajustar cor das Labels
        If frmsol.proj_st.Caption = "OK" Then frmsol.proj_st.BackColor = verde
        If frmsol.proj_st.Caption = "PENDENTE" Then frmsol.proj_st.BackColor = vermelho
        If frmsol.proj_st.Caption = "CANCELADO" Then frmsol.proj_st.BackColor = cinza_claro
        If frmsol.proj_st.Caption = "PAUSADO" Then frmsol.proj_st.BackColor = cinza_escuro
        If frmsol.proj_st.Caption = "EM ANÁLISE" Then frmsol.proj_st.BackColor = azul
        If frmsol.proj_st.Caption = "MODELO" Then frmsol.proj_st.BackColor = amarelo
        If frmsol.proj_st.Caption = "BACKLOG" Then frmsol.proj_st.BackColor = azul_claro
        
        If frmsol.det_st.Caption = "OK" Then frmsol.det_st.BackColor = verde
        If frmsol.det_st.Caption = "PENDENTE" Then frmsol.det_st.BackColor = vermelho
        If frmsol.det_st.Caption = "CANCELADO" Then frmsol.det_st.BackColor = cinza_claro
        
        If frmsol.lib_st.Caption = "OK" Then frmsol.lib_st.BackColor = verde
        If frmsol.lib_st.Caption = "PENDENTE" Then frmsol.lib_st.BackColor = vermelho
        If frmsol.lib_st.Caption = "CANCELADO" Then frmsol.lib_st.BackColor = cinza_claro
        
        If frmsol.aq_st.Caption = "OK" Then frmsol.aq_st.BackColor = verde
        If frmsol.aq_st.Caption = "PENDENTE" Then frmsol.aq_st.BackColor = vermelho
        If frmsol.aq_st.Caption = "REALIZADO" Then frmsol.aq_st.BackColor = amarelo
        If frmsol.aq_st.Caption = "CANCELADO" Then frmsol.aq_st.BackColor = cinza_claro

        If frmsol.corte_st.Caption = "FINALIZADO" Then frmsol.corte_st.BackColor = verde
        If frmsol.corte_st.Caption = "PARADO" Then frmsol.corte_st.BackColor = vermelho_escuro
        If frmsol.corte_st.Caption = "ANDAMENTO" Then frmsol.corte_st.BackColor = azul
        If frmsol.corte_st.Caption = "CANCELADO" Then frmsol.corte_st.BackColor = cinza_claro
        
        If frmsol.exec_st.Caption = "FINALIZADO" Then frmsol.exec_st.BackColor = verde
        If frmsol.exec_st.Caption = "PARADO" Then frmsol.exec_st.BackColor = vermelho_escuro
        If frmsol.exec_st.Caption = "ANDAMENTO" Then frmsol.exec_st.BackColor = azul
        If frmsol.exec_st.Caption = "CANCELADO" Then frmsol.exec_st.BackColor = cinza_claro
        
        If frmsol.tryout_st.Caption = "OK" Then frmsol.tryout_st.BackColor = verde
        If frmsol.tryout_st.Caption = "PENDENTE" Then frmsol.tryout_st.BackColor = vermelho
        If frmsol.tryout_st.Caption = "CANCELADO" Then frmsol.tryout_st.BackColor = cinza_claro
End Sub

Sub Carrega_DFX(cod_sl)
    Dim SQL             As String
    Dim ArrRes          As Variant
    Dim ArrRes_DXF      As Variant
    Dim tam_res         As Integer
    Dim i               As Integer
    Dim linha           As Variant
    Dim Colunas         As Integer
    Dim Linhas          As Integer
    Dim sts             As Variant
    Dim X               As Integer
    
    
            frmsol.dxf_lst.Gridlines = True
            frmsol.dxf_lst.View = lvwReport
            frmsol.dxf_lst.FullRowSelect = False
            frmsol.dxf_lst.ColumnHeaders.Clear
            frmsol.dxf_lst.ColumnHeaders.Add Text:="CTRL", Width:=40
            frmsol.dxf_lst.ColumnHeaders.Add Text:="DESCRIÇÃO", Width:=290, Alignment:=0
            frmsol.dxf_lst.ColumnHeaders.Add Text:="PRIORIDADE", Width:=60, Alignment:=0
            frmsol.dxf_lst.ColumnHeaders.Add Text:="STATUS CORTE", Width:=70, Alignment:=0
            
            SQL = "SELECT Controle, Descricao, Prioridade, Status FROM DXF_Control WHERE Solicitacao = '" & cod_sl & "' ORDER BY Controle DESC;"

            ArrRes_DXF = resQuery(SQL)

            If Not IsEmpty(ArrRes_DXF) Then
                tam_res = UBound(ArrRes_DXF, 2)
                frmsol.dxf_lst.ListItems.Clear
                For i = 0 To tam_res
                    Set linha = frmsol.dxf_lst.ListItems.Add(Text:="DX" & Format(ArrRes_DXF(0, i), "0000")) 'Controle
                    If Not IsNull(ArrRes_DXF(1, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(1, i) Else linha.ListSubItems.Add Text:="" 'Descrição
                    If Not IsNull(ArrRes_DXF(2, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(2, i) Else linha.ListSubItems.Add Text:="" 'Prioridade
                    If Not IsNull(ArrRes_DXF(3, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(3, i) Else linha.ListSubItems.Add Text:="" 'Status
                Next i
            End If
            
            Colunas = frmsol.dxf_lst.ColumnHeaders.Count
            Linhas = frmsol.dxf_lst.ListItems.Count
    
            For i = 1 To Linhas
            sts = frmsol.dxf_lst.ListItems(i).ListSubItems(2)
            If sts = "CONCLUÍDO" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(35, 142, 35)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(35, 142, 35)
                Next X
            End If
            
            If sts = "99-Cancelado" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(150, 150, 150)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(150, 150, 150)
                Next X
            End If

            If sts <> "CONCLUÍDO" And sts <> "99-Cancelado" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(255, 0, 0)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(255, 0, 0)
                Next X
            End If

    Next i
End Sub

Sub carrega_pdf(cod_sl)
    Dim SQL                 As String
    Dim ArrRes_PDF          As Variant
    Dim tam_res             As Integer
    Dim i                   As Integer
         
            SQL = "SELECT Codigo FROM PDF_Control WHERE Solicitacao = '" & cod_sl & "' ORDER BY Codigo;"

            ArrRes_PDF = resQuery(SQL)

            If Not IsEmpty(ArrRes_PDF) Then
                tam_res = UBound(ArrRes_PDF, 2)
                frmsol.pdf_lst.Clear
                For i = 0 To tam_res
                    frmsol.pdf_lst.AddItem (ArrRes_PDF(0, i))
                Next i
            End If
End Sub
Sub Carrega_BOM(cod_sl)
    Dim SQL                 As String
    Dim ArrRes_BOM          As Variant
    Dim tam_res             As Integer
    Dim i                   As Integer
    Dim linha               As Variant
    Dim Colunas             As Integer
    Dim Linhas              As Integer
    Dim sts                 As String
    Dim cod                 As String
    Dim OC                  As String
    Dim X                   As Integer
    Dim caminho             As String

            frmsol.bom_lst.Gridlines = True
            frmsol.bom_lst.View = lvwReport
            frmsol.bom_lst.FullRowSelect = False
            frmsol.bom_lst.ColumnHeaders.Clear
            frmsol.bom_lst.ColumnHeaders.Add Text:="", Width:=1
            frmsol.bom_lst.ColumnHeaders.Add Text:="CÓDIGO", Width:=70
            frmsol.bom_lst.ColumnHeaders.Add Text:="REV", Width:=25, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="DESCRIÇÃO", Width:=200
            frmsol.bom_lst.ColumnHeaders.Add Text:="QTD.", Width:=40, Alignment:=1
            frmsol.bom_lst.ColumnHeaders.Add Text:="TIPO", Width:=85, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="Nº OC", Width:=50, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="STATUS", Width:=70, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="PEDIDO", Width:=50, Alignment:=2
            
            SQL = "SELECT B.Controle, B.Codigo, B.Revisao, B.Descricao, B.Qtde, B.Tipo, B.OC, Aq.Status, Aq.Pedido FROM BOM_Control B LEFT OUTER JOIN OC_Control Aq ON B.OC = Aq.OC WHERE B.Solicitacao = '" & cod_sl & "';"
            
            ArrRes_BOM = resQuery(SQL)

            If Not IsEmpty(ArrRes_BOM) Then
                tam_res = UBound(ArrRes_BOM, 2)
                frmsol.bom_lst.ListItems.Clear
                For i = 0 To tam_res
                    Set linha = frmsol.bom_lst.ListItems.Add(Text:=ArrRes_BOM(0, i)) 'Controle
                    If Not IsNull(ArrRes_BOM(1, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(1, i) Else linha.ListSubItems.Add Text:="" 'Codigo
                    If Not IsNull(ArrRes_BOM(2, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(2, i) Else linha.ListSubItems.Add Text:="" 'Revisao
                    If Not IsNull(ArrRes_BOM(3, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(3, i) Else linha.ListSubItems.Add Text:="" 'Descricao
                    If Not IsNull(ArrRes_BOM(4, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(4, i) Else linha.ListSubItems.Add Text:="" 'Qtde
                    If Not IsNull(ArrRes_BOM(5, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(5, i) Else linha.ListSubItems.Add Text:="" 'Tipo
                    If Not IsNull(ArrRes_BOM(6, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(6, i) Else linha.ListSubItems.Add Text:="" 'OC
                    If Not IsNull(ArrRes_BOM(7, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(7, i) Else linha.ListSubItems.Add Text:="" 'Status
                    If Not IsNull(ArrRes_BOM(8, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(8, i) Else linha.ListSubItems.Add Text:="" 'Pedido
                Next i
            End If

            Colunas = frmsol.bom_lst.ColumnHeaders.Count
            Linhas = frmsol.bom_lst.ListItems.Count
    
            For i = 1 To Linhas

            sts = frmsol.bom_lst.ListItems(i).ListSubItems(7)
            cod = frmsol.bom_lst.ListItems(i).ListSubItems(1)
            OC = frmsol.bom_lst.ListItems(i).ListSubItems(6)
      
            If sts = "LIQUIDADA" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H8000&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H8000&
                Next X
            End If

            If sts = "PENDENTE" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF&
                Next X
            End If

            If sts = "REALIZADA" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H80FF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H80FF&
                Next X
            End If

            If sts = "EM ABERTO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF0000
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF0000
                Next X
            End If
        
            If sts = "COTAÇÃO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HC000C0
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HC000C0
                Next X
            End If
       
            If sts = "CANCELADO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H808080
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H808080
                Next X
            End If
       
            If cod = "SIDERÚRGICO" And OC <> "" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF&
                Next X
            End If
            Next i
        

        
        
End Sub

Sub carregaReqs(codSL)
    Dim SQL                 As String
    Dim ArrRes              As Variant
    Dim requisitos          As String
    Dim chkReq               As String
    Dim StConceito          As String
    Dim vtReq               As Variant
    Dim Reqs                As Variant
    Dim a                   As Integer
    
    codSL = Replace(codSL, "SL", "")
    
    SQL = "SELECT Requisitos, CKReq, Conceito_St FROM Fila WHERE Ref = " & codSL & ";"
    ArrRes = resQuery(SQL)
    If Not IsEmpty(ArrRes) Then
        If Not IsNull(ArrRes(0, 0)) Then requisitos = ArrRes(0, 0)
        If Not IsNull(ArrRes(1, 0)) Then chkReq = ArrRes(1, 0)
        If Not IsNull(ArrRes(2, 0)) Then StConceito = ArrRes(2, 0)
        
        If Not IsEmpty(requisitos) And requisitos <> "" Then
                vtReq = Split(requisitos, "-|-")
                For a = 0 To 9
                    If vtReq(a) <> "" Then
                        frmsol.Controls("txtReq" & Format(a + 1, "00")).Text = vtReq(a)
                    End If
                    If StConceito = "OK1" Then
                        frmsol.Controls("txtReq" & Format(a + 1, "00")).Locked = True
                    End If
                Next a
        End If
        
        If Not IsEmpty(chkReq) And chkReq <> "0|0|0|0|0|0|0|0|0|0|" And chkReq <> "" Then
            Reqs = Split(chkReq, "|")
            For a = 0 To 9
                If Reqs(a) = "A" Then
                    frmsol.Controls("chkReq" & Format(a + 1, "00")).Picture = frmsol.chkReqOn.Picture
                    frmsol.Controls("txtReq" & Format(a + 1, "00")).ForeColor = &H999900
                    frmsol.Controls("txtReq" & Format(a + 1, "00")).BorderColor = &H999900
                    frmsol.Controls("lblReq" & Format(a + 1, "00")).ForeColor = &H999900
                End If
            Next a
            
        End If
    End If
End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "M_Abre_UF"
Option Explicit

Sub Carrega_campos(ref)
Dim SQL             As String
Dim SQLz            As String
Dim ArrRes          As Variant
Dim a               As Integer
Dim ArrDesc         As Variant
Dim lib_st          As String
Dim caminho         As String


'Query de consulta para formulário
SQL = "SELECT Descricao, Data_Solicitacao, Solicitante, Aplicacao, Vagao, Lote, Historico,"
SQL = SQL & "Conceito_St, Conceito_Fim, "
SQL = SQL & "Det_St, Det_Fim, "
SQL = SQL & "Liberacao_St, Liberacao_Data, Aq_St, Aq_Data, Corte_St, Corte_Data, Exec_St, Exec_Data, Tryout_St, Tryout_Data, Cod_Z, Classe, "
SQL = SQL & "Tempo_Modelo, Tempo_Fila_Det, Tempo_Det, Tempo_Fila_Lib, Conceito_P, Conceito_Ini, Liberacao_Data, Liberacao_St, Executor_EI, Data_Inicio_EI, Data_Fim_EI, Status_EI "
SQL = SQL & " FROM Fila WHERE Ref = " & ref & ";"

ArrRes = resQuery(SQL)

If Not IsEmpty(ArrRes) Then
        a = 0
        frmsol.lbl_ref.Caption = "SL" & Format(ref, "0000")
        
        frmsol.lbl_desc = ArrRes(0, a)
        
        If IsNull(ArrRes(1, a)) Then frmsol.lbl_data = "" Else frmsol.lbl_data = ArrRes(1, a)
        If IsNull(ArrRes(2, a)) Then frmsol.lbl_solic = "" Else frmsol.lbl_solic = ArrRes(2, a)
        
        If IsNull(ArrRes(3, a)) Then frmsol.lbl_estagio = "" Else frmsol.lbl_estagio = ArrRes(3, a)
        If IsNull(ArrRes(4, a)) Then frmsol.lbl_vg = "" Else frmsol.lbl_vg = ArrRes(4, a)
        If IsNull(ArrRes(5, a)) Then frmsol.lbl_lote = "" Else frmsol.lbl_lote = ArrRes(5, a)
        If IsNull(ArrRes(6, a)) Then frmsol.txt_historico.Text = "" Else frmsol.txt_historico.Text = ArrRes(6, a)
        
        
        If IsNull(ArrRes(7, a)) Then frmsol.proj_st.Caption = "" Else frmsol.proj_st.Caption = ArrRes(7, a)
        If IsNull(ArrRes(8, a)) Then frmsol.proj_data.Caption = "" Else frmsol.proj_data.Caption = Format(ArrRes(8, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(8, a)) Then frmsol.dt_inicio.Caption = "" Else frmsol.dt_inicio.Caption = Format(ArrRes(8, a), "DD/MM/YY")
        
        
        If IsNull(ArrRes(9, a)) Then frmsol.det_st.Caption = "" Else frmsol.det_st.Caption = ArrRes(9, a)
        If IsNull(ArrRes(10, a)) Then frmsol.det_data.Caption = "" Else frmsol.det_data.Caption = Format(ArrRes(10, a), "DD.MM.YY | hh:mm")
        
        
        If IsNull(ArrRes(11, a)) Then frmsol.lib_st.Caption = "" Else frmsol.lib_st.Caption = ArrRes(11, a)
        If IsNull(ArrRes(12, a)) Then frmsol.lib_data.Caption = "" Else frmsol.lib_data.Caption = Format(ArrRes(12, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(12, a)) Then frmsol.dt_fim.Caption = "" Else frmsol.dt_fim.Caption = Format(ArrRes(12, a), "DD/MM/YY")
        
        If IsNull(ArrRes(13, a)) Then frmsol.aq_st.Caption = "" Else frmsol.aq_st.Caption = ArrRes(13, a)
        If IsNull(ArrRes(14, a)) Then frmsol.aq_data.Caption = "" Else frmsol.aq_data.Caption = Format(ArrRes(14, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(15, a)) Then frmsol.corte_st.Caption = "" Else frmsol.corte_st.Caption = ArrRes(15, a)
        If IsNull(ArrRes(16, a)) Then frmsol.corte_data.Caption = "" Else frmsol.corte_data.Caption = Format(ArrRes(16, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(17, a)) Then frmsol.exec_st.Caption = "" Else frmsol.exec_st.Caption = ArrRes(17, a)
        If IsNull(ArrRes(18, a)) Then frmsol.exec_data.Caption = "" Else frmsol.exec_data.Caption = Format(ArrRes(18, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(19, a)) Then frmsol.tryout_st.Caption = "" Else frmsol.tryout_st.Caption = ArrRes(19, a)
        If IsNull(ArrRes(20, a)) Then frmsol.tryout_data.Caption = "" Else frmsol.tryout_data.Caption = Format(ArrRes(20, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(21, a)) Then
            frmsol.lbl_codz.Caption = ""
            frmsol.lbl_cod_z.Caption = ""
        Else
            frmsol.lbl_cod_z.Caption = ArrRes(21, a)
            frmsol.lbl_codz.Caption = ArrRes(21, a)
            If ArrRes(21, a) <> "" Then
                SQLz = "SELECT Descricao FROM Projetos WHERE Controle = " & Replace(ArrRes(21, a), "Z", "") & ";"
                ArrDesc = resQuery(SQLz)
                If Not IsNull(ArrDesc(0, 0)) Then frmsol.lbl_descz.Caption = ArrDesc(0, 0)
            End If
        End If
              
        
        If IsNull(ArrRes(22, a)) Then frmsol.lbl_classe.Caption = "" Else frmsol.lbl_classe.Caption = ArrRes(22, a)
        
        'Horas
        If IsNull(ArrRes(23, a)) Then frmsol.lbl_proj_h.Caption = "" Else frmsol.lbl_proj_h.Caption = Format(ArrRes(23, a), "0.0h")
        If IsNull(ArrRes(24, a)) Then frmsol.lbl_fila_1.Caption = "" Else frmsol.lbl_fila_1.Caption = Format(ArrRes(24, a), "0.0h")
        If IsNull(ArrRes(25, a)) Then frmsol.lbl_det_h.Caption = "" Else frmsol.lbl_det_h.Caption = Format(ArrRes(25, a), "0.0h")
        If IsNull(ArrRes(26, a)) Then frmsol.lbl_fila_2.Caption = "" Else frmsol.lbl_fila_2.Caption = Format(ArrRes(26, a), "0.0h")
        
        If IsNull(ArrRes(27, a)) Then frmsol.lbl_projetista.Caption = "" Else frmsol.lbl_projetista.Caption = ArrRes(27, a)
        If IsNull(ArrRes(28, a)) Then frmsol.lbl_ini_proj.Caption = "" Else frmsol.lbl_ini_proj.Caption = ArrRes(28, a)
        If IsNull(ArrRes(29, a)) Then frmsol.lbl_fim_proj.Caption = "" Else frmsol.lbl_fim_proj.Caption = ArrRes(29, a)
        If IsNull(ArrRes(30, a)) Then frmsol.lbl_status_proj.Caption = "" Else frmsol.lbl_status_proj.Caption = ArrRes(30, a)
        
        If IsNull(ArrRes(31, a)) Then frmsol.lbl_executor.Caption = "" Else frmsol.lbl_executor.Caption = ArrRes(31, a)
        If IsNull(ArrRes(32, a)) Then frmsol.lbl_ini_exec.Caption = "" Else frmsol.lbl_ini_exec.Caption = ArrRes(32, a)
        If IsNull(ArrRes(33, a)) Then frmsol.lbl_fim_exec.Caption = "" Else frmsol.lbl_fim_exec.Caption = ArrRes(33, a)
        If IsNull(ArrRes(34, a)) Then frmsol.lbl_status_exec.Caption = "" Else frmsol.lbl_status_exec.Caption = ArrRes(34, a)
        
        
        If lib_st = "[VERIFICAÇÃO]" Then frmsol.btnLimparComprados.Enabled = True
        
        On Error Resume Next
        caminho = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\SL" & Format(ref, "0000") & ".jpg"
        On Error Resume Next
        frmsol.img_sl.Picture = LoadPicture(caminho)
        
        
End If

End Sub

Sub Formata_Campos()

    Dim azul                As String
    Dim vermelho            As String
    Dim vermelho_escuro     As String
    Dim azul_claro          As String
    Dim amarelo             As String
    Dim cinza_escuro        As String
    Dim cinza_claro         As String
    Dim verde               As String

    
    
        'Cores
        azul = &HC59452
        vermelho = &H8080FF
        vermelho_escuro = &HC0&
        azul_claro = &HFF8080
        amarelo = &H8080&
        cinza_escuro = &H808080
        cinza_claro = &HC0C0C0
        verde = &H8000&

        'Ajustar cor das Labels
        If frmsol.proj_st.Caption = "OK" Then frmsol.proj_st.BackColor = verde
        If frmsol.proj_st.Caption = "PENDENTE" Then frmsol.proj_st.BackColor = vermelho
        If frmsol.proj_st.Caption = "CANCELADO" Then frmsol.proj_st.BackColor = cinza_claro
        If frmsol.proj_st.Caption = "PAUSADO" Then frmsol.proj_st.BackColor = cinza_escuro
        If frmsol.proj_st.Caption = "EM ANÁLISE" Then frmsol.proj_st.BackColor = azul
        If frmsol.proj_st.Caption = "MODELO" Then frmsol.proj_st.BackColor = amarelo
        If frmsol.proj_st.Caption = "BACKLOG" Then frmsol.proj_st.BackColor = azul_claro
        
        If frmsol.det_st.Caption = "OK" Then frmsol.det_st.BackColor = verde
        If frmsol.det_st.Caption = "PENDENTE" Then frmsol.det_st.BackColor = vermelho
        If frmsol.det_st.Caption = "CANCELADO" Then frmsol.det_st.BackColor = cinza_claro
        
        If frmsol.lib_st.Caption = "OK" Then frmsol.lib_st.BackColor = verde
        If frmsol.lib_st.Caption = "PENDENTE" Then frmsol.lib_st.BackColor = vermelho
        If frmsol.lib_st.Caption = "CANCELADO" Then frmsol.lib_st.BackColor = cinza_claro
        
        If frmsol.aq_st.Caption = "OK" Then frmsol.aq_st.BackColor = verde
        If frmsol.aq_st.Caption = "PENDENTE" Then frmsol.aq_st.BackColor = vermelho
        If frmsol.aq_st.Caption = "REALIZADO" Then frmsol.aq_st.BackColor = amarelo
        If frmsol.aq_st.Caption = "CANCELADO" Then frmsol.aq_st.BackColor = cinza_claro

        If frmsol.corte_st.Caption = "FINALIZADO" Then frmsol.corte_st.BackColor = verde
        If frmsol.corte_st.Caption = "PARADO" Then frmsol.corte_st.BackColor = vermelho_escuro
        If frmsol.corte_st.Caption = "ANDAMENTO" Then frmsol.corte_st.BackColor = azul
        If frmsol.corte_st.Caption = "CANCELADO" Then frmsol.corte_st.BackColor = cinza_claro
        
        If frmsol.exec_st.Caption = "FINALIZADO" Then frmsol.exec_st.BackColor = verde
        If frmsol.exec_st.Caption = "PARADO" Then frmsol.exec_st.BackColor = vermelho_escuro
        If frmsol.exec_st.Caption = "ANDAMENTO" Then frmsol.exec_st.BackColor = azul
        If frmsol.exec_st.Caption = "CANCELADO" Then frmsol.exec_st.BackColor = cinza_claro
        
        If frmsol.tryout_st.Caption = "OK" Then frmsol.tryout_st.BackColor = verde
        If frmsol.tryout_st.Caption = "PENDENTE" Then frmsol.tryout_st.BackColor = vermelho
        If frmsol.tryout_st.Caption = "CANCELADO" Then frmsol.tryout_st.BackColor = cinza_claro
End Sub

Sub Carrega_DFX(cod_sl)
    Dim SQL             As String
    Dim ArrRes          As Variant
    Dim ArrRes_DXF      As Variant
    Dim tam_res         As Integer
    Dim i               As Integer
    Dim linha           As Variant
    Dim Colunas         As Integer
    Dim Linhas          As Integer
    Dim sts             As Variant
    Dim X               As Integer
    
    
            frmsol.dxf_lst.Gridlines = True
            frmsol.dxf_lst.View = lvwReport
            frmsol.dxf_lst.FullRowSelect = False
            frmsol.dxf_lst.ColumnHeaders.Clear
            frmsol.dxf_lst.ColumnHeaders.Add Text:="CTRL", Width:=40
            frmsol.dxf_lst.ColumnHeaders.Add Text:="DESCRIÇÃO", Width:=290, Alignment:=0
            frmsol.dxf_lst.ColumnHeaders.Add Text:="PRIORIDADE", Width:=60, Alignment:=0
            frmsol.dxf_lst.ColumnHeaders.Add Text:="STATUS CORTE", Width:=70, Alignment:=0
            
            SQL = "SELECT Controle, Descricao, Prioridade, Status FROM DXF_Control WHERE Solicitacao = '" & cod_sl & "' ORDER BY Controle DESC;"

            ArrRes_DXF = resQuery(SQL)

            If Not IsEmpty(ArrRes_DXF) Then
                tam_res = UBound(ArrRes_DXF, 2)
                frmsol.dxf_lst.ListItems.Clear
                For i = 0 To tam_res
                    Set linha = frmsol.dxf_lst.ListItems.Add(Text:="DX" & Format(ArrRes_DXF(0, i), "0000")) 'Controle
                    If Not IsNull(ArrRes_DXF(1, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(1, i) Else linha.ListSubItems.Add Text:="" 'Descrição
                    If Not IsNull(ArrRes_DXF(2, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(2, i) Else linha.ListSubItems.Add Text:="" 'Prioridade
                    If Not IsNull(ArrRes_DXF(3, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(3, i) Else linha.ListSubItems.Add Text:="" 'Status
                Next i
            End If
            
            Colunas = frmsol.dxf_lst.ColumnHeaders.Count
            Linhas = frmsol.dxf_lst.ListItems.Count
    
            For i = 1 To Linhas
            sts = frmsol.dxf_lst.ListItems(i).ListSubItems(2)
            If sts = "CONCLUÍDO" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(35, 142, 35)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(35, 142, 35)
                Next X
            End If
            
            If sts = "99-Cancelado" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(150, 150, 150)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(150, 150, 150)
                Next X
            End If

            If sts <> "CONCLUÍDO" And sts <> "99-Cancelado" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(255, 0, 0)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(255, 0, 0)
                Next X
            End If

    Next i
End Sub

Sub carrega_pdf(cod_sl)
    Dim SQL                 As String
    Dim ArrRes_PDF          As Variant
    Dim tam_res             As Integer
    Dim i                   As Integer
         
            SQL = "SELECT Codigo FROM PDF_Control WHERE Solicitacao = '" & cod_sl & "' ORDER BY Codigo;"

            ArrRes_PDF = resQuery(SQL)

            If Not IsEmpty(ArrRes_PDF) Then
                tam_res = UBound(ArrRes_PDF, 2)
                frmsol.pdf_lst.Clear
                For i = 0 To tam_res
                    frmsol.pdf_lst.AddItem (ArrRes_PDF(0, i))
                Next i
            End If
End Sub
Sub Carrega_BOM(cod_sl)
    Dim SQL                 As String
    Dim ArrRes_BOM          As Variant
    Dim tam_res             As Integer
    Dim i                   As Integer
    Dim linha               As Variant
    Dim Colunas             As Integer
    Dim Linhas              As Integer
    Dim sts                 As String
    Dim cod                 As String
    Dim OC                  As String
    Dim X                   As Integer
    Dim caminho             As String

            frmsol.bom_lst.Gridlines = True
            frmsol.bom_lst.View = lvwReport
            frmsol.bom_lst.FullRowSelect = False
            frmsol.bom_lst.ColumnHeaders.Clear
            frmsol.bom_lst.ColumnHeaders.Add Text:="", Width:=1
            frmsol.bom_lst.ColumnHeaders.Add Text:="CÓDIGO", Width:=70
            frmsol.bom_lst.ColumnHeaders.Add Text:="REV", Width:=25, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="DESCRIÇÃO", Width:=200
            frmsol.bom_lst.ColumnHeaders.Add Text:="QTD.", Width:=40, Alignment:=1
            frmsol.bom_lst.ColumnHeaders.Add Text:="TIPO", Width:=85, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="Nº OC", Width:=50, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="STATUS", Width:=70, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="PEDIDO", Width:=50, Alignment:=2
            
            SQL = "SELECT B.Controle, B.Codigo, B.Revisao, B.Descricao, B.Qtde, B.Tipo, B.OC, Aq.Status, Aq.Pedido FROM BOM_Control B LEFT OUTER JOIN OC_Control Aq ON B.OC = Aq.OC WHERE B.Solicitacao = '" & cod_sl & "';"
            
            ArrRes_BOM = resQuery(SQL)

            If Not IsEmpty(ArrRes_BOM) Then
                tam_res = UBound(ArrRes_BOM, 2)
                frmsol.bom_lst.ListItems.Clear
                For i = 0 To tam_res
                    Set linha = frmsol.bom_lst.ListItems.Add(Text:=ArrRes_BOM(0, i)) 'Controle
                    If Not IsNull(ArrRes_BOM(1, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(1, i) Else linha.ListSubItems.Add Text:="" 'Codigo
                    If Not IsNull(ArrRes_BOM(2, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(2, i) Else linha.ListSubItems.Add Text:="" 'Revisao
                    If Not IsNull(ArrRes_BOM(3, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(3, i) Else linha.ListSubItems.Add Text:="" 'Descricao
                    If Not IsNull(ArrRes_BOM(4, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(4, i) Else linha.ListSubItems.Add Text:="" 'Qtde
                    If Not IsNull(ArrRes_BOM(5, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(5, i) Else linha.ListSubItems.Add Text:="" 'Tipo
                    If Not IsNull(ArrRes_BOM(6, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(6, i) Else linha.ListSubItems.Add Text:="" 'OC
                    If Not IsNull(ArrRes_BOM(7, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(7, i) Else linha.ListSubItems.Add Text:="" 'Status
                    If Not IsNull(ArrRes_BOM(8, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(8, i) Else linha.ListSubItems.Add Text:="" 'Pedido
                Next i
            End If

            Colunas = frmsol.bom_lst.ColumnHeaders.Count
            Linhas = frmsol.bom_lst.ListItems.Count
    
            For i = 1 To Linhas

            sts = frmsol.bom_lst.ListItems(i).ListSubItems(7)
            cod = frmsol.bom_lst.ListItems(i).ListSubItems(1)
            OC = frmsol.bom_lst.ListItems(i).ListSubItems(6)
      
            If sts = "LIQUIDADA" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H8000&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H8000&
                Next X
            End If

            If sts = "PENDENTE" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF&
                Next X
            End If

            If sts = "REALIZADA" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H80FF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H80FF&
                Next X
            End If

            If sts = "EM ABERTO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF0000
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF0000
                Next X
            End If
        
            If sts = "COTAÇÃO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HC000C0
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HC000C0
                Next X
            End If
       
            If sts = "CANCELADO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H808080
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H808080
                Next X
            End If
       
            If cod = "SIDERÚRGICO" And OC <> "" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF&
                Next X
            End If
            Next i
        

        
        
End Sub

Sub carregaReqs(codSL)
    Dim SQL                 As String
    Dim ArrRes              As Variant
    Dim requisitos          As String
    Dim chkReq               As String
    Dim StConceito          As String
    Dim vtReq               As Variant
    Dim Reqs                As Variant
    Dim a                   As Integer
    
    codSL = Replace(codSL, "SL", "")
    
    SQL = "SELECT Requisitos, CKReq, Conceito_St FROM Fila WHERE Ref = " & codSL & ";"
    ArrRes = resQuery(SQL)
    If Not IsEmpty(ArrRes) Then
        If Not IsNull(ArrRes(0, 0)) Then requisitos = ArrRes(0, 0)
        If Not IsNull(ArrRes(1, 0)) Then chkReq = ArrRes(1, 0)
        If Not IsNull(ArrRes(2, 0)) Then StConceito = ArrRes(2, 0)
        
        If Not IsEmpty(requisitos) And requisitos <> "" Then
                vtReq = Split(requisitos, "-|-")
                For a = 0 To 9
                    If vtReq(a) <> "" Then
                        frmsol.Controls("txtReq" & Format(a + 1, "00")).Text = vtReq(a)
                    End If
                    If StConceito = "OK1" Then
                        frmsol.Controls("txtReq" & Format(a + 1, "00")).Locked = True
                    End If
                Next a
        End If
        
        If Not IsEmpty(chkReq) And chkReq <> "0|0|0|0|0|0|0|0|0|0|" And chkReq <> "" Then
            Reqs = Split(chkReq, "|")
            For a = 0 To 9
                If Reqs(a) = "A" Then
                    frmsol.Controls("chkReq" & Format(a + 1, "00")).Picture = frmsol.chkReqOn.Picture
                    frmsol.Controls("txtReq" & Format(a + 1, "00")).ForeColor = &H999900
                    frmsol.Controls("txtReq" & Format(a + 1, "00")).BorderColor = &H999900
                    frmsol.Controls("lblReq" & Format(a + 1, "00")).ForeColor = &H999900
                End If
            Next a
            
        End If
    End If
End Sub
```

---

## 6. VBA — `frmaut` (módulo inteiro)

Form de desenvolvimento. Mudaram 2 procedimentos: `btnLoadImage_Click` e `lbl_abrir_Click`.

### ANTES (100%)
```vb
Attribute VB_Name = "frmaut"
Attribute VB_Base = "0{30BCCC7C-89F3-408D-8AAC-1376B95D71EE}{7DF0D717-93C6-4979-908D-92EAD7F3867F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False


Private Sub btn_bom_Click()

    cod_z = frmsol.lbl_codz.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="F:\eng_ind\PROJETOS_Controle\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


End Sub

Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_docs_Click()
    
    UF.lbl_codSL.Caption = Me.lbl_ref.Caption
    UF.lbl_codz.Caption = Me.lbl_cod_z.Caption
    UF.lbl_descricao_SL.Caption = Me.lbl_desc
    
    UF.Show

End Sub

Private Sub btn_dxf_novo_Click()
    ufdxf.Show
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.cmb_autor.Text
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)


End Sub

Private Sub btn_ok_Click()

    Unload Me
    
    filtro = Sheets("Fila").Range("M4").Value
    If filtro = 0 Then Listar_todos
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06
    If filtro = 7 Then filtro_07
    If filtro = 8 Then Listar_analise
    If filtro = 9 Then Lista_SL (Range("H4").Value)
    If filtro = 10 Then Lista_Z (Range("G4").Value)
    If filtro = 11 Then Call Lista_VG(Range("I4").Value, Range("G5").Value)
    If filtro = 12 Then Call Lista_Solic(Range("G5").Value, Range("I4").Value)
    If filtro = 13 Then filtro_08
    If filtro = 14 Then Call Lista_Projetista(Range("K4").Value, Range("I4").Value)
    If filtro = 15 Then Lista_Novos

End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(ln, 2).Value = li1.Text
                .Cells(ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(ln, 16).Value = li1.ListSubItems(3).Text
                ln = ln + 1
        Next a
                
        'Carrega OCs
        ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(ln, 17).Value = li2.ListSubItems(7).Text 'Status
                ln = ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("F:\eng_ind\PROJETOS_Controle\Controle\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    

    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
        Sheets("Fila").Activate
    
        Unload Me

End Sub


Private Sub carrega_pdf_Click()

End Sub

Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "F:\eng_ind\PROJETOS_Controle\Controle\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub

Private Sub btn_pdf_novo_Click()
    Dim SQL As String
    Dim SQL_pdf As String
    lista_PDF = AbrePDF()
    
    t_cod_z = frmsol.lbl_cod_z.Caption
    t_cod_sl = frmsol.lbl_ref.Caption
    
    If Not IsEmpty(lista_PDF) Then
        For a = 1 To UBound(lista_PDF)
            caminho = lista_PDF(a)
            pos = InStrRev(caminho, "\", , vbTextCompare)
            codigo = Mid(caminho, pos + 1, Len(caminho) - pos)
            codigo = Replace(codigo, ".PDF", "")
            codigo = Replace(codigo, ".pdf", "")
                       
            t_codigo_pdf = codigo
            t_caminho_pdf = caminho
            
            SQL_pdf = "SELECT Codigo From PDF_Control WHERE Codigo = '" & t_codigo_pdf & "' AND Solicitacao = '" & t_cod_sl & "';"
            ArrPDF = resQuery(SQL_pdf)
            
            If IsEmpty(ArrPDF) Then
                SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo_pdf & "',"
                SQL = SQL & "'0');"
                upQuery (SQL)
            End If
            
            Dim oldPathPDF As String, newPathPDF As String
            oldPathPDF = t_caminho_pdf
            
            newPath = "F:\eng_ind\PROJETOS_Controle\Controle\desenhosPDF\" & t_cod_sl
            
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            
            newPathPDF = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            


            oldPathPDF = t_caminho_pdf
            newPath = "F:\eng_ind\PROJETOS_Controle\Controle\desenhosPDF\" & t_cod_sl
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            newPathPDF2 = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            newPathPDF = "F:\eng_ind\PROJETOS_Controle\Controle\.desenhos\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            If oldPathPDF <> "" Then
                Set fs = CreateObject("Scripting.FileSystemObject")
                fs.CopyFile oldPathPDF, newPathPDF
                fs.CopyFile oldPathPDF, newPathPDF2
                Set fs = Nothing
            End If

        Next a
    End If
    
    MsgBox "Desenhos em PDF carregados com sucesso!"
    
    Call carrega_pdf(frmsol.lbl_ref.Caption)
    
End Sub

Private Sub btn_buy_novo_Click()
    frm_bom2.lbl_ref.Caption = frmsol.lbl_ref.Caption
    frm_bom2.lbl_desc.Caption = frmsol.lbl_desc.Caption
    frm_bom2.Show
End Sub

Private Sub btnCheck_Click()


Me.multi.Value = 2

'set cor do botão ativo
Me.btnCheck.ForeColor = &H80000012
Me.bordaCheck.BorderColor = &H808080
Me.bordaCheck.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF




End Sub

Private Sub btnDados_Click()

Me.multi.Value = 0

'set cor do botão ativo
Me.btnDados.ForeColor = &H80000012
Me.bordaDados.BorderColor = &H808080
Me.bordaDados.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF

End Sub

Private Sub btnHabilitar_Click()

If Me.det_st.Caption = "OK" Then
    Me.btn_carregar_docs.Enabled = True
    Me.btn_carregar_docs.BackColor = &H80FF80
End If

End Sub

Private Sub btnLoad_Click()
    caminho = "http://mcs.eng.br/greenbrier/upload.html"
    ufLoad.wb.Navigate (caminho)
    ufLoad.Show
End Sub

Private Sub btnLimparComprados_Click()

Dim SQL As String
Dim rq As VbMsgBoxResult
rq = MsgBox("Deseja limpar a lista de Itens Comprados?", vbYesNo, "Deletar?")

If rq = vbYes Then
    nSL = Me.lbl_ref.Caption
    SQL = "DELETE FROM BOM_Control WHERE Solicitacao = '" & sSL & "' AND OC = '';"
    upQuery (SQL)
End If


End Sub

Private Sub btnReq_Click()
Me.multi.Value = 1

'set cor do botão ativo
Me.btnReq.ForeColor = &H80000012
Me.bordaReq.BorderColor = &H808080
Me.bordaReq.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF

End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        ArrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(ArrRes(10, 0)) Then frm_dxf.pg01.Caption = ArrRes(10, 0)
        If Not IsNull(ArrRes(0, 0)) Then frm_dxf.res01.Caption = ArrRes(0, 0)
        status_pg01 = ArrRes(11, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #2
        If Not IsNull(ArrRes(12, 0)) Then frm_dxf.pg02.Caption = ArrRes(12, 0)
        If Not IsNull(ArrRes(1, 0)) Then frm_dxf.res02.Caption = ArrRes(1, 0)
        status_pg02 = ArrRes(13, 0)
        
        'MsgBox status_pg02
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #3
        If Not IsNull(ArrRes(14, 0)) Then frm_dxf.pg03.Caption = ArrRes(14, 0)
        If Not IsNull(ArrRes(2, 0)) Then frm_dxf.res03.Caption = ArrRes(2, 0)
        status_pg03 = ArrRes(15, 0)
        
        'MsgBox status_pg03
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #4
        If Not IsNull(ArrRes(16, 0)) Then frm_dxf.pg04.Caption = ArrRes(16, 0)
        If Not IsNull(ArrRes(3, 0)) Then frm_dxf.res04.Caption = ArrRes(3, 0)
        status_pg04 = ArrRes(17, 0)
        
        'MsgBox status_pg04
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #5
        If Not IsNull(ArrRes(18, 0)) Then frm_dxf.pg05.Caption = ArrRes(18, 0)
        If Not IsNull(ArrRes(4, 0)) Then frm_dxf.res05.Caption = ArrRes(4, 0)
        status_pg05 = ArrRes(19, 0)
        
        'MsgBox status_pg05
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #6
        If Not IsNull(ArrRes(20, 0)) Then frm_dxf.pg06.Caption = ArrRes(20, 0)
        If Not IsNull(ArrRes(5, 0)) Then frm_dxf.res06.Caption = ArrRes(5, 0)
        status_pg06 = ArrRes(21, 0)
        
        'MsgBox status_pg06
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #7
        If Not IsNull(ArrRes(22, 0)) Then frm_dxf.pg07.Caption = ArrRes(22, 0)
        If Not IsNull(ArrRes(6, 0)) Then frm_dxf.res07.Caption = ArrRes(6, 0)
        status_pg07 = ArrRes(23, 0)
        
        'MsgBox status_pg07
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #8
        If Not IsNull(ArrRes(24, 0)) Then frm_dxf.pg08.Caption = ArrRes(24, 0)
        If Not IsNull(ArrRes(7, 0)) Then frm_dxf.res08.Caption = ArrRes(7, 0)
        status_pg08 = ArrRes(25, 0)
        
        'MsgBox status_pg08
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #9
        If Not IsNull(ArrRes(26, 0)) Then frm_dxf.pg09.Caption = ArrRes(26, 0)
        If Not IsNull(ArrRes(8, 0)) Then frm_dxf.res09.Caption = ArrRes(8, 0)
        status_pg09 = ArrRes(27, 0)
        
        'MsgBox status_pg09
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #10
        If Not IsNull(ArrRes(28, 0)) Then frm_dxf.pg10.Caption = ArrRes(28, 0)
        If Not IsNull(ArrRes(9, 0)) Then frm_dxf.res10.Caption = ArrRes(9, 0)
        status_pg10 = ArrRes(29, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        
        
        
        frm_dxf.Show
        
        
    End If


End Sub







Private Sub Label21_Click()
    Dim SQL_Z As String
    projetista = frmsol.lbl_projetista.Caption
    cod_z = Replace(frmsol.lbl_codz.Caption, "Z", "")
    data_inicio = DateValue(Me.dt_inicio.Caption)
    data_fim = DateValue(Me.dt_fim.Caption)
    SQL_Z = "UPDATE Projetos SET Data_Inicio = '" & data_inicio & "' , Data_Fim = '" & data_fim & "' , Projetista = '" & projetista & "', Status = 'Concluído', "
    SQL_Z = SQL_Z & "Data_R_Inicio = '" & data_inicio & "' , Data_R_Fim = '" & data_fim & "' "
    SQL_Z = SQL_Z & " WHERE Controle = " & cod_z & ";"
    upQuery (SQL_Z)
    MsgBox "Projeto " & Me.lbl_codz.Caption & " atualizado!"
    Unload Me
End Sub



Private Sub btnLoadBOM_Click()
    frm_bom.lbl_ref.Caption = frmaut.lbl_ref.Caption
    frm_bom.lbl_desc.Caption = frmaut.lbl_desc.Caption
    frm_bom.lblTipo.Caption = "Auto"
    frm_bom.lblCodZ.Caption = frmaut.lbl_codz.Caption
    frm_bom.Show
End Sub

Private Sub btnLoadImage_Click()
Dim fs As Object
Dim oldPathJPG As String, newPathJPG As String

oldPathJPG = AbreJPG
If oldPathJPG <> "" Then
    caminho_arquivo = Left(oldPathJPG, InStrRev(oldPathJPG, "\") - 1)
    caminho_arquivo = Left(caminho_arquivo, InStrRev(caminho_arquivo, "\") - 1)

    cod_sl = frmaut.lbl_ref.Caption

    If oldPathJPG <> "" Then
        Set fs = CreateObject("Scripting.FileSystemObject")
        newPathJPG = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & cod_sl & ".jpg"
        fs.CopyFile oldPathJPG, newPathJPG
        Set fs = Nothing
        caminho = newPathJPG
        Me.img_sl.Picture = LoadPicture(caminho)
    End If
End If
End Sub



Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & frmaut.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub

Private Sub lbl_trocar_Click()


End Sub

Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
   
    codigo = Me.pdf_lst.Text
   
    tgtfile = "F:\eng_ind\PROJETOS_Controle\Controle\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)
        
    
    
    'user = "MARCOS"
    'codigo = Me.lbl_ref & " - " & Me.pdf_lst.Text
    
    'caminho = "http://mcs.eng.br/greenbrier/copia.php?nome=" & user & "&pdf=" & codigo & ".PDF"
    'ufView.wb.Navigate (caminho)
    
    'ufView.Show
End Sub

Private Sub pdf_lst_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
Dim SQL As String
Dim res As VbMsgBoxResult

If KeyAscii = 120 Then
    codigo = Me.pdf_lst.Text
    n_sl = Me.lbl_ref.Caption
    
    res = MsgBox("Deseja EXCLUIR o desenho nº " & codigo & "?", vbYesNoCancel, "EXCLUIR?")
    If res = vbYes Then
        SQL = "DELETE FROM PDF_Control WHERE Codigo = '" & codigo & "' AND Solicitacao = '" & n_sl & "';"
        upQuery (SQL)
    End If
End If

Call carrega_pdf(frmsol.lbl_ref.Caption)

End Sub



Private Sub txtReq01_Change()
If Me.txtReq01.Value <> "" Then
    Me.lblReq01.ForeColor = &H8080FF
    Me.txtReq01.BorderColor = &H8080FF
    Me.txtReq01.ForeColor = &H8080FF
    Me.chkReq01.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq01.ForeColor = &HC0C0C0
    Me.txtReq01.BorderColor = &HC0C0C0
    Me.txtReq01.ForeColor = &HC0C0C0
    Me.chkReq01.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq02_Change()
If Me.txtReq02.Value <> "" Then
    Me.lblReq02.ForeColor = &H8080FF
    Me.txtReq02.BorderColor = &H8080FF
    Me.txtReq02.ForeColor = &H8080FF
    Me.chkReq02.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq02.ForeColor = &HC0C0C0
    Me.txtReq02.BorderColor = &HC0C0C0
    Me.txtReq02.ForeColor = &HC0C0C0
    Me.chkReq02.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq03_Change()
If Me.txtReq03.Value <> "" Then
    Me.lblReq03.ForeColor = &H8080FF
    Me.txtReq03.BorderColor = &H8080FF
    Me.txtReq03.ForeColor = &H8080FF
    Me.chkReq03.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq03.ForeColor = &HC0C0C0
    Me.txtReq03.BorderColor = &HC0C0C0
    Me.txtReq03.ForeColor = &HC0C0C0
    Me.chkReq03.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq04_Change()
If Me.txtReq04.Value <> "" Then
    Me.lblReq04.ForeColor = &H8080FF
    Me.txtReq04.BorderColor = &H8080FF
    Me.txtReq04.ForeColor = &H8080FF
    Me.chkReq04.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq04.ForeColor = &HC0C0C0
    Me.txtReq04.BorderColor = &HC0C0C0
    Me.txtReq04.ForeColor = &HC0C0C0
    Me.chkReq04.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq05_Change()
If Me.txtReq05.Value <> "" Then
    Me.lblReq05.ForeColor = &H8080FF
    Me.txtReq05.BorderColor = &H8080FF
    Me.txtReq05.ForeColor = &H8080FF
    Me.chkReq05.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq05.ForeColor = &HC0C0C0
    Me.txtReq05.BorderColor = &HC0C0C0
    Me.txtReq05.ForeColor = &HC0C0C0
    Me.chkReq05.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq06_Change()
If Me.txtReq06.Value <> "" Then
    Me.lblReq06.ForeColor = &H8080FF
    Me.txtReq06.BorderColor = &H8080FF
    Me.txtReq06.ForeColor = &H8080FF
    Me.chkReq06.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq06.ForeColor = &HC0C0C0
    Me.txtReq06.BorderColor = &HC0C0C0
    Me.txtReq06.ForeColor = &HC0C0C0
    Me.chkReq06.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq07_Change()
If Me.txtReq07.Value <> "" Then
    Me.lblReq07.ForeColor = &H8080FF
    Me.txtReq07.BorderColor = &H8080FF
    Me.txtReq07.ForeColor = &H8080FF
    Me.chkReq07.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq07.ForeColor = &HC0C0C0
    Me.txtReq07.BorderColor = &HC0C0C0
    Me.txtReq07.ForeColor = &HC0C0C0
    Me.chkReq07.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq08_Change()
If Me.txtReq08.Value <> "" Then
    Me.lblReq08.ForeColor = &H8080FF
    Me.txtReq08.BorderColor = &H8080FF
    Me.txtReq08.ForeColor = &H8080FF
    Me.chkReq08.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq08.ForeColor = &HC0C0C0
    Me.txtReq08.BorderColor = &HC0C0C0
    Me.txtReq08.ForeColor = &HC0C0C0
    Me.chkReq08.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq09_Change()
If Me.txtReq09.Value <> "" Then
    Me.lblReq09.ForeColor = &H8080FF
    Me.txtReq09.BorderColor = &H8080FF
    Me.txtReq09.ForeColor = &H8080FF
    Me.chkReq09.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq09.ForeColor = &HC0C0C0
    Me.txtReq09.BorderColor = &HC0C0C0
    Me.txtReq09.ForeColor = &HC0C0C0
    Me.chkReq09.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq10_Change()
If Me.txtReq10.Value <> "" Then
    Me.lblReq10.ForeColor = &H8080FF
    Me.txtReq10.BorderColor = &H8080FF
    Me.txtReq10.ForeColor = &H8080FF
    Me.chkReq10.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq10.ForeColor = &HC0C0C0
    Me.txtReq10.BorderColor = &HC0C0C0
    Me.txtReq10.ForeColor = &HC0C0C0
    Me.chkReq10.Picture = Me.chkReqOff.Picture
End If
End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "frmaut"
Attribute VB_Base = "0{30BCCC7C-89F3-408D-8AAC-1376B95D71EE}{7DF0D717-93C6-4979-908D-92EAD7F3867F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False


Private Sub btn_bom_Click()

    cod_z = frmsol.lbl_codz.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="F:\eng_ind\PROJETOS_Controle\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


End Sub

Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_docs_Click()
    
    UF.lbl_codSL.Caption = Me.lbl_ref.Caption
    UF.lbl_codz.Caption = Me.lbl_cod_z.Caption
    UF.lbl_descricao_SL.Caption = Me.lbl_desc
    
    UF.Show

End Sub

Private Sub btn_dxf_novo_Click()
    ufdxf.Show
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.cmb_autor.Text
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)


End Sub

Private Sub btn_ok_Click()

    Unload Me
    
    filtro = Sheets("Fila").Range("M4").Value
    If filtro = 0 Then Listar_todos
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06
    If filtro = 7 Then filtro_07
    If filtro = 8 Then Listar_analise
    If filtro = 9 Then Lista_SL (Range("H4").Value)
    If filtro = 10 Then Lista_Z (Range("G4").Value)
    If filtro = 11 Then Call Lista_VG(Range("I4").Value, Range("G5").Value)
    If filtro = 12 Then Call Lista_Solic(Range("G5").Value, Range("I4").Value)
    If filtro = 13 Then filtro_08
    If filtro = 14 Then Call Lista_Projetista(Range("K4").Value, Range("I4").Value)
    If filtro = 15 Then Lista_Novos

End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(ln, 2).Value = li1.Text
                .Cells(ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(ln, 16).Value = li1.ListSubItems(3).Text
                ln = ln + 1
        Next a
                
        'Carrega OCs
        ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(ln, 17).Value = li2.ListSubItems(7).Text 'Status
                ln = ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("F:\eng_ind\PROJETOS_Controle\Controle\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    

    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
        Sheets("Fila").Activate
    
        Unload Me

End Sub


Private Sub carrega_pdf_Click()

End Sub

Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "F:\eng_ind\PROJETOS_Controle\Controle\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub

Private Sub btn_pdf_novo_Click()
    Dim SQL As String
    Dim SQL_pdf As String
    lista_PDF = AbrePDF()
    
    t_cod_z = frmsol.lbl_cod_z.Caption
    t_cod_sl = frmsol.lbl_ref.Caption
    
    If Not IsEmpty(lista_PDF) Then
        For a = 1 To UBound(lista_PDF)
            caminho = lista_PDF(a)
            pos = InStrRev(caminho, "\", , vbTextCompare)
            codigo = Mid(caminho, pos + 1, Len(caminho) - pos)
            codigo = Replace(codigo, ".PDF", "")
            codigo = Replace(codigo, ".pdf", "")
                       
            t_codigo_pdf = codigo
            t_caminho_pdf = caminho
            
            SQL_pdf = "SELECT Codigo From PDF_Control WHERE Codigo = '" & t_codigo_pdf & "' AND Solicitacao = '" & t_cod_sl & "';"
            ArrPDF = resQuery(SQL_pdf)
            
            If IsEmpty(ArrPDF) Then
                SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo_pdf & "',"
                SQL = SQL & "'0');"
                upQuery (SQL)
            End If
            
            Dim oldPathPDF As String, newPathPDF As String
            oldPathPDF = t_caminho_pdf
            
            newPath = "F:\eng_ind\PROJETOS_Controle\Controle\desenhosPDF\" & t_cod_sl
            
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            
            newPathPDF = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            


            oldPathPDF = t_caminho_pdf
            newPath = "F:\eng_ind\PROJETOS_Controle\Controle\desenhosPDF\" & t_cod_sl
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            newPathPDF2 = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            newPathPDF = "F:\eng_ind\PROJETOS_Controle\Controle\.desenhos\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            If oldPathPDF <> "" Then
                Set fs = CreateObject("Scripting.FileSystemObject")
                fs.CopyFile oldPathPDF, newPathPDF
                fs.CopyFile oldPathPDF, newPathPDF2
                Set fs = Nothing
            End If

        Next a
    End If
    
    MsgBox "Desenhos em PDF carregados com sucesso!"
    
    Call carrega_pdf(frmsol.lbl_ref.Caption)
    
End Sub

Private Sub btn_buy_novo_Click()
    frm_bom2.lbl_ref.Caption = frmsol.lbl_ref.Caption
    frm_bom2.lbl_desc.Caption = frmsol.lbl_desc.Caption
    frm_bom2.Show
End Sub

Private Sub btnCheck_Click()


Me.multi.Value = 2

'set cor do botão ativo
Me.btnCheck.ForeColor = &H80000012
Me.bordaCheck.BorderColor = &H808080
Me.bordaCheck.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF




End Sub

Private Sub btnDados_Click()

Me.multi.Value = 0

'set cor do botão ativo
Me.btnDados.ForeColor = &H80000012
Me.bordaDados.BorderColor = &H808080
Me.bordaDados.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF

End Sub

Private Sub btnHabilitar_Click()

If Me.det_st.Caption = "OK" Then
    Me.btn_carregar_docs.Enabled = True
    Me.btn_carregar_docs.BackColor = &H80FF80
End If

End Sub

Private Sub btnLoad_Click()
    caminho = "http://mcs.eng.br/greenbrier/upload.html"
    ufLoad.wb.Navigate (caminho)
    ufLoad.Show
End Sub

Private Sub btnLimparComprados_Click()

Dim SQL As String
Dim rq As VbMsgBoxResult
rq = MsgBox("Deseja limpar a lista de Itens Comprados?", vbYesNo, "Deletar?")

If rq = vbYes Then
    nSL = Me.lbl_ref.Caption
    SQL = "DELETE FROM BOM_Control WHERE Solicitacao = '" & sSL & "' AND OC = '';"
    upQuery (SQL)
End If


End Sub

Private Sub btnReq_Click()
Me.multi.Value = 1

'set cor do botão ativo
Me.btnReq.ForeColor = &H80000012
Me.bordaReq.BorderColor = &H808080
Me.bordaReq.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF

End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        ArrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(ArrRes(10, 0)) Then frm_dxf.pg01.Caption = ArrRes(10, 0)
        If Not IsNull(ArrRes(0, 0)) Then frm_dxf.res01.Caption = ArrRes(0, 0)
        status_pg01 = ArrRes(11, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #2
        If Not IsNull(ArrRes(12, 0)) Then frm_dxf.pg02.Caption = ArrRes(12, 0)
        If Not IsNull(ArrRes(1, 0)) Then frm_dxf.res02.Caption = ArrRes(1, 0)
        status_pg02 = ArrRes(13, 0)
        
        'MsgBox status_pg02
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #3
        If Not IsNull(ArrRes(14, 0)) Then frm_dxf.pg03.Caption = ArrRes(14, 0)
        If Not IsNull(ArrRes(2, 0)) Then frm_dxf.res03.Caption = ArrRes(2, 0)
        status_pg03 = ArrRes(15, 0)
        
        'MsgBox status_pg03
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #4
        If Not IsNull(ArrRes(16, 0)) Then frm_dxf.pg04.Caption = ArrRes(16, 0)
        If Not IsNull(ArrRes(3, 0)) Then frm_dxf.res04.Caption = ArrRes(3, 0)
        status_pg04 = ArrRes(17, 0)
        
        'MsgBox status_pg04
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #5
        If Not IsNull(ArrRes(18, 0)) Then frm_dxf.pg05.Caption = ArrRes(18, 0)
        If Not IsNull(ArrRes(4, 0)) Then frm_dxf.res05.Caption = ArrRes(4, 0)
        status_pg05 = ArrRes(19, 0)
        
        'MsgBox status_pg05
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #6
        If Not IsNull(ArrRes(20, 0)) Then frm_dxf.pg06.Caption = ArrRes(20, 0)
        If Not IsNull(ArrRes(5, 0)) Then frm_dxf.res06.Caption = ArrRes(5, 0)
        status_pg06 = ArrRes(21, 0)
        
        'MsgBox status_pg06
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #7
        If Not IsNull(ArrRes(22, 0)) Then frm_dxf.pg07.Caption = ArrRes(22, 0)
        If Not IsNull(ArrRes(6, 0)) Then frm_dxf.res07.Caption = ArrRes(6, 0)
        status_pg07 = ArrRes(23, 0)
        
        'MsgBox status_pg07
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #8
        If Not IsNull(ArrRes(24, 0)) Then frm_dxf.pg08.Caption = ArrRes(24, 0)
        If Not IsNull(ArrRes(7, 0)) Then frm_dxf.res08.Caption = ArrRes(7, 0)
        status_pg08 = ArrRes(25, 0)
        
        'MsgBox status_pg08
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #9
        If Not IsNull(ArrRes(26, 0)) Then frm_dxf.pg09.Caption = ArrRes(26, 0)
        If Not IsNull(ArrRes(8, 0)) Then frm_dxf.res09.Caption = ArrRes(8, 0)
        status_pg09 = ArrRes(27, 0)
        
        'MsgBox status_pg09
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #10
        If Not IsNull(ArrRes(28, 0)) Then frm_dxf.pg10.Caption = ArrRes(28, 0)
        If Not IsNull(ArrRes(9, 0)) Then frm_dxf.res10.Caption = ArrRes(9, 0)
        status_pg10 = ArrRes(29, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        
        
        
        frm_dxf.Show
        
        
    End If


End Sub







Private Sub Label21_Click()
    Dim SQL_Z As String
    projetista = frmsol.lbl_projetista.Caption
    cod_z = Replace(frmsol.lbl_codz.Caption, "Z", "")
    data_inicio = DateValue(Me.dt_inicio.Caption)
    data_fim = DateValue(Me.dt_fim.Caption)
    SQL_Z = "UPDATE Projetos SET Data_Inicio = '" & data_inicio & "' , Data_Fim = '" & data_fim & "' , Projetista = '" & projetista & "', Status = 'Concluído', "
    SQL_Z = SQL_Z & "Data_R_Inicio = '" & data_inicio & "' , Data_R_Fim = '" & data_fim & "' "
    SQL_Z = SQL_Z & " WHERE Controle = " & cod_z & ";"
    upQuery (SQL_Z)
    MsgBox "Projeto " & Me.lbl_codz.Caption & " atualizado!"
    Unload Me
End Sub



Private Sub btnLoadBOM_Click()
    frm_bom.lbl_ref.Caption = frmaut.lbl_ref.Caption
    frm_bom.lbl_desc.Caption = frmaut.lbl_desc.Caption
    frm_bom.lblTipo.Caption = "Auto"
    frm_bom.lblCodZ.Caption = frmaut.lbl_codz.Caption
    frm_bom.Show
End Sub

Private Sub btnLoadImage_Click()
Dim fs As Object
Dim oldPathJPG As String, newPathJPG As String
Dim refNum As Long

oldPathJPG = AbreJPG
If oldPathJPG <> "" Then
    caminho_arquivo = Left(oldPathJPG, InStrRev(oldPathJPG, "\") - 1)
    caminho_arquivo = Left(caminho_arquivo, InStrRev(caminho_arquivo, "\") - 1)

    cod_sl = frmaut.lbl_ref.Caption                   ' ex.: "SL4001"
    refNum = CLng(Replace(cod_sl, "SL", ""))          ' "SL4001" -> 4001

    Set fs = CreateObject("Scripting.FileSystemObject")
    ' Mesmo nome que Carrega_campos le (SL{0000}.jpg), na pasta mapeada
    newPathJPG = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\SL" & Format(refNum, "0000") & ".jpg"
    fs.CopyFile oldPathJPG, newPathJPG
    Set fs = Nothing
    caminho = newPathJPG
    Me.img_sl.Picture = LoadPicture(caminho)

    ' Access -> Web: envia a mesma imagem pro MySQL/web
    enviarImagemParaMySQL refNum, newPathJPG
End If
End Sub



Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & frmaut.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub

Private Sub lbl_trocar_Click()


End Sub

Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
   
    codigo = Me.pdf_lst.Text
   
    tgtfile = "F:\eng_ind\PROJETOS_Controle\Controle\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)
        
    
    
    'user = "MARCOS"
    'codigo = Me.lbl_ref & " - " & Me.pdf_lst.Text
    
    'caminho = "http://mcs.eng.br/greenbrier/copia.php?nome=" & user & "&pdf=" & codigo & ".PDF"
    'ufView.wb.Navigate (caminho)
    
    'ufView.Show
End Sub

Private Sub pdf_lst_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
Dim SQL As String
Dim res As VbMsgBoxResult

If KeyAscii = 120 Then
    codigo = Me.pdf_lst.Text
    n_sl = Me.lbl_ref.Caption
    
    res = MsgBox("Deseja EXCLUIR o desenho nº " & codigo & "?", vbYesNoCancel, "EXCLUIR?")
    If res = vbYes Then
        SQL = "DELETE FROM PDF_Control WHERE Codigo = '" & codigo & "' AND Solicitacao = '" & n_sl & "';"
        upQuery (SQL)
    End If
End If

Call carrega_pdf(frmsol.lbl_ref.Caption)

End Sub



Private Sub txtReq01_Change()
If Me.txtReq01.Value <> "" Then
    Me.lblReq01.ForeColor = &H8080FF
    Me.txtReq01.BorderColor = &H8080FF
    Me.txtReq01.ForeColor = &H8080FF
    Me.chkReq01.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq01.ForeColor = &HC0C0C0
    Me.txtReq01.BorderColor = &HC0C0C0
    Me.txtReq01.ForeColor = &HC0C0C0
    Me.chkReq01.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq02_Change()
If Me.txtReq02.Value <> "" Then
    Me.lblReq02.ForeColor = &H8080FF
    Me.txtReq02.BorderColor = &H8080FF
    Me.txtReq02.ForeColor = &H8080FF
    Me.chkReq02.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq02.ForeColor = &HC0C0C0
    Me.txtReq02.BorderColor = &HC0C0C0
    Me.txtReq02.ForeColor = &HC0C0C0
    Me.chkReq02.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq03_Change()
If Me.txtReq03.Value <> "" Then
    Me.lblReq03.ForeColor = &H8080FF
    Me.txtReq03.BorderColor = &H8080FF
    Me.txtReq03.ForeColor = &H8080FF
    Me.chkReq03.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq03.ForeColor = &HC0C0C0
    Me.txtReq03.BorderColor = &HC0C0C0
    Me.txtReq03.ForeColor = &HC0C0C0
    Me.chkReq03.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq04_Change()
If Me.txtReq04.Value <> "" Then
    Me.lblReq04.ForeColor = &H8080FF
    Me.txtReq04.BorderColor = &H8080FF
    Me.txtReq04.ForeColor = &H8080FF
    Me.chkReq04.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq04.ForeColor = &HC0C0C0
    Me.txtReq04.BorderColor = &HC0C0C0
    Me.txtReq04.ForeColor = &HC0C0C0
    Me.chkReq04.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq05_Change()
If Me.txtReq05.Value <> "" Then
    Me.lblReq05.ForeColor = &H8080FF
    Me.txtReq05.BorderColor = &H8080FF
    Me.txtReq05.ForeColor = &H8080FF
    Me.chkReq05.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq05.ForeColor = &HC0C0C0
    Me.txtReq05.BorderColor = &HC0C0C0
    Me.txtReq05.ForeColor = &HC0C0C0
    Me.chkReq05.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq06_Change()
If Me.txtReq06.Value <> "" Then
    Me.lblReq06.ForeColor = &H8080FF
    Me.txtReq06.BorderColor = &H8080FF
    Me.txtReq06.ForeColor = &H8080FF
    Me.chkReq06.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq06.ForeColor = &HC0C0C0
    Me.txtReq06.BorderColor = &HC0C0C0
    Me.txtReq06.ForeColor = &HC0C0C0
    Me.chkReq06.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq07_Change()
If Me.txtReq07.Value <> "" Then
    Me.lblReq07.ForeColor = &H8080FF
    Me.txtReq07.BorderColor = &H8080FF
    Me.txtReq07.ForeColor = &H8080FF
    Me.chkReq07.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq07.ForeColor = &HC0C0C0
    Me.txtReq07.BorderColor = &HC0C0C0
    Me.txtReq07.ForeColor = &HC0C0C0
    Me.chkReq07.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq08_Change()
If Me.txtReq08.Value <> "" Then
    Me.lblReq08.ForeColor = &H8080FF
    Me.txtReq08.BorderColor = &H8080FF
    Me.txtReq08.ForeColor = &H8080FF
    Me.chkReq08.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq08.ForeColor = &HC0C0C0
    Me.txtReq08.BorderColor = &HC0C0C0
    Me.txtReq08.ForeColor = &HC0C0C0
    Me.chkReq08.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq09_Change()
If Me.txtReq09.Value <> "" Then
    Me.lblReq09.ForeColor = &H8080FF
    Me.txtReq09.BorderColor = &H8080FF
    Me.txtReq09.ForeColor = &H8080FF
    Me.chkReq09.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq09.ForeColor = &HC0C0C0
    Me.txtReq09.BorderColor = &HC0C0C0
    Me.txtReq09.ForeColor = &HC0C0C0
    Me.chkReq09.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq10_Change()
If Me.txtReq10.Value <> "" Then
    Me.lblReq10.ForeColor = &H8080FF
    Me.txtReq10.BorderColor = &H8080FF
    Me.txtReq10.ForeColor = &H8080FF
    Me.chkReq10.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq10.ForeColor = &HC0C0C0
    Me.txtReq10.BorderColor = &HC0C0C0
    Me.txtReq10.ForeColor = &HC0C0C0
    Me.chkReq10.Picture = Me.chkReqOff.Picture
End If
End Sub
```

