# Imagem do projeto — Access ↔ MySQL

Primeira fatia da **Parte 2** (desenvolvimento). Sincroniza a **imagem de
visualização** do dispositivo entre o workbook `Lista de Solicitações` e a web.

> 📎 **Código 100% completo (antes/depois):** [imagem-projeto-codigo.md](imagem-projeto-codigo.md).

---

## 1. Como cada lado guardava (ANTES)

| | Access (`Lista`) | Web (MySQL) |
|---|---|---|
| **Onde** | arquivo plano `.img_sl\SL{ref}.jpg` | `solic_dispositivos_files/{ref}/imagem/<nome>` |
| **Registro** | nenhum (identidade = nome do arquivo) | `solicitacao_anexo_cargas` + `solicitacao_anexo_arquivos` (tipo `IMAGEM_PROJETO`) |
| **Gatilho** | `frmaut.btnLoadImage` | `storeImagemProjeto` |
| **Sincronizava?** | ❌ não — cada lado guardava só na sua pasta | ❌ não |

O nome canônico do arquivo no Access é **`SL{ref}.jpg`** (ref com 4 dígitos —
ver `M_Abre_UF.Carrega_campos`, que faz `LoadPicture(".img_sl\SL" & Format(ref,"0000") & ".jpg")`).

---

## 2. Como ficou (DEPOIS)

```
Access troca a imagem (frmaut.btnLoadImage)
   → copia p/ K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\SL{ref}.jpg   (local, como antes)
   → enviarImagemParaMySQL (POST binário) ─────► uploadImagemVba (web)
                                                  cria carga + arquivo IMAGEM_PROJETO + histórico

Web troca a imagem (storeImagemProjeto)
   → salva em .../{ref}/imagem/ + registra
   → copiarImagemParaAccess → {APP_ACCESS_DIR}/.img_sl/SL{ref}.jpg
   → Carrega_campos já exibe no Access
```

| | ANTES | DEPOIS |
|---|---|---|
| Imagem trocada no Access subia? | ❌ | ✅ `enviarImagemParaMySQL` → `uploadImagemVba` |
| Imagem trocada na web descia? | ❌ | ✅ `copiarImagemParaAccess` → pasta mapeada |
| Caminhos VBA | `F:\eng_ind\...` / `ChDrive("K")` | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\` |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — rota + `uploadImagemVba` (Access → Web)
- **Rota:** `POST /dispositivos/desenvolvimento/uploadImagemVba` (ref + nome via query string).
- **Método:** lê o binário cru (`php://input`); cria a carga (`SolicitacaoAnexoCarga`),
  remove a imagem anterior (`removerArquivosExistentesPorTipo`), grava o arquivo a
  partir dos **bytes** (não há `$_FILES`, então não usa `move_uploaded_file`),
  registra em `solicitacao_anexo_arquivos` (tipo `IMAGEM_PROJETO`) e adiciona ao
  `Historico`. **Sem trava de status** — espelha a ação do Access (decisão do usuário).

### 3.2 PHP — `copiarImagemParaAccess` (Web → Access)
- Após o commit do `storeImagemProjeto`, copia o arquivo salvo para
  `{APP_ACCESS_DIR}/.img_sl/SL{ref}.jpg` (4 dígitos), o nome exato que o VBA lê.
- Espelho do `copiarAnexosParaAccess` da Parte 1.

### 3.3 VBA — `Funcoes` (helpers HTTP)
Este workbook ainda não tinha os helpers (estavam só no de Solicitação). Adicionados:
- `urlBaseApp()` — base da web.
- `enc()` — `EncodeURL` p/ querystring.
- `enviarImagemParaMySQL(ref, caminho)` — lê o `.jpg` via `ADODB.Stream` e faz POST
  binário (`application/octet-stream`), igual ao `enviarPdfParaMySQL` da Parte 1.

### 3.4 VBA — `frmaut.btnLoadImage` (gatilho Access → Web)
- Caminho `F:\eng_ind\...\.img_sl\` → `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\`.
- Nome do arquivo reforçado para `SL{0000}.jpg` (bate com `Carrega_campos`).
- Chama `enviarImagemParaMySQL refNum, newPathJPG`.

### 3.5 VBA — caminhos corrigidos
- `frmaut.lbl_abrir` e `M_Abre_UF.Carrega_campos`: `F:\...` → `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\`.
- `Funcoes.AbreJPG`: `ChDrive("K")` → `ChDrive("D")` + `ChDir("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")`.

---

## 4. Passo a passo para testar

1. **Re-deploy** do `routes.php` + `DesenvolvimentoController.php`.
2. Aplicar o VBA atualizado (`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\Funcoes.txt`,
   `M_Abre_UF.txt`, `frmaut.txt`).
3. No `frmaut`, troque a imagem de uma SL → confira:
   - `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\SL{ref}.jpg` criado;
   - na web, registro `IMAGEM_PROJETO`:
     ```sql
     SELECT ref, tipo, nome_arquivo FROM bd_device_request.solicitacao_anexo_arquivos
      WHERE ref = <REF> AND tipo = 'IMAGEM_PROJETO';
     ```
4. Troque a imagem **pela web** → reabra a SL no Access → a imagem nova aparece
   (veio de `{APP_ACCESS_DIR}/.img_sl/SL{ref}.jpg`).

---

## 5. Limitações / escopo

- **Sem trava de status** na rota VBA (a web exige Conceito=OK + Detalhe=OK; o
  Access não). Decisão: espelhar sempre a ação do Access.
- Conflito real só se a MESMA SL trocar imagem nos dois lados quase ao mesmo tempo
  → vence o último a gravar no MySQL (e o pull/cópia reflete esse).
- As outras caixas de diálogo do `Funcoes` (`AbreXLS`, `AbreZIP`, `AbrePDF`,
  `OpenTXTDialog`) ainda usam `ChDrive("K")` — serão corrigidas nas fatias DXF/PDF/BOM.

---

## 6. Arquivos-chave

| Item | Caminho |
|---|---|
| Rota | `src/routes/routes.php` → `dispositivos/desenvolvimento/uploadImagemVba` |
| Método Access→Web | `DesenvolvimentoController::uploadImagemVba` |
| Método Web→Access | `DesenvolvimentoController::copiarImagemParaAccess` (chamado no `storeImagemProjeto`) |
| VBA helpers | `Funcoes` → `urlBaseApp`, `enc`, `enviarImagemParaMySQL` |
| VBA gatilho | `frmaut` → `btnLoadImage` |
| VBA exibição | `M_Abre_UF` → `Carrega_campos` |
| Módulos prontos | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\{Funcoes,M_Abre_UF,frmaut}.txt` |
