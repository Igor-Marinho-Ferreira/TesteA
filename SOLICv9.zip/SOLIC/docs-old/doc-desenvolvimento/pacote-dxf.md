# Pacote DXF — Access ↔ MySQL

Terceira fatia da **Parte 2** (desenvolvimento). Sincroniza os **pacotes DXF**
(cortes — um zip por pacote) entre o workbook `Lista de Solicitações` e a web.

> 📎 **Código 100% completo (antes/depois):** [pacote-dxf-codigo.md](pacote-dxf-codigo.md).

---

## 1. O problema da numeração (e a solução)

| | Access (`DXF_Control`) | Web (antes) |
|---|---|---|
| Código | `Controle` = **AutoNumber global** → `DX0001` | `gerarProximoCodigoDxf` = **`DXF001` por-SL** |
| Metadados | Descricao, Prioridade, Status corte, Projetista, Projeto, IMG | nenhum (só arquivo + código) |
| Arquivo | `.dxf\DX0001.zip` (+ imagem `.imgs\DX0001.jpg`) | `.../dxf/<nome>` |

As numerações **não batiam** (global×por-SL, formatos diferentes). Decisão:
**unificar na regra do Access (global `DX`+4 díg.) com o MySQL como cartório** —
exatamente o que vocês fizeram com o `Ref`.

```
Access cria DXF (ufdxf)
   → pede o número à web:  GET nextDxf?floor=MAX(Controle)   → "DX0005" (GET_LOCK)
   → INSERT DXF_Control (Controle=5, ...)   [Controle agora é Número, não AutoNumber]
   → copia zip p/ K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.dxf\DX0005.zip (+ imagem .imgs\)
   → enviarDxfParaMySQL ──► uploadDxfVba  (PACOTE_DXF, codigo="DX0005")

Web cria DXF (storePacoteDxf)
   → gerarProximoCodigoDxf = global DX (mesma regra)  [piso APP_DXF_FLOOR]
   → copiarDxfParaAccess → {APP_ACCESS_DIR}/.dxf/DX0005.zip     (o arquivo)
   → sincronizarDxfsDoMySQL (no Access) baixa csvDxf e upserta DXF_Control  (a linha)
```

**Piso (`APP_DXF_FLOOR`):** como o histórico do `DXF_Control` não foi migrado, o
contador da web usa `max(MAX web, APP_DXF_FLOOR)`. Defina `APP_DXF_FLOOR` = `MAX(Controle)`
atual do Access para os novos números ficarem acima do legado.

---

## 2. ANTES × DEPOIS

| | ANTES | DEPOIS |
|---|---|---|
| Numeração web | `DXF001` por-SL | `DX0001` global (regra do Access) |
| Cartório do número | — | `nextDxf` (GET_LOCK), Access pede |
| `Controle` no Access | AutoNumber | **Número** (aceita o nº do MySQL) |
| DXF criado no Access subia? | ❌ | ✅ `enviarDxfParaMySQL` → `uploadDxfVba` |
| DXF da web descia (arquivo)? | ❌ | ✅ `copiarDxfParaAccess` |
| DXF da web aparecia no Access? | ❌ | ✅ `sincronizarDxfsDoMySQL` (upsert `DXF_Control`) |
| Caminhos VBA | `F:\eng_ind\...` | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\` |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — numeração (regra do Access) + cartório
- `gerarProximoCodigoDxf` → **global `DX`+4 díg.** (era `DXF` por-SL); helper `proximoNumeroDxfGlobal`.
- **`nextDxf`** (rota GET, `GET_LOCK('solic_dxf')`) devolve `{controle, codigo}`; aceita `?floor=N`.

### 3.2 PHP — push/pull do arquivo
- `uploadDxfVba` (Access→Web): zip cru + `codigo` (o que o Access recebeu do cartório), tipo `PACOTE_DXF`, dedup por codigo.
- `copiarDxfParaAccess` (no `storePacoteDxf`): zip → `{APP_ACCESS_DIR}/.dxf/{codigo}.zip`.
- `csvDxf` (pull): `Controle;Solicitacao;Projeto;Descricao`.

### 3.3 VBA — `Funcoes`
- `pedirProximoDxf(floor)` — GET `nextDxf`, extrai o `controle`.
- `enviarDxfParaMySQL(ref, codigo, caminho)` — POST binário do zip.
- `sincronizarDxfsDoMySQL()` — baixa o CSV e **upserta** `DXF_Control` (Controle explícito).

### 3.4 VBA — `ufdxf.btn_novo_dxf` (criar DXF)
- Pede o número ao cartório (passando `MAX(Controle)` local como piso).
- `INSERT DXF_Control (Controle, ...)` com número **explícito**.
- Caminhos `F:`→`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` (`.dxf`, `.imgs`, `.img_sl`); push do zip.

### 3.5 VBA — `uf_lista_dxf.btn_reparar` (substituir o zip)
- Caminho `F:`→`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.dxf`; reenvia o zip via `enviarDxfParaMySQL`.

### 3.6 Access — schema
- `DXF_Control.Controle`: **AutoNumeração → Número** (igual ao `Ref`).

---

## 4. Passo a passo para testar

1. No Access: `SELECT MAX(Controle) FROM DXF_Control;` → ponha o valor em `APP_DXF_FLOOR` (`.env`).
2. No Access: mude `DXF_Control.Controle` para **Número**.
3. **Re-deploy** do PHP. Aplicar VBA (`Funcoes.txt`, `ufdxf.txt`, `uf_lista_dxf.txt`).
4. No `ufdxf`, adicione um DXF → confira:
   - número veio sequencial e **igual** dos 2 lados (ex.: `DX0501`);
   - `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.dxf\DX0501.zip` criado;
   - na web:
     ```sql
     SELECT ref, tipo, codigo FROM bd_device_request.solicitacao_anexo_arquivos
      WHERE tipo = 'PACOTE_DXF' AND codigo = 'DX0501';
     ```
5. Crie um DXF **pela web** → rode `sincronizarDxfsDoMySQL` no Access → aparece no `DXF_Control`/`dxf_lst`.

---

## 5. Limitações / escopo

- **Metadados ricos** (Descricao/Prioridade/Status corte/Projetista) só existem no Access.
  DXF criado **pela web** entra no Access com Descrição = nome do arquivo e demais campos vazios.
- **Imagem do DXF** (`.imgs\{cod}.jpg`): o Access gera ao criar; a web **não** copia a imagem do
  DXF (só o zip) — fica como melhoria.
- **`UF.btn_carregar`** (carga em massa da criação do dev) **não** entra aqui — mistura imagem/PDF/BOM/DXF, fica para a fatia de criação.
- **Reserva do número:** `nextDxf` serializa com `GET_LOCK`, mas só reserva durante a leitura
  (não grava placeholder). Criações simultâneas no mesmo instante são raras; se virar problema,
  dá pra reservar inserindo um registro placeholder sob o lock.

---

## 6. Arquivos-chave

| Item | Caminho |
|---|---|
| Cartório do número | `routes.php` → `dispositivos/desenvolvimento/nextDxf` · `DesenvolvimentoController::nextDxf` |
| Rota push | `dispositivos/desenvolvimento/uploadDxfVba` |
| Rota pull (CSV) | `dispositivos/csvAtualizado/dxf` |
| Web→Access (arquivo) | `DesenvolvimentoController::copiarDxfParaAccess` (no `storePacoteDxf`) |
| Web→Access (registro) | `DesenvolvimentoController::csvDxf` + VBA `sincronizarDxfsDoMySQL` |
| VBA número | `Funcoes.pedirProximoDxf` |
| VBA push | `Funcoes.enviarDxfParaMySQL` + `ufdxf.btn_novo_dxf` + `uf_lista_dxf.btn_reparar` |
| Piso | `.env` → `APP_DXF_FLOOR` |
| Módulos prontos | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\{Funcoes,ufdxf,uf_lista_dxf}.txt` |
