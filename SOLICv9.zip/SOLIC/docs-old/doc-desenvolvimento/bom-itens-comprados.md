# BOM / Itens comprados — Access ↔ MySQL

Quarta e **última** fatia da Parte 2. Sincroniza as **linhas da lista de materiais
/ itens comprados** entre o workbook `Lista de Solicitações` e a web.

> 📎 **Código 100% completo (antes/depois):** [bom-itens-comprados-codigo.md](bom-itens-comprados-codigo.md).

---

## 1. Como cada lado guarda

| | Access | Web |
|---|---|---|
| Tabela | `BOM_Control` (Controle, Codigo, Revisao, Descricao, Qtde, Tipo, **OC**) | `solicitacao_itens_comprados` (codigo, rev, descricao, quantidade, tipo) |
| Origem | `frm_bom` (carrega TXT largura-fixa em campos `cod1..N`, depois `btnInserir`) | `storeItensCompradosTxt` (parseia TXT delimitado) |
| Identidade | `Controle` (AutoNumber, PK interna) | `id` (uuid) |
| Aquisição | `OC_Control` (join por OC) | — (não modela OC) |

**Chave compartilhada:** `Solicitacao + Codigo + Revisao`. Os campos batem 1:1
(menos a OC/aquisição, que é processo só do Access). **Sem cartório e sem mudança de
schema** — o `Controle` é só PK interna.

---

## 2. Como ficou (DEPOIS)

```
Access insere itens (frm_bom.btnInserir, modo Auto)
   → INSERT BOM_Control (por item)
   → acumula o lote (codigo<TAB>rev<TAB>desc<TAB>qtde<TAB>tipo por linha)
   → enviarBomParaMySQL (1 POST do lote) ──► uploadBomVba
                                              insere em solicitacao_itens_comprados (dedup por codigo+rev)

Web adiciona itens (storeItensCompradosTxt: parseia o TXT)
   → sincronizarBomDoMySQL (no Access) baixa csvBom e faz upsert em BOM_Control
```

| | ANTES | DEPOIS |
|---|---|---|
| BOM inserida no Access subia? | ❌ | ✅ `enviarBomParaMySQL` → `uploadBomVba` |
| Itens da web desciam pro Access? | ❌ | ✅ `sincronizarBomDoMySQL` (upsert `BOM_Control`) |
| Dedup | — | por `ref + codigo + rev` nos 2 lados |
| Caminho `.bom` (xlsx) | `F:\eng_ind\...` | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.bom` |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — `uploadBomVba` (Access → Web)
- **Rota:** `POST /dispositivos/desenvolvimento/uploadBomVba` (form-urlencoded: `ref` + `dados`).
- `dados` = linhas `codigo\trev\tdescricao\tqtde\ttipo`. Insere em
  `solicitacao_itens_comprados` os que ainda não existem (dedup por `codigo+rev`),
  sob uma carga + um arquivo "marcador" (`BOM (Access)`, sem TXT físico). Sem trava.

### 3.2 PHP — `csvBom` (Web → Access)
- CSV `Solicitacao;Projeto;Codigo;Revisao;Descricao;Qtde;Tipo` (limpa `;`/quebras
  dos campos livres, pro `Split` simples do VBA).

### 3.3 VBA — `Funcoes`
- `enviarBomParaMySQL(ref, payload)` — POST do lote (form-urlencoded, `enc()` no payload).
- `sincronizarBomDoMySQL()` — baixa o CSV e **upserta** `BOM_Control` (insere os que
  faltam por `Solicitacao+Codigo+Revisao`; `Controle` segue AutoNumber).

### 3.4 VBA — `frm_bom.btnInserir` (modo Auto)
- Acumula cada item num `bomPayload` (campos por `vbTab`, linhas por `vbLf`) e, após os
  `INSERT BOM_Control`, chama `enviarBomParaMySQL`.

### 3.5 VBA — `frmaut`/`frmsol.btn_bom_novo`
- Caminho do xlsx `.bom`: `F:\eng_ind\...` → `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.bom` (o arquivo em si **não**
  é sincronizado — a web usa as linhas, não o xlsx).

---

## 4. Passo a passo para testar

1. **Re-deploy** do PHP. Aplicar VBA (`Funcoes.txt`, `frm_bom.txt`, `frmaut.txt`, `frmsol.txt`).
2. No Access, carregue um TXT no `frm_bom` (`btnCarregar`) e clique **Inserir** (Auto) → confira:
   - linhas em `BOM_Control`;
   - na web:
     ```sql
     SELECT ref, codigo, rev, descricao, quantidade, tipo
       FROM bd_device_request.solicitacao_itens_comprados WHERE ref = <REF>;
     ```
3. Adicione itens **pela web** (TXT) → rode `sincronizarBomDoMySQL` no Access → aparecem
   no `BOM_Control`/`bom_lst`.

---

## 5. Limitações / escopo

- **OC / aquisição** (`OC_Control`, status de compra) **não** é sincronizada — é processo
  só do Access; a web não modela.
- **Arquivo BOM (xlsx)** não é sincronizado (só as linhas). O TXT da web vira linhas;
  a BOM do Access vira linhas — o arquivo em si fica em cada lado.
- **Exclusão** de item não sincroniza (o pull só **insere** os que faltam).
- `UF.btn_carregar` (carga em massa da criação do dev) continua fora (fatia de criação).

---

## 6. Arquivos-chave

| Item | Caminho |
|---|---|
| Rota push | `routes.php` → `dispositivos/desenvolvimento/uploadBomVba` |
| Rota pull (CSV) | `dispositivos/csvAtualizado/bom` |
| Método Access→Web | `DesenvolvimentoController::uploadBomVba` |
| Método Web→Access | `DesenvolvimentoController::csvBom` + VBA `sincronizarBomDoMySQL` |
| VBA push | `Funcoes.enviarBomParaMySQL` + `frm_bom.btnInserir` |
| VBA pull | `Funcoes.sincronizarBomDoMySQL` |
| Módulos prontos | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\{Funcoes,frm_bom,frmaut,frmsol}.txt` |
