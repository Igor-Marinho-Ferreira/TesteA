# Desenhos PDF — Código 100% (ANTES / DEPOIS completos)

Fatia 2 da Parte 2. Para **cada** artefato: **ANTES 100%** e **DEPOIS 100%**.
Visão geral em [desenhos-pdf.md](desenhos-pdf.md).

> O **ANTES** dos módulos VBA já inclui as mudanças da fatia *imagem* (cada fatia
> parte da anterior). Módulos prontos cumulativos: `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\*.txt`.

| Artefato | Mudou nesta fatia |
|---|---|
| `routes.php` | +2 rotas (`uploadDesenhoPdfVba`, `csvAtualizado/desenhosPdf`) |
| `storeDesenhosPdf` | grava `codigo` + copia PDFs pro Access |
| `DesenvolvimentoController` (novos) | `uploadDesenhoPdfVba`, `removerArquivoDesenhoPorCodigo`, `copiarDesenhoPdfParaAccess`, `csvDesenhosPdf` |
| VBA `Funcoes` | +`enviarPdfDesenhoParaMySQL`, +`sincronizarPdfsDoMySQL` |
| VBA `frmaut` | `btn_pdf_novo_Click` (caminhos+envio) + `pdf_lst_DblClick` (abrir) |
| VBA `frmsol` | `btn_pdf_novo_Click` (caminhos+envio) + `pdf_lst_DblClick` (abrir) |

---

## 1. PHP — `src/routes/routes.php` (bloco do PDF)

### ANTES
```php
Route::post('/dispositivos/desenvolvimento/pdf/{ref}/store', DesenvolvimentoController::class, 'storeDesenhosPdf')
    ->name('dispositivos.desenvolvimento.pdf.store')
    ->whereint(['ref']);
```

### DEPOIS
```php
Route::post('/dispositivos/desenvolvimento/pdf/{ref}/store', DesenvolvimentoController::class, 'storeDesenhosPdf')
    ->name('dispositivos.desenvolvimento.pdf.store')
    ->whereint(['ref']);

// Access -> Web: recebe UM desenho PDF (frmaut.btn_pdf_novo) em binario cru.
// Parametros via query string: ?ref=NNN&codigo=XXX&nome=arquivo.pdf
Route::post('/dispositivos/desenvolvimento/uploadDesenhoPdfVba', DesenvolvimentoController::class, 'uploadDesenhoPdfVba')
    ->name('dispositivos.desenvolvimento.uploadDesenhoPdfVba');

// Web -> Access (pull): CSV dos desenhos PDF p/ o VBA upsertar em PDF_Control.
Route::get('/dispositivos/csvAtualizado/desenhosPdf', DesenvolvimentoController::class, 'csvDesenhosPdf')
    ->name('dispositivos.atualizaCSV.desenhosPdf');
```

---

## 2. PHP — `DesenvolvimentoController::storeDesenhosPdf` (método inteiro)

### ANTES (método 100%)
```php
    public function storeDesenhosPdf(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar PDF quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        $desenhosPdf = $this->normalizarFilesArray($_FILES['desenhos_pdf'] ?? null);

        if (empty($desenhosPdf)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione ao menos um PDF válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosCriadosFisicamente = [];

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga dos PDFs.");
            }

            $qtdSalvos = 0;

            foreach ($desenhosPdf as $pdf) {
                if (!$this->arquivoValido($pdf)) {
                    continue;
                }

                $this->validarExtensaoArquivo($pdf, ['pdf'], 'desenho PDF');

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $saveCarga['id'],
                    $ref,
                    $pdf,
                    'DESENHO_PDF',
                    "{$baseUploadDir}/desenhos_pdf",
                    "{$baseUploadPath}/desenhos_pdf",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
                $qtdSalvos++;
            }

            if ($qtdSalvos === 0) {
                throw new \Exception("Nenhum PDF válido foi enviado.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$qtdSalvos} desenho(s) PDF adicionado(s) à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("PDF(s) salvo(s) com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar PDF da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar os PDFs.");
        }
    }
```

### DEPOIS (método 100%)
```php
    public function storeDesenhosPdf(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar PDF quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        $desenhosPdf = $this->normalizarFilesArray($_FILES['desenhos_pdf'] ?? null);

        if (empty($desenhosPdf)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione ao menos um PDF válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosCriadosFisicamente = [];

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga dos PDFs.");
            }

            $qtdSalvos = 0;
            $pdfsParaAccess = []; // [ ['codigo'=>..., 'fisico'=>...], ... ]

            foreach ($desenhosPdf as $pdf) {
                if (!$this->arquivoValido($pdf)) {
                    continue;
                }

                $this->validarExtensaoArquivo($pdf, ['pdf'], 'desenho PDF');

                // codigo = nome do arquivo sem extensão (mesma identidade do Access/PDF_Control)
                $codigo = pathinfo($pdf['name'] ?? '', PATHINFO_FILENAME);

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $saveCarga['id'],
                    $ref,
                    $pdf,
                    'DESENHO_PDF',
                    "{$baseUploadDir}/desenhos_pdf",
                    "{$baseUploadPath}/desenhos_pdf",
                    $usuarioLogado,
                    $codigo
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
                $pdfsParaAccess[] = ['codigo' => $codigo, 'fisico' => $arquivoSalvo['caminho_fisico']];
                $qtdSalvos++;
            }

            if ($qtdSalvos === 0) {
                throw new \Exception("Nenhum PDF válido foi enviado.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$qtdSalvos} desenho(s) PDF adicionado(s) à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            // Web -> Access: copia cada PDF pra pasta mapeada (.desenhos/SL{ref} - {codigo}.pdf)
            foreach ($pdfsParaAccess as $p) {
                $this->copiarDesenhoPdfParaAccess($ref, $p['codigo'], $p['fisico']);
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("PDF(s) salvo(s) com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar PDF da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar os PDFs.");
        }
    }
```

---

## 3. PHP — métodos NOVOS no `DesenvolvimentoController`

`uploadDesenhoPdfVba` (Access→Web), `removerArquivoDesenhoPorCodigo`,
`copiarDesenhoPdfParaAccess` (Web→Access) e `csvDesenhosPdf` (pull). **ANTES: não existiam.**

### DEPOIS (100%)
```php
    /**
     * Access -> Web: recebe UM desenho PDF enviado pelo VBA (frmaut.btn_pdf_novo)
     * como corpo binário cru. Registra como DESENHO_PDF com o `codigo` (= nome do
     * arquivo, igual ao PDF_Control do Access). Se já houver um PDF de mesmo
     * codigo nesta SL, substitui. SEM trava de status — espelha o Access.
     * Parâmetros via query string: ?ref=NNN&codigo=XXX&nome=arquivo.pdf
     */
    public function uploadDesenhoPdfVba()
    {
        $ref    = (int) (Request::query('ref') ?? 0);
        $codigo = trim((string) (Request::query('codigo') ?? ''));
        $nome   = Request::query('nome') ?: (($codigo !== '' ? $codigo : ('SL' . $ref)) . '.pdf');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }
        if ($codigo === '') {
            return Json::return(['error' => 'codigo obrigatório'], 400);
        }

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado = 'ACCESS';

        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do PDF.");
            }

            // Substitui o PDF anterior de MESMO codigo (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivoDesenhoPorCodigo($ref, $codigo);

            $diretorioFisico   = "{$baseUploadDir}/desenhos_pdf";
            $diretorioRelativo = "{$baseUploadPath}/desenhos_pdf";
            if (!is_dir($diretorioFisico)) {
                mkdir($diretorioFisico, 0777, true);
            }

            $nomeSeguro      = $this->gerarNomeArquivoSeguro((string) $ref, 'DESENHO_PDF', 'pdf');
            $caminhoFisico   = "{$diretorioFisico}/{$nomeSeguro}";
            $caminhoRelativo = "{$diretorioRelativo}/{$nomeSeguro}";

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar o PDF.");
            }
            $caminhoFisicoNovo = $caminhoFisico;

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'DESENHO_PDF',
                'codigo'        => $codigo,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'application/pdf',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);

            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro do PDF.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Desenho PDF '{$codigo}' adicionado (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro, 'codigo' => $codigo], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }
            error_log("Erro no uploadDesenhoPdfVba {$ref}/{$codigo}: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar PDF'], 500);
        }
    }

    /**
     * Remove (registro + retorna caminhos físicos) o desenho PDF de mesmo codigo
     * de uma SL, para que o re-upload substitua em vez de duplicar.
     */
    private function removerArquivoDesenhoPorCodigo(string $ref, string $codigo): array
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT *
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref
              AND tipo = 'DESENHO_PDF'
              AND codigo = :codigo
        ");
        $stmt->execute([':ref' => $ref, ':codigo' => $codigo]);
        $arquivos = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        if (empty($arquivos)) {
            return [];
        }

        $fisicos = [];
        foreach ($arquivos as $arquivo) {
            $arquivoId = $arquivo->id ?? null;
            if (!$arquivoId) {
                continue;
            }

            $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');
            if (!empty($caminhoFisico)) {
                $fisicos[] = $caminhoFisico;
            }

            $pdo->prepare("DELETE FROM bd_device_request.solicitacao_anexo_arquivos WHERE id = :id")
                ->execute([':id' => $arquivoId]);
        }

        return $fisicos;
    }

    /**
     * Web -> Access: copia um desenho PDF para a pasta mapeada, com o nome que o
     * VBA espera: .desenhos/SL{ref} - {codigo}.pdf  (ver frmsol.pdf_lst_DblClick).
     */
    private function copiarDesenhoPdfParaAccess($ref, string $codigo, string $caminhoFisico): void
    {
        if (empty($caminhoFisico) || !is_file($caminhoFisico) || $codigo === '') {
            return;
        }

        $base = rtrim($_ENV['APP_ACCESS_DIR'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') {
            return; // sem pasta mapeada configurada -> não faz nada
        }

        $dir = $base . '/.desenhos';
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
        }

        $sl = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT);
        @copy($caminhoFisico, $dir . '/' . $sl . ' - ' . $codigo . '.pdf'); // ex.: SL4001 - DESENHO01.pdf
    }

    /**
     * Web -> Access (pull): CSV de todos os desenhos PDF (DESENHO_PDF) para o VBA
     * upsertar em PDF_Control. Colunas: Solicitacao;Projeto;Codigo;Revisao.
     * Solicitacao no formato do Access ("SL"+4 dígitos); Projeto = cod_z da SL.
     */
    public function csvDesenhosPdf()
    {
        if (ob_get_level()) ob_end_clean();

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=DesenhosPdf.csv');

        $pdo = SolicitacaoAnexoArquivo::getPDO();
        $rows = $pdo->query("
            SELECT a.ref AS ref, a.codigo AS codigo, s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_anexo_arquivos a
            LEFT JOIN bd_device_request.solicitacoes s ON s.ref = a.ref
            WHERE a.tipo = 'DESENHO_PDF'
              AND a.codigo IS NOT NULL AND a.codigo <> ''
            ORDER BY a.ref, a.codigo
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');
        fputs($file, "\xEF\xBB\xBF");
        fputcsv($file, ['Solicitacao', 'Projeto', 'Codigo', 'Revisao'], ';');

        foreach ($rows as $r) {
            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);
            fputcsv($file, [$sl, $r->cod_z ?? '', $r->codigo, '0'], ';');
        }
        fclose($file);
        exit;
    }
```

---

## 4. VBA — módulo `Funcoes` (inteiro)

ANTES = pós-imagem; DEPOIS = +`enviarPdfDesenhoParaMySQL` e +`sincronizarPdfsDoMySQL`.

### ANTES (100%)
```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("D")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ChDir ("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
'==================== INTEGRACAO COM A WEB (MySQL) ====================
' Base da aplicacao web (mesma do workbook de Solicitacao)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Codifica um valor para querystring (UTF-8)
Public Function enc(ByVal v As Variant) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Access -> Web: envia a imagem do projeto (bytes) para a rota uploadImagemVba.
' ref = numero da SL (so o numero, sem "SL"); caminhoArquivo = .jpg local.
Public Function enviarImagemParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarImagemParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "Imagem nao encontrada para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadImagemVba?ref=" & ref & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarImagemParaMySQL = True
    Else
        MsgBox "Falha ao enviar imagem (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar imagem para a web:" & vbCrLf & Err.Description, vbCritical
End Function

```

### DEPOIS (100%)
```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("D")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ChDir ("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
'==================== INTEGRACAO COM A WEB (MySQL) ====================
' Base da aplicacao web (mesma do workbook de Solicitacao)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Codifica um valor para querystring (UTF-8)
Public Function enc(ByVal v As Variant) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Access -> Web: envia a imagem do projeto (bytes) para a rota uploadImagemVba.
' ref = numero da SL (so o numero, sem "SL"); caminhoArquivo = .jpg local.
Public Function enviarImagemParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarImagemParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "Imagem nao encontrada para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadImagemVba?ref=" & ref & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarImagemParaMySQL = True
    Else
        MsgBox "Falha ao enviar imagem (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar imagem para a web:" & vbCrLf & Err.Description, vbCritical
End Function
' Access -> Web: envia UM desenho PDF (bytes) para a rota uploadDesenhoPdfVba.
' ref = numero da SL; codigo = nome do arquivo sem extensao; caminho = .pdf local.
Public Function enviarPdfDesenhoParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarPdfDesenhoParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "PDF nao encontrado para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDesenhoPdfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarPdfDesenhoParaMySQL = True
    Else
        MsgBox "Falha ao enviar PDF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar PDF para a web:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de desenhos PDF e faz upsert em PDF_Control.
' Os arquivos ja sao copiados pela web para .desenhos\ ; aqui so garantimos a
' linha em PDF_Control para o desenho aparecer na pdf_lst.
Public Sub sincronizarPdfsDoMySQL()
    Dim http        As Object
    Dim txt         As String
    Dim linhas()    As String
    Dim campos()    As String
    Dim i           As Long
    Dim sol         As String, proj As String, cod As String, rev As String
    Dim SQL         As String
    Dim ArrChk      As Variant
    Dim inseridos   As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/desenhosPdf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de PDFs (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM

    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                sol = Trim(campos(0))
                proj = Trim(campos(1))
                cod = Trim(campos(2))
                rev = Trim(campos(3))

                SQL = "SELECT Codigo FROM PDF_Control WHERE Codigo = '" & Replace(cod, "'", "''") & _
                      "' AND Solicitacao = '" & Replace(sol, "'", "''") & "';"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ('" & _
                          Replace(proj, "'", "''") & "','" & Replace(sol, "'", "''") & "','" & _
                          Replace(cod, "'", "''") & "','" & Replace(rev, "'", "''") & "');"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de PDFs concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar PDFs:" & vbCrLf & Err.Description, vbCritical
End Sub

```

---

## 5. VBA — `frmaut` (módulo inteiro)

Mudou `btn_pdf_novo_Click` (caminhos `F:`→`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` + `enviarPdfDesenhoParaMySQL`)
e `pdf_lst_DblClick` (caminho de abrir o PDF). ANTES = pós-imagem.

### ANTES (100%)
```vb
Attribute VB_Name = "frmaut"
Attribute VB_Base = "0{30BCCC7C-89F3-408D-8AAC-1376B95D71EE}{7DF0D717-93C6-4979-908D-92EAD7F3867F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False


Private Sub btn_bom_Click()

    cod_z = frmsol.lbl_codz.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="F:\eng_ind\PROJETOS_Controle\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


End Sub

Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_docs_Click()
    
    UF.lbl_codSL.Caption = Me.lbl_ref.Caption
    UF.lbl_codz.Caption = Me.lbl_cod_z.Caption
    UF.lbl_descricao_SL.Caption = Me.lbl_desc
    
    UF.Show

End Sub

Private Sub btn_dxf_novo_Click()
    ufdxf.Show
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.cmb_autor.Text
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)


End Sub

Private Sub btn_ok_Click()

    Unload Me
    
    filtro = Sheets("Fila").Range("M4").Value
    If filtro = 0 Then Listar_todos
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06
    If filtro = 7 Then filtro_07
    If filtro = 8 Then Listar_analise
    If filtro = 9 Then Lista_SL (Range("H4").Value)
    If filtro = 10 Then Lista_Z (Range("G4").Value)
    If filtro = 11 Then Call Lista_VG(Range("I4").Value, Range("G5").Value)
    If filtro = 12 Then Call Lista_Solic(Range("G5").Value, Range("I4").Value)
    If filtro = 13 Then filtro_08
    If filtro = 14 Then Call Lista_Projetista(Range("K4").Value, Range("I4").Value)
    If filtro = 15 Then Lista_Novos

End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(ln, 2).Value = li1.Text
                .Cells(ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(ln, 16).Value = li1.ListSubItems(3).Text
                ln = ln + 1
        Next a
                
        'Carrega OCs
        ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(ln, 17).Value = li2.ListSubItems(7).Text 'Status
                ln = ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("F:\eng_ind\PROJETOS_Controle\Controle\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    

    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
        Sheets("Fila").Activate
    
        Unload Me

End Sub


Private Sub carrega_pdf_Click()

End Sub

Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "F:\eng_ind\PROJETOS_Controle\Controle\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub

Private Sub btn_pdf_novo_Click()
    Dim SQL As String
    Dim SQL_pdf As String
    lista_PDF = AbrePDF()
    
    t_cod_z = frmsol.lbl_cod_z.Caption
    t_cod_sl = frmsol.lbl_ref.Caption
    
    If Not IsEmpty(lista_PDF) Then
        For a = 1 To UBound(lista_PDF)
            caminho = lista_PDF(a)
            pos = InStrRev(caminho, "\", , vbTextCompare)
            codigo = Mid(caminho, pos + 1, Len(caminho) - pos)
            codigo = Replace(codigo, ".PDF", "")
            codigo = Replace(codigo, ".pdf", "")
                       
            t_codigo_pdf = codigo
            t_caminho_pdf = caminho
            
            SQL_pdf = "SELECT Codigo From PDF_Control WHERE Codigo = '" & t_codigo_pdf & "' AND Solicitacao = '" & t_cod_sl & "';"
            ArrPDF = resQuery(SQL_pdf)
            
            If IsEmpty(ArrPDF) Then
                SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo_pdf & "',"
                SQL = SQL & "'0');"
                upQuery (SQL)
            End If
            
            Dim oldPathPDF As String, newPathPDF As String
            oldPathPDF = t_caminho_pdf
            
            newPath = "F:\eng_ind\PROJETOS_Controle\Controle\desenhosPDF\" & t_cod_sl
            
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            
            newPathPDF = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            


            oldPathPDF = t_caminho_pdf
            newPath = "F:\eng_ind\PROJETOS_Controle\Controle\desenhosPDF\" & t_cod_sl
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            newPathPDF2 = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            newPathPDF = "F:\eng_ind\PROJETOS_Controle\Controle\.desenhos\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            If oldPathPDF <> "" Then
                Set fs = CreateObject("Scripting.FileSystemObject")
                fs.CopyFile oldPathPDF, newPathPDF
                fs.CopyFile oldPathPDF, newPathPDF2
                Set fs = Nothing
            End If

        Next a
    End If
    
    MsgBox "Desenhos em PDF carregados com sucesso!"
    
    Call carrega_pdf(frmsol.lbl_ref.Caption)
    
End Sub

Private Sub btn_buy_novo_Click()
    frm_bom2.lbl_ref.Caption = frmsol.lbl_ref.Caption
    frm_bom2.lbl_desc.Caption = frmsol.lbl_desc.Caption
    frm_bom2.Show
End Sub

Private Sub btnCheck_Click()


Me.multi.Value = 2

'set cor do botão ativo
Me.btnCheck.ForeColor = &H80000012
Me.bordaCheck.BorderColor = &H808080
Me.bordaCheck.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF




End Sub

Private Sub btnDados_Click()

Me.multi.Value = 0

'set cor do botão ativo
Me.btnDados.ForeColor = &H80000012
Me.bordaDados.BorderColor = &H808080
Me.bordaDados.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF

End Sub

Private Sub btnHabilitar_Click()

If Me.det_st.Caption = "OK" Then
    Me.btn_carregar_docs.Enabled = True
    Me.btn_carregar_docs.BackColor = &H80FF80
End If

End Sub

Private Sub btnLoad_Click()
    caminho = "http://mcs.eng.br/greenbrier/upload.html"
    ufLoad.wb.Navigate (caminho)
    ufLoad.Show
End Sub

Private Sub btnLimparComprados_Click()

Dim SQL As String
Dim rq As VbMsgBoxResult
rq = MsgBox("Deseja limpar a lista de Itens Comprados?", vbYesNo, "Deletar?")

If rq = vbYes Then
    nSL = Me.lbl_ref.Caption
    SQL = "DELETE FROM BOM_Control WHERE Solicitacao = '" & sSL & "' AND OC = '';"
    upQuery (SQL)
End If


End Sub

Private Sub btnReq_Click()
Me.multi.Value = 1

'set cor do botão ativo
Me.btnReq.ForeColor = &H80000012
Me.bordaReq.BorderColor = &H808080
Me.bordaReq.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF

End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        ArrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(ArrRes(10, 0)) Then frm_dxf.pg01.Caption = ArrRes(10, 0)
        If Not IsNull(ArrRes(0, 0)) Then frm_dxf.res01.Caption = ArrRes(0, 0)
        status_pg01 = ArrRes(11, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #2
        If Not IsNull(ArrRes(12, 0)) Then frm_dxf.pg02.Caption = ArrRes(12, 0)
        If Not IsNull(ArrRes(1, 0)) Then frm_dxf.res02.Caption = ArrRes(1, 0)
        status_pg02 = ArrRes(13, 0)
        
        'MsgBox status_pg02
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #3
        If Not IsNull(ArrRes(14, 0)) Then frm_dxf.pg03.Caption = ArrRes(14, 0)
        If Not IsNull(ArrRes(2, 0)) Then frm_dxf.res03.Caption = ArrRes(2, 0)
        status_pg03 = ArrRes(15, 0)
        
        'MsgBox status_pg03
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #4
        If Not IsNull(ArrRes(16, 0)) Then frm_dxf.pg04.Caption = ArrRes(16, 0)
        If Not IsNull(ArrRes(3, 0)) Then frm_dxf.res04.Caption = ArrRes(3, 0)
        status_pg04 = ArrRes(17, 0)
        
        'MsgBox status_pg04
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #5
        If Not IsNull(ArrRes(18, 0)) Then frm_dxf.pg05.Caption = ArrRes(18, 0)
        If Not IsNull(ArrRes(4, 0)) Then frm_dxf.res05.Caption = ArrRes(4, 0)
        status_pg05 = ArrRes(19, 0)
        
        'MsgBox status_pg05
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #6
        If Not IsNull(ArrRes(20, 0)) Then frm_dxf.pg06.Caption = ArrRes(20, 0)
        If Not IsNull(ArrRes(5, 0)) Then frm_dxf.res06.Caption = ArrRes(5, 0)
        status_pg06 = ArrRes(21, 0)
        
        'MsgBox status_pg06
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #7
        If Not IsNull(ArrRes(22, 0)) Then frm_dxf.pg07.Caption = ArrRes(22, 0)
        If Not IsNull(ArrRes(6, 0)) Then frm_dxf.res07.Caption = ArrRes(6, 0)
        status_pg07 = ArrRes(23, 0)
        
        'MsgBox status_pg07
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #8
        If Not IsNull(ArrRes(24, 0)) Then frm_dxf.pg08.Caption = ArrRes(24, 0)
        If Not IsNull(ArrRes(7, 0)) Then frm_dxf.res08.Caption = ArrRes(7, 0)
        status_pg08 = ArrRes(25, 0)
        
        'MsgBox status_pg08
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #9
        If Not IsNull(ArrRes(26, 0)) Then frm_dxf.pg09.Caption = ArrRes(26, 0)
        If Not IsNull(ArrRes(8, 0)) Then frm_dxf.res09.Caption = ArrRes(8, 0)
        status_pg09 = ArrRes(27, 0)
        
        'MsgBox status_pg09
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #10
        If Not IsNull(ArrRes(28, 0)) Then frm_dxf.pg10.Caption = ArrRes(28, 0)
        If Not IsNull(ArrRes(9, 0)) Then frm_dxf.res10.Caption = ArrRes(9, 0)
        status_pg10 = ArrRes(29, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        
        
        
        frm_dxf.Show
        
        
    End If


End Sub







Private Sub Label21_Click()
    Dim SQL_Z As String
    projetista = frmsol.lbl_projetista.Caption
    cod_z = Replace(frmsol.lbl_codz.Caption, "Z", "")
    data_inicio = DateValue(Me.dt_inicio.Caption)
    data_fim = DateValue(Me.dt_fim.Caption)
    SQL_Z = "UPDATE Projetos SET Data_Inicio = '" & data_inicio & "' , Data_Fim = '" & data_fim & "' , Projetista = '" & projetista & "', Status = 'Concluído', "
    SQL_Z = SQL_Z & "Data_R_Inicio = '" & data_inicio & "' , Data_R_Fim = '" & data_fim & "' "
    SQL_Z = SQL_Z & " WHERE Controle = " & cod_z & ";"
    upQuery (SQL_Z)
    MsgBox "Projeto " & Me.lbl_codz.Caption & " atualizado!"
    Unload Me
End Sub



Private Sub btnLoadBOM_Click()
    frm_bom.lbl_ref.Caption = frmaut.lbl_ref.Caption
    frm_bom.lbl_desc.Caption = frmaut.lbl_desc.Caption
    frm_bom.lblTipo.Caption = "Auto"
    frm_bom.lblCodZ.Caption = frmaut.lbl_codz.Caption
    frm_bom.Show
End Sub

Private Sub btnLoadImage_Click()
Dim fs As Object
Dim oldPathJPG As String, newPathJPG As String
Dim refNum As Long

oldPathJPG = AbreJPG
If oldPathJPG <> "" Then
    caminho_arquivo = Left(oldPathJPG, InStrRev(oldPathJPG, "\") - 1)
    caminho_arquivo = Left(caminho_arquivo, InStrRev(caminho_arquivo, "\") - 1)

    cod_sl = frmaut.lbl_ref.Caption                   ' ex.: "SL4001"
    refNum = CLng(Replace(cod_sl, "SL", ""))          ' "SL4001" -> 4001

    Set fs = CreateObject("Scripting.FileSystemObject")
    ' Mesmo nome que Carrega_campos le (SL{0000}.jpg), na pasta mapeada
    newPathJPG = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\SL" & Format(refNum, "0000") & ".jpg"
    fs.CopyFile oldPathJPG, newPathJPG
    Set fs = Nothing
    caminho = newPathJPG
    Me.img_sl.Picture = LoadPicture(caminho)

    ' Access -> Web: envia a mesma imagem pro MySQL/web
    enviarImagemParaMySQL refNum, newPathJPG
End If
End Sub



Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & frmaut.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub

Private Sub lbl_trocar_Click()


End Sub

Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
   
    codigo = Me.pdf_lst.Text
   
    tgtfile = "F:\eng_ind\PROJETOS_Controle\Controle\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)
        
    
    
    'user = "MARCOS"
    'codigo = Me.lbl_ref & " - " & Me.pdf_lst.Text
    
    'caminho = "http://mcs.eng.br/greenbrier/copia.php?nome=" & user & "&pdf=" & codigo & ".PDF"
    'ufView.wb.Navigate (caminho)
    
    'ufView.Show
End Sub

Private Sub pdf_lst_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
Dim SQL As String
Dim res As VbMsgBoxResult

If KeyAscii = 120 Then
    codigo = Me.pdf_lst.Text
    n_sl = Me.lbl_ref.Caption
    
    res = MsgBox("Deseja EXCLUIR o desenho nº " & codigo & "?", vbYesNoCancel, "EXCLUIR?")
    If res = vbYes Then
        SQL = "DELETE FROM PDF_Control WHERE Codigo = '" & codigo & "' AND Solicitacao = '" & n_sl & "';"
        upQuery (SQL)
    End If
End If

Call carrega_pdf(frmsol.lbl_ref.Caption)

End Sub



Private Sub txtReq01_Change()
If Me.txtReq01.Value <> "" Then
    Me.lblReq01.ForeColor = &H8080FF
    Me.txtReq01.BorderColor = &H8080FF
    Me.txtReq01.ForeColor = &H8080FF
    Me.chkReq01.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq01.ForeColor = &HC0C0C0
    Me.txtReq01.BorderColor = &HC0C0C0
    Me.txtReq01.ForeColor = &HC0C0C0
    Me.chkReq01.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq02_Change()
If Me.txtReq02.Value <> "" Then
    Me.lblReq02.ForeColor = &H8080FF
    Me.txtReq02.BorderColor = &H8080FF
    Me.txtReq02.ForeColor = &H8080FF
    Me.chkReq02.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq02.ForeColor = &HC0C0C0
    Me.txtReq02.BorderColor = &HC0C0C0
    Me.txtReq02.ForeColor = &HC0C0C0
    Me.chkReq02.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq03_Change()
If Me.txtReq03.Value <> "" Then
    Me.lblReq03.ForeColor = &H8080FF
    Me.txtReq03.BorderColor = &H8080FF
    Me.txtReq03.ForeColor = &H8080FF
    Me.chkReq03.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq03.ForeColor = &HC0C0C0
    Me.txtReq03.BorderColor = &HC0C0C0
    Me.txtReq03.ForeColor = &HC0C0C0
    Me.chkReq03.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq04_Change()
If Me.txtReq04.Value <> "" Then
    Me.lblReq04.ForeColor = &H8080FF
    Me.txtReq04.BorderColor = &H8080FF
    Me.txtReq04.ForeColor = &H8080FF
    Me.chkReq04.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq04.ForeColor = &HC0C0C0
    Me.txtReq04.BorderColor = &HC0C0C0
    Me.txtReq04.ForeColor = &HC0C0C0
    Me.chkReq04.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq05_Change()
If Me.txtReq05.Value <> "" Then
    Me.lblReq05.ForeColor = &H8080FF
    Me.txtReq05.BorderColor = &H8080FF
    Me.txtReq05.ForeColor = &H8080FF
    Me.chkReq05.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq05.ForeColor = &HC0C0C0
    Me.txtReq05.BorderColor = &HC0C0C0
    Me.txtReq05.ForeColor = &HC0C0C0
    Me.chkReq05.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq06_Change()
If Me.txtReq06.Value <> "" Then
    Me.lblReq06.ForeColor = &H8080FF
    Me.txtReq06.BorderColor = &H8080FF
    Me.txtReq06.ForeColor = &H8080FF
    Me.chkReq06.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq06.ForeColor = &HC0C0C0
    Me.txtReq06.BorderColor = &HC0C0C0
    Me.txtReq06.ForeColor = &HC0C0C0
    Me.chkReq06.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq07_Change()
If Me.txtReq07.Value <> "" Then
    Me.lblReq07.ForeColor = &H8080FF
    Me.txtReq07.BorderColor = &H8080FF
    Me.txtReq07.ForeColor = &H8080FF
    Me.chkReq07.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq07.ForeColor = &HC0C0C0
    Me.txtReq07.BorderColor = &HC0C0C0
    Me.txtReq07.ForeColor = &HC0C0C0
    Me.chkReq07.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq08_Change()
If Me.txtReq08.Value <> "" Then
    Me.lblReq08.ForeColor = &H8080FF
    Me.txtReq08.BorderColor = &H8080FF
    Me.txtReq08.ForeColor = &H8080FF
    Me.chkReq08.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq08.ForeColor = &HC0C0C0
    Me.txtReq08.BorderColor = &HC0C0C0
    Me.txtReq08.ForeColor = &HC0C0C0
    Me.chkReq08.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq09_Change()
If Me.txtReq09.Value <> "" Then
    Me.lblReq09.ForeColor = &H8080FF
    Me.txtReq09.BorderColor = &H8080FF
    Me.txtReq09.ForeColor = &H8080FF
    Me.chkReq09.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq09.ForeColor = &HC0C0C0
    Me.txtReq09.BorderColor = &HC0C0C0
    Me.txtReq09.ForeColor = &HC0C0C0
    Me.chkReq09.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq10_Change()
If Me.txtReq10.Value <> "" Then
    Me.lblReq10.ForeColor = &H8080FF
    Me.txtReq10.BorderColor = &H8080FF
    Me.txtReq10.ForeColor = &H8080FF
    Me.chkReq10.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq10.ForeColor = &HC0C0C0
    Me.txtReq10.BorderColor = &HC0C0C0
    Me.txtReq10.ForeColor = &HC0C0C0
    Me.chkReq10.Picture = Me.chkReqOff.Picture
End If
End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "frmaut"
Attribute VB_Base = "0{30BCCC7C-89F3-408D-8AAC-1376B95D71EE}{7DF0D717-93C6-4979-908D-92EAD7F3867F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False


Private Sub btn_bom_Click()

    cod_z = frmsol.lbl_codz.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="F:\eng_ind\PROJETOS_Controle\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


End Sub

Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_docs_Click()
    
    UF.lbl_codSL.Caption = Me.lbl_ref.Caption
    UF.lbl_codz.Caption = Me.lbl_cod_z.Caption
    UF.lbl_descricao_SL.Caption = Me.lbl_desc
    
    UF.Show

End Sub

Private Sub btn_dxf_novo_Click()
    ufdxf.Show
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.cmb_autor.Text
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)


End Sub

Private Sub btn_ok_Click()

    Unload Me
    
    filtro = Sheets("Fila").Range("M4").Value
    If filtro = 0 Then Listar_todos
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06
    If filtro = 7 Then filtro_07
    If filtro = 8 Then Listar_analise
    If filtro = 9 Then Lista_SL (Range("H4").Value)
    If filtro = 10 Then Lista_Z (Range("G4").Value)
    If filtro = 11 Then Call Lista_VG(Range("I4").Value, Range("G5").Value)
    If filtro = 12 Then Call Lista_Solic(Range("G5").Value, Range("I4").Value)
    If filtro = 13 Then filtro_08
    If filtro = 14 Then Call Lista_Projetista(Range("K4").Value, Range("I4").Value)
    If filtro = 15 Then Lista_Novos

End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(ln, 2).Value = li1.Text
                .Cells(ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(ln, 16).Value = li1.ListSubItems(3).Text
                ln = ln + 1
        Next a
                
        'Carrega OCs
        ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(ln, 17).Value = li2.ListSubItems(7).Text 'Status
                ln = ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("F:\eng_ind\PROJETOS_Controle\Controle\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    

    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
        Sheets("Fila").Activate
    
        Unload Me

End Sub


Private Sub carrega_pdf_Click()

End Sub

Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "F:\eng_ind\PROJETOS_Controle\Controle\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub

Private Sub btn_pdf_novo_Click()
    Dim SQL As String
    Dim SQL_pdf As String
    lista_PDF = AbrePDF()
    
    t_cod_z = frmsol.lbl_cod_z.Caption
    t_cod_sl = frmsol.lbl_ref.Caption
    
    If Not IsEmpty(lista_PDF) Then
        For a = 1 To UBound(lista_PDF)
            caminho = lista_PDF(a)
            pos = InStrRev(caminho, "\", , vbTextCompare)
            codigo = Mid(caminho, pos + 1, Len(caminho) - pos)
            codigo = Replace(codigo, ".PDF", "")
            codigo = Replace(codigo, ".pdf", "")
                       
            t_codigo_pdf = codigo
            t_caminho_pdf = caminho
            
            SQL_pdf = "SELECT Codigo From PDF_Control WHERE Codigo = '" & t_codigo_pdf & "' AND Solicitacao = '" & t_cod_sl & "';"
            ArrPDF = resQuery(SQL_pdf)
            
            If IsEmpty(ArrPDF) Then
                SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo_pdf & "',"
                SQL = SQL & "'0');"
                upQuery (SQL)
            End If
            
            Dim oldPathPDF As String, newPathPDF As String
            oldPathPDF = t_caminho_pdf
            
            newPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\desenhosPDF\" & t_cod_sl
            
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            
            newPathPDF = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            


            oldPathPDF = t_caminho_pdf
            newPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\desenhosPDF\" & t_cod_sl
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            newPathPDF2 = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            newPathPDF = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            If oldPathPDF <> "" Then
                Set fs = CreateObject("Scripting.FileSystemObject")
                fs.CopyFile oldPathPDF, newPathPDF
                fs.CopyFile oldPathPDF, newPathPDF2
                Set fs = Nothing

                ' Access -> Web: envia o desenho PDF pro MySQL/web
                enviarPdfDesenhoParaMySQL CLng(Replace(t_cod_sl, "SL", "")), t_codigo_pdf, newPathPDF
            End If

        Next a
    End If
    
    MsgBox "Desenhos em PDF carregados com sucesso!"
    
    Call carrega_pdf(frmsol.lbl_ref.Caption)
    
End Sub

Private Sub btn_buy_novo_Click()
    frm_bom2.lbl_ref.Caption = frmsol.lbl_ref.Caption
    frm_bom2.lbl_desc.Caption = frmsol.lbl_desc.Caption
    frm_bom2.Show
End Sub

Private Sub btnCheck_Click()


Me.multi.Value = 2

'set cor do botão ativo
Me.btnCheck.ForeColor = &H80000012
Me.bordaCheck.BorderColor = &H808080
Me.bordaCheck.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF




End Sub

Private Sub btnDados_Click()

Me.multi.Value = 0

'set cor do botão ativo
Me.btnDados.ForeColor = &H80000012
Me.bordaDados.BorderColor = &H808080
Me.bordaDados.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF

End Sub

Private Sub btnHabilitar_Click()

If Me.det_st.Caption = "OK" Then
    Me.btn_carregar_docs.Enabled = True
    Me.btn_carregar_docs.BackColor = &H80FF80
End If

End Sub

Private Sub btnLoad_Click()
    caminho = "http://mcs.eng.br/greenbrier/upload.html"
    ufLoad.wb.Navigate (caminho)
    ufLoad.Show
End Sub

Private Sub btnLimparComprados_Click()

Dim SQL As String
Dim rq As VbMsgBoxResult
rq = MsgBox("Deseja limpar a lista de Itens Comprados?", vbYesNo, "Deletar?")

If rq = vbYes Then
    nSL = Me.lbl_ref.Caption
    SQL = "DELETE FROM BOM_Control WHERE Solicitacao = '" & sSL & "' AND OC = '';"
    upQuery (SQL)
End If


End Sub

Private Sub btnReq_Click()
Me.multi.Value = 1

'set cor do botão ativo
Me.btnReq.ForeColor = &H80000012
Me.bordaReq.BorderColor = &H808080
Me.bordaReq.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF

End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        ArrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(ArrRes(10, 0)) Then frm_dxf.pg01.Caption = ArrRes(10, 0)
        If Not IsNull(ArrRes(0, 0)) Then frm_dxf.res01.Caption = ArrRes(0, 0)
        status_pg01 = ArrRes(11, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #2
        If Not IsNull(ArrRes(12, 0)) Then frm_dxf.pg02.Caption = ArrRes(12, 0)
        If Not IsNull(ArrRes(1, 0)) Then frm_dxf.res02.Caption = ArrRes(1, 0)
        status_pg02 = ArrRes(13, 0)
        
        'MsgBox status_pg02
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #3
        If Not IsNull(ArrRes(14, 0)) Then frm_dxf.pg03.Caption = ArrRes(14, 0)
        If Not IsNull(ArrRes(2, 0)) Then frm_dxf.res03.Caption = ArrRes(2, 0)
        status_pg03 = ArrRes(15, 0)
        
        'MsgBox status_pg03
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #4
        If Not IsNull(ArrRes(16, 0)) Then frm_dxf.pg04.Caption = ArrRes(16, 0)
        If Not IsNull(ArrRes(3, 0)) Then frm_dxf.res04.Caption = ArrRes(3, 0)
        status_pg04 = ArrRes(17, 0)
        
        'MsgBox status_pg04
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #5
        If Not IsNull(ArrRes(18, 0)) Then frm_dxf.pg05.Caption = ArrRes(18, 0)
        If Not IsNull(ArrRes(4, 0)) Then frm_dxf.res05.Caption = ArrRes(4, 0)
        status_pg05 = ArrRes(19, 0)
        
        'MsgBox status_pg05
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #6
        If Not IsNull(ArrRes(20, 0)) Then frm_dxf.pg06.Caption = ArrRes(20, 0)
        If Not IsNull(ArrRes(5, 0)) Then frm_dxf.res06.Caption = ArrRes(5, 0)
        status_pg06 = ArrRes(21, 0)
        
        'MsgBox status_pg06
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #7
        If Not IsNull(ArrRes(22, 0)) Then frm_dxf.pg07.Caption = ArrRes(22, 0)
        If Not IsNull(ArrRes(6, 0)) Then frm_dxf.res07.Caption = ArrRes(6, 0)
        status_pg07 = ArrRes(23, 0)
        
        'MsgBox status_pg07
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #8
        If Not IsNull(ArrRes(24, 0)) Then frm_dxf.pg08.Caption = ArrRes(24, 0)
        If Not IsNull(ArrRes(7, 0)) Then frm_dxf.res08.Caption = ArrRes(7, 0)
        status_pg08 = ArrRes(25, 0)
        
        'MsgBox status_pg08
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #9
        If Not IsNull(ArrRes(26, 0)) Then frm_dxf.pg09.Caption = ArrRes(26, 0)
        If Not IsNull(ArrRes(8, 0)) Then frm_dxf.res09.Caption = ArrRes(8, 0)
        status_pg09 = ArrRes(27, 0)
        
        'MsgBox status_pg09
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #10
        If Not IsNull(ArrRes(28, 0)) Then frm_dxf.pg10.Caption = ArrRes(28, 0)
        If Not IsNull(ArrRes(9, 0)) Then frm_dxf.res10.Caption = ArrRes(9, 0)
        status_pg10 = ArrRes(29, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        
        
        
        frm_dxf.Show
        
        
    End If


End Sub







Private Sub Label21_Click()
    Dim SQL_Z As String
    projetista = frmsol.lbl_projetista.Caption
    cod_z = Replace(frmsol.lbl_codz.Caption, "Z", "")
    data_inicio = DateValue(Me.dt_inicio.Caption)
    data_fim = DateValue(Me.dt_fim.Caption)
    SQL_Z = "UPDATE Projetos SET Data_Inicio = '" & data_inicio & "' , Data_Fim = '" & data_fim & "' , Projetista = '" & projetista & "', Status = 'Concluído', "
    SQL_Z = SQL_Z & "Data_R_Inicio = '" & data_inicio & "' , Data_R_Fim = '" & data_fim & "' "
    SQL_Z = SQL_Z & " WHERE Controle = " & cod_z & ";"
    upQuery (SQL_Z)
    MsgBox "Projeto " & Me.lbl_codz.Caption & " atualizado!"
    Unload Me
End Sub



Private Sub btnLoadBOM_Click()
    frm_bom.lbl_ref.Caption = frmaut.lbl_ref.Caption
    frm_bom.lbl_desc.Caption = frmaut.lbl_desc.Caption
    frm_bom.lblTipo.Caption = "Auto"
    frm_bom.lblCodZ.Caption = frmaut.lbl_codz.Caption
    frm_bom.Show
End Sub

Private Sub btnLoadImage_Click()
Dim fs As Object
Dim oldPathJPG As String, newPathJPG As String
Dim refNum As Long

oldPathJPG = AbreJPG
If oldPathJPG <> "" Then
    caminho_arquivo = Left(oldPathJPG, InStrRev(oldPathJPG, "\") - 1)
    caminho_arquivo = Left(caminho_arquivo, InStrRev(caminho_arquivo, "\") - 1)

    cod_sl = frmaut.lbl_ref.Caption                   ' ex.: "SL4001"
    refNum = CLng(Replace(cod_sl, "SL", ""))          ' "SL4001" -> 4001

    Set fs = CreateObject("Scripting.FileSystemObject")
    ' Mesmo nome que Carrega_campos le (SL{0000}.jpg), na pasta mapeada
    newPathJPG = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\SL" & Format(refNum, "0000") & ".jpg"
    fs.CopyFile oldPathJPG, newPathJPG
    Set fs = Nothing
    caminho = newPathJPG
    Me.img_sl.Picture = LoadPicture(caminho)

    ' Access -> Web: envia a mesma imagem pro MySQL/web
    enviarImagemParaMySQL refNum, newPathJPG
End If
End Sub



Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & frmaut.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub

Private Sub lbl_trocar_Click()


End Sub

Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
   
    codigo = Me.pdf_lst.Text
   
    tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)
        
    
    
    'user = "MARCOS"
    'codigo = Me.lbl_ref & " - " & Me.pdf_lst.Text
    
    'caminho = "http://mcs.eng.br/greenbrier/copia.php?nome=" & user & "&pdf=" & codigo & ".PDF"
    'ufView.wb.Navigate (caminho)
    
    'ufView.Show
End Sub

Private Sub pdf_lst_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
Dim SQL As String
Dim res As VbMsgBoxResult

If KeyAscii = 120 Then
    codigo = Me.pdf_lst.Text
    n_sl = Me.lbl_ref.Caption
    
    res = MsgBox("Deseja EXCLUIR o desenho nº " & codigo & "?", vbYesNoCancel, "EXCLUIR?")
    If res = vbYes Then
        SQL = "DELETE FROM PDF_Control WHERE Codigo = '" & codigo & "' AND Solicitacao = '" & n_sl & "';"
        upQuery (SQL)
    End If
End If

Call carrega_pdf(frmsol.lbl_ref.Caption)

End Sub



Private Sub txtReq01_Change()
If Me.txtReq01.Value <> "" Then
    Me.lblReq01.ForeColor = &H8080FF
    Me.txtReq01.BorderColor = &H8080FF
    Me.txtReq01.ForeColor = &H8080FF
    Me.chkReq01.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq01.ForeColor = &HC0C0C0
    Me.txtReq01.BorderColor = &HC0C0C0
    Me.txtReq01.ForeColor = &HC0C0C0
    Me.chkReq01.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq02_Change()
If Me.txtReq02.Value <> "" Then
    Me.lblReq02.ForeColor = &H8080FF
    Me.txtReq02.BorderColor = &H8080FF
    Me.txtReq02.ForeColor = &H8080FF
    Me.chkReq02.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq02.ForeColor = &HC0C0C0
    Me.txtReq02.BorderColor = &HC0C0C0
    Me.txtReq02.ForeColor = &HC0C0C0
    Me.chkReq02.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq03_Change()
If Me.txtReq03.Value <> "" Then
    Me.lblReq03.ForeColor = &H8080FF
    Me.txtReq03.BorderColor = &H8080FF
    Me.txtReq03.ForeColor = &H8080FF
    Me.chkReq03.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq03.ForeColor = &HC0C0C0
    Me.txtReq03.BorderColor = &HC0C0C0
    Me.txtReq03.ForeColor = &HC0C0C0
    Me.chkReq03.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq04_Change()
If Me.txtReq04.Value <> "" Then
    Me.lblReq04.ForeColor = &H8080FF
    Me.txtReq04.BorderColor = &H8080FF
    Me.txtReq04.ForeColor = &H8080FF
    Me.chkReq04.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq04.ForeColor = &HC0C0C0
    Me.txtReq04.BorderColor = &HC0C0C0
    Me.txtReq04.ForeColor = &HC0C0C0
    Me.chkReq04.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq05_Change()
If Me.txtReq05.Value <> "" Then
    Me.lblReq05.ForeColor = &H8080FF
    Me.txtReq05.BorderColor = &H8080FF
    Me.txtReq05.ForeColor = &H8080FF
    Me.chkReq05.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq05.ForeColor = &HC0C0C0
    Me.txtReq05.BorderColor = &HC0C0C0
    Me.txtReq05.ForeColor = &HC0C0C0
    Me.chkReq05.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq06_Change()
If Me.txtReq06.Value <> "" Then
    Me.lblReq06.ForeColor = &H8080FF
    Me.txtReq06.BorderColor = &H8080FF
    Me.txtReq06.ForeColor = &H8080FF
    Me.chkReq06.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq06.ForeColor = &HC0C0C0
    Me.txtReq06.BorderColor = &HC0C0C0
    Me.txtReq06.ForeColor = &HC0C0C0
    Me.chkReq06.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq07_Change()
If Me.txtReq07.Value <> "" Then
    Me.lblReq07.ForeColor = &H8080FF
    Me.txtReq07.BorderColor = &H8080FF
    Me.txtReq07.ForeColor = &H8080FF
    Me.chkReq07.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq07.ForeColor = &HC0C0C0
    Me.txtReq07.BorderColor = &HC0C0C0
    Me.txtReq07.ForeColor = &HC0C0C0
    Me.chkReq07.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq08_Change()
If Me.txtReq08.Value <> "" Then
    Me.lblReq08.ForeColor = &H8080FF
    Me.txtReq08.BorderColor = &H8080FF
    Me.txtReq08.ForeColor = &H8080FF
    Me.chkReq08.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq08.ForeColor = &HC0C0C0
    Me.txtReq08.BorderColor = &HC0C0C0
    Me.txtReq08.ForeColor = &HC0C0C0
    Me.chkReq08.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq09_Change()
If Me.txtReq09.Value <> "" Then
    Me.lblReq09.ForeColor = &H8080FF
    Me.txtReq09.BorderColor = &H8080FF
    Me.txtReq09.ForeColor = &H8080FF
    Me.chkReq09.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq09.ForeColor = &HC0C0C0
    Me.txtReq09.BorderColor = &HC0C0C0
    Me.txtReq09.ForeColor = &HC0C0C0
    Me.chkReq09.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq10_Change()
If Me.txtReq10.Value <> "" Then
    Me.lblReq10.ForeColor = &H8080FF
    Me.txtReq10.BorderColor = &H8080FF
    Me.txtReq10.ForeColor = &H8080FF
    Me.chkReq10.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq10.ForeColor = &HC0C0C0
    Me.txtReq10.BorderColor = &HC0C0C0
    Me.txtReq10.ForeColor = &HC0C0C0
    Me.chkReq10.Picture = Me.chkReqOff.Picture
End If
End Sub
```

---

## 6. VBA — `frmsol` (módulo inteiro)

Mesmas mudanças do `frmaut` (`btn_pdf_novo_Click` + `pdf_lst_DblClick`). Este form
**não** teve mudança na fatia imagem, então ANTES = original.

### ANTES (100%)
```vb
Attribute VB_Name = "frmsol"
Attribute VB_Base = "0{316AB81B-4A3A-4B8F-AE6B-5D3608E11D71}{F38E8303-9D50-4862-A92C-269A29854D6F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False



Private Sub btn_bom_Click()

    cod_z = frmsol.lbl_codz.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="F:\eng_ind\PROJETOS_Controle\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


End Sub

Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_docs_Click()
    
    UF.lbl_codSL.Caption = Me.lbl_ref.Caption
    UF.lbl_codz.Caption = Me.lbl_cod_z.Caption
    UF.lbl_descricao_SL.Caption = Me.lbl_desc
    
    UF.Show

End Sub

Private Sub btn_dxf_novo_Click()
    ufdxf.Show
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.cmb_autor.Text
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)


End Sub

Private Sub btn_ok_Click()
    Dim SQL         As String
    Dim vtReq       As String
    Dim a           As Integer
    
    
    vtReq = ""
    For a = 1 To 10
        vtReq = vtReq & Me.Controls("txtReq" & Format(a, "00")).Text & "-|-"
    Next a
    SQL = "UPDATE Fila SET Requisitos = '" & vtReq & "' WHERE Ref = " & Replace(Me.lbl_ref, "SL", "")
    upQuery (SQL)
 
    
    Unload Me
    
    filtro = Sheets("Fila").Range("M4").Value
    If filtro = 0 Then Listar_todos
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06
    If filtro = 7 Then filtro_07
    If filtro = 8 Then Listar_analise
    If filtro = 9 Then Lista_SL (Range("H4").Value)
    If filtro = 10 Then Lista_Z (Range("G4").Value)
    If filtro = 11 Then Call Lista_VG(Range("I4").Value, Range("G5").Value)
    If filtro = 12 Then Call Lista_Solic(Range("G5").Value, Range("I4").Value)
    If filtro = 13 Then filtro_08
    If filtro = 14 Then Call Lista_Projetista(Range("K4").Value, Range("I4").Value)
    If filtro = 15 Then Lista_Novos

End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(ln, 2).Value = li1.Text
                .Cells(ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(ln, 16).Value = li1.ListSubItems(3).Text
                ln = ln + 1
        Next a
                
        'Carrega OCs
        ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(ln, 17).Value = li2.ListSubItems(7).Text 'Status
                ln = ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("F:\eng_ind\PROJETOS_Controle\Controle\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    

    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
        Sheets("Fila").Activate
    
        Unload Me

End Sub


Private Sub carrega_pdf_Click()

End Sub

Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "F:\eng_ind\PROJETOS_Controle\Controle\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub

Private Sub btn_pdf_novo_Click()
    Dim SQL As String
    Dim SQL_pdf As String
    lista_PDF = AbrePDF()
    
    t_cod_z = frmsol.lbl_cod_z.Caption
    t_cod_sl = frmsol.lbl_ref.Caption
    
    If Not IsEmpty(lista_PDF) Then
        For a = 1 To UBound(lista_PDF)
            caminho = lista_PDF(a)
            pos = InStrRev(caminho, "\", , vbTextCompare)
            codigo = Mid(caminho, pos + 1, Len(caminho) - pos)
            codigo = Replace(codigo, ".PDF", "")
            codigo = Replace(codigo, ".pdf", "")
                       
            t_codigo_pdf = codigo
            t_caminho_pdf = caminho
            
            SQL_pdf = "SELECT Codigo From PDF_Control WHERE Codigo = '" & t_codigo_pdf & "' AND Solicitacao = '" & t_cod_sl & "';"
            ArrPDF = resQuery(SQL_pdf)
            
            If IsEmpty(ArrPDF) Then
                SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo_pdf & "',"
                SQL = SQL & "'0');"
                upQuery (SQL)
            End If
            
            Dim oldPathPDF As String, newPathPDF As String
            oldPathPDF = t_caminho_pdf
            
            newPath = "F:\eng_ind\PROJETOS_Controle\Controle\desenhosPDF\" & t_cod_sl
            
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            
            newPathPDF = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            


            oldPathPDF = t_caminho_pdf
            newPath = "F:\eng_ind\PROJETOS_Controle\Controle\desenhosPDF\" & t_cod_sl
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            newPathPDF2 = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            newPathPDF = "F:\eng_ind\PROJETOS_Controle\Controle\.desenhos\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            If oldPathPDF <> "" Then
                Set fs = CreateObject("Scripting.FileSystemObject")
                fs.CopyFile oldPathPDF, newPathPDF
                fs.CopyFile oldPathPDF, newPathPDF2
                Set fs = Nothing
            End If

        Next a
    End If
    
    MsgBox "Desenhos em PDF carregados com sucesso!"
    
    Call carrega_pdf(frmsol.lbl_ref.Caption)
    
End Sub

Private Sub btn_buy_novo_Click()
    frm_bom.lbl_ref.Caption = frmsol.lbl_ref.Caption
    frm_bom.lbl_desc.Caption = frmsol.lbl_desc.Caption
    frm_bom.lblTipo.Caption = "Auto"
    frm_bom.Show
End Sub

Private Sub btnCheck_Click()


Me.multi.Value = 2

'set cor do botão ativo
Me.btnCheck.ForeColor = &H80000012
Me.bordaCheck.BorderColor = &H808080
Me.bordaCheck.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF




End Sub

Private Sub btnDados_Click()

Me.multi.Value = 0

'set cor do botão ativo
Me.btnDados.ForeColor = &H80000012
Me.bordaDados.BorderColor = &H808080
Me.bordaDados.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF

End Sub

Private Sub btnHabilitar_Click()

If Me.det_st.Caption = "OK" Then
    Me.btn_carregar_docs.Enabled = True
    Me.btn_carregar_docs.BackColor = &H80FF80
End If

End Sub

Private Sub btnLoad_Click()
    caminho = "http://mcs.eng.br/greenbrier/upload.html"
    ufLoad.wb.Navigate (caminho)
    ufLoad.Show
End Sub

Private Sub btnLiberar_Click()
Dim SQL As String
Dim ref As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "")

SQL = "UPDATE Fila SET Conceito_St = 'OK', Det_St = 'OK', Liberacao_St = 'OK', Aq_St = 'OK', Corte_St = 'FINALIZADO', Exec_St = 'FINALIZADO', Tryout_St = 'OK', "
SQL = SQL + "Conceito_Fim = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Det_Ini = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Det_Fim = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Liberacao_Data = '" & Format(Now, "DD/MM/YYYY HH:MM") & "' WHERE Ref = " & ref & ";"
upQuery (SQL)

Call Carrega_campos(ref)
Call Formata_Campos


MsgBox "SL Liberada!"

End Sub

Private Sub btnLimparComprados_Click()

Dim SQL As String
Dim rq As VbMsgBoxResult
rq = MsgBox("Deseja limpar a lista de Itens Comprados?", vbYesNo, "Deletar?")

If rq = vbYes Then
    nSL = Me.lbl_ref.Caption
    SQL = "DELETE FROM BOM_Control WHERE Solicitacao = '" & sSL & "' AND OC = '';"
    upQuery (SQL)
End If


End Sub

Private Sub btnReq_Click()
Me.multi.Value = 1

'set cor do botão ativo
Me.btnReq.ForeColor = &H80000012
Me.bordaReq.BorderColor = &H808080
Me.bordaReq.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF

End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        ArrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(ArrRes(10, 0)) Then frm_dxf.pg01.Caption = ArrRes(10, 0)
        If Not IsNull(ArrRes(0, 0)) Then frm_dxf.res01.Caption = ArrRes(0, 0)
        status_pg01 = ArrRes(11, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #2
        If Not IsNull(ArrRes(12, 0)) Then frm_dxf.pg02.Caption = ArrRes(12, 0)
        If Not IsNull(ArrRes(1, 0)) Then frm_dxf.res02.Caption = ArrRes(1, 0)
        status_pg02 = ArrRes(13, 0)
        
        'MsgBox status_pg02
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #3
        If Not IsNull(ArrRes(14, 0)) Then frm_dxf.pg03.Caption = ArrRes(14, 0)
        If Not IsNull(ArrRes(2, 0)) Then frm_dxf.res03.Caption = ArrRes(2, 0)
        status_pg03 = ArrRes(15, 0)
        
        'MsgBox status_pg03
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #4
        If Not IsNull(ArrRes(16, 0)) Then frm_dxf.pg04.Caption = ArrRes(16, 0)
        If Not IsNull(ArrRes(3, 0)) Then frm_dxf.res04.Caption = ArrRes(3, 0)
        status_pg04 = ArrRes(17, 0)
        
        'MsgBox status_pg04
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #5
        If Not IsNull(ArrRes(18, 0)) Then frm_dxf.pg05.Caption = ArrRes(18, 0)
        If Not IsNull(ArrRes(4, 0)) Then frm_dxf.res05.Caption = ArrRes(4, 0)
        status_pg05 = ArrRes(19, 0)
        
        'MsgBox status_pg05
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #6
        If Not IsNull(ArrRes(20, 0)) Then frm_dxf.pg06.Caption = ArrRes(20, 0)
        If Not IsNull(ArrRes(5, 0)) Then frm_dxf.res06.Caption = ArrRes(5, 0)
        status_pg06 = ArrRes(21, 0)
        
        'MsgBox status_pg06
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #7
        If Not IsNull(ArrRes(22, 0)) Then frm_dxf.pg07.Caption = ArrRes(22, 0)
        If Not IsNull(ArrRes(6, 0)) Then frm_dxf.res07.Caption = ArrRes(6, 0)
        status_pg07 = ArrRes(23, 0)
        
        'MsgBox status_pg07
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #8
        If Not IsNull(ArrRes(24, 0)) Then frm_dxf.pg08.Caption = ArrRes(24, 0)
        If Not IsNull(ArrRes(7, 0)) Then frm_dxf.res08.Caption = ArrRes(7, 0)
        status_pg08 = ArrRes(25, 0)
        
        'MsgBox status_pg08
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #9
        If Not IsNull(ArrRes(26, 0)) Then frm_dxf.pg09.Caption = ArrRes(26, 0)
        If Not IsNull(ArrRes(8, 0)) Then frm_dxf.res09.Caption = ArrRes(8, 0)
        status_pg09 = ArrRes(27, 0)
        
        'MsgBox status_pg09
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #10
        If Not IsNull(ArrRes(28, 0)) Then frm_dxf.pg10.Caption = ArrRes(28, 0)
        If Not IsNull(ArrRes(9, 0)) Then frm_dxf.res10.Caption = ArrRes(9, 0)
        status_pg10 = ArrRes(29, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        
        
        
        frm_dxf.Show
        
        
    End If


End Sub







Private Sub Label21_Click()
    Dim SQL_Z As String
    projetista = frmsol.lbl_projetista.Caption
    cod_z = Replace(frmsol.lbl_codz.Caption, "Z", "")
    data_inicio = DateValue(Me.dt_inicio.Caption)
    data_fim = DateValue(Me.dt_fim.Caption)
    SQL_Z = "UPDATE Projetos SET Data_Inicio = '" & data_inicio & "' , Data_Fim = '" & data_fim & "' , Projetista = '" & projetista & "', Status = 'Concluído', "
    SQL_Z = SQL_Z & "Data_R_Inicio = '" & data_inicio & "' , Data_R_Fim = '" & data_fim & "' "
    SQL_Z = SQL_Z & " WHERE Controle = " & cod_z & ";"
    upQuery (SQL_Z)
    MsgBox "Projeto " & Me.lbl_codz.Caption & " atualizado!"
    Unload Me
End Sub



Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & frmsol.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub

Private Sub lbl_trocar_Click()
Dim fs As Object
Dim oldPathJPG As String, newPathJPG As String

oldPathJPG = AbreJPG
If oldPathJPG <> "" Then
    caminho_arquivo = Left(oldPathJPG, InStrRev(oldPathJPG, "\") - 1)
    caminho_arquivo = Left(caminho_arquivo, InStrRev(caminho_arquivo, "\") - 1)

    cod_sl = frmsol.lbl_ref.Caption

    If oldPathJPG <> "" Then
        Set fs = CreateObject("Scripting.FileSystemObject")
        newPathJPG = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & cod_sl & ".jpg"
        fs.CopyFile oldPathJPG, newPathJPG
        Set fs = Nothing
        caminho = newPathJPG
        frmsol.img_sl.Picture = LoadPicture(caminho)
    End If
End If

End Sub

Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
   
    codigo = Me.pdf_lst.Text
   
    tgtfile = "F:\eng_ind\PROJETOS_Controle\Controle\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)
        
    
    
    'user = "MARCOS"
    'codigo = Me.lbl_ref & " - " & Me.pdf_lst.Text
    
    'caminho = "http://mcs.eng.br/greenbrier/copia.php?nome=" & user & "&pdf=" & codigo & ".PDF"
    'ufView.wb.Navigate (caminho)
    
    'ufView.Show
End Sub

Private Sub pdf_lst_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
Dim SQL As String
Dim res As VbMsgBoxResult

If KeyAscii = 120 Then
    codigo = Me.pdf_lst.Text
    n_sl = Me.lbl_ref.Caption
    
    res = MsgBox("Deseja EXCLUIR o desenho nº " & codigo & "?", vbYesNoCancel, "EXCLUIR?")
    If res = vbYes Then
        SQL = "DELETE FROM PDF_Control WHERE Codigo = '" & codigo & "' AND Solicitacao = '" & n_sl & "';"
        upQuery (SQL)
    End If
End If

Call carrega_pdf(frmsol.lbl_ref.Caption)

End Sub

Private Sub txt_msg_Change()
    
    If Me.cmb_autor.Value = "" Then
        MsgBox "O Nome do Projetista não foi informado!", vbInformation
        Me.cmb_autor.SetFocus
        Exit Sub
    End If
End Sub

Private Sub txtReq01_Change()
If Me.txtReq01.Value <> "" Then
    Me.lblReq01.ForeColor = &H8080FF
    Me.txtReq01.BorderColor = &H8080FF
    Me.txtReq01.ForeColor = &H8080FF
    Me.chkReq01.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq01.ForeColor = &HC0C0C0
    Me.txtReq01.BorderColor = &HC0C0C0
    Me.txtReq01.ForeColor = &HC0C0C0
    Me.chkReq01.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq02_Change()
If Me.txtReq02.Value <> "" Then
    Me.lblReq02.ForeColor = &H8080FF
    Me.txtReq02.BorderColor = &H8080FF
    Me.txtReq02.ForeColor = &H8080FF
    Me.chkReq02.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq02.ForeColor = &HC0C0C0
    Me.txtReq02.BorderColor = &HC0C0C0
    Me.txtReq02.ForeColor = &HC0C0C0
    Me.chkReq02.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq03_Change()
If Me.txtReq03.Value <> "" Then
    Me.lblReq03.ForeColor = &H8080FF
    Me.txtReq03.BorderColor = &H8080FF
    Me.txtReq03.ForeColor = &H8080FF
    Me.chkReq03.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq03.ForeColor = &HC0C0C0
    Me.txtReq03.BorderColor = &HC0C0C0
    Me.txtReq03.ForeColor = &HC0C0C0
    Me.chkReq03.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq04_Change()
If Me.txtReq04.Value <> "" Then
    Me.lblReq04.ForeColor = &H8080FF
    Me.txtReq04.BorderColor = &H8080FF
    Me.txtReq04.ForeColor = &H8080FF
    Me.chkReq04.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq04.ForeColor = &HC0C0C0
    Me.txtReq04.BorderColor = &HC0C0C0
    Me.txtReq04.ForeColor = &HC0C0C0
    Me.chkReq04.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq05_Change()
If Me.txtReq05.Value <> "" Then
    Me.lblReq05.ForeColor = &H8080FF
    Me.txtReq05.BorderColor = &H8080FF
    Me.txtReq05.ForeColor = &H8080FF
    Me.chkReq05.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq05.ForeColor = &HC0C0C0
    Me.txtReq05.BorderColor = &HC0C0C0
    Me.txtReq05.ForeColor = &HC0C0C0
    Me.chkReq05.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq06_Change()
If Me.txtReq06.Value <> "" Then
    Me.lblReq06.ForeColor = &H8080FF
    Me.txtReq06.BorderColor = &H8080FF
    Me.txtReq06.ForeColor = &H8080FF
    Me.chkReq06.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq06.ForeColor = &HC0C0C0
    Me.txtReq06.BorderColor = &HC0C0C0
    Me.txtReq06.ForeColor = &HC0C0C0
    Me.chkReq06.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq07_Change()
If Me.txtReq07.Value <> "" Then
    Me.lblReq07.ForeColor = &H8080FF
    Me.txtReq07.BorderColor = &H8080FF
    Me.txtReq07.ForeColor = &H8080FF
    Me.chkReq07.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq07.ForeColor = &HC0C0C0
    Me.txtReq07.BorderColor = &HC0C0C0
    Me.txtReq07.ForeColor = &HC0C0C0
    Me.chkReq07.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq08_Change()
If Me.txtReq08.Value <> "" Then
    Me.lblReq08.ForeColor = &H8080FF
    Me.txtReq08.BorderColor = &H8080FF
    Me.txtReq08.ForeColor = &H8080FF
    Me.chkReq08.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq08.ForeColor = &HC0C0C0
    Me.txtReq08.BorderColor = &HC0C0C0
    Me.txtReq08.ForeColor = &HC0C0C0
    Me.chkReq08.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq09_Change()
If Me.txtReq09.Value <> "" Then
    Me.lblReq09.ForeColor = &H8080FF
    Me.txtReq09.BorderColor = &H8080FF
    Me.txtReq09.ForeColor = &H8080FF
    Me.chkReq09.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq09.ForeColor = &HC0C0C0
    Me.txtReq09.BorderColor = &HC0C0C0
    Me.txtReq09.ForeColor = &HC0C0C0
    Me.chkReq09.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq10_Change()
If Me.txtReq10.Value <> "" Then
    Me.lblReq10.ForeColor = &H8080FF
    Me.txtReq10.BorderColor = &H8080FF
    Me.txtReq10.ForeColor = &H8080FF
    Me.chkReq10.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq10.ForeColor = &HC0C0C0
    Me.txtReq10.BorderColor = &HC0C0C0
    Me.txtReq10.ForeColor = &HC0C0C0
    Me.chkReq10.Picture = Me.chkReqOff.Picture
End If
End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "frmsol"
Attribute VB_Base = "0{316AB81B-4A3A-4B8F-AE6B-5D3608E11D71}{F38E8303-9D50-4862-A92C-269A29854D6F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False



Private Sub btn_bom_Click()

    cod_z = frmsol.lbl_codz.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="F:\eng_ind\PROJETOS_Controle\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


End Sub

Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_docs_Click()
    
    UF.lbl_codSL.Caption = Me.lbl_ref.Caption
    UF.lbl_codz.Caption = Me.lbl_cod_z.Caption
    UF.lbl_descricao_SL.Caption = Me.lbl_desc
    
    UF.Show

End Sub

Private Sub btn_dxf_novo_Click()
    ufdxf.Show
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.cmb_autor.Text
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)


End Sub

Private Sub btn_ok_Click()
    Dim SQL         As String
    Dim vtReq       As String
    Dim a           As Integer
    
    
    vtReq = ""
    For a = 1 To 10
        vtReq = vtReq & Me.Controls("txtReq" & Format(a, "00")).Text & "-|-"
    Next a
    SQL = "UPDATE Fila SET Requisitos = '" & vtReq & "' WHERE Ref = " & Replace(Me.lbl_ref, "SL", "")
    upQuery (SQL)
 
    
    Unload Me
    
    filtro = Sheets("Fila").Range("M4").Value
    If filtro = 0 Then Listar_todos
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06
    If filtro = 7 Then filtro_07
    If filtro = 8 Then Listar_analise
    If filtro = 9 Then Lista_SL (Range("H4").Value)
    If filtro = 10 Then Lista_Z (Range("G4").Value)
    If filtro = 11 Then Call Lista_VG(Range("I4").Value, Range("G5").Value)
    If filtro = 12 Then Call Lista_Solic(Range("G5").Value, Range("I4").Value)
    If filtro = 13 Then filtro_08
    If filtro = 14 Then Call Lista_Projetista(Range("K4").Value, Range("I4").Value)
    If filtro = 15 Then Lista_Novos

End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(ln, 2).Value = li1.Text
                .Cells(ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(ln, 16).Value = li1.ListSubItems(3).Text
                ln = ln + 1
        Next a
                
        'Carrega OCs
        ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(ln, 17).Value = li2.ListSubItems(7).Text 'Status
                ln = ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("F:\eng_ind\PROJETOS_Controle\Controle\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    

    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
        Sheets("Fila").Activate
    
        Unload Me

End Sub


Private Sub carrega_pdf_Click()

End Sub

Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "F:\eng_ind\PROJETOS_Controle\Controle\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub

Private Sub btn_pdf_novo_Click()
    Dim SQL As String
    Dim SQL_pdf As String
    lista_PDF = AbrePDF()
    
    t_cod_z = frmsol.lbl_cod_z.Caption
    t_cod_sl = frmsol.lbl_ref.Caption
    
    If Not IsEmpty(lista_PDF) Then
        For a = 1 To UBound(lista_PDF)
            caminho = lista_PDF(a)
            pos = InStrRev(caminho, "\", , vbTextCompare)
            codigo = Mid(caminho, pos + 1, Len(caminho) - pos)
            codigo = Replace(codigo, ".PDF", "")
            codigo = Replace(codigo, ".pdf", "")
                       
            t_codigo_pdf = codigo
            t_caminho_pdf = caminho
            
            SQL_pdf = "SELECT Codigo From PDF_Control WHERE Codigo = '" & t_codigo_pdf & "' AND Solicitacao = '" & t_cod_sl & "';"
            ArrPDF = resQuery(SQL_pdf)
            
            If IsEmpty(ArrPDF) Then
                SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo_pdf & "',"
                SQL = SQL & "'0');"
                upQuery (SQL)
            End If
            
            Dim oldPathPDF As String, newPathPDF As String
            oldPathPDF = t_caminho_pdf
            
            newPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\desenhosPDF\" & t_cod_sl
            
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            
            newPathPDF = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            


            oldPathPDF = t_caminho_pdf
            newPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\desenhosPDF\" & t_cod_sl
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            newPathPDF2 = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            newPathPDF = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            If oldPathPDF <> "" Then
                Set fs = CreateObject("Scripting.FileSystemObject")
                fs.CopyFile oldPathPDF, newPathPDF
                fs.CopyFile oldPathPDF, newPathPDF2
                Set fs = Nothing

                ' Access -> Web: envia o desenho PDF pro MySQL/web
                enviarPdfDesenhoParaMySQL CLng(Replace(t_cod_sl, "SL", "")), t_codigo_pdf, newPathPDF
            End If

        Next a
    End If
    
    MsgBox "Desenhos em PDF carregados com sucesso!"
    
    Call carrega_pdf(frmsol.lbl_ref.Caption)
    
End Sub

Private Sub btn_buy_novo_Click()
    frm_bom.lbl_ref.Caption = frmsol.lbl_ref.Caption
    frm_bom.lbl_desc.Caption = frmsol.lbl_desc.Caption
    frm_bom.lblTipo.Caption = "Auto"
    frm_bom.Show
End Sub

Private Sub btnCheck_Click()


Me.multi.Value = 2

'set cor do botão ativo
Me.btnCheck.ForeColor = &H80000012
Me.bordaCheck.BorderColor = &H808080
Me.bordaCheck.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF




End Sub

Private Sub btnDados_Click()

Me.multi.Value = 0

'set cor do botão ativo
Me.btnDados.ForeColor = &H80000012
Me.bordaDados.BorderColor = &H808080
Me.bordaDados.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF

End Sub

Private Sub btnHabilitar_Click()

If Me.det_st.Caption = "OK" Then
    Me.btn_carregar_docs.Enabled = True
    Me.btn_carregar_docs.BackColor = &H80FF80
End If

End Sub

Private Sub btnLoad_Click()
    caminho = "http://mcs.eng.br/greenbrier/upload.html"
    ufLoad.wb.Navigate (caminho)
    ufLoad.Show
End Sub

Private Sub btnLiberar_Click()
Dim SQL As String
Dim ref As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "")

SQL = "UPDATE Fila SET Conceito_St = 'OK', Det_St = 'OK', Liberacao_St = 'OK', Aq_St = 'OK', Corte_St = 'FINALIZADO', Exec_St = 'FINALIZADO', Tryout_St = 'OK', "
SQL = SQL + "Conceito_Fim = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Det_Ini = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Det_Fim = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Liberacao_Data = '" & Format(Now, "DD/MM/YYYY HH:MM") & "' WHERE Ref = " & ref & ";"
upQuery (SQL)

Call Carrega_campos(ref)
Call Formata_Campos


MsgBox "SL Liberada!"

End Sub

Private Sub btnLimparComprados_Click()

Dim SQL As String
Dim rq As VbMsgBoxResult
rq = MsgBox("Deseja limpar a lista de Itens Comprados?", vbYesNo, "Deletar?")

If rq = vbYes Then
    nSL = Me.lbl_ref.Caption
    SQL = "DELETE FROM BOM_Control WHERE Solicitacao = '" & sSL & "' AND OC = '';"
    upQuery (SQL)
End If


End Sub

Private Sub btnReq_Click()
Me.multi.Value = 1

'set cor do botão ativo
Me.btnReq.ForeColor = &H80000012
Me.bordaReq.BorderColor = &H808080
Me.bordaReq.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF

End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        ArrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(ArrRes(10, 0)) Then frm_dxf.pg01.Caption = ArrRes(10, 0)
        If Not IsNull(ArrRes(0, 0)) Then frm_dxf.res01.Caption = ArrRes(0, 0)
        status_pg01 = ArrRes(11, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #2
        If Not IsNull(ArrRes(12, 0)) Then frm_dxf.pg02.Caption = ArrRes(12, 0)
        If Not IsNull(ArrRes(1, 0)) Then frm_dxf.res02.Caption = ArrRes(1, 0)
        status_pg02 = ArrRes(13, 0)
        
        'MsgBox status_pg02
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #3
        If Not IsNull(ArrRes(14, 0)) Then frm_dxf.pg03.Caption = ArrRes(14, 0)
        If Not IsNull(ArrRes(2, 0)) Then frm_dxf.res03.Caption = ArrRes(2, 0)
        status_pg03 = ArrRes(15, 0)
        
        'MsgBox status_pg03
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #4
        If Not IsNull(ArrRes(16, 0)) Then frm_dxf.pg04.Caption = ArrRes(16, 0)
        If Not IsNull(ArrRes(3, 0)) Then frm_dxf.res04.Caption = ArrRes(3, 0)
        status_pg04 = ArrRes(17, 0)
        
        'MsgBox status_pg04
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #5
        If Not IsNull(ArrRes(18, 0)) Then frm_dxf.pg05.Caption = ArrRes(18, 0)
        If Not IsNull(ArrRes(4, 0)) Then frm_dxf.res05.Caption = ArrRes(4, 0)
        status_pg05 = ArrRes(19, 0)
        
        'MsgBox status_pg05
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #6
        If Not IsNull(ArrRes(20, 0)) Then frm_dxf.pg06.Caption = ArrRes(20, 0)
        If Not IsNull(ArrRes(5, 0)) Then frm_dxf.res06.Caption = ArrRes(5, 0)
        status_pg06 = ArrRes(21, 0)
        
        'MsgBox status_pg06
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #7
        If Not IsNull(ArrRes(22, 0)) Then frm_dxf.pg07.Caption = ArrRes(22, 0)
        If Not IsNull(ArrRes(6, 0)) Then frm_dxf.res07.Caption = ArrRes(6, 0)
        status_pg07 = ArrRes(23, 0)
        
        'MsgBox status_pg07
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #8
        If Not IsNull(ArrRes(24, 0)) Then frm_dxf.pg08.Caption = ArrRes(24, 0)
        If Not IsNull(ArrRes(7, 0)) Then frm_dxf.res08.Caption = ArrRes(7, 0)
        status_pg08 = ArrRes(25, 0)
        
        'MsgBox status_pg08
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #9
        If Not IsNull(ArrRes(26, 0)) Then frm_dxf.pg09.Caption = ArrRes(26, 0)
        If Not IsNull(ArrRes(8, 0)) Then frm_dxf.res09.Caption = ArrRes(8, 0)
        status_pg09 = ArrRes(27, 0)
        
        'MsgBox status_pg09
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #10
        If Not IsNull(ArrRes(28, 0)) Then frm_dxf.pg10.Caption = ArrRes(28, 0)
        If Not IsNull(ArrRes(9, 0)) Then frm_dxf.res10.Caption = ArrRes(9, 0)
        status_pg10 = ArrRes(29, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        
        
        
        frm_dxf.Show
        
        
    End If


End Sub







Private Sub Label21_Click()
    Dim SQL_Z As String
    projetista = frmsol.lbl_projetista.Caption
    cod_z = Replace(frmsol.lbl_codz.Caption, "Z", "")
    data_inicio = DateValue(Me.dt_inicio.Caption)
    data_fim = DateValue(Me.dt_fim.Caption)
    SQL_Z = "UPDATE Projetos SET Data_Inicio = '" & data_inicio & "' , Data_Fim = '" & data_fim & "' , Projetista = '" & projetista & "', Status = 'Concluído', "
    SQL_Z = SQL_Z & "Data_R_Inicio = '" & data_inicio & "' , Data_R_Fim = '" & data_fim & "' "
    SQL_Z = SQL_Z & " WHERE Controle = " & cod_z & ";"
    upQuery (SQL_Z)
    MsgBox "Projeto " & Me.lbl_codz.Caption & " atualizado!"
    Unload Me
End Sub



Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & frmsol.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub

Private Sub lbl_trocar_Click()
Dim fs As Object
Dim oldPathJPG As String, newPathJPG As String

oldPathJPG = AbreJPG
If oldPathJPG <> "" Then
    caminho_arquivo = Left(oldPathJPG, InStrRev(oldPathJPG, "\") - 1)
    caminho_arquivo = Left(caminho_arquivo, InStrRev(caminho_arquivo, "\") - 1)

    cod_sl = frmsol.lbl_ref.Caption

    If oldPathJPG <> "" Then
        Set fs = CreateObject("Scripting.FileSystemObject")
        newPathJPG = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & cod_sl & ".jpg"
        fs.CopyFile oldPathJPG, newPathJPG
        Set fs = Nothing
        caminho = newPathJPG
        frmsol.img_sl.Picture = LoadPicture(caminho)
    End If
End If

End Sub

Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
   
    codigo = Me.pdf_lst.Text
   
    tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)
        
    
    
    'user = "MARCOS"
    'codigo = Me.lbl_ref & " - " & Me.pdf_lst.Text
    
    'caminho = "http://mcs.eng.br/greenbrier/copia.php?nome=" & user & "&pdf=" & codigo & ".PDF"
    'ufView.wb.Navigate (caminho)
    
    'ufView.Show
End Sub

Private Sub pdf_lst_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
Dim SQL As String
Dim res As VbMsgBoxResult

If KeyAscii = 120 Then
    codigo = Me.pdf_lst.Text
    n_sl = Me.lbl_ref.Caption
    
    res = MsgBox("Deseja EXCLUIR o desenho nº " & codigo & "?", vbYesNoCancel, "EXCLUIR?")
    If res = vbYes Then
        SQL = "DELETE FROM PDF_Control WHERE Codigo = '" & codigo & "' AND Solicitacao = '" & n_sl & "';"
        upQuery (SQL)
    End If
End If

Call carrega_pdf(frmsol.lbl_ref.Caption)

End Sub

Private Sub txt_msg_Change()
    
    If Me.cmb_autor.Value = "" Then
        MsgBox "O Nome do Projetista não foi informado!", vbInformation
        Me.cmb_autor.SetFocus
        Exit Sub
    End If
End Sub

Private Sub txtReq01_Change()
If Me.txtReq01.Value <> "" Then
    Me.lblReq01.ForeColor = &H8080FF
    Me.txtReq01.BorderColor = &H8080FF
    Me.txtReq01.ForeColor = &H8080FF
    Me.chkReq01.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq01.ForeColor = &HC0C0C0
    Me.txtReq01.BorderColor = &HC0C0C0
    Me.txtReq01.ForeColor = &HC0C0C0
    Me.chkReq01.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq02_Change()
If Me.txtReq02.Value <> "" Then
    Me.lblReq02.ForeColor = &H8080FF
    Me.txtReq02.BorderColor = &H8080FF
    Me.txtReq02.ForeColor = &H8080FF
    Me.chkReq02.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq02.ForeColor = &HC0C0C0
    Me.txtReq02.BorderColor = &HC0C0C0
    Me.txtReq02.ForeColor = &HC0C0C0
    Me.chkReq02.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq03_Change()
If Me.txtReq03.Value <> "" Then
    Me.lblReq03.ForeColor = &H8080FF
    Me.txtReq03.BorderColor = &H8080FF
    Me.txtReq03.ForeColor = &H8080FF
    Me.chkReq03.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq03.ForeColor = &HC0C0C0
    Me.txtReq03.BorderColor = &HC0C0C0
    Me.txtReq03.ForeColor = &HC0C0C0
    Me.chkReq03.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq04_Change()
If Me.txtReq04.Value <> "" Then
    Me.lblReq04.ForeColor = &H8080FF
    Me.txtReq04.BorderColor = &H8080FF
    Me.txtReq04.ForeColor = &H8080FF
    Me.chkReq04.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq04.ForeColor = &HC0C0C0
    Me.txtReq04.BorderColor = &HC0C0C0
    Me.txtReq04.ForeColor = &HC0C0C0
    Me.chkReq04.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq05_Change()
If Me.txtReq05.Value <> "" Then
    Me.lblReq05.ForeColor = &H8080FF
    Me.txtReq05.BorderColor = &H8080FF
    Me.txtReq05.ForeColor = &H8080FF
    Me.chkReq05.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq05.ForeColor = &HC0C0C0
    Me.txtReq05.BorderColor = &HC0C0C0
    Me.txtReq05.ForeColor = &HC0C0C0
    Me.chkReq05.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq06_Change()
If Me.txtReq06.Value <> "" Then
    Me.lblReq06.ForeColor = &H8080FF
    Me.txtReq06.BorderColor = &H8080FF
    Me.txtReq06.ForeColor = &H8080FF
    Me.chkReq06.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq06.ForeColor = &HC0C0C0
    Me.txtReq06.BorderColor = &HC0C0C0
    Me.txtReq06.ForeColor = &HC0C0C0
    Me.chkReq06.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq07_Change()
If Me.txtReq07.Value <> "" Then
    Me.lblReq07.ForeColor = &H8080FF
    Me.txtReq07.BorderColor = &H8080FF
    Me.txtReq07.ForeColor = &H8080FF
    Me.chkReq07.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq07.ForeColor = &HC0C0C0
    Me.txtReq07.BorderColor = &HC0C0C0
    Me.txtReq07.ForeColor = &HC0C0C0
    Me.chkReq07.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq08_Change()
If Me.txtReq08.Value <> "" Then
    Me.lblReq08.ForeColor = &H8080FF
    Me.txtReq08.BorderColor = &H8080FF
    Me.txtReq08.ForeColor = &H8080FF
    Me.chkReq08.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq08.ForeColor = &HC0C0C0
    Me.txtReq08.BorderColor = &HC0C0C0
    Me.txtReq08.ForeColor = &HC0C0C0
    Me.chkReq08.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq09_Change()
If Me.txtReq09.Value <> "" Then
    Me.lblReq09.ForeColor = &H8080FF
    Me.txtReq09.BorderColor = &H8080FF
    Me.txtReq09.ForeColor = &H8080FF
    Me.chkReq09.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq09.ForeColor = &HC0C0C0
    Me.txtReq09.BorderColor = &HC0C0C0
    Me.txtReq09.ForeColor = &HC0C0C0
    Me.chkReq09.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq10_Change()
If Me.txtReq10.Value <> "" Then
    Me.lblReq10.ForeColor = &H8080FF
    Me.txtReq10.BorderColor = &H8080FF
    Me.txtReq10.ForeColor = &H8080FF
    Me.chkReq10.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq10.ForeColor = &HC0C0C0
    Me.txtReq10.BorderColor = &HC0C0C0
    Me.txtReq10.ForeColor = &HC0C0C0
    Me.chkReq10.Picture = Me.chkReqOff.Picture
End If
End Sub
```

