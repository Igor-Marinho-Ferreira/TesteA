# Pacote DXF — Código 100% (ANTES / DEPOIS completos)

Fatia 3 da Parte 2 (cortes). Para **cada** artefato: **ANTES 100%** e **DEPOIS 100%**.
Visão geral em [pacote-dxf.md](pacote-dxf.md).

> **Numeração unificada (cartório):** o número do DXF agora é **global** e no formato
> do Access (`DX0001`). O **MySQL é o cartório** (rota `nextDxf` com `GET_LOCK`); o Access
> pede o número antes de inserir. Piso via `APP_DXF_FLOOR` (= `MAX(Controle)` atual do
> Access) para não reiniciar/colidir com o legado.

> ⚠️ **Mudança no Access:** `DXF_Control.Controle` passa de **AutoNumeração → Número**
> (igual ao `Ref`), para aceitar o número que o MySQL emite.

| Artefato | Mudou |
|---|---|
| `.env` | +`APP_DXF_FLOOR` |
| `routes.php` | +3 rotas (`nextDxf`, `uploadDxfVba`, `csvAtualizado/dxf`) |
| `gerarProximoCodigoDxf` | regra do Access (global `DX`+4) + `proximoNumeroDxfGlobal` + `nextDxf` |
| `storePacoteDxf` | +`copiarDxfParaAccess` após commit |
| `DesenvolvimentoController` (novos) | `uploadDxfVba`, `removerArquivoPorCodigo`, `copiarDxfParaAccess`, `csvDxf` |
| VBA `Funcoes` | +`pedirProximoDxf`, +`enviarDxfParaMySQL`, +`sincronizarDxfsDoMySQL` |
| VBA `ufdxf` | `btn_novo_dxf_Click` (cartório + Controle explícito + caminhos + push) |
| VBA `uf_lista_dxf` | `btn_reparar_Click` (caminhos + push) |

---

## 1. `.env` (novo)
```ini
# Piso do contador global de DXF (= MAX(Controle) atual do DXF_Control do Access)
APP_DXF_FLOOR=0
```

## 2. PHP — `src/routes/routes.php` (bloco do DXF)

### ANTES
```php
Route::post('/dispositivos/desenvolvimento/dxf/{ref}/store', DesenvolvimentoController::class, 'storePacoteDxf')
    ->name('dispositivos.desenvolvimento.dxf.store')
    ->whereint(['ref']);
```

### DEPOIS
```php
Route::post('/dispositivos/desenvolvimento/dxf/{ref}/store', DesenvolvimentoController::class, 'storePacoteDxf')
    ->name('dispositivos.desenvolvimento.dxf.store')
    ->whereint(['ref']);

// Cartorio do numero de DXF (GET_LOCK) - Access (ufdxf) pede o proximo Controle.
Route::get('/dispositivos/desenvolvimento/nextDxf', DesenvolvimentoController::class, 'nextDxf')
    ->name('dispositivos.desenvolvimento.nextDxf');

// Access -> Web: recebe UM pacote DXF (zip) do Access (ufdxf) em binario cru.
Route::post('/dispositivos/desenvolvimento/uploadDxfVba', DesenvolvimentoController::class, 'uploadDxfVba')
    ->name('dispositivos.desenvolvimento.uploadDxfVba');

// Web -> Access (pull): CSV dos pacotes DXF p/ o VBA upsertar em DXF_Control.
Route::get('/dispositivos/csvAtualizado/dxf', DesenvolvimentoController::class, 'csvDxf')
    ->name('dispositivos.atualizaCSV.dxf');
```

---

## 3. PHP — numeração: `gerarProximoCodigoDxf` (+ `proximoNumeroDxfGlobal` + `nextDxf`)

### ANTES (era `DXF`+número por-SL)
```php
    private function gerarProximoCodigoDxf(string $ref): string
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT codigo
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref
            AND tipo = :tipo
        ");

        $stmt->execute([
            ':ref'  => $ref,
            ':tipo' => 'PACOTE_DXF'
        ]);

        $arquivosDxf = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $maiorNumero = 0;
        $totalDxf = 0;

        foreach ($arquivosDxf as $arquivo) {
            $totalDxf++;

            $codigo = strtoupper(trim((string)($arquivo->codigo ?? '')));

            if (preg_match('/^DXF(\d+)$/', $codigo, $matches)) {
                $numero = (int)$matches[1];

                if ($numero > $maiorNumero) {
                    $maiorNumero = $numero;
                }
            }
        }

        if ($maiorNumero === 0 && $totalDxf > 0) {
            $maiorNumero = $totalDxf;
        }

        $proximoNumero = $maiorNumero + 1;

        return 'DXF' . str_pad((string)$proximoNumero, 3, '0', STR_PAD_LEFT);
    }
```

### DEPOIS (regra do Access: `DX`+4 global, + cartório)
```php
    private function gerarProximoCodigoDxf(string $ref): string
    {
        // MESMA REGRA DO ACCESS: numeração GLOBAL (todas as SLs), formato "DX" + 4 dígitos
        // (ex.: DX0001). Antes era "DXF" + número por-SL.
        return 'DX' . str_pad((string) $this->proximoNumeroDxfGlobal(), 4, '0', STR_PAD_LEFT);
    }

    /**
     * Próximo número global de DXF, espelhando o MAX(Controle)+1 do DXF_Control do
     * Access. Como o histórico do DXF_Control não foi migrado, usamos um PISO
     * (APP_DXF_FLOOR = MAX(Controle) atual do Access) para o contador da web não
     * reiniciar em 1 e colidir com os DX legados. `$floorExtra` permite o Access
     * passar o próprio MAX no momento da criação (rota nextDxf).
     */
    private function proximoNumeroDxfGlobal(int $floorExtra = 0): int
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $rows = $pdo->query("
            SELECT codigo
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE tipo = 'PACOTE_DXF' AND codigo REGEXP '^DX[0-9]+$'
        ")->fetchAll(\PDO::FETCH_COLUMN) ?: [];

        $max = max((int) ($_ENV['APP_DXF_FLOOR'] ?? 0), $floorExtra);

        foreach ($rows as $codigo) {
            if (preg_match('/^DX(\d+)$/i', trim((string) $codigo), $m)) {
                $n = (int) $m[1];
                if ($n > $max) {
                    $max = $n;
                }
            }
        }

        return $max + 1;
    }

    /**
     * Cartório do número de DXF: o Access (ufdxf) pede aqui o próximo Controle para
     * os dois lados compartilharem a MESMA numeração global (igual ao Ref).
     * Serializa com GET_LOCK. Aceita ?floor=N (MAX(Controle) atual do Access).
     * Devolve { "controle": N, "codigo": "DX000N" }.
     */
    public function nextDxf()
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();
        $floor = (int) (Request::query('floor') ?? 0);

        $pdo->query("SELECT GET_LOCK('solic_dxf', 10)")->fetchColumn();
        try {
            $n = $this->proximoNumeroDxfGlobal($floor);
        } finally {
            $pdo->query("SELECT RELEASE_LOCK('solic_dxf')")->fetchColumn();
        }

        return Json::return([
            'controle' => $n,
            'codigo'   => 'DX' . str_pad((string) $n, 4, '0', STR_PAD_LEFT),
        ], 200);
    }
```

---

## 4. PHP — `storePacoteDxf` (método inteiro)

### ANTES (método 100%)
```php
    public function storePacoteDxf(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar DXF quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        if (empty($_FILES['pacote_dxf']) || !$this->arquivoValido($_FILES['pacote_dxf'])) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione um pacote DXF válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosCriadosFisicamente = [];

        try {
            $this->validarExtensaoArquivo($_FILES['pacote_dxf'], ['zip', 'rar', '7z', 'dxf'], 'pacote DXF');

            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do DXF.");
            }

            $codigoDxf = $this->gerarProximoCodigoDxf($ref);

            $arquivoSalvo = $this->salvarArquivoSolicitacao(
                $saveCarga['id'],
                $ref,
                $_FILES['pacote_dxf'],
                'PACOTE_DXF',
                "{$baseUploadDir}/dxf",
                "{$baseUploadPath}/dxf",
                $usuarioLogado,
                $codigoDxf
            );

            $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Pacote DXF {$codigoDxf} adicionado à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Pacote DXF {$codigoDxf} salvo com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar DXF da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar o pacote DXF.");
        }
    }
```

### DEPOIS (método 100%)
```php
    public function storePacoteDxf(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar DXF quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        if (empty($_FILES['pacote_dxf']) || !$this->arquivoValido($_FILES['pacote_dxf'])) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione um pacote DXF válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosCriadosFisicamente = [];

        try {
            $this->validarExtensaoArquivo($_FILES['pacote_dxf'], ['zip', 'rar', '7z', 'dxf'], 'pacote DXF');

            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do DXF.");
            }

            $codigoDxf = $this->gerarProximoCodigoDxf($ref);

            $arquivoSalvo = $this->salvarArquivoSolicitacao(
                $saveCarga['id'],
                $ref,
                $_FILES['pacote_dxf'],
                'PACOTE_DXF',
                "{$baseUploadDir}/dxf",
                "{$baseUploadPath}/dxf",
                $usuarioLogado,
                $codigoDxf
            );

            $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Pacote DXF {$codigoDxf} adicionado à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            // Web -> Access: copia o zip pra pasta mapeada (.dxf/{codigo}.zip)
            $this->copiarDxfParaAccess($codigoDxf, $arquivoSalvo['caminho_fisico']);

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Pacote DXF {$codigoDxf} salvo com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar DXF da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar o pacote DXF.");
        }
    }
```

---

## 5. PHP — métodos NOVOS no `DesenvolvimentoController`

`uploadDxfVba` (Access→Web), `removerArquivoPorCodigo`, `copiarDxfParaAccess`
(Web→Access) e `csvDxf` (pull). **ANTES: não existiam.**

### DEPOIS (100%)
```php
    /**
     * Access -> Web: recebe UM pacote DXF (zip) enviado pelo VBA (ufdxf) como corpo
     * binário cru. Usa o `codigo` JÁ atribuído pelo Access via cartório (nextDxf),
     * tipo PACOTE_DXF. Se já houver DXF de mesmo codigo, substitui. Sem trava.
     * Parâmetros via query: ?ref=NNN&codigo=DX0001&nome=arquivo.zip
     */
    public function uploadDxfVba()
    {
        $ref    = (int) (Request::query('ref') ?? 0);
        $codigo = trim((string) (Request::query('codigo') ?? ''));
        $nome   = Request::query('nome') ?: (($codigo !== '' ? $codigo : ('SL' . $ref)) . '.zip');

        if ($ref <= 0)      return Json::return(['error' => 'ref inválido'], 400);
        if ($codigo === '') return Json::return(['error' => 'codigo obrigatório'], 400);

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) return Json::return(['error' => 'solicitação não encontrada'], 404);

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado  = 'ACCESS';
        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();
            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);
            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do DXF.");
            }

            // Substitui o DXF anterior de MESMO codigo (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivoPorCodigo($ref, 'PACOTE_DXF', $codigo);

            $diretorioFisico   = "{$baseUploadDir}/dxf";
            $diretorioRelativo = "{$baseUploadPath}/dxf";
            if (!is_dir($diretorioFisico)) {
                mkdir($diretorioFisico, 0777, true);
            }

            $extensao   = strtolower(pathinfo($nome, PATHINFO_EXTENSION)) ?: 'zip';
            $nomeSeguro = $this->gerarNomeArquivoSeguro((string) $ref, 'PACOTE_DXF', $extensao);
            $caminhoFisico   = "{$diretorioFisico}/{$nomeSeguro}";
            $caminhoRelativo = "{$diretorioRelativo}/{$nomeSeguro}";

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar o DXF.");
            }
            $caminhoFisicoNovo = $caminhoFisico;

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'PACOTE_DXF',
                'codigo'        => $codigo,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'application/zip',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);
            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro do DXF.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Pacote DXF '{$codigo}' adicionado (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro, 'codigo' => $codigo], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }
            error_log("Erro no uploadDxfVba {$ref}/{$codigo}: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar DXF'], 500);
        }
    }

    /**
     * Remove (registro + retorna caminhos físicos) o arquivo de um dado tipo/codigo
     * de uma SL, para que o re-upload substitua em vez de duplicar.
     */
    private function removerArquivoPorCodigo(string $ref, string $tipo, string $codigo): array
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT *
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref AND tipo = :tipo AND codigo = :codigo
        ");
        $stmt->execute([':ref' => $ref, ':tipo' => $tipo, ':codigo' => $codigo]);
        $arquivos = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        if (empty($arquivos)) {
            return [];
        }

        $fisicos = [];
        foreach ($arquivos as $arquivo) {
            $arquivoId = $arquivo->id ?? null;
            if (!$arquivoId) {
                continue;
            }

            $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');
            if (!empty($caminhoFisico)) {
                $fisicos[] = $caminhoFisico;
            }

            $pdo->prepare("DELETE FROM bd_device_request.solicitacao_anexo_arquivos WHERE id = :id")
                ->execute([':id' => $arquivoId]);
        }

        return $fisicos;
    }

    /**
     * Web -> Access: copia o pacote DXF para a pasta mapeada, com o nome que o VBA
     * espera: .dxf/{codigo}.zip  (ex.: .dxf/DX0001.zip — ver ufdxf/Carrega_DFX).
     */
    private function copiarDxfParaAccess(string $codigo, string $caminhoFisico): void
    {
        if (empty($caminhoFisico) || !is_file($caminhoFisico) || $codigo === '') {
            return;
        }

        $base = rtrim($_ENV['APP_ACCESS_DIR'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') {
            return; // sem pasta mapeada configurada -> não faz nada
        }

        $dir = $base . '/.dxf';
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
        }

        @copy($caminhoFisico, $dir . '/' . $codigo . '.zip'); // ex.: .dxf/DX0001.zip
    }

    /**
     * Web -> Access (pull): CSV dos pacotes DXF (PACOTE_DXF) p/ o VBA upsertar em
     * DXF_Control. Colunas: Controle;Solicitacao;Projeto;Descricao.
     * Controle = número do codigo (DX0001 -> 1); Solicitacao = "SL"+4 díg.;
     * Projeto = cod_z da SL. Descrição vem do nome do arquivo (web não modela a rica).
     */
    public function csvDxf()
    {
        if (ob_get_level()) ob_end_clean();

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=Dxf.csv');

        $pdo = SolicitacaoAnexoArquivo::getPDO();
        $rows = $pdo->query("
            SELECT a.ref AS ref, a.codigo AS codigo, a.nome_original AS nome, s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_anexo_arquivos a
            LEFT JOIN bd_device_request.solicitacoes s ON s.ref = a.ref
            WHERE a.tipo = 'PACOTE_DXF' AND a.codigo REGEXP '^DX[0-9]+$'
            ORDER BY a.codigo
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');
        fputs($file, "\xEF\xBB\xBF");
        fputcsv($file, ['Controle', 'Solicitacao', 'Projeto', 'Descricao'], ';');

        foreach ($rows as $r) {
            $controle = (int) preg_replace('/\D/', '', (string) $r->codigo);
            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);
            fputcsv($file, [$controle, $sl, $r->cod_z ?? '', $r->nome ?? ''], ';');
        }
        fclose($file);
        exit;
    }
```

---

## 6. Access — mudança de schema (manual)

No `DB_Projetos.accdb`, tabela **`DXF_Control`**, campo **`Controle`**:
**AutoNumeração → Número (Inteiro Longo)**. (Mesmo procedimento feito no `Ref` da `Fila`.)
Sem isso, o `INSERT ... (Controle, ...)` com número explícito é rejeitado.

---

## 7. VBA — módulo `Funcoes` (inteiro)

ANTES = pós-PDF; DEPOIS = +`pedirProximoDxf`, +`enviarDxfParaMySQL`, +`sincronizarDxfsDoMySQL`.

### ANTES (100%)
```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("D")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ChDir ("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
'==================== INTEGRACAO COM A WEB (MySQL) ====================
' Base da aplicacao web (mesma do workbook de Solicitacao)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Codifica um valor para querystring (UTF-8)
Public Function enc(ByVal v As Variant) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Access -> Web: envia a imagem do projeto (bytes) para a rota uploadImagemVba.
' ref = numero da SL (so o numero, sem "SL"); caminhoArquivo = .jpg local.
Public Function enviarImagemParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarImagemParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "Imagem nao encontrada para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadImagemVba?ref=" & ref & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarImagemParaMySQL = True
    Else
        MsgBox "Falha ao enviar imagem (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar imagem para a web:" & vbCrLf & Err.Description, vbCritical
End Function
' Access -> Web: envia UM desenho PDF (bytes) para a rota uploadDesenhoPdfVba.
' ref = numero da SL; codigo = nome do arquivo sem extensao; caminho = .pdf local.
Public Function enviarPdfDesenhoParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarPdfDesenhoParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "PDF nao encontrado para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDesenhoPdfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarPdfDesenhoParaMySQL = True
    Else
        MsgBox "Falha ao enviar PDF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar PDF para a web:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de desenhos PDF e faz upsert em PDF_Control.
' Os arquivos ja sao copiados pela web para .desenhos\ ; aqui so garantimos a
' linha em PDF_Control para o desenho aparecer na pdf_lst.
Public Sub sincronizarPdfsDoMySQL()
    Dim http        As Object
    Dim txt         As String
    Dim linhas()    As String
    Dim campos()    As String
    Dim i           As Long
    Dim sol         As String, proj As String, cod As String, rev As String
    Dim SQL         As String
    Dim ArrChk      As Variant
    Dim inseridos   As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/desenhosPdf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de PDFs (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM

    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                sol = Trim(campos(0))
                proj = Trim(campos(1))
                cod = Trim(campos(2))
                rev = Trim(campos(3))

                SQL = "SELECT Codigo FROM PDF_Control WHERE Codigo = '" & Replace(cod, "'", "''") & _
                      "' AND Solicitacao = '" & Replace(sol, "'", "''") & "';"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ('" & _
                          Replace(proj, "'", "''") & "','" & Replace(sol, "'", "''") & "','" & _
                          Replace(cod, "'", "''") & "','" & Replace(rev, "'", "''") & "');"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de PDFs concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar PDFs:" & vbCrLf & Err.Description, vbCritical
End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("D")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ChDir ("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
'==================== INTEGRACAO COM A WEB (MySQL) ====================
' Base da aplicacao web (mesma do workbook de Solicitacao)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Codifica um valor para querystring (UTF-8)
Public Function enc(ByVal v As Variant) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Access -> Web: envia a imagem do projeto (bytes) para a rota uploadImagemVba.
' ref = numero da SL (so o numero, sem "SL"); caminhoArquivo = .jpg local.
Public Function enviarImagemParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarImagemParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "Imagem nao encontrada para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadImagemVba?ref=" & ref & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarImagemParaMySQL = True
    Else
        MsgBox "Falha ao enviar imagem (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar imagem para a web:" & vbCrLf & Err.Description, vbCritical
End Function
' Access -> Web: envia UM desenho PDF (bytes) para a rota uploadDesenhoPdfVba.
' ref = numero da SL; codigo = nome do arquivo sem extensao; caminho = .pdf local.
Public Function enviarPdfDesenhoParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarPdfDesenhoParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "PDF nao encontrado para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDesenhoPdfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarPdfDesenhoParaMySQL = True
    Else
        MsgBox "Falha ao enviar PDF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar PDF para a web:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de desenhos PDF e faz upsert em PDF_Control.
' Os arquivos ja sao copiados pela web para .desenhos\ ; aqui so garantimos a
' linha em PDF_Control para o desenho aparecer na pdf_lst.
Public Sub sincronizarPdfsDoMySQL()
    Dim http        As Object
    Dim txt         As String
    Dim linhas()    As String
    Dim campos()    As String
    Dim i           As Long
    Dim sol         As String, proj As String, cod As String, rev As String
    Dim SQL         As String
    Dim ArrChk      As Variant
    Dim inseridos   As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/desenhosPdf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de PDFs (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM

    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                sol = Trim(campos(0))
                proj = Trim(campos(1))
                cod = Trim(campos(2))
                rev = Trim(campos(3))

                SQL = "SELECT Codigo FROM PDF_Control WHERE Codigo = '" & Replace(cod, "'", "''") & _
                      "' AND Solicitacao = '" & Replace(sol, "'", "''") & "';"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ('" & _
                          Replace(proj, "'", "''") & "','" & Replace(sol, "'", "''") & "','" & _
                          Replace(cod, "'", "''") & "','" & Replace(rev, "'", "''") & "');"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de PDFs concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar PDFs:" & vbCrLf & Err.Description, vbCritical
End Sub
' Cartorio do numero de DXF: pede o proximo Controle a web (GET_LOCK no servidor).
' floor = MAX(Controle) atual do Access (para o contador nao reiniciar/colidir).
Public Function pedirProximoDxf(ByVal floor As Long) As Long
    Dim http As Object
    Dim txt As String
    Dim p As Long
    Dim s As String
    Dim ch As String

    pedirProximoDxf = 0
    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/desenvolvimento/nextDxf?floor=" & floor, False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao pedir numero DXF (HTTP " & http.Status & ")", vbExclamation
        Exit Function
    End If

    ' Extrai o numero apos "controle": do JSON {"controle":N,"codigo":"DX000N"}
    txt = http.responseText
    p = InStr(txt, """controle""")
    If p = 0 Then Exit Function
    p = InStr(p, txt, ":") + 1
    s = ""
    Do While p <= Len(txt)
        ch = Mid(txt, p, 1)
        If ch >= "0" And ch <= "9" Then
            s = s & ch
        ElseIf s <> "" Then
            Exit Do
        End If
        p = p + 1
    Loop
    If s <> "" Then pedirProximoDxf = CLng(s)
    Exit Function
erro:
    MsgBox "Erro ao pedir numero DXF:" & vbCrLf & Err.Description, vbCritical
End Function

' Access -> Web: envia UM pacote DXF (zip) para a rota uploadDxfVba.
Public Function enviarDxfParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http As Object
    Dim stream As Object
    Dim dados() As Byte
    Dim url As String
    Dim nomeArq As String

    enviarDxfParaMySQL = False
    If Dir(caminhoArquivo) = "" Then
        MsgBox "Pacote DXF nao encontrado:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDxfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarDxfParaMySQL = True
    Else
        MsgBox "Falha ao enviar DXF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar DXF:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de DXF e faz upsert em DXF_Control (insere os que faltam).
' O Controle vem do MySQL (cartorio), por isso pode ser inserido explicito.
Public Sub sincronizarDxfsDoMySQL()
    Dim http As Object
    Dim txt As String
    Dim linhas() As String
    Dim campos() As String
    Dim i As Long
    Dim ctrl As String, sol As String, proj As String, desc As String
    Dim SQL As String
    Dim ArrChk As Variant
    Dim inseridos As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/dxf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de DXF (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM
    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                ctrl = Trim(campos(0))
                sol = Trim(campos(1))
                proj = Trim(campos(2))
                desc = Trim(campos(3))

                SQL = "SELECT Controle FROM DXF_Control WHERE Controle = " & Val(ctrl) & ";"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO DXF_Control (Controle, Solicitacao, Cod_Proj, Descricao, IMG, DXF) VALUES (" & _
                          Val(ctrl) & ",'" & Replace(sol, "'", "''") & "','" & Replace(proj, "'", "''") & "','" & _
                          Replace(desc, "'", "''") & "', TRUE, TRUE);"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de DXF concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar DXF:" & vbCrLf & Err.Description, vbCritical
End Sub
```

---

## 8. VBA — `ufdxf` (módulo inteiro)

Mudou `btn_novo_dxf_Click`: pede o número ao cartório, INSERT com `Controle` explícito,
caminhos `F:`→`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE`, e push `enviarDxfParaMySQL`.

### ANTES (100%)
```vb
Attribute VB_Name = "ufdxf"
Attribute VB_Base = "0{B8E8382F-16FA-4CDF-ACA0-E5E314F4ABB7}{679F29D4-B76B-4260-BF75-D3DF48D88559}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Private Sub btn_novo_dxf_Click()
'Carrega DXFs

Dim dxf_path As String

dxf_path = AbreZIP

t_desc = frmsol.lbl_desc.Caption
t_cod_z = frmsol.lbl_cod_z.Caption
ctrl = Replace(t_cod_z, "Z", "")
t_cod_sl = frmsol.lbl_ref.Caption
t_projeto = frmsol.lbl_vg.Caption & "_" & frmsol.lbl_lote.Caption
t_projetista = frmsol.lbl_projetista.Caption
t_prioridade = UF.cmb_prio_dxf.Text
t_data_dxf = DateValue(Date)

SQL = "INSERT INTO DXF_Control (Descricao, Cod_Proj, Solicitacao, Projeto, Projetista, Prioridade, Data_DXF, IMG, DXF) VALUES ("
SQL = SQL & "'" & t_desc & "',"
SQL = SQL & "'" & t_cod_z & "',"
SQL = SQL & "'" & t_cod_sl & "',"
SQL = SQL & "'" & t_projeto & "',"
SQL = SQL & "'" & t_projetista & "',"
SQL = SQL & "'" & t_prioridade & "',"
SQL = SQL & "'" & t_data_dxf & "', TRUE, TRUE)"

upQuery (SQL)

arrUltimo = resQuery("SELECT MAX(Controle) FROM DXF_Control;")
t_cod_dxf = "DX" & Format(arrUltimo(0, 0), "0000")

newPathDXF = "F:\eng_ind\PROJETOS_Controle\Controle\.dxf" 'Folder dos arquivos DXF
Dim fs As Object
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile dxf_path, newPathDXF & "\" & t_cod_dxf & ".zip"
Set fs = Nothing

img_path = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & t_cod_sl & ".jpg"
newPathIMG = "F:\eng_ind\PROJETOS_Controle\Controle\.imgs" 'Folder das imagens DXF
Dim FS2 As Object
Set FS2 = CreateObject("Scripting.FileSystemObject")
FS2.CopyFile img_path, newPathIMG & "\" & t_cod_dxf & ".jpg"
Set FS2 = Nothing

MsgBox "Pacote de DXF nº " & t_cod_dxf & " inserido com sucesso!"

Call Carrega_DFX(frmsol.lbl_ref.Caption)

Unload Me

End Sub

Private Sub btn_reparar_Click()
Dim SQL As String

SQL = "SELECT Controle FROM DXF_Control WHERE Solicitacao ='" & frmsol.lbl_ref.Caption & "';"

ArrRes = resQuery(SQL)
If Not IsEmpty(ArrRes) Then
uf_lista_dxf.lst_dxf.Clear
For a = 0 To UBound(ArrRes, 2)
    uf_lista_dxf.lst_dxf.AddItem ("DX" & Format(ArrRes(0, a), "0000"))
Next a
End If

Unload Me
uf_lista_dxf.Show

End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "ufdxf"
Attribute VB_Base = "0{B8E8382F-16FA-4CDF-ACA0-E5E314F4ABB7}{679F29D4-B76B-4260-BF75-D3DF48D88559}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Private Sub btn_novo_dxf_Click()
'Carrega DXFs

Dim dxf_path As String
Dim floorDxf As Long
Dim controleDxf As Long
Dim arrMax As Variant

dxf_path = AbreZIP

t_desc = frmsol.lbl_desc.Caption
t_cod_z = frmsol.lbl_cod_z.Caption
ctrl = Replace(t_cod_z, "Z", "")
t_cod_sl = frmsol.lbl_ref.Caption
t_projeto = frmsol.lbl_vg.Caption & "_" & frmsol.lbl_lote.Caption
t_projetista = frmsol.lbl_projetista.Caption
t_prioridade = UF.cmb_prio_dxf.Text
t_data_dxf = DateValue(Date)

' Cartorio: pede o numero global do DXF a web (passando o MAX local como piso)
floorDxf = 0
arrMax = resQuery("SELECT MAX(Controle) FROM DXF_Control;")
If Not IsEmpty(arrMax) Then If Not IsNull(arrMax(0, 0)) Then floorDxf = CLng(arrMax(0, 0))
controleDxf = pedirProximoDxf(floorDxf)
If controleDxf <= 0 Then
    MsgBox "Nao foi possivel obter o numero do DXF (web). Operacao cancelada.", vbExclamation
    Exit Sub
End If

' INSERT com Controle EXPLICITO (Controle agora e Numero, nao AutoNumeracao)
SQL = "INSERT INTO DXF_Control (Controle, Descricao, Cod_Proj, Solicitacao, Projeto, Projetista, Prioridade, Data_DXF, IMG, DXF) VALUES ("
SQL = SQL & controleDxf & ","
SQL = SQL & "'" & t_desc & "',"
SQL = SQL & "'" & t_cod_z & "',"
SQL = SQL & "'" & t_cod_sl & "',"
SQL = SQL & "'" & t_projeto & "',"
SQL = SQL & "'" & t_projetista & "',"
SQL = SQL & "'" & t_prioridade & "',"
SQL = SQL & "'" & t_data_dxf & "', TRUE, TRUE)"

upQuery (SQL)

t_cod_dxf = "DX" & Format(controleDxf, "0000")

newPathDXF = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.dxf" 'Folder dos arquivos DXF
Dim fs As Object
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile dxf_path, newPathDXF & "\" & t_cod_dxf & ".zip"
Set fs = Nothing

' Access -> Web: envia o pacote DXF pro MySQL/web
enviarDxfParaMySQL CLng(Replace(t_cod_sl, "SL", "")), t_cod_dxf, newPathDXF & "\" & t_cod_dxf & ".zip"

img_path = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & t_cod_sl & ".jpg"
newPathIMG = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.imgs" 'Folder das imagens DXF
Dim FS2 As Object
Set FS2 = CreateObject("Scripting.FileSystemObject")
FS2.CopyFile img_path, newPathIMG & "\" & t_cod_dxf & ".jpg"
Set FS2 = Nothing

MsgBox "Pacote de DXF nº " & t_cod_dxf & " inserido com sucesso!"

Call Carrega_DFX(frmsol.lbl_ref.Caption)

Unload Me

End Sub

Private Sub btn_reparar_Click()
Dim SQL As String

SQL = "SELECT Controle FROM DXF_Control WHERE Solicitacao ='" & frmsol.lbl_ref.Caption & "';"

ArrRes = resQuery(SQL)
If Not IsEmpty(ArrRes) Then
uf_lista_dxf.lst_dxf.Clear
For a = 0 To UBound(ArrRes, 2)
    uf_lista_dxf.lst_dxf.AddItem ("DX" & Format(ArrRes(0, a), "0000"))
Next a
End If

Unload Me
uf_lista_dxf.Show

End Sub
```

---

## 9. VBA — `uf_lista_dxf` (módulo inteiro)

Mudou `btn_reparar_Click` (substituir zip): caminho `F:`→`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` + push.

### ANTES (100%)
```vb
Attribute VB_Name = "uf_lista_dxf"
Attribute VB_Base = "0{C6C3BE26-6BD1-458D-AA46-09A5483E6F35}{BC7A82BD-BBB1-4B50-A590-39AF7A124C5E}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Private Sub btn_carregar_Click()
'Carrega DXFs
Dim dxf_path As String
dxf_path = AbreZIP

Me.lbl_path_dxf.Caption = dxf_path

Me.lbl_ok.ForeColor = &H4000&
Me.lbl_ok.BackColor = &HC000&
Me.btn_reparar.Enabled = True




End Sub

Private Sub btn_reparar_Click()
Dim SLQ As String

t_cod_dxf = Me.lst_dxf.Text
n_ctrl = Replace(t_cod_dxf, "DX", "")
t_data_dxf = DateValue(Date)

SQL = "UPDATE DXF_Control SET Data_DXF = " & t_data_dxf & " WHERE Controle = " & n_ctrl & ";"
upQuery (SQL)

dxf_path = Me.lbl_path_dxf.Caption

newPathDXF = "F:\eng_ind\PROJETOS_Controle\Controle\.dxf" 'Folder dos pacotes DXF
Dim fs As Object
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile dxf_path, newPathDXF & "\" & t_cod_dxf & ".zip"
Set fs = Nothing

MsgBox "Pacote de DXF nº " & t_cod_dxf & " substituído com sucesso!"

Call Carrega_DFX(frmsol.lbl_ref.Caption)

Unload Me



End Sub

Private Sub lst_dxf_Click()

If Me.lst_dxf.Text <> "" Then

    Me.btn_carregar.Enabled = True

End If

End Sub
```

### DEPOIS (100%)
```vb
Attribute VB_Name = "uf_lista_dxf"
Attribute VB_Base = "0{C6C3BE26-6BD1-458D-AA46-09A5483E6F35}{BC7A82BD-BBB1-4B50-A590-39AF7A124C5E}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Private Sub btn_carregar_Click()
'Carrega DXFs
Dim dxf_path As String
dxf_path = AbreZIP

Me.lbl_path_dxf.Caption = dxf_path

Me.lbl_ok.ForeColor = &H4000&
Me.lbl_ok.BackColor = &HC000&
Me.btn_reparar.Enabled = True




End Sub

Private Sub btn_reparar_Click()
Dim SLQ As String

t_cod_dxf = Me.lst_dxf.Text
n_ctrl = Replace(t_cod_dxf, "DX", "")
t_data_dxf = DateValue(Date)

SQL = "UPDATE DXF_Control SET Data_DXF = " & t_data_dxf & " WHERE Controle = " & n_ctrl & ";"
upQuery (SQL)

dxf_path = Me.lbl_path_dxf.Caption

newPathDXF = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.dxf" 'Folder dos pacotes DXF
Dim fs As Object
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile dxf_path, newPathDXF & "\" & t_cod_dxf & ".zip"
Set fs = Nothing

' Access -> Web: reenvia o pacote DXF substituido
enviarDxfParaMySQL CLng(Replace(frmsol.lbl_ref.Caption, "SL", "")), t_cod_dxf, newPathDXF & "\" & t_cod_dxf & ".zip"

MsgBox "Pacote de DXF nº " & t_cod_dxf & " substituído com sucesso!"

Call Carrega_DFX(frmsol.lbl_ref.Caption)

Unload Me



End Sub

Private Sub lst_dxf_Click()

If Me.lst_dxf.Text <> "" Then

    Me.btn_carregar.Enabled = True

End If

End Sub
```

