# Desenhos PDF — Access ↔ MySQL

Segunda fatia da **Parte 2** (desenvolvimento). Sincroniza os **desenhos em PDF**
(vários por SL) entre o workbook `Lista de Solicitações` e a web.

> 📎 **Código 100% completo (antes/depois):** [desenhos-pdf-codigo.md](desenhos-pdf-codigo.md).

---

## 1. Como cada lado guardava (ANTES)

| | Access (`Lista`) | Web (MySQL) |
|---|---|---|
| **Arquivo** | `.desenhos\SL{ref} - {codigo}.pdf` (+ cópia em `desenhosPDF\{SL}\`) | `.../{ref}/desenhos_pdf/<nome>` |
| **Registro** | linha em **`PDF_Control`** (Projeto, Solicitacao, Codigo, Revisao) | `solicitacao_anexo_arquivos` tipo `DESENHO_PDF` (+ `cargas`) |
| **Lista na tela** | `frmsol.pdf_lst` ← lê **`PDF_Control`** (`M_Abre_UF.carrega_pdf`) | grid do `info` |
| **Gatilho** | `frmaut.btn_pdf_novo` **e** `frmsol.btn_pdf_novo` (código idêntico) | `storeDesenhosPdf` |
| **Sincronizava?** | ❌ não | ❌ não |

**Diferença-chave vs. imagem:** a imagem não tinha registro no Access (era só o
arquivo). O PDF **precisa de uma linha em `PDF_Control`** pra aparecer na `pdf_lst`.
A identidade do PDF nos dois lados é o **`codigo`** (= nome do arquivo sem extensão).

---

## 2. Como ficou (DEPOIS)

```
Access adiciona PDFs (frmaut.btn_pdf_novo)
   → INSERT PDF_Control + copia p/ K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\SL{ref} - {codigo}.pdf
   → enviarPdfDesenhoParaMySQL (POST binário, 1 por arquivo) ──► uploadDesenhoPdfVba
                                                                  carga + arquivo DESENHO_PDF (codigo) + histórico

Web adiciona PDFs (storeDesenhosPdf)
   → salva em .../desenhos_pdf/ com `codigo` (= nome do arquivo)
   → copiarDesenhoPdfParaAccess → {APP_ACCESS_DIR}/.desenhos/SL{ref} - {codigo}.pdf   (o arquivo)
   → sincronizarPdfsDoMySQL (no Access) baixa csvDesenhosPdf e faz upsert em PDF_Control   (a linha)
```

| | ANTES | DEPOIS |
|---|---|---|
| PDF adicionado no Access subia? | ❌ | ✅ `enviarPdfDesenhoParaMySQL` → `uploadDesenhoPdfVba` |
| PDF adicionado na web descia (arquivo)? | ❌ | ✅ `copiarDesenhoPdfParaAccess` |
| PDF da web aparecia na `pdf_lst`? | ❌ | ✅ `sincronizarPdfsDoMySQL` (upsert `PDF_Control`) |
| Web guardava `codigo` do PDF? | ❌ (null) | ✅ = nome do arquivo |
| Caminhos VBA | `F:\eng_ind\...` | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\` |

---

## 3. O que foi feito, onde e como

### 3.1 PHP — `uploadDesenhoPdfVba` (Access → Web)
- **Rota:** `POST /dispositivos/desenvolvimento/uploadDesenhoPdfVba` (`ref`, `codigo`, `nome` via query).
- Lê o binário cru; cria carga; **substitui** o PDF de mesmo `codigo`
  (`removerArquivoDesenhoPorCodigo`); grava em `.../desenhos_pdf/`; registra
  `DESENHO_PDF` com `codigo`; `Historico`. **Sem trava de status.**

### 3.2 PHP — `storeDesenhosPdf` (Web, ajustado)
- Passa `codigo` (= nome do arquivo) ao salvar e, após o commit, chama
  `copiarDesenhoPdfParaAccess` para cada PDF.

### 3.3 PHP — `copiarDesenhoPdfParaAccess` (Web → Access, arquivo)
- Copia pra `{APP_ACCESS_DIR}/.desenhos/SL{ref} - {codigo}.pdf` (4 dígitos), o nome
  que o `frmsol.pdf_lst_DblClick` abre.

### 3.4 PHP — `csvDesenhosPdf` (Web → Access, registro)
- CSV `Solicitacao;Projeto;Codigo;Revisao` de todos os `DESENHO_PDF` (Solicitacao =
  `SL`+4 díg.; Projeto = `cod_z` da SL). Consumido pelo VBA.

### 3.5 VBA — `Funcoes`
- `enviarPdfDesenhoParaMySQL(ref, codigo, caminho)` — POST binário (1 por PDF).
- `sincronizarPdfsDoMySQL()` — baixa o CSV e faz **upsert** em `PDF_Control`
  (insere os que faltam). Os arquivos já vieram pela web.

### 3.6 VBA — `frmaut` **e** `frmsol`
Os dois forms têm o mesmo `btn_pdf_novo` (add) e `pdf_lst_DblClick` (abrir):
- Caminhos `F:\eng_ind\...` → `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\` (`desenhosPDF\`, `.desenhos\`).
- `btn_pdf_novo`: após copiar local, chama `enviarPdfDesenhoParaMySQL` por arquivo.
- `pdf_lst_DblClick`: abre o PDF de `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\`.

> **Não incluído nesta fatia:** o `UF.btn_carregar` (carga em massa da criação do
> dev) também carrega PDFs, mas mistura DXF/BOM — fica para a fatia de criação.
> A exclusão (`pdf_lst_KeyPress`) apaga só do `PDF_Control` local (sem sync de delete).

---

## 4. Passo a passo para testar

1. **Re-deploy** do `routes.php` + `DesenvolvimentoController.php`.
2. Aplicar o VBA cumulativo (`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\Funcoes.txt` e `frmaut.txt`).
3. No `frmaut`, adicione 1+ PDFs (`btn_pdf_novo`) → confira:
   - `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\SL{ref} - {codigo}.pdf` criado;
   - na web:
     ```sql
     SELECT ref, tipo, codigo, nome_arquivo FROM bd_device_request.solicitacao_anexo_arquivos
      WHERE ref = <REF> AND tipo = 'DESENHO_PDF';
     ```
4. Adicione um PDF **pela web** → rode `sincronizarPdfsDoMySQL` no Access → o desenho
   aparece na `pdf_lst` (linha em `PDF_Control` + arquivo já em `.desenhos`).

---

## 5. Limitações / escopo

- **Sem trava de status** na rota VBA (espelha o Access; mesma decisão da imagem).
- **Revisão**: a web não controla revisão de PDF — `PDF_Control.Revisao` entra como `0`.
- **Pull manual**: `sincronizarPdfsDoMySQL` é botão/macro (ainda não automatizado).
- O `btn_pdf` (Ficha_Resumo) **não** faz parte desta fatia — é outro PDF (resumo
  gerado da planilha), não os desenhos.

---

## 6. Arquivos-chave

| Item | Caminho |
|---|---|
| Rota push | `routes.php` → `dispositivos/desenvolvimento/uploadDesenhoPdfVba` |
| Rota pull (CSV) | `routes.php` → `dispositivos/csvAtualizado/desenhosPdf` |
| Método Access→Web | `DesenvolvimentoController::uploadDesenhoPdfVba` |
| Web→Access (arquivo) | `DesenvolvimentoController::copiarDesenhoPdfParaAccess` (no `storeDesenhosPdf`) |
| Web→Access (registro) | `DesenvolvimentoController::csvDesenhosPdf` + VBA `sincronizarPdfsDoMySQL` |
| VBA push | `Funcoes.enviarPdfDesenhoParaMySQL` + `btn_pdf_novo` (`frmaut` e `frmsol`) |
| VBA abrir | `pdf_lst_DblClick` (`frmaut` e `frmsol`) → `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\` |
| VBA pull | `Funcoes.sincronizarPdfsDoMySQL` |
| Módulos prontos | `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\{Funcoes,frmaut,frmsol}.txt` (cumulativo) |
