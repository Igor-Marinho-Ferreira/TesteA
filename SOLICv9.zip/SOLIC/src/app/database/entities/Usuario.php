<?php

namespace src\app\database\entities;

use src\app\database\Querio;
use src\app\database\Database;
use PDO;
use Exception;

class Usuario extends Querio
{
    protected static string $table  = 'bd_device_request.usuarios';
    protected static string $dbType = 'intranet';

    /**
     * Retorna o nome do usuário logado no padrão do Access.
     * Uso principal: histórico/comentário feito pela web, mas com nome compatível com Access.
     */
    public static function nomeNoAccess(): string
    {
        $padrao = $_SESSION['usuarioNome'] ?? ($_SESSION['user']['nome'] ?? 'Sistema');

        try {
            $pdo = static::getPDO();

            // 1) E-mail do logado: da sessão, ou da tabela usuarios pela matrícula/login
            $email = $_SESSION['user']['email'] ?? null;

            if (!$email && !empty($_SESSION['usuarioLogin'])) {
                $st = $pdo->prepare("
                    SELECT email 
                    FROM bd_device_request.usuarios 
                    WHERE matricula = :m 
                    LIMIT 1
                ");
                $st->execute([':m' => $_SESSION['usuarioLogin']]);
                $email = $st->fetchColumn() ?: null;
            }

            $email = strtolower(trim((string) $email));

            if ($email === '') {
                return $padrao;
            }

            // 2) Nome do Access casando pelo e-mail
            $st = $pdo->prepare("
                SELECT nome 
                FROM bd_device_request.solicitantes_access 
                WHERE LOWER(email) = :e 
                LIMIT 1
            ");
            $st->execute([':e' => $email]);

            $nome = $st->fetchColumn();

            return $nome ?: $padrao;
        } catch (\Throwable $e) {
            return $padrao;
        }
    }

    /**
     * MySQL/Web -> Access
     *
     * Recebe o solicitante no padrão do MySQL, normalmente bd_device_request.usuarios.nome,
     * ou eventualmente um e-mail, e retorna o nome equivalente na tabela solicitantes_access.
     *
     * Exemplo:
     * usuarios.nome -> usuarios.email -> solicitantes_access.nome
     */
    public static function nomeNoAccessPorSolicitante(?string $solicitante): string
    {
        $padrao = trim((string) $solicitante);

        if ($padrao === '') {
            return '';
        }

        try {
            $pdo = static::getPDO();

            $email = '';

            // Se já veio e-mail, usa direto
            if (filter_var($padrao, FILTER_VALIDATE_EMAIL)) {
                $email = strtolower(trim($padrao));
            } else {
                // Se veio nome do sistema/MySQL, busca o e-mail em usuarios
                $st = $pdo->prepare("
                    SELECT email
                    FROM bd_device_request.usuarios
                    WHERE nome = :nome
                    LIMIT 1
                ");
                $st->execute([':nome' => $padrao]);
                $email = strtolower(trim((string) ($st->fetchColumn() ?: '')));
            }

            if ($email === '') {
                return $padrao;
            }

            // Com o e-mail, busca o nome no padrão do Access
            $st = $pdo->prepare("
                SELECT nome
                FROM bd_device_request.solicitantes_access
                WHERE LOWER(email) = :email
                LIMIT 1
            ");
            $st->execute([':email' => $email]);

            $nomeAccess = $st->fetchColumn();

            return $nomeAccess ?: $padrao;
        } catch (\Throwable $e) {
            return $padrao;
        }
    }

    /**
     * Access -> MySQL/Web
     *
     * Recebe o solicitante no padrão do Access, normalmente solicitantes_access.nome,
     * ou eventualmente um e-mail, e retorna o nome equivalente na tabela usuarios.
     *
     * Exemplo:
     * solicitantes_access.nome -> solicitantes_access.email -> usuarios.nome
     */
    public static function nomeSistemaPorNomeAccess(?string $nomeAccess): string
    {
        $padrao = trim((string) $nomeAccess);

        if ($padrao === '') {
            return '';
        }

        try {
            $pdo = static::getPDO();

            $email = '';

            // Se já veio e-mail, usa direto
            if (filter_var($padrao, FILTER_VALIDATE_EMAIL)) {
                $email = strtolower(trim($padrao));
            } else {
                // Se veio nome do Access, busca o e-mail na solicitantes_access
                $st = $pdo->prepare("
                    SELECT email
                    FROM bd_device_request.solicitantes_access
                    WHERE nome = :nome
                    LIMIT 1
                ");
                $st->execute([':nome' => $padrao]);
                $email = strtolower(trim((string) ($st->fetchColumn() ?: '')));
            }

            if ($email === '') {
                return $padrao;
            }

            // Com o e-mail, busca o nome no padrão do sistema/MySQL
            $st = $pdo->prepare("
                SELECT nome
                FROM bd_device_request.usuarios
                WHERE LOWER(email) = :email
                LIMIT 1
            ");
            $st->execute([':email' => $email]);

            $nomeSistema = $st->fetchColumn();

            return $nomeSistema ?: $padrao;
        } catch (\Throwable $e) {
            return $padrao;
        }
    }

    public static function findSeniorByMatricula($matricula)
    {
        $db = Database::get('senior');

        try {
            $sql = "
                SELECT 
                    f.numcad AS matricula,
                    f.nomfun AS nome,
                    c.nomccu AS area,
                    e.emacom AS email
                FROM senior.R034fun f
                LEFT JOIN senior.R018ccu c 
                    ON c.codccu = f.codccu
                LEFT JOIN senior.r034cpl e 
                    ON e.numcad = f.numcad
                WHERE f.numcad = :matricula
            ";

            $stmt = $db->prepare($sql);
            $stmt->execute(['matricula' => $matricula]);

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return false;
        }
    }

    public static function getAllLeader()
    {
        $query = static::select(['nome'], false)
            ->where('role', '=', 'LÍDER DE PROJETO')
            ->andWhere('status', '=', 'ATIVO');

        $result = $query->finish();

        return $result;
    }

    public static function getSolicRole($nomeSolic)
    {
        $role = static::select(['role'], false)
            ->where('nome', '=', $nomeSolic)
            ->finish();

        if (!$role) {
            return false;
        }

        return array_column($role, 'role');
    }

    public static function getAllByNome($nome, $tipo)
    {
        $query = static::select(['nome'], false)
            ->where('nome', 'like', "%{$nome}%");

        if ($tipo == 'projetista') {
            $query->andWhere('role', '=', 'projetista');
        }

        $result = $query->finish();

        return $result === false ? [] : $result;
    }
}