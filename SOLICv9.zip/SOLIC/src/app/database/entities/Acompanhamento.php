<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

class Acompanhamento extends Querio
{
    protected static string $table = 'bd_device_request.fila';
    protected static string $dbType = 'intranet';

    public static function getAllNaoFinalizadoBySolic($status, $solicitante, $projetista, $coluna)
    {
        $query = static::select(['*'], false);
        $query->where('ref', '>', 0);

        $statusPendentes = ['pendente', 'modelo', 'backlog', '[VALIDAÇÃO]', 'andamento', 'parado', 'revisar', 'em andamento', 'EM ANÁLISE'];
        $statusConcluidos = ['finalizado', 'ok', 'pausado', 'cancelado'];


        if (!empty($coluna) && !empty($status) && $status !== 'todos') {

            if ($status === 'EM ANÁLISE') {
                $query->andWhere($coluna, '=', 'EM ANÁLISE');
            } else {
                $query->andIn($coluna, $statusPendentes);
            }

            $dependencias = [
                'detalhamento_status' => ['conceito_status'],
                'liberacao_status'     => ['conceito_status', 'detalhamento_status'],
                'corte_status'         => ['conceito_status', 'detalhamento_status', 'liberacao_status'],
                'exec_status'          => ['conceito_status', 'detalhamento_status', 'liberacao_status', 'corte_status'],
                'aquisicao_status'     => ['conceito_status', 'detalhamento_status', 'liberacao_status', 'corte_status', 'exec_status'],
                'tryout_status'        => ['conceito_status', 'detalhamento_status', 'liberacao_status', 'corte_status', 'exec_status', 'aquisicao_status']
            ];

            if (isset($dependencias[$coluna])) {
                foreach ($dependencias[$coluna] as $campoAnterior) {
                    $query->andIn($campoAnterior, $statusConcluidos);
                }
            }
        } else if (empty($coluna) && !empty($status) && $status !== 'todos') {
            if ($status === 'novos') {
                $status = 'pendente';
                $query->andWhereRaw(" (
            conceito_status = '$status' OR detalhamento_status = '$status' OR 
            liberacao_status = '$status' OR corte_status = '$status' OR 
            exec_status = '$status' OR aquisicao_status = '$status' OR tryout_status = '$status'
        ) and conceito_proj is null and detalhamento_proj is null ");
            }

            if ($status === 'projetos') {
                $status = 'pendente';
                $query->andWhereRaw(" (
            conceito_status = '$status' OR detalhamento_status = '$status' OR 
            liberacao_status = '$status' OR corte_status = '$status' OR 
            exec_status = '$status' OR aquisicao_status = '$status' OR tryout_status = '$status'
        ) and conceito_proj is not null and detalhamento_proj is not null ");
            }

            $query->andWhereRaw(" (
            conceito_status = '$status' OR detalhamento_status = '$status' OR 
            liberacao_status = '$status' OR corte_status = '$status' OR 
            exec_status = '$status' OR aquisicao_status = '$status' OR tryout_status = '$status'
        ) ");
        }

        // Agora essas variáveis existem porque estão na assinatura da função
        if (!empty($solicitante)) {
            $query->andWhere('solicitante', '=', $solicitante);
        }

        if (!empty($projetista)) {

            $query->andWhereRaw(" (conceito_proj = '$projetista' OR detalhamento_proj = '$projetista') ");
        }

        $results = $query->order('ref', 'DESC')->finish() ?: [];
        return $results;
    }


    // public static function updateStatus($ref, $coluna, $valor)
    // {
    //     $dadosParaAtualizar = [];

    //     // Se for um array de colunas, montamos o update para todas elas
    //     if (is_array($coluna)) {
    //         foreach ($coluna as $nomeColuna) {
    //             $dadosParaAtualizar[$nomeColuna] = $valor;
    //         }
    //     } else {
    //         $dadosParaAtualizar[$coluna] = $valor;

    //         if ($coluna === 'conceito_status' && $valor === 'MODELO') {
    //             $dadosParaAtualizar['conceito_inicio'] = date('Y-m-d');
    //         } else if ($coluna === 'conceito_status' && $valor === 'OK') {
    //             $dadosParaAtualizar['conceito_fim'] = date('Y-m-d');
    //             $dadosParaAtualizar['detalhamento_status'] = '[VALIDAÇÃO]';
    //         }

    //         if ($coluna === 'detalhamento_status' && $valor === 'PENDENTE') {
    //             $dadosParaAtualizar['conceito_status'] = 'MODELO';
    //             $dadosParaAtualizar['conceito_fim'] = null;
    //         }
    //     }

    //     return static::update($dadosParaAtualizar)
    //         ->where("ref", "=", $ref)
    //         ->finish();
    // }

public static function updateStatus($ref, $coluna, $valor)
{
    $dadosParaAtualizar = [];

    if (is_array($coluna)) {
        foreach ($coluna as $nomeColuna) {
            $dadosParaAtualizar[$nomeColuna] = $valor;
        }
    } else {
        $dadosParaAtualizar[$coluna] = $valor;

        if ($coluna === 'conceito_status' && $valor === 'MODELO') {
            $dadosParaAtualizar['conceito_inicio'] = date('Y-m-d H:i:s');
        } 
        else if ($coluna === 'conceito_status' && $valor === 'OK') {
            $dadosParaAtualizar['conceito_fim'] = date('Y-m-d H:i:s');
            $dadosParaAtualizar['detalhamento_status'] = '[VALIDAÇÃO]';
        }

        if ($coluna === 'detalhamento_status' && $valor === 'EM ANDAMENTO') {
            $dadosParaAtualizar['detalhamento_inicio'] = date('Y-m-d H:i:s');
        } 
        else if ($coluna === 'detalhamento_status' && $valor === 'OK') {
            $dadosParaAtualizar['detalhamento_fim'] = date('Y-m-d H:i:s');
        }

        if ($coluna === 'detalhamento_status' && $valor === 'PENDENTE') {
            $dadosParaAtualizar['conceito_status'] = 'MODELO';
            $dadosParaAtualizar['conceito_fim'] = null;
            $dadosParaAtualizar['detalhamento_inicio'] = null;
        }
    }

    return static::update($dadosParaAtualizar)
        ->where("ref", "=", $ref)
        ->finish();
}

    /**
     * Lista da tela INDUSTRIAL (2026-07-21, 4ª rodada).
     *
     * Traz as SLs já liberadas — que são as que o industrial pode tocar —
     * com os filtros da tela. Usa bind em todos os valores.
     *
     * @return array<int, object>
     */
    public static function getParaIndustrial($status = '', $solicitante = '', $equipe = '')
    {
        $query = static::select(['*'], false);
        $query->where('ref', '>', 0);

        // Só o que já passou pela liberação
        $query->andWhereRaw(" UPPER(TRIM(liberacao_status)) = 'OK' ");

        if (!empty($solicitante)) {
            $query->andWhere('solicitante', '=', $solicitante);
        }

        if (!empty($equipe)) {
            $query->andWhere('equipeei', '=', $equipe);
        }

        $status = strtoupper(trim((string) $status));

        if ($status !== '' && $status !== 'TODOS') {
            if ($status === 'PENDENTES') {
                // Ainda há corte OU execução em aberto
                $query->andWhereRaw("
                    (
                        UPPER(TRIM(COALESCE(corte_status, ''))) NOT IN ('FINALIZADO', 'TERCEIRIZADO', 'CANCELADO')
                        OR UPPER(TRIM(COALESCE(exec_status, ''))) NOT IN ('FINALIZADO', 'TERCEIRIZADO', 'CANCELADO')
                    )
                ");
            } else {
                // Um status específico em corte ou execução
                $query->andWhereRaw(
                    " (UPPER(TRIM(COALESCE(corte_status, ''))) = :statusIndCorte
                       OR UPPER(TRIM(COALESCE(exec_status, ''))) = :statusIndExec) ",
                    ['statusIndCorte' => $status, 'statusIndExec' => $status]
                );
            }
        }

        return $query->order('ref', 'DESC')->finish() ?: [];
    }

    /** Cache das colunas da tabela fila (por requisição). */
    private static ?array $colunasFila = null;

    /**
     * Colunas existentes na tabela fila. Usado para não montar UPDATE com
     * coluna inexistente (que derrubaria a gravação inteira).
     *
     * @return array<int, string>
     */
    public static function colunasFila(): array
    {
        if (self::$colunasFila !== null) {
            return self::$colunasFila;
        }

        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return self::$colunasFila = [];
            }

            $stmt = $pdo->prepare("
                SELECT COLUMN_NAME
                  FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = 'bd_device_request'
                   AND TABLE_NAME   = 'fila'
            ");
            $stmt->execute();

            return self::$colunasFila = array_map('strval', $stmt->fetchAll(\PDO::FETCH_COLUMN) ?: []);
        } catch (\Throwable $e) {
            error_log('Falha ao ler colunas da fila: ' . $e->getMessage());
            return self::$colunasFila = [];
        }
    }

    /**
     * Equipes distintas já usadas, para o filtro da lista industrial.
     *
     * @return array<int, string>
     */
    public static function equipesDistintas(): array
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return [];
            }

            $stmt = $pdo->prepare("
                SELECT DISTINCT equipeei
                  FROM bd_device_request.fila
                 WHERE equipeei IS NOT NULL
                   AND TRIM(equipeei) <> ''
              ORDER BY equipeei ASC
            ");

            $stmt->execute();

            return array_map('strval', $stmt->fetchAll(\PDO::FETCH_COLUMN) ?: []);
        } catch (\Throwable $e) {
            error_log('Falha ao listar equipes: ' . $e->getMessage());
            return [];
        }
    }

   public static function getAllTratado()
    {
        $query = "SELECT 
  f.id, 
  f.ref, 
  f.solicitante, 
  f.cod_z, 
  f.aplicacao, 
  f.vagao, 
  f.lote, 
  f.created_at, 
  f.updated_at, 
  f.conceito_proj, 
  f.conceito_status, 
  f.conceito_inicio, 
  f.conceito_fim, 
  f.detalhamento_proj, 
  f.detalhamento_status, 
  f.detalhamento_inicio, 
  f.detalhamento_fim, 
  f.liberacao_status, 
  f.liberacao_data, 
  f.corte_status, 
  f.corte_data, 
  f.exec_status, 
  f.exec_data, 
  f.tryout_status, 
  f.tryout_data, 
  f.prio, 
  f.data_solicitacao, 
  f.descricao, 
  f.aquisicao_status, 
  f.aquisicao_data, 
  f.classe, 
  f.conta, 
  f.qtdRev, 
  f.situacao, 
  (
    SELECT 
      GROUP_CONCAT(
        CONCAT(
          '-- ', 
          h.usuario, 
          ' (', 
          DATE_FORMAT(
            h.created_at, '%d.%m.%Y - %H:%i'
          ), 
          '):\n', 
          h.mensagem
        ) 
        ORDER BY 
          h.created_at ASC SEPARATOR '\n\n'
      ) 
    FROM 
      bd_device_request.historico h 
    WHERE 
      h.ref = f.ref
  ) AS historico 
FROM 
  bd_device_request.fila f;
";

        static::$queryString = $query;
        static::$selectIsOne = false;

        $result = static::finish();


        if (!is_array($result)) {
            return [];
        }
        return $result;
    }
}
