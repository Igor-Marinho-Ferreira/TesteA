<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class SolicitacaoItemComprado extends Querio
{
    protected static string $table = 'bd_device_request.solicitacao_itens_comprados';
    protected static string $dbType = 'intranet';

    /**
     * Cache do teste de existencia das colunas de aquisicao.
     * null = ainda nao testado nesta requisicao.
     */
    private static ?bool $colunasAquisicao = null;

    /** Colunas criadas pela migration 2026-07-21-aquisicao-itens-comprados.sql */
    public const COLUNAS_AQUISICAO = [
        'n_oc',
        'pedido',
        'liquidado',
        'liquidado_em',
        'sincronizado_em',
        'updated_by',
        'updated_at',
    ];

    /**
     * Informa se a migration de aquisicao ja foi aplicada.
     *
     * Enquanto o .sql nao for executado o modulo de aquisicao fica em modo
     * somente leitura, em vez de quebrar a tela com "Column not found".
     */
    public static function temColunasAquisicao(): bool
    {
        if (self::$colunasAquisicao !== null) {
            return self::$colunasAquisicao;
        }

        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return self::$colunasAquisicao = false;
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                  FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = 'bd_device_request'
                   AND TABLE_NAME   = 'solicitacao_itens_comprados'
                   AND COLUMN_NAME IN ('n_oc', 'pedido', 'liquidado')
            ");

            $stmt->execute();

            return self::$colunasAquisicao = ((int) $stmt->fetchColumn() === 3);
        } catch (\Throwable $e) {
            error_log('Falha ao verificar colunas de aquisicao: ' . $e->getMessage());

            return self::$colunasAquisicao = false;
        }
    }

    /**
     * Itens de uma SL, na ordem de carga.
     *
     * @return array<int, object>
     */
    public static function getPorRef(int $ref): array
    {
        return static::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'ASC')
            ->finish() ?: [];
    }

    /** A tabela de itens comprados existe? */
    public static function tabelaExiste(): bool
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return false;
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                  FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = 'bd_device_request'
                   AND TABLE_NAME   = 'solicitacao_itens_comprados'
            ");
            $stmt->execute();

            return ((int) $stmt->fetchColumn()) > 0;
        } catch (\Throwable $e) {
            error_log('Falha ao verificar solicitacao_itens_comprados: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * TODOS os itens comprados, com o contexto da SL (fila), para o
     * consolidado por descrição (2026-07-21, 7ª rodada).
     *
     * As colunas de aquisição (n_oc, liquidado) só entram se a migration
     * 2026-07-21-aquisicao já tiver rodado.
     *
     * @return array<int, object>
     */
    public static function todosComContexto(): array
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return [];
            }

            $temAquis = self::temColunasAquisicao();
            $colsAquis = $temAquis
                ? ', i.n_oc AS n_oc, i.pedido AS pedido, i.liquidado AS liquidado'
                : '';

            $stmt = $pdo->prepare("
                SELECT
                    i.id, i.ref, i.codigo, i.rev, i.descricao, i.quantidade, i.tipo
                    {$colsAquis},
                    f.cod_z            AS cod_z,
                    f.vagao            AS vagao,
                    f.lote             AS lote,
                    f.aplicacao        AS aplicacao,
                    f.conceito_proj      AS conceito_proj,
                    f.detalhamento_proj  AS detalhamento_proj
                  FROM bd_device_request.solicitacao_itens_comprados i
             LEFT JOIN bd_device_request.fila f ON f.ref = i.ref
              ORDER BY i.descricao ASC, i.ref ASC, i.codigo ASC
            ");

            $stmt->execute();

            return $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
        } catch (\Throwable $e) {
            error_log('Falha ao consolidar itens comprados: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Contagem de itens de uma SL separada por situacao de liquidacao.
     *
     * Se a migration ainda nao rodou, 'liquidados' volta 0 e 'pendentes'
     * recebe o total - assim a regra "tudo liquidado para dar OK" nunca
     * libera por engano quando o controle ainda nao existe no banco.
     *
     * @return array{total:int, liquidados:int, pendentes:int}
     */
    public static function resumoLiquidacao(int $ref): array
    {
        $vazio = ['total' => 0, 'liquidados' => 0, 'pendentes' => 0];

        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return $vazio;
            }

            if (!self::temColunasAquisicao()) {
                $stmt = $pdo->prepare("
                    SELECT COUNT(*)
                      FROM bd_device_request.solicitacao_itens_comprados
                     WHERE ref = :ref
                ");

                $stmt->execute([':ref' => $ref]);

                $total = (int) $stmt->fetchColumn();

                return [
                    'total'      => $total,
                    'liquidados' => 0,
                    'pendentes'  => $total,
                ];
            }

            $stmt = $pdo->prepare("
                SELECT
                    COUNT(*)                                   AS total,
                    SUM(CASE WHEN liquidado = 1 THEN 1 ELSE 0 END) AS liquidados
                  FROM bd_device_request.solicitacao_itens_comprados
                 WHERE ref = :ref
            ");

            $stmt->execute([':ref' => $ref]);

            $linha = $stmt->fetch(\PDO::FETCH_ASSOC) ?: [];

            $total      = (int) ($linha['total'] ?? 0);
            $liquidados = (int) ($linha['liquidados'] ?? 0);

            return [
                'total'      => $total,
                'liquidados' => $liquidados,
                'pendentes'  => max(0, $total - $liquidados),
            ];
        } catch (\Throwable $e) {
            error_log("Falha ao calcular liquidacao da SL {$ref}: " . $e->getMessage());

            return $vazio;
        }
    }

    /** A SL possui itens comprados/siderurgicos? Decide se passa por Aquisicao. */
    public static function possuiItens(int $ref): bool
    {
        return self::resumoLiquidacao($ref)['total'] > 0;
    }

    /** Todos os itens da SL estao liquidados? Pre-requisito do Aquisicao = OK. */
    public static function tudoLiquidado(int $ref): bool
    {
        $resumo = self::resumoLiquidacao($ref);

        return $resumo['total'] > 0 && $resumo['pendentes'] === 0;
    }

    /**
     * Grava o N OC de UM item — a unica coisa digitada manualmente.
     *
     * `pedido` e `liquidado` NAO sao tocados aqui: quem preenche os dois e a
     * rotina de consulta ao Logix (LogixOrdemCompraService).
     *
     * Trocar a OC zera o que o Logix ja tinha trazido, porque o pedido e a
     * liquidacao pertenciam a OC anterior.
     */
    public static function salvarOc(string $id, ?string $nOc, string $usuario): bool
    {
        if (!self::temColunasAquisicao()) {
            return false;
        }

        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return false;
            }

            $nOc  = ($nOc === null || trim($nOc) === '') ? null : trim($nOc);
            $atual = static::getByColumn('id', $id);

            if (!$atual) {
                return false;
            }

            $ocAnterior = trim((string) ($atual->n_oc ?? ''));
            $mudouOc    = $ocAnterior !== (string) $nOc;

            if (!$mudouOc) {
                return true; // nada a fazer
            }

            $stmt = $pdo->prepare("
                UPDATE bd_device_request.solicitacao_itens_comprados
                   SET n_oc            = :n_oc,
                       pedido          = NULL,
                       liquidado       = 0,
                       liquidado_em    = NULL,
                       sincronizado_em = NULL,
                       updated_by      = :updated_by,
                       updated_at      = :updated_at
                 WHERE id = :id
            ");

            $stmt->execute([
                ':n_oc'       => $nOc,
                ':updated_by' => $usuario,
                ':updated_at' => date('Y-m-d H:i:s'),
                ':id'         => $id,
            ]);

            return true;
        } catch (\Throwable $e) {
            error_log("Falha ao salvar OC do item {$id}: " . $e->getMessage());

            return false;
        }
    }

    /**
     * Itens que a rotina do Logix precisa consultar:
     * tem OC preenchida, ainda nao esta liquidado e a SL nao teve a aquisicao
     * concluida.
     *
     * @return array<int, object>
     */
    public static function pendentesDeSincronizacao(int $limite = 500): array
    {
        if (!self::temColunasAquisicao()) {
            return [];
        }

        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return [];
            }

            $stmt = $pdo->prepare("
                SELECT i.id, i.ref, i.codigo, i.n_oc
                  FROM bd_device_request.solicitacao_itens_comprados i
             LEFT JOIN bd_device_request.fila f ON f.ref = i.ref
                 WHERE i.n_oc IS NOT NULL
                   AND TRIM(i.n_oc) <> ''
                   AND i.liquidado = 0
                   AND (f.aquisicao_status IS NULL OR UPPER(TRIM(f.aquisicao_status)) <> 'OK')
              ORDER BY i.ref ASC
                 LIMIT {$limite}
            ");

            $stmt->execute();

            return $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
        } catch (\Throwable $e) {
            error_log('Falha ao listar itens pendentes de sincronizacao: ' . $e->getMessage());

            return [];
        }
    }

    /**
     * Aplica num item o que o Logix devolveu.
     * Chamado somente pela rotina — nunca pela tela.
     *
     * @return bool true se algo mudou de fato
     */
    public static function aplicarRetornoLogix(string $id, ?string $pedido, bool $liquidado): bool
    {
        if (!self::temColunasAquisicao()) {
            return false;
        }

        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return false;
            }

            $agora = date('Y-m-d H:i:s');

            // Cada placeholder aparece UMA vez: o PDO não aceita nome repetido.
            // COALESCE preserva a data da primeira liquidação em re-sincronizações.
            $stmt = $pdo->prepare("
                UPDATE bd_device_request.solicitacao_itens_comprados
                   SET pedido          = :pedido,
                       liquidado       = :liquidado,
                       liquidado_em    = CASE
                                            WHEN :liquidado_flag = 1
                                            THEN COALESCE(liquidado_em, :agora_liq)
                                            ELSE NULL
                                         END,
                       sincronizado_em = :agora_sync,
                       updated_by      = 'LOGIX',
                       updated_at      = :agora_upd
                 WHERE id = :id
            ");

            $stmt->execute([
                ':pedido'         => ($pedido === null || trim($pedido) === '') ? null : trim($pedido),
                ':liquidado'      => $liquidado ? 1 : 0,
                ':liquidado_flag' => $liquidado ? 1 : 0,
                ':agora_liq'      => $agora,
                ':agora_sync'     => $agora,
                ':agora_upd'      => $agora,
                ':id'             => $id,
            ]);

            return $stmt->rowCount() > 0;
        } catch (\Throwable $e) {
            error_log("Falha ao aplicar retorno do Logix no item {$id}: " . $e->getMessage());

            return false;
        }
    }

    /**
     * Marca a data de consulta mesmo quando o Logix nao devolveu a OC.
     * Serve para saber que a rotina passou por ali.
     */
    public static function marcarSincronizado(string $id): void
    {
        if (!self::temColunasAquisicao()) {
            return;
        }

        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return;
            }

            $stmt = $pdo->prepare("
                UPDATE bd_device_request.solicitacao_itens_comprados
                   SET sincronizado_em = :agora
                 WHERE id = :id
            ");

            $stmt->execute([
                ':agora' => date('Y-m-d H:i:s'),
                ':id'    => $id,
            ]);
        } catch (\Throwable $e) {
            error_log("Falha ao marcar sincronizacao do item {$id}: " . $e->getMessage());
        }
    }
}
