<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

/**
 * Controle por pacote DXF (2026-07-21, 5ª rodada).
 *
 * O ARQUIVO do pacote continua em solicitacao_anexo_arquivos
 * (tipo = 'PACOTE_DXF'). Esta tabela guarda só o que o Access tinha e a web
 * não: NEST, prioridade, status de corte e observações.
 *
 * A linha é criada sob demanda (getOuCriar) na primeira vez que o DX é
 * aberto — não existe carga prévia.
 */
class DxfControle extends Querio
{
    protected static string $table = 'bd_device_request.dxf_controle';
    protected static string $dbType = 'intranet';

    public const STATUS = [
        'AGUARDANDO',
        'CORTE LIBERADO',
        'CORTE EM ANDAMENTO',
        'FINALIZADO',
    ];

    public const PRIORIDADES = [
        '01-Alta',
        '02-Média',
        '03-Baixa',
    ];

    /** A tabela já foi criada? (migration 2026-07-21e) */
    public static function tabelaExiste(): bool
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return false;
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                  FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = 'bd_device_request'
                   AND TABLE_NAME   = 'dxf_controle'
            ");
            $stmt->execute();

            return ((int) $stmt->fetchColumn()) > 0;
        } catch (\Throwable $e) {
            error_log('Falha ao verificar dxf_controle: ' . $e->getMessage());
            return false;
        }
    }

    public static function getByCodigo(string $codigo): object|bool
    {
        return static::getByColumn('codigo', $codigo);
    }

    /**
     * Devolve o controle do DX, criando a linha se ainda não existir.
     * $ref e $inseridoEm só são usados na criação.
     */
    public static function getOuCriar(string $codigo, ?int $ref = null, ?string $inseridoEm = null): object|bool
    {
        $existente = self::getByCodigo($codigo);

        if ($existente) {
            return $existente;
        }

        static::create([
            'codigo'          => $codigo,
            'ref'             => $ref,
            'status_corte'    => 'AGUARDANDO',
            'prioridade'      => '02-Média',
            'dxf_inserido_em' => $inseridoEm,
        ]);

        return self::getByCodigo($codigo);
    }

    /**
     * Mapa codigo => linha de controle, para a lista não fazer N consultas.
     *
     * @return array<string, object>
     */
    public static function mapaPorCodigo(): array
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return [];
            }

            $stmt = $pdo->prepare("SELECT * FROM bd_device_request.dxf_controle");
            $stmt->execute();

            $mapa = [];

            foreach ($stmt->fetchAll(PDO::FETCH_OBJ) ?: [] as $linha) {
                $mapa[(string) $linha->codigo] = $linha;
            }

            return $mapa;
        } catch (\Throwable $e) {
            error_log('Falha ao montar mapa de dxf_controle: ' . $e->getMessage());
            return [];
        }
    }
}
