<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

class Solicitacao extends Querio
{
    protected static string $table = 'bd_device_request.solicitacoes';
    protected static string $dbType = 'intranet';

    static function getNumSL(){
        $number = static::select(['ref'])
        ->order('ref', 'DESC')
        ->finish();  

        if(!$number)
            return 1;
            
        $lastNumber = (int) $number[0]->ref;
            
        return $lastNumber + 1;

    }



    /**
     * Salva múltiplas linhas de dados repetidos em uma tabela específica.
     *
     * @param array $dadosRepeticao Array de arrays de dados a serem inseridos.
     * @param string $refSolicitacao O valor da Chave Estrangeira (ref/numSL).
     * @param string $tableName O nome completo da tabela (ex: 'bd_device_request.requisitos').
     * @return bool Retorna true se todas as inserções forem bem-sucedidas.
     */
    static function storeRepeticao(array $dadosRepeticao, string $refSolicitacao, string $tableName): bool
    {
        $sucesso = true;

        foreach ($dadosRepeticao as $dadosLinha) {

            $dadosLinha['ref'] = $refSolicitacao;

            $execute = static::create($dadosLinha, true, $tableName);

            if (!$execute) {
                $sucesso = false;
                break;
            }
        }

        return $sucesso;
    }

    static function storeFila($solicitacao, $numRef, string $tableName): bool
    {
        $solicitacao['ref'] = $numRef;

        $solicitacao['conceito_status']     = $solicitacao['conceito_status']     ?? 'PENDENTE';
        $solicitacao['detalhamento_status'] = $solicitacao['detalhamento_status'] ?? 'PENDENTE';
        $solicitacao['liberacao_status']    = $solicitacao['liberacao_status']    ?? 'PENDENTE';
        $solicitacao['corte_status']    = $solicitacao['corte_status']    ?? 'PENDENTE';
        $solicitacao['exec_status']     = $solicitacao['exec_status']     ?? 'PARADO';
        $solicitacao['aquisicao_status']     = $solicitacao['aquisicao_status']     ?? 'PARADO';
        $solicitacao['tryout_status']       = $solicitacao['tryout_status']       ?? 'PENDENTE';

        if (empty($solicitacao['descricao'])) {
            $solicitacao['descricao'] = "SEM DESCRIÇÃO";
        }
        $execute = static::create($solicitacao, true, $tableName);
        return $execute ? true : false;
    }



    /**
     * Find all records
     * @param array<int, string> $fields
     * @return array<int, object>
     */
    public static function getAllByStatusAndSolic($status, $name)
    {
        $tableName = 'bd_device_request.fila';

        $query = static::select(['*'], false, $tableName)->where('solicitante', '=', $name);
        if ($status === 'validacao' || $status === 'validação') {
            $status = '[VALIDAÇÃO]';
        }

        if (empty($status)) {
            $results = $query->andWhereRaw(" (
            conceito_status = 'pendente' OR 
            detalhamento_status = 'pendente' OR 
            liberacao_status = 'pendente' OR 
            corte_status = 'pendente' OR 
            exec_status = 'pendente' OR 
            aquisicao_status = 'pendente' OR 
            tryout_status = 'pendente'
            ) ")
            ->order('ref', 'DESC')
            ->finish() ?: [];
        } else if ($status === 'todos') {
            $results = $query->order('ref', 'DESC')->finish() ?: [];
        } else {
            $results = $query->andWhereRaw(" (
            conceito_status = '$status' OR 
            detalhamento_status = '$status' OR 
            liberacao_status = '$status' OR 
            corte_status = '$status' OR 
            exec_status = '$status' OR 
            aquisicao_status = '$status' OR 
            tryout_status = '$status'
        ) ")
            ->order('ref', 'DESC')
            ->finish() ?: [];
        }

        return array_map(function ($item) {
            $statusFields = [
                'conceito_status', 'detalhamento_status', 'liberacao_status',
                'corte_status', 'exec_status', 'aquisicao_status', 'tryout_status'
            ];

            foreach ($statusFields as $field) {
                $currentValue = is_object($item) ? ($item->$field ?? null) : ($item[$field] ?? null);

                if ($currentValue !== null) {
                    if (strtolower($currentValue) === 'pausado') {
                        $newValue = 'PSD';
                    } else if (strtolower($currentValue) === 'backlog') {
                        $newValue = 'BAK';
                    } else if (strtolower($currentValue) === 'em andamento') {
                        $newValue = 'AND';
                    } else {
                        $newValue = mb_strtoupper(mb_substr($currentValue, 0, 3));
                        if ($newValue == '[VA') {
                            $newValue = 'VAL';
                        }
                    }

                    if (is_object($item)) {
                        $item->$field = $newValue;
                    } else {
                        $item[$field] = $newValue;
                    }
                }
            }
            return $item;
        }, $results);
    }


    }