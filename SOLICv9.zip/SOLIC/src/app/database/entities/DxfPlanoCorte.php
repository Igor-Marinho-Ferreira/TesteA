<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

/**
 * Linhas da grade "Dados dos Planos de Corte" (2026-07-21, 5ª rodada).
 * Uma linha por programa de corte dentro de um pacote DXF.
 */
class DxfPlanoCorte extends Querio
{
    protected static string $table = 'bd_device_request.dxf_planos_corte';
    protected static string $dbType = 'intranet';

    /**
     * Planos de um DX, na ordem da grade.
     *
     * @return array<int, object>
     */
    public static function getPorDxf(string $codigo): array
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return [];
            }

            $stmt = $pdo->prepare("
                SELECT *
                  FROM bd_device_request.dxf_planos_corte
                 WHERE dxf_codigo = :codigo
              ORDER BY ordem ASC, created_at ASC
            ");

            $stmt->execute([':codigo' => $codigo]);

            return $stmt->fetchAll(PDO::FETCH_OBJ) ?: [];
        } catch (\Throwable $e) {
            error_log("Falha ao listar planos de corte de {$codigo}: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Resumo para a lista e para o cabeçalho: total de planos e quantos já
     * foram cortados.
     *
     * @return array{total:int, cortados:int, pendentes:int}
     */
    public static function resumo(string $codigo): array
    {
        $vazio = ['total' => 0, 'cortados' => 0, 'pendentes' => 0];

        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return $vazio;
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*) AS total,
                       SUM(CASE WHEN cortado = 1 THEN 1 ELSE 0 END) AS cortados
                  FROM bd_device_request.dxf_planos_corte
                 WHERE dxf_codigo = :codigo
            ");

            $stmt->execute([':codigo' => $codigo]);

            $linha = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

            $total    = (int) ($linha['total'] ?? 0);
            $cortados = (int) ($linha['cortados'] ?? 0);

            return [
                'total'     => $total,
                'cortados'  => $cortados,
                'pendentes' => max(0, $total - $cortados),
            ];
        } catch (\Throwable $e) {
            error_log("Falha no resumo de planos de {$codigo}: " . $e->getMessage());
            return $vazio;
        }
    }

    /** Próxima posição na grade. */
    public static function proximaOrdem(string $codigo): int
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return 0;
            }

            $stmt = $pdo->prepare("
                SELECT COALESCE(MAX(ordem), 0) + 1
                  FROM bd_device_request.dxf_planos_corte
                 WHERE dxf_codigo = :codigo
            ");

            $stmt->execute([':codigo' => $codigo]);

            return (int) $stmt->fetchColumn();
        } catch (\Throwable $e) {
            return 0;
        }
    }
}
