<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;
use src\exceptions\pdo\DuplicateEntryException;
use src\exceptions\pdo\Exception;


class Vagao extends Querio
{
    protected static string $table = 'bd_device_request.lote_vagoes';
    protected static string $dbType = 'intranet';


  /**
 * Verifica se o Vagão ou o Lote já possuem uma associação ativa.
 * @param string $wagonId
 * @param string $lotId
 * @return bool
 */
static function isAlreadyAssociated($data, $currentId = null)
{
    $query = static::select(['id']) 
        ->where('vagao', '=', $data['vagao']) 
        ->andWhere('lote', '=', $data['lote']); 

        if ($currentId !== null) {
        $query->andWhere('id', '!=', $currentId);
    }
    $result = $query->finish();

    if($result) { 
        throw new DuplicateEntryException(
            ["O registro já existe para o Vagão: {$data['vagao']} e Lote: {$data['lote']}."], 
            409
        );
    }
    return true;
}



public static function getDistinctWagons() {

    $vagoes = static::select(['distinct vagao']) 
    ->where('status','=', 'ATIVO')->finish();

    return $vagoes;
}


public static function getLoteByVagao(string $vagao) {
    $lotes = static::select(['lote'])->where('vagao', '=', $vagao)->andWhere('status', '=', 'ATIVO')->finish();
    
    return $lotes;
}

}