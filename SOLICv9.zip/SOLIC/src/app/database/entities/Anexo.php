<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

class Anexo extends Querio
{
    protected static string $table = 'bd_device_request.anexos';
    protected static string $dbType = 'intranet';


    static function getAnexosTratados($ref)
    {
        $anexos = static::getAllByRef($ref);

        $serverLink = 'http://172.29.5.2/';

        if (empty($anexos)) {
            return [];
        }

        foreach ($anexos as $item) {
            if (!empty($item->anexo)) {
                $item->anexo = str_replace('/var/www/htdocs/', $serverLink, $item->anexo);
            }
        }

        return $anexos;
    }

}
