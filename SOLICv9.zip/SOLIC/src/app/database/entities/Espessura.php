<?php

namespace src\app\database\entities;

use src\app\database\Querio;

/**
 * Espessuras parametrizadas dos planos de corte (2026-07-21, 5ª rodada).
 * Guardadas como texto porque nem toda espessura é numérica ("4,75 Xd").
 *
 * 6ª rodada: ganham densidade e peso da chapa padrão, para o consolidado
 * calcular o peso teórico e a quantidade de chapas a comprar.
 */
class Espessura extends Querio
{
    protected static string $table = 'bd_device_request.espessuras';
    protected static string $dbType = 'intranet';

    public const DENSIDADE_PADRAO = 7860.0;

    /** @return array<int, object> */
    public static function listar(): array
    {
        return static::select(['*'])->order('valor', 'ASC')->finish() ?: [];
    }

    /** As colunas densidade/peso_chapa_padrao já existem? (migration 2026-07-21f) */
    public static function temColunasPeso(): bool
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return false;
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                  FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = 'bd_device_request'
                   AND TABLE_NAME   = 'espessuras'
                   AND COLUMN_NAME IN ('densidade', 'peso_chapa_padrao')
            ");
            $stmt->execute();

            return ((int) $stmt->fetchColumn()) === 2;
        } catch (\Throwable $e) {
            error_log('Falha ao verificar colunas de peso das espessuras: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Mapa normalizado (valor numérico em mm => {densidade, peso_chapa_padrao})
     * para o consolidado casar a espessura do plano com a parametrização.
     *
     * @return array<string, object>
     */
    public static function mapaPorValorNumerico(): array
    {
        $mapa = [];

        foreach (self::listar() as $esp) {
            $chave = self::normalizarEspessura($esp->valor);

            if ($chave !== null) {
                $mapa[$chave] = $esp;
            }
        }

        return $mapa;
    }

    /**
     * Converte a espessura texto para número em mm.
     * "4,75" -> "4.75" ; "4,75 Xd" -> "4.75" ; "6.35" -> "6.35".
     * Devolve null se não houver número.
     */
    public static function normalizarEspessura($valor): ?string
    {
        $texto = str_replace(',', '.', trim((string) $valor));

        if (preg_match('/([0-9]+(?:\.[0-9]+)?)/', $texto, $m)) {
            // (float) para uniformizar "4.750" e "4.75"
            return (string) (float) $m[1];
        }

        return null;
    }
}
