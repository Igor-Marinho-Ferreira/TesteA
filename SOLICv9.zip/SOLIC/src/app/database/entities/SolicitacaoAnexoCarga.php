<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class SolicitacaoAnexoCarga extends Querio
{
    protected static string $table = 'bd_device_request.solicitacao_anexo_cargas';
    protected static string $dbType = 'intranet';
}