<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

class Estagio extends Querio
{
    protected static string $table = 'bd_device_request.estagios';
    protected static string $dbType = 'intranet';

    
}
