<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

class Requisito extends Querio
{
    protected static string $table = 'bd_device_request.requisitos';
    protected static string $dbType = 'intranet';
}
