<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

class Projeto extends Querio
{
  protected static string $table = 'bd_device_request.controle_z';
  protected static string $dbType = 'intranet';

  static function getProjectInfos($projectNumber)
  {
    $query = static::select(['descricao'], false)
      ->where('cod_z', '=', $projectNumber);
    $result = $query->finish();
    if (!is_array($result)) {
      return [];
    }



    return array_column($result, 'descricao');
  }

  static function getProjectStatus($projectNumber)
  {
    $sql = "SELECT 
  z.cod_z,
  f.ref, 
  z.descricao, 
  f.aplicacao, 
  f.vagao, 
   z.qtdRev,
  z.solicitante, 
  f.conceito_status, 
  f.detalhamento_status, 
  f.liberacao_status 
FROM 
  bd_device_request.controle_z z 
  INNER JOIN bd_device_request.fila f ON (z.cod_z = f.cod_z OR f.cod_z LIKE CONCAT('%', z.cod_z))
WHERE 
  (
    f.conceito_status IN ('PENDENTE', 'BACKLOG', 'MODELO')
    OR f.detalhamento_status = 'PENDENTE' 
    OR f.liberacao_status = 'PENDENTE'
  ) 
  AND (z.cod_z = :cod_z OR z.cod_z = CONCAT('Z', :cod_z))";


    static::$queryString = $sql;
    static::$bind = ['cod_z' => $projectNumber];
    static::$selectIsOne = false;

    $result = static::finish();


    if (!is_array($result)) {
      return [];
    }

    return $result;
  }
  static function getLastZ()
  {
    $result = static::select(['MAX(CAST(cod_z AS UNSIGNED)) AS ultimo_z'], false)->finish();

    return $result[0]->ultimo_z;
  }


  public static function getInfoProjetos2CSV()
  {
    $query = "SELECT 
  p.cod_z, 
  p.solicitante, 
  f_recente.data_solicitacao, 
  p.descricao, 
  p.vagao, 
  p.lote 
FROM 
   bd_device_request.controle_z p 
  LEFT JOIN (
    SELECT 
      * 
    FROM 
      bd_device_request.fila 
    WHERE 
      id IN (
        SELECT 
          MAX(id) 
        FROM 
           bd_device_request.fila 
        GROUP BY 
          vagao
      )
  ) f_recente ON p.vagao = f_recente.vagao
";



    static::$queryString = $query;
    static::$selectIsOne = false;

    $result = static::finish();


    if (!is_array($result)) {
      return [];
    }
    return $result;
  }
}
