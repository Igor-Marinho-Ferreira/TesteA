<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class SolicitacaoAnexoArquivo extends Querio
{
    protected static string $table = 'bd_device_request.solicitacao_anexo_arquivos';
    protected static string $dbType = 'intranet';
}