<?php

namespace src\app\database\entities;

use src\app\database\Querio;

/**
 * Perfis lineares para o cálculo de peso (2026-07-21, 6ª rodada).
 * Cada perfil guarda o peso por metro (kg/m); a calculadora faz
 * peso = peso_por_metro × comprimento(m) × quantidade.
 */
class Perfil extends Querio
{
    protected static string $table = 'bd_device_request.perfis';
    protected static string $dbType = 'intranet';

    /** Tipos = abas da planilha original. valor => rótulo. */
    public const TIPOS = [
        'TUBO_RET'    => 'Tubo Retangular',
        'VIGA_W'      => 'Viga W',
        'PERFIL_U'    => 'Perfil U',
        'BARRA'       => 'Barra',
        'FUSO'        => 'Fuso',
        'TUBO'        => 'Tubo',
        'CANTONEIRA'  => 'Cantoneira',
        'BR_CHATA'    => 'Barra Chata',
        'BR_QUADRADA' => 'Barra Quadrada',
    ];

    public static function tabelaExiste(): bool
    {
        try {
            $pdo = static::getPDO();

            if (!$pdo) {
                return false;
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                  FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = 'bd_device_request'
                   AND TABLE_NAME   = 'perfis'
            ");
            $stmt->execute();

            return ((int) $stmt->fetchColumn()) > 0;
        } catch (\Throwable $e) {
            error_log('Falha ao verificar tabela perfis: ' . $e->getMessage());
            return false;
        }
    }

    /** @return array<int, object> */
    public static function listar(): array
    {
        return static::select(['*'])->order('tipo', 'ASC')->finish() ?: [];
    }
}
