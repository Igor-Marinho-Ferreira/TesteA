<?php

namespace src\app\database\entities;

use src\app\database\Querio;

class Conta extends Querio
{
    protected static string $table = 'bd_device_request.contas';
    protected static string $dbType = 'intranet';

    public static function getContasByRole($role): array
    {
        $contaDespesa = ['3231020503'];

        /**
         * Garante que $role sempre seja array.
         * Evita erro quando vier false, null ou string.
         */
        if (empty($role)) {
            return $contaDespesa;
        }

        if (!is_array($role)) {
            $role = [$role];
        }

        /**
         * Normaliza os nomes dos perfis.
         */
        $roles = array_map(function ($item) {
            if (is_array($item)) {
                return strtoupper(trim($item[0] ?? $item['descricao'] ?? $item['role'] ?? $item['nome'] ?? ''));
            }

            return strtoupper(trim((string) $item));
        }, $role);

        /**
         * Se não for administrador/líder, retorna somente conta de despesa.
         */
        if (
            !in_array('ADMINISTRADOR', $roles, true) &&
            !in_array('LIDER DE PROJETO', $roles, true)
        ) {
            return $contaDespesa;
        }

        /**
         * Busca todas as contas.
         */
        $contas = static::select(['sfp_conta_contabil'], false)->finish();

        /**
         * Se a query retornar false, null ou vazio, evita quebrar no array_column.
         */
        if (empty($contas) || !is_array($contas)) {
            return [];
        }

        $result = array_column($contas, 'sfp_conta_contabil');

        return array_values(array_filter($result));
    }

    public static function getDescricaoConta($conta): array
    {
        if (empty($conta)) {
            return [];
        }

        $descricao = static::select(['descricao'], false)
            ->where('sfp_conta_contabil', '=', $conta)
            ->finish();

        if (empty($descricao) || !is_array($descricao)) {
            return [];
        }

        $result = array_column($descricao, 'descricao');

        return array_values(array_filter($result));
    }
}