<?php

namespace src\app\database\entities;

use PDO;
use src\app\database\Querio;

class Historico extends Querio
{
    protected static string $table = 'bd_device_request.historico';
    protected static string $dbType = 'intranet';
}
