<?php

namespace src\app\database;

use Exception;
use PDO;
use PDOException;


class Database
{
    protected static ?PDO $pdo = null;
    protected static ?string $typeConnection = null;
    protected static ?string $host = null;
    protected static ?string $dbname = null;
    protected static ?string $username = null;
    protected static ?string $password = null;
    protected static ?string $service = null;
    protected static ?string $server = null;
    protected static ?string $dbFilePath = null;

    static function config(string $type, string $host, string $dbname, string $username, string $password, ?string $service = null, ?string $server = null, ?string $dbFilePath = null)
    {
        self::$typeConnection = $type;
        self::$host = $host;
        self::$dbname = $dbname;
        self::$username = $username;
        self::$password = $password;
        self::$service = $service;
        self::$server = $server;
        self::$dbFilePath = $dbFilePath;
        
    }

    static function get(string|null $dbType = null)
    {
        self::setConfig($dbType);
        return self::connect();
    }

static function setConfig(string|null $dbType)
{
    $file = null;
    $isDefault = false;
    if ($dbType === "intranet")
        $file = "DB_FILE_INTRANET";
    else if ($dbType === "workflow")
        $file = "DB_FILE_WORKFLOW";
    else if ($dbType === "access_control")
        $file = "DB_FILE_INTRANET_ACCESS_CONTROL";
     else if ($dbType === "senior")
        $file = "DB_FILE_SENIOR_GBMX";
    else if ($dbType === "logix")
        // 2026-07-21 — Logix roda sobre Informix. O arquivo já existia no .env
        // (DB_FILE_INFORMIX) mas não tinha mapeamento aqui.
        $file = "DB_FILE_INFORMIX";
    else if ($dbType === "casa")
        $isDefault = true;



        if ($isDefault) {
            $config = $_ENV;
        } else {
                $config = require $_ENV[$file];
        }
        
            self::config(
            type: $config["typeConnection"],
            host: $config["host"],
            username: $config["username"],
            password: $config["password"],
            dbname: $config["dbname"],
            server: $config["DB_SERVER"] ?? null,
            service: $config["DB_PORT"] ?? null,
            dbFilePath: $config["DB_FILEPATH"] ?? null 
        );

    return new self;
}

    static function instance(): PDO
    {
        return self::get();
    }

    /**
     * Method performs the database connection
     * @return PDO
     */
    protected static function connect(): PDO
    {
        try {
            self::$pdo = new PDO(self::dns(), self::$username, self::$password);
            return self::$pdo;
        } catch (PDOException $e) {
            dd([
                "erro" => "Erro ao conectar com o banco de dados",
                "banco" => [
                    "tipo"    => self::$typeConnection ?? null,
                    "host"    => self::$host ?? null,
                    "dbname"  => self::$dbname ?? null,
                    "usuario" => self::$username ?? null,
                    "dsn"     => self::dns(),
                ],
                "mensagem" => $e->getMessage(),
            ]);
        }
    }

    /**
     * Obtains the type of DNS according to the informed connection
     * 
     * @return string
     */
    protected static function dns(): string
    {
        switch (self::$typeConnection) {
            case 'mysql':
                return "mysql:host=" . self::$host . ";dbname=" . self::$dbname . ";charset=utf8mb4";
            case 'sqlsrv':
                return "sqlsrv:Server=" . self::$host . ";Database=" . self::$dbname . "";
            case 'informix':
                return "informix:host=" . self::$host . "; service=" . self::$service . "; database=" . self::$dbname . "; server=" . self::$server . "; protocol=olsoctcp";
            default:
                throw new Exception("Tipo de conexão inválido: " . self::$typeConnection . "");
        }
    }
}
