<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.menu"),
    "webTitle"  => "Dispositivos - Reservas / Cálculo de Peso",
    "cardTitle" => "RESERVAS - CÁLCULO DE PESO POR ESPESSURA",
    "styles"    => [
        path()->css("cortes.css")
    ],
    "js" => [
        path()->js("calculoPeso.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

// Números no padrão pt-BR
$n = function ($valor, $dec = 2) {
    return number_format((float) $valor, $dec, ',', '.');
};

$grupos     = $grupos ?? [];
$totalGeral = $totalGeral ?? ['area' => 0.0, 'peso' => 0.0, 'linhas' => 0];
$espessuras = $espessuras ?? [];
$pronta     = !empty($tabelaPronta);
$temPeso    = !empty($temColunaPeso);

// Densidades cadastradas por espessura, para a calculadora (JS)
$densMap = [];
foreach ($espessuras as $e) {
    $densMap[(string) $e->valor] = (float) ($e->densidade ?? 7860);
}
?>

<?php if (!$pronta) : ?>
    <div class="alert alert-warning fs-7" role="alert">
        <i class="bi bi-database-exclamation me-1"></i>
        Não há planos de corte para consolidar. Cadastre-os no
        <a href="<?= route('dispositivos.cortes.lista') ?>">Controle de Cortes</a>
        (é preciso ter rodado as migrations 2026-07-21e e 2026-07-21f).
    </div>
<?php endif; ?>

<?php if (!$temPeso) : ?>
    <div class="alert alert-info fs-8" role="alert">
        <i class="bi bi-info-circle me-1"></i>
        Densidade e peso da chapa padrão ainda não parametrizados: usando densidade
        padrão do aço (7860 kg/m³) e sem cálculo de chapas a comprar. Rode a migration
        <code>2026-07-21f-calculo-peso.sql</code> e preencha em Parametrização &rsaquo; Espessuras.
    </div>
<?php endif; ?>

<?php /* ---------------------- FERRAMENTAS / RESUMO ---------------------- */ ?>
<div class="row g-2 mb-3">
    <div class="col-md-3">
        <div class="box-corte text-center py-2">
            <div class="rotulo-corte">Total de linhas</div>
            <div class="fs-4 fw-bold"><?= (int) $totalGeral['linhas'] ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="box-corte text-center py-2">
            <div class="rotulo-corte">Área total (m²)</div>
            <div class="fs-4 fw-bold"><?= $h($n($totalGeral['area'], 4)) ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="box-corte text-center py-2">
            <div class="rotulo-corte">Peso total (kg)</div>
            <div class="fs-4 fw-bold text-danger"><?= $h($n($totalGeral['peso'], 2)) ?></div>
        </div>
    </div>
    <div class="col-md-3 d-grid gap-2">
        <button type="button" class="btn btn-outline-primary btn-sm" id="btnCalculadora">
            <i class="bi bi-calculator me-1"></i> Calculadora de peso
        </button>
        <a href="<?= route('dispositivos.cortes.perfis') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-rulers me-1"></i> Peso de perfis
        </a>
    </div>
</div>

<?php /* -------------------- CALCULADORA (peso teórico) -------------------- */ ?>
<div class="box-corte mb-3 d-none" id="painelCalculadora" data-dens='<?= $h(json_encode($densMap, JSON_UNESCAPED_UNICODE)) ?>'>
    <div class="d-flex justify-content-between align-items-center mb-2">
        <strong class="fs-7">Cálculo do Peso Teórico (chapa)</strong>
        <button type="button" class="btn-close" id="fecharCalculadora" aria-label="Fechar"></button>
    </div>

    <div class="row g-2 align-items-end">
        <div class="col-6 col-md-2">
            <label class="rotulo-corte d-block">Largura (mm)</label>
            <input type="number" class="form-control form-control-sm" id="calcLarg" value="1100" min="0">
        </div>
        <div class="col-6 col-md-2">
            <label class="rotulo-corte d-block">Comprimento (mm)</label>
            <input type="number" class="form-control form-control-sm" id="calcComp" value="3000" min="0">
        </div>
        <div class="col-6 col-md-2">
            <label class="rotulo-corte d-block">Espessura (mm)</label>
            <input type="text" class="form-control form-control-sm" id="calcEsp" value="4,75">
        </div>
        <div class="col-6 col-md-2">
            <label class="rotulo-corte d-block">Qtde</label>
            <input type="number" class="form-control form-control-sm" id="calcQtde" value="1" min="1">
        </div>
        <div class="col-6 col-md-2">
            <label class="rotulo-corte d-block">Densidade (kg/m³)</label>
            <input type="number" class="form-control form-control-sm" id="calcDens" value="7860" min="0">
        </div>
        <div class="col-6 col-md-2">
            <button type="button" class="btn btn-primary btn-sm w-100" id="btnCalcular">Calcular</button>
        </div>
    </div>

    <div class="row g-2 mt-2 fs-8">
        <div class="col-md-3">Volume (m³): <strong id="calcVol">—</strong></div>
        <div class="col-md-3">Área (m²): <strong id="calcArea">—</strong></div>
        <div class="col-md-3">Peso unitário (kg): <strong id="calcPesoUnit">—</strong></div>
        <div class="col-md-3">Peso total (kg): <strong class="text-danger" id="calcPesoTotal">—</strong></div>
    </div>
</div>

<?php /* ----------------------- CONSOLIDADO ----------------------- */ ?>
<?php foreach ($grupos as $grupo) : ?>
    <div class="grupo-espessura mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center py-2 px-2 cabecalho-espessura">
            <span class="fw-bold">Espessura <?= $h($grupo->rotulo) ?></span>
            <span class="fs-8">
                Área: <strong><?= $h($n($grupo->area, 4)) ?> m²</strong> &nbsp;|&nbsp;
                Peso: <strong class="text-danger"><?= $h($n($grupo->peso, 2)) ?> kg</strong>
                <?php if ($grupo->chapas !== null) : ?>
                    &nbsp;|&nbsp; Chapas a comprar:
                    <strong class="text-primary"><?= (int) $grupo->chapas ?></strong>
                    <span class="text-muted">(chapa padrão <?= $h($n($grupo->peso_chapa_padrao, 0)) ?> kg)</span>
                <?php endif; ?>
            </span>
        </div>

        <div class="table-responsive">
            <table class="table table-sm tabela-planos align-middle mb-0">
                <thead>
                    <tr>
                        <th>Ctrl (DX)</th>
                        <th>Cod Z</th>
                        <th>Descrição</th>
                        <th>Vagão/Local</th>
                        <th>Projetista</th>
                        <th>Programa</th>
                        <th>Esp</th>
                        <th class="text-end">Larg</th>
                        <th class="text-end">Comp</th>
                        <th class="text-end">Qtde</th>
                        <th class="text-end">Área (m²)</th>
                        <th class="text-end">Peso (kg)</th>
                        <th>Reserva</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($grupo->linhas as $l) : ?>
                        <tr>
                            <td>
                                <a href="<?= route('dispositivos.cortes.detalhe', ['codigo' => $l->dxf_codigo]) ?>">
                                    <?= $h($l->dxf_codigo) ?>
                                </a>
                            </td>
                            <td><?= $h($l->cod_z_formatado) ?></td>
                            <td class="text-start"><?= $h($l->descricao) ?></td>
                            <td><?= $h($l->vagao) ?><?= $l->aplicacao ? ' / ' . $h($l->aplicacao) : '' ?></td>
                            <td><?= $h($l->projetista) ?></td>
                            <td><?= $h($l->n_prog) ?></td>
                            <td><?= $h($l->espessura) ?></td>
                            <td class="text-end"><?= $h($n($l->largura, 0)) ?></td>
                            <td class="text-end"><?= $h($n($l->comprimento, 0)) ?></td>
                            <td class="text-end"><?= (int) $l->qtde ?></td>
                            <td class="text-end"><?= $h($n($l->area, 4)) ?></td>
                            <td class="text-end"><?= $h($n($l->peso, 2)) ?></td>
                            <td><?= $h($l->reserva) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr class="linha-total">
                        <td colspan="10" class="text-end fw-bold">Subtotal da espessura:</td>
                        <td class="text-end fw-bold"><?= $h($n($grupo->area, 4)) ?></td>
                        <td class="text-end fw-bold text-danger"><?= $h($n($grupo->peso, 2)) ?></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php endforeach; ?>

<?php if ($pronta && empty($grupos)) : ?>
    <p class="text-muted py-4">Nenhum plano de corte cadastrado ainda.</p>
<?php endif; ?>
