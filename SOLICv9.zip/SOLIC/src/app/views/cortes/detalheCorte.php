<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.cortes.lista"),
    "webTitle"  => "Dispositivos - Dados do Projeto",
    "cardTitle" => "DADOS DO PROJETO - CONTROLE DE CORTE",
    "styles"    => [
        path()->css("cortes.css")
    ],
    "js" => [
        path()->js("detalheCorte.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$formatarData = function ($data) {
    if (empty($data) || $data === '0000-00-00' || $data === '0000-00-00 00:00:00') {
        return '--';
    }
    try {
        return (new DateTime($data))->format('d/m/Y');
    } catch (Throwable $e) {
        return '--';
    }
};

// TIME do MySQL vem "00:25:00"; deixa vazio quando nulo
$formatarTempo = function ($tempo) {
    $tempo = trim((string) $tempo);
    return $tempo !== '' && $tempo !== '00:00:00' ? $tempo : '';
};

$controle   = $controle ?? null;
$planos     = $planos ?? [];
$espessuras = $espessuras ?? [];
$resumo     = $resumo ?? ['total' => 0, 'cortados' => 0, 'pendentes' => 0];
$pronta     = !empty($tabelaPronta);

$statusAtual     = strtoupper(trim((string) ($controle->status_corte ?? 'AGUARDANDO')));
$prioridadeAtual = trim((string) ($controle->prioridade ?? ''));
?>

<?php if (!$pronta) : ?>
    <div class="alert alert-warning fs-7" role="alert">
        <i class="bi bi-database-exclamation me-1"></i>
        Controle ainda não inicializado: rode a migration
        <code>database/migrations/2026-07-21e-controle-cortes.sql</code>.
        Os dados do projeto aparecem, mas não é possível gravar planos de corte.
    </div>
<?php endif; ?>

<div class="row g-3">
    <?php /* ----------------------- PROJETO (cabeçalho) ----------------------- */ ?>
    <div class="col-lg-8">
        <fieldset class="box-corte h-100">
            <legend>Projeto</legend>

            <div class="row g-3">
                <div class="col-md-5">
                    <h2 class="dx-titulo mb-2"><?= $h($codigo) ?></h2>

                    <div class="mb-1">
                        <span class="rotulo-corte">Codigo Z:</span>
                        <span class="valor-z"><?= $h($pacote->cod_z ?: '--') ?></span>
                    </div>

                    <div class="row">
                        <div class="col-6 mb-1">
                            <span class="rotulo-corte d-block">Solicitação:</span>
                            <a href="<?= route('dispositivos.desenvolvimento.info', ['ref' => $pacote->ref]) ?>"
                               class="valor-azul text-decoration-none">
                                SL<?= $h(str_pad((string) $pacote->ref, 4, '0', STR_PAD_LEFT)) ?>
                            </a>
                        </div>

                        <div class="col-6 mb-1">
                            <span class="rotulo-corte d-block">Projeto:</span>
                            <span class="valor-azul"><?= $h($projeto ?: '--') ?></span>
                        </div>
                    </div>

                    <div class="mb-1">
                        <span class="rotulo-corte d-block">Projetista:</span>
                        <span class="valor-azul text-uppercase"><?= $h($projetista ?: '--') ?></span>
                    </div>

                    <div class="mt-2">
                        <span class="rotulo-corte d-block">Descrição:</span>
                        <span class="valor-azul"><?= $h($controle->descricao ?? $pacote->descricao_sl ?? '--') ?></span>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="box-preview-corte">
                        <?php if (!empty($pacote->imagem_id)) : ?>
                            <img src="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $pacote->imagem_id]) ?>"
                                 alt="Imagem do projeto">
                        <?php else : ?>
                            <span class="text-muted fs-8">Sem imagem</span>
                        <?php endif; ?>
                    </div>

                    <div class="text-center mt-2 fs-8 text-muted">
                        DXF inserido em: <strong class="text-danger"><?= $h($formatarData($pacote->inserido_em ?? null)) ?></strong>
                    </div>

                    <div class="d-flex gap-2 mt-2">
                        <?php if (!empty($pacote->imagem_id)) : ?>
                            <a href="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $pacote->imagem_id]) ?>"
                               target="_blank" class="btn btn-sm btn-outline-secondary flex-fill">Imagem</a>
                        <?php else : ?>
                            <button type="button" class="btn btn-sm btn-outline-secondary flex-fill" disabled>Imagem</button>
                        <?php endif; ?>

                        <a href="<?= route('dispositivos.desenvolvimento.arquivo.download', ['id' => $pacote->arquivo_id]) ?>"
                           class="btn btn-sm btn-outline-secondary flex-fill">Arquivos DXF (ZIP)</a>
                    </div>
                </div>

                <div class="col-md-3">
                    <label for="nest" class="rotulo-corte d-block mb-1">NEST</label>
                    <input type="text" class="form-control form-control-sm" id="nest"
                           value="<?= $h($controle->nest ?? '') ?>" maxlength="60"
                           <?= $pronta ? '' : 'disabled' ?>>

                    <label for="prioridade" class="rotulo-corte d-block mb-1 mt-3">Prioridade</label>
                    <select class="form-select form-select-sm" id="prioridade" <?= $pronta ? '' : 'disabled' ?>>
                        <option value="">--</option>
                        <?php foreach ($prioridades as $p) : ?>
                            <option value="<?= $h($p) ?>" <?= $prioridadeAtual === $p ? 'selected' : '' ?>>
                                <?= $h($p) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </fieldset>
    </div>

    <?php /* -------------------- STATUS DOS PROJETOS/EXECUÇÃO -------------------- */ ?>
    <div class="col-lg-4">
        <fieldset class="box-corte h-100">
            <legend>Status dos Projetos/Execução</legend>

            <div id="grupoStatusCorte" data-codigo="<?= $h($codigo) ?>">
                <?php foreach ($statusOpcoes as $st) : ?>
                    <div class="form-check status-radio">
                        <input class="form-check-input" type="radio" name="status_corte"
                               id="st_<?= $h(str_replace(' ', '_', $st)) ?>" value="<?= $h($st) ?>"
                               <?= $statusAtual === $st ? 'checked' : '' ?>
                               <?= $pronta ? '' : 'disabled' ?>>
                        <label class="form-check-label <?= 'radio-' . strtolower(str_replace(' ', '-', $st)) ?>"
                               for="st_<?= $h(str_replace(' ', '_', $st)) ?>">
                            <?= $h($st) ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>

            <hr>

            <div class="fs-8 text-muted">
                Planos de corte:
                <strong id="resumoCortados"><?= (int) $resumo['cortados'] ?></strong>
                de
                <strong id="resumoTotal"><?= (int) $resumo['total'] ?></strong>
                com corte OK
            </div>
        </fieldset>
    </div>
</div>

<?php /* --------------------- DADOS DOS PLANOS DE CORTE --------------------- */ ?>
<fieldset class="box-corte mt-3">
    <legend>Dados dos Planos de Corte</legend>

    <div class="table-responsive">
        <table class="table table-sm tabela-planos align-middle mb-0" id="tabelaPlanos" data-codigo="<?= $h($codigo) ?>">
            <thead>
                <tr>
                    <th style="width:38px"></th>
                    <th>Nº Prog</th>
                    <th style="width:120px">Esp.</th>
                    <th style="width:100px">Larg.</th>
                    <th style="width:100px">Comp.</th>
                    <th style="width:80px">Qtde.</th>
                    <th style="width:110px">Tempo</th>
                    <th style="width:120px">Reserva</th>
                    <th style="width:90px">Corte?</th>
                    <th style="width:90px"></th>
                </tr>
            </thead>

            <tbody id="corpoPlanos">
                <?php foreach ($planos as $plano) : ?>
                    <tr data-id="<?= $h($plano->id) ?>" class="<?= !empty($plano->cortado) ? 'linha-cortada' : '' ?>">
                        <td>
                            <button type="button" class="btn btn-sm btn-outline-danger btn-remover-plano"
                                    title="Remover linha" <?= $pronta ? '' : 'disabled' ?>>x</button>
                        </td>

                        <td>
                            <input type="text" class="form-control form-control-sm" data-campo="n_prog"
                                   value="<?= $h($plano->n_prog) ?>" maxlength="60" <?= $pronta ? '' : 'disabled' ?>>
                        </td>

                        <td>
                            <select class="form-select form-select-sm" data-campo="espessura" <?= $pronta ? '' : 'disabled' ?>>
                                <option value="">--</option>
                                <?php
                                $espAtual = trim((string) $plano->espessura);
                                $achou = false;
                                foreach ($espessuras as $esp) :
                                    $selecionado = ($espAtual === trim((string) $esp->valor));
                                    $achou = $achou || $selecionado;
                                ?>
                                    <option value="<?= $h($esp->valor) ?>" <?= $selecionado ? 'selected' : '' ?>>
                                        <?= $h($esp->valor) ?>
                                    </option>
                                <?php endforeach; ?>

                                <?php /* Espessura antiga que saiu da parametrização não some da linha */ ?>
                                <?php if (!$achou && $espAtual !== '') : ?>
                                    <option value="<?= $h($espAtual) ?>" selected><?= $h($espAtual) ?></option>
                                <?php endif; ?>
                            </select>
                        </td>

                        <td>
                            <input type="number" class="form-control form-control-sm" data-campo="largura"
                                   value="<?= $h($plano->largura) ?>" min="0" <?= $pronta ? '' : 'disabled' ?>>
                        </td>

                        <td>
                            <input type="number" class="form-control form-control-sm" data-campo="comprimento"
                                   value="<?= $h($plano->comprimento) ?>" min="0" <?= $pronta ? '' : 'disabled' ?>>
                        </td>

                        <td>
                            <input type="number" class="form-control form-control-sm" data-campo="qtde"
                                   value="<?= $h($plano->qtde) ?>" min="0" <?= $pronta ? '' : 'disabled' ?>>
                        </td>

                        <td>
                            <input type="text" class="form-control form-control-sm text-center" data-campo="tempo"
                                   value="<?= $h($formatarTempo($plano->tempo)) ?>" placeholder="00:00:00"
                                   <?= $pronta ? '' : 'disabled' ?>>
                        </td>

                        <td>
                            <input type="text" class="form-control form-control-sm" data-campo="reserva"
                                   value="<?= $h($plano->reserva) ?>" maxlength="60" <?= $pronta ? '' : 'disabled' ?>>
                        </td>

                        <td class="text-center">
                            <div class="form-check d-inline-block">
                                <input class="form-check-input" type="checkbox" data-campo="cortado"
                                       <?= !empty($plano->cortado) ? 'checked' : '' ?> <?= $pronta ? '' : 'disabled' ?>>
                                <label class="form-check-label fs-8">OK</label>
                            </div>
                        </td>

                        <td>
                            <button type="button" class="btn btn-sm btn-salvar-plano" <?= $pronta ? '' : 'disabled' ?>>
                                Salvar
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <?php /* Linha em branco no fim da grade, como no formulário do Access */ ?>
                <?php if ($pronta) : ?>
                    <tr data-id="">
                        <td>
                            <button type="button" class="btn btn-sm btn-outline-danger btn-remover-plano" title="Remover linha">x</button>
                        </td>
                        <td>
                            <input type="text" class="form-control form-control-sm" data-campo="n_prog" maxlength="60">
                        </td>
                        <td>
                            <select class="form-select form-select-sm" data-campo="espessura">
                                <option value="">--</option>
                                <?php foreach ($espessuras as $esp) : ?>
                                    <option value="<?= $h($esp->valor) ?>"><?= $h($esp->valor) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td><input type="number" class="form-control form-control-sm" data-campo="largura" min="0"></td>
                        <td><input type="number" class="form-control form-control-sm" data-campo="comprimento" min="0"></td>
                        <td><input type="number" class="form-control form-control-sm" data-campo="qtde" min="0"></td>
                        <td><input type="text" class="form-control form-control-sm text-center" data-campo="tempo" placeholder="00:00:00"></td>
                        <td><input type="text" class="form-control form-control-sm" data-campo="reserva" maxlength="60"></td>
                        <td class="text-center">
                            <div class="form-check d-inline-block">
                                <input class="form-check-input" type="checkbox" data-campo="cortado">
                                <label class="form-check-label fs-8">OK</label>
                            </div>
                        </td>
                        <td>
                            <button type="button" class="btn btn-sm btn-salvar-plano">Salvar</button>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($pronta) : ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <button type="button" class="btn btn-sm btn-outline-primary" id="btnAdicionarPlano">
                <i class="bi bi-plus-lg me-1"></i> Adicionar linha
            </button>

            <small class="text-muted fs-8">
                Preencha o Nº Prog e clique em <strong>Salvar</strong> na linha.
            </small>
        </div>
    <?php endif; ?>
</fieldset>

<?php /* ---------------------------- OBSERVAÇÕES ---------------------------- */ ?>
<fieldset class="box-corte mt-3">
    <legend>Observações</legend>

    <textarea id="observacoes" class="form-control" rows="3" style="resize:vertical;"
              placeholder="Observações do corte..." <?= $pronta ? '' : 'disabled' ?>><?= $h($controle->observacoes ?? '') ?></textarea>
</fieldset>

<div class="row mt-4">
    <div class="col-md-3">
        <button type="button" class="btn btn-primary btn-sm w-100" id="btnSalvarControle"
                data-codigo="<?= $h($codigo) ?>" <?= $pronta ? '' : 'disabled' ?>>
            <i class="bi bi-save me-1"></i> Salvar dados do projeto
        </button>
    </div>

    <div class="col-md-3">
        <a href="<?= route('dispositivos.cortes.lista') ?>" class="btn btn-secondary btn-sm w-100">
            <i class="bi bi-list me-1"></i> Voltar para a lista
        </a>
    </div>
</div>
