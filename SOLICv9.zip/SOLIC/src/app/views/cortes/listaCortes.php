<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.menu"),
    "webTitle"  => "Dispositivos - Controle de Cortes",
    "cardTitle" => "CONTROLE DE CORTES DE PEÇAS",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css',
        path()->css("cortes.css")
    ],
    "js" => [
        path()->js("listaCortes.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

function classeStatusCorte($status)
{
    return match (strtoupper(trim((string) $status))) {
        'FINALIZADO'         => 'status-ok',
        'CORTE EM ANDAMENTO' => 'status-alerta',
        'CORTE LIBERADO'     => 'status-backlog',
        'AGUARDANDO'         => 'status-espera',
        default              => '',
    };
}

function classePrioridade($prioridade)
{
    return match (trim((string) $prioridade)) {
        '01-Alta'  => 'status-revisao',
        '02-Média' => 'status-alerta',
        '03-Baixa' => 'status-espera',
        default    => '',
    };
}
?>

<?php if (empty($tabelaPronta)) : ?>
    <div class="alert alert-warning fs-7" role="alert">
        <i class="bi bi-database-exclamation me-1"></i>
        Controle ainda não inicializado: rode a migration
        <code>database/migrations/2026-07-21e-controle-cortes.sql</code>.
        A lista abaixo funciona, mas prioridade, NEST e status ficam vazios.
    </div>
<?php endif; ?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
    <h5 class="mb-0">TOTAL DE PACOTES DXF: <?= (int) $qtd ?></h5>
    <a href="<?= route('dispositivos.cortes.calculoPeso') ?>" class="btn btn-sm btn-outline-primary">
        <i class="bi bi-calculator me-1"></i> Cálculo de Peso (consolidado por espessura)
    </a>
</div>

<div class="container-fluid mb-4">
    <div class="d-flex flex-wrap gap-2">
        <?php foreach ($statusOpcoes as $st) : ?>
            <a href="?status=<?= urlencode($st) ?>" class="btn btn-sm <?= classeStatusCorte($st) ?: 'btn-secondary' ?> flex-fill">
                <?= $h($st) ?>
            </a>
        <?php endforeach; ?>
        <a href="?" class="btn btn-sm btn-light border flex-fill">LIMPAR FILTROS</a>
    </div>

    <div class="row pt-3 g-2">
        <div class="col-md-6">
            <label for="prioridade" class="form-label fs-7 fw-bold d-block mb-0">Prioridade:</label>
            <select class="form-select form-select-sm" id="prioridade" name="prioridade">
                <option value="">Todas...</option>
                <?php foreach ($prioridades as $p) : ?>
                    <option value="<?= $h($p) ?>" <?= isSelect($p, $_GET['prioridade'] ?? '') ?>>
                        <?= $h($p) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
</div>

<?php /* dt-loading-shell evita o salto de layout na carga (ver responsivo.css) */ ?>
<div class="table-responsive dt-loading-shell">
    <table id="listCortes">
        <thead>
            <tr>
                <th>REF.</th>
                <th>DESCRIÇÃO</th>
                <th>COD Z</th>
                <th>N° SL</th>
                <th>PROJETO</th>
                <th>IMG</th>
                <th>DXF</th>
                <th>NEST</th>
                <th>PRIORIDADE</th>
                <th>STATUS CORTE</th>
            </tr>
        </thead>

        <tbody class="tbody">
            <?php foreach ($linhas as $linha) : ?>
                <tr>
                    <td data-label="Ref.">
                        <strong>
                            <a href="<?= route('dispositivos.cortes.detalhe', ['codigo' => $linha->codigo]) ?>">
                                <?= $h($linha->codigo) ?>
                            </a>
                        </strong>
                    </td>

                    <td data-label="Descrição" class="text-start"><?= $h($linha->descricao) ?></td>
                    <td data-label="Cod Z"><?= $h($linha->cod_z) ?></td>
                    <td data-label="N° SL"><?= $h($linha->sl) ?></td>
                    <td data-label="Projeto"><?= $h($linha->projeto) ?></td>

                    <td data-label="IMG">
                        <?php if ($linha->tem_img) : ?>
                            <i class="bi bi-check-circle-fill text-success" title="Imagem anexada"></i>
                        <?php else : ?>
                            <i class="bi bi-dash-circle text-muted" title="Sem imagem"></i>
                        <?php endif; ?>
                    </td>

                    <td data-label="DXF">
                        <?php if ($linha->tem_dxf) : ?>
                            <i class="bi bi-check-circle-fill text-success" title="Pacote DXF anexado"></i>
                        <?php else : ?>
                            <i class="bi bi-dash-circle text-muted" title="Sem pacote"></i>
                        <?php endif; ?>
                    </td>

                    <td data-label="NEST"><?= $h($linha->nest) ?: '--' ?></td>

                    <td data-label="Prioridade" class="<?= classePrioridade($linha->prioridade) ?>">
                        <?= $h($linha->prioridade) ?: '--' ?>
                    </td>

                    <td data-label="Status Corte" class="<?= classeStatusCorte($linha->status_corte) ?>">
                        <?= $h($linha->status_corte) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= $this->insert('templates/dt'); ?>
