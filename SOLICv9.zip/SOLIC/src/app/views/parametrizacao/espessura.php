<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.menu.parametrizacao"),
    "webTitle"  => "Dispositivos - Espessuras",
    "cardTitle" => "PARAMETRIZAÇÃO DE ESPESSURAS",
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};
?>

<div class="alert alert-light border fs-8">
    <i class="bi bi-info-circle me-1"></i>
    As espessuras cadastradas aqui alimentam a coluna <strong>Esp.</strong> dos planos de
    corte. O valor é texto, porque nem toda espessura é numérica (ex.: <code>4,75 Xd</code>).
    A <strong>densidade</strong> e o <strong>peso da chapa padrão</strong> são usados no
    Cálculo de Peso (consolidado por espessura).
</div>

<form action="<?= route('parametrizacao.espessuras.store') ?>" method="POST" id="formEspessura">
    <div class="row g-2 align-items-end">
        <div class="col-md-3">
            <label for="valor" class="form-label">ESPESSURA <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="valor" name="valor"
                   maxlength="30" placeholder="Ex.: 6,35" required>
        </div>

        <div class="col-md-3">
            <label for="descricao" class="form-label">DESCRIÇÃO</label>
            <input type="text" class="form-control form-control-sm" id="descricao" name="descricao"
                   maxlength="120" placeholder="Opcional">
        </div>

        <div class="col-md-2">
            <label for="densidade" class="form-label">DENSIDADE (kg/m³)</label>
            <input type="text" class="form-control form-control-sm" id="densidade" name="densidade"
                   placeholder="7860">
        </div>

        <div class="col-md-2">
            <label for="peso_chapa_padrao" class="form-label">CHAPA PADRÃO (kg)</label>
            <input type="text" class="form-control form-control-sm" id="peso_chapa_padrao" name="peso_chapa_padrao"
                   placeholder="Opcional">
        </div>

        <div class="col-md-2">
            <button type="submit" class="btn btn-company btn-sm w-100">
                <i class="bi bi-plus-lg me-1"></i> Cadastrar
            </button>
        </div>
    </div>
</form>

<div class="table-responsive mt-4">
    <table>
        <thead>
            <tr>
                <th>ESPESSURA</th>
                <th>DESCRIÇÃO</th>
                <th>DENSIDADE</th>
                <th>CHAPA PADRÃO (kg)</th>
                <th>AÇÕES</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($espessuras as $espessura) : ?>
                <tr>
                    <td data-label="Espessura"><strong><?= $h($espessura->valor) ?></strong></td>
                    <td data-label="Descrição"><?= $h($espessura->descricao) ?: '--' ?></td>
                    <td data-label="Densidade"><?= $h($espessura->densidade ?? '7860') ?></td>
                    <td data-label="Chapa padrão (kg)"><?= $h($espessura->peso_chapa_padrao ?? '') ?: '--' ?></td>
                    <td data-label="Ações">
                        <a href="<?= route('parametrizacao.espessuras.delete', ['id' => $espessura->id]) ?>"
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Excluir a espessura <?= $h($espessura->valor) ?>?');">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>

            <?php if (empty($espessuras)) : ?>
                <tr>
                    <td colspan="5" class="text-muted py-4">Nenhuma espessura cadastrada.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
