<?php
$this->layout("templates/base", [
    "backTo" => "http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/parametrizacoes",
    "webTitle" => "Dispositivos - Cadastro de usuário",
    "cardTitle" => "Cadastro de vagões e lote",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
    "js" => [
        path()->js("vagoes.js"),
    ],
]);
?>

<style>
    .dt-search {
        input {
            text-align: center;
            margin-bottom: 12px;
        }
    }
</style>


<form method="POST" action="<?= route('parametrizacao.vagoes.store') ?>" id="formCadastroVagao">
    <div class="row mb-3">
        <div class="col-md-3">
            <label for="inputVagao" class="form-label">VAGÃO <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="inputVagao" name="vagao" required oninput="this.value = this.value.toUpperCase().replace(/[^A-Z]/g, '')" maxlength="3" >
        </div>
        <div class="col-md-4">
            <label for="inputDescricao" class="form-label">DESCRIÇÃO <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="inputDescricao" name="descricao" required oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-3">
            <label for="inputLote" class="form-label">LOTE <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="inputLote" name="lote" required>
        </div>
        <div class="col-md-2">
            <label for="selectStatus" class="form-label">STATUS <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="selectStatus" name="status" required>
                <option selected value="ATIVO">Ativo</option>
                <option value="INATIVO">Inativo</option>
            </select>
        </div>
    </div>

    <div class="buttonsDiv">
        <button type="submit" class="btn btn-company" onclick="loading('show')">Registrar</button>
        <a class="btn btn-secondary" id="cancelForm">Cancelar</a>
    </div>
</form>
<hr>

<table id="list">
    <thead>
        <tr>
            <th class="text-center">Vagão</th>
            <th class="text-center">Descrição</th>
            <th class="text-center">Lote</th>
            <th class="text-center">Status</th>
            <th class="text-center">Ações</th>
        </tr>
    </thead>

    <tbody>
        <?php if (is_array($vagoes) || is_object($vagoes)) : ?>
            <?php foreach ($vagoes as $vagao) : ?>
                <tr>
                    <td class="text-center"><?= $vagao->vagao ?></td>
                    <td class="text-center"><?= $vagao->descricao ?></td>
                    <td class="text-center"><?= $vagao->lote ?></td>
                    <td class="text-center"><?= $vagao->status ?></td>
                    <td>
                        <a onclick="openModal('<?= $vagao->id ?>', 'delete')" class="btn btn-sm btn-danger"><i class="ph ph-trash"></i></a>
                        <a onclick="openModal('<?= $vagao->id ?>', 'edit')" class="btn btn-sm btn-primary"><i class="ph ph-pencil"></i></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr>
                <td colspan="5" class="text-center">Nenhum registro encontrado.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<div id="edit-form" class="sidebar-content"></div>
<?= $this->insert('templates/dt'); ?>