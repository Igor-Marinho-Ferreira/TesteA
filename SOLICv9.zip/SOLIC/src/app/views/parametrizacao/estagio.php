<?php
$this->layout("templates/base", [
      "backTo" => "http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/parametrizacoes",
  "webTitle" => "Dispositivos - Cadastro de estágios",
  "cardTitle" => "Cadastro de estágios",
  "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
  "js" => [
    path()->js("estagio.js"),
  ],
]);
?>

<style>
.dt-search {
    input {
        text-align: center;
        margin-bottom: 12px;
    }
}
</style>


<form method="POST" action="<?= route('parametrizacao.estagios.store') ?>" id="formCadastroEstagio">
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="inputEstagio" class="form-label">ESTÁGIO <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="inputEstagio" name="estagio" required oninput="this.value = this.value.toUpperCase()">
        </div>
    </div>


    <div class="buttonsDiv">
        <button type="submit" class="btn btn-company" onclick="loading('show')">Registrar</button>
        <a class="btn btn-secondary" id="cancelForm">Cancelar</a>
    </div>
</form>

<hr>

<table id="list">
    <thead>
        <tr>
            <th class="text-center">Estágio</th>
            <th class="text-center">Ações</th>
        </tr>
    </thead>

    <tbody>
        <?php if (is_array($estagios) || is_object($estagios)): ?>
        <?php foreach ($estagios as $estagio): ?>
        <tr>
            <td class="text-center"><?= $estagio->estagio ?></td>
            <td>
                <a onclick="openModal('<?= $estagio->id ?>', 'delete')" class="btn btn-sm btn-danger"><i
                        class="ph ph-trash"></i></a>
                <a onclick="openModal('<?= $estagio->id ?>', 'edit')" class="btn btn-sm btn-primary"><i
                        class="ph ph-pencil"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php else: ?>
        <tr>
            <td colspan="5" class="text-center">Nenhum registro encontrado.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<div id="edit-form" class="sidebar-content"></div>
<?= $this->insert('templates/dt'); ?>