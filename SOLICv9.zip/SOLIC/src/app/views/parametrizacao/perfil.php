<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.menu.parametrizacao"),
    "webTitle"  => "Dispositivos - Perfis",
    "cardTitle" => "PARAMETRIZAÇÃO DE PERFIS",
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$perfis = $perfis ?? [];
$tipos  = $tipos ?? [];
$pronta = !empty($pronta);
?>

<?php if (!$pronta) : ?>
    <div class="alert alert-warning fs-7" role="alert">
        <i class="bi bi-database-exclamation me-1"></i>
        Rode a migration <code>database/migrations/2026-07-21f-calculo-peso.sql</code>
        para habilitar o cadastro de perfis.
    </div>
<?php endif; ?>

<div class="alert alert-light border fs-8">
    <i class="bi bi-info-circle me-1"></i>
    O <strong>peso por metro (kg/m)</strong> de cada perfil vem das tabelas da área. Ele
    alimenta a calculadora de peso de perfis: <em>peso = kg/m × comprimento(m) × qtde</em>.
</div>

<form action="<?= route('parametrizacao.perfis.store') ?>" method="POST">
    <div class="row g-2 align-items-end">
        <div class="col-md-3">
            <label for="tipo" class="form-label">TIPO <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="tipo" name="tipo" required <?= $pronta ? '' : 'disabled' ?>>
                <option value="">Selecione...</option>
                <?php foreach ($tipos as $valor => $rotulo) : ?>
                    <option value="<?= $h($valor) ?>"><?= $h($rotulo) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label for="descricao" class="form-label">BITOLA / DIMENSÃO</label>
            <input type="text" class="form-control form-control-sm" id="descricao" name="descricao"
                   maxlength="120" placeholder="Ex.: 50x30x2" <?= $pronta ? '' : 'disabled' ?>>
        </div>

        <div class="col-md-2">
            <label for="peso_por_metro" class="form-label">PESO (kg/m) <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="peso_por_metro" name="peso_por_metro"
                   placeholder="Ex.: 2,35" required <?= $pronta ? '' : 'disabled' ?>>
        </div>

        <div class="col-md-3">
            <button type="submit" class="btn btn-company btn-sm w-100" <?= $pronta ? '' : 'disabled' ?>>
                <i class="bi bi-plus-lg me-1"></i> Cadastrar
            </button>
        </div>
    </div>
</form>

<div class="table-responsive mt-4">
    <table>
        <thead>
            <tr>
                <th>TIPO</th>
                <th>BITOLA / DIMENSÃO</th>
                <th>PESO (kg/m)</th>
                <th>AÇÕES</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($perfis as $perfil) : ?>
                <tr>
                    <td data-label="Tipo"><strong><?= $h($tipos[$perfil->tipo] ?? $perfil->tipo) ?></strong></td>
                    <td data-label="Bitola"><?= $h($perfil->descricao) ?: '--' ?></td>
                    <td data-label="Peso (kg/m)"><?= $h(number_format((float) $perfil->peso_por_metro, 3, ',', '.')) ?></td>
                    <td data-label="Ações">
                        <a href="<?= route('parametrizacao.perfis.delete', ['id' => $perfil->id]) ?>"
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Excluir este perfil?');">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>

            <?php if (empty($perfis)) : ?>
                <tr>
                    <td colspan="4" class="text-muted py-4">Nenhum perfil cadastrado.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
