<?php
$this->layout("templates/base", [
    "backTo" => "http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/parametrizacoes",
    "webTitle" => "Dispositivos - Cadastro de conta",
    "cardTitle" => "Cadastro de Contas",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
    "js" => [
        path()->js("conta.js"),
    ],
]);
?>

<style>
    .dt-search {
        input {
            text-align: center;
            margin-bottom: 12px;
        }
    }
</style>


<form method="POST" action="<?= route('parametrizacao.contas.store') ?>" id="formCadastroConta">
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="inputSfpContaContabil" class="form-label">CONTA CONTÁBIL <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="inputSfpContaContabil" name="sfp_conta_contabil" required oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>
        <div class="col-md-5">
            <label for="inputDescricao" class="form-label">DESCRIÇÃO <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="inputDescricao" name="descricao" required oninput="this.value = this.value.toUpperCase().replace(/^\s+/g, '')">
        </div>
        <div class="col-md-3">
            <label for="selectStatus" class="form-label">STATUS <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="selectStatus" name="status" required>
                <option selected value="ATIVO">Ativo</option>
                <option value="INATIVO">Inativo</option>
            </select>
        </div>
    </div>

    <div class="row mb-3 mt-3">
        <div class="col-md-4">
            <label for="inputValorFerramenta" class="form-label">VALOR DE FERRAMENTA (R$)</label>
            <input type="text" class="form-control form-control-sm" id="inputValorFerramenta" name="valor_ferramenta" placeholder="0,00" oninput="this.value = this.value.replace(/[^0-9,]/g, '').replace(/(,.*),/g, '$1')">
        </div>

        <div class="col-md-4">
            <label for="inputValorMateriaPrima" class="form-label">VALOR DE MATÉRIA PRIMA (R$)</label>
            <input type="text" class="form-control form-control-sm" id="inputValorMateriaPrima" name="valor_materia_prima" placeholder="0,00" oninput="this.value = this.value.replace(/[^0-9,]/g, '').replace(/(,.*),/g, '$1')">
        </div>

        <div class="col-md-4">
            <label for="inputValorHH" class="form-label">VALOR DE HH (R$)</label>
            <input type="text" class="form-control form-control-sm" id="inputValorHH" name="valor_hh" placeholder="0,00" oninput="this.value = this.value.replace(/[^0-9,]/g, '').replace(/(,.*),/g, '$1')">
        </div>
    </div>

    <div class="row mb-3 mt-3">
        <div class="col-md-3">
            <label for="inputSfp" class="form-label">N° SFP</label>
            <input type="text" class="form-control form-control-sm" id="inputSfp" name="sfp" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>

        <div class="col-md-4">
            <label for="selectLiderProjeto" class="form-label">LÍDER DO PROJETO</label>
            <select class="form-select form-select-sm" id="selectLiderProjeto" name="lider_projeto">
                <option selected disabled value="">Selecione o Líder...</option>
                <?php foreach ($leaders as $leader) : ?>
                    <option value="<?= $leader->nome ?>">
                        <?= $leader->nome ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3">
            <label for="inputVagao" class="form-label">VAGÃO <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="selectVagao" name="vagao">
                <option selected disabled value="">Selecione o vagão...</option>
                <?php foreach ($vagoes as $vagao) : ?>
                    <option value="<?= $vagao->vagao ?>">
                        <?= $vagao->vagao ?>
                    </option>
                <?php endforeach; ?>
            </select>

        </div>

        <div class="col-md-2">
            <label for="inputLote" class="form-label">LOTE <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="selectLote" name="lote" disabled>
                <option selected disabled value="">Selecione o lote...</option>
                <?php foreach ($lotes as $lote) : ?>
                    <option value="<?= $lote->lote ?>">
                        <?= $lote->lote ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>


    <div class="buttonsDiv">
        <button type="submit" class="btn btn-company">Registrar</button>
        <a class="btn btn-secondary" id="cancelForm">Cancelar</a>
    </div>
</form>
<hr>

<table id="list">
    <thead>
        <tr>
            <th class="text-center">N° SFP OU CONTA CONTÁBIL</th>
            <th class="text-center" style="width: 30%;">DESCRIÇÃO</th>
            <th class="text-center">VALOR DE FERRAMENTA (R$)</th>
            <th class="text-center">VALOR DE MATÉRIA PRIMA (R$)</th>
            <th class="text-center">VALOR DE HH (R$)</th>
            <th class="text-center">N° SFP</th>
            <th class="text-center">LÍDER DO PROJETO</th>
            <th class="text-center">VAGÃO</th>
            <th class="text-center">LOTE</th>
            <th class="text-center">STATUS</th>
            <th class="text-center">AÇÕES</th>
        </tr>
    </thead>

    <tbody>
        <?php if (is_array($contas) || is_object($contas)) : ?>
            <?php foreach ($contas as $conta) : ?>
                <tr>
                    <td class="text-center"><?= $conta->sfp_conta_contabil ?></td>
                    <td class="text-center"><?= $conta->descricao ?></td>
                    <td class="text-center"><?= $conta->valor_ferramenta ?></td>
                    <td class="text-center"><?= $conta->valor_materia_prima ?></td>
                    <td class="text-center"><?= $conta->valor_hh ?></td>
                    <td class="text-center"><?= $conta->sfp ?></td>
                    <td class="text-center"><?= $conta->lider_projeto ?></td>
                    <td class="text-center"><?= $conta->vagao ?></td>
                    <td class="text-center"><?= $conta->lote ?></td>
                    <td class="text-center"><?= $conta->status ?></td>
                    <td>
                        <a onclick="openModal('<?= $conta->id ?>', 'delete')" class="btn btn-sm btn-danger"><i class="ph ph-trash"></i></a>
                        <a onclick="openModal('<?= $conta->id ?>', 'edit')" class="btn btn-sm btn-primary"><i class="ph ph-pencil"></i></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr>
                <td colspan="5" class="text-center">Nenhum registro encontrado.</td>
            </tr>
        <?php endif; ?>
    </tbody>

</table>
<div id="edit-form" class="sidebar-content"></div>
<?= $this->insert('templates/dt'); ?>