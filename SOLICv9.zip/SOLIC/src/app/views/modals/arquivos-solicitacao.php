<?php
$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$ultimaCarga = $ultimaCarga ?? null;

$imagemProjeto = $imagemProjeto ?? null;
$pacotesDxf = $pacotesDxf ?? [];
$txtItensComprados = $txtItensComprados ?? [];
$listasMateriais = $listasMateriais ?? [];
$desenhosPdf = $desenhosPdf ?? [];
$itensComprados = $itensComprados ?? [];

$prioridadeAtual = $ultimaCarga->prioridade ?? '02-Média';

$semArquivosDxfAtual = !empty($ultimaCarga) && (string)($ultimaCarga->sem_arquivos_dxf ?? '0') === '1';
$nenhumItemCompradoAtual = !empty($ultimaCarga) && (string)($ultimaCarga->nenhum_item_comprado ?? '0') === '1';

$existeImagem = !empty($imagemProjeto);
$existeDxf = !empty($pacotesDxf) || $semArquivosDxfAtual;
$existeItens = !empty($txtItensComprados) || !empty($itensComprados) || $nenhumItemCompradoAtual;
$existeListaMateriais = !empty($listasMateriais);
$existeDesenhos = !empty($desenhosPdf);
?>

<style>
    .btn-remover-arquivo {
        border: none;
        background: transparent;
        color: #dc3545;
        font-size: 1.45rem;
        line-height: 1;
        padding: 0.15rem 0.25rem;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .btn-remover-arquivo:hover {
        color: #842029;
        transform: scale(1.15);
    }

    .btn-remover-arquivo i {
        font-size: 1.45rem;
        font-weight: 700;
    }

    .confirmacao-remover-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.45);
        z-index: 99999;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 1rem;
    }

    .confirmacao-remover-card {
        width: 100%;
        max-width: 430px;
        background: #fff;
        border-radius: 14px;
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
        overflow: hidden;
        animation: confirmacaoArquivoIn 0.18s ease-out;
    }

    .confirmacao-remover-header {
        padding: 1rem 1.25rem;
        border-bottom: 1px solid #e9ecef;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .confirmacao-remover-body {
        padding: 1.25rem;
    }

    .confirmacao-remover-footer {
        padding: 1rem 1.25rem;
        background: #f8f9fa;
        border-top: 1px solid #e9ecef;
        display: flex;
        justify-content: flex-end;
        gap: .5rem;
    }

    .confirmacao-remover-icone {
        width: 46px;
        height: 46px;
        border-radius: 50%;
        background: #f8d7da;
        color: #dc3545;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        margin-bottom: .75rem;
    }

    .confirmacao-remover-icone i {
        font-size: 1.6rem;
    }

    @keyframes confirmacaoArquivoIn {
        from {
            opacity: 0;
            transform: translateY(8px) scale(.98);
        }

        to {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }
</style>

<form 
    action="<?= route('dispositivos.desenvolvimento.arquivosSolicitacao.store', ['ref' => $solicitacao->ref]) ?>" 
    method="POST" 
    enctype="multipart/form-data"
    class="modal-arquivos-solicitacao"
>
    <div class="modal-arquivos-header">
        <h6 class="mb-0 fw-bold">Inserir Arquivos da Solicitação</h6>

        <button type="button" class="btn-close-modal" onclick="closeModal()">
            &times;
        </button>
    </div>

    <div class="modal-arquivos-body">
        <div class="row mb-2">
            <div class="col-md-1">
                <label class="modal-label">Projeto:</label>

                <div class="modal-info">
                    <?= !empty($solicitacao->cod_z) ? 'Z' . ltrim($solicitacao->cod_z, 'zZ') : '--' ?>
                </div>
            </div>

            <div class="col-md-2">
                <label class="modal-label">Solicitação n.º:</label>

                <div class="modal-info">
                    SL<?= $h($solicitacao->ref) ?>
                </div>
            </div>

            <div class="col-md-9 d-flex align-items-end">
                <strong class="modal-title-desc">
                    <?= strtoupper($h($solicitacao->descricao ?? '')) ?>
                </strong>
            </div>
        </div>

        <?php if (!empty($ultimaCarga)) : ?>
            <div class="alert alert-info py-2 mb-3 small">
                Já existe uma carga de arquivos para esta solicitação.
                Você pode adicionar novos arquivos ou substituir enviando novamente.
            </div>
        <?php endif; ?>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="box-preview-imagem">
                    <?php if ($existeImagem) : ?>
                        <a 
                            href="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $imagemProjeto->id]) ?>" 
                            target="_blank"
                            title="Abrir imagem"
                        >
                            <img 
                                id="previewImagemSolicitacao" 
                                src="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $imagemProjeto->id]) ?>" 
                                alt="Imagem do Projeto"
                                onerror="this.src='https://placehold.co/420x220?text=Imagem+do+Projeto'"
                            >
                        </a>
                    <?php else : ?>
                        <img 
                            id="previewImagemSolicitacao" 
                            src="https://placehold.co/420x220?text=Imagem+do+Projeto" 
                            alt="Imagem do Projeto"
                        >
                    <?php endif; ?>
                </div>

                <input 
                    type="file" 
                    name="imagem_projeto" 
                    id="imagem_projeto" 
                    class="visually-hidden" 
                    accept="image/*"
                    data-existe="<?= $existeImagem ? '1' : '0' ?>"
                >

                <label 
                    for="imagem_projeto"
                    id="btn_imagem_projeto"
                    class="btn-modal-success w-100 mt-2 text-center d-block" 
                    title="Insira a imagem do projeto."
                    style="cursor: pointer;"
                >
                    <?= $existeImagem ? 'Substituir Imagem' : 'Inserir Imagem' ?>
                </label>

                <div class="mt-3">
                    <div class="form-check">
                        <input 
                            class="form-check-input" 
                            type="checkbox" 
                            name="sem_arquivos_dxf" 
                            id="sem_arquivos_dxf" 
                            value="1"
                            <?= $semArquivosDxfAtual ? 'checked' : '' ?>
                            <?= $existeImagem ? '' : 'disabled' ?>
                            title="Primeiro insira a imagem do projeto."
                        >

                        <label class="form-check-label small" for="sem_arquivos_dxf">
                            Sem arquivos DXF
                        </label>
                    </div>

                    <label class="modal-label mt-1">Pacote de Arquivos DXF</label>

                    <?php if (!empty($pacotesDxf)) : ?>
                        <div class="border rounded bg-light p-2 mb-2 small">
                            <strong>DXF carregado(s):</strong>

                            <?php foreach ($pacotesDxf as $dxf) : ?>
                                <?php $formId = 'form_remover_arquivo_' . ($dxf->id ?? ''); ?>

                                <div class="d-flex align-items-center justify-content-between gap-2 border-bottom py-1">
                                    <a
                                        href="<?= route('dispositivos.desenvolvimento.arquivo.download', ['id' => $dxf->id]) ?>"
                                        class="text-truncate text-decoration-none"
                                        title="Clique para baixar <?= $h($dxf->nome_original ?? '') ?>"
                                    >
                                        <?= $h($dxf->nome_original ?? '') ?>
                                    </a>

                                    <button
                                        type="button"
                                        class="btn-remover-arquivo"
                                        title="Remover DXF"
                                        data-form-id="<?= $h($formId) ?>"
                                        data-nome-arquivo="<?= $h($dxf->nome_original ?? '') ?>"
                                        data-tipo-arquivo="DXF"
                                        onclick="abrirConfirmacaoRemoverArquivo(this)"
                                    >
                                        <i class="ph ph-trash"></i>
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <input 
                        type="file" 
                        name="pacote_dxf" 
                        id="pacote_dxf" 
                        class="visually-hidden" 
                        accept=".zip,.rar,.7z"
                        data-existe="<?= !empty($pacotesDxf) ? '1' : '0' ?>"
                    >

                    <input 
                        type="text" 
                        id="nome_pacote_dxf" 
                        class="form-control form-control-sm mb-1" 
                        value="<?= !empty($pacotesDxf) ? count($pacotesDxf) . ' pacote(s) DXF carregado(s)' : '' ?>"
                        readonly
                    >

                    <label 
                        for="pacote_dxf"
                        id="btn_pacote_dxf"
                        class="btn-modal-outline w-100 text-center d-block <?= $existeImagem && !$semArquivosDxfAtual ? '' : 'disabled' ?>" 
                        title="Primeiro insira a imagem do projeto."
                        style="<?= $existeImagem && !$semArquivosDxfAtual ? 'cursor: pointer;' : 'cursor: not-allowed; opacity: 0.65; pointer-events: none;' ?>"
                    >
                        <?= !empty($pacotesDxf) ? 'Adicionar outro Pacote de DXF' : 'Inserir Pacote de DXF' ?>
                    </label>
                </div>
            </div>

            <div class="col-md-5">
                <fieldset class="modal-fieldset h-100">
                    <legend>Itens Comprados</legend>

                    <?php if (!empty($txtItensComprados)) : ?>
                        <div class="border rounded bg-light p-2 mb-2 small">
                            <strong>TXT carregado(s):</strong>

                            <?php foreach ($txtItensComprados as $txt) : ?>
                                <div class="d-flex align-items-center gap-2 border-bottom py-1">
                                    <span class="text-truncate" title="<?= $h($txt->nome_original ?? '') ?>">
                                        <?= $h($txt->nome_original ?? '') ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <label class="modal-label">Selecione um ou mais TXT de Itens Comprados:</label>

                    <input 
                        type="file" 
                        name="itens_comprados_txt[]" 
                        id="itens_comprados_txt" 
                        class="visually-hidden" 
                        accept=".txt,text/plain"
                        multiple
                        data-existe="<?= !empty($txtItensComprados) ? '1' : '0' ?>"
                    >

                    <input 
                        type="text" 
                        id="nome_itens_comprados_txt" 
                        class="form-control form-control-sm mb-2" 
                        value="<?= !empty($txtItensComprados) ? count($txtItensComprados) . ' TXT(s) carregado(s)' : '' ?>"
                        readonly
                        placeholder="Nenhum TXT selecionado"
                    >

                    <label 
                        for="itens_comprados_txt"
                        id="btn_itens_comprados_txt"
                        class="btn-modal-outline w-100 text-center d-block <?= $existeDxf && !$nenhumItemCompradoAtual ? '' : 'disabled' ?>"
                        title="Primeiro informe o pacote DXF ou marque Sem arquivos DXF."
                        style="<?= $existeDxf && !$nenhumItemCompradoAtual ? 'cursor: pointer;' : 'cursor: not-allowed; opacity: 0.65; pointer-events: none;' ?>"
                    >
                        <?= !empty($txtItensComprados) ? 'Substituir TXT de Itens Comprados' : 'Adicionar TXT de Itens Comprados' ?>
                    </label>

                    <div id="lista_itens_comprados_txt" class="mt-2 mb-2 small">
                        <?php if (!empty($txtItensComprados)) : ?>
                            <div class="text-muted">
                                Ao selecionar novo TXT, o atual será substituído.
                            </div>
                        <?php endif; ?>
                    </div>

                    <button
                        type="button"
                        id="btn_limpar_itens_comprados_txt"
                        class="btn-modal-outline w-100 mb-2"
                        onclick="limparTodosTxtItensComprados()"
                        disabled
                        title="Nenhum TXT adicionado."
                    >
                        Limpar TXTs selecionados
                    </button>

                    <div class="form-check small mt-2 mb-2">
                        <input 
                            class="form-check-input" 
                            type="checkbox" 
                            name="nenhum_item_comprado" 
                            id="nenhum_item_comprado" 
                            value="1"
                            <?= $nenhumItemCompradoAtual ? 'checked' : '' ?>
                            <?= $existeDxf ? '' : 'disabled' ?>
                            title="Primeiro informe o pacote DXF ou marque Sem arquivos DXF."
                        >

                        <label class="form-check-label" for="nenhum_item_comprado">
                            Nenhum Item Comprado
                        </label>
                    </div>

                    <div class="table-responsive tabela-modal-wrapper" style="max-height: 260px; overflow: auto;">
                        <table class="table table-sm table-bordered mb-0" style="min-width: 900px; table-layout: fixed;">
                            <thead>
                                <tr>
                                    <th style="width: 12%;">CÓDIGO</th>
                                    <th style="width: 8%;">REV</th>
                                    <th style="width: 42%;">DESCRIÇÃO</th>
                                    <th style="width: 13%;">QTDE</th>
                                    <th style="width: 25%;">TIPO</th>
                                </tr>
                            </thead>

                            <tbody id="tbodyItensComprados">
                                <?php if (!empty($itensComprados)) : ?>
                                    <?php foreach ($itensComprados as $item) : ?>
                                        <tr>
                                            <td><?= $h($item->codigo ?? '--') ?></td>
                                            <td><?= $h($item->rev ?? '--') ?></td>
                                            <td class="text-break text-start" style="white-space: normal;">
                                                <?= $h($item->descricao ?? '--') ?>
                                            </td>
                                            <td class="text-break" style="white-space: normal;">
                                                <?= $h($item->quantidade ?? '--') ?>
                                            </td>
                                            <td class="text-break text-start" style="white-space: normal;">
                                                <?= $h($item->tipo ?? '--') ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            Nenhum item comprado informado.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </fieldset>
            </div>

            <div class="col-md-3">
                <fieldset class="modal-fieldset">
                    <legend>Desenhos em PDF</legend>

                    <div class="table-responsive tabela-modal-wrapper tabela-desenhos">
                        <table class="table table-sm table-bordered mb-2">
                            <thead>
                                <tr>
                                    <th>DESENHO</th>
                                </tr>
                            </thead>

                            <tbody id="tbodyDesenhosPdf">
                                <?php if (!empty($desenhosPdf)) : ?>
                                    <?php foreach ($desenhosPdf as $pdf) : ?>
                                        <?php $formId = 'form_remover_arquivo_' . ($pdf->id ?? ''); ?>

                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center justify-content-between gap-2">
                                                    <a
                                                        href="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $pdf->id]) ?>"
                                                        target="_blank"
                                                        class="text-truncate text-decoration-none"
                                                        title="Clique para abrir <?= $h($pdf->nome_original ?? '') ?>"
                                                    >
                                                        <?= $h($pdf->nome_original ?? '') ?>
                                                    </a>

                                                    <button
                                                        type="button"
                                                        class="btn-remover-arquivo"
                                                        title="Remover PDF"
                                                        data-form-id="<?= $h($formId) ?>"
                                                        data-nome-arquivo="<?= $h($pdf->nome_original ?? '') ?>"
                                                        data-tipo-arquivo="PDF"
                                                        onclick="abrirConfirmacaoRemoverArquivo(this)"
                                                    >
                                                        <i class="ph ph-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td class="text-center text-muted py-4">
                                            Nenhum desenho informado.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <input 
                        type="file" 
                        name="desenhos_pdf[]" 
                        id="desenhos_pdf" 
                        class="visually-hidden" 
                        accept="application/pdf,.pdf" 
                        multiple
                        data-existe="<?= !empty($desenhosPdf) ? '1' : '0' ?>"
                    >

                    <label 
                        for="desenhos_pdf"
                        id="btn_desenhos_pdf"
                        class="btn-modal-outline w-100 text-center d-block <?= $existeListaMateriais ? '' : 'disabled' ?>"
                        title="Primeiro insira a lista de materiais."
                        style="<?= $existeListaMateriais ? 'cursor: pointer;' : 'cursor: not-allowed; opacity: 0.65; pointer-events: none;' ?>"
                    >
                        <?= !empty($desenhosPdf) ? 'Adicionar Desenhos' : 'Inserir Desenhos' ?>
                    </label>
                </fieldset>

                <div class="mt-3">
                    <label class="modal-label">Prioridade:</label>

                    <select name="prioridade" id="prioridade" class="form-select form-select-sm">
                        <option value="01-Alta" <?= $prioridadeAtual === '01-Alta' ? 'selected' : '' ?>>01-Alta</option>
                        <option value="02-Média" <?= $prioridadeAtual === '02-Média' ? 'selected' : '' ?>>02-Média</option>
                        <option value="03-Baixa" <?= $prioridadeAtual === '03-Baixa' ? 'selected' : '' ?>>03-Baixa</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="row g-3 mt-2">
            <div class="col-md-4"></div>

            <div class="col-md-5">
                <fieldset class="modal-fieldset">
                    <legend>Lista de Materiais</legend>

                    <?php if (!empty($listasMateriais)) : ?>
                        <div class="border rounded bg-light p-2 mb-2 small">
                            <strong>Lista(s) carregada(s):</strong>

                            <?php foreach ($listasMateriais as $lista) : ?>
                                <div class="d-flex align-items-center gap-2 border-bottom py-1">
                                    <span class="text-truncate" title="<?= $h($lista->nome_original ?? '') ?>">
                                        <?= $h($lista->nome_original ?? '') ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <label class="modal-label">Selecione um arquivo Excel:</label>

                    <input 
                        type="file" 
                        name="lista_materiais" 
                        id="lista_materiais" 
                        class="visually-hidden" 
                        accept=".xls,.xlsx,.csv"
                        data-existe="<?= !empty($listasMateriais) ? '1' : '0' ?>"
                    >

                    <input 
                        type="text" 
                        id="nome_lista_materiais" 
                        class="form-control form-control-sm mb-2" 
                        value="<?= !empty($listasMateriais) ? count($listasMateriais) . ' lista(s) já carregada(s)' : '' ?>"
                        readonly
                    >

                    <label 
                        for="lista_materiais"
                        id="btn_lista_materiais"
                        class="btn-modal-danger w-100 text-center d-block <?= $existeItens ? '' : 'disabled' ?>"
                        title="Primeiro insira o TXT de itens comprados ou marque Nenhum Item Comprado."
                        style="<?= $existeItens ? 'cursor: pointer;' : 'cursor: not-allowed; opacity: 0.65; pointer-events: none;' ?>"
                    >
                        <?= !empty($listasMateriais) ? 'Substituir Lista de Materiais' : 'Inserir Lista de Materiais' ?>
                    </label>
                </fieldset>
            </div>

            <div class="col-md-3 d-flex flex-column justify-content-end gap-2">
                <button 
                    type="button" 
                    class="btn-modal-outline w-100"
                    onclick="closeModal()"
                >
                    Cancelar
                </button>

                <button 
                    type="submit" 
                    id="btn_carregar_dados"
                    class="btn-modal-primary w-100"
                    onclick="loading('show', true)"
                    <?= ($existeImagem && $existeDxf && $existeItens && $existeListaMateriais && $existeDesenhos) ? '' : 'disabled' ?>
                    title="Primeiro complete a sequência de arquivos."
                >
                    Carregar Dados
                </button>
            </div>
        </div>
    </div>
</form>

<?php foreach ($pacotesDxf as $dxf) : ?>
    <form
        id="form_remover_arquivo_<?= $h($dxf->id) ?>"
        action="<?= route('dispositivos.desenvolvimento.arquivo.remover', ['id' => $dxf->id]) ?>"
        method="POST"
    ></form>
<?php endforeach; ?>

<?php foreach ($desenhosPdf as $pdf) : ?>
    <form
        id="form_remover_arquivo_<?= $h($pdf->id) ?>"
        action="<?= route('dispositivos.desenvolvimento.arquivo.remover', ['id' => $pdf->id]) ?>"
        method="POST"
    ></form>
<?php endforeach; ?>

<div id="confirmacaoRemoverArquivoBackdrop" class="confirmacao-remover-backdrop d-none">
    <div class="confirmacao-remover-card">
        <div class="confirmacao-remover-header">
            <strong>Confirmar remoção</strong>

            <button 
                type="button" 
                class="btn-close" 
                onclick="fecharConfirmacaoRemoverArquivo()"
            ></button>
        </div>

        <div class="confirmacao-remover-body">
            <div class="confirmacao-remover-icone">
                <i class="ph ph-trash"></i>
            </div>

            <p class="mb-1 fw-semibold">
                Deseja remover este arquivo?
            </p>

            <p class="mb-0 text-muted small">
                <span id="confirmacaoRemoverTipoArquivo">Arquivo</span>:
                <strong id="confirmacaoRemoverNomeArquivo"></strong>
            </p>
        </div>

        <div class="confirmacao-remover-footer">
            <button 
                type="button" 
                class="btn btn-sm btn-outline-secondary"
                onclick="fecharConfirmacaoRemoverArquivo()"
            >
                Cancelar
            </button>

            <button 
                type="button" 
                class="btn btn-sm btn-danger"
                onclick="confirmarRemocaoArquivo()"
            >
                Remover
            </button>
        </div>
    </div>
</div>