<?php
$this->layout("templates/baseModal", [
    "headTitle" => ($acao ?? 'retornar') === 'cancelar' ? 'CANCELAMENTO DE SL' : 'RETORNAR SL',
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$acao = ($acao ?? 'retornar') === 'cancelar' ? 'cancelar' : 'retornar';

// Cada ação tem seu texto, cor e rota de POST
if ($acao === 'cancelar') {
    $icone       = 'bi-exclamation-triangle text-danger';
    $titulo      = 'Cancelar a SL' . $h($ref) . '?';
    $descricao   = 'O cancelamento marca TODAS as etapas como CANCELADO. A ação é registrada no histórico.';
    $btnClasse   = 'btn-danger';
    $btnTexto    = 'CANCELAR SOLICITAÇÃO';
    $rotaPost    = route('dispositivos.desenvolvimento.cancelar', ['ref' => $ref]);
    $placeholder = 'Digite o motivo do cancelamento...';
} else {
    $icone       = 'bi-arrow-counterclockwise text-warning';
    $titulo      = 'Retornar a SL' . $h($ref) . ' para revisão?';
    $descricao   = 'A SL volta para a etapa de LIBERAÇÃO como REVISAR. Aquisição, corte e execução são reabertos. Os dados de OC/liquidação são preservados.';
    $btnClasse   = 'btn-warning';
    $btnTexto    = 'RETORNAR SL';
    $rotaPost    = route('dispositivos.desenvolvimento.retornar', ['ref' => $ref]);
    $placeholder = 'Digite o motivo do retorno...';
}
?>

<?php $this->start('modalContent') ?>

<div class="text-center pb-2">
    <div class="mb-2">
        <i class="bi <?= $icone ?>" style="font-size: 2.5rem;"></i>
    </div>
    <h5 class="fw-bold text-dark mb-1"><?= $titulo ?></h5>
    <p class="text-muted fs-7 mb-0"><?= $descricao ?></p>
</div>

<form id="formMotivoEtapa" data-ref="<?= (int) $ref ?>" data-url="<?= $h($rotaPost) ?>" data-acao="<?= $h($acao) ?>">
    <label for="mensagemMotivoEtapa" class="form-label fw-bold mb-1 fs-7">
        MOTIVO <span class="text-danger">*</span>
    </label>

    <textarea
        name="mensagem"
        id="mensagemMotivoEtapa"
        class="form-control"
        rows="3"
        style="resize: none;"
        placeholder="<?= $h($placeholder) ?>"
        required
        maxlength="1000"
    ></textarea>

    <div class="form-text fs-8">O texto acima é publicado no histórico da SL.</div>

    <div class="modal-footer d-flex justify-content-center gap-2 border-0 pt-4">
        <button type="submit" class="btn <?= $btnClasse ?>" id="btnConfirmarMotivoEtapa">
            <?= $h($btnTexto) ?>
        </button>

        <button type="button" onclick="closeModal()" class="btn btn-secondary">
            FECHAR
        </button>
    </div>
</form>

<?php $this->stop() ?>
