<?php
$this->layout("templates/baseModal", [
    "headTitle" => "Editar Vagão - lote",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
    "js" => [
        path()->js("usuario.js"),
        path()->js("controle.js"),
    ],
]);
?>
<?php $this->start('modalContent') ?>


<form method="POST" action="<?= route('parametrizacao.vagoes.update') ?>" id="formUpdateVagao">
    <input type="hidden" class="form-control form-control-sm" id="inputId" name="id" value="<?= $vagao->id ?>" readonly>
    <div class="row mb-3">
        <div class="col-md-3">
            <label for="vagao" class="form-label">VAGÃO <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="vagao" name="vagao" value="<?= $vagao->vagao ?>" readonly>
        </div>
        <div class="col-md-3">
            <label for="descricao" class="form-label">DESCRIÇÃO <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="descricao" name="descricao" value="<?= $vagao->descricao ?>" required>
        </div>
        <div class="col-md-4">
            <label for="lote" class="form-label">LOTE <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="lote" name="lote" value="<?= $vagao->lote ?>" required>
        </div>

        <div class="col-md-2">
            <label for="selectStatus" class="form-label">STATUS <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="selectStatus" name="status" required>
                <option value="ATIVO" <?= isSelect($vagao->status, 'ATIVO') ?>>Ativo</option>
                <option value="INATIVO" <?= isSelect($vagao->status, 'INATIVO') ?>>Inativo</option>
            </select>
        </div>
    </div>



    <div class="buttonsDiv d-flex justify-content-end gap-2 mt-4">
        <button type="submit" class="btn btn-company" onclick="loading('show')">Registrar</button>
        <a class="btn btn-secondary" id="cancelForm" onclick="closeModal()">Cancelar</a>
    </div>
</form>



</div>
<?php $this->stop() ?>