<?php
$this->layout("templates/baseModal", [
    "headTitle" => "Código Z pendente",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
]);
?>
<?php $this->start('modalContent') ?>

<div class="text-center py-4">
    <div class="mb-3">
        <i class="bi bi-exclamation-triangle text-warning" style="font-size: 3rem;"></i>
    </div>

    <h4 class="fw-bold text-dark">ATENÇÃO esta SL pode ser duplicada!</h4>
    <p class="fs-6 text-muted">
        Confira outras SL pendentes para esse mesmo código <span id="modal-cod-z-display" class="text-dark"></span>
    </p>
</div>

<div id="container-sl-pendentes">
</div>

<div class="modal-footer d-flex justify-content-center gap-2 border-0 pb-4">
    <button type="button" onclick="closeModal(false)" class="btn btn-secondary px-4" data-bs-dismiss="modal">
        Estou ciente
    </button>

    <button type="button" onclick="closeModal(true)" class="btn btn-outline-danger px-4" data-bs-dismiss="modal">
        Cancelar
    </button>
</div>

<?php $this->stop() ?>