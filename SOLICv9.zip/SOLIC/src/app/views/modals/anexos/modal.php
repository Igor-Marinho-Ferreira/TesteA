<?php
$this->layout("templates/baseModal", [
    "headTitle" => "ANEXOS",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
]);
?>
<?php $this->start('modalContent') ?>

<div class="container py-3">
    <div class="row g-3">
        <?php if (empty($anexos)) : ?>
            <div class="col-12 text-center py-4">
                <p class="text-muted italic">Nenhum anexo encontrado.</p>
            </div>
        <?php else : ?>
            <?php foreach ($anexos as $anexo) : ?>
                <?php if (isset($anexo->anexo) && mb_strlen(trim($anexo->anexo)) > 0) :
                    $nomeArquivo = basename($anexo->anexo);
                    $extensao = pathinfo($anexo->anexo, PATHINFO_EXTENSION);
                ?>
                    <div class="col-12">
                        <div class="card border-0 border-start border-primary border-4 shadow-sm h-100">
                            <div class="card-body py-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center overflow-hidden">
                                        <div class="bg-light rounded p-2 me-3">
                                            <i class="bi bi-file-earmark-text text-primary fs-4"></i>
                                        </div>
                                        <div class="text-truncate">
                                            <h6 class="mb-1 text-dark fw-bold" style="font-size: 0.85rem; letter-spacing: 0.5px; opacity: 0.7;">
                                                <?= htmlspecialchars($anexo->descricao ?? 'Arquivo') ?>
                                            </h6>
                                            <p class="mb-0 text-secondary text-truncate" style="font-size: 0.9rem;">
                                                <?= htmlspecialchars($nomeArquivo) ?>
                                            </p>
                                        </div>
                                    </div>

                                    <div class="ms-3">
                                        <a href="<?= $anexo->anexo ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3" title="Baixar arquivo">
                                            <i class="bi bi-download me-1"></i> Abrir
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<div class="modal-footer d-flex justify-content-center gap-2 border-0 pb-4">
    <button type="button" onclick="closeModal(true)" class="btn btn-outline-danger px-4" data-bs-dismiss="modal">
        Fechar
    </button>
</div>

<?php $this->stop() ?>