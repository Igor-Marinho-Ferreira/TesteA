<?php
$this->layout("templates/baseModal", [
    "headTitle" => "Editar conta",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
]);
?>
<?php $this->start('modalContent') ?>

<form method="POST" action="<?= route('parametrizacao.contas.update') ?>" id="formUpdateConta">
    <div class="row mb-3">
        <div class="col-md-4">
            <input type="hidden" id="inputId" name="id" value="<?= $conta->id ?>" readonly>
            <label for="inputSfpContaContabil" class="form-label">CONTA CONTÁBIL <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="inputSfpContaContabil" name="sfp_conta_contabil" value="<?= $conta->sfp_conta_contabil ?>" required oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>
        <div class="col-md-5">
            <label for="inputDescricao" class="form-label">DESCRIÇÃO <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="inputDescricao" name="descricao" value="<?= $conta->descricao ?>" required oninput="this.value = this.value.replace(/^\s+/g, '')">
        </div>
        <div class="col-md-3">
            <label for="selectStatus" class="form-label">STATUS <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="selectStatus" name="status" required>
                <option selected value="ATIVO">Ativo</option>
                <option value="INATIVO" isSelect()>Inativo</option>
            </select>
        </div>
    </div>

    <div class="row mb-3 mt-3">
        <div class="col-md-4">
            <label for="inputValorFerramenta" class="form-label">VALOR DE FERRAMENTA (R$)</label>
            <input type="text" class="form-control form-control-sm" id="inputValorFerramenta" name="valor_ferramenta" value="<?= $conta->valor_ferramenta ?>" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>

        <div class="col-md-4">
            <label for="inputValorMateriaPrima" class="form-label">VALOR DE MATÉRIA PRIMA (R$)</label>
            <input type="text" class="form-control form-control-sm" id="inputValorMateriaPrima" name="valor_materia_prima" value="<?= $conta->valor_materia_prima ?>" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>

        <div class="col-md-4">
            <label for="inputValorHH" class="form-label">VALOR DE HH (R$)</label>
            <input type="text" class="form-control form-control-sm" id="inputValorHH" name="valor_hh" value="<?= $conta->valor_hh ?>" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>
    </div>

    <div class="row mb-3 mt-3">
        <div class="col-md-3">
            <label for="inputSfp" class="form-label">N° SFP</label>
            <input type="text" class="form-control form-control-sm" id="inputSfp" name="sfp" value="<?= $conta->sfp ?>" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>

        <div class="col-md-4">
            <label for="selectLiderProjeto" class="form-label">LÍDER DO PROJETO</label>
            <select class="form-select form-select-sm" id="selectLiderProjeto" name="lider_projeto">
                <?php foreach ($leaders as $leader) : ?>
                    <option value="<?= $leader->nome ?>" <?= isSelect($leader->nome, $conta->lider_projeto) ?>>
                        <?= $leader->nome ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3">
            <label for="inputVagao" class="form-label">VAGÃO</label>
            <input type="text" class="form-control form-control-sm" id="inputSfp" name="sfp" value="<?= $vagoes ?>" disabled>

        </div>

        <div class="col-md-2">
            <label for="inputLote" class="form-label">LOTE</label>
            <select class="form-select form-select-sm" id="selectLote" name="lote">
                <option selected disabled value="">Selecione o lote...</option>
                <?php foreach ($lotes as $lote) : ?>
                    <option value="<?= $lote->lote ?>">
                        <?= $lote->lote ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>


    <div class="buttonsDiv">
        <button type="submit" class="btn btn-company">Registrar</button>
        <a class="btn btn-secondary" id="cancelForm" onclick="closeModal()">Cancelar</a>
    </div>
</form>

<?php $this->stop() ?>