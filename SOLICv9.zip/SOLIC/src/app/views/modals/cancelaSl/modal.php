<?php
$this->layout("templates/baseModal", [
    "headTitle" => "CANCELAMENTO DE SL",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
]);
?>
<?php $this->start('modalContent') ?>

<div class="text-center py-4">
    <div class="mb-3">
        <i class="bi bi-exclamation-triangle text-warning" style="font-size: 3rem;"></i>
    </div>

    <h4 class="fw-bold text-dark">CANCELAMENTO DE SL!</h4>
</div>

<div class="card-footer bg-white p-3">
    <form action="<?= route('dispositivos.validacao.store', ['ref' => $ref]) ?>" method="POST">
        <input type="hidden" name="ref" value="<?= $ref ?>">
        <input type="hidden" name="usuario" value="<?= $_SESSION['usuarioNome'] ?? 'Usuário não logado' ?>">

        <label for="mensagem" class="form-label fw-bold mb-1 fs-7">
            CONSIDERAÇÕES <span class="text-danger">*</span>
        </label>

        <div class="input-group">
            <textarea name="mensagem" class="form-control" rows="1" placeholder="Digite o motivo do cancelamento..." style="resize: none; border-radius: 0.375rem 0 0 0.375rem;" id="mensagem" required></textarea>
        </div>
        <div class="modal-footer d-flex justify-content-center gap-2 border-0 pt-4">
            <button type="submit" class="btn btn-warning" name="situacao" value="cancelar">
                CANCELAR SOLICITAÇÃO
            </button>

            <button type="button" onclick="closeModal()" class="btn btn-secondary ">
                FECHAR
            </button>
        </div>
    </form>
</div>

<?php $this->stop() ?>