<?php
$this->layout("templates/baseModal", [
    "headTitle" => "LIBERAÇÃO DE SL",
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$resumo      = $resumo ?? ['total' => 0, 'liquidados' => 0, 'pendentes' => 0];
$possuiItens = $possuiItens ?? false;
$jaLiberada  = $jaLiberada ?? false;
?>

<?php $this->start('modalContent') ?>

<div class="text-center pb-3">
    <div class="mb-2">
        <i class="bi bi-check2-circle text-success" style="font-size: 2.5rem;"></i>
    </div>

    <h5 class="fw-bold text-dark mb-1">Liberar a SL<?= $h($ref) ?>?</h5>

    <p class="text-muted fs-7 mb-0">
        A liberação muda o status para <strong>OK</strong> e registra a sua
        consideração no histórico da solicitação.
    </p>
</div>

<?php if ($jaLiberada) : ?>

    <div class="alert alert-warning fs-7 mb-0" role="alert">
        <i class="bi bi-exclamation-triangle me-1"></i>
        Esta SL já está com a liberação em <strong>OK</strong>.
    </div>

    <div class="modal-footer d-flex justify-content-center border-0 pt-4">
        <button type="button" onclick="closeModal()" class="btn btn-secondary">FECHAR</button>
    </div>

<?php else : ?>

    <?php /* Roteamento da próxima etapa — deixa explícito para quem libera */ ?>
    <?php if ($possuiItens) : ?>
        <div class="alert alert-info fs-7 d-flex align-items-start gap-2" role="alert">
            <i class="bi bi-cart-check mt-1"></i>
            <div>
                Esta SL tem <strong><?= (int) $resumo['total'] ?> item(ns) comprado(s)/siderúrgico(s)</strong>.
                Ao liberar, ela vai para <strong>AQUISIÇÃO</strong>, onde o comprador
                informa o N° OC e o pedido de cada item.
            </div>
        </div>
    <?php else : ?>
        <div class="alert alert-secondary fs-7 d-flex align-items-start gap-2" role="alert">
            <i class="bi bi-box-seam mt-1"></i>
            <div>
                Esta SL <strong>não tem itens comprados</strong>. A etapa de aquisição
                será concluída automaticamente e a SL segue para o <strong>CORTE</strong>.
            </div>
        </div>
    <?php endif; ?>

    <form id="formLiberacaoSl" data-ref="<?= (int) $ref ?>">
        <input type="hidden" name="ref" value="<?= (int) $ref ?>">

        <label for="mensagemLiberacao" class="form-label fw-bold mb-1 fs-7">
            CONSIDERAÇÕES <span class="text-danger">*</span>
        </label>

        <textarea
            name="mensagem"
            id="mensagemLiberacao"
            class="form-control"
            rows="3"
            style="resize: none;"
            placeholder="Descreva a liberação (vai para o histórico da SL)..."
            required
            maxlength="1000"
        ></textarea>

        <div class="form-text fs-8">
            O texto acima é publicado no histórico de interações da SL.
        </div>

        <div class="modal-footer d-flex justify-content-center gap-2 border-0 pt-4">
            <button type="submit" class="btn btn-success" id="btnConfirmarLiberacao">
                <i class="bi bi-check-lg me-1"></i> CONFIRMAR LIBERAÇÃO
            </button>

            <button type="button" onclick="closeModal()" class="btn btn-secondary">
                FECHAR
            </button>
        </div>
    </form>

<?php endif; ?>

<?php $this->stop() ?>
