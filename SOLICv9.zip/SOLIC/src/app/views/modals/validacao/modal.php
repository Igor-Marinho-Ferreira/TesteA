<?php
$this->layout("templates/baseModal", [
    "headTitle" => "Confirmação de validação",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
]);
?>
<?php $this->start('modalContent') ?>

<div class="text-center py-4">
    <div class="mb-3">
        <i class="bi bi-exclamation-triangle text-warning" style="font-size: 3rem;"></i>
    </div>

    <h4 class="fw-bold text-dark">VALIDAÇÃO DE SL!</h4>
</div>
<!-- 
é melhor eu ter uma rota salvando a mensagem direto
ou é melhor eu ter a rota para salvar a validação e ter toda a regra, e logo após pegar a mensagem e salvar? -->
<div class="card-footer bg-white p-3">
    <form action="<?= route('dispositivos.validacao.store', ['ref' => $ref]) ?>" method="POST">
        <input type="hidden" name="ref" value="<?= $ref ?>">
        <input type="hidden" name="usuario" value="<?= $_SESSION['usuarioNome'] ?? 'Usuário não logado' ?>">

        <label for="mensagem" class="form-label fw-bold mb-1 fs-7">
            CONSIDERAÇÕES <span class="text-danger">*</span>
        </label>

        <div class="input-group">
            <textarea name="mensagem" class="form-control" rows="1" placeholder="Digite as considerações da validação..." style="resize: none; border-radius: 0.375rem 0 0 0.375rem;" id="mensagem" required></textarea>
        </div>
        <div class="modal-footer d-flex justify-content-center gap-2 border-0 pt-4">
            <button type="submit" class="btn btn-success" name="situacao" value="aprovar" >
                APROVAR VALIDAÇÃO
            </button>

            <button type="submit" class="btn btn-danger" name="situacao" value="rejeitar" >
                REJEITAR VALIDAÇÃO
            </button>
            <button type="button" onclick="closeModal()" class="btn btn-secondary " >
                FECHAR
            </button>
        </div>
    </form>
</div>

<?php $this->stop() ?>