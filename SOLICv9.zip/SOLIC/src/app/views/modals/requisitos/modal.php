<?php
$this->layout("templates/baseModal", [
    "headTitle" => "REQUISITOS",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
]);
?>

<?php $this->start('modalContent') ?>

<?php
$requisitosFiltrados = array_filter((array)$requisitos, function ($item) {
    return isset($item->requisito) && mb_strlen(trim($item->requisito)) > 0;
});
?>

<div class="container py-3">
    <div class="row g-3">
        <?php if (empty($requisitosFiltrados)) : ?>
            <div class="col-12 text-center py-4">
                <p class="text-muted italic">Nenhum requisito encontrado.</p>
            </div>
        <?php else : ?>
            <?php foreach ($requisitosFiltrados as $requisito) : ?>
                <div class="col-12">
                    <div class="card border-0 border-start border-primary border-4 shadow-sm">
                        <div class="card-body py-3">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1 ms-2">
                                    <h6 class="mb-1 text-dark fw-bold" style="font-size: 0.85rem; letter-spacing: 0.5px; opacity: 0.7;">
                                        REQUISITO
                                    </h6>
                                    <p class="mb-0 text-secondary" style="font-size: 1rem; line-height: 1.4;">
                                        <?= htmlspecialchars($requisito->requisito) ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<div class="modal-footer d-flex justify-content-center gap-2 border-0 pb-4">
    <button type="button" onclick="closeModal(true)" class="btn btn-outline-danger px-4" data-bs-dismiss="modal">
        Fechar
    </button>
</div>

<?php $this->stop() ?>