<?php
$this->layout("templates/baseModal", [
  "headTitle" => "Editar estágio",
  "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
]);
?>
<?php $this->start('modalContent') ?>


    <form method="POST" action="<?= route('parametrizacao.estagios.update') ?>" id="formUpdateEstagio">
        <input type="hidden" class="form-control form-control-sm" id="inputId" name="id"
            value="<?= $estagio->id ?>" readonly>
        <div class="row mb-3">
            <div class="col-md-12">
                <label for="estagio" class="form-label">Estágio <span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control form-control-sm" id="estagio" name="estagio"
                    value="<?= $estagio->estagio ?>">
            </div>
        </div>



        <div class="buttonsDiv d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-company" onclick="loading('show')">Registrar</button>
            <a class="btn btn-secondary" id="cancelForm" onclick="closeModal()">Cancelar</a>
        </div>
    </form>



</div>
<?php $this->stop() ?>


