<?php
$this->layout("templates/baseModal", [
  "headTitle" => "Deletar usuário",
]);
?>

<?php $this->start('modalContent') ?>

<script src="<?= path()->js("/init.js?t={$t}"); ?>"></script>
<div id="myAppModal" >

        <div class="d-flex flex-column gap-3 mt-4 align-items-center">
            

            <h4 class="mb-0">Você está prestes a deletar o usuário <strong><?= $usuario->matricula?></strong> </h4>
            <h4 class="mb-0">Você tem certeza? </h4>

            <div class="d-flex gap-2 mt-3">

                <a href="<?= route('parametrizacao.usuario.delete', ['id' => $usuario->id]) ?>" id="btnDelete" class="btn btn-danger">
                    Confirmar
                </a>

                <button type="button" class="btn btn-secondary"  onclick="closeModal()">
                    Cancelar
                </button>
            </div>

        </div>

    </div>
</div>

<?php $this->stop() ?>