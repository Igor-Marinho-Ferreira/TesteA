<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.industrial.lista"),
    "webTitle"  => "Dispositivos - Industrial",
    "cardTitle" => "SOLICITAÇÃO DE PROJETO DE DISPOSITIVOS - INDUSTRIAL",
    "styles"    => [
        path()->css("desenvolvimento.css")
    ],
    "js" => [
        path()->js("desenvolvimentoProj.js"),
        // Depois de desenvolvimentoProj.js: embrulha gerenciarMudancaStatus
        path()->js("liberacaoAquisicao.js"),
        path()->js("industrialForm.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$formatarDataHora = function ($data) {
    if (empty($data) || $data === '0000-00-00 00:00:00') {
        return '--';
    }
    try {
        return (new DateTime($data))->format('d/m/Y H:i');
    } catch (Throwable $e) {
        return '--';
    }
};

$formatarData = function ($data) {
    if (empty($data) || $data === '0000-00-00' || $data === '0000-00-00 00:00:00') {
        return '--';
    }
    try {
        return (new DateTime($data))->format('d/m/Y');
    } catch (Throwable $e) {
        return '--';
    }
};

// Valor para <input type="date"> (YYYY-MM-DD) ou vazio
$dataParaInput = function ($data) {
    if (empty($data) || $data === '0000-00-00' || $data === '0000-00-00 00:00:00') {
        return '';
    }
    try {
        return (new DateTime($data))->format('Y-m-d');
    } catch (Throwable $e) {
        return '';
    }
};

$formatarBytes = function ($bytes) {
    $bytes = (int) ($bytes ?? 0);
    if ($bytes <= 0) {
        return '--';
    }
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2, ',', '.') . ' GB';
    }
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2, ',', '.') . ' MB';
    }
    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 2, ',', '.') . ' KB';
    }
    return $bytes . ' bytes';
};

$temposEtapa = $temposEtapa ?? [];
$slLiberada  = $slLiberada ?? false;
$slCancelada = $slCancelada ?? false;

// 10ª rodada — contexto de anexos (SÓ LEITURA; a automação é quem sobe)
$imagemProjeto     = $imagemProjeto ?? null;
$desenhosPdf       = $desenhosPdf ?? [];
$pacotesDxf        = $pacotesDxf ?? [];
$txtItensComprados = $txtItensComprados ?? [];
$cargasMap         = $cargasMap ?? [];

// 8ª rodada — Liberação + Aquisição/OC passaram para a Industrial
$podeLiberar         = $podeLiberar ?? false;
$itensComprados      = $itensComprados ?? [];
$resumoAquisicao     = $resumoAquisicao ?? ['total' => 0, 'liquidados' => 0, 'pendentes' => 0];
$aquisicaoHabilitada = $aquisicaoHabilitada ?? false;
$podeBypassAquisicao = $podeBypassAquisicao ?? false;

// Industrial só edita os campos com a SL liberada e não cancelada
$camposEditaveis = $slLiberada && !$slCancelada;

// Nome completo: a view roda dentro de um método do Plates, então "use" aqui
// seria erro de parse.
$formatarDuracao = function ($segundos) {
    return \src\support\Cronometro::formatar($segundos);
};
?>

<?php /* ------ CABEÇALHO / CONTEXTO (mesmo layout da automação — SÓ LEITURA) ------ */ ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body mb-3.5">
        <div class="row header-infos">
            <div class="col-md-7">
                <div class="row mb-1">
                    <div class="col-md-12">
                        <label class="form-label fs-7 fw-bold d-block mb-1">PROJETO:</label>

                        <?php /* Cartão do Z — só leitura (a automação é quem associa/gera) */ ?>
                        <div class="card shadow-sm p-3 mb-3">
                            <div class="row align-items-end g-2">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold small text-muted">CÓD. Z</label>
                                    <div class="input-group">
                                        <span class="input-group-text fw-bold text-primary bg-light">
                                            <i class="fas fa-project-diagram me-1"></i>Z
                                        </span>
                                        <input type="text" class="form-control"
                                               value="<?= $h(ltrim((string) ($z_info->cod_z ?? $solicitacao->cod_z ?? ''), 'zZ')) ?>"
                                               readonly>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <label class="form-label small text-muted">REV</label>
                                    <input type="text" class="form-control text-center px-1"
                                           value="<?= $h($z_info->qtdRev ?? '0') ?>" readonly>
                                </div>

                                <?php if (is_object($z_info) && isset($z_info->descricao)) : ?>
                                    <div class="col-md-6 border-start ps-3">
                                        <label class="form-label text-muted small d-block mb-1">DESCRIÇÃO DO PROJETO</label>
                                        <span class="text-secondary fw-bold d-block" style="line-height: 1.2;">
                                            <?= $h($z_info->descricao) ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="d-flex align-items-center my-3">
                            <hr class="flex-grow-1 text-muted opacity-25">
                            <span class="mx-3 text-muted fw-bold small">CONSULTA</span>
                            <hr class="flex-grow-1 text-muted opacity-25">
                        </div>

                        <div class="row g-2 align-items-stretch">
                            <div class="col-md-6">
                                <button type="button" class="btn btn-primary shadow-sm w-100 py-2 h-100"
                                        onclick="openModal(<?= (int) $solicitacao->ref ?>, 'requisitos')">
                                    <i class="fas fa-list-check me-1"></i> Requisitos
                                </button>
                            </div>
                            <div class="col-md-6">
                                <button type="button" class="btn btn-primary shadow-sm w-100 py-2 h-100"
                                        onclick="openModal(<?= (int) $solicitacao->ref ?>, 'anexos')">
                                    <i class="fas fa-paperclip me-1"></i> Ver anexos
                                </button>
                            </div>
                            <div class="col-12">
                                <small class="text-muted fs-8">
                                    <i class="bi bi-info-circle me-1"></i>
                                    O envio de arquivos é feito pela automação. Aqui é apenas consulta.
                                </small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4.5">
                    <div class="col-md-10">
                        <label class="form-label fs-7 fw-bold d-block mb-2 border-bottom pb-1">DADOS DA SOLICITAÇÃO:</label>
                        <div class="mb-5">
                            <span class="fs-5 fw-bold text-dark">SL<?= $h($solicitacao->ref) ?></span>
                            <span class="fs-6 text-secondary ms-2">
                                <?= (is_object($solicitacao) && isset($solicitacao->descricao)) ? ' | ' . $h($solicitacao->descricao) : '' ?>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="row g-3 bg-light rounded p-1 mx-0">
                    <div class="col-md-4 col-lg-2">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Data:</label>
                        <span class="fs-7 text-dark"><?= $formatarData($solicitacao->data_solicitacao ?? null) ?></span>
                    </div>

                    <div class="col-md-8 col-lg-3">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Solicitante:</label>
                        <span class="fs-7 text-dark text-truncate d-block" title="<?= $h($solicitacao->solicitante) ?>">
                            <?= strtoupper($h($solicitacao->solicitante)) ?>
                        </span>
                    </div>

                    <div class="col-md-4 col-lg-2">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Estágio:</label>
                        <span class="fs-7 text-dark"><?= strtoupper($h($solicitacao->aplicacao)) ?></span>
                    </div>

                    <div class="col-md-2 col-lg-1">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Vagão:</label>
                        <span class="fs-7 text-dark"><?= strtoupper($h($solicitacao->vagao)) ?></span>
                    </div>

                    <div class="col-md-2 col-lg-1">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Lote:</label>
                        <span class="fs-7 text-dark"><?= strtoupper($h($solicitacao->lote)) ?></span>
                    </div>

                    <div class="col-md-12 col-lg-3">
                        <div class="d-flex align-items-start gap-4">
                            <div>
                                <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Classificação:</label>
                                <span class="fs-7 text-dark text-truncate d-block">
                                    <?= strtoupper($h($solicitacao->classe)) ?>
                                </span>
                            </div>

                            <?php if (!empty($solicitacao->n_safety_walk)) : ?>
                                <div class="border-start ps-3">
                                    <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-danger">N° Safety Walk</label>
                                    <span class="fs-7 text-muted d-block">
                                        <?= strtoupper($h($solicitacao->n_safety_walk)) ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <?php /* VISUALIZAÇÃO — imagem: ver/baixar (sem inserir/alterar) */ ?>
            <div class="col-md-3 d-flex flex-column align-items-center justify-content-center border-start bg-white py-3">
                <label class="form-label small fw-bold text-muted mb-3">VISUALIZAÇÃO</label>

                <div class="imgProj w-100 text-center px-2">
                    <?php if (!empty($imagemProjeto)) : ?>
                        <a href="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $imagemProjeto->id]) ?>"
                           target="_blank" title="Abrir imagem do projeto">
                            <img src="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $imagemProjeto->id]) ?>"
                                 class="img-fluid rounded shadow-sm border" alt="Imagem do Projeto"
                                 style="max-height: 180px; object-fit: contain;"
                                 onerror="this.src='https://placehold.co/200x150?text=Sem+Imagem'">
                        </a>
                        <div class="mt-2 w-100">
                            <a href="<?= route('dispositivos.desenvolvimento.arquivo.download', ['id' => $imagemProjeto->id]) ?>"
                               class="btn btn-sm btn-outline-primary w-100 text-truncate"
                               title="<?= $h($imagemProjeto->nome_original ?? '') ?>">
                                <i class="bi bi-download me-1"></i> Baixar imagem
                            </a>
                        </div>
                    <?php else : ?>
                        <img src="https://placehold.co/200x150?text=Sem+Imagem"
                             class="img-fluid rounded shadow-sm border" alt="Sem Imagem"
                             style="max-height: 180px; object-fit: contain;">
                    <?php endif; ?>
                </div>
            </div>

            <?php /* DOCUMENTAÇÃO — PDFs: ver/baixar (sem adicionar) */ ?>
            <div class="col-md-2 d-flex flex-column border-start bg-white py-3">
                <label class="form-label small fw-bold text-muted mb-2 text-center">DOCUMENTAÇÃO</label>

                <div class="w-100 px-2">
                    <?php if (empty($desenhosPdf)) : ?>
                        <div class="text-center text-muted small py-3">
                            <i class="fas fa-folder-open fa-2x mb-2 d-block"></i>
                            Nenhum PDF.
                        </div>
                    <?php else : ?>
                        <div class="border rounded bg-light p-2 mb-2" style="max-height: 180px; overflow-y: auto;">
                            <?php foreach ($desenhosPdf as $index => $desenhoPdf) : ?>
                                <a href="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $desenhoPdf->id]) ?>"
                                   target="_blank"
                                   class="d-block bg-white border rounded px-2 py-1 mb-1 text-decoration-none text-dark small text-truncate"
                                   title="<?= $h($desenhoPdf->nome_original ?? '') ?>">
                                    <i class="fas fa-file-pdf text-danger me-1"></i>
                                    <?= $h($desenhoPdf->nome_original ?? 'PDF ' . ($index + 1)) ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /* ------------------------ BARRA DE PROGRESSO ------------------------ */ ?>
<div class="barra-progresso-container">
    <?php
    $class_map = [
        'OK'           => 'status-ok',
        'FINALIZADO'   => 'status-ok',
        'EM ANDAMENTO' => 'status-alerta',
        'ANDAMENTO'    => 'status-alerta',
        'MODELO'       => 'status-alerta',
        'PENDENTE'     => 'status-espera',
        'PARADO'       => 'status-espera',
        'CANCELADO'    => 'status-espera',
        '[VALIDAÇÃO]'  => 'status-alerta',
        'REVISAR'      => 'status-revisao',
        'BACKLOG'      => 'status-backlog',
        'AGUARDANDO'   => 'status-backlog',
        'PAUSADO'      => 'status-pausado',
        'TERCEIRIZADO' => 'status-pausado',
    ];

    foreach ($etapas as $etapa) :
        $valorAtual = strtoupper(trim((string) $etapa['valor']));
        $classeAtual = $class_map[$valorAtual] ?? 'status-espera';

        // Etapa terminal também trava (mesma regra da automação)
        $isTerminal  = in_array($valorAtual, ['CANCELADO'], true);
        $isDisabled  = !$etapa['edit'] || $isTerminal;
    ?>
        <div class="step-card">
            <label class="step-label text-truncate"><?= $h($etapa['label']) ?></label>

            <?php if (empty($etapa['opcoes'])) : ?>
                <?php /* Etapas da automação: só leitura aqui */ ?>
                <div class="form-select form-select-sm select-status <?= $classeAtual ?>"
                     style="pointer-events:none; opacity:.85; background-image:none;">
                    <?= $h($etapa['valor'] ?: '--') ?>
                </div>
            <?php else : ?>
                <select
                    class="form-select form-select-sm select-status <?= $classeAtual ?>"
                    data-id="<?= $h($solicitacao->ref) ?>"
                    data-coluna="<?= $h($etapa['coluna']) ?>"
                    onchange="gerenciarMudancaStatus(this), loading('show')"
                    <?= $isDisabled ? 'disabled' : '' ?>
                    title="<?= $slLiberada ? '' : 'Disponível somente após a liberação da SL' ?>"
                >
                    <?php if (!in_array($etapa['valor'], $etapa['opcoes'])) : ?>
                        <option value="<?= $h($etapa['valor']) ?>" selected><?= $h($etapa['valor']) ?></option>
                    <?php endif; ?>

                    <?php foreach ($etapa['opcoes'] as $opcao) : ?>
                        <option value="<?= $h($opcao) ?>" <?= ($valorAtual === strtoupper($opcao)) ? 'selected' : '' ?>>
                            <?= $h($opcao) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>

            <?php /* Cronômetro da etapa */ ?>
            <?php if (isset($temposEtapa[$etapa['coluna']])) : ?>
                <?php $tempoEt = $temposEtapa[$etapa['coluna']]; ?>
                <small class="d-block mt-1" style="font-size: 0.65rem;"
                       title="<?= !empty($tempoEt['derivado'])
                                    ? 'Tempo corrido entre início e fim da etapa'
                                    : 'Tempo somando apenas os períodos em andamento/terceirizado' ?>">
                    <i class="bi bi-stopwatch<?= !empty($tempoEt['rodando']) ? '-fill text-success' : ' text-muted' ?>"></i>
                    <span class="<?= !empty($tempoEt['rodando']) ? 'text-success fw-semibold' : 'text-muted' ?>">
                        <?= $h($formatarDuracao($tempoEt['segundos'])) ?>
                    </span>
                    <?= !empty($tempoEt['rodando']) ? '<span class="text-success">•</span>' : '' ?>
                </small>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<?php /* ------ PROJETO / PROJETISTAS (mesmo layout da automação — SÓ LEITURA) ------ */ ?>
<div class="d-flex align-items-center py-3">
    <div class="flex-grow-1 border-top"></div>
    <span class="mx-3 fw-bold text-uppercase fs-7">PROJETO</span>
    <div class="flex-grow-1 border-top"></div>
</div>

<div class="row">
    <div class="col-md-4">
        <h6 class="fw-bold text-muted border-bottom pb-2 mb-3">Conceito/Modelo</h6>

        <div class="mb-3">
            <label class="form-label fs-7 fw-bold d-block mb-0">Projetista:</label>
            <span class="text-uppercase"><?= $h($solicitacao->conceito_proj ?: 'Não alocado') ?></span>
        </div>

        <div class="row text-center pt-3">
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Início</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->conceito_inicio ?? null)) ?></span>
            </div>
            <div class="col-4 border-start border-end">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Fim</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->conceito_fim ?? null)) ?></span>
            </div>
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Status</h6>
                <span class="fs-8"><?= $h($solicitacao->conceito_status) ?></span>
            </div>
        </div>
    </div>

    <div class="col-md-4 border-start">
        <h6 class="fw-bold text-muted border-bottom pb-2 mb-3">Detalhamento</h6>

        <div class="mb-3">
            <label class="form-label fs-7 fw-bold d-block mb-0">Projetista:</label>
            <span class="text-uppercase"><?= $h($solicitacao->detalhamento_proj ?: 'Não alocado') ?></span>
        </div>

        <div class="row text-center pt-3">
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Início</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->detalhamento_inicio ?? null)) ?></span>
            </div>
            <div class="col-4 border-start border-end">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Fim</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->detalhamento_fim ?? null)) ?></span>
            </div>
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Status</h6>
                <span class="fs-8"><?= $h($solicitacao->detalhamento_status) ?></span>
            </div>
        </div>
    </div>

    <div class="col-md-4 border-start">
        <h6 class="fw-bold text-muted border-bottom pb-2 mb-3">Execução</h6>

        <div class="mb-3">
            <label class="form-label fs-7 fw-bold d-block mb-0">Executor:</label>
            <span class="text-uppercase"><?= $h($solicitacao->executor_proj ?: 'Não alocado') ?></span>
        </div>

        <div class="row text-center pt-3">
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Início</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->exec_data ?? null)) ?></span>
            </div>
            <div class="col-4 border-start border-end">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Fim</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->exec_fim ?? null)) ?></span>
            </div>
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Status</h6>
                <span class="fs-8"><?= $h($solicitacao->exec_status) ?></span>
            </div>
        </div>
    </div>
</div>

<div class="d-flex align-items-center py-3">
    <div class="flex-grow-1 border-top"></div>
    <span class="mx-3 fw-bold text-uppercase fs-7">DADOS DO INDUSTRIAL</span>
    <div class="flex-grow-1 border-top"></div>
</div>

<div class="row">
    <div class="col-lg-8">
        <?php /* -------------------- CAMPOS DO INDUSTRIAL -------------------- */ ?>
        <form id="formCamposIndustrial" data-ref="<?= (int) $solicitacao->ref ?>">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="n_pasta" class="form-label fs-7 fw-bold mb-1"># Pasta</label>
                    <input type="text" class="form-control form-control-sm" id="n_pasta" name="n_pasta"
                           value="<?= $h($solicitacao->n_pasta ?? '') ?>" maxlength="60"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-3">
                    <label for="data_entrega" class="form-label fs-7 fw-bold mb-1">Data de Entrega</label>
                    <input type="date" class="form-control form-control-sm" id="data_entrega" name="data_entrega"
                           value="<?= $h($dataParaInput($solicitacao->data_entrega ?? null)) ?>"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-3">
                    <label for="equipeei" class="form-label fs-7 fw-bold mb-1">Equipe</label>
                    <input type="text" class="form-control form-control-sm" id="equipeei" name="equipeei"
                           value="<?= $h($solicitacao->equipeei ?? '') ?>" maxlength="60"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-3">
                    <label for="setor_pendencia" class="form-label fs-7 fw-bold mb-1">Setor</label>
                    <input type="text" class="form-control form-control-sm" id="setor_pendencia" name="setor_pendencia"
                           value="<?= $h($solicitacao->setor_pendencia ?? '') ?>" maxlength="60"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-4">
                    <label for="natureza" class="form-label fs-7 fw-bold mb-1">Natureza</label>
                    <input type="text" class="form-control form-control-sm" id="natureza" name="natureza"
                           value="<?= $h($solicitacao->natureza ?? '') ?>" maxlength="120"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>

                <div class="col-md-8">
                    <label for="descricaoservico" class="form-label fs-7 fw-bold mb-1">Descrição do Serviço</label>
                    <input type="text" class="form-control form-control-sm" id="descricaoservico" name="descricaoservico"
                           value="<?= $h($solicitacao->descricaoservico ?? '') ?>" maxlength="255"
                           <?= $camposEditaveis ? '' : 'disabled' ?>>
                </div>
            </div>

            <?php if ($camposEditaveis) : ?>
                <div class="d-flex justify-content-end align-items-center gap-2 mt-3">
                    <small class="text-muted fs-8" id="statusSalvarIndustrial"></small>
                    <button type="submit" class="btn btn-sm btn-primary" id="btnSalvarIndustrial">
                        <i class="bi bi-save me-1"></i> Salvar dados
                    </button>
                </div>
            <?php else : ?>
                <div class="alert alert-secondary fs-7 mt-3 mb-0">
                    <?= $slCancelada
                        ? 'SL cancelada — os campos estão bloqueados.'
                        : 'A SL ainda não foi liberada pela automação.' ?>
                </div>
            <?php endif; ?>
        </form>

        <?php /* Datas das etapas do industrial */ ?>
        <div class="row text-center pt-4">
            <div class="col-6 col-md-3">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Corte — Início</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->corte_inicio ?? null)) ?></span>
            </div>
            <div class="col-6 col-md-3 border-start">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Corte — Fim</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->corte_fim ?? null)) ?></span>
            </div>
            <div class="col-6 col-md-3 border-start">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Exec. — Início</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->exec_inicio ?? null)) ?></span>
            </div>
            <div class="col-6 col-md-3 border-start">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Exec. — Fim</h6>
                <span class="fs-7"><?= $h($formatarDataHora($solicitacao->exec_fim ?? null)) ?></span>
            </div>
        </div>
    </div>

    <?php /* ---------------------------- CHATBOX ---------------------------- */ ?>
    <div class="col-lg-4 container-history">
        <div class="card shadow-sm card-history">
            <div class="card-header bg-light py-2">
                <h6 class="mb-0 fw-bold text-uppercase fs-7 text-muted">
                    <i class="bi bi-clock-history me-2"></i>Histórico de Interações
                </h6>
            </div>

            <div class="card-body p-0" style="max-height: 400px; overflow-y: auto;">
                <div class="list-group list-group-flush shadow-none">
                    <?php foreach ($interacoes as $interacao) : ?>
                        <?php $data = new DateTime($interacao->created_at); ?>
                        <div class="list-group-item border-0 border-bottom p-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="fw-bold text-primary fs-7">
                                    <i class="bi bi-person-fill"></i> <?= strtoupper($h($interacao->usuario)) ?>
                                </span>
                                <small class="text-muted fs-8"><?= $data->format('d.m.Y - H:i') ?></small>
                            </div>
                            <div class="ps-3 border-start border-2 ms-1">
                                <p class="mb-1 text-dark fs-7">- <?= $h($interacao->mensagem) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (empty($interacoes)) : ?>
                        <div class="list-group-item border-0 p-3 text-muted">Nenhuma interação registrada.</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card-footer bg-white p-3">
                <form action="<?= route('dispositivos.historico.store', ['ref' => $solicitacao->ref, 'tipo' => 'industrial']) ?>" method="POST">
                    <input type="hidden" name="ref" value="<?= $h($solicitacao->ref) ?>">
                    <input type="hidden" name="usuario" value="<?= $h($_SESSION['usuarioNome'] ?? '') ?>">

                    <div class="input-group">
                        <textarea name="mensagem" class="form-control fs-7" rows="2"
                                  placeholder="Digite uma nova interação..." style="resize: none;" required></textarea>
                        <button class="btn btn-primary" type="submit" title="Enviar">
                            <i class="bi bi-send-fill"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php /* -------------------- PACOTES DE DXF PARA CORTE (SÓ LEITURA — 10ª rodada) -------------------- */ ?>
<div class="position-relative d-flex align-items-center py-3 pt-4">
    <div class="flex-grow-1 border-top"></div>
    <span class="mx-3 fw-bold text-uppercase fs-7">PACOTES DE DXFs PARA CORTE</span>
    <div class="flex-grow-1 border-top"></div>
</div>

<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr>
                <th class="text-center">CÓDIGO</th>
                <th class="text-center">DESCRIÇÃO</th>
                <th class="text-center">PRIORIDADE</th>
                <th class="text-center">STATUS</th>
                <th class="text-center">Ações</th>
            </tr>
        </thead>
        <tbody class="align-middle text-center fs-7">
            <?php if (!empty($pacotesDxf)) : ?>
                <?php foreach ($pacotesDxf as $index => $dxf) : ?>
                    <?php
                    $carga = $cargasMap[$dxf->carga_id] ?? null;
                    $prioridade = $carga->prioridade ?? '--';
                    $codigoArquivo = !empty($dxf->codigo)
                        ? $dxf->codigo
                        : 'DXF' . str_pad((string) ($index + 1), 3, '0', STR_PAD_LEFT);
                    ?>
                    <tr>
                        <td><span class="fw-bold text-primary"><?= $h($codigoArquivo) ?></span></td>
                        <td class="text-start">
                            <?= $h($dxf->nome_original ?? '--') ?>
                            <div class="text-muted small">
                                <?= $formatarBytes($dxf->tamanho_bytes ?? 0) ?> | <?= $h($formatarDataHora($dxf->created_at ?? null)) ?>
                            </div>
                        </td>
                        <td><?= $h($prioridade) ?></td>
                        <td><span class="badge bg-success">Carregado</span></td>
                        <td>
                            <a href="<?= route('dispositivos.desenvolvimento.arquivo.download', ['id' => $dxf->id]) ?>"
                               class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-download me-1"></i> Baixar
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="5" class="text-muted py-4">Nenhum DXF adicionado até o momento.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if (!empty($txtItensComprados)) : ?>
    <div class="card border-0 shadow-sm mt-3">
        <div class="card-header bg-light py-2">
            <h6 class="mb-0 fw-bold text-uppercase fs-7 text-muted">TXTs de Itens Comprados</h6>
        </div>
        <div class="card-body p-2">
            <?php foreach ($txtItensComprados as $txt) : ?>
                <div class="d-flex justify-content-between align-items-center border-bottom py-2 gap-2">
                    <div class="small text-truncate">
                        <span title="<?= $h($txt->nome_original ?? '') ?>"><?= $h($txt->nome_original ?? '--') ?></span>
                        <div class="text-muted">
                            <?= $formatarBytes($txt->tamanho_bytes ?? 0) ?> | <?= $h($formatarDataHora($txt->created_at ?? null)) ?>
                        </div>
                    </div>
                    <a href="<?= route('dispositivos.desenvolvimento.arquivo.download', ['id' => $txt->id]) ?>"
                       class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-download me-1"></i> Baixar
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<?php /* -------------------- AQUISIÇÃO / ITENS COMPRADOS (8ª rodada) -------------------- */ ?>
<div class="position-relative d-flex align-items-center py-3 pt-4">
    <div class="flex-grow-1 border-top"></div>
    <span class="mx-3 fw-bold text-uppercase fs-7">ITENS COMPRADOS E AQUISIÇÃO</span>
    <div class="flex-grow-1 border-top"></div>
</div>

<?php if (!$slLiberada) : ?>
    <div class="alert alert-secondary fs-7">
        <i class="bi bi-info-circle me-1"></i>
        A aquisição abre após a liberação da SL.
    </div>
<?php endif; ?>

<?= $this->insert('desenvolvimento/aquisicaoPanel', [
    'solicitacao'         => $solicitacao,
    'itensComprados'      => $itensComprados,
    'resumoAquisicao'     => $resumoAquisicao,
    'aquisicaoHabilitada' => $aquisicaoHabilitada,
    'podeBypassAquisicao' => $podeBypassAquisicao,
    'editavel'            => $camposEditaveis,
]) ?>

<?php /* ---------------------------- AÇÕES ---------------------------- */ ?>
<div class="row mt-4">
    <div class="col-md-3">
        <?php if ($slCancelada) : ?>
            <button type="button" class="btn btn-outline-secondary btn-sm w-100" disabled>
                <i class="bi bi-x-circle me-1"></i> SL Cancelada
            </button>
        <?php elseif ($slLiberada) : ?>
            <button type="button" class="btn btn-warning btn-sm w-100"
                    title="Retorna a SL para revisão (liberação)"
                    onclick="abrirModalMotivo(<?= (int) $solicitacao->ref ?>, 'retornar')">
                <i class="bi bi-arrow-counterclockwise me-1"></i> Retornar SL
            </button>
        <?php elseif ($podeLiberar) : ?>
            <?php /* 8ª rodada — Liberar SL agora é da Industrial */ ?>
            <button type="button" class="btn btn-company btn-sm w-100"
                    id="btnLiberarSl"
                    title="Liberar a SL e registrar a consideração"
                    onclick="abrirModalLiberacao(<?= (int) $solicitacao->ref ?>)">
                Liberar SL
            </button>
        <?php else : ?>
            <button type="button" class="btn btn-secondary btn-sm w-100" disabled
                    title="Disponível após Conceito e Detalhamento estarem OK">
                <i class="bi bi-hourglass-split me-1"></i> Aguardando projeto
            </button>
        <?php endif; ?>
    </div>

    <div class="col-md-3">
        <a href="<?= route('dispositivos.industrial.lista') ?>" class="btn btn-secondary btn-sm w-100">
            <i class="bi bi-list me-1"></i> Voltar para a lista
        </a>
    </div>
</div>
