<?php
$this->layout("templates/base", [
    "backTo" => "http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/acompanhamento/",
    "webTitle" => "Dispositivos - Solicitação de projetos",
    "cardTitle" => "SISTEMA DE CONTROLE DE PROJETOS DE DISPOSITIVOS",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css',
        path()->css("desenvolvimento.css")
    ],
    "js" => [
        path()->js("listaProjetos.js"),
    ],
]);



?>


<!-- 

Arrumar descrição SL
Trazer itens que não estão trazendo - todos
Formatar datas 
Padronizar cores
Não está salvando conta_select

-->

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <div class="row align-items-center">
            <div class="col-md-6">
                <span class="fs-5 fw-bold text-dark">SL<?= $solicitacao->ref ?></span>
                <span class="fs-6 text-secondary ms-2">
                    <?= (is_object($solicitacao) && isset($solicitacao->descricao)) ? " | " . $solicitacao->descricao : "" ?>
                </span>

            </div>
            <div class="col-md-6 text-end">
                <button class="btn btn-primary btn-sm shadow-sm" onclick="openModal(<?= $solicitacao->ref ?>, 'requisitos')">Requisitos</button>
                <div class="btn-group shadow-sm">
                    <?php if ($solicitacao->detalhamento_status === '[VALIDAÇÃO]') : ?>
                        <button class="btn btn-warning btn-sm" onclick="openModal(<?= $solicitacao->ref ?>,'validacao')">Validar</button>
                    <?php else : ?>
                        <button class="btn btn-outline-warning btn-sm" disabled>Validar</button>
                    <?php endif; ?>
                    <button class="btn btn-outline-danger btn-sm" disabled>Tryout NOK</button>
                    <button class="btn btn-outline-success btn-sm" disabled>Tryout OK</button>
                    <?php if ($solicitacao->conceito_status === 'CANCELADO') : ?>
                        <button class="btn btn-outline-secondary btn-sm" disabled>Cancelar Solicitação</button>
                    <?php else : ?>
                        <button class="btn btn-secondary btn-sm" onclick="openModal(<?= $solicitacao->ref  ?>, 'cancelarSl')">Cancelar Solicitação</button>
                    <?php endif; ?>

                </div>
            </div>
        </div>

        <div class="row g-0 bg-light rounded p-3 mx-0 mt-3 border shadow-sm align-items-center">
            <div class="col-md-8">
                <div class="row g-2">
                    <div class="col-md-3">
                        <label class="form-label fs-9 fw-bold d-block mb-0 text-uppercase text-dark">Data Solicitação</label>
                        <span class="fs-7 text-muted"><?= (new DateTime($solicitacao->data_solicitacao))->format('d/m/Y') ?></span>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fs-9 fw-bold d-block mb-0 text-uppercase text-dark">Solicitante</label>
                        <span class="fs-7 text-muted text-truncate d-block" title="<?= $solicitacao->solicitante ?>"><?= strtoupper($solicitacao->solicitante) ?></span>
                    </div>
                    <div class="col-md-5 g-4">
                        <div class="d-flex flex-wrap">
                            <div class="me-5">
                                <label class="form-label fs-9 fw-bold d-block mb-0 text-uppercase text-dark">Classificação</label>
                                <span class="fs-7 text-muted"><?= strtoupper($solicitacao->classe) ?></span>
                            </div>

                            <?php if ($solicitacao->n_safety_walk) : ?>
                                <div>
                                    <label class="form-label fs-9 fw-bold d-block mb-0 text-uppercase text-danger">N° Safety Walk</label>
                                    <span class="fs-7 text-muted"><?= strtoupper($solicitacao->n_safety_walk) ?></span>
                                </div>
                            <?php endif ?>
                        </div>
                    </div>

                    <div class="col-md-3 pt-3">
                        <label class="form-label fs-9 fw-bold d-block mb-0 text-uppercase text-dark">Estágio</label>
                        <span class="fs-7 text-muted"><?= strtoupper($solicitacao->aplicacao) ?></span>
                    </div>
                    <div class="col-md-4 pt-3">
                        <label class="form-label fs-9 fw-bold d-block mb-0 text-uppercase text-dark">Vagão/Lote</label>
                        <span class="fs-7 text-muted"><?= strtoupper($solicitacao->vagao) ?> / <?= strtoupper($solicitacao->lote) ?></span>
                    </div>
                    <div class="col-md-4 ps-3 pt-3">
                        <label class="form-label fs-9 fw-bold d-block mb-0 text-primary text-uppercase">Nº SFP / Conta</label>
                        <span class="fs-6 fw-bold text-dark"><?= $solicitacao->conta ?></span>
                    </div>
                </div>
            </div>

            <div class="col-md-4 border-start ps-3">
                <div class="row g-2 text-center">
                    <div class="col-6">
                        <label class="fw-bold text-muted mb-1 d-block" style="font-size: 0.65rem;">VISUALIZAÇÃO 3D</label>
                        <div class="ratio ratio-16x9">
                            <img src="https://placehold.co/300x150?text=3D+Model" class="img-fluid rounded border shadow-sm object-fit-cover">
                        </div>
                    </div>
                    <div class="col-6">
                        <label class="fw-bold text-muted mb-1 d-block" style="font-size: 0.65rem;">DESENHOS PDF</label>
                        <div class="ratio ratio-16x9">
                            <img src="https://placehold.co/300x150?text=PDF" class="img-fluid rounded border shadow-sm object-fit-cover">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="d-flex align-items-center py-3">
        <div class="flex-grow-1 border-top border-2"></div>
        <span class="mx-3 fw-bold text-uppercase fs-7 text-secondary tracking-wider">
            <i class="fas fa-tasks me-2"></i>Andamento da Solicitação
        </span>
        <div class="flex-grow-1 border-top border-2"></div>
    </div>
</div>

<div class="barra-progresso-container mb-4">
    <?php
    $class_map = [
        'OK'           => 'status-ok',
        'FINALIZADO'   => 'status-ok',
        'EM ANDAMENTO' => 'status-alerta',
        'MODELO'       => 'status-alerta',
        'PENDENTE'     => 'status-espera',
        'CANCELADO'    => 'status-espera',
        '[VALIDAÇÃO]'  => 'status-alerta',
        'REVISAR'      => 'status-revisao',
        'BACKLOG'      => 'status-backlog',
        'PAUSADO'      => 'status-pausado'
    ];

    $etapas = [
        ['label' => 'Conceito',   'status' => $solicitacao->conceito_status],
        ['label' => 'Detalhe',   'status' => $solicitacao->detalhamento_status],
        ['label' => 'Liberação', 'status' => $solicitacao->liberacao_status],
        ['label' => 'Aquisição', 'status' => $solicitacao->aquisicao_status],
        ['label' => 'Corte',     'status' => $solicitacao->corte_status],
        ['label' => 'Execução',  'status' => $solicitacao->exec_status],
    ];

    foreach ($etapas as $etapa) :
        $status_atual = strtoupper($etapa['status']);
        $status_class = $class_map[$status_atual] ?? 'status-espera';
    ?>
        <div class="step-card">
            <label class="step-label text-truncate"><?= $etapa['label'] ?></label>
            <div class="select-status text-center py-1 fw-bold fs-8 rounded <?= $status_class ?>">
                <?= $etapa['status'] ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="container-fluid px-0">
    <div class="row g-4">

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h6 class="fw-bold text-muted border-bottom pb-2 mb-3 text-uppercase">Informações do Projeto</h6>
                    <div class="mb-4">
                        <p class="mb-1 fs-7"><strong>CÓDIGO Z:</strong> <span class="text-primary fw-bold"><?= $solicitacao->cod_z ?></span></p>
                        <p class="mb-1 fs-7"><strong>PROJETO/CONCEITO:</strong> <?= $solicitacao->conceito_proj ?></span></p>
                        <p class="mb-1 fs-7"><strong>DETALHAMENTO:</strong><?= $solicitacao->detalhamento_proj ?></span></p>
                    </div>

                    <div class="row text-center mb-4 p-3">
                        <div class="col-4">
                            <h6 class="fw-bold mb-0 small text-muted text-uppercase">Início</h6>
                            <span class="fs-7"><?= !empty($solicitacao->conceito_inicio) ? (new DateTime($solicitacao->conceito_inicio))->format('d/m/Y') : '--' ?></span>
                        </div>
                        <div class="col-4 border-start border-end">
                            <h6 class="fw-bold mb-0 small text-muted text-uppercase">Fim</h6>
                            <span class="fs-7"><?= !empty($solicitacao->conceito_fim) ? (new DateTime($solicitacao->conceito_fim))->format('d/m/Y') : '--' ?></span>
                        </div>
                        <div class="col-4">
                            <h6 class="fw-bold mb-0 small text-muted text-uppercase">Status</h6>
                            <span class="fs-8"><?= $solicitacao->liberacao_status ?></span>
                        </div>
                    </div>

                    <h6 class="fw-bold text-muted border-bottom pb-2 mb-3 text-uppercase">Pacotes de Corte</h6>
                    <table class="table table-sm table-hover border">
                        <thead class="table-dark fs-8">
                            <tr>
                                <th>CTRL</th>
                                <th>DESCRIÇÃO</th>
                                <th class="text-center">STATUS</th>
                            </tr>
                        </thead>
                        <tbody class="fs-8">
                            <tr>
                                <td colspan="3" class="text-center text-muted py-3">Nenhum pacote listado</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h6 class="fw-bold text-muted border-bottom pb-2 mb-3 text-uppercase">Execução</h6>
                    <div class="row mb-4">
                        <div class="col-12 mb-2">
                            <p class="mb-0 fs-7"><strong>Executor:</strong> <span class="text-muted small">Não alocado</span></p>
                        </div>
                        <div class="col-6"><label class="small text-muted d-block">Início</label><span class="fs-7">__/__/__</span></div>
                        <div class="col-6"><label class="small text-muted d-block">Fim</label><span class="fs-7">__/__/__</span></div>
                    </div>

                    <h6 class="fw-bold text-muted border-bottom pb-2 mb-3 text-uppercase">Ordens de Compra</h6>
                    <table class="table table-sm table-hover border">
                        <thead class="table-dark fs-8">
                            <tr>
                                <th>CÓDIGO</th>
                                <th class="text-center">REV</th>
                                <th class="text-center">STATUS</th>
                            </tr>
                        </thead>
                        <tbody class="fs-8">
                            <tr>
                                <td colspan="3" class="text-center text-muted py-3">Nenhuma OC encontrada</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-3 p-3">

            </div>

            <div class="card shadow-sm">
                <div class="card-header bg-light py-2">
                    <h6 class="mb-0 fw-bold text-uppercase fs-7 text-muted">
                        <i class="bi bi-clock-history me-2"></i>Histórico
                    </h6>
                </div>
                <div class="card-body p-0" style="max-height: 300px; overflow-y: auto;">
                    <div class="list-group list-group-flush">
                        <?php foreach ($interacoes as $interacao) :
                            $data = new DateTime($interacao->created_at);
                        ?>
                            <div class="list-group-item border-0 border-bottom p-2">
                                <div class="d-flex justify-content-between">
                                    <span class="fw-bold text-primary fs-8"><?= strtoupper($interacao->usuario) ?></span>
                                    <small class="text-muted fs-9"><?= $data->format('d/m H:i') ?></small>
                                </div>
                                <p class="mb-0 text-dark fs-8">- <?= $interacao->mensagem ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="card-footer bg-white p-2">
                    <form action="<?= route('dispositivos.historico.store', ['ref' => $solicitacao->ref, 'tipo' => 'solicitacao']) ?>" method="POST">
                        <div class="input-group input-group-sm">

                            <input type="hidden" name="ref" value="<?= $solicitacao->ref ?>">

                            <input type="hidden" name="usuario" value="<?= $_SESSION['usuarioNome'] ?>">
                            <textarea name="mensagem" class="form-control" rows="1" placeholder="Digite aqui..." style="resize: none;" required></textarea>
                            <button class="btn btn-primary" type="submit"><i class="bi bi-send"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4 mb-5 d-flex justify-content-center">
    <div class="col-md-3"><button class="btn btn-company btn-sm w-100 shadow-sm">Abrir BOM</button></div>
    <div class="col-md-3"><button class="btn btn-primary btn-sm w-100 shadow-sm" onclick="openModal(<?= $solicitacao->ref ?>, 'anexos')">Ver Anexo</button></div>

</div>