<?php
$this->layout("templates/base", [
    "backTo" => "http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/",
    "webTitle" => "Dispositivos - Solicitação de projetos",
    "cardTitle" => "SOLICITAÇÃO DE PROJETO DE DISPOSITIVOS",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css'
    ],
    "js" => [
        path()->js("solicitacao.js"),
    ],
]);
?>


<form method="POST" action="<?= route('dispositivos.solicitacao.store') ?>" id="formCadastroSolicitacao" enctype="multipart/form-data">
    <!-- <div class="row mb-3">
        <p>SL<?= $nSL ?></p>
    </div> -->
    <div class="row mb-3">
        <div class="col-md-8">
            <label for="descricao" class="form-label fs-7">SOLICITAÇÃO <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" id="descricao" name="descricao" placeholder="Descrição do projeto" required>
        </div>
        <div class="col-md-4">
            <label for="cod_z" class="form-label fs-7 ">CÓDIGO Z</label>
            <input type="text" class="form-control form-control-sm" id="cod_z" name="cod_z" placeholder="Digite o número do projeto" value="">
        </div>
    </div>
    <hr>

    <div class="row mb-3">
        <div class="col-md-8">
            <label for="solicitante" class="form-label fs-7">SOLICITANTE</label>
            <input type="text" class="form-control form-control-sm" name="solicitante" id="solicitante" value="<?= $solicitante ?>" readOnly>
        </div>
        <input type="hidden" class="form-control form-control-sm" id="inputRole" readOnly>
        <div class="col-md-2">
            <label for="data_solicitacao" class="form-label fs-7">SOLICITAÇÃO (DATA)</label>
            <input type="date" class="form-control form-control-sm" id="data_solicitacao" name="data_solicitacao" readOnly value="<?= $todayIs ?>">
        </div>
        <div class="col-md-2">
            <label for="data_necessidade" class="form-label fs-7">DATA NECESSIDADE <span class="text-danger">*</span></label>
            <input type="date" class="form-control form-control-sm" id="data_necessidade" name="data_necessidade" required>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-md-4">
            <label for="aplicacao" class="form-label fs-7">APLICAÇÃO/ESTÁGIO <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="aplicacao" name="aplicacao" required>
                <option value="" selected disabled hidden>Selecione...</option>
                <?php foreach ($estagios as $estagio) : ?>
                    <option value="<?= $estagio->estagio ?>"><?= $estagio->estagio ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label for="vagao" class="form-label fs-7">VAGÃO/LOCAL <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="vagao" name="vagao" required>
                <option value="" selected disabled hidden>Selecione...</option>
                <?php foreach ($vagoesInfos as $info) : ?>
                    <option value="<?= $info->vagao ?>"><?= $info->vagao ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label for="lote" class="form-label fs-7">LOTE/APLICAÇÃO <span class="text-danger">*</span></label>
            <select class="form-select form-select-sm" id="lote" disabled name="lote" required>
                <option value="" selected disabled hidden>Selecione...</option>
            </select>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-4">
            <label for="conta_select" class="form-label fs-7">N° SFP OU CONTA CONTÁBIL <span class="text-danger">*</span></label>

            <select class="form-select form-select-sm" id="conta_select" name="conta_select" disabled required>
                <option selected value="">Selecione...</option>
                <?php foreach ($contas as $conta) : ?>
                    <option value="<?= $conta ?>"><?= $conta ?></option>
                <?php endforeach; ?>
            </select>

            <input type="hidden" id="conta" name="conta" value="">
        </div>
        <div class="col-md-4">
            <label for="descricao_conta" class="form-label">DESCRIÇÃO DA CONTA</label>
            <input class="form-control form-control-sm" type="text" id="descricao_conta" name="descricao_conta" readOnly>
        </div>
    </div>
    <hr>

    <h3 class="mt-4 mb-3">CLASSIFICAÇÃO <span class="text-danger">*</span></h3>

    <div class="row mb-4">
        <div class="col-md-4 mb-2">
            <p class="fw-bold text-danger">SEGURANÇA</p>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioSeguranca1" value="Notificacao" required>
                <label class="form-check-label" for="radioSeguranca1">
                    Notificação de segurança
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioSeguranca2" value="Safety Walk">
                <label class="form-check-label" for="radioSeguranca2">
                    Safety Walk
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioSeguranca3" value="ATA CIPA">
                <label class="form-check-label" for="radioSeguranca3">
                    Ata da CIPA
                </label>
            </div>
            <div class="col-md-6 mt-3 d-none" id="inputSafetyWalk">
                <label for="n_safety_walk" class="form-label fs-7">N° AÇÃO SAFETY WALK <span class="text-danger">*</span></label>
                <input type="number" class="form-control form-control-sm" id="n_safety_walk" name="n_safety_walk">
            </div>
        </div>

        <div class="col-md-4">
            <p class="fw-bold">LINHAS DE PRODUÇÃO</p>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioProducao1" value="Projeto Linha" disabled>
                <label class="form-check-label" for="radioProducao1">
                    Projeto de linha
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioProducao2" value="Projeto Melhoria">
                <label class="form-check-label" for="radioProducao2">
                    Projeto de melhoria
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioProducao3" value="Revisao Projeto">
                <label class="form-check-label" for="radioProducao3">
                    Revisão de projeto
                </label>
            </div>
        </div>

        <div class="col-md-4">
            <p class="fw-bold">PROJETOS DE AUTOMAÇÃO</p>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioAutomacao1" value="Automacao">
                <label class="form-check-label" for="radioAutomacao1">
                    Automação
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioAutomacao2" value="Robotizacao">
                <label class="form-check-label" for="radioAutomacao2">
                    Robotização
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="classe" id="radioAutomacao3" value="Simulacao Robo">
                <label class="form-check-label" for="radioAutomacao3">
                    Simulação Robô
                </label>
            </div>
        </div>
    </div>
    <hr>

    <div class="row mb-3">
        <div class="col-12">
            <label for="escopo" class="form-label fs-7">ESCOPO DA SOLICITAÇÃO <span class="text-danger">*</span></label>
            <textarea class="form-control form-control-sm" id="escopo" rows="3" placeholder="Descreva o escopo da solicitação" name="escopo" required></textarea>
        </div>
    </div>

    <hr>

    <div class="row mb-3">
        <div class="mb-4 mt-4" style="background: #F4F4F4; padding: 0.5rem; border-radius: 4px;" id="requisitoContainer">
            <div class="repeat-div" id="item-0">
                <div class="col-12">
                    <label for="requisito-0" class="form-label fs-7 form-label fs-7-sm">Requisitos</label>
                    <textarea class="form-control form-control-sm" id="requisito-0" rows="3" placeholder="Liste os requisitos" name="requisito[0]" data-idx="0"></textarea>
                </div>

                <div class="d-flex ms-3 gap-1">
                    <button type="button" class="btn btn-transparent text-success btn-requisitos-add p-0">
                        <i class="ph ph-plus"></i>
                    </button>
                    <button type="button" class="btn btn-transparent text-danger btn-requisitos-delete p-0" data-idx="0">
                        <i class="ph ph-minus"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <hr>

    <div class="row mb-3">
        <div id="anexoContainer" class="col-12" style="background: #F4F4F4; padding: 0.5rem; border-radius: 4px;">

            <div class="repeat-anexo-div" id="anexo-item-0">
                <div class="row g-2 align-items-end">

                    <div class="col-md-4">
                        <label for="anexo-0" class="form-label fs-7">Anexo</label>
                        <input class="form-control form-control-sm" type="file" accept=".pdf,.doc,.docx,.txt" id="anexo-0" name="anexo[0]">
                    </div>

                    <div class="col-md-8">
                        <label for="anexoDescricao-0" class="form-label fs-7">Descrição</label>
                        <input class="form-control form-control-sm" type="text" id="anexoDescricao-0" name="anexoDescricao[0]">
                    </div>

                    <div class="d-flex ms-3 gap-1">
                        <button type="button" class="btn btn-transparent text-success btn-anexos-add p-0">
                            <i class="ph ph-plus"></i>
                        </button>
                        <button type="button" class="btn btn-transparent text-danger btn-anexos-delete p-0" data-idx="0">
                            <i class="ph ph-minus"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <button type="submit" class="btn btn-company btn-sm" onclick="loading('show')">Enviar Solicitação</button>
        </div>
    </div>

    </div>
</form>
<?= $this->insert('templates/dt'); ?>