<?= $this->layout("templates/base", [
    "webTitle" => "Menu Dispositivos",
    "cardTitle" => "Menu",
    "styles" => [
        path()->css("/menu.css")
    ],
]);

/*
$isLider      = authorization($_SESSION['usuarioLogin'], 1963, 'lider_proj');
$isProcessos  = authorization($_SESSION['usuarioLogin'], 1963, 'eng_processos');
$isAutomacao  = authorization($_SESSION['usuarioLogin'], 1963, 'eng_automacao');
$isProjetista = authorization($_SESSION['usuarioLogin'], 1963, 'projetista');

$parametrizacao = $isLider;
$abrirSL        = $isLider || $isProcessos || $isAutomacao;
$acompanhar     = $isLider || $isProcessos || $isAutomacao;
$lista          = $isLider || $isAutomacao || $isProjetista;
*/
?>

<div class="row g-3" id="options">

    <?php /* if ($parametrizacao) : */ ?>
        <div class="col-12">
            <a href="<?= route("dispositivos.menu.parametrizacao") ?>" class="btn btn-company menu-option">
                <span>PARAMETRIZAÇÃO</span> <i class="fa-solid fa-gear"></i>
            </a>
        </div>
    <?php /* endif; */ ?>

    <?php /* if ($abrirSL) : */ ?>
        <div class="col-12">
            <a href="<?= route("dispositivos.solicitacao") ?>" class="btn btn-company menu-option">
                <span>ABRIR NOVA SOLICITAÇÃO</span> <i class="fa-solid fa-plus"></i>
            </a>
        </div>
    <?php /* endif; */ ?>

    <?php /* if ($acompanhar) : */ ?>
        <div class="col-12">
            <a href="<?= route("dispositivos.acompanhamento") ?>" class="btn btn-company menu-option">
                <span>ACOMPANHAR SOLICITAÇÕES DE PROJETOS</span>
                <h6>(Engenharia de Processos)</h6>
                <i class="fa-solid fa-magnifying-glass"></i>
            </a>
        </div>
    <?php /* endif; */ ?>

    <?php /* if ($lista) : */ ?>
        <div class="col-12">
            <a href="<?= route("dispositivos.desenvolvimento.lista") ?>" class="btn btn-company menu-option">
                <span>LISTA DE SOLICITAÇÕES DE PROJETOS</span>
                <h6>(Engenharia de Automação / Projetista)</h6>
                <i class="fa-solid fa-list-check"></i>
            </a>
        </div>
    <?php /* endif; */ ?>

    <?php /* INDUSTRIAL — corte e execução (2026-07-21, 4ª rodada) */ ?>
    <div class="col-12">
        <a href="<?= route("dispositivos.industrial.lista") ?>" class="btn btn-company menu-option">
            <span>LISTA INDUSTRIAL - CORTE E EXECUÇÃO</span>
            <h6>(Industrial)</h6>
            <i class="fa-solid fa-industry"></i>
        </a>
    </div>

    <?php /* CONTROLE DE CORTES — pacotes DXF (2026-07-21, 5ª rodada) */ ?>
    <div class="col-12">
        <a href="<?= route("dispositivos.cortes.lista") ?>" class="btn btn-company menu-option">
            <span>CONTROLE DE CORTES DE PEÇAS</span>
            <h6>(Planos de corte / DXF)</h6>
            <i class="fa-solid fa-scissors"></i>
        </a>
    </div>

    <?php /* RESERVAS / CÁLCULO DE PESO — consolidado por espessura (2026-07-21, 6ª rodada) */ ?>
    <div class="col-12">
        <a href="<?= route("dispositivos.cortes.calculoPeso") ?>" class="btn btn-company menu-option">
            <span>RESERVAS - CÁLCULO DE PESO</span>
            <h6>(Consolidado por espessura / compra de chapas)</h6>
            <i class="fa-solid fa-weight-hanging"></i>
        </a>
    </div>

    <?php /* ITENS COMPRADOS por descrição (2026-07-21, 7ª rodada) */ ?>
    <div class="col-12">
        <a href="<?= route("dispositivos.itens.consolidado") ?>" class="btn btn-company menu-option">
            <span>ITENS COMPRADOS POR DESCRIÇÃO</span>
            <h6>(Quais SLs pedem o mesmo item)</h6>
            <i class="fa-solid fa-layer-group"></i>
        </a>
    </div>

</div>