<?= $this->layout("templates/base", [
    "backTo" => "http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/",
    "webTitle" => "Comunicado de Falhas",
    "cardTitle" => "Menu parametrização",
    "styles" => [
        path()->css("/menu.css")
    ],
]); ?>

<div class="row g-3" id="options">
    <div class="col-12">
        <a href="<?= route("parametrizacao.usuario") ?>" class="btn btn-company menu-option">
            <span>USUÁRIOS</span> <i class="fa-solid fa-exclamation"></i>
        </a>
    </div>

    <div class="col-12">
        <a href="<?= route("parametrizacao.vagoes") ?>" class="btn btn-company menu-option">
            <span>VAGÕES E LOTES</span> <i class="fa-solid fa-exclamation"></i>
        </a>
    </div>
    <div class="col-12">
        <a  href="<?= route("parametrizacao.estagios") ?>" class="btn btn-company menu-option">
            <span>ESTÁGIOS</span> <i class="fa-solid fa-exclamation"></i>
        </a>
    </div>
    <div class="col-12">
        <a href="<?= route("parametrizacao.contas") ?>" class="btn btn-company menu-option">
            <span>CONTAS</span> <i class="fa-solid fa-exclamation"></i>
        </a>
    </div>

    <?php /* Espessuras dos planos de corte (2026-07-21, 5ª rodada) */ ?>
    <div class="col-12">
        <a href="<?= route("parametrizacao.espessuras") ?>" class="btn btn-company menu-option">
            <span>ESPESSURAS</span> <i class="fa-solid fa-exclamation"></i>
        </a>
    </div>

    <?php /* Perfis para o cálculo de peso (2026-07-21, 6ª rodada) */ ?>
    <div class="col-12">
        <a href="<?= route("parametrizacao.perfis") ?>" class="btn btn-company menu-option">
            <span>PERFIS</span> <i class="fa-solid fa-exclamation"></i>
        </a>
    </div>


</div>