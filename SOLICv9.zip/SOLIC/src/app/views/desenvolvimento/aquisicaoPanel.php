<?php
/**
 * Painel de Aquisição (itens comprados + OC) — partial compartilhado.
 * 2026-07-21 (8ª rodada): Aquisição/OC passou a ser da INDUSTRIAL; a
 * Automação inclui este mesmo painel apenas em modo leitura ($editavel=false).
 *
 * Recebe: $solicitacao, $itensComprados, $resumoAquisicao,
 *         $aquisicaoHabilitada, $podeBypassAquisicao, $editavel
 */
$h = function ($v) {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
};
$formatarDataHora = function ($data) {
    if (empty($data) || $data === '0000-00-00 00:00:00') {
        return '--';
    }
    try {
        return (new DateTime($data))->format('d/m/Y H:i');
    } catch (Throwable $e) {
        return '--';
    }
};

$itensComprados      = $itensComprados ?? [];
$resumoAquisicao     = $resumoAquisicao ?? ['total' => 0, 'liquidados' => 0, 'pendentes' => 0];
$aquisicaoHabilitada = $aquisicaoHabilitada ?? false;
$podeBypassAquisicao = $podeBypassAquisicao ?? false;
$editavel            = $editavel ?? false;

$statusAquisicaoAtual = strtoupper(trim((string)($solicitacao->aquisicao_status ?? '')));
$slJaLiberada = strtoupper(trim((string)($solicitacao->liberacao_status ?? ''))) === 'OK';

$percentualLiquidado = $resumoAquisicao['total'] > 0
    ? (int) round(($resumoAquisicao['liquidados'] / $resumoAquisicao['total']) * 100)
    : 0;

// Aquisição só é editável nesta tela (Industrial), depois da liberação e antes de concluir
$aquisicaoEmAberto = $editavel
    && $slJaLiberada
    && $statusAquisicaoAtual !== 'OK'
    && $resumoAquisicao['total'] > 0;

$podeConcluirAquisicao = $aquisicaoEmAberto
    && $aquisicaoHabilitada
    && $resumoAquisicao['pendentes'] === 0;
?>

<?php /* ---------- AQUISIÇÃO: resumo + pesquisa ---------- */ ?>
<?php if (!empty($itensComprados)) : ?>

    <?php if ($editavel && !$aquisicaoHabilitada) : ?>
        <div class="alert alert-warning fs-7 mt-3 mb-0" role="alert">
            <i class="bi bi-database-exclamation me-1"></i>
            Controle de aquisição indisponível: rode a migration
            <code>database/migrations/2026-07-21-aquisicao-itens-comprados.sql</code>.
            A lista abaixo segue apenas para consulta.
        </div>
    <?php endif; ?>

    <div class="row g-2 align-items-end mt-3">
        <div class="col-12 col-md-5">
            <label for="pesquisaItemAquisicao" class="form-label fs-7 fw-bold mb-1">
                Pesquisar item (código, descrição, OC ou pedido)
            </label>
            <input
                type="search"
                id="pesquisaItemAquisicao"
                class="form-control form-control-sm"
                placeholder="Ex.: 1234567 ou CHAPA"
                autocomplete="off"
            >
        </div>

        <div class="col-12 col-md-4">
            <label class="form-label fs-7 fw-bold mb-1">Liquidação</label>
            <div class="progress" style="height: 22px;">
                <div
                    id="barraLiquidacao"
                    class="progress-bar bg-success"
                    role="progressbar"
                    style="width: <?= $percentualLiquidado ?>%;"
                    aria-valuenow="<?= $percentualLiquidado ?>"
                    aria-valuemin="0"
                    aria-valuemax="100"
                ><?= $percentualLiquidado ?>%</div>
            </div>

            <small class="text-muted fs-8 d-block">
                <span id="resumoLiquidados"><?= (int) $resumoAquisicao['liquidados'] ?></span>
                de
                <span id="resumoTotalItens"><?= (int) $resumoAquisicao['total'] ?></span>
                liquidados —
                <span id="resumoPendentes"><?= (int) $resumoAquisicao['pendentes'] ?></span>
                pendente(s)
            </small>

            <small class="text-muted fs-8 d-block">
                <i class="bi bi-arrow-repeat me-1"></i>
                Pedido e liquidação são preenchidos automaticamente pela rotina do Logix.
            </small>
        </div>

        <div class="col-12 col-md-3 d-flex flex-column gap-2">
            <?php if ($aquisicaoEmAberto) : ?>
                <button
                    type="button"
                    id="btnConcluirAquisicao"
                    class="btn btn-sm btn-success w-100"
                    data-ref="<?= (int) $solicitacao->ref ?>"
                    <?= $podeConcluirAquisicao ? '' : 'disabled' ?>
                    title="<?= $podeConcluirAquisicao
                                ? 'Todos os itens liquidados — pode concluir'
                                : 'Liquide todos os itens para concluir a aquisição' ?>"
                >
                    <i class="bi bi-flag-fill me-1"></i> Concluir aquisição
                </button>

                <?php if ($podeBypassAquisicao && !$podeConcluirAquisicao) : ?>
                    <button
                        type="button"
                        id="btnBypassAquisicao"
                        class="btn btn-sm btn-outline-warning w-100"
                        data-ref="<?= (int) $solicitacao->ref ?>"
                        title="TESTE: conclui a aquisição sem exigir liquidação"
                    >
                        <i class="bi bi-fast-forward-fill me-1"></i> Pular liquidação (teste)
                    </button>
                <?php endif; ?>
            <?php elseif ($statusAquisicaoAtual === 'OK') : ?>
                <span class="badge bg-success w-100 py-2">
                    <i class="bi bi-check-circle me-1"></i> Aquisição concluída
                </span>
            <?php elseif (!$slJaLiberada) : ?>
                <span class="badge bg-secondary w-100 py-2 text-wrap">
                    SL ainda não liberada
                </span>
            <?php endif; ?>
        </div>
    </div>

<?php endif; ?>

<div class="table-responsive">
    <table class="table table-hover mt-4">
        <thead>
            <tr>
                <th class="text-center">CÓDIGO</th>
                <th class="text-center">REV</th>
                <th class="text-center">DESCRIÇÃO</th>
                <th class="text-center">QTDE</th>
                <th class="text-center">TIPO</th>
                <th class="text-center">N° OC</th>
                <th class="text-center">PEDIDO</th>
                <th class="text-center">STATUS</th>
            </tr>
        </thead>

        <tbody class="align-middle text-center fs-7" id="tbodyItensAquisicao">
            <?php if (!empty($itensComprados)) : ?>
                <?php foreach ($itensComprados as $item) : ?>
                    <?php
                    $itemLiquidado = !empty($item->liquidado);
                    $itemOc        = (string)($item->n_oc ?? '');
                    $itemPedido    = (string)($item->pedido ?? '');

                    $itemSincronizado = !empty($item->sincronizado_em)
                        ? $formatarDataHora($item->sincronizado_em)
                        : '';

                    // Só o N° OC é digitável, e só com a aquisição em aberto (Industrial)
                    $itemEditavel = $aquisicaoEmAberto && $aquisicaoHabilitada;

                    $textoBusca = trim(implode(' ', [
                        (string)($item->codigo ?? ''),
                        (string)($item->descricao ?? ''),
                        $itemOc,
                        $itemPedido,
                    ]));
                    ?>
                    <tr
                        data-item-id="<?= $h($item->id) ?>"
                        data-codigo="<?= $h($item->codigo ?? '') ?>"
                        data-descricao="<?= $h($item->descricao ?? '') ?>"
                        data-busca="<?= $h($textoBusca) ?>"
                    >
                        <td data-label="Código"><?= $h($item->codigo ?? '--') ?></td>
                        <td data-label="Rev"><?= $h($item->rev ?? '--') ?></td>
                        <td data-label="Descrição" class="text-start"><?= $h($item->descricao ?? '--') ?></td>
                        <td data-label="Qtde"><?= $h($item->quantidade ?? '--') ?></td>
                        <td data-label="Tipo"><?= $h($item->tipo ?? '--') ?></td>

                        <td data-label="N° OC">
                            <?php if ($itemEditavel) : ?>
                                <input
                                    type="text"
                                    class="form-control form-control-sm text-center"
                                    data-campo="n_oc"
                                    value="<?= $h($itemOc) ?>"
                                    placeholder="OC"
                                    maxlength="60"
                                    aria-label="Número da OC do item <?= $h($item->codigo ?? '') ?>"
                                >
                            <?php else : ?>
                                <?= $itemOc !== '' ? $h($itemOc) : '--' ?>
                            <?php endif; ?>
                        </td>

                        <?php /* Pedido e Status vêm da rotina do Logix — sempre leitura */ ?>
                        <td data-label="Pedido">
                            <?php if ($itemPedido !== '') : ?>
                                <?= $h($itemPedido) ?>
                            <?php elseif ($itemOc !== '') : ?>
                                <span class="text-muted fst-italic fs-8">aguardando Logix</span>
                            <?php else : ?>
                                --
                            <?php endif; ?>
                        </td>

                        <td data-label="Status">
                            <div class="d-flex align-items-center justify-content-center gap-2">
                                <span
                                    data-selo-status
                                    class="badge <?= $itemLiquidado ? 'bg-success' : 'bg-secondary' ?>"
                                    title="<?= $itemSincronizado !== ''
                                                ? 'Última consulta ao Logix: ' . $h($itemSincronizado)
                                                : 'Ainda não consultado no Logix' ?>"
                                ><?= $itemLiquidado ? 'Liquidado' : 'Pendente' ?></span>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <tr id="itensAquisicaoVazio" hidden>
                    <td colspan="8" class="text-muted py-4">Nenhum item corresponde à pesquisa.</td>
                </tr>
            <?php else : ?>
                <tr>
                    <td colspan="8" class="text-muted py-4">Nenhum item comprado ou siderúrgico listado.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
