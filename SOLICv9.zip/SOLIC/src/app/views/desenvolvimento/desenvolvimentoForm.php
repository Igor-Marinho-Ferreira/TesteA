<?php
$this->layout("templates/base", [
    "backTo" => route("dispositivos.desenvolvimento.lista"),
    "webTitle" => "Dispositivos - Solicitação de projetos",
    "cardTitle" => "SOLICITAÇÃO DE PROJETO DE DISPOSITIVOS - DESENVOLVIMENTO",
    "styles"    => [
        'https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css',
        path()->css("desenvolvimento.css")
    ],
    "js" => [
        path()->js("desenvolvimentoProj.js"),
        // Carrega DEPOIS de desenvolvimentoProj.js: embrulha gerenciarMudancaStatus
        path()->js("liberacaoAquisicao.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$formatarData = function ($data) {
    if (empty($data)) {
        return '--';
    }

    try {
        return (new DateTime($data))->format('d/m/Y');
    } catch (Throwable $e) {
        return '--';
    }
};

$formatarDataHora = function ($data) {
    if (empty($data)) {
        return '--';
    }

    try {
        return (new DateTime($data))->format('d/m/Y H:i');
    } catch (Throwable $e) {
        return '--';
    }
};

$formatarBytes = function ($bytes) {
    $bytes = (int)($bytes ?? 0);

    if ($bytes <= 0) {
        return '--';
    }

    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2, ',', '.') . ' GB';
    }

    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2, ',', '.') . ' MB';
    }

    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 2, ',', '.') . ' KB';
    }

    return $bytes . ' bytes';
};

$statusConceito = strtoupper(trim((string)($solicitacao->status_conceito ?? $solicitacao->conceito_status ?? '')));
$statusDetalhe  = strtoupper(trim((string)($solicitacao->status_detalhe ?? $solicitacao->detalhamento_status ?? '')));

$liberaCarregarAnexos = ($statusConceito === 'OK' && $statusDetalhe === 'OK');

$tooltipCarregarAnexos = $liberaCarregarAnexos
    ? 'Liberado para envio de anexos.'
    : 'Disponível somente após Conceito/Modelo e Detalhamento estarem com status OK.';

$imagemProjeto = $imagemProjeto ?? null;
$pacotesDxf = $pacotesDxf ?? [];
$txtItensComprados = $txtItensComprados ?? [];
$listasMateriais = $listasMateriais ?? [];
$desenhosPdf = $desenhosPdf ?? [];
$itensComprados = $itensComprados ?? [];
$cargasMap = $cargasMap ?? [];

/* ---------------------------------------------------------------------------
 * LIBERAÇÃO / AQUISIÇÃO — 2026-07-21
 * ------------------------------------------------------------------------- */
$statusLiberacaoAtual = strtoupper(trim((string)($solicitacao->liberacao_status ?? '')));
$statusAquisicaoAtual = strtoupper(trim((string)($solicitacao->aquisicao_status ?? '')));

$slJaLiberada = ($statusLiberacaoAtual === 'OK');

// Só libera a SL depois que Conceito e Detalhamento estiverem OK
$podeLiberarSl = $liberaCarregarAnexos && !$slJaLiberada;

$tooltipLiberarSl = $slJaLiberada
    ? 'Esta SL já foi liberada.'
    : ($liberaCarregarAnexos
        ? 'Liberar a SL e registrar a consideração no histórico.'
        : 'Disponível somente após Conceito/Modelo e Detalhamento estarem com status OK.');

// Resumo da liquidação (vem do controller; fallback defensivo)
$resumoAquisicao = $resumoAquisicao ?? ['total' => 0, 'liquidados' => 0, 'pendentes' => 0];
$aquisicaoHabilitada = $aquisicaoHabilitada ?? false;

$percentualLiquidado = $resumoAquisicao['total'] > 0
    ? (int) round(($resumoAquisicao['liquidados'] / $resumoAquisicao['total']) * 100)
    : 0;

// A aquisição só é editável depois da liberação e antes de concluir
$aquisicaoEmAberto = $slJaLiberada
    && $statusAquisicaoAtual !== 'OK'
    && $resumoAquisicao['total'] > 0;

$podeConcluirAquisicao = $aquisicaoEmAberto
    && $aquisicaoHabilitada
    && $resumoAquisicao['pendentes'] === 0;

// 2026-07-21 (2ª rodada) — bypass de teste liberado só para matrículas autorizadas
$podeBypassAquisicao = $podeBypassAquisicao ?? false;

// 2026-07-21 (3ª rodada) — retorno de SL + cronômetro de corte/execução
$temposEtapa = $temposEtapa ?? [];
$slCancelada = strtoupper(trim((string)($solicitacao->liberacao_status ?? ''))) === 'CANCELADO';
// Botão "Retornar SL": disponível nas etapas de aquisição/corte/execução
$podeRetornarSl = $slJaLiberada && !$slCancelada;

/* ---------------------------------------------------------------------------
 * 2026-07-21 (8ª rodada) — Liberação, Aquisição/OC e cortes são da INDUSTRIAL.
 * Nesta tela (Automação) essas ações ficam SOMENTE LEITURA.
 * ------------------------------------------------------------------------- */
$aquisicaoEmAberto     = false;  // OC não editável, sem "concluir"/bypass
$podeConcluirAquisicao = false;
$podeLiberarSl         = false;  // Liberar SL fica na Industrial
$podeRetornarSl        = false;  // Retornar SL fica na Industrial

// Formata segundos em "Xh Ym" (ou "Ym", ou "—")
$formatarDuracao = function ($segundos) {
    $segundos = max(0, (int) $segundos);
    if ($segundos < 60) {
        return $segundos === 0 ? '—' : $segundos . 's';
    }
    $h = intdiv($segundos, 3600);
    $m = intdiv($segundos % 3600, 60);
    if ($h > 0) {
        return $h . 'h ' . str_pad((string) $m, 2, '0', STR_PAD_LEFT) . 'm';
    }
    return $m . 'm';
};
?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body mb-3.5">
        <div class="row header-infos">
            <div class="col-md-7">
                <div class="row mb-1">
                    <div class="col-md-12">
                        <label class="form-label fs-7 fw-bold d-block mb-1">PROJETO:</label>

                        <?php if (!empty($solicitacao->cod_z)) : ?>
                            <div class="card shadow-sm p-3 mb-3">
                                <form action="<?= route('dispositivos.desenvolvimento.associarZ', ['ref' => $solicitacao->ref]) ?>" method="POST">
                                    <div class="row align-items-end g-2">
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold small text-muted">CÓD. Z</label>

                                            <div class="input-group">
                                                <span class="input-group-text fw-bold text-primary bg-light">
                                                    <i class="fas fa-project-diagram me-1"></i>Z
                                                </span>

                                                <input
                                                    type="text"
                                                    class="form-control"
                                                    id="cod_z"
                                                    name="cod_z"
                                                    value="<?= $h($z_info->cod_z ?? $solicitacao->cod_z) ?>"
                                                    placeholder="Código"
                                                >

                                                <button
                                                    class="btn btn-outline-primary"
                                                    id="botaoAssociar"
                                                    type="button"
                                                    disabled
                                                    title="Associar"
                                                >
                                                    <i class="fas fa-link"></i>
                                                    Associar
                                                </button>
                                            </div>
                                        </div>

                                        <div class="col-md-2 text-center">
                                            <label class="form-label d-block text-nowrap small text-muted" for="novaRev">NOVA REV.</label>

                                            <div class="form-check d-inline-block">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="novaRev"
                                                    id="novaRev"
                                                    style="transform: scale(1.3); cursor:pointer;"
                                                >
                                            </div>
                                        </div>

                                        <div class="col-md-1">
                                            <label for="qtdRev" class="form-label small text-muted">REV</label>

                                            <input
                                                type="text"
                                                name="qtdRev"
                                                id="qtdRev"
                                                class="form-control text-center px-1"
                                                value="<?= $h($z_info->qtdRev ?? '0') ?>"
                                                placeholder="--"
                                                readonly
                                            >
                                        </div>

                                        <?php if (is_object($z_info) && isset($z_info->descricao)) : ?>
                                            <div class="col-md-5 border-start ps-3">
                                                <label class="form-label text-muted small d-block mb-1">DESCRIÇÃO DO PROJETO</label>

                                                <span class="text-secondary fw-bold d-block" style="line-height: 1.2;">
                                                    <?= $h($z_info->descricao) ?>
                                                </span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>

                            <div class="d-flex align-items-center my-3">
                                <hr class="flex-grow-1 text-muted opacity-25">
                                <span class="mx-3 text-muted fw-bold small">OU</span>
                                <hr class="flex-grow-1 text-muted opacity-25">
                            </div>

                            <div class="row g-2 align-items-stretch">
                                <div class="col-md-5">
                                    <a
                                        href="<?= route('dispositivos.desenvolvimento.gerarZ', ['ref' => $solicitacao->ref]) ?>"
                                        class="btn btn-success shadow-sm w-100 py-2 h-100"
                                        onclick="loading('show')"
                                    >
                                        <i class="fas fa-magic me-2"></i>
                                        Gerar Novo Código Z
                                    </a>
                                </div>

                                <div class="col-md-3">
                                    <button
                                        type="button"
                                        class="btn btn-primary shadow-sm w-100 py-2 h-100"
                                        onclick="openModal(<?= (int)$solicitacao->ref ?>, 'requisitos')"
                                    >
                                        <i class="fas fa-list-check me-1"></i>
                                        Requisitos
                                    </button>
                                </div>

                                <div class="col-md-4">
                                    <span
                                        class="d-block h-100"
                                        title="<?= $h($tooltipCarregarAnexos) ?>"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top"
                                    >
                                        <button
                                            type="button"
                                            id="btnCarregarAnexos"
                                            class="btn shadow-sm w-100 py-2 h-100 <?= $liberaCarregarAnexos ? 'btn-primary' : 'btn-secondary' ?>"
                                            data-liberado="<?= $liberaCarregarAnexos ? '1' : '0' ?>"
                                            <?= $liberaCarregarAnexos ? "onclick=\"openModal({$solicitacao->ref}, 'arquivos_solicitacao')\"" : 'disabled' ?>
                                            title="<?= $h($tooltipCarregarAnexos) ?>"
                                        >
                                            <i class="fas fa-paperclip me-1"></i>
                                            Carregar anexos
                                        </button>
                                    </span>
                                </div>
                            </div>
                        <?php else : ?>
                            <div class="card p-3 border-dashed">
                                <div class="row g-2 align-items-end">
                                    <div class="col-md-4">
                                        <form action="<?= route('dispositivos.desenvolvimento.associarZ', ['ref' => $solicitacao->ref]) ?>" method="POST">
                                            <label class="form-label small fw-bold text-muted mb-1">
                                                ASSOCIAR EXISTENTE:
                                            </label>

                                            <div class="input-group">
                                                <span class="input-group-text">Z</span>

                                                <input
                                                    type="text"
                                                    name="cod_z"
                                                    id="cod_z"
                                                    class="form-control"
                                                    placeholder="Cód. Existente"
                                                >

                                                <input type="hidden" name="qtdRev" id="qtdRev_hidden" value="0">

                                                <button
                                                    class="btn btn-primary"
                                                    id="botaoAssociar"
                                                    disabled
                                                    type="submit"
                                                    onclick="loading('show')"
                                                >
                                                    Associar
                                                </button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="col-md-1 text-center fw-bold text-muted pb-2">
                                        OU
                                    </div>

                                    <div class="col-md-3">
                                        <a
                                            href="<?= route('dispositivos.desenvolvimento.gerarZ', ['ref' => $solicitacao->ref]) ?>"
                                            class="btn btn-success w-100 py-2"
                                            onclick="loading('show')"
                                        >
                                            <i class="fas fa-magic me-1"></i>
                                            Gerar Novo Z
                                        </a>
                                    </div>

                                    <div class="col-md-2">
                                        <button
                                            type="button"
                                            class="btn btn-primary w-100 py-2"
                                            onclick="openModal(<?= (int)$solicitacao->ref ?>, 'requisitos')"
                                        >
                                            Requisitos
                                        </button>
                                    </div>

                                    <div class="col-md-2">
                                        <span
                                            class="d-block"
                                            title="<?= $h($tooltipCarregarAnexos) ?>"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="top"
                                        >
                                            <button
                                                type="button"
                                                id="btnCarregarAnexos"
                                                class="btn w-100 py-2 <?= $liberaCarregarAnexos ? 'btn-primary' : 'btn-secondary' ?>"
                                                data-liberado="<?= $liberaCarregarAnexos ? '1' : '0' ?>"
                                                <?= $liberaCarregarAnexos ? "onclick=\"openModal({$solicitacao->ref}, 'arquivos_solicitacao')\"" : 'disabled' ?>
                                                title="<?= $h($tooltipCarregarAnexos) ?>"
                                            >
                                                <i class="fas fa-paperclip me-1"></i>
                                                Anexos
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mt-4.5">
                    <div class="col-md-10">
                        <label class="form-label fs-7 fw-bold d-block mb-2 border-bottom pb-1">DADOS DA SOLICITAÇÃO:</label>

                        <div class="mb-5">
                            <span class="fs-5 fw-bold text-dark">SL<?= $h($solicitacao->ref) ?></span>

                            <span class="fs-6 text-secondary ms-2">
                                <?= (is_object($solicitacao) && isset($solicitacao->descricao)) ? " | " . $h($solicitacao->descricao) : "" ?>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="row g-3 bg-light rounded p-1 mx-0">
                    <div class="col-md-4 col-lg-2">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Data:</label>
                        <span class="fs-7 text-dark"><?= $formatarData($solicitacao->data_solicitacao ?? null) ?></span>
                    </div>

                    <div class="col-md-8 col-lg-3">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Solicitante:</label>

                        <span class="fs-7 text-dark text-truncate d-block" title="<?= $h($solicitacao->solicitante) ?>">
                            <?= strtoupper($h($solicitacao->solicitante)) ?>
                        </span>
                    </div>

                    <div class="col-md-4 col-lg-2">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Estágio:</label>
                        <span class="fs-7 text-dark"><?= strtoupper($h($solicitacao->aplicacao)) ?></span>
                    </div>

                    <div class="col-md-2 col-lg-1">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Vagão:</label>
                        <span class="fs-7 text-dark"><?= strtoupper($h($solicitacao->vagao)) ?></span>
                    </div>

                    <div class="col-md-2 col-lg-1">
                        <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Lote:</label>
                        <span class="fs-7 text-dark"><?= strtoupper($h($solicitacao->lote)) ?></span>
                    </div>

                    <div class="col-md-12 col-lg-3">
                        <div class="d-flex align-items-start gap-4">
                            <div>
                                <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-muted">Classificação:</label>

                                <span class="fs-7 text-dark text-truncate d-block">
                                    <?= strtoupper($h($solicitacao->classe)) ?>
                                </span>
                            </div>

                            <?php if ($solicitacao->n_safety_walk) : ?>
                                <div class="border-start ps-3">
                                    <label class="form-label fs-8 fw-bold d-block mb-0 text-uppercase text-danger">N° Safety Walk</label>

                                    <span class="fs-7 text-muted d-block">
                                        <?= strtoupper($h($solicitacao->n_safety_walk)) ?>
                                    </span>
                                </div>
                            <?php endif ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 d-flex flex-column align-items-center justify-content-center border-start bg-white py-3">
                <label class="form-label small fw-bold text-muted mb-3">VISUALIZAÇÃO</label>

                <div class="imgProj w-100 text-center px-2">
                    <?php if (!empty($imagemProjeto)) : ?>
                        <a
                            href="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $imagemProjeto->id]) ?>"
                            target="_blank"
                            title="Abrir imagem do projeto"
                        >
                            <img
                                src="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $imagemProjeto->id]) ?>"
                                class="img-fluid rounded shadow-sm border"
                                alt="Imagem do Projeto"
                                style="max-height: 180px; object-fit: contain;"
                                onerror="this.src='https://placehold.co/200x150?text=Sem+Imagem'"
                            >
                        </a>

                        <div class="mt-2 w-100">
                            <a
                                href="<?= route('dispositivos.desenvolvimento.arquivo.download', ['id' => $imagemProjeto->id]) ?>"
                                class="btn btn-sm btn-outline-primary w-100 text-truncate mb-1"
                                title="<?= $h($imagemProjeto->nome_original ?? '') ?>"
                            >
                                Baixar imagem
                            </a>

                            <form
                                action="<?= route('dispositivos.desenvolvimento.imagemProjeto.store', ['ref' => $solicitacao->ref]) ?>"
                                method="POST"
                                enctype="multipart/form-data"
                                id="formAlterarImagemProjeto"
                            >
                                <input
                                    type="file"
                                    name="imagem_projeto"
                                    id="inputAlterarImagemProjeto"
                                    accept="image/*"
                                    class="d-none"
                                    <?= $liberaCarregarAnexos ? '' : 'disabled' ?>
                                    onchange="loading('show', true); document.getElementById('formAlterarImagemProjeto').submit();"
                                >

                                <button
                                    type="button"
                                    class="btn btn-sm w-100 <?= $liberaCarregarAnexos ? 'btn-outline-warning' : 'btn-secondary' ?>"
                                    <?= $liberaCarregarAnexos ? "onclick=\"document.getElementById('inputAlterarImagemProjeto').click();\"" : 'disabled' ?>
                                    title="<?= $h($tooltipCarregarAnexos) ?>"
                                >
                                    Alterar imagem
                                </button>
                            </form>
                        </div>
                    <?php else : ?>
                        <img
                            src="https://placehold.co/200x150?text=Sem+Imagem"
                            class="img-fluid rounded shadow-sm border"
                            alt="Sem Imagem"
                            style="max-height: 180px; object-fit: contain;"
                        >

                        <div class="mt-2 w-100">
                            <form
                                action="<?= route('dispositivos.desenvolvimento.imagemProjeto.store', ['ref' => $solicitacao->ref]) ?>"
                                method="POST"
                                enctype="multipart/form-data"
                                id="formInserirImagemProjeto"
                            >
                                <input
                                    type="file"
                                    name="imagem_projeto"
                                    id="inputInserirImagemProjeto"
                                    accept="image/*"
                                    class="d-none"
                                    <?= $liberaCarregarAnexos ? '' : 'disabled' ?>
                                    onchange="loading('show', true); document.getElementById('formInserirImagemProjeto').submit();"
                                >

                                <button
                                    type="button"
                                    class="btn btn-sm w-100 <?= $liberaCarregarAnexos ? 'btn-outline-warning' : 'btn-secondary' ?>"
                                    <?= $liberaCarregarAnexos ? "onclick=\"document.getElementById('inputInserirImagemProjeto').click();\"" : 'disabled' ?>
                                    title="<?= $h($tooltipCarregarAnexos) ?>"
                                >
                                    Inserir imagem
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-2 d-flex flex-column border-start bg-white py-3">
                <label class="form-label small fw-bold text-muted mb-2 text-center">
                    DOCUMENTAÇÃO
                </label>

                <div class="w-100 px-2">
                    <?php if (empty($desenhosPdf)) : ?>
                        <div class="text-center text-muted small py-3">
                            <i class="fas fa-folder-open fa-2x mb-2 d-block"></i>
                            Nenhum PDF.
                        </div>
                    <?php else : ?>
                        <div
                            class="border rounded bg-light p-2 mb-2"
                            style="max-height: 145px; overflow-y: auto;"
                        >
                            <?php foreach ($desenhosPdf as $index => $desenhoPdf) : ?>
                                <a
                                    href="<?= route('dispositivos.desenvolvimento.arquivo.visualizar', ['id' => $desenhoPdf->id]) ?>"
                                    target="_blank"
                                    class="d-block bg-white border rounded px-2 py-1 mb-1 text-decoration-none text-dark small text-truncate"
                                    title="<?= $h($desenhoPdf->nome_original ?? '') ?>"
                                >
                                    <i class="fas fa-file-pdf text-danger me-1"></i>
                                    <?= $h($desenhoPdf->nome_original ?? 'PDF ' . ($index + 1)) ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <form
                        action="<?= route('dispositivos.desenvolvimento.pdf.store', ['ref' => $solicitacao->ref]) ?>"
                        method="POST"
                        enctype="multipart/form-data"
                        id="formAdicionarPdf"
                    >
                        <input
                            type="file"
                            name="desenhos_pdf[]"
                            id="inputAdicionarPdf"
                            accept="application/pdf,.pdf"
                            multiple
                            class="d-none"
                            <?= $liberaCarregarAnexos ? '' : 'disabled' ?>
                            onchange="loading('show', true); document.getElementById('formAdicionarPdf').submit();"
                        >

                        <button
                            type="button"
                            class="btn btn-sm w-100 <?= $liberaCarregarAnexos ? 'btn-outline-danger' : 'btn-secondary' ?>"
                            <?= $liberaCarregarAnexos ? "onclick=\"document.getElementById('inputAdicionarPdf').click();\"" : 'disabled' ?>
                            title="<?= $h($tooltipCarregarAnexos) ?>"
                        >
                            <?= empty($desenhosPdf) ? 'Inserir PDF' : 'Adicionar PDF' ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="barra-progresso-container">
    <?php
    $class_map = [
        'OK'           => 'status-ok',
        'FINALIZADO'   => 'status-ok',
        'EM ANDAMENTO' => 'status-alerta',
        'MODELO'       => 'status-alerta',
        'PENDENTE'     => 'status-espera',
        'CANCELADO'    => 'status-espera',
        '[VALIDAÇÃO]'  => 'status-alerta',
        'REVISAR'      => 'status-revisao',
        'BACKLOG'      => 'status-backlog',
        'PAUSADO'      => 'status-pausado',
        // 2026-07-21 (2ª rodada) — novos status de corte/execução
        'TERCEIRIZADO' => 'status-pausado',
        'AGUARDANDO'   => 'status-backlog',
        'ANDAMENTO'    => 'status-alerta'
    ];

    foreach ($etapas as $etapa) :
        $current_status_class = $class_map[$etapa['valor']] ?? 'status-espera';
        $valor_atual = strtoupper($etapa['valor']);

        $is_finalizado = ($valor_atual === 'OK' || $valor_atual === 'CANCELADO');
        $is_validacao  = ($etapa['coluna'] === 'detalhamento_status' && $valor_atual === '[VALIDAÇÃO]');
        $sem_projetista_conceito = ($etapa['coluna'] === 'conceito_status' && empty($solicitacao->conceito_proj));
        $sem_projetista_detalhe = ($etapa['coluna'] === 'detalhamento_status' && empty($solicitacao->detalhamento_proj));
        $projeto_nao_concluido = ($etapa['coluna'] === 'detalhamento_status' && strtoupper($solicitacao->conceito_status) !== 'OK');

        $is_disabled = (
            !$etapa['edit'] ||
            $is_finalizado ||
            $is_validacao ||
            $sem_projetista_conceito ||
            $sem_projetista_detalhe ||
            $projeto_nao_concluido
        );
    ?>
        <div class="step-card">
            <label class="step-label text-truncate"><?= $h($etapa['label']) ?></label>

            <select
                name="status_<?= strtolower(str_replace(' ', '_', $etapa['label'])) ?>"
                class="form-select form-select-sm select-status <?= $current_status_class ?>"
                data-id="<?= $h($solicitacao->ref) ?>"
                data-coluna="<?= $h($etapa['coluna']) ?>"
                onchange="gerenciarMudancaStatus(this), loading('show')"
                <?= $is_disabled ? 'disabled' : '' ?>
                title="<?= $sem_projetista_detalhe ? 'Selecione o projetista de detalhamento' : ($projeto_nao_concluido ? 'Finalize o Projeto primeiro' : '') ?>"
            >
                <?php if (!in_array($etapa['valor'], $etapa['opcoes'])) : ?>
                    <option value="<?= $h($etapa['valor']) ?>" selected>
                        <?= $h($etapa['valor']) ?>
                    </option>
                <?php endif; ?>

                <?php foreach ($etapa['opcoes'] as $opcao) : ?>
                    <option value="<?= $h($opcao) ?>" <?= (strtoupper($etapa['valor']) == strtoupper($opcao)) ? 'selected' : '' ?>>
                        <?= $h($opcao) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <?php if ($projeto_nao_concluido) : ?>
                <small class="text-warning" style="font-size: 0.65rem;">Aguardando Projeto OK</small>
            <?php elseif ($sem_projetista_conceito || $sem_projetista_detalhe) : ?>
                <small class="text-danger" style="font-size: 0.65rem;">Selecione um projetista</small>
            <?php endif; ?>

            <?php /* Cronômetro de corte/execução (3ª rodada) */ ?>
            <?php if (isset($temposEtapa[$etapa['coluna']])) : ?>
                <?php $tempoEt = $temposEtapa[$etapa['coluna']]; ?>
                <small class="d-block mt-1" style="font-size: 0.65rem;"
                       title="<?= !empty($tempoEt['derivado'])
                                    ? 'Tempo corrido entre o início e o fim da etapa'
                                    : 'Tempo somando apenas os períodos em andamento/terceirizado' ?>">
                    <i class="bi bi-stopwatch<?= !empty($tempoEt['rodando']) ? '-fill text-success' : ' text-muted' ?>"></i>
                    <span class="<?= !empty($tempoEt['rodando']) ? 'text-success fw-semibold' : 'text-muted' ?>">
                        <?= $h($formatarDuracao($tempoEt['segundos'])) ?>
                    </span>
                    <?= !empty($tempoEt['rodando']) ? '<span class="text-success">•</span>' : '' ?>
                </small>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<div class="d-flex align-items-center py-3">
    <div class="flex-grow-1 border-top"></div>
    <span class="mx-3 fw-bold text-uppercase fs-7">PROJETO</span>
    <div class="flex-grow-1 border-top"></div>
</div>

<div class="row">
    <div class="col-md-4">
        <h6 class="fw-bold text-muted border-bottom pb-2 mb-3">Conceito/Modelo</h6>

        <div class="mb-3">
            <?php if (!empty($solicitacao->conceito_proj) && $solicitacao->conceito_status === 'OK') : ?>
                <label class="form-label fs-7 fw-bold d-block mb-0">Projetista:</label>
                <span class="text-uppercase"><?= $h($solicitacao->conceito_proj) ?></span>
            <?php else : ?>
                <form action="<?= route('dispositivos.desenvolvimento.storeProjetista', ['ref' => $solicitacao->ref, 'tipo' => 'conceito']) ?>" method="POST">
                    <label for="projetista_conceito" class="form-label fs-7 fw-bold d-block mb-0">Projetista:</label>

                    <div class="d-flex gap-2">
                        <select class="form-select form-select-sm" id="projetista_conceito" name="projetista" required>
                            <option value="" <?= empty($solicitacao->conceito_proj) ? 'selected' : '' ?>>Selecione...</option>

                            <?php foreach ($projetistas as $projetista) : ?>
                                <option value="<?= $h($projetista->nome) ?>" <?= (isset($solicitacao->conceito_proj) && $solicitacao->conceito_proj == $projetista->nome) ? 'selected' : '' ?>>
                                    <?= $h($projetista->nome) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <button type="submit" class="btn btn-sm status-backlog text-nowrap" onclick="loading('show', true)">
                            <?= !empty($solicitacao->conceito_proj) ? 'Atualizar / Backlog' : 'Enviar para BACKLOG' ?>
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>

        <div class="row text-center pt-3">
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Início</h6>
                <span class="fs-7"><?= date('d/m/Y H:i:s', strtotime($solicitacao->conceito_inicio)) ?></span>
            </div>

            <div class="col-4 border-start border-end">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Fim</h6>
                <span class="fs-7"><?= date('d/m/Y H:i:s', strtotime($solicitacao->conceito_fim)) ?></span>
            </div>

            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Status</h6>
                <span class="fs-8"><?= $h($solicitacao->conceito_status) ?></span>
            </div>
        </div>
    </div>

    <div class="col-md-4 border-start">
        <h6 class="fw-bold text-muted border-bottom pb-2 mb-3">Detalhamento</h6>

        <div class="mb-3">
            <?php if (!empty($solicitacao->detalhamento_proj)) : ?>
                <label class="form-label fs-7 fw-bold d-block mb-0">Projetista:</label>
                <span class="text-uppercase"><?= $h($solicitacao->detalhamento_proj) ?></span>
            <?php else : ?>
                <form action="<?= route('dispositivos.desenvolvimento.storeProjetista', ['ref' => $solicitacao->ref, 'tipo' => 'detalhamento']) ?>" method="POST">
                    <label for="projetista" class="form-label fs-7 fw-bold d-block mb-0">Projetista:</label>

                    <div class="d-flex gap-2">
                        <select class="form-select form-select-sm" id="projetista" name="projetista" required>
                            <option value="" selected>Selecione...</option>

                            <?php foreach ($projetistas as $projetista) : ?>
                                <option value="<?= $h($projetista->nome) ?>"><?= $h($projetista->nome) ?></option>
                            <?php endforeach; ?>
                        </select>

                        <button type="submit" class="btn btn-sm status-backlog text-nowrap">
                            Alocar
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>

        <div class="row text-center pt-3">
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Início</h6>
                <span class="fs-7"><?= date('d/m/Y H:i:s', strtotime($solicitacao->detalhamento_inicio)) ?></span>
            </div>

            <div class="col-4 border-start border-end">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Fim</h6>
                <span class="fs-7"><?= date('d/m/Y H:i:s', strtotime($solicitacao->detalhamento_fim)) ?></span>
            </div>

            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Status</h6>
                <span class="fs-8"><?= $h($solicitacao->detalhamento_status) ?></span>
            </div>
        </div>
    </div>

    <div class="col-md-4 border-start">
        <h6 class="fw-bold text-muted border-bottom pb-2 mb-3">Execução</h6>

        <div class="mb-3">
            <?php if (empty($solicitacao->executor_proj)) : ?>
                <label class="form-label fs-7 fw-bold d-block mb-0">Executor:</label>
                <span class="text-muted pt-4"><?= $h($solicitacao->executor_proj ?? 'Não alocado') ?></span>
            <?php else : ?>
                <label for="executor_proj" class="form-label fs-7 fw-bold d-block mb-0">Executor:</label>

                <div class="d-flex gap-2">
                    <select name="executor_proj" id="executor_proj" class="form-select form-select-sm">
                        <option value="" selected disabled>Selecione...</option>
                        <option value="1">Executor 1</option>
                        <option value="2">Executor 2</option>
                        <option value="3">Executor 3</option>
                    </select>

                    <a href="<?= route('parametrizacao.usuario') ?>" class="btn btn-sm status-backlog text-nowrap">Alocar</a>
                </div>
            <?php endif; ?>
        </div>

        <div class="row text-center pt-3">
            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Início</h6>
                <span class="fs-7"><?= date('d/m/Y H:i:s', strtotime($solicitacao->exec_data)) ?></span>
            </div>

            <div class="col-4 border-start border-end">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Fim</h6>
                <span class="fs-7">--</span>
            </div>

            <div class="col-4">
                <h6 class="fw-bold mb-0 small text-muted text-uppercase">Status</h6>
                <span class="fs-8"><?= $h($solicitacao->exec_status) ?></span>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-8">
            <div class="position-relative d-flex align-items-center py-3 pt-5">
                <div class="flex-grow-1 border-top"></div>
                <span class="mx-3 fw-bold text-uppercase fs-7">PACOTES DE DXFs PARA CORTE</span>
                <div class="flex-grow-1 border-top"></div>
            </div>

            <form
                action="<?= route('dispositivos.desenvolvimento.dxf.store', ['ref' => $solicitacao->ref]) ?>"
                method="POST"
                enctype="multipart/form-data"
                id="formAdicionarDxf"
                class="d-inline-block"
            >
                <input
                    type="file"
                    name="pacote_dxf"
                    id="inputAdicionarDxf"
                    accept=".zip,.rar,.7z"
                    class="d-none"
                    <?= $liberaCarregarAnexos ? '' : 'disabled' ?>
                    onchange="loading('show', true); document.getElementById('formAdicionarDxf').submit();"
                >

                <button
                    type="button"
                    class="btn btn-sm fw-semibold px-3 <?= $liberaCarregarAnexos ? 'text-white' : 'btn-secondary' ?>"
                    style="<?= $liberaCarregarAnexos ? 'background-color: #006A67; border-color: #006A67;' : '' ?>"
                    <?= $liberaCarregarAnexos ? "onclick=\"document.getElementById('inputAdicionarDxf').click();\"" : 'disabled' ?>
                    title="<?= $h($tooltipCarregarAnexos) ?>"
                >
                    <i class="fas fa-file-archive me-1"></i>
                    Adicionar DXF
                </button>
            </form>

            <table class="table table-hover mt-4">
                <thead>
                    <tr>
                        <th class="text-center">CÓDIGO</th>
                        <th class="text-center">DESCRIÇÃO</th>
                        <th class="text-center">PRIORIDADE</th>
                        <th class="text-center">STATUS</th>
                        <th class="text-center">Ações</th>
                    </tr>
                </thead>

                <tbody class="align-middle text-center fs-7">
                    <?php if (!empty($pacotesDxf)) : ?>
                        <?php foreach ($pacotesDxf as $index => $dxf) : ?>
                            <?php
                            $carga = $cargasMap[$dxf->carga_id] ?? null;
                            $prioridade = $carga->prioridade ?? '--';

                            /*
                            * Usa o código salvo no banco: DXF001, DXF002, DXF003...
                            * Caso seja um registro antigo sem código, mostra um fallback visual.
                            */
                            $codigoArquivo = !empty($dxf->codigo)
                                ? $dxf->codigo
                                : 'DXF' . str_pad((string)($index + 1), 3, '0', STR_PAD_LEFT);
                            ?>

                            <tr>
                                <td>
                                    <span class="fw-bold text-primary">
                                        <?= $h($codigoArquivo) ?>
                                    </span>
                                </td>

                                <td class="text-start">
                                    <?= $h($dxf->nome_original ?? '--') ?>

                                    <div class="text-muted small">
                                        <?= $formatarBytes($dxf->tamanho_bytes ?? 0) ?> | <?= $formatarDataHora($dxf->created_at ?? null) ?>
                                    </div>
                                </td>

                                <td><?= $h($prioridade) ?></td>

                                <td>
                                    <span class="badge bg-success">Carregado</span>
                                </td>

                                <td>
                                    <a
                                        href="<?= route('dispositivos.desenvolvimento.arquivo.download', ['id' => $dxf->id]) ?>"
                                        class="btn btn-sm btn-outline-primary"
                                    >
                                        Baixar
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="5" class="text-muted py-4">
                                Nenhum DXF adicionado até o momento.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php if (!empty($txtItensComprados)) : ?>
                <div class="card border-0 shadow-sm mt-3">
                    <div class="card-header bg-light py-2">
                        <h6 class="mb-0 fw-bold text-uppercase fs-7 text-muted">
                            TXTs de Itens Comprados
                        </h6>
                    </div>

                    <div class="card-body p-2">
                        <?php foreach ($txtItensComprados as $txt) : ?>
                            <div class="d-flex justify-content-between align-items-center border-bottom py-2 gap-2">
                                <div class="small text-truncate">
                                    <span title="<?= $h($txt->nome_original ?? '') ?>">
                                        <?= $h($txt->nome_original ?? '--') ?>
                                    </span>

                                    <div class="text-muted">
                                        <?= $formatarBytes($txt->tamanho_bytes ?? 0) ?> | <?= $formatarDataHora($txt->created_at ?? null) ?>
                                    </div>
                                </div>

                                <a
                                    href="<?= route('dispositivos.desenvolvimento.arquivo.download', ['id' => $txt->id]) ?>"
                                    class="btn btn-sm btn-outline-primary"
                                >
                                    Baixar
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="position-relative d-flex align-items-center py-3 pt-5">
                <div class="flex-grow-1 border-top"></div>
                <span class="mx-3 fw-bold text-uppercase fs-7">ITENS COMPRADOS E SIDERÚRGICOS</span>
                <div class="flex-grow-1 border-top"></div>
            </div>

            <form
                action="<?= route('dispositivos.desenvolvimento.itensCompradosTxt.store', ['ref' => $solicitacao->ref]) ?>"
                method="POST"
                enctype="multipart/form-data"
                id="formAdicionarItensTxt"
                class="d-inline-block"
            >
                <input
                    type="file"
                    name="itens_comprados_txt[]"
                    id="inputAdicionarItensTxt"
                    accept=".txt,text/plain"
                    multiple
                    class="d-none"
                    <?= $liberaCarregarAnexos ? '' : 'disabled' ?>
                    onchange="loading('show', true); document.getElementById('formAdicionarItensTxt').submit();"
                >

                <button
                    type="button"
                    class="btn btn-sm fw-semibold px-3 <?= $liberaCarregarAnexos ? 'text-white' : 'btn-secondary' ?>"
                    style="<?= $liberaCarregarAnexos ? 'background-color: #006A67; border-color: #006A67;' : '' ?>"
                    <?= $liberaCarregarAnexos ? "onclick=\"document.getElementById('inputAdicionarItensTxt').click();\"" : 'disabled' ?>
                    title="<?= $h($tooltipCarregarAnexos) ?>"
                >
                    <i class="fas fa-plus me-1"></i>
                    Adicionar Item
                </button>
            </form>

            <?php /* ---------- AQUISIÇÃO: resumo + pesquisa (2026-07-21) ---------- */ ?>
            <?php if (!empty($itensComprados)) : ?>

                <?php if (!$aquisicaoHabilitada) : ?>
                    <div class="alert alert-warning fs-7 mt-3 mb-0" role="alert">
                        <i class="bi bi-database-exclamation me-1"></i>
                        Controle de aquisição indisponível: rode a migration
                        <code>database/migrations/2026-07-21-aquisicao-itens-comprados.sql</code>.
                        A lista abaixo segue apenas para consulta.
                    </div>
                <?php endif; ?>

                <div class="row g-2 align-items-end mt-3">
                    <div class="col-12 col-md-5">
                        <label for="pesquisaItemAquisicao" class="form-label fs-7 fw-bold mb-1">
                            Pesquisar item (código, descrição, OC ou pedido)
                        </label>

                        <input
                            type="search"
                            id="pesquisaItemAquisicao"
                            class="form-control form-control-sm"
                            placeholder="Ex.: 1234567 ou CHAPA"
                            autocomplete="off"
                        >
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fs-7 fw-bold mb-1">Liquidação</label>

                        <div class="progress" style="height: 22px;">
                            <div
                                id="barraLiquidacao"
                                class="progress-bar bg-success"
                                role="progressbar"
                                style="width: <?= $percentualLiquidado ?>%;"
                                aria-valuenow="<?= $percentualLiquidado ?>"
                                aria-valuemin="0"
                                aria-valuemax="100"
                            ><?= $percentualLiquidado ?>%</div>
                        </div>

                        <small class="text-muted fs-8 d-block">
                            <span id="resumoLiquidados"><?= (int) $resumoAquisicao['liquidados'] ?></span>
                            de
                            <span id="resumoTotalItens"><?= (int) $resumoAquisicao['total'] ?></span>
                            liquidados —
                            <span id="resumoPendentes"><?= (int) $resumoAquisicao['pendentes'] ?></span>
                            pendente(s)
                        </small>

                        <small class="text-muted fs-8 d-block">
                            <i class="bi bi-arrow-repeat me-1"></i>
                            Pedido e liquidação são preenchidos automaticamente pela rotina do Logix.
                        </small>
                    </div>

                    <div class="col-12 col-md-3 d-flex flex-column gap-2">
                        <?php if ($aquisicaoEmAberto) : ?>
                            <button
                                type="button"
                                id="btnConcluirAquisicao"
                                class="btn btn-sm btn-success w-100"
                                data-ref="<?= (int) $solicitacao->ref ?>"
                                <?= $podeConcluirAquisicao ? '' : 'disabled' ?>
                                title="<?= $podeConcluirAquisicao
                                            ? 'Todos os itens liquidados — pode concluir'
                                            : 'Liquide todos os itens para concluir a aquisição' ?>"
                            >
                                <i class="bi bi-flag-fill me-1"></i> Concluir aquisição
                            </button>

                            <?php /* Bypass de TESTE: só aparece para matrículas autorizadas (2026-07-21 2ª rodada) */ ?>
                            <?php if ($podeBypassAquisicao && !$podeConcluirAquisicao) : ?>
                                <button
                                    type="button"
                                    id="btnBypassAquisicao"
                                    class="btn btn-sm btn-outline-warning w-100"
                                    data-ref="<?= (int) $solicitacao->ref ?>"
                                    title="TESTE: conclui a aquisição sem exigir liquidação"
                                >
                                    <i class="bi bi-fast-forward-fill me-1"></i> Pular liquidação (teste)
                                </button>
                            <?php endif; ?>
                        <?php elseif ($statusAquisicaoAtual === 'OK') : ?>
                            <span class="badge bg-success w-100 py-2">
                                <i class="bi bi-check-circle me-1"></i> Aquisição concluída
                            </span>
                        <?php elseif (!$slJaLiberada) : ?>
                            <span class="badge bg-secondary w-100 py-2 text-wrap">
                                Libere a SL para iniciar a aquisição
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover mt-4">
                    <thead>
                        <tr>
                            <th class="text-center">CÓDIGO</th>
                            <th class="text-center">REV</th>
                            <th class="text-center">DESCRIÇÃO</th>
                            <th class="text-center">QTDE</th>
                            <th class="text-center">TIPO</th>
                            <th class="text-center">N° OC</th>
                            <th class="text-center">PEDIDO</th>
                            <th class="text-center">STATUS</th>
                        </tr>
                    </thead>

                    <tbody class="align-middle text-center fs-7" id="tbodyItensAquisicao">
                        <?php if (!empty($itensComprados)) : ?>
                            <?php foreach ($itensComprados as $item) : ?>
                                <?php
                                $itemLiquidado = !empty($item->liquidado);
                                $itemOc        = (string)($item->n_oc ?? '');
                                $itemPedido    = (string)($item->pedido ?? '');

                                $itemSincronizado = !empty($item->sincronizado_em)
                                    ? $formatarDataHora($item->sincronizado_em)
                                    : '';

                                // Só o N° OC é digitável, e só com a aquisição em aberto
                                $editavel = $aquisicaoEmAberto && $aquisicaoHabilitada;

                                $textoBusca = trim(implode(' ', [
                                    (string)($item->codigo ?? ''),
                                    (string)($item->descricao ?? ''),
                                    $itemOc,
                                    $itemPedido,
                                ]));
                                ?>
                                <tr
                                    data-item-id="<?= $h($item->id) ?>"
                                    data-codigo="<?= $h($item->codigo ?? '') ?>"
                                    data-descricao="<?= $h($item->descricao ?? '') ?>"
                                    data-busca="<?= $h($textoBusca) ?>"
                                >
                                    <td data-label="Código"><?= $h($item->codigo ?? '--') ?></td>

                                    <td data-label="Rev"><?= $h($item->rev ?? '--') ?></td>

                                    <td data-label="Descrição" class="text-start">
                                        <?= $h($item->descricao ?? '--') ?>
                                    </td>

                                    <td data-label="Qtde"><?= $h($item->quantidade ?? '--') ?></td>

                                    <td data-label="Tipo"><?= $h($item->tipo ?? '--') ?></td>

                                    <td data-label="N° OC">
                                        <?php if ($editavel) : ?>
                                            <input
                                                type="text"
                                                class="form-control form-control-sm text-center"
                                                data-campo="n_oc"
                                                value="<?= $h($itemOc) ?>"
                                                placeholder="OC"
                                                maxlength="60"
                                                aria-label="Número da OC do item <?= $h($item->codigo ?? '') ?>"
                                            >
                                        <?php else : ?>
                                            <?= $itemOc !== '' ? $h($itemOc) : '--' ?>
                                        <?php endif; ?>
                                    </td>

                                    <?php /* Pedido e Status são preenchidos pela rotina do Logix — somente leitura */ ?>
                                    <td data-label="Pedido">
                                        <?php if ($itemPedido !== '') : ?>
                                            <?= $h($itemPedido) ?>
                                        <?php elseif ($itemOc !== '') : ?>
                                            <span class="text-muted fst-italic fs-8">aguardando Logix</span>
                                        <?php else : ?>
                                            --
                                        <?php endif; ?>
                                    </td>

                                    <td data-label="Status">
                                        <div class="d-flex align-items-center justify-content-center gap-2">
                                            <span
                                                data-selo-status
                                                class="badge <?= $itemLiquidado ? 'bg-success' : 'bg-secondary' ?>"
                                                title="<?= $itemSincronizado !== ''
                                                            ? 'Última consulta ao Logix: ' . $h($itemSincronizado)
                                                            : 'Ainda não consultado no Logix' ?>"
                                            ><?= $itemLiquidado ? 'Liquidado' : 'Pendente' ?></span>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>

                            <tr id="itensAquisicaoVazio" hidden>
                                <td colspan="8" class="text-muted py-4">
                                    Nenhum item corresponde à pesquisa.
                                </td>
                            </tr>
                        <?php else : ?>
                            <tr>
                                <td colspan="8" class="text-muted py-4">
                                    Nenhum item comprado ou siderúrgico listado.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-lg-4 pt-5 container-history">
            <div class="card shadow-sm card-history">
                <div class="card-header bg-light py-2">
                    <h6 class="mb-0 fw-bold text-uppercase fs-7 text-muted">
                        <i class="bi bi-clock-history me-2"></i>Histórico de Interações
                    </h6>
                </div>

                <div class="card-body p-0" style="max-height: 400px; overflow-y: auto;">
                    <div class="list-group list-group-flush shadow-none">
                        <?php foreach ($interacoes as $interacao) : ?>
                            <?php $data = new DateTime($interacao->created_at); ?>

                            <div class="list-group-item border-0 border-bottom p-3">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="fw-bold text-primary fs-7">
                                        <i class="bi bi-person-fill"></i> <?= strtoupper($h($interacao->usuario)) ?>
                                    </span>

                                    <small class="text-muted fs-8">
                                        <?= $data->format('d.m.Y - H:i') ?>
                                    </small>
                                </div>

                                <div class="ps-3 border-start border-2 ms-1">
                                    <p class="mb-1 text-dark fs-7">- <?= $h($interacao->mensagem) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <?php if (empty($interacoes)) : ?>
                            <div class="list-group-item border-0 p-3 text-muted">
                                Nenhuma interação registrada.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card-footer bg-white p-3">
                    <form action="<?= route('dispositivos.historico.store', ['ref' => $solicitacao->ref, 'tipo' => 'desenvolvimento']) ?>" method="POST">
                        <input type="hidden" name="ref" value="<?= $h($solicitacao->ref) ?>">

                        <input type="hidden" name="usuario" value="<?= $h($_SESSION['usuarioNome'] ?? '') ?>">

                        <div class="input-group">
                            <textarea name="mensagem" class="form-control fs-7" rows="2" placeholder="Digite uma nova interação..." style="resize: none;" required></textarea>

                            <button class="btn btn-primary" type="submit" title="Enviar">
                                <i class="bi bi-send-fill"></i>
                            </button>
                        </div>

                        <div class="d-flex justify-content-end mt-2">
                            <small class="text-muted fs-8">Clique no botão para enviar</small>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-3">
        <?php /* 8ª rodada — Liberar/Retornar é da INDUSTRIAL; aqui é só o status */ ?>
        <?php if ($slCancelada) : ?>
            <button type="button" class="btn btn-outline-secondary btn-sm w-100" disabled>
                <i class="bi bi-x-circle me-1"></i> SL Cancelada
            </button>
        <?php elseif ($slJaLiberada) : ?>
            <button type="button" class="btn btn-success btn-sm w-100" disabled title="Gerenciado pela Industrial">
                <i class="bi bi-check-circle me-1"></i> SL Liberada
            </button>
        <?php else : ?>
            <button type="button" class="btn btn-secondary btn-sm w-100" disabled title="A liberação é feita pela Industrial">
                <i class="bi bi-hourglass-split me-1"></i> Aguardando liberação
            </button>
        <?php endif; ?>
    </div>

    <div class="col-md-3">
        <button type="submit" class="btn btn-primary btn-sm w-100" onclick="openModal(<?= (int)$solicitacao->ref ?>, 'anexos')">Ver Anexo</button>
    </div>

    <div class="col-md-3">
        <button type="submit" class="btn btn-warning btn-sm w-100" onclick="loading('show')">Gerar PDF</button>
    </div>

    <div class="col-md-3">
        <button type="submit" class="btn btn-secondary btn-sm w-100" onclick="loading('show')">Abrir BOM</button>
    </div>
</div>

<?= $this->insert('templates/dt'); ?>