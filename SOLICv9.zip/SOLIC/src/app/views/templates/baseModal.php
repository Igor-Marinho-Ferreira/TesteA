    <link rel="stylesheet" href="<?= path()->css("/teste.css") ?>">

 
 
 <div class="header">
        <h3 class="headTitle"><?=  $headTitle ?></h3>
    </div>
     <hr>
    <div class="modal-body">
    <?= $this->section('modalContent') ?>
</div>

