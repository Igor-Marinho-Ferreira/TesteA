<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manutenção - Sistema temporariamente indisponível</title>

    <style>
        html,
        body {
            height: 100%;
            margin: 0;
        }

        html {
            font-size: 62.5%;
        }

        body {
            font-family: "Lato", sans-serif;
            font-size: 1.5rem;
            color: #293b49;
            background-color: #f7f9fb;
        }

        a {
            text-decoration: none;
        }

        .center {
            min-height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            padding: 2rem;
            box-sizing: border-box;
        }

        .maintenance {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
        }

        .number {
            font-weight: 900;
            font-size: 15rem;
            line-height: 1;
            color: #293b49;
        }

        .illustration {
            position: relative;
            width: 12.2rem;
            height: 13rem;
            margin: 0 2.1rem;
        }

        .circle {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 12.2rem;
            height: 11.4rem;
            border-radius: 50%;
            background-color: #293b49;
        }

        .clip {
            position: absolute;
            bottom: 0.3rem;
            left: 50%;
            transform: translateX(-50%);
            overflow: hidden;
            width: 12.5rem;
            height: 13rem;
            border-radius: 0 0 50% 50%;
        }

        .paper {
            position: absolute;
            bottom: -0.3rem;
            left: 50%;
            transform: translateX(-50%);
            width: 9.2rem;
            height: 12.4rem;
            border: 0.3rem solid #293b49;
            background-color: white;
            border-radius: 0.8rem;
        }

        .paper::before {
            content: "";
            position: absolute;
            top: -0.7rem;
            right: -0.7rem;
            width: 1.4rem;
            height: 1rem;
            background-color: white;
            border-bottom: 0.3rem solid #293b49;
            transform: rotate(45deg);
        }

        .face {
            position: relative;
            margin-top: 2.3rem;
        }

        .eyes {
            position: absolute;
            top: 0;
            left: 2.4rem;
            width: 4.6rem;
            height: 0.8rem;
        }

        .eye {
            position: absolute;
            bottom: 0;
            width: 0.8rem;
            height: 0.8rem;
            border-radius: 50%;
            background-color: #293b49;
            animation-name: eye;
            animation-duration: 4s;
            animation-iteration-count: infinite;
            animation-timing-function: ease-in-out;
        }

        .eye-left {
            left: 0;
        }

        .eye-right {
            right: 0;
        }

        @keyframes eye {
            0% {
                height: 0.8rem;
            }

            50% {
                height: 0.8rem;
            }

            52% {
                height: 0.1rem;
            }

            54% {
                height: 0.8rem;
            }

            100% {
                height: 0.8rem;
            }
        }

        .rosyCheeks {
            position: absolute;
            top: 1.6rem;
            width: 1rem;
            height: 0.2rem;
            border-radius: 50%;
            background-color: #fdabaf;
        }

        .rosyCheeks-left {
            left: 1.4rem;
        }

        .rosyCheeks-right {
            right: 1.4rem;
        }

        .mouth {
            position: absolute;
            top: 3.1rem;
            left: 50%;
            width: 1.6rem;
            height: 0.2rem;
            border-radius: 0.1rem;
            transform: translateX(-50%);
            background-color: #293b49;
        }

        .gear {
            position: absolute;
            top: 5.2rem;
            left: 50%;
            width: 3rem;
            height: 3rem;
            margin-left: -1.5rem;
            border: 0.4rem solid #04cba0;
            border-radius: 50%;
            animation: spin 3s linear infinite;
        }

        .gear::before,
        .gear::after {
            content: "";
            position: absolute;
            background-color: #04cba0;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            border-radius: 0.2rem;
        }

        .gear::before {
            width: 4.2rem;
            height: 0.5rem;
        }

        .gear::after {
            width: 0.5rem;
            height: 4.2rem;
        }

        .gear-center {
            position: absolute;
            width: 1rem;
            height: 1rem;
            background-color: white;
            border: 0.3rem solid #04cba0;
            border-radius: 50%;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            z-index: 2;
        }

        @keyframes spin {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        .title {
            margin-top: 5rem;
            font-size: 2.8rem;
            font-weight: 700;
            color: #293b49;
        }

        .text {
            margin-top: 1.2rem;
            max-width: 52rem;
            font-weight: 300;
            font-size: 1.7rem;
            line-height: 1.6;
            color: #52616d;
        }

        .button {
            margin-top: 4rem;
            padding: 1.2rem 3rem;
            color: white;
            background-color: #04cba0;
            border-radius: 8px;
            font-weight: 700;
            transition: background-color 0.2s ease;
        }

        .button:hover {
            background-color: #01ac88;
        }

        @media (max-width: 600px) {
            .number {
                font-size: 8rem;
            }

            .illustration {
                width: 9rem;
                height: 10rem;
                margin: 0 1.2rem;
            }

            .circle {
                width: 9rem;
                height: 8.5rem;
            }

            .clip {
                width: 9.5rem;
                height: 10rem;
            }

            .paper {
                width: 7rem;
                height: 9.5rem;
            }

            .eyes {
                left: 1.7rem;
                width: 3.8rem;
            }

            .rosyCheeks-left {
                left: 1rem;
            }

            .rosyCheeks-right {
                right: 1rem;
            }

            .gear {
                top: 4.5rem;
            }

            .title {
                font-size: 2.2rem;
            }

            .text {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>
    <div class="center">
        <div class="maintenance">
            <div class="number">5</div>

            <div class="illustration">
                <div class="circle"></div>

                <div class="clip">
                    <div class="paper">
                        <div class="face">
                            <div class="eyes">
                                <div class="eye eye-left"></div>
                                <div class="eye eye-right"></div>
                            </div>

                            <div class="rosyCheeks rosyCheeks-left"></div>
                            <div class="rosyCheeks rosyCheeks-right"></div>
                            <div class="mouth"></div>

                            <div class="gear">
                                <div class="gear-center"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="number">3</div>
        </div>

        <div class="title">Sistema em manutenção</div>

        <div class="text">
            Devido ao relato de alguns problemas, estamos realizando a manutenção no sistema. Por favor, tente acessar novamente em breve.
        </div>

        <a class="button" href="http://172.29.5.2/greenbrier">Voltar para o sistema</a>
    </div>
</body>

</html>