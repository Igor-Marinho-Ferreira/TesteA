<?php
$this->layout("templates/base", [
    "backTo"    => route("dispositivos.menu"),
    "webTitle"  => "Dispositivos - Itens por Descrição",
    "cardTitle" => "ITENS COMPRADOS - CONSOLIDADO POR DESCRIÇÃO",
    "styles"    => [
        path()->css("cortes.css")
    ],
    "js" => [
        path()->js("itensConsolidado.js"),
    ],
]);

$h = function ($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
};

$n = function ($valor, $dec = 0) {
    return number_format((float) $valor, $dec, ',', '.');
};

$grupos = $grupos ?? [];
$totais = $totais ?? ['itens' => 0, 'descricoes' => 0, 'sls' => 0];
$temAquisicao = !empty($temAquisicao);
$pronta = !empty($tabelaPronta);
$colspan = $temAquisicao ? 9 : 7;
?>

<?php if (!$pronta) : ?>
    <div class="alert alert-warning fs-7" role="alert">
        <i class="bi bi-database-exclamation me-1"></i>
        Não há itens comprados cadastrados. Eles chegam da lista de materiais (BOM) das SLs
        — pelo Access (uploadBomVba) ou pela tela de desenvolvimento.
    </div>
<?php endif; ?>

<?php /* ------------------------- RESUMO + BUSCA ------------------------- */ ?>
<div class="row g-2 mb-3">
    <div class="col-6 col-md-2">
        <div class="box-corte text-center py-2">
            <div class="rotulo-corte">Descrições</div>
            <div class="fs-4 fw-bold"><?= (int) $totais['descricoes'] ?></div>
        </div>
    </div>
    <div class="col-6 col-md-2">
        <div class="box-corte text-center py-2">
            <div class="rotulo-corte">Itens</div>
            <div class="fs-4 fw-bold"><?= (int) $totais['itens'] ?></div>
        </div>
    </div>
    <div class="col-6 col-md-2">
        <div class="box-corte text-center py-2">
            <div class="rotulo-corte">SLs envolvidas</div>
            <div class="fs-4 fw-bold"><?= (int) $totais['sls'] ?></div>
        </div>
    </div>
    <div class="col-12 col-md-6">
        <label for="buscaItem" class="form-label fs-7 fw-bold mb-1">Pesquisar (descrição, código ou SL)</label>
        <input type="search" id="buscaItem" class="form-control form-control-sm"
               placeholder="Ex.: PARAFUSO, 1234567 ou SL4790" autocomplete="off">
    </div>
</div>

<?php /* ------------------------- GRUPOS ------------------------- */ ?>
<?php foreach ($grupos as $grupo) : ?>
    <?php
    $buscaGrupo = mb_strtoupper($grupo->rotulo);
    ?>
    <div class="grupo-espessura mb-4 grupo-item" data-busca="<?= $h($buscaGrupo) ?>">
        <div class="d-flex flex-wrap justify-content-between align-items-center py-2 px-2 cabecalho-espessura">
            <span class="fw-bold text-start"><?= $h($grupo->rotulo) ?></span>
            <span class="fs-8">
                Qtde total: <strong class="text-danger"><?= $h($n($grupo->qtdeTotal, 0)) ?></strong>
                &nbsp;|&nbsp; SLs: <strong class="text-primary"><?= (int) $grupo->qtdSls ?></strong>
                &nbsp;|&nbsp; Linhas: <strong><?= count($grupo->linhas) ?></strong>
            </span>
        </div>

        <div class="table-responsive">
            <table class="table table-sm tabela-planos align-middle mb-0">
                <thead>
                    <tr>
                        <th>N° SL</th>
                        <th>Cod Z</th>
                        <th>Vagão/Local</th>
                        <th>Projetista</th>
                        <th>Código</th>
                        <th>Rev</th>
                        <th class="text-end">Qtde</th>
                        <th>Tipo</th>
                        <?php if ($temAquisicao) : ?>
                            <th>N° OC</th>
                            <th>Status</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($grupo->linhas as $l) : ?>
                        <?php
                        $buscaLinha = mb_strtoupper(implode(' ', [
                            $grupo->rotulo, (string) $l->codigo, (string) $l->sl, (string) $l->cod_z_formatado,
                        ]));
                        ?>
                        <tr class="linha-item" data-busca="<?= $h($buscaLinha) ?>">
                            <td>
                                <?php if (!empty($l->ref)) : ?>
                                    <a href="<?= route('dispositivos.desenvolvimento.info', ['ref' => $l->ref]) ?>">
                                        <?= $h($l->sl) ?>
                                    </a>
                                <?php else : ?>
                                    --
                                <?php endif; ?>
                            </td>
                            <td><?= $h($l->cod_z_formatado) ?></td>
                            <td><?= $h($l->vagao) ?><?= $l->aplicacao ? ' / ' . $h($l->aplicacao) : '' ?></td>
                            <td><?= $h($l->projetista) ?></td>
                            <td><?= $h($l->codigo ?? '--') ?></td>
                            <td><?= $h($l->rev ?? '--') ?></td>
                            <td class="text-end"><?= $h($n($l->quantidade ?? 0, 0)) ?></td>
                            <td><?= $h($l->tipo ?? '--') ?></td>
                            <?php if ($temAquisicao) : ?>
                                <td><?= $h($l->n_oc ?? '') ?: '--' ?></td>
                                <td>
                                    <span class="badge <?= !empty($l->liquidado) ? 'bg-success' : 'bg-secondary' ?>">
                                        <?= !empty($l->liquidado) ? 'Liquidado' : 'Pendente' ?>
                                    </span>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr class="linha-total">
                        <td colspan="6" class="text-end fw-bold">Qtde total desta descrição:</td>
                        <td class="text-end fw-bold text-danger"><?= $h($n($grupo->qtdeTotal, 0)) ?></td>
                        <td colspan="<?= $colspan - 7 ?>"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php endforeach; ?>

<?php if ($pronta && empty($grupos)) : ?>
    <p class="text-muted py-4">Nenhum item comprado cadastrado ainda.</p>
<?php endif; ?>

<p id="semResultado" class="text-muted py-4 d-none">Nenhum item corresponde à pesquisa.</p>
