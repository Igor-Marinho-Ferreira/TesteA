<?php

namespace src\app\services;

use PDO;
use src\app\database\Database;

/**
 * Consulta de Ordens de Compra no Logix (Informix).
 *
 * ┌──────────────────────────────────────────────────────────────────────────┐
 * │  ESTE É O ÚNICO ARQUIVO QUE PRECISA SER AJUSTADO PARA A ROTINA FUNCIONAR │
 * └──────────────────────────────────────────────────────────────────────────┘
 *
 * Preencha a constante SQL_CONSULTA_OC (logo abaixo) com a query real do
 * Logix. Nada mais no sistema precisa mudar — a rotina de sincronização, a
 * gravação no MySQL, o histórico e a tela já estão prontos e apenas consomem
 * o retorno deste serviço.
 *
 * Enquanto a query não for preenchida, `configurado()` devolve false e a
 * rotina termina sem fazer nada, registrando o motivo no log. Nunca quebra
 * a aplicação nem marca item algum como liquidado por engano.
 */
class LogixOrdemCompraService
{
    /**
     * ═══════════════════════════════════════════════════════════════════════
     *  PREENCHA AQUI
     * ═══════════════════════════════════════════════════════════════════════
     *
     * A query recebe UM parâmetro nomeado repetido conforme a quantidade de
     * OCs consultadas — o placeholder `:ocs` é substituído em tempo de
     * execução por uma lista de binds (:oc0, :oc1, ...). Você só precisa
     * deixar o `IN (:ocs)` no lugar certo.
     *
     * A query DEVE retornar exatamente estas três colunas (use alias):
     *
     *   num_oc      -> número da ordem de compra (casa com itens.n_oc)
     *   num_pedido  -> número do pedido de compra (ou NULL se ainda não tem)
     *   liquidado   -> 1 / 'S' / 'T' quando liquidada; 0 / 'N' / 'F' quando não
     *
     * Exemplo do formato esperado (nomes de tabela/campo FICTÍCIOS —
     * substitua pelos reais da sua base):
     *
     *   SELECT
     *       oc.num_ordem            AS num_oc,
     *       ped.num_pedido          AS num_pedido,
     *       CASE WHEN ped.situacao = 'L' THEN 1 ELSE 0 END AS liquidado
     *     FROM <tabela_ordem_compra> oc
     *     LEFT JOIN <tabela_pedido>  ped ON ped.num_ordem = oc.num_ordem
     *    WHERE oc.num_ordem IN (:ocs)
     *
     * Deixe como string vazia para manter a rotina desligada.
     */
    private const SQL_CONSULTA_OC = '';

    /** Valores que o Logix pode usar para "liquidado = sim". */
    private const VALORES_LIQUIDADO = ['1', 'S', 'T', 'Y', 'L', 'SIM', 'TRUE'];

    /**
     * A query já foi preenchida?
     * Enquanto for false a rotina de sincronização não roda.
     */
    public static function configurado(): bool
    {
        return trim(self::SQL_CONSULTA_OC) !== '';
    }

    /**
     * Consulta um lote de OCs no Logix.
     *
     * @param  array<int, string> $ocs Números de OC (já limpos/únicos)
     * @return array<string, array{pedido: ?string, liquidado: bool}>
     *         Indexado pelo número da OC. OC não encontrada não aparece no
     *         retorno — o chamador trata como "ainda sem resposta".
     */
    public static function consultarPorOcs(array $ocs): array
    {
        if (!self::configurado()) {
            return [];
        }

        $ocs = array_values(array_unique(array_filter(array_map('trim', $ocs), function ($oc) {
            return $oc !== '';
        })));

        if (empty($ocs)) {
            return [];
        }

        try {
            $pdo = Database::get('logix');

            if (!$pdo) {
                error_log('Logix: não foi possível obter a conexão.');
                return [];
            }

            // Monta os binds (:oc0, :oc1, ...) no lugar do marcador :ocs
            $binds  = [];
            $nomes  = [];

            foreach ($ocs as $indice => $oc) {
                $nome          = ":oc{$indice}";
                $nomes[]       = $nome;
                $binds[$nome]  = $oc;
            }

            $sql = str_replace(':ocs', implode(', ', $nomes), self::SQL_CONSULTA_OC);

            $stmt = $pdo->prepare($sql);
            $stmt->execute($binds);

            $resultado = [];

            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $linha) {
                $numOc = trim((string) ($linha['num_oc'] ?? ''));

                if ($numOc === '') {
                    continue;
                }

                $pedido = trim((string) ($linha['num_pedido'] ?? ''));

                $resultado[$numOc] = [
                    'pedido'    => $pedido !== '' ? $pedido : null,
                    'liquidado' => self::interpretarLiquidado($linha['liquidado'] ?? null),
                ];
            }

            return $resultado;
        } catch (\Throwable $e) {
            // Falha no Logix não pode derrubar a rotina nem a aplicação.
            error_log('Logix: falha ao consultar OCs — ' . $e->getMessage());

            return [];
        }
    }

    /**
     * Normaliza o indicador de liquidação.
     * Aceita 1/0, S/N, T/F, true/false — o Logix varia conforme a versão.
     */
    private static function interpretarLiquidado(mixed $valor): bool
    {
        if (is_bool($valor)) {
            return $valor;
        }

        if (is_numeric($valor)) {
            return ((int) $valor) === 1;
        }

        return in_array(
            strtoupper(trim((string) $valor)),
            self::VALORES_LIQUIDADO,
            true
        );
    }
}
