<?php

namespace src\app\controllers;

use PDO;
use src\app\database\entities\DxfPlanoCorte;
use src\app\database\entities\Espessura;
use src\app\database\entities\Perfil;
use src\support\View;

/**
 * CÁLCULO DE PESO / CONSOLIDADO POR ESPESSURA — 2026-07-21 (6ª rodada).
 *
 * Resolve o problema "na lista não fica claro para quais projetos preciso da
 * mesma espessura": junta TODOS os planos de corte (dxf_planos_corte, da 5ª
 * rodada) e agrupa por espessura, calculando área e peso teórico por linha e
 * por grupo, além da quantidade de chapas a comprar.
 *
 * Peso teórico da chapa:
 *   Área(m²) = Larg(mm) × Comp(mm) × Qtde / 1.000.000
 *   Peso(kg) = Área(m²) × Espessura(m) × Densidade(kg/m³)
 */
class CalculoPesoController
{
    /* ------------------------------------------------------------------ */
    /*  CONSOLIDADO POR ESPESSURA                                          */
    /* ------------------------------------------------------------------ */

    function consolidadoView(): View
    {
        if (!DxfPlanoCorte::getPDO() || !$this->planosDisponiveis()) {
            return view('cortes.calculoPeso', [
                'grupos'        => [],
                'totalGeral'    => ['area' => 0.0, 'peso' => 0.0, 'linhas' => 0],
                'espessuras'    => Espessura::temColunasPeso() ? Espessura::listar() : [],
                'tabelaPronta'  => $this->planosDisponiveis(),
                'temColunaPeso' => Espessura::temColunasPeso(),
            ]);
        }

        $planos      = $this->planosComContexto();
        $mapaEsp     = Espessura::temColunasPeso() ? Espessura::mapaPorValorNumerico() : [];

        $grupos     = [];
        $totalArea  = 0.0;
        $totalPeso  = 0.0;
        $totalLinhas = 0;

        foreach ($planos as $plano) {
            $chaveEsp = Espessura::normalizarEspessura($plano->espessura);
            $rotulo   = trim((string) $plano->espessura) !== '' ? trim((string) $plano->espessura) : 'Sem espessura';

            // Densidade da parametrização (por espessura) ou o padrão do aço
            $espCad    = ($chaveEsp !== null && isset($mapaEsp[$chaveEsp])) ? $mapaEsp[$chaveEsp] : null;
            $densidade = $espCad ? (float) $espCad->densidade : Espessura::DENSIDADE_PADRAO;

            $espMm = $chaveEsp !== null ? (float) $chaveEsp : 0.0;
            $larg  = (int) $plano->largura;
            $comp  = (int) $plano->comprimento;
            $qtde  = max(1, (int) $plano->qtde);

            $area = ($larg * $comp * $qtde) / 1000000.0;      // m²
            $peso = $area * ($espMm / 1000.0) * $densidade;    // kg

            if (!isset($grupos[$rotulo])) {
                $grupos[$rotulo] = (object) [
                    'rotulo'           => $rotulo,
                    'linhas'           => [],
                    'area'             => 0.0,
                    'peso'             => 0.0,
                    'densidade'        => $densidade,
                    'peso_chapa_padrao' => $espCad ? (float) ($espCad->peso_chapa_padrao ?? 0) : 0.0,
                ];
            }

            $plano->area = $area;
            $plano->peso = $peso;

            $grupos[$rotulo]->linhas[] = $plano;
            $grupos[$rotulo]->area    += $area;
            $grupos[$rotulo]->peso    += $peso;

            $totalArea  += $area;
            $totalPeso  += $peso;
            $totalLinhas++;
        }

        // Quantidade de chapas a comprar por grupo (peso total / chapa padrão)
        foreach ($grupos as $g) {
            $g->chapas = ($g->peso_chapa_padrao > 0)
                ? (int) ceil($g->peso / $g->peso_chapa_padrao)
                : null;
        }

        // Ordena os grupos pela espessura numérica (Sem espessura por último)
        uasort($grupos, function ($a, $b) {
            $na = Espessura::normalizarEspessura($a->rotulo);
            $nb = Espessura::normalizarEspessura($b->rotulo);

            if ($na === null && $nb === null) return 0;
            if ($na === null) return 1;
            if ($nb === null) return -1;

            return (float) $na <=> (float) $nb;
        });

        return view('cortes.calculoPeso', [
            'grupos'        => array_values($grupos),
            'totalGeral'    => ['area' => $totalArea, 'peso' => $totalPeso, 'linhas' => $totalLinhas],
            'espessuras'    => Espessura::temColunasPeso() ? Espessura::listar() : [],
            'tabelaPronta'  => true,
            'temColunaPeso' => Espessura::temColunasPeso(),
        ]);
    }

    /** Há a tabela de planos de corte? */
    private function planosDisponiveis(): bool
    {
        try {
            $pdo = DxfPlanoCorte::getPDO();

            if (!$pdo) {
                return false;
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                  FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = 'bd_device_request'
                   AND TABLE_NAME   = 'dxf_planos_corte'
            ");
            $stmt->execute();

            return ((int) $stmt->fetchColumn()) > 0;
        } catch (\Throwable $e) {
            error_log('Falha ao verificar dxf_planos_corte: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Todos os planos de corte com os dados de contexto (DX, SL, projeto...).
     *
     * @return array<int, object>
     */
    private function planosComContexto(): array
    {
        try {
            $pdo = DxfPlanoCorte::getPDO();

            if (!$pdo) {
                return [];
            }

            $stmt = $pdo->prepare("
                SELECT
                    pc.id, pc.dxf_codigo, pc.n_prog, pc.espessura,
                    pc.largura, pc.comprimento, pc.qtde, pc.reserva, pc.ordem,
                    dc.ref            AS ref,
                    dc.descricao      AS descricao_dx,
                    f.cod_z           AS cod_z,
                    f.descricao       AS descricao_sl,
                    f.vagao           AS vagao,
                    f.lote            AS lote,
                    f.aplicacao       AS aplicacao,
                    f.conceito_proj      AS conceito_proj,
                    f.detalhamento_proj  AS detalhamento_proj
                  FROM bd_device_request.dxf_planos_corte pc
             LEFT JOIN bd_device_request.dxf_controle dc ON dc.codigo = pc.dxf_codigo
             LEFT JOIN bd_device_request.fila f ON f.ref = dc.ref
              ORDER BY pc.espessura ASC, pc.dxf_codigo ASC, pc.ordem ASC
            ");

            $stmt->execute();

            $planos = $stmt->fetchAll(PDO::FETCH_OBJ) ?: [];

            foreach ($planos as $p) {
                $p->cod_z_formatado = $this->formatarZ($p->cod_z ?? '');
                $p->projetista      = trim((string) ($p->detalhamento_proj ?? '')) !== ''
                    ? $p->detalhamento_proj
                    : ($p->conceito_proj ?? '');
                $p->projeto = $this->projeto($p);
                $p->descricao = trim((string) ($p->descricao_dx ?? '')) !== ''
                    ? $p->descricao_dx
                    : ($p->descricao_sl ?? '');
                $p->sl = $p->ref ? ('SL' . str_pad((string) $p->ref, 4, '0', STR_PAD_LEFT)) : '';
            }

            return $planos;
        } catch (\Throwable $e) {
            error_log('Falha ao consolidar planos de corte: ' . $e->getMessage());
            return [];
        }
    }

    private function projeto(object $o): string
    {
        $vagao = trim((string) ($o->vagao ?? ''));
        $lote  = trim((string) ($o->lote ?? ''));

        if ($vagao === '' && $lote === '') return '';
        if ($lote === '') return $vagao;

        return $vagao . '_' . $lote;
    }

    private function formatarZ($codZ): string
    {
        $limpo = trim(str_ireplace('Z', '', (string) $codZ));
        return $limpo !== '' ? 'Z' . $limpo : '';
    }

    /* ------------------------------------------------------------------ */
    /*  CALCULADORA DE PERFIS                                              */
    /* ------------------------------------------------------------------ */

    function perfisView(): View
    {
        return view('cortes.calculoPerfis', [
            'perfis'       => Perfil::tabelaExiste() ? Perfil::listar() : [],
            'tipos'        => Perfil::TIPOS,
            'tabelaPronta' => Perfil::tabelaExiste(),
        ]);
    }
}
