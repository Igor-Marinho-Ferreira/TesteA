<?php
namespace src\app\controllers;

use src\app\database\entities\Conta;
use src\app\database\entities\Estagio;
use src\app\database\entities\Vagao;
use src\app\database\entities\Usuario;
use src\app\database\entities\Solicitacao;
use src\app\database\entities\Historico;
use src\app\database\entities\Projeto;
use src\app\requests\solicProjeto\StoreRequest;
use src\support\Request;
use src\support\Json;
use src\support\View;
use DateTime;
use src\app\database\entities\Acompanhamento;
use src\app\database\entities\Requisito;
use src\app\database\entities\Anexo;
use src\app\requests\historico\HistoricoRequest;

class SolicitacaoController
{
    public static $USUARIO_LOGADO = null;

    /**
     * Exibe a view principal de cadastro e listagem de usuários.
     *
     * @return View Retorna a view 'parametrizacao.usuario' com a lista de todos os usuários.
     */
    function solicitacaoView(): View
    {

        if (isset($_SESSION['user']['nome'])) {
            $nomeDoUsuario = $_SESSION['user']['nome'];
            self::$USUARIO_LOGADO = $nomeDoUsuario;
        }

        $date = new DateTime();
        $todayIs = $date->format('Y-m-d');
        $role = Usuario::getSolicRole($nomeDoUsuario);
        $contas = Conta::getContasByRole($role);
        $nSl = Solicitacao::getNumSL();



        return view('solicitacao.solicitacao', [

            "estagios" => Estagio::getAll(),
            "vagoesInfos" => Vagao::getDistinctWagons(),
            "contas" => $contas,
            "solicitante" => $nomeDoUsuario,
            "todayIs" => $todayIs,
            "nSL" => $nSl
        ]);
    }


    function menuParametrizacaoView(): View
    {


        return view('menus.menuParametrizacao', []);
    }


    function modalConfirmZ(): View
    {

        return view('modals.codigoZ.modal', []);
    }

    function modalValidacao(string $ref): View
    {

        return view('modals.validacao.modal', [
            'ref' => $ref
        ]);
    }


    function modalAnexos(string $ref): View
    {
        $anexos = Anexo::getAnexosTratados($ref);
        return view('modals.anexos.modal', [
            'ref' => $ref,
            'anexos' => $anexos
        ]);
    }
    function modalRequisitos(string $ref): View
    {
     
        return view('modals.requisitos.modal', [
            'ref' => $ref,
            'requisitos' => Requisito::getAllByRef($ref)   
            ]);
    }

    function modalCancelarSl(string $ref): View

    {

        return view('modals.cancelaSl.modal', [

            'ref' => $ref

        ]);
    }


    function getProjectInfos()
    {
        $projectNumberRaw = Request::query('projectNumber');

        $projectNumber = ltrim($projectNumberRaw, 'Zz');



        $infos = Projeto::getProjectInfos($projectNumber);
        if (!$infos) {
            return Json::return([
                'message' => 'Código Z não encontrado',
                'infos' => null
            ], 404);
        }

        $status = Projeto::getProjectStatus($projectNumber);

        return Json::return([
            'message' => 'Código Z encontrado',
            'infos' => $infos,
            'status' => $status
        ], 200);
    }

    function getRole()
    {
        $nomeSolic = Request::query('solic');

        $role = Usuario::getSolicRole($nomeSolic);
        if (!$role) {
            return Json::return([
                'message' => 'Usuário não encontrado',
                'role' => null
            ], 404);
        }

        return Json::return([
            'message' => 'Usuário encontrado',
            'role' => $role
        ], 200);
    }



    function storeSolicitacao(StoreRequest $request)
    {

        $data2Save = $request->getSolicitacaoData();
        $requisitos2save = $request->getRequisitosData();
        $anexos2save = $request->getAnexosData();
        $fila2save = $request->getFilaData();
        $numSL = Solicitacao::getNumSL();
        $data2Save['ref'] = $numSL;
        $solicitacao = Solicitacao::create($data2Save);

        if (!$solicitacao) {
            return redirect()->route("dispositivos.solicitacao")->withError("Não foi possível salvar o registro");
        }

        if ($solicitacao) {
            $executeFila = Solicitacao::storeFila($fila2save, $solicitacao['ref'], 'bd_device_request.fila');
            $executeRequisitos = Solicitacao::storeRepeticao($requisitos2save, $solicitacao['ref'], 'bd_device_request.requisitos');
            $executeAnexos = Solicitacao::storeRepeticao($anexos2save, $solicitacao['ref'], 'bd_device_request.anexos');

            // Copia os anexos para a pasta do Access (web -> Access)
            $this->copiarAnexosParaAccess($solicitacao['ref'], $anexos2save);
            $executeHistorico = Historico::create([
                'ref' => $solicitacao['ref'],
                'mensagem'       => $solicitacao['escopo'],
                'usuario'        => $_SESSION['usuarioNome'],
            ]);

            if (!$executeRequisitos || !$executeAnexos || !$executeFila)
                return redirect()->route("dispositivos.solicitacao")->withError("Solicitação salva, mas **falha** ao salvar os campos dinâmicos.");
        }

        
        return redirect()->route("dispositivos.acompanhamento")->withSuccess("Registro salvo! 🎉");
    }

    /**
     * Copia os anexos enviados pela web para a pasta do Access (pasta mapeada/montada).
     * 1º PDF -> .Files/SL{ref}.pdf (o que o Access abre); os demais -> .Files/SL{ref}/.
     */
    private function copiarAnexosParaAccess($ref, array $anexos): void
    {
        if (empty($anexos)) return;

        $base = rtrim($_ENV['APP_STORAGE_MAPPED'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') return; // sem storage-mapped configurado -> não faz nada

        $filesDir = $base . '/.Files';
        if (!is_dir($filesDir)) @mkdir($filesDir, 0777, true);

        $refFmt = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT); // ex.: SL4001
        $pdfPrincipalUsado = false;

        foreach ($anexos as $a) {
            $origem = $a['anexo'] ?? '';
            if ($origem === '' || !is_file($origem)) continue;

            $ext = strtolower(pathinfo($origem, PATHINFO_EXTENSION));

            if (!$pdfPrincipalUsado && $ext === 'pdf') {
                @copy($origem, $filesDir . '/' . $refFmt . '.pdf');   // .Files/SL{ref}.pdf
                $pdfPrincipalUsado = true;
            } else {
                $sub = $filesDir . '/' . $refFmt;
                if (!is_dir($sub)) @mkdir($sub, 0777, true);
                @copy($origem, $sub . '/' . basename($origem));       // extras em .Files/SL{ref}/
            }
        }
    }


    /**
     * Recebe uma solicitação criada no Access (VBA), gera o Ref no MySQL
     * de forma atômica (GET_LOCK) e grava em solicitacoes + fila.
     * Devolve { "ref": NNNN } para o VBA usar no INSERT do Access.
     *
     * Regra de solicitante:
     * Access manda o nome no padrão solicitantes_access.
     * MySQL salva o nome no padrão usuarios.
     */
    function salvarVba()
    {
        $pdo = Solicitacao::getPDO();

        $dataSql = $this->dataBR2SQL(Request::input('data_solicitacao'));

        // Access -> MySQL
        // O Access manda o nome como está em bd_device_request.solicitantes_access.
        // Aqui convertemos para o nome usado em bd_device_request.usuarios.
        $solicitanteAccess  = Request::input('solicitante') ?? '';
        $solicitanteSistema = Usuario::nomeSistemaPorNomeAccess($solicitanteAccess);

        try {
            // Serializa a emissão do número NESTA conexão (evita Ref duplicado)
            $pdo->query("SELECT GET_LOCK('solic_ref', 10)")->fetchColumn();

            // Próximo Ref = MAX + 1
            $ref = (int) $pdo->query(
                "SELECT COALESCE(MAX(ref), 0) + 1 FROM bd_device_request.solicitacoes"
            )->fetchColumn();

            // Reserva o Ref já inserindo em solicitacoes (mesma conexão do lock)
            $stmt = $pdo->prepare(
                "INSERT INTO bd_device_request.solicitacoes
                (id, ref, descricao, solicitante, data_solicitacao, cod_z, aplicacao, vagao, lote, conta, classe, escopo, created_at)
                VALUES (:id, :ref, :descricao, :solicitante, :data_solicitacao, :cod_z, :aplicacao, :vagao, :lote, :conta, :classe, :escopo, :created_at)"
            );

            $stmt->execute([
                'id'               => \Ramsey\Uuid\Rfc4122\UuidV4::uuid4()->toString(),
                'ref'              => $ref,
                'descricao'        => Request::input('descricao'),
                'solicitante'      => $solicitanteSistema,
                'data_solicitacao' => $dataSql,
                'cod_z'            => Request::input('cod_z'),
                'aplicacao'        => Request::input('aplicacao'),
                'vagao'            => Request::input('vagao'),
                'lote'             => Request::input('lote'),
                'conta'            => Request::input('conta'),
                'classe'           => Request::input('classe'),
                'escopo'           => Request::input('historico'),
                'created_at'       => date('Y-m-d H:i:s'),
            ]);
        } catch (\Exception $e) {
            $pdo->query("SELECT RELEASE_LOCK('solic_ref')")->fetchColumn();

            return Json::return([
                'error' => 'Falha ao gerar Ref: ' . $e->getMessage()
            ], 500);
        }

        // Libera o lock assim que o Ref está reservado
        $pdo->query("SELECT RELEASE_LOCK('solic_ref')")->fetchColumn();

        // Grava na fila (status PENDENTE/PARADO via storeFila)
        Solicitacao::storeFila([
            'descricao'        => Request::input('descricao'),
            'solicitante'      => $solicitanteSistema,
            'cod_z'            => Request::input('cod_z'),
            'aplicacao'        => Request::input('aplicacao'),
            'vagao'            => Request::input('vagao'),
            'lote'             => Request::input('lote'),
            'conta'            => Request::input('conta'),
            'classe'           => Request::input('classe'),
            'historico'        => Request::input('historico'),
            'data_solicitacao' => $dataSql,
            'prio'             => 99,
        ], $ref, 'bd_device_request.fila');

        // Histórico inicial.
        // Aqui mantemos o usuário no padrão do Access, porque o histórico volta para o Access no CSV.
        Historico::create([
            'ref'      => $ref,
            'usuario'  => $solicitanteAccess,
            'mensagem' => Request::input('historico'),
        ]);

        return Json::return(['ref' => $ref], 200);
    }

    /**
     * Converte data do VBA para o MySQL.
     * Aceita 'DD/MM/YYYY' e 'DD/MM/YYYY HH:MM:SS'. Se já vier em
     * 'YYYY-MM-DD ...' (sem '/'), passa direto.
     */
    private function dataBR2SQL($valor)
    {
        if (empty($valor)) return null;
        $valor = trim($valor);
        $partes = explode(' ', $valor, 2);          // separa data e hora
        $d = explode('/', $partes[0]);
        if (count($d) !== 3) return $valor;          // já está em formato SQL
        $sql = sprintf('%04d-%02d-%02d', $d[2], $d[1], $d[0]);
        if (isset($partes[1]) && trim($partes[1]) !== '') $sql .= ' ' . trim($partes[1]);
        return $sql;
    }

    /**
     * Recebe o PDF da SL criada no Access (corpo binário cru), salva no storage
     * do web e registra na tabela anexos. Parâmetros: ?ref=NNN&nome=arquivo.pdf
     */
    function uploadAnexoVba()
    {
        $ref  = (int) (Request::query('ref') ?? 0);
        $nome = Request::query('nome') ?: ('SL' . $ref . '.pdf');
        if ($ref <= 0) return Json::return(['error' => 'ref inválido'], 400);

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        // Storage do web (cria a pasta por ref)
        $base = rtrim($_ENV['APP_UPLOADS_DIR'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') $base = '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files';
        $dir = $base . '/' . $ref;
        if (!is_dir($dir)) @mkdir($dir, 0777, true);

        $nomeSeguro = 'SL' . $ref . '_' . basename($nome);
        $destino    = $dir . '/' . $nomeSeguro;

        if (file_put_contents($destino, $conteudo) === false) {
            return Json::return(['error' => 'falha ao salvar o arquivo'], 500);
        }

        // Registra em anexos (FK ref -> fila, que já existe via salvarVba)
        $pdo = Solicitacao::getPDO();
        $pdo->prepare(
            "INSERT INTO bd_device_request.anexos (id, ref, anexo, descricao, created_at)
             VALUES (:id, :ref, :anexo, :descricao, :created_at)"
        )->execute([
            'id'         => \Ramsey\Uuid\Rfc4122\UuidV4::uuid4()->toString(),
            'ref'        => $ref,
            'anexo'      => $destino,
            'descricao'  => 'PDF da solicitação (Access)',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return Json::return(['ok' => true, 'arquivo' => $nomeSeguro], 200);
    }

    /**
     * Recebe um comentário do Access e insere UMA linha em historico.
     * O texto completo é remontado por getAllTratado (não sobrescreve nada).
     * POST: ref, usuario, mensagem
     */
    function comentarVba()
    {
        $ref      = (int) (Request::input('ref') ?? 0);
        $usuario  = Request::input('usuario') ?? '';
        $mensagem = Request::input('mensagem') ?? '';

        if ($ref <= 0 || trim($mensagem) === '') {
            return Json::return(['error' => 'ref ou mensagem inválidos'], 400);
        }

        Historico::create([
            'ref'      => $ref,
            'usuario'  => $usuario,
            'mensagem' => $mensagem,
        ]);

        return Json::return(['ok' => true], 200);
    }

    /**
     * Atualiza campos vindos do Access.
     * POST: ref + campos permitidos.
     */
    function atualizarStatusVba()
    {
        $ref = (int) (Request::input('ref') ?? 0);

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }

        $permitidas = [
            'conceito_status',
            'detalhamento_status',
            'liberacao_status',
            'corte_status',
            'exec_status',
            'aquisicao_status',
            'tryout_status',

            'conceito_proj',
            'conceito_inicio',
            'conceito_fim',
            'tempo_modelo',

            'detalhamento_proj',
            'detalhamento_inicio',
            'detalhamento_fim',
            'tempo_det',

            'cod_z'
        ];

        $dados = [];

        foreach ($permitidas as $col) {
            $v = Request::input($col);

            if ($v !== null && $v !== '') {
                $dados[$col] = $v;
            }
        }

        if (empty($dados)) {
            return Json::return(['error' => 'nenhum status enviado'], 400);
        }

        // Atualiza a tabela principal da fila
        Acompanhamento::updateByRef($ref, $dados);

        // Se veio alteração de Z, mantém solicitacoes sincronizada também
        if (isset($dados['cod_z'])) {
            $pdo = Solicitacao::getPDO();

            $stmt = $pdo->prepare("
                UPDATE bd_device_request.solicitacoes
                SET cod_z = :cod_z
                WHERE ref = :ref
            ");

            $stmt->execute([
                ':cod_z' => $dados['cod_z'],
                ':ref'   => $ref
            ]);
        }

        return Json::return([
            'ok'     => true,
            'campos' => array_keys($dados)
        ], 200);
    }

    /**
     * Carga inicial Access -> MySQL.
     * Recebe UMA linha da Fila do Access (POST, nomes de coluna do Access),
     * mapeia e faz upsert por Ref em fila + solicitacoes.
     * Preserva o Ref existente (não gera número novo).
     *
     * Regra de solicitante:
     * Access manda o nome no padrão solicitantes_access.
     * MySQL salva o nome no padrão usuarios.
     */
    function migrarFila()
    {
        $pdo = Solicitacao::getPDO();

        $ref = (int) ($_POST['Ref'] ?? 0);

        if ($ref <= 0) {
            return Json::return([
                'error' => 'Ref ausente ou invalido'
            ], 400);
        }

        // Access -> MySQL (tabela fila)
        $mapFila = [
            'Descricao'        => 'descricao',
            'Solicitante'      => 'solicitante',
            'Cod_Z'            => 'cod_z',
            'Aplicacao'        => 'aplicacao',
            'Vagao'            => 'vagao',

            'Conceito_P'       => 'conceito_proj',
            'Conceito_St'      => 'conceito_status',
            'Conceito_Ini'     => 'conceito_inicio',
            'Conceito_Fim'     => 'conceito_fim',

            'Det_P'            => 'detalhamento_proj',
            'Det_St'           => 'detalhamento_status',
            'Det_Ini'          => 'detalhamento_inicio',
            'Det_Fim'          => 'detalhamento_fim',

            'Liberacao_St'     => 'liberacao_status',
            'Liberacao_Data'   => 'liberacao_data',

            'Corte_St'         => 'corte_status',
            'Corte_Data'       => 'corte_data',

            'Exec_St'          => 'exec_status',
            'Exec_Data'        => 'exec_data',

            'Tryout_St'        => 'tryout_status',
            'Tryout_Data'      => 'tryout_data',

            'Aq_St'            => 'aquisicao_status',
            'Aq_Data'          => 'aquisicao_data',

            'Data_Solicitacao' => 'data_solicitacao',
            'Historico'        => 'historico',
            'Lote'             => 'lote',
            'Prio'             => 'prio',
            'Classe'           => 'classe',
            'NumSfpCC'         => 'conta',
        ];

        $fila = [];

        foreach ($mapFila as $acc => $my) {
            if (array_key_exists($acc, $_POST)) {
                $v = $_POST[$acc];
                $fila[$my] = ($v === '' ? null : $v);
            }
        }

        // Access -> MySQL
        // Se veio Solicitante do Access, converte para o nome do sistema/MySQL.
        if (isset($fila['solicitante']) && trim((string) $fila['solicitante']) !== '') {
            $fila['solicitante'] = Usuario::nomeSistemaPorNomeAccess($fila['solicitante']);
        }

        // Atualiza ou insere na fila
        $this->upsert($pdo, 'bd_device_request.fila', 'ref', $ref, $fila);

        // Núcleo em solicitacoes (mantém o contador MAX(ref) correto)
        $solic = [];

        foreach ([
            'descricao',
            'solicitante',
            'cod_z',
            'aplicacao',
            'vagao',
            'lote',
            'conta',
            'classe',
            'data_solicitacao'
        ] as $c) {
            if (array_key_exists($c, $fila)) {
                $solic[$c] = $fila[$c];
            }
        }

        // Atualiza ou insere em solicitacoes
        $this->upsert($pdo, 'bd_device_request.solicitacoes', 'ref', $ref, $solic);

        return Json::return([
            'ref' => $ref,
            'ok'  => true
        ], 200);
    }

    /** Upsert genérico por chave: atualiza se existe, insere (com id uuid + created_at) se não. */
    private function upsert($pdo, string $table, string $key, $keyVal, array $data): void
    {
        unset($data[$key]);

        $chk = $pdo->prepare("SELECT 1 FROM {$table} WHERE {$key} = ? LIMIT 1");
        $chk->execute([$keyVal]);

        if ($chk->fetch()) {
            if (empty($data)) return;
            $sets = [];
            $params = [];
            foreach ($data as $col => $v) {
                $sets[] = "{$col} = :{$col}";
                $params[":{$col}"] = $v;
            }
            $params[':__k'] = $keyVal;
            $pdo->prepare("UPDATE {$table} SET " . implode(', ', $sets) . " WHERE {$key} = :__k")
                ->execute($params);
        } else {
            $data[$key]        = $keyVal;
            $data['id']        = \Ramsey\Uuid\Rfc4122\UuidV4::uuid4()->toString();
            $data['created_at'] = date('Y-m-d H:i:s');
            $cols = array_keys($data);
            $params = [];
            foreach ($data as $col => $v) $params[":{$col}"] = $v;
            $pdo->prepare("INSERT INTO {$table} (" . implode(', ', $cols) . ") VALUES (:" . implode(', :', $cols) . ")")
                ->execute($params);
        }
    }

    public function trataCSV(){


        try {
            if (ob_get_level()) ob_end_clean();

            // 2. Força cabeçalhos de "Não Cachear" para o Navegador/VBA
            header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
            header("Cache-Control: post-check=0, pre-check=0", false);
            header("Pragma: no-cache");
            header("Expires: Wed, 11 Jan 1984 05:00:00 GMT");
            // set_time_limit(300); // 5 minutos
            ini_set('memory_limit', '512M');

            $solicitacoes = Acompanhamento::getAllTratado();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=Fila.csv');

            //abre o arquivo
            $file  = fopen('php://output', 'w');
            //trata utf-8
            fputs($file, "\xEF\xBB\xBF");
            
            //cabeçalhos do meu arquivo
            $cabecalhos = [
                'Ref', 'Descricao', 'Solicitante', 'Cod_Z', 'Aplicacao', 'Vagao', 'Conceito_P',
                'Conceito_St', 'Conceito_Ini', 'Conceito_Fim', 'Det_P', 'Det_St',
                'Det_Ini', 'Det_Fim', 'Liberacao_St', 'Liberacao_Data', 'Corte_St',
                'Corte_Data', 'Exec_St', 'Exec_Data', 'Tryout_St', 'Tryout_Data',
                'Data_Solicitacao', 'Historico', 'Lote', 'Prio', 'Classe', 'Aq_St',
                'Aq_Data', 'Tempo_Modelo', 'Tempo_Det', 'Tempo_Fila_Det', 'Tempo_Fila_Lib',
                'Executor_EI', 'Data_Inicio_EI', 'Data_Fim_EI', 'Status_EI', 'Recebido_EI',
                'RVD', 'Obs_Aquisicao', 'TAG', 'Pendencia', 'Responsavel', 'Setor_Pendencia',
                'N_Pasta', 'Requisitos', 'CK3D', 'CKDet', 'CKReq', 'TempoTarefa',
                'PrioTarefa', 'IniTarefa', 'complexidade', 'FimTarefa', 'EquipeEI',
                'Liberacao', 'Natureza', 'DescricaoServico', 'NumSfpCC'
            ];

            fputcsv($file, $cabecalhos, ';');


            $formatarData = function ($valor) {
                if (empty($valor) || $valor == '0000-00-00') return '';
                try {
                    $date = new \DateTime($valor);
                    return $date->format('d/m/Y');
                } catch (\Exception $e) {
                    return $valor;
                    }
                    };

            foreach ($solicitacoes as $solicitacao) {
                $limpar = function ($texto) {
                    if (empty($texto)) return '';
                    // Remove quebras de linha (Windows e Linux) e troca por espaço
                    $texto = str_replace(["\r\n", "\r", "\n"], " ", $texto);
                    // Remove pontos e vírgula para não confundir o delimitador do CSV
                    $texto = str_replace(";", ",", $texto);
                    return $texto;
                };

                // Para o HISTÓRICO: preserva as quebras de linha como token [BR]
                // (o VBA troca [BR] por quebra de linha ao gravar no Access -> multilinha)
                $histAccess = function ($texto) {
                    if (empty($texto)) return '';
                    $texto = str_replace(["\r\n", "\r", "\n"], "[BR]", $texto);
                    $texto = str_replace(";", ",", $texto);
                    return $texto;
                };

                
                $novoRegistro = [
                    $solicitacao->ref ?? '',
                    // $solicitacao->descricao ?? '',
                    $limpar($solicitacao->descricao ?? ''),
                    Usuario::nomeNoAccessPorSolicitante($solicitacao->solicitante ?? ''),
                    $solicitacao->cod_z ?? '',
                    $solicitacao->aplicacao ?? '',
                    $solicitacao->vagao ?? '',
                    $solicitacao->conceito_proj ?? '',
                    $solicitacao->conceito_status ?? 'PENDENTE',
                    $solicitacao->conceito_inicio ?? '',
                    $solicitacao->conceito_fim ?? '',
                    $solicitacao->detalhamento_proj ?? '',
                    $solicitacao->detalhamento_status ?? 'PENDENTE',
                    $solicitacao->detalhamento_inicio ?? '',
                    $solicitacao->detalhamento_fim ?? '',
                    $solicitacao->liberacao_status ?? 'PENDENTE',
                    $solicitacao->liberacao_data ?? '',
                    $solicitacao->corte_status ?? 'PARADO',
                    $solicitacao->corte_data ?? '',
                    $solicitacao->exec_status ?? 'PARADO',
                    $solicitacao->exec_data ?? '',
                    $solicitacao->tryout_status ?? 'PENDENTE',
                    $solicitacao->tryout_data ?? '',
                    $formatarData($solicitacao->data_solicitacao ?? ''),
                    $histAccess($solicitacao->historico ?? ''),
                    $solicitacao->lote ?? '',
                    $solicitacao->prio ?? '99',
                    $solicitacao->classe ?? '',
                    $solicitacao->aquisicao_status ?? 'PENDENTE',
                    $solicitacao->aquisicao_data ?? '',
                    $solicitacao->tempo_modelo ?? '',
                    $solicitacao->tempo_det ?? '',
                    $solicitacao->tempo_fila_det ?? '',
                    $solicitacao->tempo_fila_lib ?? '',
                    $solicitacao->executor_ei ?? '',
                    $solicitacao->data_inicio_ei ?? '',
                    $solicitacao->data_fim_ei ?? '',
                    $solicitacao->status_ei ?? '',
                    $solicitacao->recebido_ei ?? '',
                    $solicitacao->rvd ?? '',
                    $solicitacao->obs_aquisicao ?? '',
                    $solicitacao->tag ?? '',
                    $solicitacao->pendencia ?? '',
                    $solicitacao->responsavel ?? '',
                    $solicitacao->setor_pendencia ?? '',
                    $solicitacao->n_pasta ?? '',
                    $solicitacao->requisitos ?? '',
                    $solicitacao->ck3d ?? '',
                    $solicitacao->ckdet ?? '',
                    $solicitacao->ckreq ?? '',
                    $solicitacao->tempotarefa ?? '',
                    $solicitacao->prio ?? '',
                    $solicitacao->initarefa ?? '',
                    $solicitacao->complexidade ?? '',
                    $solicitacao->fimtarefa ?? '',
                    $solicitacao->equipeei ?? '',
                    $solicitacao->liberacao ?? '',
                    $solicitacao->natureza ?? '',
                    $solicitacao->descricaoservico ?? '',
                    $solicitacao->conta ?? ''
                ];

                fputcsv($file, $novoRegistro, ';');
            }

            fclose($file);
            exit;
        } catch (\Exception $e) {
            return "Erro ao gerar CSV: " . $e->getMessage();
        }

      
    }




    public function trataProjetosCSV()
    {
        try {
            if (ob_get_level()) ob_end_clean();
            
            // Headers anti-cache e tipo de arquivo
            header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
            header("Pragma: no-cache");
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=Projetos.csv');
            $projetos = Projeto::getInfoProjetos2CSV();
            $file = fopen('php://output', 'w');
            fputs($file, "\xEF\xBB\xBF"); // BOM UTF-8

            $cabecalhos = [
                'Controle', 'EAP', 'Solicitante', 'Data_solic', 'Descricao', 'Vagao',
                'Complexidade', 'Prioridade', 'Horas', 'Data_Inicio', 'Data_Fim',
                'Data_R_Inicio', 'Data_R_Fim', 'Projetista', 'Cod_Projeto', 'Status',
                'SEG', 'ERG', 'PROD', 'Observacao', 'Justificativa', 'Objetivo',
                'Beneficios', 'Produto', 'Requisitos', 'Stakeholder', 'Equipe',
                'Premissas', 'Entregas', 'Restricoes', 'Riscos', 'Prazos', 'Custos',
                'Data_Desenhos_EI', 'Executor_EI', 'Data_Inicio_EI', 'Data_Fim_EI',
                'Status_EI', 'Recebido_EI', 'RVD_EI', 'Data_Recebido_EI', 'Status_KB',
                'Conceito_KB', 'Modelamento_KB', 'Detalhamento_KB', 'Revisao_KB',
                'Licoes_Aprendidas', 'Comentarios', 'Lote'
            ];
            fputcsv($file, $cabecalhos, ';');

            $limpar = function ($texto) {
                if (empty($texto)) return '';
                $texto = str_replace(["\r\n", "\r", "\n"], " ", $texto);
                $texto = str_replace(";", ",", $texto);
                return trim($texto);
            };

            $formatarData = function ($valor) {
                if (empty($valor) || $valor == '0000-00-00') return '';
                try {
                    return (new \DateTime($valor))->format('d/m/Y');
                } catch (\Exception $e) {
                    return $valor;
                }
            };
            foreach ($projetos as $projeto) {
                $registro = [
                    $projeto->cod_z ?? '',        
                    '',                        
                    Usuario::nomeNoAccessPorSolicitante($projeto->solicitante ?? ''),   
                    $formatarData($projeto->created_at ?? ''),
                    $limpar($projeto->descricao ?? ''), 
                    $projeto->vagao ?? '',           
                    '', '', '', '', '', '', '', '', '', '', 
                    0, 0, 0,                  
                    '', '', '', '', '', '', '', '', '', '', '', '', '', 
                    '', '', '', '', '', '', '', '', '', 
                    '',                       
                    '',                        
                    0, 0, 0, 0,               
                    '', '',                   
                    $projeto->lote ?? ''          
                ];

                fputcsv($file, $registro, ';');
            }
            fclose($file);
            exit; 
        } catch (\Exception $e) {
            http_response_code(500);
           dd("Erro interno: " . $e->getMessage());
            exit; 
        }
    }



    public function updateSituacao(HistoricoRequest $request, int $ref)
    {
        try {
            $situacao = $request->input('situacao');
            $mensagemUsuario = $request->input('mensagem');

            if ($situacao === 'cancelar') {
                $updated = Acompanhamento::updateStatus($ref, [
                    'conceito_status',
                    'detalhamento_status',
                    'liberacao_status',
                    'corte_status',
                    'aquisicao_status',
                    'exec_status',
                    'tryout_status',
                ], 'CANCELADO');
            } 
            else if ($situacao === 'rejeitar') {
                Acompanhamento::updateStatus($ref, 'conceito_status', 'MODELO');
                $updated = Acompanhamento::updateStatus($ref, 'detalhamento_status', 'PENDENTE');
            } 
            else {
                $novoStatus = ($situacao === 'aprovar') ? 'EM ANDAMENTO' : 'PENDENTE';

                /*
                * Aqui precisa passar como string, não como array,
                * para o Acompanhamento::updateStatus conseguir aplicar
                * as regras automáticas, como preencher detalhamento_inicio.
                */
                $updated = Acompanhamento::updateStatus($ref, 'detalhamento_status', $novoStatus);
            }

            if (!$updated) {
                return redirect()->back()->withError("Erro ao processar a atualização da solicitação.");
            }

            [$statusMsg, $mensagemFinal] = match ($situacao) {
                'aprovar'  => ['success', 'Validação aprovada com sucesso!'],
                'rejeitar' => ['error',   'Validação rejeitada.'],
                'cancelar' => ['warning', 'Solicitação e todos os status relacionados foram cancelados.'],
                default    => ['success', 'Ação processada.']
            };

            $this->salvarHistoricoValidacao([
                'ref'      => $ref,
                'usuario'  => Usuario::nomeNoAccess(),
                'mensagem' => $mensagemUsuario,
                'situacao' => $situacao
            ]);

            return redirect()
                ->route('dispositivos.acompanhamento.sl', ["ref" => $ref])
                ->with($statusMsg, $mensagemFinal);

        } catch (\Exception $e) {
            return redirect()->back()->withError("Erro crítico: " . $e->getMessage());
        }
    }
    private function salvarHistoricoValidacao(array $dados)
    {
        return Historico::create($dados, true);
    }



    function registraHistorico(HistoricoRequest $request, int $ref, string $tipo = null)
    {
        // $execute = $this->salvarHistoricoValidacao($request->get());
        $dados = $request->get();
        $dados['usuario'] = Usuario::nomeNoAccess(); // NOVO — autor no formato do Access (casa por e-mail)
        $execute = $this->salvarHistoricoValidacao($dados);

        if (!$execute)
            return redirect()->back()->withError("Não foi possível salvar a mensagem");

            $returnRota = match ($tipo) {
                'desenvolvimento' => 'dispositivos.desenvolvimento.info',
                // 2026-07-21 (4ª rodada) — chatbox da tela industrial
                'industrial'      => 'dispositivos.industrial.info',
                default           => 'dispositivos.acompanhamento.sl'
            };

        return redirect()->route($returnRota, ['ref' => $ref])
            ->withSuccess("Mensagem enviada!");
    }

    // NOVO — recebe "email<TAB>nome" por linha, cria/regrava solicitantes_access
    public function uploadSolicitantesVba()
    {
        $dados = (string) (Request::input('dados') ?? '');

        $regs = [];
        foreach (preg_split('/\r\n|\r|\n/', $dados) as $linha) {
            if (trim($linha) === '') continue;
            $c = explode("\t", $linha);
            $email = strtolower(trim($c[0] ?? ''));
            $nome  = trim($c[1] ?? '');
            if ($email !== '' && $nome !== '') $regs[$email] = $nome; // dedup por e-mail
        }

        $pdo = null;
        try {
            $pdo = Solicitacao::getPDO();
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS bd_device_request.solicitantes_access (
                    email VARCHAR(255) NOT NULL PRIMARY KEY,
                    nome  VARCHAR(255) NOT NULL
                )
            ");
            if (!$pdo->inTransaction()) $pdo->beginTransaction();
            $pdo->exec("DELETE FROM bd_device_request.solicitantes_access");
            $stmt = $pdo->prepare("INSERT INTO bd_device_request.solicitantes_access (email, nome) VALUES (:e, :n)");
            $n = 0;
            foreach ($regs as $email => $nome) { $stmt->execute([':e' => $email, ':n' => $nome]); $n++; }
            $pdo->commit();
            return Json::return(['ok' => true, 'usuarios' => $n], 200);
        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) $pdo->rollBack();
            error_log("Erro no uploadSolicitantesVba: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar solicitantes'], 500);
        }
    }
}
