<?php

namespace src\app\controllers;

use src\app\database\entities\Solicitacao;
use src\app\database\entities\Usuario;
use src\app\database\entities\Historico;
use src\support\Redirect;
use src\support\Request;
use src\support\Json;
use src\support\View;
use Exception;
use src\app\database\entities\Acompanhamento;


class AcompanhamentoController
{

    /**
     * Exibe a view principal de cadastro e listagem de usuários.
     *
     * @return View Retorna a view 'parametrizacao.usuario' com a lista de todos os usuários.
     */
    function acompanhamentoView(): View
    {
        $status = Request::query('status') ?? '';
        $nome = Request::query('solicitante') ??  $_SESSION['usuarioNome'];
        $solicitacoes = Solicitacao::getAllByStatusAndSolic($status, $nome);
        foreach ($solicitacoes as $item) {
            $valorLimpo = trim(str_ireplace('Z', '', $item->cod_z));
            $item->cod_z_formatado = !empty($valorLimpo) ? 'Z' . $valorLimpo : '';
        }


        return view('solicitacao.listaSL', [
            'solicitacoes' => $solicitacoes,
            "solicitantes" =>  Usuario::getSolic(),
            
        ]);
    }



    function acompanhamentoFormSL(string $ref): View
    {
        $solicitacoes = Acompanhamento::getByRef($ref);

        return view('solicitacao.acompanhamentoSL', [
            'solicitacao' => $solicitacoes,
            "interacoes" =>  Historico::getHistoryInfos($ref) ?: []
        ]);
    }


    function autoComplete()
    {
        try {
            $nome = Request::query("nome");
            $tipo = Request::query("tipo");
            $result = Usuario::getAllByNome($nome, $tipo);
            
            return Json::return([
                "type" => "success",
                "message" => "Usuários encontrados",
                "data" => $result,
            ], 200);
        } catch (Exception $e) {
            throw new Exception("Usuário não encontrado");
        }
    }
  
}
