<?php

namespace src\app\controllers;

use src\app\database\entities\Usuario;
use src\app\requests\usuarios\StoreRequest;
use src\app\requests\usuarios\UpdateRequest;
use src\support\Redirect;
use src\support\Request;
use src\support\View;
use src\support\Json;
use src\exceptions\pdo\DuplicateEntryException;


/**
 * Controller responsável por gerenciar as operações de usuário, 
 * incluindo CRUD, visualização de listagem e consultas via API.
 */
class UsuarioController
{
    /**
     * Exibe a view principal de cadastro e listagem de usuários.
     * * @return View Retorna a view 'parametrizacao.usuario' com a lista de todos os usuários.
     */
    function cadastroUsuarioView(): View
    {
        return view('parametrizacao.usuario', [
            'usuarios' => Usuario::getAll()
        ]);
    }

    /**
     * Consulta um usuário pelo número de matrícula e retorna o resultado em formato JSON.
     * Utilizado tipicamente por chamadas AJAX ou API.
     * * @return Json Retorna um objeto JSON com os dados do usuário ou uma mensagem de erro (status 404).
     */
    function consultaUsuario() {
        $matricula = Request::query('matricula');
        $userData = Usuario::findSeniorByMatricula($matricula);
        
        if(!$userData){
            return Json::return([
            "message" => "Usuário Não Encontrado",
            "data" => null],404);
        }
        
        return Json::return([
            "message" => "Usuário Encontrado",
            "data" => $userData],200);
    }

    /**
     * Armazena um novo registro de Usuário no banco de dados.
     * * @param StoreRequest $request Objeto de requisição contendo os dados validados para criação.
     * @return Redirect Redireciona para a listagem com mensagem de sucesso ou erro.
     */
    function storeUsuario(StoreRequest $request)
    {
        try {
        $user = Usuario::create($request->get(), true);
          if(!$user) {
            return redirect()->route("parametrizacao.usuario")->withError("Usuário não cadastrado");
          }

        return redirect()->route("parametrizacao.usuario")->withSuccess("Usuário cadastrado 🎉");
        }catch (DuplicateEntryException $e) {
          return redirect()->route("parametrizacao.usuario")->withError("Registro ja existente");
        }
        
    }

    /**
     * Atualiza um registro de Usuário existente no banco de dados.
     * * @param UpdateRequest $request Objeto de requisição contendo os dados validados e o ID/UUID.
     * @return Redirect Redireciona para a listagem com mensagem de sucesso.
     */
    function updateUsuario(UpdateRequest $request)
    {
        $data2update = $request->get();
        Usuario::updateByUuid($data2update['id'], $data2update);
        return redirect()->route("parametrizacao.usuario")->withSuccess("Usuário atualizado 🎉");
    }

    
    /**
     * Exibe o modal de confirmação para exclusão de um Usuário.
     *
     * @param string $id O UUID do Usuário para exibição da confirmação.
     *
     * @return View Retorna a view do modal de confirmação ('modals.confirmation') com os dados do usuário.
     */
    function modalConfirm(string $id): View
    {
        $usuario = Usuario::getByUuid($id);
        return view('modals.confirmation', [
            "usuario" => $usuario
        ]);
    }

    /**
     * Exibe o modal para edição de um Usuário existente.
     *
     * @param string $id O UUID do Usuário a ser editado.
     *
     * @return View Retorna a view do modal de edição ('modals.editUsuario') com os dados do usuário.
     */
    function modalEdit(string $id): View
    {
        $usuario = Usuario::getByUuid($id);
        return view('modals.editUsuario', [
            "usuario" => $usuario
        ]);
    }

    /**
     * Exclui um Usuário permanentemente do banco de dados pelo seu UUID.
     *
     * @param string $id O UUID do Usuário a ser deletado.
     *
     * @return Redirect Redireciona para a tela de listagem de usuários com mensagem de sucesso.
     */
    function deleteUsuario(string $id)
    {
        Usuario::deleteByUuid($id);
        return redirect()->route("parametrizacao.usuario")->withSuccess("Usuário deletado com sucesso🎉");
    }
}