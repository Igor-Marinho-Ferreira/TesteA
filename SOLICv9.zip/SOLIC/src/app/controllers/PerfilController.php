<?php

namespace src\app\controllers;

use Exception;
use src\app\database\entities\Perfil;
use src\support\View;

/**
 * Parametrização dos PERFIS lineares (2026-07-21, 6ª rodada).
 * Cada perfil guarda o peso por metro (kg/m), informado pela área conforme
 * as tabelas de cada tipo. Mesmo padrão dos demais cadastros.
 */
class PerfilController
{
    function cadastroPerfilView(): View
    {
        return view('parametrizacao.perfil', [
            'perfis' => Perfil::tabelaExiste() ? Perfil::listar() : [],
            'tipos'  => Perfil::TIPOS,
            'pronta' => Perfil::tabelaExiste(),
        ]);
    }

    function storePerfil()
    {
        $tipo = trim((string) ($_POST['tipo'] ?? ''));

        if (!array_key_exists($tipo, Perfil::TIPOS)) {
            return redirect()->route('parametrizacao.perfis')->withError('Tipo de perfil inválido.');
        }

        $peso = $this->numero($_POST['peso_por_metro'] ?? '');

        if ($peso === null || $peso <= 0) {
            return redirect()->route('parametrizacao.perfis')->withError('Informe o peso por metro (kg/m).');
        }

        try {
            $criado = Perfil::create([
                'tipo'           => $tipo,
                'descricao'      => $this->texto($_POST['descricao'] ?? '', 120),
                'peso_por_metro' => $peso,
                'densidade'      => $this->numero($_POST['densidade'] ?? ''),
            ]);

            if (!$criado) {
                return redirect()->route('parametrizacao.perfis')->withError('Registro não cadastrado');
            }

            return redirect()->route('parametrizacao.perfis')->withSuccess('Registro salvo 🎉');
        } catch (Exception $e) {
            return redirect()->route('parametrizacao.perfis')->withError('Ocorreu um erro interno ao salvar o registro.');
        }
    }

    function updatePerfil()
    {
        $id   = trim((string) ($_POST['id'] ?? ''));
        $tipo = trim((string) ($_POST['tipo'] ?? ''));

        if ($id === '' || !array_key_exists($tipo, Perfil::TIPOS)) {
            return redirect()->route('parametrizacao.perfis')->withError('Dados inválidos.');
        }

        $peso = $this->numero($_POST['peso_por_metro'] ?? '');

        if ($peso === null || $peso <= 0) {
            return redirect()->route('parametrizacao.perfis')->withError('Informe o peso por metro (kg/m).');
        }

        try {
            Perfil::updateByUuid($id, [
                'tipo'           => $tipo,
                'descricao'      => $this->texto($_POST['descricao'] ?? '', 120),
                'peso_por_metro' => $peso,
                'densidade'      => $this->numero($_POST['densidade'] ?? ''),
            ]);

            return redirect()->route('parametrizacao.perfis')->withSuccess('Registro atualizado 🎉');
        } catch (Exception $e) {
            return redirect()->route('parametrizacao.perfis')->withError('Ocorreu um erro interno ao salvar o registro.');
        }
    }

    function deletePerfil(string $id)
    {
        Perfil::deleteByUuid($id);
        return redirect()->route('parametrizacao.perfis')->withSuccess('Registro deletado com sucesso 🎉');
    }

    private function texto($valor, int $limite): ?string
    {
        $valor = trim((string) $valor);
        return $valor !== '' ? mb_substr($valor, 0, $limite) : null;
    }

    /** Aceita "6,35" ou "6.35"; devolve float ou null. */
    private function numero($valor): ?float
    {
        $valor = str_replace(',', '.', trim((string) $valor));
        return ($valor !== '' && is_numeric($valor)) ? (float) $valor : null;
    }
}
