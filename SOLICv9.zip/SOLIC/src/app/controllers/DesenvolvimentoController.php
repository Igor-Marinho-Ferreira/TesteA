<?php

namespace src\app\controllers;

use src\app\database\entities\Acompanhamento;
use src\app\database\entities\Historico;
use src\app\database\entities\Projeto;
use src\app\database\entities\Solicitacao;
use src\app\database\entities\Usuario;
use src\app\database\entities\SolicitacaoAnexoCarga;
use src\app\database\entities\SolicitacaoAnexoArquivo;
use src\app\database\entities\SolicitacaoItemComprado;
use src\app\requests\projetistas\UpdateRequest;
use src\app\requests\projetos\CodigoZRequest;
use src\app\requests\projetos\UpdateStatusRequest;
use src\app\services\LogixOrdemCompraService;
use src\support\Cronometro;
use src\support\Request;
use src\support\View;
use src\support\Json;

class DesenvolvimentoController
{
    function desenvolvimentoListaView(): View
    {
        $status      = Request::query('status') ?? '';
        $solicitante = Request::query('solicitante') ?? '';
        $projetista  = Request::query('projetista') ?? '';
        $coluna      = Request::query('coluna') ?? '';

        $solicitacoes = Acompanhamento::getAllNaoFinalizadoBySolic($status, $solicitante, $projetista, $coluna);

        foreach ($solicitacoes as $item) {
            $valorLimpo = trim(str_ireplace('Z', '', $item->cod_z));
            $item->cod_z_formatado = !empty($valorLimpo) ? 'Z' . $valorLimpo : '';
        }

        $numSL = count($solicitacoes);

        return view('/desenvolvimento.listaDesenvolvimento', [
            "solicitacoes" => $solicitacoes,
            "qtdSL"        => $numSL,
            "projetistas"  => Usuario::getByRole('role', 'PROJETISTA'),
            "solicitantes" => Usuario::getSolic()
        ]);
    }

    function atualizaStatus(UpdateStatusRequest $request)
    {
        $data = $request->get();

        $resultado = Acompanhamento::updateStatus(
            $data['id'],
            $data['coluna'],
            $data['valor']
        );

        if (!$resultado) {
            return JSON::return([
                "success" => false,
                "message" => "Erro interno ao atualizar no banco de dados."
            ], 500);
        }

        // Carimba a data de início quando a fase INICIA (espelha o btnConceito do Access).
        $this->carimbarInicioFase($data['id'], $data['coluna'], $data['valor']);
        // Carimba o FIM + tempo quando a fase termina (espelha o btnConceitoOK/btnDetalheOK).
        $this->carimbarFimFase($data['id'], $data['coluna'], $data['valor']);
        // 2026-07-21 (3ª/4ª rodadas) — cronômetro com pausa (corte, execução,
        // aquisição e tryout).
        $this->carimbarCronometro($data['id'], $data['coluna'], $data['valor']);

        return JSON::return([
            "success" => true,
            "message" => "Status atualizado com sucesso."
        ], 200);
    }

    /**
     * Grava a data de início da fase quando o status muda para o valor de "início"
     * (conceito → MODELO; detalhamento → EM ANDAMENTO), igual ao btnConceito do VBA.
     * Só grava se ainda estiver vazio (não reseta o 1º início).
     */
    private function carimbarInicioFase($id, $coluna, $valor): void
    {
        $mapa = [
            'conceito_status'     => ['gatilho' => 'MODELO',       'campo' => 'conceito_inicio'],
            'detalhamento_status' => ['gatilho' => 'EM ANDAMENTO', 'campo' => 'detalhamento_inicio'],
        ];

        if (!isset($mapa[$coluna])) {
            return;
        }
        if (strtoupper(trim((string) $valor)) !== $mapa[$coluna]['gatilho']) {
            return;
        }

        $campo = $mapa[$coluna]['campo'];

        // não sobrescreve um início já gravado
        $linha = Acompanhamento::select([$campo])->where('id', '=', $id)->finish();
        $atual = $linha[0]->{$campo} ?? null;
        if (!empty($atual) && $atual !== '0000-00-00 00:00:00') {
            return;
        }

        Acompanhamento::updateStatus($id, $campo, date('Y-m-d H:i:s'));
    }

    /**
     * Carimba o FIM da fase + calcula o tempo (horas) quando o status vira OK,
     * espelhando o btnConceitoOK/btnDetalheOK do Access:
     *   Tempo = dias_uteis(inicio, fim) * 8 + (hora_fim - hora_inicio)
     * conceito → conceito_fim + tempo_modelo ; detalhamento → detalhamento_fim + tempo_det.
     * Só grava se ainda não houver fim (não recarimba).
     */
    private function carimbarFimFase($id, $coluna, $valor): void
    {
        $mapa = [
            'conceito_status'     => ['inicio' => 'conceito_inicio',     'fim' => 'conceito_fim',     'tempo' => 'tempo_modelo'],
            'detalhamento_status' => ['inicio' => 'detalhamento_inicio', 'fim' => 'detalhamento_fim', 'tempo' => 'tempo_det'],
        ];

        if (!isset($mapa[$coluna])) {
            return;
        }
        if (strtoupper(trim((string) $valor)) !== 'OK') {
            return;
        }

        $cfg   = $mapa[$coluna];
        $linha = Acompanhamento::select([$cfg['inicio'], $cfg['fim']])->where('id', '=', $id)->finish();
        if (empty($linha)) {
            return;
        }

        $inicio   = $linha[0]->{$cfg['inicio']} ?? null;
        $fimAtual = $linha[0]->{$cfg['fim']} ?? null;

        // não recarimba um fim já gravado
        if (!empty($fimAtual) && $fimAtual !== '0000-00-00 00:00:00') {
            return;
        }

        $agora = date('Y-m-d H:i:s');
        Acompanhamento::updateStatus($id, $cfg['fim'], $agora);

        if (!empty($inicio) && $inicio !== '0000-00-00 00:00:00') {
            Acompanhamento::updateStatus($id, $cfg['tempo'], $this->calcularTempoFaseHoras($inicio, $agora));
        }
    }

    /**
     * Tempo da fase em horas, igual ao Access (TESTE.Diff):
     *   dias_uteis * 8 + (hora_fim - hora_inicio em horas, podendo ser negativo).
     */
    private function calcularTempoFaseHoras(string $inicio, string $fim): float
    {
        try {
            $ini = new \DateTime($inicio);
            $f   = new \DateTime($fim);
        } catch (\Throwable $e) {
            return 0.0;
        }

        $diasUteis = $this->diasUteis($ini, $f);

        // diferença da HORA do dia (HH:MM, igual ao DateDiff("n")/60 do Access)
        $minIni = (int) $ini->format('H') * 60 + (int) $ini->format('i');
        $minFim = (int) $f->format('H') * 60 + (int) $f->format('i');
        $diffHoras = ($minFim - $minIni) / 60;

        return round($diasUteis * 8 + $diffHoras, 1);
    }

    /**
     * Dias úteis no intervalo (inicio, fim] — exclui sáb/dom e feriados — espelhando
     * a Diff_Dias do VBA. Feriados vêm da tabela `feriados` (se existir); senão, só fds.
     */
    private function diasUteis(\DateTime $ini, \DateTime $fim): int
    {
        $d1 = (clone $ini)->setTime(0, 0, 0);
        $d2 = (clone $fim)->setTime(0, 0, 0);
        if ($d2 <= $d1) {
            return 0;
        }

        $feriados = $this->feriados();
        $uteis  = 0;
        $cursor = clone $d1;

        while ($cursor < $d2) {
            $cursor->modify('+1 day');
            $dow = (int) $cursor->format('N'); // 1=seg ... 6=sáb, 7=dom
            if ($dow >= 6) {
                continue;
            }
            if (in_array($cursor->format('Y-m-d'), $feriados, true)) {
                continue;
            }
            $uteis++;
        }

        return $uteis;
    }

    /**
     * Lista de feriados ('Y-m-d'). Lê da tabela `feriados` (coluna `data`) se existir;
     * caso contrário devolve [] (aí o cálculo exclui só fins de semana).
     */
    private function feriados(): array
    {
        try {
            $pdo  = Acompanhamento::getPDO();
            $rows = $pdo->query("SELECT data FROM bd_device_request.feriados")->fetchAll(\PDO::FETCH_COLUMN);
            return array_map(function ($d) {
                return date('Y-m-d', strtotime((string) $d));
            }, $rows ?: []);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /* ======================================================================
     *  CRONÔMETRO COM PAUSA (2026-07-21, 3ª e 4ª rodadas)
     *  Corte/Execução/Tryout: ANDAMENTO+TERCEIRIZADO contam,
     *    PARADO/AGUARDANDO pausam, FINALIZADO fecha o fim.
     *  Aquisição: conta enquanto está aberta (PENDENTE/REALIZADO/
     *    TERCEIRIZADO) e fecha em OK.
     *  Conceito/Detalhamento NÃO entram aqui — o tempo corrido deles é
     *  derivado das colunas que já existem (ver src\support\Cronometro).
     * ====================================================================== */

    private const CRONOMETRO_ETAPAS = [
        'corte_status' => [
            'ativo' => ['ANDAMENTO', 'TERCEIRIZADO'], 'pausa' => ['PARADO', 'AGUARDANDO'], 'fim' => ['FINALIZADO'],
            'inicio' => 'corte_inicio', 'fimCampo' => 'corte_fim', 'tempo' => 'corte_tempo', 'retomado' => 'corte_retomado_em',
        ],
        'exec_status' => [
            'ativo' => ['ANDAMENTO', 'TERCEIRIZADO'], 'pausa' => ['PARADO', 'AGUARDANDO'], 'fim' => ['FINALIZADO'],
            'inicio' => 'exec_inicio', 'fimCampo' => 'exec_fim', 'tempo' => 'exec_tempo', 'retomado' => 'exec_retomado_em',
        ],
        'aquisicao_status' => [
            'ativo' => ['PENDENTE', 'REALIZADO', 'TERCEIRIZADO'], 'pausa' => [], 'fim' => ['OK'],
            'inicio' => 'aquisicao_inicio', 'fimCampo' => 'aquisicao_fim', 'tempo' => 'aquisicao_tempo', 'retomado' => 'aquisicao_retomado_em',
        ],
        'tryout_status' => [
            'ativo' => ['ANDAMENTO', 'TERCEIRIZADO'], 'pausa' => ['PARADO', 'AGUARDANDO'], 'fim' => ['FINALIZADO'],
            'inicio' => 'tryout_inicio', 'fimCampo' => 'tryout_fim', 'tempo' => 'tryout_tempo', 'retomado' => 'tryout_retomado_em',
        ],
    ];

    /** Colunas existentes na tabela fila (cache por requisição). */
    private static ?array $colunasFila = null;

    private function colunasFila(): array
    {
        if (self::$colunasFila !== null) {
            return self::$colunasFila;
        }

        try {
            $pdo = Acompanhamento::getPDO();
            if (!$pdo) {
                return self::$colunasFila = [];
            }

            $stmt = $pdo->prepare("
                SELECT COLUMN_NAME
                  FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = 'bd_device_request'
                   AND TABLE_NAME   = 'fila'
            ");
            $stmt->execute();

            return self::$colunasFila = array_map(
                'strval',
                $stmt->fetchAll(\PDO::FETCH_COLUMN) ?: []
            );
        } catch (\Throwable $e) {
            error_log('Falha ao ler colunas da fila: ' . $e->getMessage());
            return self::$colunasFila = [];
        }
    }

    /** A etapa tem todas as colunas de cronômetro criadas? */
    public function cronometroDisponivel(string $coluna): bool
    {
        $cfg = self::CRONOMETRO_ETAPAS[$coluna] ?? null;

        if (!$cfg) {
            return false;
        }

        $cols = $this->colunasFila();

        foreach (['inicio', 'fimCampo', 'tempo', 'retomado'] as $chave) {
            if (!in_array($cfg[$chave], $cols, true)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Contabiliza o tempo da etapa conforme a transição de status.
     * $id aqui é o REF (o select manda data-id = ref), igual ao resto do fluxo.
     */
    private function carimbarCronometro($id, $coluna, $valor): void
    {
        $cfg = self::CRONOMETRO_ETAPAS[$coluna] ?? null;

        if (!$cfg || !$this->cronometroDisponivel($coluna)) {
            return;
        }

        $v = strtoupper(trim((string) $valor));

        $linha = Acompanhamento::select([$cfg['inicio'], $cfg['fimCampo'], $cfg['tempo'], $cfg['retomado']])
            ->where('ref', '=', $id)
            ->finish();

        if (empty($linha)) {
            return;
        }

        $row      = $linha[0];
        $inicio   = $row->{$cfg['inicio']} ?? null;
        $tempo    = (int) ($row->{$cfg['tempo']} ?? 0);
        $retomado = $row->{$cfg['retomado']} ?? null;
        $agora    = date('Y-m-d H:i:s');

        $temRetomado = !empty($retomado) && $retomado !== '0000-00-00 00:00:00';

        // Soma o intervalo ativo em curso ao acumulado
        $acumular = function () use (&$tempo, $retomado, $agora) {
            $ini = strtotime((string) $retomado);
            $fim = strtotime($agora);
            if ($ini && $fim && $fim > $ini) {
                $tempo += ($fim - $ini);
            }
        };

        if (in_array($v, $cfg['ativo'], true)) {
            // 1º início (não sobrescreve)
            if (empty($inicio) || $inicio === '0000-00-00 00:00:00') {
                Acompanhamento::updateStatus($id, $cfg['inicio'], $agora);
            }
            // reabriu depois de finalizado -> limpa o fim
            Acompanhamento::updateStatus($id, $cfg['fimCampo'], null);
            // abre um novo intervalo ativo só se não houver um em curso
            if (!$temRetomado) {
                Acompanhamento::updateStatus($id, $cfg['retomado'], $agora);
            }
            return;
        }

        if (in_array($v, $cfg['pausa'], true)) {
            if ($temRetomado) {
                $acumular();
                Acompanhamento::updateStatus($id, $cfg['tempo'], $tempo);
                Acompanhamento::updateStatus($id, $cfg['retomado'], null);
            }
            return;
        }

        if (in_array($v, $cfg['fim'], true)) {
            if ($temRetomado) {
                $acumular();
                Acompanhamento::updateStatus($id, $cfg['tempo'], $tempo);
                Acompanhamento::updateStatus($id, $cfg['retomado'], null);
            }
            Acompanhamento::updateStatus($id, $cfg['fimCampo'], $agora);
            return;
        }

        // CANCELADO e outros: o tempo não é tocado aqui.
    }


    /**
     * Access -> Web: recebe os feriados (planilha "Feriados" do VBA) e regrava a
     * tabela `feriados`. Cria a tabela se não existir. POST form-urlencoded:
     * dados = uma data YYYY-MM-DD por linha. Substitui todo o conteúdo.
     */
    public function uploadFeriadosVba()
    {
        $dados = (string) (Request::input('dados') ?? '');

        // valida e deduplica as datas (só aceita YYYY-MM-DD)
        $datas = [];
        foreach (preg_split('/\r\n|\r|\n/', $dados) as $linha) {
            $linha = trim($linha);
            if ($linha !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $linha)) {
                $datas[$linha] = true;
            }
        }
        $datas = array_keys($datas);

        $pdo = null;
        try {
            $pdo = Acompanhamento::getPDO();

            $pdo->exec("
                CREATE TABLE IF NOT EXISTS bd_device_request.feriados (
                    id   INT AUTO_INCREMENT PRIMARY KEY,
                    data DATE NOT NULL,
                    UNIQUE KEY uq_feriado_data (data)
                )
            ");

            if (!$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $pdo->exec("DELETE FROM bd_device_request.feriados");

            $stmt = $pdo->prepare("INSERT INTO bd_device_request.feriados (data) VALUES (:data)");
            $n = 0;
            foreach ($datas as $d) {
                $stmt->execute([':data' => $d]);
                $n++;
            }

            $pdo->commit();

            return Json::return(['ok' => true, 'feriados' => $n], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Erro no uploadFeriadosVba: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar feriados'], 500);
        }
    }

    function arquivosSolicitacao(string $ref): View
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        $cargasAnexos = SolicitacaoAnexoCarga::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $ultimaCarga = $cargasAnexos[0] ?? null;

        $arquivosSolicitacao = SolicitacaoAnexoArquivo::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $itensComprados = SolicitacaoItemComprado::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'ASC')
            ->finish() ?: [];

        $arquivosPorTipo = $this->separarArquivosSolicitacao($arquivosSolicitacao);

        return view('modals.arquivos-solicitacao', [
            'solicitacao'         => $solicitacao,
            'z_info'              => Projeto::getByZcode(ltrim((string)($solicitacao->cod_z ?? ''), 'zZ')),

            'ultimaCarga'         => $ultimaCarga,
            'cargasAnexos'        => $cargasAnexos,
            'arquivosSolicitacao' => $arquivosSolicitacao,
            'arquivosPorTipo'     => $arquivosPorTipo,

            'imagemProjeto'       => $arquivosPorTipo['IMAGEM_PROJETO'][0] ?? null,
            'pacotesDxf'          => $arquivosPorTipo['PACOTE_DXF'] ?? [],
            'txtItensComprados'   => $arquivosPorTipo['ITENS_COMPRADOS_TXT'] ?? [],
            'listasMateriais'     => $arquivosPorTipo['LISTA_MATERIAIS'] ?? [],
            'desenhosPdf'         => $arquivosPorTipo['DESENHO_PDF'] ?? [],

            'itensComprados'      => $itensComprados
        ]);
    }

    function storeArquivosSolicitacao(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível carregar arquivos quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $prioridade = $_POST['prioridade'] ?? '02-Média';

        $semArquivosDxf = isset($_POST['sem_arquivos_dxf']) ? '1' : '0';
        $nenhumItemComprado = isset($_POST['nenhum_item_comprado']) ? '1' : '0';

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $arquivosCriadosFisicamente = [];

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $prioridade,
                'sem_arquivos_dxf'     => $semArquivosDxf,
                'nenhum_item_comprado' => $nenhumItemComprado,
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga dos anexos.");
            }

            $cargaId = $saveCarga['id'];

            if (!empty($_FILES['imagem_projeto']) && $this->arquivoValido($_FILES['imagem_projeto'])) {
                $this->validarExtensaoArquivo($_FILES['imagem_projeto'], ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'], 'imagem');

                $arquivosParaExcluirFisicamente = array_merge(
                    $arquivosParaExcluirFisicamente,
                    $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO')
                );

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $_FILES['imagem_projeto'],
                    'IMAGEM_PROJETO',
                    "{$baseUploadDir}/imagem",
                    "{$baseUploadPath}/imagem",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
            }

            if ($semArquivosDxf === '1') {
                $arquivosParaExcluirFisicamente = array_merge(
                    $arquivosParaExcluirFisicamente,
                    $this->removerArquivosExistentesPorTipo($ref, 'PACOTE_DXF')
                );
            } elseif (!empty($_FILES['pacote_dxf']) && $this->arquivoValido($_FILES['pacote_dxf'])) {
                $this->validarExtensaoArquivo($_FILES['pacote_dxf'], ['zip', 'rar', '7z', 'dxf'], 'pacote DXF');

                $codigoDxf = $this->gerarProximoCodigoDxf($ref);

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $_FILES['pacote_dxf'],
                    'PACOTE_DXF',
                    "{$baseUploadDir}/dxf",
                    "{$baseUploadPath}/dxf",
                    $usuarioLogado,
                    $codigoDxf
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
            }

            if ($nenhumItemComprado === '1') {
                $arquivosParaExcluirFisicamente = array_merge(
                    $arquivosParaExcluirFisicamente,
                    $this->removerArquivosExistentesPorTipo($ref, 'ITENS_COMPRADOS_TXT')
                );
            } else {
                $arquivosTxt = $this->normalizarFilesArray($_FILES['itens_comprados_txt'] ?? null);

                $txtValidos = [];

                foreach ($arquivosTxt as $arquivoTxt) {
                    if (!$this->arquivoValido($arquivoTxt)) {
                        continue;
                    }

                    $this->validarExtensaoArquivo($arquivoTxt, ['txt'], 'TXT de itens comprados');

                    $txtValidos[] = $arquivoTxt;
                }

                if (!empty($txtValidos)) {
                    $arquivosParaExcluirFisicamente = array_merge(
                        $arquivosParaExcluirFisicamente,
                        $this->removerArquivosExistentesPorTipo($ref, 'ITENS_COMPRADOS_TXT')
                    );

                    foreach ($txtValidos as $arquivoTxt) {
                        $arquivoSalvo = $this->salvarArquivoSolicitacao(
                            $cargaId,
                            $ref,
                            $arquivoTxt,
                            'ITENS_COMPRADOS_TXT',
                            "{$baseUploadDir}/itens_comprados",
                            "{$baseUploadPath}/itens_comprados",
                            $usuarioLogado
                        );

                        $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

                        $this->salvarItensCompradosDoTxt(
                            $cargaId,
                            $arquivoSalvo['id'],
                            $ref,
                            $arquivoSalvo['caminho_fisico'],
                            $usuarioLogado
                        );
                    }
                }
            }

            if (!empty($_FILES['lista_materiais']) && $this->arquivoValido($_FILES['lista_materiais'])) {
                $this->validarExtensaoArquivo($_FILES['lista_materiais'], ['xls', 'xlsx', 'csv'], 'lista de materiais');

                $arquivosParaExcluirFisicamente = array_merge(
                    $arquivosParaExcluirFisicamente,
                    $this->removerArquivosExistentesPorTipo($ref, 'LISTA_MATERIAIS')
                );

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $_FILES['lista_materiais'],
                    'LISTA_MATERIAIS',
                    "{$baseUploadDir}/lista_materiais",
                    "{$baseUploadPath}/lista_materiais",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
            }

            $desenhosPdf = $this->normalizarFilesArray($_FILES['desenhos_pdf'] ?? null);

            foreach ($desenhosPdf as $desenhoPdf) {
                if (!$this->arquivoValido($desenhoPdf)) {
                    continue;
                }

                $this->validarExtensaoArquivo($desenhoPdf, ['pdf'], 'desenho PDF');

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $desenhoPdf,
                    'DESENHO_PDF',
                    "{$baseUploadDir}/desenhos_pdf",
                    "{$baseUploadPath}/desenhos_pdf",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Arquivos da solicitação carregados/atualizados com sucesso.',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Arquivos carregados com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar arquivos da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar os arquivos da solicitação.");
        }
    }

    public function removerArquivoSolicitacao(string $id)
    {
        $arquivo = $this->buscarArquivoSolicitacaoPorId($id);

        if (!$arquivo) {
            return redirect()
                ->back()
                ->withError("Arquivo não encontrado.");
        }

        $tipo = strtoupper(trim((string)($arquivo->tipo ?? '')));

        if (!in_array($tipo, ['PACOTE_DXF', 'DESENHO_PDF'], true)) {
            return redirect()
                ->back()
                ->withError("Este tipo de arquivo não pode ser removido manualmente.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $ref = $arquivo->ref ?? null;
        $nomeOriginal = $arquivo->nome_original ?? 'arquivo';
        $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');

        $pdo = null;

        try {
            $pdo = SolicitacaoAnexoArquivo::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $deleteArquivo = $pdo->prepare("
                DELETE FROM bd_device_request.solicitacao_anexo_arquivos
                WHERE id = :id
            ");

            $deleteArquivo->execute([
                ':id' => $id
            ]);

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Arquivo removido da solicitação: {$nomeOriginal}.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            if (!empty($caminhoFisico) && file_exists($caminhoFisico)) {
                @unlink($caminhoFisico);
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Arquivo removido com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log("Erro ao remover arquivo {$id}: " . $e->getMessage());

            return redirect()
                ->back()
                ->withError("Erro ao remover o arquivo.");
        }
    }

    function desenvolvimentoInfoView(string $ref): View
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        $zCode = ltrim((string)($solicitacao->cod_z ?? ''), 'zZ');

        if ($solicitacao->situacao === 'aprovar') {
            $statusConceito = ['OK', 'REVISAR'];
        }

        $statusConceito = ['EM ANÁLISE', 'BACKLOG', 'MODELO', 'PAUSADO', 'CONCEITO OK', 'OK', 'REVISAR'];
        $statusDetalhamento = ['EM ANDAMENTO', 'PAUSADO', 'OK'];
        // REVISAR entra como opção porque é o estado após "Retornar SL" (3ª rodada)
        $statusLiberacao = ['PENDENTE', 'REVISAR', 'OK'];
        $statusAquisicao = ['PENDENTE', 'REALIZADO', 'TERCEIRIZADO', 'OK'];
        // 2026-07-21 (2ª rodada) — novas opções de Corte e Execução
        $statusCorte = ['ANDAMENTO', 'PARADO', 'TERCEIRIZADO', 'CANCELADO', 'FINALIZADO', 'AGUARDANDO'];
        $statusExecucao = ['PARADO', 'ANDAMENTO', 'TERCEIRIZADO', 'CANCELADO', 'FINALIZADO'];
        $statusTryout = ['PARADO', 'ANDAMENTO', 'TERCEIRIZADO', 'FINALIZADO'];

        // 2026-07-21 (4ª rodada) — Corte e Execução saíram do controle da
        // AUTOMAÇÃO: continuam visíveis na barra de progresso (para a
        // automação acompanhar a SL), mas travados. Quem edita é a tela
        // INDUSTRIAL (IndustrialController).
        $slLiberada = strtoupper(trim((string) $solicitacao->liberacao_status)) === 'OK';

        $etapas = [
            [
                'label'  => 'Conceito',
                'coluna' => 'conceito_status',
                'valor'  => $solicitacao->conceito_status,
                'opcoes' => $statusConceito,
                'edit'   => true
            ],
            [
                'label'  => 'Detalhe',
                'coluna' => 'detalhamento_status',
                'valor'  => $solicitacao->detalhamento_status,
                'opcoes' => $statusDetalhamento,
                'edit'   => true
            ],
            [
                'label'  => 'Liberação',
                'coluna' => 'liberacao_status',
                'valor'  => $solicitacao->liberacao_status,
                'opcoes' => $statusLiberacao,
                // 2026-07-21 (8ª rodada): Liberação é da INDUSTRIAL. Automação só vê.
                'edit'   => false
            ],
            [
                'label'  => 'Aquisição',
                'coluna' => 'aquisicao_status',
                'valor'  => $solicitacao->aquisicao_status,
                'opcoes' => $statusAquisicao,
                // 2026-07-21 (8ª rodada): Aquisição/OC é da INDUSTRIAL. Automação só vê.
                'edit'   => false
            ],
            [
                'label'  => 'Corte',
                'coluna' => 'corte_status',
                'valor'  => $solicitacao->corte_status,
                'opcoes' => $statusCorte,
                // Somente leitura na automação — controlado pela tela Industrial
                'edit'   => false
            ],
            [
                'label'  => 'Execução',
                'coluna' => 'exec_status',
                'valor'  => $solicitacao->exec_status,
                'opcoes' => $statusExecucao,
                // Somente leitura na automação — controlado pela tela Industrial
                'edit'   => false
            ],
            [
                'label'  => 'Tryout',
                'coluna' => 'tryout_status',
                'valor'  => $solicitacao->tryout_status,
                'opcoes' => $statusTryout,
                'edit'   => false
            ]
        ];

        $cargasAnexos = SolicitacaoAnexoCarga::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $arquivosSolicitacao = SolicitacaoAnexoArquivo::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $itensComprados = SolicitacaoItemComprado::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'ASC')
            ->finish() ?: [];

        $arquivosPorTipo = $this->separarArquivosSolicitacao($arquivosSolicitacao);
        $cargasMap = $this->criarMapaCargas($cargasAnexos);

        return view('desenvolvimento.desenvolvimentoForm', [
            "solicitacao" => $solicitacao,
            "z_info"      => Projeto::getByZcode($zCode),
            "etapas"      => $etapas,
            "projetistas" => Usuario::getByRole('role', [
                'PROJETISTA',
                'LIDER DE PROJETO'
            ]),
            "interacoes"  => Historico::getHistoryInfos($ref) ?: [],

            "cargasAnexos"        => $cargasAnexos,
            "cargasMap"           => $cargasMap,
            "arquivosSolicitacao" => $arquivosSolicitacao,
            "arquivosPorTipo"     => $arquivosPorTipo,

            "imagemProjeto"       => $arquivosPorTipo['IMAGEM_PROJETO'][0] ?? null,
            "pacotesDxf"          => $arquivosPorTipo['PACOTE_DXF'] ?? [],
            "txtItensComprados"   => $arquivosPorTipo['ITENS_COMPRADOS_TXT'] ?? [],
            "listasMateriais"     => $arquivosPorTipo['LISTA_MATERIAIS'] ?? [],
            "desenhosPdf"         => $arquivosPorTipo['DESENHO_PDF'] ?? [],
            "itensComprados"      => $itensComprados,

            // 2026-07-21 — controle de aquisição
            "resumoAquisicao"     => SolicitacaoItemComprado::resumoLiquidacao((int) $ref),
            "aquisicaoHabilitada" => SolicitacaoItemComprado::temColunasAquisicao(),

            // 2026-07-21 (2ª rodada) — bypass de teste da aquisição
            "podeBypassAquisicao" => $this->podeBypassAquisicao(),

            // 2026-07-21 (3ª/4ª rodadas) — cronômetro de todas as etapas.
            // Etapa sem as colunas criadas é omitida automaticamente.
            "temposEtapa" => Cronometro::mapa($solicitacao)
        ]);
    }

    /**
     * Cria (idempotente) todas as subpastas que o VBA usa dentro do storage
     * mapeado (APP_STORAGE_MAPPED) — a pasta que o Access enxerga (mapeada no
     * Windows). Rode uma vez após configurar/mapear a pasta. GET, devolve a lista.
     */
    public function garantirStorageMapeado()
    {
        $base = rtrim($_ENV['APP_STORAGE_MAPPED'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') {
            return Json::return(['error' => 'APP_STORAGE_MAPPED não configurado'], 500);
        }

        if (!is_dir($base)) {
            @mkdir($base, 0777, true);
        }

        // Mesmas pastas usadas pelo VBA (workbooks Solicitação + Lista)
        $subpastas = ['.Files', '.img_sl', '.img_z', '.imgs', '.desenhos', 'desenhosPDF', '.dxf', '.cortes', '.bom'];
        $criadas = [];
        $existentes = [];

        foreach ($subpastas as $p) {
            $dir = $base . '/' . $p;
            if (is_dir($dir)) {
                $existentes[] = $p;
            } elseif (@mkdir($dir, 0777, true)) {
                $criadas[] = $p;
            }
        }

        return Json::return([
            'base'       => $base,
            'criadas'    => $criadas,
            'existentes' => $existentes,
        ], 200);
    }

    public function storeImagemProjeto(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível alterar a imagem quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        if (empty($_FILES['imagem_projeto']) || !$this->arquivoValido($_FILES['imagem_projeto'])) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione uma imagem válida.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $arquivosCriadosFisicamente = [];

        try {
            $this->validarExtensaoArquivo($_FILES['imagem_projeto'], ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'], 'imagem');

            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da imagem.");
            }

            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO');

            $arquivoSalvo = $this->salvarArquivoSolicitacao(
                $saveCarga['id'],
                $ref,
                $_FILES['imagem_projeto'],
                'IMAGEM_PROJETO',
                "{$baseUploadDir}/imagem",
                "{$baseUploadPath}/imagem",
                $usuarioLogado
            );

            $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Imagem de visualização do projeto atualizada.',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (empty($arquivoFisico)) {
                    continue;
                }

                if (!file_exists($arquivoFisico)) {
                    continue;
                }

                /*
                * Cuidado:
                * Para IMAGEM_PROJETO, o nome final costuma ser sempre o mesmo:
                * .img_sl/SLxxxx.jpg
                *
                * Se apagar esse caminho depois de salvar a imagem nova,
                * você apaga a imagem recém-atualizada.
                */
                $antigo = realpath($arquivoFisico);
                $novo   = realpath($arquivoSalvo['caminho_fisico'] ?? '');

                if ($antigo && $novo && $antigo === $novo) {
                    continue;
                }

                @unlink($arquivoFisico);
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Imagem atualizada com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar imagem da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao atualizar a imagem.");
        }
    }

    /**
     * Access -> Web: recebe a imagem do projeto enviada pelo VBA
     * (frmaut.btnLoadImage) como corpo binário cru (php://input) e a registra
     * como IMAGEM_PROJETO usando a MESMA estrutura do storeImagemProjeto:
     * cria a carga, grava o arquivo em .../imagem/, registra em
     * solicitacao_anexo_arquivos e adiciona ao histórico. Substitui a imagem
     * anterior, se houver. SEM trava de status — espelha o que o Access já fez.
     * Parâmetros via query string: ?ref=NNN&nome=arquivo.jpg
     */
    public function uploadImagemVba()
    {
        $ref  = (int) (Request::query('ref') ?? 0);
        $nome = Request::query('nome') ?: ('SL' . $ref . '.jpg');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado = 'ACCESS';

        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da imagem.");
            }

            // Remove o registro da imagem anterior (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO');

            // Grava a partir dos BYTES (não há $_FILES no POST do VBA, então não
            // dá pra usar salvarArquivoSolicitacao/move_uploaded_file)
            // Storage na ARQUITETURA DO ACCESS (a imagem já existe no Access; não espelha)
            [$subpasta, $nomeSeguro] = $this->caminhoAccess('IMAGEM_PROJETO', (string) $ref, null, $nome);
            $dirStorage = $this->storageBase() . '/' . $subpasta;
            if (!is_dir($dirStorage)) {
                mkdir($dirStorage, 0777, true);
            }
            $caminhoFisico   = $dirStorage . '/' . $nomeSeguro;
            $caminhoRelativo = $subpasta . '/' . $nomeSeguro;

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar a imagem.");
            }
            $caminhoFisicoNovo = $caminhoFisico;

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'IMAGEM_PROJETO',
                'codigo'        => null,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'image/jpeg',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);

            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro da imagem.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Imagem de visualização do projeto atualizada (Access).',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (empty($arquivoFisico)) {
                    continue;
                }

                if (!file_exists($arquivoFisico)) {
                    continue;
                }

                $antigo = realpath($arquivoFisico);
                $novo   = realpath($caminhoFisicoNovo ?? '');

                if ($antigo && $novo && $antigo === $novo) {
                    continue;
                }

                @unlink($arquivoFisico);
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }

            error_log("Erro no uploadImagemVba {$ref}: " . $e->getMessage());

            return Json::return(['error' => 'falha ao salvar imagem'], 500);
        }
    }

    public function storePacoteDxf(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar DXF quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        if (empty($_FILES['pacote_dxf']) || !$this->arquivoValido($_FILES['pacote_dxf'])) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione um pacote DXF válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosCriadosFisicamente = [];

        try {
            $this->validarExtensaoArquivo($_FILES['pacote_dxf'], ['zip', 'rar', '7z', 'dxf'], 'pacote DXF');

            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do DXF.");
            }

            $codigoDxf = $this->gerarProximoCodigoDxf($ref);

            $arquivoSalvo = $this->salvarArquivoSolicitacao(
                $saveCarga['id'],
                $ref,
                $_FILES['pacote_dxf'],
                'PACOTE_DXF',
                "{$baseUploadDir}/dxf",
                "{$baseUploadPath}/dxf",
                $usuarioLogado,
                $codigoDxf
            );

            $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Pacote DXF {$codigoDxf} adicionado à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Pacote DXF {$codigoDxf} salvo com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar DXF da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar o pacote DXF.");
        }
    }

    /**
     * Access -> Web: recebe UM pacote DXF (zip) enviado pelo VBA (ufdxf) como corpo
     * binário cru. Usa o `codigo` JÁ atribuído pelo Access via cartório (nextDxf),
     * tipo PACOTE_DXF. Se já houver DXF de mesmo codigo, substitui. Sem trava.
     * Parâmetros via query: ?ref=NNN&codigo=DX0001&nome=arquivo.zip
     */
    public function uploadDxfVba()
    {
        $ref    = (int) (Request::query('ref') ?? 0);
        $codigo = trim((string) (Request::query('codigo') ?? ''));
        $nome   = Request::query('nome') ?: (($codigo !== '' ? $codigo : ('SL' . $ref)) . '.zip');

        if ($ref <= 0)      return Json::return(['error' => 'ref inválido'], 400);
        if ($codigo === '') return Json::return(['error' => 'codigo obrigatório'], 400);

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) return Json::return(['error' => 'solicitação não encontrada'], 404);

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado  = 'ACCESS';
        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();
            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);
            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do DXF.");
            }

            // Substitui o DXF anterior de MESMO codigo (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivoPorCodigo($ref, 'PACOTE_DXF', $codigo);

            // Storage na ARQUITETURA DO ACCESS (o zip já existe no Access; não espelha)
            [$subpasta, $nomeSeguro] = $this->caminhoAccess('PACOTE_DXF', (string) $ref, $codigo, $nome);
            $dirStorage = $this->storageBase() . '/' . $subpasta;
            if (!is_dir($dirStorage)) {
                mkdir($dirStorage, 0777, true);
            }
            $caminhoFisico   = $dirStorage . '/' . $nomeSeguro;
            $caminhoRelativo = $subpasta . '/' . $nomeSeguro;

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar o DXF.");
            }
            $caminhoFisicoNovo = $caminhoFisico;

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'PACOTE_DXF',
                'codigo'        => $codigo,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'application/zip',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);
            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro do DXF.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Pacote DXF '{$codigo}' adicionado (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro, 'codigo' => $codigo], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }
            error_log("Erro no uploadDxfVba {$ref}/{$codigo}: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar DXF'], 500);
        }
    }

    /**
     * Remove (registro + retorna caminhos físicos) o arquivo de um dado tipo/codigo
     * de uma SL, para que o re-upload substitua em vez de duplicar.
     */
    private function removerArquivoPorCodigo(string $ref, string $tipo, string $codigo): array
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT *
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref AND tipo = :tipo AND codigo = :codigo
        ");
        $stmt->execute([':ref' => $ref, ':tipo' => $tipo, ':codigo' => $codigo]);
        $arquivos = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        if (empty($arquivos)) {
            return [];
        }

        $fisicos = [];
        foreach ($arquivos as $arquivo) {
            $arquivoId = $arquivo->id ?? null;
            if (!$arquivoId) {
                continue;
            }

            $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');
            if (!empty($caminhoFisico)) {
                $fisicos[] = $caminhoFisico;
            }

            $pdo->prepare("DELETE FROM bd_device_request.solicitacao_anexo_arquivos WHERE id = :id")
                ->execute([':id' => $arquivoId]);
        }

        return $fisicos;
    }

    /**
     * Web -> Access (pull): CSV dos pacotes DXF (PACOTE_DXF) p/ o VBA upsertar em
     * DXF_Control. Colunas: Controle;Solicitacao;Projeto;Descricao.
     * Controle = número do codigo (DX0001 -> 1); Solicitacao = "SL"+4 díg.;
     * Projeto = cod_z da SL. Descrição vem do nome do arquivo (web não modela a rica).
     */
    /**
     * Web -> Access (pull): CSV dos pacotes DXF para o VBA inserir em DXF_Control.
     *
     * Colunas esperadas pelo Access:
     * Controle;Solicitacao;Projeto;Descricao
     *
     * Controle = número do DX. Ex.: DX0001 -> 1
     * Solicitação = SL5042
     * Projeto = cod_z
     * Descricao = nome original do arquivo
     */
    public function csvDxf()
    {
        if (ob_get_level()) {
            ob_end_clean();
        }

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=Dxf.csv');

        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $rows = $pdo->query("
            SELECT 
                a.ref AS ref,
                a.codigo AS codigo,
                a.nome_original AS nome_original,
                a.nome_arquivo AS nome_arquivo,
                a.caminho AS caminho,
                s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_anexo_arquivos a
            LEFT JOIN bd_device_request.solicitacoes s 
                ON s.ref = a.ref
            WHERE a.tipo = 'PACOTE_DXF'
            ORDER BY a.ref, a.codigo, a.nome_original
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');

        fputs($file, "\xEF\xBB\xBF");

        fputcsv($file, [
            'Controle',
            'Solicitacao',
            'Projeto',
            'Descricao'
        ], ';');

        foreach ($rows as $r) {
            $codigo = trim((string)($r->codigo ?? ''));

            /*
            * Tenta descobrir o DX em:
            * 1) codigo
            * 2) nome_arquivo
            * 3) nome_original
            * 4) caminho
            */
            $fontesCodigo = [
                $codigo,
                (string)($r->nome_arquivo ?? ''),
                (string)($r->nome_original ?? ''),
                basename((string)($r->caminho ?? ''))
            ];

            $controle = 0;

            foreach ($fontesCodigo as $fonte) {
                $fonte = trim($fonte);

                if ($fonte === '') {
                    continue;
                }

                if (preg_match('/DX\s*0*([0-9]+)/i', $fonte, $m)) {
                    $controle = (int) $m[1];
                    break;
                }
            }

            /*
            * Sem Controle numérico, o Access não consegue montar corretamente
            * o registro da DXF_Control.
            */
            if ($controle <= 0) {
                continue;
            }

            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);

            $descricao = trim((string)($r->nome_original ?? ''));

            if ($descricao === '') {
                $descricao = trim((string)($r->nome_arquivo ?? ''));
            }

            if ($descricao === '') {
                $descricao = basename((string)($r->caminho ?? ''));
            }

            fputcsv($file, [
                $controle,
                $sl,
                $r->cod_z ?? '',
                $descricao
            ], ';');
        }

        fclose($file);
        exit;
    }

    public function storeDesenhosPdf(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar PDF quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        $desenhosPdf = $this->normalizarFilesArray($_FILES['desenhos_pdf'] ?? null);

        if (empty($desenhosPdf)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione ao menos um PDF válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosCriadosFisicamente = [];

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga dos PDFs.");
            }

            $qtdSalvos = 0;
            $pdfsParaAccess = []; // [ ['codigo'=>..., 'fisico'=>...], ... ]

            foreach ($desenhosPdf as $pdf) {
                if (!$this->arquivoValido($pdf)) {
                    continue;
                }

                $this->validarExtensaoArquivo($pdf, ['pdf'], 'desenho PDF');

                // codigo = nome do arquivo sem extensão (mesma identidade do Access/PDF_Control)
                $codigo = pathinfo($pdf['name'] ?? '', PATHINFO_FILENAME);

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $saveCarga['id'],
                    $ref,
                    $pdf,
                    'DESENHO_PDF',
                    "{$baseUploadDir}/desenhos_pdf",
                    "{$baseUploadPath}/desenhos_pdf",
                    $usuarioLogado,
                    $codigo
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
                $pdfsParaAccess[] = ['codigo' => $codigo, 'fisico' => $arquivoSalvo['caminho_fisico']];
                $qtdSalvos++;
            }

            if ($qtdSalvos === 0) {
                throw new \Exception("Nenhum PDF válido foi enviado.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$qtdSalvos} desenho(s) PDF adicionado(s) à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("PDF(s) salvo(s) com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar PDF da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar os PDFs.");
        }
    }

    /**
     * Access -> Web: recebe UM desenho PDF enviado pelo VBA (frmaut.btn_pdf_novo)
     * como corpo binário cru. Registra como DESENHO_PDF com o `codigo` (= nome do
     * arquivo, igual ao PDF_Control do Access). Se já houver um PDF de mesmo
     * codigo nesta SL, substitui. SEM trava de status — espelha o Access.
     * Parâmetros via query string: ?ref=NNN&codigo=XXX&nome=arquivo.pdf
     */
    public function uploadDesenhoPdfVba()
    {
        $ref    = (int) (Request::query('ref') ?? 0);
        $codigo = trim((string) (Request::query('codigo') ?? ''));
        $nome   = Request::query('nome') ?: (($codigo !== '' ? $codigo : ('SL' . $ref)) . '.pdf');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }
        if ($codigo === '') {
            return Json::return(['error' => 'codigo obrigatório'], 400);
        }

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado = 'ACCESS';

        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do PDF.");
            }

            // Substitui o PDF anterior de MESMO codigo (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivoDesenhoPorCodigo($ref, $codigo);

            // Storage na ARQUITETURA DO ACCESS (o PDF já existe no Access; não espelha)
            [$subpasta, $nomeSeguro] = $this->caminhoAccess('DESENHO_PDF', (string) $ref, $codigo, $nome);
            $dirStorage = $this->storageBase() . '/' . $subpasta;
            if (!is_dir($dirStorage)) {
                mkdir($dirStorage, 0777, true);
            }
            $caminhoFisico   = $dirStorage . '/' . $nomeSeguro;
            $caminhoRelativo = $subpasta . '/' . $nomeSeguro;

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar o PDF.");
            }
            $caminhoFisicoNovo = $caminhoFisico;
            $this->copiarDesenhoPdfParaPastasAccess((string) $ref, $codigo, $nome, $caminhoFisico);
            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'DESENHO_PDF',
                'codigo'        => $codigo,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'application/pdf',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);

            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro do PDF.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Desenho PDF '{$codigo}' adicionado (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro, 'codigo' => $codigo], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }
            error_log("Erro no uploadDesenhoPdfVba {$ref}/{$codigo}: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar PDF'], 500);
        }
    }

    /**
     * Remove (registro + retorna caminhos físicos) o desenho PDF de mesmo codigo
     * de uma SL, para que o re-upload substitua em vez de duplicar.
     */
    private function removerArquivoDesenhoPorCodigo(string $ref, string $codigo): array
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT *
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref
              AND tipo = 'DESENHO_PDF'
              AND codigo = :codigo
        ");
        $stmt->execute([':ref' => $ref, ':codigo' => $codigo]);
        $arquivos = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        if (empty($arquivos)) {
            return [];
        }

        $fisicos = [];
        foreach ($arquivos as $arquivo) {
            $arquivoId = $arquivo->id ?? null;
            if (!$arquivoId) {
                continue;
            }

            $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');
            if (!empty($caminhoFisico)) {
                $fisicos[] = $caminhoFisico;
            }

            $pdo->prepare("DELETE FROM bd_device_request.solicitacao_anexo_arquivos WHERE id = :id")
                ->execute([':id' => $arquivoId]);
        }

        return $fisicos;
    }

    /**
     * Web -> Access (pull): CSV de todos os desenhos PDF (DESENHO_PDF) para o VBA
     * upsertar em PDF_Control. Colunas: Solicitacao;Projeto;Codigo;Revisao.
     * Solicitacao no formato do Access ("SL"+4 dígitos); Projeto = cod_z da SL.
     */
    public function csvDesenhosPdf()
    {
        if (ob_get_level()) {
            ob_end_clean();
        }

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=DesenhosPdf.csv');

        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $rows = $pdo->query("
            SELECT 
                a.ref AS ref,
                a.codigo AS codigo,
                a.nome_original AS nome_original,
                a.nome_arquivo AS nome_arquivo,
                a.caminho AS caminho,
                s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_anexo_arquivos a
            LEFT JOIN bd_device_request.solicitacoes s 
                ON s.ref = a.ref
            WHERE a.tipo = 'DESENHO_PDF'
            ORDER BY a.ref, a.codigo, a.nome_original
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');

        fputs($file, "\xEF\xBB\xBF");

        fputcsv($file, [
            'Solicitacao',
            'Projeto',
            'Codigo',
            'Revisao'
        ], ';');

        foreach ($rows as $r) {
            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);

            $codigo = trim((string)($r->codigo ?? ''));

            if ($codigo === '') {
                $base = trim((string)($r->nome_original ?? ''));

                if ($base === '') {
                    $base = trim((string)($r->nome_arquivo ?? ''));
                }

                if ($base === '') {
                    $base = basename((string)($r->caminho ?? ''));
                }

                $codigo = pathinfo($base, PATHINFO_FILENAME);
            }

            $codigo = trim($codigo);

            if ($codigo === '') {
                continue;
            }

            fputcsv($file, [
                $sl,
                $r->cod_z ?? '',
                $codigo,
                '0'
            ], ';');
        }

        fclose($file);
        exit;
    }

    public function storeItensCompradosTxt(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar itens quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        $arquivosTxt = $this->normalizarFilesArray($_FILES['itens_comprados_txt'] ?? null);

        if (empty($arquivosTxt)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione ao menos um arquivo TXT válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $arquivosCriadosFisicamente = [];

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga dos itens comprados.");
            }

            $cargaId = $saveCarga['id'];
            $qtdTxtSalvos = 0;

            $txtValidos = [];

            foreach ($arquivosTxt as $arquivoTxt) {
                if (!$this->arquivoValido($arquivoTxt)) {
                    continue;
                }

                $this->validarExtensaoArquivo($arquivoTxt, ['txt'], 'TXT de itens comprados');

                $txtValidos[] = $arquivoTxt;
            }

            if (empty($txtValidos)) {
                throw new \Exception("Nenhum TXT válido foi enviado.");
            }

            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'ITENS_COMPRADOS_TXT');

            foreach ($txtValidos as $arquivoTxt) {
                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $arquivoTxt,
                    'ITENS_COMPRADOS_TXT',
                    "{$baseUploadDir}/itens_comprados",
                    "{$baseUploadPath}/itens_comprados",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

                $this->salvarItensCompradosDoTxt(
                    $cargaId,
                    $arquivoSalvo['id'],
                    $ref,
                    $arquivoSalvo['caminho_fisico'],
                    $usuarioLogado
                );

                $qtdTxtSalvos++;
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$qtdTxtSalvos} arquivo(s) TXT de itens comprados adicionado(s) à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("TXT(s) de itens comprados salvo(s) com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar TXT de itens comprados da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar o(s) TXT(s) de itens comprados.");
        }
    }

    /**
     * Access -> Web: recebe os itens de BOM vindos do Access.
     *
     * O VBA envia:
     * ref=NNN
     * dados=Solicitacao;Projeto;Codigo;Revisao;Descricao;Qtde;Tipo
     *
     * Regra:
     * - A BOM do Access vira fonte oficial daquela SL.
     * - Apaga os itens antigos da SL.
     * - Insere novamente tudo que veio do Access.
     * - Permite duas linhas com mesmo Codigo/Revisao, desde que sejam linhas diferentes.
     */
    public function uploadBomVba()
    {
        if (ob_get_level()) {
            ob_end_clean();
        }

        try {
            $ref   = (int) (Request::input('ref') ?? 0);
            $dados = (string) (Request::input('dados') ?? '');

            if ($ref <= 0) {
                return Json::return([
                    'ok' => false,
                    'error' => 'ref inválido'
                ], 400);
            }

            if (trim($dados) === '') {
                return Json::return([
                    'ok' => true,
                    'inseridos' => 0,
                    'message' => 'dados vazio'
                ], 200);
            }

            $solicitacao = Acompanhamento::getByRef($ref);

            if (!$solicitacao) {
                return Json::return([
                    'ok' => false,
                    'error' => 'solicitação não encontrada'
                ], 404);
            }

            $linhas = preg_split('/\r\n|\r|\n/', $dados);

            if (!$linhas || count($linhas) === 0) {
                return Json::return([
                    'ok' => true,
                    'inseridos' => 0
                ], 200);
            }

            $itens = [];

            foreach ($linhas as $idx => $linha) {
                $linhaOriginal = trim((string) $linha);

                if ($linhaOriginal === '') {
                    continue;
                }

                /*
                * Ignora cabeçalho:
                * Solicitacao;Projeto;Codigo;Revisao;Descricao;Qtde;Tipo
                */
                if ($idx === 0 && stripos($linhaOriginal, 'Solicitacao;Projeto;Codigo;Revisao') !== false) {
                    continue;
                }

                $campos = $this->quebrarCsvPontoVirgula($linhaOriginal);

                if (count($campos) < 7) {
                    continue;
                }

                $codigo = trim((string)($campos[2] ?? ''));

                if ($codigo === '') {
                    continue;
                }

                $quantidade = trim((string)($campos[5] ?? '0'));
                $quantidade = str_replace(' ', '', $quantidade);

                if (strpos($quantidade, ',') !== false) {
                    $quantidade = str_replace('.', '', $quantidade);
                    $quantidade = str_replace(',', '.', $quantidade);
                }

                if ($quantidade === '' || !is_numeric($quantidade)) {
                    $quantidade = '0';
                }

                $itens[] = [
                    'codigo'     => $codigo,
                    'rev'        => trim((string)($campos[3] ?? '')),
                    'descricao'  => trim((string)($campos[4] ?? '')),
                    'quantidade' => $quantidade,
                    'tipo'       => trim((string)($campos[6] ?? '')),
                    'linha'      => $linhaOriginal,
                ];
            }

            if (empty($itens)) {
                return Json::return([
                    'ok' => true,
                    'inseridos' => 0,
                    'message' => 'nenhum item válido recebido'
                ], 200);
            }

            $usuarioLogado = 'ACCESS';

            $pdo = SolicitacaoItemComprado::getPDO();

            if (!$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            /*
            * Cria carga para histórico/controle.
            */
            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da BOM.");
            }

            $cargaId = $saveCarga['id'];

            /*
            * Access vira fonte oficial da BOM desta SL.
            */
            $stmtDelete = $pdo->prepare("
                DELETE FROM bd_device_request.solicitacao_itens_comprados
                WHERE ref = :ref
            ");

            $stmtDelete->execute([
                ':ref' => $ref
            ]);

            /*
            * Não cria arquivo marcador em solicitacao_anexo_arquivos.
            * Isso evita erro com campos de arquivo vazios.
            * A BOM será controlada pela tabela solicitacao_itens_comprados.
            */
            $stmtInsert = $pdo->prepare("
                INSERT INTO bd_device_request.solicitacao_itens_comprados
                    (
                        id,
                        carga_id,
                        arquivo_id,
                        ref,
                        codigo,
                        rev,
                        descricao,
                        quantidade,
                        tipo,
                        linha_original,
                        created_by,
                        created_at
                    )
                VALUES
                    (
                        UUID(),
                        :carga_id,
                        NULL,
                        :ref,
                        :codigo,
                        :rev,
                        :descricao,
                        :quantidade,
                        :tipo,
                        :linha_original,
                        :created_by,
                        NOW()
                    )
            ");
            $inseridos = 0;

            foreach ($itens as $it) {
                $stmtInsert->execute([
                    ':carga_id'       => $cargaId,
                    ':ref'            => $ref,
                    ':codigo'         => $it['codigo'],
                    ':rev'            => $it['rev'],
                    ':descricao'      => $it['descricao'],
                    ':quantidade'     => $it['quantidade'],
                    ':tipo'           => $it['tipo'],
                    ':linha_original' => $it['linha'],
                    ':created_by'     => $usuarioLogado,
                ]);

                $inseridos++;
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$inseridos} item(ns) de BOM adicionado(s)/atualizado(s) (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo->inTransaction()) {
                $pdo->commit();
            }

            return Json::return([
                'ok'        => true,
                'inseridos' => $inseridos
            ], 200);

        } catch (\Throwable $e) {
            if (isset($pdo) && $pdo instanceof \PDO && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log("Erro no uploadBomVba: " . $e->getMessage());

            return Json::return([
                'ok' => false,
                'error' => 'falha ao salvar BOM',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Quebra uma linha CSV separada por ponto e vírgula, respeitando aspas.
     *
     * Exemplo:
     * SL5042;Z1000;SIDERÚRGICO;-;"TUBO REDONDO - 0 x 0 x 12,7 mm";18700;"TUBO REDONDO"
     */
    private function quebrarCsvPontoVirgula(string $linha): array
    {
        $campos = [];
        $atual = '';
        $dentroAspas = false;
        $len = strlen($linha);

        for ($i = 0; $i < $len; $i++) {
            $ch = $linha[$i];

            if ($ch === '"') {
                if ($dentroAspas && $i + 1 < $len && $linha[$i + 1] === '"') {
                    $atual .= '"';
                    $i++;
                } else {
                    $dentroAspas = !$dentroAspas;
                }

                continue;
            }

            if ($ch === ';' && !$dentroAspas) {
                $campos[] = trim($atual);
                $atual = '';
                continue;
            }

            $atual .= $ch;
        }

        $campos[] = trim($atual);

        return $campos;
    }

    /**
     * Web -> Access (pull): CSV dos itens de BOM (solicitacao_itens_comprados) p/ o
     * VBA upsertar em BOM_Control.
     * Colunas: Solicitacao;Projeto;Codigo;Revisao;Descricao;Qtde;Tipo.
     */
    public function csvBom()
    {
        if (ob_get_level()) ob_end_clean();

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=Bom.csv');

        // Tira ';' e quebras dos campos livres (o VBA faz Split simples por ';')
        $limpar = function ($v) {
            return str_replace([';', "\r", "\n"], [',', ' ', ' '], (string) $v);
        };

        $pdo = SolicitacaoItemComprado::getPDO();
        $rows = $pdo->query("
            SELECT i.ref AS ref, i.codigo AS codigo, i.rev AS rev, i.descricao AS descricao,
                   i.quantidade AS qtde, i.tipo AS tipo, s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_itens_comprados i
            LEFT JOIN bd_device_request.solicitacoes s ON s.ref = i.ref
            ORDER BY i.ref, i.codigo
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');
        fputs($file, "\xEF\xBB\xBF");
        fputcsv($file, ['Solicitacao', 'Projeto', 'Codigo', 'Revisao', 'Descricao', 'Qtde', 'Tipo'], ';');

        foreach ($rows as $r) {
            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);
            fputcsv($file, [
                $sl,
                $limpar($r->cod_z),
                $limpar($r->codigo),
                $limpar($r->rev),
                $limpar($r->descricao),
                $limpar($r->qtde),
                $limpar($r->tipo),
            ], ';');
        }
        fclose($file);
        exit;
    }

    public function storeProjetista(UpdateRequest $request, int $ref, string $tipo)
    {
        $projetista = $request->input('projetista');

        if (!$projetista) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", [$ref])
                ->withError("Por favor, selecione um projetista.");
        }

        $dadosParaAtualizar = [];

        if ($tipo === 'conceito') {
            $dadosParaAtualizar = [
                'conceito_proj'   => $projetista,
                'conceito_status' => 'BACKLOG'
            ];
        } else if ($tipo === 'detalhamento') {
            $dadosParaAtualizar = [
                'detalhamento_proj' => $projetista
            ];
        }

        if (empty($dadosParaAtualizar)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", [$ref])
                ->withError("Tipo de alocação inválido.");
        }

        $updateProjetista = Acompanhamento::updateByColumn('ref', $ref, $dadosParaAtualizar);

        if (!$updateProjetista) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", [$ref])
                ->withError("Erro interno ao atualizar no banco de dados.");
        }

        return redirect()
            ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
            ->withSuccess('Projetista alocado!');
    }

    public function gerarZ(int $ref)
    {
        $lastZ = Projeto::getLastZ();
        $newZ = $lastZ + 1;
        $slInfos = Acompanhamento::getByRef($ref);

        $saveProjeto = Projeto::create([
            'cod_z'       => $newZ,
            'descricao'   => $slInfos->descricao,
            'vagao'       => $slInfos->vagao,
            'lote'        => $slInfos->lote,
            'solicitante' => $slInfos->solicitante
        ]);

        if (!$saveProjeto) {
            throw new \Exception("Erro ao criar registro no Controle Z.");
        }

        $updateFila = Acompanhamento::updateByColumn('ref', $ref, [
            'cod_z' => $newZ
        ]);

        if (!$updateFila) {
            return redirect()->back()->withError("Não foi possível gerar o Z");
        }

        return redirect()->back()->withSuccess("Z{$newZ} gerado com sucesso!");
    }

    public function associarZ(CodigoZRequest $request, int $ref)
    {
        $zAssociado = $request->get();

        if (!$zAssociado) {
            return redirect()->back()->withError("Não foi possível associar o Z");
        }

        $updateZ = Projeto::updateByColumn('cod_z', $zAssociado['cod_z'], [
            'cod_z'  => $zAssociado['cod_z'],
            'qtdRev' => $zAssociado['qtdRev'],
        ]);

        if (!$updateZ) {
            return redirect()->back()->withError("Não foi possível criar nova revisão para o Z");
        }

        $updateFila = Acompanhamento::updateByColumn('ref', $ref, [
            'cod_z'  => $zAssociado['cod_z'],
            'qtdRev' => $zAssociado['qtdRev'],
        ]);

        if (!$updateFila) {
            return redirect()->back()->withError("Não foi possível associar o Z");
        }

        return redirect()->back()->withSuccess("Z{$zAssociado['cod_z']} associado com sucesso!");
    }

    public function visualizarArquivoSolicitacao(string $id)
    {
        return $this->entregarArquivoSolicitacao($id, true);
    }

    public function downloadArquivoSolicitacao(string $id)
    {
        return $this->entregarArquivoSolicitacao($id, false);
    }

    private function entregarArquivoSolicitacao(string $id, bool $inline = false)
    {
        $arquivo = $this->buscarArquivoSolicitacaoPorId($id);
        // dd($arquivo);
        if (!$arquivo) {
            return redirect()
                ->back()
                ->withError("Arquivo não encontrado.");
        }

        $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');
        
        if (!$caminhoFisico || !file_exists($caminhoFisico)) {
            return redirect()
                ->back()
                ->withError("Arquivo não localizado no servidor.");
        }

        $nomeOriginal = $arquivo->nome_original ?? basename($caminhoFisico);

        $mimeType = $arquivo->mime_type ?? null;

        if (!$mimeType && function_exists('mime_content_type')) {
            $mimeType = mime_content_type($caminhoFisico);
        }

        if (!$mimeType) {
            $mimeType = 'application/octet-stream';
        }

        while (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Type: ' . $mimeType);
        header('Content-Length: ' . filesize($caminhoFisico));

        if ($inline) {
            header('Content-Disposition: inline; filename="' . basename($nomeOriginal) . '"');
        } else {
            header('Content-Disposition: attachment; filename="' . basename($nomeOriginal) . '"');
        }

        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');

        readfile($caminhoFisico);
        exit;
    }

    private function criarMapaCargas(array $cargas): array
    {
        $mapa = [];

        foreach ($cargas as $carga) {
            if (!empty($carga->id)) {
                $mapa[$carga->id] = $carga;
            }
        }

        return $mapa;
    }

    private function gerarProximoCodigoDxf(string $ref): string
    {
        $numero = $this->proximoNumeroDxfGlobal();

        return 'DX' . str_pad((string) $numero, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Próximo número global de DXF, espelhando o MAX(Controle)+1 do DXF_Control do
     * Access. Como o histórico do DXF_Control não foi migrado, usamos um PISO
     * (APP_DXF_FLOOR = MAX(Controle) atual do Access) para o contador da web não
     * reiniciar em 1 e colidir com os DX legados. `$floorExtra` permite o Access
     * passar o próprio MAX no momento da criação (rota nextDxf).
     */
    /**
     * Próximo número global de DXF.
     *
     * Usa o cartório:
     * bd_device_request.controle_sequencial
     *
     * E também se protege olhando:
     * - dxf_control_access, que veio exportado do Access
     * - solicitacao_anexo_arquivos, que são DXFs já criados pelo web
     */
    private function proximoNumeroDxfGlobal(int $floorExtra = 0): int
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $lock = $pdo->query("SELECT GET_LOCK('solic_dxf_global', 10)")->fetchColumn();

        if ((int) $lock !== 1) {
            throw new \Exception("Não foi possível obter lock para gerar DXF.");
        }

        try {
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS bd_device_request.controle_sequencial (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    chave VARCHAR(50) NOT NULL UNIQUE,
                    ultimo_numero INT NOT NULL DEFAULT 0,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");

            $maxAccess = 0;
            try {
                $maxAccess = (int) $pdo->query("
                    SELECT COALESCE(MAX(controle), 0)
                    FROM bd_device_request.dxf_control_access
                ")->fetchColumn();
            } catch (\Throwable $e) {
                $maxAccess = 0;
            }

            $maxWeb = 0;
            try {
                $maxWeb = (int) $pdo->query("
                    SELECT COALESCE(MAX(CAST(REGEXP_REPLACE(codigo, '[^0-9]', '') AS UNSIGNED)), 0)
                    FROM bd_device_request.solicitacao_anexo_arquivos
                    WHERE tipo = 'PACOTE_DXF'
                    AND codigo REGEXP '^DX[0-9]+$'
                ")->fetchColumn();
            } catch (\Throwable $e) {
                $maxWeb = 0;
            }

            $pisoEnv = (int) ($_ENV['APP_DXF_FLOOR'] ?? 0);

            $piso = max(
                $pisoEnv,
                $floorExtra,
                $maxAccess,
                $maxWeb
            );

            $stmt = $pdo->prepare("
                INSERT INTO bd_device_request.controle_sequencial
                    (chave, ultimo_numero)
                VALUES
                    ('DXF_GLOBAL', :piso)
                ON DUPLICATE KEY UPDATE
                    ultimo_numero = GREATEST(ultimo_numero, VALUES(ultimo_numero))
            ");

            $stmt->execute([
                ':piso' => $piso
            ]);

            $pdo->exec("
                UPDATE bd_device_request.controle_sequencial
                SET ultimo_numero = LAST_INSERT_ID(ultimo_numero + 1)
                WHERE chave = 'DXF_GLOBAL'
            ");

            $numero = (int) $pdo->query("SELECT LAST_INSERT_ID()")->fetchColumn();

            if ($numero <= 0) {
                throw new \Exception("Falha ao gerar próximo número DXF.");
            }

            return $numero;

        } finally {
            $pdo->query("SELECT RELEASE_LOCK('solic_dxf_global')")->fetchColumn();
        }
    }

    /**
     * Access -> Web: recebe o XLSX da Lista de Materiais vindo do Access.
     *
     * O Access envia corpo binário cru.
     *
     * Query string:
     * ?ref=NNN&cod_z=Z1000&solicitacao=SL5042&nome=arquivo.xlsx
     *
     * Salva como LISTA_MATERIAIS.
     * Pela função caminhoAccess(), o destino fica:
     * .bom/Zxxxx - SLxxxx - Lista_Materiais.xlsx
     */
    public function uploadListaMateriaisVba()
    {
        $ref         = (int) (Request::query('ref') ?? 0);
        $codZ        = trim((string) (Request::query('cod_z') ?? ''));
        $solicitacao = trim((string) (Request::query('solicitacao') ?? ''));
        $nome        = Request::query('nome') ?: ('Lista_Materiais.xlsx');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }

        $solicitacaoObj = Acompanhamento::getByRef($ref);

        if (!$solicitacaoObj) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        $conteudo = file_get_contents('php://input');

        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $ext = strtolower(pathinfo((string) $nome, PATHINFO_EXTENSION));

        if (!in_array($ext, ['xls', 'xlsx', 'csv'], true)) {
            return Json::return(['error' => 'extensão inválida para lista de materiais'], 400);
        }

        $usuarioLogado = 'ACCESS';

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da Lista de Materiais.");
            }

            /*
            * Substitui a Lista de Materiais anterior da mesma SL.
            * O arquivo físico antigo só é apagado depois do commit.
            */
            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'LISTA_MATERIAIS');

            /*
            * Salva usando a arquitetura do Access.
            * caminhoAccess('LISTA_MATERIAIS') deve retornar:
            * .bom/Zxxxx - SLxxxx - Lista_Materiais.xlsx
            */
            [$subpasta, $nomeSeguro] = $this->caminhoAccess(
                'LISTA_MATERIAIS',
                (string) $ref,
                null,
                $nome
            );

            $dirStorage = $this->storageBase() . '/' . $subpasta;

            if (!is_dir($dirStorage)) {
                mkdir($dirStorage, 0777, true);
            }

            $caminhoFisico   = $dirStorage . '/' . $nomeSeguro;
            $caminhoRelativo = $subpasta . '/' . $nomeSeguro;

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar o XLSX da Lista de Materiais.");
            }

            $caminhoFisicoNovo = $caminhoFisico;

            /*
            * Espelha para APP_STORAGE_MAPPED, se configurado.
            */
            $this->espelharNoMapeado($subpasta, $nomeSeguro, $caminhoFisico);

            $mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

            if ($ext === 'xls') {
                $mimeType = 'application/vnd.ms-excel';
            } elseif ($ext === 'csv') {
                $mimeType = 'text/csv';
            }

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'LISTA_MATERIAIS',
                'codigo'        => null,
                'nome_original' => basename((string) $nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => $mimeType,
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);

            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro da Lista de Materiais.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Lista de Materiais XLSX adicionada/atualizada (Access).',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return([
                'ok'      => true,
                'tipo'    => 'LISTA_MATERIAIS',
                'arquivo' => $nomeSeguro,
                'caminho' => $caminhoRelativo
            ], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }

            error_log("Erro no uploadListaMateriaisVba {$ref}: " . $e->getMessage());

            return Json::return(['error' => 'falha ao salvar Lista de Materiais'], 500);
        }
    }
    /**
     * Cartório do número de DXF: o Access (ufdxf) pede aqui o próximo Controle para
     * os dois lados compartilharem a MESMA numeração global (igual ao Ref).
     * Serializa com GET_LOCK. Aceita ?floor=N (MAX(Controle) atual do Access).
     * Devolve { "controle": N, "codigo": "DX000N" }.
     */
    public function nextDxf()
    {
        try {
            $floor = (int) (Request::query('floor') ?? 0);

            $numero = $this->proximoNumeroDxfGlobal($floor);

            return Json::return([
                'controle' => $numero,
                'codigo'   => 'DX' . str_pad((string) $numero, 4, '0', STR_PAD_LEFT),
            ], 200);

        } catch (\Throwable $e) {
            error_log("Erro ao gerar próximo DXF: " . $e->getMessage());

            return Json::return([
                'error' => 'falha ao gerar próximo DXF'
            ], 500);
        }
    }

    private function separarArquivosSolicitacao(array $arquivos): array
    {
        $separados = [
            'IMAGEM_PROJETO'      => [],
            'PACOTE_DXF'          => [],
            'ITENS_COMPRADOS_TXT' => [],
            'LISTA_MATERIAIS'     => [],
            'DESENHO_PDF'         => [],
            'OUTROS'              => []
        ];

        foreach ($arquivos as $arquivo) {
            $tipo = strtoupper(trim((string)($arquivo->tipo ?? '')));

            if (isset($separados[$tipo])) {
                $separados[$tipo][] = $arquivo;
                continue;
            }

            $separados['OUTROS'][] = $arquivo;
        }

        return $separados;
    }

    private function buscarArquivoSolicitacaoPorId(string $id)
    {
        $arquivos = SolicitacaoAnexoArquivo::select(['*'])
            ->where('id', '=', $id)
            ->finish() ?: [];

        return $arquivos[0] ?? null;
    }

    private function removerArquivosExistentesPorTipo(string $ref, string $tipo): array
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT *
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref
            AND tipo = :tipo
        ");

        $stmt->execute([
            ':ref'  => $ref,
            ':tipo' => $tipo
        ]);

        $arquivos = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        if (empty($arquivos)) {
            return [];
        }

        $arquivosFisicosParaRemover = [];

        foreach ($arquivos as $arquivo) {
            $arquivoId = $arquivo->id ?? null;

            if (!$arquivoId) {
                continue;
            }

            $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');

            if (!empty($caminhoFisico)) {
                $arquivosFisicosParaRemover[] = $caminhoFisico;
            }

            if ($tipo === 'ITENS_COMPRADOS_TXT') {
                $deleteItens = $pdo->prepare("
                    DELETE FROM bd_device_request.solicitacao_itens_comprados
                    WHERE arquivo_id = :arquivo_id
                ");

                $deleteItens->execute([
                    ':arquivo_id' => $arquivoId
                ]);
            }

            $deleteArquivo = $pdo->prepare("
                DELETE FROM bd_device_request.solicitacao_anexo_arquivos
                WHERE id = :id
            ");

            $deleteArquivo->execute([
                ':id' => $arquivoId
            ]);
        }

        return $arquivosFisicosParaRemover;
    }

    /**
     * Garante compatibilidade com o Access para desenhos PDF.
     *
     * No Access antigo, cada desenho PDF era copiado para:
     * 1) Controle\desenhosPDF\SLxxxx\SLxxxx - CODIGO.pdf
     * 2) Controle\.desenhos\SLxxxx - CODIGO.pdf
     */
    private function copiarDesenhoPdfParaPastasAccess(
        string $ref,
        ?string $codigo,
        string $nomeOriginal,
        string $origemFisica
    ): void {
        if (!is_file($origemFisica)) {
            return;
        }

        $sl = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT);

        $cod = trim((string) $codigo);
        if ($cod === '') {
            $cod = pathinfo($nomeOriginal, PATHINFO_FILENAME);
        }

        $nomeArquivo = $sl . ' - ' . $this->nomeBaseSeguroAccess($cod) . '.pdf';

        $destinos = [
            '.desenhos'        => $nomeArquivo,
            'desenhosPDF/' . $sl => $nomeArquivo,
        ];

        foreach ($destinos as $subpasta => $nomeDestino) {
            $dir = $this->storageBase() . '/' . $subpasta;

            if (!is_dir($dir)) {
                @mkdir($dir, 0777, true);
            }

            $destino = $dir . '/' . $nomeDestino;

            $origemNorm  = str_replace('\\', '/', $origemFisica);
            $destinoNorm = str_replace('\\', '/', $destino);

            if ($origemNorm !== $destinoNorm) {
                @copy($origemFisica, $destino);
            }

            $this->espelharNoMapeado($subpasta, $nomeDestino, $destino);
        }
    }
    private function salvarArquivoSolicitacao(
        string $cargaId,
        string $ref,
        array $arquivo,
        string $tipo,
        string $diretorioFisico,
        string $diretorioRelativo,
        string $usuarioLogado,
        ?string $codigo = null
    ): array {
        if (!$this->arquivoValido($arquivo)) {
            throw new \Exception("Arquivo inválido para o tipo {$tipo}.");
        }

        $nomeOriginal = $arquivo['name'];

        // Storage do web na ARQUITETURA DO ACCESS (mesma p/ storage e storage-mapped).
        // ($diretorioFisico/$diretorioRelativo recebidos ficam só por compatibilidade.)
        [$subpasta, $nomeArquivo] = $this->caminhoAccess($tipo, $ref, $codigo, $nomeOriginal);

        $dirStorage = $this->storageBase() . '/' . $subpasta;
        if (!is_dir($dirStorage)) {
            mkdir($dirStorage, 0777, true);
        }

        $caminhoFisico   = $dirStorage . '/' . $nomeArquivo;
        $caminhoRelativo = $subpasta . '/' . $nomeArquivo;

        if (!move_uploaded_file($arquivo['tmp_name'], $caminhoFisico)) {
            throw new \Exception("Não foi possível mover o arquivo {$nomeOriginal}.");
        }

        // Salva também no storage-mapped (mesma estrutura) para o Access enxergar
        $this->espelharNoMapeado($subpasta, $nomeArquivo, $caminhoFisico);
        if ($tipo === 'DESENHO_PDF') {
            $this->copiarDesenhoPdfParaPastasAccess($ref, $codigo, $nomeOriginal, $caminhoFisico);
        }
        $saveArquivo = SolicitacaoAnexoArquivo::create([
            'carga_id'      => $cargaId,
            'ref'           => $ref,
            'tipo'          => $tipo,
            'codigo'        => $codigo,
            'nome_original' => $nomeOriginal,
            'nome_arquivo'  => $nomeArquivo,
            'caminho'       => $caminhoRelativo,
            'mime_type'     => $arquivo['type'] ?? null,
            'tamanho_bytes' => $arquivo['size'] ?? null,
            'created_by'    => $usuarioLogado
        ]);

        if (!$saveArquivo || empty($saveArquivo['id'])) {
            throw new \Exception("Não foi possível salvar o registro do arquivo {$nomeOriginal}.");
        }

        return [
            'id'               => $saveArquivo['id'],
            'codigo'           => $codigo,
            'nome_original'    => $nomeOriginal,
            'nome_arquivo'     => $nomeArquivo,
            'caminho_fisico'   => $caminhoFisico,
            'caminho_relativo' => $caminhoRelativo,
            'tipo'             => $tipo
        ];
    }

    private function salvarItensCompradosDoTxt(
        string $cargaId,
        string $arquivoId,
        string $ref,
        string $caminhoFisico,
        string $usuarioLogado
    ): void {
        if (!file_exists($caminhoFisico)) {
            return;
        }

        $conteudo = file_get_contents($caminhoFisico);

        if ($conteudo === false || trim($conteudo) === '') {
            return;
        }

        $conteudo = $this->normalizarEncodingTexto($conteudo);

        $linhas = preg_split('/\r\n|\r|\n/', $conteudo);

        if (!$linhas) {
            return;
        }

        foreach ($linhas as $linha) {
            $linhaOriginal = trim($linha);

            if ($linhaOriginal === '') {
                continue;
            }

            $item = $this->parseLinhaItemComprado($linhaOriginal);

            if (
                empty($item['codigo']) &&
                empty($item['rev']) &&
                empty($item['descricao']) &&
                empty($item['quantidade']) &&
                empty($item['tipo'])
            ) {
                continue;
            }

            SolicitacaoItemComprado::create([
                'carga_id'       => $cargaId,
                'arquivo_id'     => $arquivoId,
                'ref'            => $ref,
                'codigo'         => $item['codigo'],
                'rev'            => $item['rev'],
                'descricao'      => $item['descricao'],
                'quantidade'     => $item['quantidade'],
                'tipo'           => $item['tipo'],
                'linha_original' => $linhaOriginal,
                'created_by'     => $usuarioLogado
            ]);
        }
    }

    private function parseLinhaItemComprado(string $linha): array
    {
        $linha = str_replace("\xc2\xa0", ' ', $linha);
        $linha = trim($linha);

        $partes = preg_split('/\t+|\s{2,}/u', $linha);

        $partes = array_values(array_filter(array_map('trim', $partes), function ($parte) {
            return $parte !== '';
        }));

        $item = [
            'codigo'     => '',
            'rev'        => '',
            'descricao'  => '',
            'quantidade' => '',
            'tipo'       => '',
        ];

        if (count($partes) === 0) {
            return $item;
        }

        $item['codigo'] = $partes[0] ?? '';
        $item['rev'] = $partes[1] ?? '';

        $indiceQuantidade = null;

        foreach ($partes as $index => $parte) {
            if ($index <= 1) {
                continue;
            }

            if ($this->ehQuantidade($parte)) {
                $indiceQuantidade = $index;
                break;
            }
        }

        if ($indiceQuantidade !== null) {
            $descricaoPartes = array_slice($partes, 2, $indiceQuantidade - 2);
            $tipoPartes = array_slice($partes, $indiceQuantidade + 1);

            $item['descricao'] = trim(implode(' ', $descricaoPartes));
            $item['quantidade'] = $partes[$indiceQuantidade] ?? '';
            $item['tipo'] = trim(implode(' ', $tipoPartes));
        } else {
            $descricaoPartes = array_slice($partes, 2);
            $item['descricao'] = trim(implode(' ', $descricaoPartes));
        }

        return $item;
    }

    private function ehQuantidade(string $valor): bool
    {
        $valor = trim($valor);

        if ($valor === '') {
            return false;
        }

        return (bool) preg_match('/^-?\d+([,.]\d+)?$/', $valor)
            || (bool) preg_match('/^-?\d{1,3}(\.\d{3})+([,.]\d+)?$/', $valor);
    }

    private function normalizarFilesArray(?array $files): array
    {
        if (empty($files)) {
            return [];
        }

        if (!isset($files['name'])) {
            return [];
        }

        if (!is_array($files['name'])) {
            return [$files];
        }

        $arquivos = [];

        foreach ($files['name'] as $index => $name) {
            $arquivos[] = [
                'name'     => $files['name'][$index] ?? null,
                'type'     => $files['type'][$index] ?? null,
                'tmp_name' => $files['tmp_name'][$index] ?? null,
                'error'    => $files['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size'     => $files['size'][$index] ?? 0,
            ];
        }

        return $arquivos;
    }

    private function arquivoValido(?array $arquivo): bool
    {
        if (empty($arquivo)) {
            return false;
        }

        if (!isset($arquivo['error'])) {
            return false;
        }

        if ((int)$arquivo['error'] !== UPLOAD_ERR_OK) {
            return false;
        }

        if (empty($arquivo['tmp_name'])) {
            return false;
        }

        if (!is_uploaded_file($arquivo['tmp_name'])) {
            return false;
        }

        return true;
    }

    private function validarExtensaoArquivo(array $arquivo, array $extensoesPermitidas, string $descricao): void
    {
        $nome = $arquivo['name'] ?? '';
        $extensao = strtolower(pathinfo($nome, PATHINFO_EXTENSION));

        if (!in_array($extensao, $extensoesPermitidas, true)) {
            throw new \Exception("Arquivo inválido para {$descricao}. Extensão enviada: {$extensao}.");
        }
    }

    /** Base física do storage do web. */
    private function storageBase(): string
    {
        return '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files';
    }

   /**
     * Subpasta + nome do arquivo na ARQUITETURA DO ACCESS.
     * A mesma estrutura vale para o storage do web e para o storage-mapped.
     * Retorna [subpasta, nomeArquivo].
     */
    private function caminhoAccess(string $tipo, string $ref, ?string $codigo, string $nomeOriginal): array
    {
        $sl  = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT);
        $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));
        $cod = trim((string) $codigo);

        $codZ = $this->codZAccess($ref);

        switch ($tipo) {
            case 'IMAGEM_PROJETO':
                return [
                    '.img_sl',
                    $sl . '.jpg'
                ];

        case 'DESENHO_PDF':
            $c = $cod !== '' ? $cod : pathinfo($nomeOriginal, PATHINFO_FILENAME);

            return [
                'desenhosPDF/' . $sl,
                $sl . ' - ' . $this->nomeBaseSeguroAccess($c) . '.pdf'
            ];

            case 'PACOTE_DXF':
                return [
                    '.dxf',
                    ($cod !== '' ? $cod : $sl) . '.zip'
                ];

            case 'LISTA_MATERIAIS':
                /*
                * XLSX igual ao Access:
                * Controle\.bom\Zxxxx - SLxxxx - Lista_Materiais.xlsx
                */
                return [
                    '.bom',
                    ($codZ !== '' ? $codZ . ' - ' : '') . $sl . ' - Lista_Materiais.' . ($ext ?: 'xlsx')
                ];

            case 'ITENS_COMPRADOS_TXT':
                /*
                * TXT volta para itens_comprados.
                * Ele continua sendo processado para gerar BOM_Control via csvBom().
                */
                return [
                    'itens_comprados',
                    $sl . '_' . $this->gerarNomeArquivoSeguro($ref, $tipo, $ext ?: 'txt')
                ];

            default:
                $pasta = strtolower(preg_replace('/[^a-z0-9_]+/i', '_', $tipo));

                return [
                    $pasta,
                    $this->gerarNomeArquivoSeguro($ref, $tipo, $ext)
                ];
        }
    }

    /**
     * Busca o Cod_Z da solicitação e devolve no padrão do Access: Z1234.
     */
    private function codZAccess(string $ref): string
    {
        try {
            $solicitacao = Acompanhamento::getByRef($ref);

            $codZ = trim((string)($solicitacao->cod_z ?? ''));

            if ($codZ === '') {
                return '';
            }

            $codZ = strtoupper($codZ);

            if (strpos($codZ, 'Z') !== 0) {
                $codZ = 'Z' . $codZ;
            }

            return $codZ;
        } catch (\Throwable $e) {
            return '';
        }
    }

    /**
     * Limpa caracteres problemáticos para nome de arquivo no Windows/Access.
     */
    private function nomeBaseSeguroAccess(string $nome): string
    {
        $nome = trim($nome);

        if ($nome === '') {
            return 'Arquivo';
        }

        $nome = preg_replace('/[\\\\\/:*?"<>|]+/', '_', $nome);
        $nome = preg_replace('/\s+/', ' ', $nome);
        $nome = trim($nome);

        return $nome !== '' ? $nome : 'Arquivo';
    }

    /**
     * Espelha um arquivo já gravado no storage para o storage-mapped (mesma
     * subpasta/nome), para o Access enxergar. Não faz nada se APP_STORAGE_MAPPED
     * não estiver configurado.
     */
    private function espelharNoMapeado(string $subpasta, string $nomeArquivo, string $caminhoFisicoStorage): void
    {
        if (!is_file($caminhoFisicoStorage)) {
            return;
        }
        $base = rtrim($_ENV['APP_STORAGE_MAPPED'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') {
            return;
        }
        $dir = $base . '/' . $subpasta;
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
        }
        @copy($caminhoFisicoStorage, $dir . '/' . $nomeArquivo);
    }

    private function gerarNomeArquivoSeguro(string $ref, string $tipo, string $extensao): string
    {
        $tipo = strtolower($tipo);
        $tipo = preg_replace('/[^a-z0-9_]+/', '_', $tipo);

        $extensao = strtolower($extensao);
        $extensao = preg_replace('/[^a-z0-9]+/', '', $extensao);

        $hash = bin2hex(random_bytes(8));
        $data = date('Ymd_His');

        if ($extensao) {
            return "{$ref}_{$tipo}_{$data}_{$hash}.{$extensao}";
        }

        return "{$ref}_{$tipo}_{$data}_{$hash}";
    }

private function resolverCaminhoArquivo(string $caminho): ?string
{
    $caminho = trim($caminho);

    if ($caminho === '') {
        return null;
    }

    $caminho = str_replace('\\', '/', $caminho);

    if (file_exists($caminho)) {
        return $caminho;
    }

    $baseFiles = '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files';
    $baseMapped = '/var/www/htdocs/greenbrier/v2/solic_dispositivos-storage-mappeddd';

    $caminhoLimpo = ltrim($caminho, '/');

    $possiveis = [
        $baseMapped . '/' . $caminhoLimpo,
        $baseFiles . '/' . $caminhoLimpo,

        '/var/www/htdocs/greenbrier/v2/solic_dispositivos-storage-mappeddd/' . $caminhoLimpo,
        '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/' . $caminhoLimpo,

        '/var/www/htdocs/' . $caminhoLimpo,
        dirname(__DIR__, 3) . '/' . $caminhoLimpo
    ];

    foreach ($possiveis as $possivel) {
        $possivel = str_replace('\\', '/', $possivel);

        if (file_exists($possivel)) {
            return $possivel;
        }
    }

    return null;
}

    private function normalizarEncodingTexto(string $conteudo): string
    {
        if (function_exists('mb_detect_encoding')) {
            $encoding = mb_detect_encoding($conteudo, ['UTF-8', 'Windows-1252', 'ISO-8859-1'], true);

            if ($encoding && strtoupper($encoding) !== 'UTF-8') {
                return mb_convert_encoding($conteudo, 'UTF-8', $encoding);
            }

            return $conteudo;
        }

        $convertido = @iconv('Windows-1252', 'UTF-8//IGNORE', $conteudo);

        if ($convertido !== false && trim($convertido) !== '') {
            return $convertido;
        }

        return $conteudo;
    }

    private function podeCarregarArquivos($solicitacao): bool
    {
        $statusConceito = strtoupper(trim((string)($solicitacao->status_conceito ?? $solicitacao->conceito_status ?? '')));
        $statusDetalhe  = strtoupper(trim((string)($solicitacao->status_detalhe ?? $solicitacao->detalhamento_status ?? '')));

        return $statusConceito === 'OK' && $statusDetalhe === 'OK';
    }

    private function usuarioLogado(): string
    {
        // return $_SESSION['usuarioNome']
        //     ?? $_SESSION['usuarioLogin']
        //     ?? $_SESSION['usuario']
        //     ?? 'SISTEMA';
        return Usuario::nomeNoAccess();
    }

    /* ======================================================================
     *  LIBERACAO DE SL  +  AQUISICAO
     *  Adicionado em 2026-07-21. Ver docs/doc-alteracoes/.
     * ====================================================================== */

    /** Cache do corpo JSON da requisição (php://input só pode ser lido uma vez). */
    private static ?array $corpoJson = null;

    /**
     * Matrículas autorizadas a PULAR a liquidação e dar OK na aquisição.
     * Recurso de TESTE — ver docs/doc-alteracoes/2026-07-21b-...md.
     */
    private const MATRICULAS_BYPASS_AQUISICAO = ['459844'];

    /** Matrícula do usuário logado, nos formatos usados pelo projeto. */
    private function matriculaLogada(): string
    {
        return trim((string) (
            $_SESSION['user']['matricula']
            ?? $_SESSION['usuarioMatricula']
            ?? ''
        ));
    }

    /** A matrícula logada pode pular a liquidação da aquisição? */
    private function podeBypassAquisicao(): bool
    {
        // 9ª rodada — liberado para TODOS por enquanto.
        // Para restringir de novo: return in_array($this->matriculaLogada(), self::MATRICULAS_BYPASS_AQUISICAO, true);
        return true;
    }

    /**
     * Lê um campo do corpo da requisição aceitando $_POST OU JSON.
     *
     * src\support\Request::input() enxerga apenas $_POST — quando o fetch()
     * envia Content-Type: application/json o PHP não popula $_POST e o campo
     * chegaria nulo. Este helper cobre os dois formatos.
     */
    private function entrada(string $campo, ?string $padrao = null): ?string
    {
        if (isset($_POST[$campo]) && !is_array($_POST[$campo])) {
            return (string) $_POST[$campo];
        }

        if (self::$corpoJson === null) {
            $bruto = file_get_contents('php://input');
            $json  = json_decode((string) $bruto, true);

            self::$corpoJson = is_array($json) ? $json : [];
        }

        if (isset(self::$corpoJson[$campo]) && !is_array(self::$corpoJson[$campo])) {
            return (string) self::$corpoJson[$campo];
        }

        return $padrao;
    }

    /**
     * GET - Modal "Liberar SL".
     * Mostra o resumo dos itens comprados e pede a consideracao que sera
     * gravada no historico (chatbox).
     */
    public function modalLiberacao(int $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return Json::return(['error' => 'Solicitação não encontrada'], 404);
        }

        $resumo = SolicitacaoItemComprado::resumoLiquidacao($ref);

        return view('modals.liberacao.modal', [
            'ref'          => $ref,
            'solicitacao'  => $solicitacao,
            'resumo'       => $resumo,
            'possuiItens'  => $resumo['total'] > 0,
            'jaLiberada'   => strtoupper(trim((string) $solicitacao->liberacao_status)) === 'OK',
        ]);
    }

    /**
     * POST - Confirma a liberacao da SL.
     *
     *  1. liberacao_status  -> OK  (+ liberacao_data)
     *  2. a mensagem digitada vai para o historico (chatbox)
     *  3. roteamento da proxima etapa:
     *       TEM itens comprados  -> aquisicao_status = PENDENTE
     *       NAO tem              -> aquisicao_status = OK e segue para o corte
     */
    public function storeLiberacao(int $ref)
    {
        $mensagem = trim((string) ($this->entrada('mensagem') ?? ''));

        if ($mensagem === '') {
            return Json::return([
                'success' => false,
                'message' => 'Descreva a liberação antes de confirmar.',
            ], 422);
        }

        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return Json::return([
                'success' => false,
                'message' => 'Solicitação não encontrada.',
            ], 404);
        }

        if (strtoupper(trim((string) $solicitacao->liberacao_status)) === 'OK') {
            return Json::return([
                'success' => false,
                'message' => 'Esta SL já está liberada.',
            ], 409);
        }

        $usuario     = $this->usuarioLogado();
        $possuiItens = SolicitacaoItemComprado::possuiItens($ref);
        $agora       = date('Y-m-d H:i:s');

        $dados = [
            'liberacao_status' => 'OK',
            'liberacao_data'   => $agora,
        ];

        if ($possuiItens) {
            // Tem item comprado/siderurgico -> passa pelo comprador.
            $dados['aquisicao_status'] = 'PENDENTE';
        } else {
            // Nada a comprar -> aquisicao ja nasce concluida e o corte abre.
            $dados['aquisicao_status'] = 'OK';
            $dados['aquisicao_data']   = $agora;

            if (empty(trim((string) $solicitacao->corte_status))) {
                $dados['corte_status'] = 'PARADO';
            }
        }

        $atualizou = Acompanhamento::updateByColumn('ref', $ref, $dados);

        if (!$atualizou) {
            return Json::return([
                'success' => false,
                'message' => 'Não foi possível atualizar o status de liberação.',
            ], 500);
        }

        // Cronômetro da aquisição: abre o relógio (PENDENTE) ou já fecha (OK)
        $this->carimbarCronometro($ref, 'aquisicao_status', $dados['aquisicao_status']);

        // Consideracao do usuario no chatbox
        Historico::create([
            'ref'      => $ref,
            'usuario'  => $usuario,
            'mensagem' => $mensagem,
            'situacao' => 'liberacao',
        ]);

        // Registro automatico do roteamento, para deixar a decisao auditavel
        $resumo = SolicitacaoItemComprado::resumoLiquidacao($ref);

        $mensagemRoteamento = $possuiItens
            ? "SL liberada. Encaminhada para AQUISIÇÃO com {$resumo['total']} item(ns) a liquidar."
            : 'SL liberada. Sem itens comprados — aquisição concluída automaticamente.';

        Historico::create([
            'ref'      => $ref,
            'usuario'  => $usuario,
            'mensagem' => $mensagemRoteamento,
            'situacao' => 'liberacao',
        ]);

        return Json::return([
            'success'     => true,
            'message'     => $possuiItens
                ? 'SL liberada e enviada para Aquisição.'
                : 'SL liberada.',
            'possuiItens' => $possuiItens,
        ], 200);
    }

    /**
     * POST - Salva N OC / pedido / liquidacao de UM item comprado.
     * Chamado pela pesquisa da aba de Aquisicao (edicao inline).
     */
    public function storeItemAquisicao(string $id)
    {
        if (!SolicitacaoItemComprado::temColunasAquisicao()) {
            return Json::return([
                'success' => false,
                'message' => 'Banco desatualizado: rode a migration '
                    . '2026-07-21-aquisicao-itens-comprados.sql.',
            ], 503);
        }

        $item = SolicitacaoItemComprado::getByColumn('id', $id);

        if (!$item) {
            return Json::return([
                'success' => false,
                'message' => 'Item não encontrado.',
            ], 404);
        }

        // Só o N° OC é digitado. O pedido e a liquidação vêm da rotina do Logix.
        $nOc = trim((string) ($this->entrada('n_oc') ?? ''));

        $salvou = SolicitacaoItemComprado::salvarOc(
            $id,
            $nOc,
            $this->usuarioLogado()
        );

        if (!$salvou) {
            return Json::return([
                'success' => false,
                'message' => 'Não foi possível salvar a OC.',
            ], 500);
        }

        $ref    = (int) $item->ref;
        $resumo = SolicitacaoItemComprado::resumoLiquidacao($ref);

        return Json::return([
            'success'       => true,
            'message'       => $nOc === ''
                ? 'OC removida.'
                : 'OC gravada. O pedido e a liquidação serão preenchidos pela rotina do Logix.',
            'resumo'        => $resumo,
            'podeFinalizar' => $resumo['total'] > 0 && $resumo['pendentes'] === 0,
        ], 200);
    }

    /**
     * GET - ROTINA AUTOMÁTICA (cron): consulta o Logix e atualiza os itens.
     *
     * Para cada item que tem OC preenchida e ainda não está liquidado,
     * pergunta ao Logix se a ordem já tem pedido e se está liquidada, e grava
     * o retorno.
     *
     * NÃO conclui a aquisição sozinha: quando o último item de uma SL é
     * liquidado, apenas registra no histórico que ela está pronta. O OK final
     * continua sendo de uma pessoa (botão "Concluir aquisição").
     *
     * Protegida por token — ver APP_CRON_TOKEN no .env.
     * O agendamento sugerido (crontab, a cada 15 min) está documentado em
     * docs/doc-alteracoes/2026-07-21-responsivo-liberacao-aquisicao.md
     */
    public function sincronizarLogix()
    {
        $tokenConfigurado = trim((string) ($_ENV['APP_CRON_TOKEN'] ?? ''));

        if ($tokenConfigurado === '') {
            return Json::return([
                'success' => false,
                'message' => 'APP_CRON_TOKEN não configurado no .env. '
                    . 'Defina um valor secreto antes de habilitar a rotina.',
            ], 503);
        }

        if (!hash_equals($tokenConfigurado, (string) (Request::query('token') ?? ''))) {
            return Json::return([
                'success' => false,
                'message' => 'Token inválido.',
            ], 403);
        }

        if (!SolicitacaoItemComprado::temColunasAquisicao()) {
            return Json::return([
                'success' => false,
                'message' => 'Banco desatualizado: rode a migration '
                    . '2026-07-21-aquisicao-itens-comprados.sql.',
            ], 503);
        }

        if (!LogixOrdemCompraService::configurado()) {
            return Json::return([
                'success' => false,
                'message' => 'Consulta ao Logix ainda não preenchida — '
                    . 'ver SQL_CONSULTA_OC em src/app/services/LogixOrdemCompraService.php.',
            ], 503);
        }

        $itens = SolicitacaoItemComprado::pendentesDeSincronizacao();

        if (empty($itens)) {
            return Json::return([
                'success'    => true,
                'message'    => 'Nenhum item pendente de consulta.',
                'consultados' => 0,
                'atualizados' => 0,
            ], 200);
        }

        // Uma única ida ao Logix para todas as OCs distintas
        $ocs = [];

        foreach ($itens as $item) {
            $oc = trim((string) $item->n_oc);

            if ($oc !== '') {
                $ocs[$oc] = true;
            }
        }

        $retornoLogix = LogixOrdemCompraService::consultarPorOcs(array_keys($ocs));

        $atualizados   = 0;
        $naoEncontrados = 0;
        $refsAfetadas  = [];

        foreach ($itens as $item) {
            $oc = trim((string) $item->n_oc);

            if (!isset($retornoLogix[$oc])) {
                // OC não veio na resposta: registra a passagem e segue
                SolicitacaoItemComprado::marcarSincronizado($item->id);
                $naoEncontrados++;
                continue;
            }

            $dados = $retornoLogix[$oc];

            $mudou = SolicitacaoItemComprado::aplicarRetornoLogix(
                $item->id,
                $dados['pedido'],
                $dados['liquidado']
            );

            if ($mudou) {
                $atualizados++;
                $refsAfetadas[(int) $item->ref] = true;
            }
        }

        // Avisa no histórico as SLs que ficaram prontas para conclusão
        $prontas = [];

        foreach (array_keys($refsAfetadas) as $ref) {
            $resumo = SolicitacaoItemComprado::resumoLiquidacao($ref);

            if ($resumo['total'] > 0 && $resumo['pendentes'] === 0) {
                $prontas[] = $ref;

                Historico::create([
                    'ref'      => $ref,
                    'usuario'  => 'LOGIX',
                    'mensagem' => "Todos os {$resumo['total']} itens estão liquidados no Logix. "
                        . 'Aquisição pronta para ser concluída.',
                    'situacao' => 'aquisicao',
                ]);
            }
        }

        return Json::return([
            'success'        => true,
            'message'        => 'Sincronização concluída.',
            'consultados'    => count($itens),
            'ocsConsultadas' => count($ocs),
            'atualizados'    => $atualizados,
            'naoEncontrados' => $naoEncontrados,
            'slsProntas'     => $prontas,
        ], 200);
    }

    /**
     * GET - Resumo da liquidacao de uma SL (usado para reavaliar o botao
     * "Concluir aquisição" sem recarregar a pagina).
     */
    public function resumoAquisicao(int $ref)
    {
        $resumo = SolicitacaoItemComprado::resumoLiquidacao($ref);

        return Json::return([
            'success'       => true,
            'resumo'        => $resumo,
            'podeFinalizar' => $resumo['total'] > 0 && $resumo['pendentes'] === 0,
        ], 200);
    }

    /**
     * POST - Conclui a etapa de Aquisicao (aquisicao_status = OK).
     * So passa se TODOS os itens estiverem liquidados.
     */
    public function concluirAquisicao(int $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return Json::return([
                'success' => false,
                'message' => 'Solicitação não encontrada.',
            ], 404);
        }

        if (!SolicitacaoItemComprado::temColunasAquisicao()) {
            return Json::return([
                'success' => false,
                'message' => 'Banco desatualizado: rode a migration '
                    . '2026-07-21-aquisicao-itens-comprados.sql.',
            ], 503);
        }

        $resumo = SolicitacaoItemComprado::resumoLiquidacao($ref);

        if ($resumo['total'] === 0) {
            return Json::return([
                'success' => false,
                'message' => 'Esta SL não possui itens comprados.',
            ], 422);
        }

        if ($resumo['pendentes'] > 0) {
            return Json::return([
                'success' => false,
                'message' => "Ainda há {$resumo['pendentes']} item(ns) sem liquidação.",
                'resumo'  => $resumo,
            ], 422);
        }

        $mensagem = trim((string) ($this->entrada('mensagem') ?? ''));
        $usuario  = $this->usuarioLogado();
        $agora    = date('Y-m-d H:i:s');

        $dados = [
            'aquisicao_status' => 'OK',
            'aquisicao_data'   => $agora,
        ];

        if (empty(trim((string) $solicitacao->corte_status))) {
            $dados['corte_status'] = 'PARADO';
        }

        $atualizou = Acompanhamento::updateByColumn('ref', $ref, $dados);

        if (!$atualizou) {
            return Json::return([
                'success' => false,
                'message' => 'Não foi possível concluir a aquisição.',
            ], 500);
        }

        // Fecha o cronômetro da aquisição
        $this->carimbarCronometro($ref, 'aquisicao_status', 'OK');

        Historico::create([
            'ref'      => $ref,
            'usuario'  => $usuario,
            'mensagem' => $mensagem !== ''
                ? $mensagem
                : "Aquisição concluída — {$resumo['total']} item(ns) liquidado(s).",
            'situacao' => 'aquisicao',
        ]);

        return Json::return([
            'success' => true,
            'message' => 'Aquisição concluída.',
        ], 200);
    }

    /**
     * POST - BYPASS de TESTE: conclui a aquisição SEM exigir liquidação.
     *
     * Restrito às matrículas em MATRICULAS_BYPASS_AQUISICAO. Serve para testar
     * as etapas seguintes (corte/execução) sem depender do Logix liquidar.
     *
     * A checagem de matrícula é feita AQUI, no servidor — o botão escondido na
     * tela é só conveniência. Toda passagem é registrada no histórico com a
     * marca [TESTE] e a matrícula, para não se confundir com uma conclusão real.
     */
    public function concluirAquisicaoBypass(int $ref)
    {
        if (!$this->podeBypassAquisicao()) {
            return Json::return([
                'success' => false,
                'message' => 'Ação restrita: sua matrícula não pode pular a liquidação.',
            ], 403);
        }

        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return Json::return([
                'success' => false,
                'message' => 'Solicitação não encontrada.',
            ], 404);
        }

        if (strtoupper(trim((string) $solicitacao->aquisicao_status)) === 'OK') {
            return Json::return([
                'success' => false,
                'message' => 'Aquisição já concluída.',
            ], 409);
        }

        $usuario   = $this->usuarioLogado();
        $matricula = $this->matriculaLogada();
        $agora     = date('Y-m-d H:i:s');
        $resumo    = SolicitacaoItemComprado::resumoLiquidacao($ref);

        $dados = [
            'aquisicao_status' => 'OK',
            'aquisicao_data'   => $agora,
        ];

        if (empty(trim((string) $solicitacao->corte_status))) {
            $dados['corte_status'] = 'PARADO';
        }

        $atualizou = Acompanhamento::updateByColumn('ref', $ref, $dados);

        if (!$atualizou) {
            return Json::return([
                'success' => false,
                'message' => 'Não foi possível concluir a aquisição.',
            ], 500);
        }

        // Fecha o cronômetro da aquisição
        $this->carimbarCronometro($ref, 'aquisicao_status', 'OK');

        Historico::create([
            'ref'      => $ref,
            'usuario'  => $usuario,
            'mensagem' => "[TESTE] Aquisição concluída SEM liquidação (bypass) pela matrícula "
                . "{$matricula}. Situação no momento: {$resumo['liquidados']} de "
                . "{$resumo['total']} liquidado(s), {$resumo['pendentes']} pendente(s).",
            'situacao' => 'aquisicao',
        ]);

        return Json::return([
            'success' => true,
            'message' => 'Aquisição concluída (bypass de teste).',
        ], 200);
    }

    /* ======================================================================
     *  RETORNAR SL  +  CANCELAR SL  (2026-07-21, 3ª rodada)
     *  Botões presentes nas etapas de aquisição/corte/execução.
     *  Ambos pedem um motivo, que vai para o histórico (chatbox).
     * ====================================================================== */

    /**
     * GET - Modal genérica de motivo, usada por "Retornar SL" e por CANCELADO.
     * A ação vem em ?acao=retornar|cancelar.
     */
    public function modalMotivoEtapa(int $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return Json::return(['error' => 'Solicitação não encontrada'], 404);
        }

        $acao = strtolower((string) (Request::query('acao') ?? 'retornar'));
        if (!in_array($acao, ['retornar', 'cancelar'], true)) {
            $acao = 'retornar';
        }

        return view('modals.motivoEtapa.modal', [
            'ref'         => $ref,
            'acao'        => $acao,
            'solicitacao' => $solicitacao,
        ]);
    }

    /**
     * POST - "Retornar SL": volta a etapa de LIBERAÇÃO como REVISAR e reabre o
     * fluxo (aquisição/corte/execução voltam ao início). Preserva os dados de
     * OC/liquidação dos itens. O motivo vai para o histórico.
     */
    public function retornarSl(int $ref)
    {
        $mensagem = trim((string) ($this->entrada('mensagem') ?? ''));

        if ($mensagem === '') {
            return Json::return([
                'success' => false,
                'message' => 'Descreva o motivo do retorno antes de confirmar.',
            ], 422);
        }

        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return Json::return([
                'success' => false,
                'message' => 'Solicitação não encontrada.',
            ], 404);
        }

        if (strtoupper(trim((string) $solicitacao->liberacao_status)) !== 'OK') {
            return Json::return([
                'success' => false,
                'message' => 'Só é possível retornar uma SL já liberada.',
            ], 409);
        }

        // Reabre o fluxo a partir da liberação
        $dados = [
            'liberacao_status' => 'REVISAR',
            'aquisicao_status' => 'PENDENTE',
            'corte_status'     => 'PARADO',
            'exec_status'      => 'PARADO',
        ];

        // Zera os cronômetros das etapas reabertas (recontagem no novo ciclo).
        // OC/pedido/liquidação dos itens NÃO são tocados (decisão do usuário).
        foreach (self::CRONOMETRO_ETAPAS as $colunaStatus => $cfg) {
            if (!$this->cronometroDisponivel($colunaStatus)) {
                continue;
            }

            $dados[$cfg['inicio']]   = null;
            $dados[$cfg['fimCampo']] = null;
            $dados[$cfg['tempo']]    = 0;
            $dados[$cfg['retomado']] = null;
        }

        $atualizou = Acompanhamento::updateByColumn('ref', $ref, $dados);

        if (!$atualizou) {
            return Json::return([
                'success' => false,
                'message' => 'Não foi possível retornar a SL.',
            ], 500);
        }

        Historico::create([
            'ref'      => $ref,
            'usuario'  => $this->usuarioLogado(),
            'mensagem' => 'SL retornada para revisão (liberação). Motivo: ' . $mensagem,
            'situacao' => 'revisar',
        ]);

        return Json::return([
            'success' => true,
            'message' => 'SL retornada para revisão.',
        ], 200);
    }

    /**
     * POST - "Cancelar SL" a partir do corte/execução (status CANCELADO).
     * Espelha o cancelamento já existente: todas as etapas viram CANCELADO e o
     * motivo é registrado no histórico.
     */
    public function cancelarSl(int $ref)
    {
        $mensagem = trim((string) ($this->entrada('mensagem') ?? ''));

        if ($mensagem === '') {
            return Json::return([
                'success' => false,
                'message' => 'Descreva o motivo do cancelamento antes de confirmar.',
            ], 422);
        }

        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return Json::return([
                'success' => false,
                'message' => 'Solicitação não encontrada.',
            ], 404);
        }

        $atualizou = Acompanhamento::updateStatus($ref, [
            'conceito_status',
            'detalhamento_status',
            'liberacao_status',
            'aquisicao_status',
            'corte_status',
            'exec_status',
            'tryout_status',
        ], 'CANCELADO');

        if (!$atualizou) {
            return Json::return([
                'success' => false,
                'message' => 'Não foi possível cancelar a SL.',
            ], 500);
        }

        Historico::create([
            'ref'      => $ref,
            'usuario'  => $this->usuarioLogado(),
            'mensagem' => 'SL cancelada. Motivo: ' . $mensagem,
            'situacao' => 'cancelar',
        ]);

        return Json::return([
            'success' => true,
            'message' => 'SL cancelada.',
        ], 200);
    }
}