<?php

namespace src\app\controllers;

use src\app\database\entities\Usuario;
use src\app\database\entities\Conta;
use src\app\database\entities\Estagio;
use src\app\database\entities\Vagao;
use src\app\requests\contas\StoreRequest;
use src\app\requests\contas\UpdateRequest;
use src\support\Redirect;
use src\support\Request;
use src\support\View;
use src\support\Json;
use Exception;
use src\exceptions\pdo\DuplicateEntryException;


class ContaController
{

    /**
     * Exibe a view principal de cadastro e listagem de estágios.
     * * @return View Retorna a view 'parametrizacao.estagio' com a lista de todos os estágios.
     */
    function cadastroContaView(): View
    {
        $leaders = Usuario::getAllLeader();
        $vagoes = Vagao::getDistinctWagons();




        return view('parametrizacao.conta', [
            "contas" => Conta::getAll(),
            "leaders" => $leaders,
            "vagoes" => $vagoes,

        ]);
    }



    function getLoteByVagao(){
        $vagao = Request::query('vagao');
        
        try{
            $lote = Vagao::getLoteByVagao($vagao);

            if(!$lote) {
                 return Json::return([
                "message" => 'not found',
                "data" => null
            ], 404);
            }

            return Json::return([
                "message" => 'success',
                "data" => $lote
            ], 200);


        }catch(Exception $e){
            dd($e->getMessage());
        }
    }

    function getDescricaoConta(){
        $conta = Request::query('conta');
        
        try{
            $descricaoConta = Conta::getDescricaoConta($conta);
            if(!$descricaoConta) {
                return Json::return([
                    "message" => 'not found',
                    "data" => null
                ], 404);
            }
            
            return Json::return([
                "message" => 'success',
                "data" =>  $descricaoConta
            ], 200);


        }catch(Exception $e){
            dd($e->getMessage());
        }
    }

    /**
     * Armazena um novo registro de Estágio no banco de dados.
     * * @param StoreRequest $request Objeto de requisição contendo os dados validados.
     * @return Redirect Redireciona para a listagem com mensagem de sucesso ou erro.
     */
    function storeConta(StoreRequest $request)
    {
        try {
            $conta = Conta::create($request->get());

            if (!$conta) {
                return redirect()->route("parametrizacao.contas")->withError("Registro não cadastrado");
            }
            return redirect()->route("parametrizacao.contas")->withSuccess("Registro salvo 🎉");
        } catch (DuplicateEntryException $e) {
            return redirect()->route("parametrizacao.contas")->withError("Registro já existente");
        } catch (Exception $e) {
            return redirect()->route("parametrizacao.contas")->withError("Ocorreu um erro interno ao salvar o registro.");
        }
    } 

    /**
     * Atualiza um registro de Estágio existente no banco de dados.
     * * @param UpdateRequest $request Objeto de requisição contendo os dados validados e o ID.
     * @return Redirect Redireciona para a listagem com mensagem de sucesso ou erro.
     */
    function updateConta(UpdateRequest $request)
    {
        try{
        $data2update = $request->get();
        Conta::updateByUuid($data2update['id'], $data2update);
        return redirect()->route("parametrizacao.contas")->withSuccess("Registro atualizado 🎉");
        } catch (DuplicateEntryException $e) {
        return redirect()->route("parametrizacao.contas")->withError("Registro já existente");

        } catch (Exception $e) {
        return redirect()->route("parametrizacao.contas")->withError("Ocorreu um erro interno ao salvar o registro.");
        }
    }

    /**
     * Exibe o modal de confirmação de exclusão para um Estágio específico.
     *
     * @param string $id O UUID do Estágio a ser excluído.
     *
     * @return View Retorna a view do modal de confirmação com os dados do Estágio.
     */
    function modalConfirm(string $id): View
    {
        $conta = Conta::getByUuid($id);
        return view('modals.contas.destroy', [
            "conta" => $conta
        ]);
    }

    /**
     * Exibe o modal de edição para um Estágio específico.
     *
     * @param string $id O UUID do Estágio a ser editado.
     *
     * @return View Retorna a view do modal de edição com os dados do Estágio.
     */
    function modalEdit(string $id): View
    {
        $conta = Conta::getByUuid($id);
        $vagoes = $conta->vagao;
        $lotes = Vagao::getLoteByVagao($vagoes);
        return view('modals.contas.edit', [
            "conta" => $conta,
            "leaders" => Usuario::getAllLeader(),
            "vagoes" => $vagoes,
            "lotes" => $lotes
        ]);
    }

    /**
     * Exclui um Estágio permanentemente do banco de dados pelo seu UUID.
     * * Nota: O comentário original foi ajustado de 'menu'/'lançamento' para 'Estágio'.
     *
     * @param string $id O UUID do Estágio a ser deletado.
     *
     * @return Redirect Redireciona para a tela de listagem de estágios com mensagem de sucesso.
     */
    function deleteEstagio(string $id)
    {
        Conta::deleteByUuid($id);
        return redirect()->route("parametrizacao.contas")->withSuccess("Registro deletado com sucesso🎉");
    }
}