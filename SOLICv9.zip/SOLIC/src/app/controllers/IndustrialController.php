<?php

namespace src\app\controllers;

use src\app\database\entities\Acompanhamento;
use src\app\database\entities\Historico;
use src\app\database\entities\Projeto;
use src\app\database\entities\SolicitacaoAnexoArquivo;
use src\app\database\entities\SolicitacaoAnexoCarga;
use src\app\database\entities\SolicitacaoItemComprado;
use src\app\database\entities\Usuario;
use src\support\Cronometro;
use src\support\Json;
use src\support\Request;
use src\support\View;

/**
 * Tela INDUSTRIAL — 2026-07-21 (4ª rodada).
 *
 * Corte e Execução saíram do controle da automação e passaram a ser tocados
 * aqui. A estrutura espelha a tela de desenvolvimento (lista + detalhe), mas
 * com os campos que o industrial usa (equipe, setor, pasta, natureza,
 * descrição do serviço e data de entrega).
 *
 * Aquisição, Corte e Execução correm em PARALELO: nenhuma depende da outra
 * terminar. As três abrem quando a SL é liberada.
 */
class IndustrialController
{
    /** Campos que o industrial edita e que já existem na tabela fila. */
    private const CAMPOS_EDITAVEIS = [
        'n_pasta',
        'natureza',
        'descricaoservico',
        'equipeei',
        'setor_pendencia',
        'data_entrega',
    ];

    /** Matrículas autorizadas a pular a liquidação (teste) — igual à automação. */
    private const MATRICULAS_BYPASS_AQUISICAO = ['459844'];

    private function matriculaLogada(): string
    {
        return trim((string) (
            $_SESSION['user']['matricula']
            ?? $_SESSION['usuarioMatricula']
            ?? ''
        ));
    }

    private function podeBypassAquisicao(): bool
    {
        // 9ª rodada — liberado para TODOS por enquanto.
        // Para voltar a restringir: return in_array($this->matriculaLogada(), self::MATRICULAS_BYPASS_AQUISICAO, true);
        return true;
    }

    /* ------------------------------------------------------------------ */
    /*  LISTA                                                              */
    /* ------------------------------------------------------------------ */

    function industrialListaView(): View
    {
        $status      = Request::query('status') ?? '';
        $solicitante = Request::query('solicitante') ?? '';
        $equipe      = Request::query('equipe') ?? '';

        $solicitacoes = Acompanhamento::getParaIndustrial($status, $solicitante, $equipe);

        foreach ($solicitacoes as $item) {
            $valorLimpo = trim(str_ireplace('Z', '', (string) ($item->cod_z ?? '')));
            $item->cod_z_formatado = !empty($valorLimpo) ? 'Z' . $valorLimpo : '';
            $item->status_geral    = $this->statusGeral($item);
        }

        return view('/industrial.listaIndustrial', [
            'solicitacoes' => $solicitacoes,
            'qtdSL'        => count($solicitacoes),
            'solicitantes' => Usuario::getSolic(),
            'equipes'      => Acompanhamento::equipesDistintas(),
        ]);
    }

    /**
     * Situação geral da SL para a coluna "Status" da lista.
     * Derivada — não existe coluna para isso.
     */
    private function statusGeral(object $solic): string
    {
        $corte = strtoupper(trim((string) ($solic->corte_status ?? '')));
        $exec  = strtoupper(trim((string) ($solic->exec_status ?? '')));

        if ($corte === 'CANCELADO' || $exec === 'CANCELADO') {
            return 'CANCELADO';
        }

        $concluido = ['FINALIZADO', 'TERCEIRIZADO'];

        if (in_array($corte, $concluido, true) && in_array($exec, $concluido, true)) {
            return 'FINALIZADO';
        }

        if ($corte === 'ANDAMENTO' || $exec === 'ANDAMENTO') {
            return 'ANDAMENTO';
        }

        if ($corte === 'AGUARDANDO' || $exec === 'AGUARDANDO') {
            return 'AGUARDANDO';
        }

        return 'PARADO';
    }

    /* ------------------------------------------------------------------ */
    /*  DETALHE                                                            */
    /* ------------------------------------------------------------------ */

    function industrialInfoView(string $ref): View
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return view('404', []);
        }

        $zCode = ltrim((string) ($solicitacao->cod_z ?? ''), 'zZ');

        $slLiberada = strtoupper(trim((string) $solicitacao->liberacao_status)) === 'OK';
        $slCancelada = strtoupper(trim((string) $solicitacao->liberacao_status)) === 'CANCELADO';

        // Mesmas opções da automação (2ª rodada)
        $statusLiberacao = ['PENDENTE', 'REVISAR', 'OK'];
        $statusCorte    = ['ANDAMENTO', 'PARADO', 'TERCEIRIZADO', 'CANCELADO', 'FINALIZADO', 'AGUARDANDO'];
        $statusExecucao = ['PARADO', 'ANDAMENTO', 'TERCEIRIZADO', 'CANCELADO', 'FINALIZADO'];
        $statusTryout   = ['PARADO', 'ANDAMENTO', 'TERCEIRIZADO', 'FINALIZADO'];

        // 8ª rodada — Liberação passou para a Industrial. Liberável quando
        // Conceito e Detalhamento estão OK (e a SL não está cancelada).
        $conceitoOk = strtoupper(trim((string) $solicitacao->conceito_status)) === 'OK';
        $detalheOk  = strtoupper(trim((string) $solicitacao->detalhamento_status)) === 'OK';
        $podeLiberar = $conceitoOk && $detalheOk && !$slLiberada && !$slCancelada;

        /*
         * Etapas mostradas ao industrial. Corte, Execução e Tryout são as
         * editáveis aqui; as anteriores aparecem só para dar contexto do
         * andamento da SL (espelho do que a automação enxerga).
         *
         * PARALELISMO: corte e execução abrem juntos assim que a SL é
         * liberada — nenhum espera o outro terminar.
         */
        $etapas = [
            [
                'label'  => 'Conceito',
                'coluna' => 'conceito_status',
                'valor'  => $solicitacao->conceito_status,
                'opcoes' => [],
                'edit'   => false,
            ],
            [
                'label'  => 'Detalhe',
                'coluna' => 'detalhamento_status',
                'valor'  => $solicitacao->detalhamento_status,
                'opcoes' => [],
                'edit'   => false,
            ],
            [
                'label'  => 'Liberação',
                'coluna' => 'liberacao_status',
                'valor'  => $solicitacao->liberacao_status,
                'opcoes' => $statusLiberacao,
                // 8ª rodada — Liberação é da Industrial (OK abre a modal via JS)
                'edit'   => $podeLiberar,
            ],
            [
                'label'  => 'Aquisição',
                'coluna' => 'aquisicao_status',
                'valor'  => $solicitacao->aquisicao_status,
                'opcoes' => ['PENDENTE', 'REALIZADO', 'TERCEIRIZADO', 'OK'],
                // 8ª rodada — Aquisição é da Industrial (OK passa por concluirAquisicao)
                'edit'   => $slLiberada && !$slCancelada,
            ],
            [
                'label'  => 'Corte',
                'coluna' => 'corte_status',
                'valor'  => $solicitacao->corte_status,
                'opcoes' => $statusCorte,
                'edit'   => $slLiberada && !$slCancelada,
            ],
            [
                'label'  => 'Execução',
                'coluna' => 'exec_status',
                'valor'  => $solicitacao->exec_status,
                'opcoes' => $statusExecucao,
                'edit'   => $slLiberada && !$slCancelada,
            ],
            [
                'label'  => 'Tryout',
                'coluna' => 'tryout_status',
                'valor'  => $solicitacao->tryout_status,
                'opcoes' => $statusTryout,
                'edit'   => $slLiberada && !$slCancelada,
            ],
        ];

        /*
         * 10ª rodada — a Industrial passou a enxergar o mesmo contexto da
         * automação (imagem do projeto, PDFs de documentação, pacotes de DXF,
         * anexos). Aqui é SÓ LEITURA: quem sobe os arquivos continua sendo a
         * automação. Por isso apenas carregamos e listamos; nenhuma rota de
         * upload foi criada nesta tela.
         */
        $cargasAnexos = SolicitacaoAnexoCarga::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $arquivosSolicitacao = SolicitacaoAnexoArquivo::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $arquivosPorTipo = $this->separarArquivosSolicitacao($arquivosSolicitacao);
        $cargasMap       = $this->criarMapaCargas($cargasAnexos);

        return view('industrial.industrialForm', [
            'solicitacao' => $solicitacao,
            'z_info'      => Projeto::getByZcode($zCode),
            'etapas'      => $etapas,
            'interacoes'  => Historico::getHistoryInfos($ref) ?: [],
            'temposEtapa' => Cronometro::mapa($solicitacao),
            'slLiberada'  => $slLiberada,
            'slCancelada' => $slCancelada,

            // 8ª rodada — Liberação + Aquisição/OC passaram para a Industrial
            'podeLiberar'         => $podeLiberar,
            'itensComprados'      => SolicitacaoItemComprado::getPorRef((int) $ref),
            'resumoAquisicao'     => SolicitacaoItemComprado::resumoLiquidacao((int) $ref),
            'aquisicaoHabilitada' => SolicitacaoItemComprado::temColunasAquisicao(),
            'podeBypassAquisicao' => $this->podeBypassAquisicao(),

            // 10ª rodada — contexto de anexos (SÓ LEITURA nesta tela)
            'cargasMap'         => $cargasMap,
            'imagemProjeto'     => $arquivosPorTipo['IMAGEM_PROJETO'][0] ?? null,
            'pacotesDxf'        => $arquivosPorTipo['PACOTE_DXF'] ?? [],
            'txtItensComprados' => $arquivosPorTipo['ITENS_COMPRADOS_TXT'] ?? [],
            'listasMateriais'   => $arquivosPorTipo['LISTA_MATERIAIS'] ?? [],
            'desenhosPdf'       => $arquivosPorTipo['DESENHO_PDF'] ?? [],
        ]);
    }

    /* ------------------------------------------------------------------ */
    /*  CAMPOS DO INDUSTRIAL                                               */
    /* ------------------------------------------------------------------ */

    /**
     * POST - Salva os campos do industrial (equipe, setor, pasta, natureza,
     * descrição do serviço, data de entrega).
     *
     * Só grava o que veio no corpo e está na whitelist CAMPOS_EDITAVEIS —
     * nome de coluna nunca vem do request sem passar por essa lista.
     */
    public function salvarCamposIndustrial(int $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return Json::return([
                'success' => false,
                'message' => 'Solicitação não encontrada.',
            ], 404);
        }

        $corpo = $this->corpoRequisicao();
        $dados = [];

        foreach (self::CAMPOS_EDITAVEIS as $campo) {
            if (!array_key_exists($campo, $corpo)) {
                continue;
            }

            $valor = is_array($corpo[$campo]) ? '' : trim((string) $corpo[$campo]);

            if ($campo === 'data_entrega') {
                // Aceita vazio (limpa) ou YYYY-MM-DD
                if ($valor === '') {
                    $dados[$campo] = null;
                    continue;
                }

                $data = \DateTime::createFromFormat('Y-m-d', $valor);

                if (!$data || $data->format('Y-m-d') !== $valor) {
                    return Json::return([
                        'success' => false,
                        'message' => 'Data de entrega inválida.',
                    ], 422);
                }

                $dados[$campo] = $valor;
                continue;
            }

            $dados[$campo] = ($valor === '') ? null : $valor;
        }

        if (empty($dados)) {
            return Json::return([
                'success' => false,
                'message' => 'Nenhum campo para salvar.',
            ], 422);
        }

        // Só atualiza colunas que EXISTEM na fila — assim uma coluna ausente
        // (ex.: migration não rodada) não derruba a gravação inteira.
        $colunas   = Acompanhamento::colunasFila();
        $ignorados = [];

        if (!empty($colunas)) {
            foreach (array_keys($dados) as $campo) {
                if (!in_array($campo, $colunas, true)) {
                    $ignorados[] = $campo;
                    unset($dados[$campo]);
                }
            }
        }

        if (empty($dados)) {
            return Json::return([
                'success' => false,
                'message' => 'Os campos ainda não existem no banco. Rode a migration '
                    . '2026-07-21i-campos-industrial.sql.',
            ], 503);
        }

        try {
            Acompanhamento::updateByColumn('ref', $ref, $dados);
        } catch (\Throwable $e) {
            error_log('Falha ao salvar campos do industrial (ref ' . $ref . '): ' . $e->getMessage());
            return Json::return([
                'success' => false,
                'message' => 'Não foi possível salvar.',
            ], 500);
        }

        $mensagem = 'Dados salvos.';
        if (!empty($ignorados)) {
            $mensagem .= ' (ignorados por falta de coluna: ' . implode(', ', $ignorados)
                . ' — rode a migration 2026-07-21i.)';
        }

        return Json::return([
            'success'   => true,
            'message'   => $mensagem,
            'ignorados' => $ignorados,
        ], 200);
    }

    /**
     * Lê o corpo aceitando $_POST OU JSON (mesma razão do helper equivalente
     * em DesenvolvimentoController: src\support\Request só enxerga $_POST).
     */
    private function corpoRequisicao(): array
    {
        if (!empty($_POST)) {
            return $_POST;
        }

        $bruto = file_get_contents('php://input');
        $json  = json_decode((string) $bruto, true);

        return is_array($json) ? $json : [];
    }

    /* ------------------------------------------------------------------ */
    /*  ANEXOS (SÓ LEITURA) — 10ª rodada                                  */
    /* ------------------------------------------------------------------ */

    /**
     * Agrupa os arquivos da solicitação por tipo. Espelha o helper de mesmo
     * nome da automação (DesenvolvimentoController) — a Industrial só lê.
     */
    private function separarArquivosSolicitacao(array $arquivos): array
    {
        $separados = [
            'IMAGEM_PROJETO'      => [],
            'PACOTE_DXF'          => [],
            'ITENS_COMPRADOS_TXT' => [],
            'LISTA_MATERIAIS'     => [],
            'DESENHO_PDF'         => [],
            'OUTROS'              => [],
        ];

        foreach ($arquivos as $arquivo) {
            $tipo = strtoupper(trim((string) ($arquivo->tipo ?? '')));

            if (isset($separados[$tipo])) {
                $separados[$tipo][] = $arquivo;
                continue;
            }

            $separados['OUTROS'][] = $arquivo;
        }

        return $separados;
    }

    /** Mapa id => carga, para casar prioridade com cada DXF. */
    private function criarMapaCargas(array $cargas): array
    {
        $mapa = [];

        foreach ($cargas as $carga) {
            if (!empty($carga->id)) {
                $mapa[$carga->id] = $carga;
            }
        }

        return $mapa;
    }
}
