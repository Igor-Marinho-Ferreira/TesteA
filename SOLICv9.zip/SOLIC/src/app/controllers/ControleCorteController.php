<?php

namespace src\app\controllers;

use PDO;
use src\app\database\entities\DxfControle;
use src\app\database\entities\DxfPlanoCorte;
use src\app\database\entities\Espessura;
use src\app\database\entities\SolicitacaoAnexoArquivo;
use src\support\Json;
use src\support\Request;
use src\support\View;

/**
 * CONTROLE DE CORTES DE PEÇAS — 2026-07-21 (5ª rodada).
 *
 * Traz para a web a tela que hoje vive no Access ("Dados do Projeto"):
 * a lista dos pacotes DXF e, ao abrir um DX, os planos de corte.
 *
 * O ARQUIVO do pacote continua em solicitacao_anexo_arquivos
 * (tipo = 'PACOTE_DXF'); os metadados novos ficam em dxf_controle e as
 * linhas da grade em dxf_planos_corte.
 *
 * Campos derivados (não viram coluna):
 *   Projeto    = vagao + '_' + lote   (decisão do usuário)
 *   Projetista = detalhamento_proj ou conceito_proj
 *   Cod Z / SL / Descrição = da fila
 */
class ControleCorteController
{
    /* ------------------------------------------------------------------ */
    /*  LISTA                                                              */
    /* ------------------------------------------------------------------ */

    function listaCortesView(): View
    {
        $statusFiltro = strtoupper(trim((string) (Request::query('status') ?? '')));
        $prioridade   = trim((string) (Request::query('prioridade') ?? ''));

        $pacotes  = $this->pacotesDxf();
        $controle = DxfControle::tabelaExiste() ? DxfControle::mapaPorCodigo() : [];

        $linhas = [];

        foreach ($pacotes as $pacote) {
            $codigo = $this->codigoDoPacote($pacote);

            if ($codigo === '') {
                continue;
            }

            $ctrl = $controle[$codigo] ?? null;

            $status = strtoupper(trim((string) ($ctrl->status_corte ?? 'AGUARDANDO')));

            if ($statusFiltro !== '' && $statusFiltro !== 'TODOS' && $status !== $statusFiltro) {
                continue;
            }

            if ($prioridade !== '' && trim((string) ($ctrl->prioridade ?? '')) !== $prioridade) {
                continue;
            }

            $linhas[] = (object) [
                'codigo'      => $codigo,
                'ref'         => (int) $pacote->ref,
                'sl'          => 'SL' . str_pad((string) $pacote->ref, 4, '0', STR_PAD_LEFT),
                'cod_z'       => $this->formatarZ($pacote->cod_z ?? ''),
                'descricao'   => trim((string) ($ctrl->descricao ?? '')) !== ''
                    ? $ctrl->descricao
                    : ($pacote->descricao_sl ?? ''),
                'projeto'     => $this->projeto($pacote),
                'tem_img'     => !empty($pacote->tem_imagem),
                'tem_dxf'     => true, // a linha existe porque o zip existe
                'nest'        => $ctrl->nest ?? '',
                'prioridade'  => $ctrl->prioridade ?? '',
                'status_corte' => $status,
            ];
        }

        return view('cortes.listaCortes', [
            'linhas'        => $linhas,
            'qtd'           => count($linhas),
            'statusOpcoes'  => DxfControle::STATUS,
            'prioridades'   => DxfControle::PRIORIDADES,
            'tabelaPronta'  => DxfControle::tabelaExiste(),
        ]);
    }

    /**
     * Pacotes DXF já recebidos pela web, com os dados da SL.
     * Só os que estão na web — o histórico antigo do Access não foi migrado
     * (decisão do usuário).
     *
     * @return array<int, object>
     */
    private function pacotesDxf(): array
    {
        try {
            $pdo = SolicitacaoAnexoArquivo::getPDO();

            if (!$pdo) {
                return [];
            }

            $stmt = $pdo->prepare("
                SELECT
                    a.id            AS arquivo_id,
                    a.ref           AS ref,
                    a.codigo        AS codigo,
                    a.nome_original AS nome_original,
                    a.nome_arquivo  AS nome_arquivo,
                    a.caminho       AS caminho,
                    a.created_at    AS inserido_em,
                    f.cod_z         AS cod_z,
                    f.descricao     AS descricao_sl,
                    f.vagao         AS vagao,
                    f.lote          AS lote,
                    f.conceito_proj      AS conceito_proj,
                    f.detalhamento_proj  AS detalhamento_proj,
                    (
                        SELECT i.id
                          FROM bd_device_request.solicitacao_anexo_arquivos i
                         WHERE i.ref = a.ref
                           AND i.tipo = 'IMAGEM_PROJETO'
                         LIMIT 1
                    ) AS imagem_id,
                    (
                        SELECT COUNT(*)
                          FROM bd_device_request.solicitacao_anexo_arquivos i2
                         WHERE i2.ref = a.ref
                           AND i2.tipo = 'IMAGEM_PROJETO'
                    ) AS tem_imagem
                  FROM bd_device_request.solicitacao_anexo_arquivos a
             LEFT JOIN bd_device_request.fila f ON f.ref = a.ref
                 WHERE a.tipo = 'PACOTE_DXF'
              ORDER BY a.ref DESC, a.codigo DESC
            ");

            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_OBJ) ?: [];
        } catch (\Throwable $e) {
            error_log('Falha ao listar pacotes DXF: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Extrai o código DX do pacote. Mesma cascata do csvDxf que já existia:
     * codigo -> nome_arquivo -> nome_original -> caminho.
     */
    private function codigoDoPacote(object $pacote): string
    {
        $fontes = [
            (string) ($pacote->codigo ?? ''),
            (string) ($pacote->nome_arquivo ?? ''),
            (string) ($pacote->nome_original ?? ''),
            basename((string) ($pacote->caminho ?? '')),
        ];

        foreach ($fontes as $fonte) {
            $fonte = trim($fonte);

            if ($fonte === '') {
                continue;
            }

            if (preg_match('/DX\s*0*([0-9]+)/i', $fonte, $m)) {
                return 'DX' . str_pad($m[1], 4, '0', STR_PAD_LEFT);
            }
        }

        return '';
    }

    /** Projeto = vagão_lote (decisão do usuário). */
    private function projeto(object $origem): string
    {
        $vagao = trim((string) ($origem->vagao ?? ''));
        $lote  = trim((string) ($origem->lote ?? ''));

        if ($vagao === '' && $lote === '') {
            return '';
        }

        if ($lote === '') {
            return $vagao;
        }

        return $vagao . '_' . $lote;
    }

    private function projetista(object $origem): string
    {
        $det = trim((string) ($origem->detalhamento_proj ?? ''));

        return $det !== '' ? $det : trim((string) ($origem->conceito_proj ?? ''));
    }

    private function formatarZ($codZ): string
    {
        $limpo = trim(str_ireplace('Z', '', (string) $codZ));

        return $limpo !== '' ? 'Z' . $limpo : '';
    }

    /* ------------------------------------------------------------------ */
    /*  DETALHE DO DX                                                      */
    /* ------------------------------------------------------------------ */

    function detalheCorteView(string $codigo): View
    {
        $codigo = strtoupper(trim($codigo));

        $pacote = $this->pacotePorCodigo($codigo);

        if (!$pacote) {
            return view('404', []);
        }

        if (!DxfControle::tabelaExiste()) {
            return view('cortes.detalheCorte', [
                'codigo'       => $codigo,
                'pacote'       => $pacote,
                'controle'     => null,
                'planos'       => [],
                'espessuras'   => [],
                'resumo'       => ['total' => 0, 'cortados' => 0, 'pendentes' => 0],
                'statusOpcoes' => DxfControle::STATUS,
                'prioridades'  => DxfControle::PRIORIDADES,
                'projeto'      => $this->projeto($pacote),
                'projetista'   => $this->projetista($pacote),
                'tabelaPronta' => false,
            ]);
        }

        $controle = DxfControle::getOuCriar(
            $codigo,
            (int) $pacote->ref,
            $pacote->inserido_em ?? null
        );

        return view('cortes.detalheCorte', [
            'codigo'       => $codigo,
            'pacote'       => $pacote,
            'controle'     => $controle,
            'planos'       => DxfPlanoCorte::getPorDxf($codigo),
            'espessuras'   => Espessura::listar(),
            'resumo'       => DxfPlanoCorte::resumo($codigo),
            'statusOpcoes' => DxfControle::STATUS,
            'prioridades'  => DxfControle::PRIORIDADES,
            'projeto'      => $this->projeto($pacote),
            'projetista'   => $this->projetista($pacote),
            'tabelaPronta' => true,
        ]);
    }

    /** Um pacote específico pelo código DX. */
    private function pacotePorCodigo(string $codigo): ?object
    {
        foreach ($this->pacotesDxf() as $pacote) {
            if ($this->codigoDoPacote($pacote) === $codigo) {
                return $pacote;
            }
        }

        return null;
    }

    /* ------------------------------------------------------------------ */
    /*  GRAVAÇÕES                                                          */
    /* ------------------------------------------------------------------ */

    /** POST - cabeçalho do DX: status, prioridade, NEST, observações. */
    public function salvarControle(string $codigo)
    {
        $codigo = strtoupper(trim($codigo));

        if (!DxfControle::tabelaExiste()) {
            return $this->erroMigration();
        }

        $controle = DxfControle::getByCodigo($codigo);

        if (!$controle) {
            return Json::return(['success' => false, 'message' => 'DX não encontrado.'], 404);
        }

        $corpo = $this->corpo();
        $dados = [];

        if (array_key_exists('status_corte', $corpo)) {
            $status = strtoupper(trim((string) $corpo['status_corte']));

            if (!in_array($status, DxfControle::STATUS, true)) {
                return Json::return(['success' => false, 'message' => 'Status inválido.'], 422);
            }

            $dados['status_corte'] = $status;
        }

        if (array_key_exists('prioridade', $corpo)) {
            $prioridade = trim((string) $corpo['prioridade']);

            if ($prioridade !== '' && !in_array($prioridade, DxfControle::PRIORIDADES, true)) {
                return Json::return(['success' => false, 'message' => 'Prioridade inválida.'], 422);
            }

            $dados['prioridade'] = $prioridade !== '' ? $prioridade : null;
        }

        foreach (['nest' => 60, 'descricao' => 255] as $campo => $limite) {
            if (array_key_exists($campo, $corpo)) {
                $valor = trim((string) $corpo[$campo]);
                $dados[$campo] = $valor !== '' ? mb_substr($valor, 0, $limite) : null;
            }
        }

        if (array_key_exists('observacoes', $corpo)) {
            $obs = trim((string) $corpo['observacoes']);
            $dados['observacoes'] = $obs !== '' ? $obs : null;
        }

        if (empty($dados)) {
            return Json::return(['success' => false, 'message' => 'Nada para salvar.'], 422);
        }

        $dados['updated_at'] = date('Y-m-d H:i:s');
        $dados['updated_by'] = $this->usuario();

        DxfControle::updateByColumn('codigo', $codigo, $dados);

        return Json::return(['success' => true, 'message' => 'Dados salvos.'], 200);
    }

    /** POST - cria ou atualiza UMA linha do plano de corte. */
    public function salvarPlano(string $codigo)
    {
        $codigo = strtoupper(trim($codigo));

        if (!DxfControle::tabelaExiste()) {
            return $this->erroMigration();
        }

        $corpo = $this->corpo();

        $id     = trim((string) ($corpo['id'] ?? ''));
        $nProg  = trim((string) ($corpo['n_prog'] ?? ''));
        $tempo  = trim((string) ($corpo['tempo'] ?? ''));

        if ($nProg === '') {
            return Json::return([
                'success' => false,
                'message' => 'Informe o N° Prog antes de salvar a linha.',
            ], 422);
        }

        if ($tempo !== '' && !preg_match('/^\d{1,2}:[0-5]\d(:[0-5]\d)?$/', $tempo)) {
            return Json::return([
                'success' => false,
                'message' => 'Tempo inválido. Use HH:MM ou HH:MM:SS.',
            ], 422);
        }

        if ($tempo !== '' && substr_count($tempo, ':') === 1) {
            $tempo .= ':00';
        }

        $dados = [
            'n_prog'      => $nProg,
            'espessura'   => $this->ouNulo($corpo['espessura'] ?? null),
            'largura'     => $this->inteiroOuNulo($corpo['largura'] ?? null),
            'comprimento' => $this->inteiroOuNulo($corpo['comprimento'] ?? null),
            'qtde'        => $this->inteiroOuNulo($corpo['qtde'] ?? null),
            'tempo'       => $tempo !== '' ? $tempo : null,
            'reserva'     => $this->ouNulo($corpo['reserva'] ?? null),
            'cortado'     => $this->booleano($corpo['cortado'] ?? null) ? 1 : 0,
            'updated_at'  => date('Y-m-d H:i:s'),
            'updated_by'  => $this->usuario(),
        ];

        if ($id !== '') {
            $existente = DxfPlanoCorte::getByUuid($id);

            if (!$existente || (string) $existente->dxf_codigo !== $codigo) {
                return Json::return(['success' => false, 'message' => 'Linha não encontrada.'], 404);
            }

            DxfPlanoCorte::updateByUuid($id, $dados);
        } else {
            $dados['dxf_codigo'] = $codigo;
            $dados['ordem']      = DxfPlanoCorte::proximaOrdem($codigo);
            $dados['created_by'] = $this->usuario();

            $criado = DxfPlanoCorte::create($dados);

            if (!$criado) {
                return Json::return(['success' => false, 'message' => 'Não foi possível criar a linha.'], 500);
            }

            $id = $criado['id'] ?? '';
        }

        return Json::return([
            'success' => true,
            'message' => 'Linha salva.',
            'id'      => $id,
            'resumo'  => DxfPlanoCorte::resumo($codigo),
        ], 200);
    }

    /** POST - remove UMA linha do plano de corte. */
    public function removerPlano(string $id)
    {
        if (!DxfControle::tabelaExiste()) {
            return $this->erroMigration();
        }

        $plano = DxfPlanoCorte::getByUuid($id);

        if (!$plano) {
            return Json::return(['success' => false, 'message' => 'Linha não encontrada.'], 404);
        }

        $codigo = (string) $plano->dxf_codigo;

        DxfPlanoCorte::deleteByUuid($id);

        return Json::return([
            'success' => true,
            'message' => 'Linha removida.',
            'resumo'  => DxfPlanoCorte::resumo($codigo),
        ], 200);
    }

    /* ------------------------------------------------------------------ */
    /*  AUXILIARES                                                         */
    /* ------------------------------------------------------------------ */

    private function erroMigration()
    {
        return Json::return([
            'success' => false,
            'message' => 'Banco desatualizado: rode a migration '
                . '2026-07-21e-controle-cortes.sql.',
        ], 503);
    }

    private function corpo(): array
    {
        if (!empty($_POST)) {
            return $_POST;
        }

        $json = json_decode((string) file_get_contents('php://input'), true);

        return is_array($json) ? $json : [];
    }

    private function usuario(): string
    {
        return (string) ($_SESSION['usuarioNome'] ?? ($_SESSION['user']['nome'] ?? 'SISTEMA'));
    }

    private function ouNulo($valor): ?string
    {
        $valor = trim((string) $valor);

        return $valor !== '' ? $valor : null;
    }

    private function inteiroOuNulo($valor): ?int
    {
        $valor = trim((string) $valor);

        return $valor !== '' && is_numeric($valor) ? (int) $valor : null;
    }

    private function booleano($valor): bool
    {
        return in_array(
            strtolower(trim((string) $valor)),
            ['1', 'true', 'on', 'sim'],
            true
        );
    }
}
