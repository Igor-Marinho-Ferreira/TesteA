<?php

namespace src\app\controllers;

use src\app\database\entities\Estagio;
use src\app\requests\estagios\StoreRequest;
use src\app\requests\estagios\UpdateRequest;
use src\support\Redirect;
use src\support\View;
use Exception;
use src\exceptions\pdo\DuplicateEntryException;

/**
 * Controller responsável por gerenciar as operações CRUD (Criação, Leitura, 
 * Atualização e Exclusão) para a entidade Estagio.
 */
class EstagioController
{

    /**
     * Exibe a view principal de cadastro e listagem de estágios.
     * * @return View Retorna a view 'parametrizacao.estagio' com a lista de todos os estágios.
     */
    function cadastroEstagioView(): View
    {
        return view('parametrizacao.estagio', [
            "estagios" => Estagio::getAll()
        ]);
    }

    /**
     * Armazena um novo registro de Estágio no banco de dados.
     * * @param StoreRequest $request Objeto de requisição contendo os dados validados.
     * @return Redirect Redireciona para a listagem com mensagem de sucesso ou erro.
     */
    function storeEstagio(StoreRequest $request)
    {
        try {
            $estagio = Estagio::create($request->get());
            if (!$estagio) {
                return redirect()->route("parametrizacao.estagios")->withError("Registro não cadastrado");
            }
            return redirect()->route("parametrizacao.estagios")->withSuccess("Registro salvo 🎉");
        } catch (DuplicateEntryException $e) {
            return redirect()->route("parametrizacao.estagios")->withError("Registro já existente");
        } catch (Exception $e) {
            return redirect()->route("parametrizacao.estagios")->withError("Ocorreu um erro interno ao salvar o registro.");
        }
    } 

    /**
     * Atualiza um registro de Estágio existente no banco de dados.
     * * @param UpdateRequest $request Objeto de requisição contendo os dados validados e o ID.
     * @return Redirect Redireciona para a listagem com mensagem de sucesso ou erro.
     */
    function updateEstagio(UpdateRequest $request)
    {
        try{

        $data2update = $request->get();

        Estagio::updateByUuid($data2update['id'], $data2update);
        return redirect()->route("parametrizacao.estagios")->withSuccess("Registro atualizado 🎉");
        } catch (DuplicateEntryException $e) {
        return redirect()->route("parametrizacao.estagios")->withError("Registro já existente");

        } catch (Exception $e) {
        return redirect()->route("parametrizacao.estagios")->withError("Ocorreu um erro interno ao salvar o registro.");
        }
    }

    /**
     * Exibe o modal de confirmação de exclusão para um Estágio específico.
     *
     * @param string $id O UUID do Estágio a ser excluído.
     *
     * @return View Retorna a view do modal de confirmação com os dados do Estágio.
     */
    function modalConfirm(string $id): View
    {
        $estagio = Estagio::getByUuid($id);
        return view('modals.estagios.destroy', [
            "estagio" => $estagio
        ]);
    }

    /**
     * Exibe o modal de edição para um Estágio específico.
     *
     * @param string $id O UUID do Estágio a ser editado.
     *
     * @return View Retorna a view do modal de edição com os dados do Estágio.
     */
    function modalEdit(string $id): View
    {
        $estagio = Estagio::getByUuid($id);
        return view('modals.estagios.edit', [
            "estagio" => $estagio
        ]);
    }

    /**
     * Exclui um Estágio permanentemente do banco de dados pelo seu UUID.
     * * Nota: O comentário original foi ajustado de 'menu'/'lançamento' para 'Estágio'.
     *
     * @param string $id O UUID do Estágio a ser deletado.
     *
     * @return Redirect Redireciona para a tela de listagem de estágios com mensagem de sucesso.
     */
    function deleteEstagio(string $id)
    {
        Estagio::deleteByUuid($id);
        return redirect()->route("parametrizacao.estagios")->withSuccess("Registro deletado com sucesso🎉");
    }
}