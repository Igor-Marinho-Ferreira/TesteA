<?php

namespace src\app\controllers;


use src\support\Redirect;
use src\support\View;



class MenuController
{
    /**
     * Exibe a view principal de cadastro e listagem de usuários.
     * * @return View Retorna a view 'parametrizacao.usuario' com a lista de todos os usuários.
     */
    function menuView(): View
    {
        if (!isset($_SESSION)) {
            header("Location: http://172.29.5.2/greenbrier");
            exit;
        }
        return view('menus.menu', [
           
        ]);
        // return view('404', [
           
        // ]);
    }

    function menuParametrizacaoView(): View
    {
        return view('menus.menuParametrizacao', [
           
        ]);
    }

}