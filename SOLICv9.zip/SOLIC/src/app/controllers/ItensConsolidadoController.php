<?php

namespace src\app\controllers;

use src\app\database\entities\SolicitacaoItemComprado;
use src\support\View;

/**
 * CONSOLIDADO DE ITENS COMPRADOS POR DESCRIÇÃO — 2026-07-21 (7ª rodada).
 *
 * Separa/agrupa as SLs pela descrição dos itens comprados (BOM), para ver
 * quais solicitações pedem o mesmo item e a quantidade total. Espelha a
 * ideia do consolidado por espessura, mas sobre os itens comprados.
 *
 * Agrupamento por DESCRIÇÃO (decisão do usuário) — descrições escritas de
 * forma diferente formam grupos distintos.
 */
class ItensConsolidadoController
{
    function consolidadoItensView(): View
    {
        if (!SolicitacaoItemComprado::tabelaExiste()) {
            return view('itens.consolidadoItens', [
                'grupos'       => [],
                'totais'       => ['itens' => 0, 'descricoes' => 0, 'sls' => 0],
                'temAquisicao' => false,
                'tabelaPronta' => false,
            ]);
        }

        $itens        = SolicitacaoItemComprado::todosComContexto();
        $temAquisicao = SolicitacaoItemComprado::temColunasAquisicao();

        $grupos = [];
        $slsGeral = [];

        foreach ($itens as $item) {
            $desc   = trim((string) ($item->descricao ?? ''));
            $rotulo = $desc !== '' ? $desc : 'SEM DESCRIÇÃO';
            $chave  = mb_strtoupper($rotulo); // agrupa ignorando maiúsc/minúsc

            if (!isset($grupos[$chave])) {
                $grupos[$chave] = (object) [
                    'rotulo'    => $rotulo,
                    'linhas'    => [],
                    'qtdeTotal' => 0.0,
                    'sls'       => [],
                ];
            }

            // Contexto derivado
            $item->cod_z_formatado = $this->formatarZ($item->cod_z ?? '');
            $item->sl = $item->ref ? ('SL' . str_pad((string) $item->ref, 4, '0', STR_PAD_LEFT)) : '';
            $item->projeto = $this->projeto($item);
            $item->projetista = trim((string) ($item->detalhamento_proj ?? '')) !== ''
                ? $item->detalhamento_proj
                : ($item->conceito_proj ?? '');

            $grupos[$chave]->linhas[]   = $item;
            $grupos[$chave]->qtdeTotal += (float) ($item->quantidade ?? 0);
            $grupos[$chave]->sls[(int) $item->ref] = true;

            if (!empty($item->ref)) {
                $slsGeral[(int) $item->ref] = true;
            }
        }

        // Ordena os grupos por descrição (rótulo)
        uasort($grupos, function ($a, $b) {
            return strcasecmp($a->rotulo, $b->rotulo);
        });

        // Finaliza contagem de SLs distintas por grupo
        foreach ($grupos as $g) {
            $g->qtdSls = count($g->sls);
        }

        return view('itens.consolidadoItens', [
            'grupos'       => array_values($grupos),
            'totais'       => [
                'itens'      => count($itens),
                'descricoes' => count($grupos),
                'sls'        => count($slsGeral),
            ],
            'temAquisicao' => $temAquisicao,
            'tabelaPronta' => true,
        ]);
    }

    private function projeto(object $o): string
    {
        $vagao = trim((string) ($o->vagao ?? ''));
        $lote  = trim((string) ($o->lote ?? ''));

        if ($vagao === '' && $lote === '') return '';
        if ($lote === '') return $vagao;

        return $vagao . '_' . $lote;
    }

    private function formatarZ($codZ): string
    {
        $limpo = trim(str_ireplace('Z', '', (string) $codZ));
        return $limpo !== '' ? 'Z' . $limpo : '';
    }
}
