<?php

namespace src\app\controllers;

use Exception;
use src\app\database\entities\Espessura;
use src\exceptions\pdo\DuplicateEntryException;
use src\support\View;

/**
 * Parametrização das ESPESSURAS usadas nos planos de corte
 * (2026-07-21, 5ª rodada). Mesmo padrão dos demais cadastros
 * (Vagões / Estágios / Contas).
 */
class EspessuraController
{
    function cadastroEspessuraView(): View
    {
        return view('parametrizacao.espessura', [
            'espessuras' => Espessura::listar(),
        ]);
    }

    function storeEspessura()
    {
        $valor = trim((string) ($_POST['valor'] ?? ''));

        if ($valor === '') {
            return redirect()->route('parametrizacao.espessuras')
                ->withError('Informe a espessura.');
        }

        try {
            $criado = Espessura::create(array_merge([
                'valor'     => mb_substr($valor, 0, 30),
                'descricao' => $this->descricao(),
            ], $this->camposPeso()));

            if (!$criado) {
                return redirect()->route('parametrizacao.espessuras')
                    ->withError('Registro não cadastrado');
            }

            return redirect()->route('parametrizacao.espessuras')
                ->withSuccess('Registro salvo 🎉');
        } catch (DuplicateEntryException $e) {
            return redirect()->route('parametrizacao.espessuras')
                ->withError('Espessura já cadastrada');
        } catch (Exception $e) {
            return redirect()->route('parametrizacao.espessuras')
                ->withError('Ocorreu um erro interno ao salvar o registro.');
        }
    }

    function updateEspessura()
    {
        $id    = trim((string) ($_POST['id'] ?? ''));
        $valor = trim((string) ($_POST['valor'] ?? ''));

        if ($id === '' || $valor === '') {
            return redirect()->route('parametrizacao.espessuras')
                ->withError('Informe a espessura.');
        }

        try {
            Espessura::updateByUuid($id, array_merge([
                'valor'     => mb_substr($valor, 0, 30),
                'descricao' => $this->descricao(),
            ], $this->camposPeso()));

            return redirect()->route('parametrizacao.espessuras')
                ->withSuccess('Registro atualizado 🎉');
        } catch (DuplicateEntryException $e) {
            return redirect()->route('parametrizacao.espessuras')
                ->withError('Espessura já cadastrada');
        } catch (Exception $e) {
            return redirect()->route('parametrizacao.espessuras')
                ->withError('Ocorreu um erro interno ao salvar o registro.');
        }
    }

    function deleteEspessura(string $id)
    {
        Espessura::deleteByUuid($id);

        return redirect()->route('parametrizacao.espessuras')
            ->withSuccess('Registro deletado com sucesso 🎉');
    }

    private function descricao(): ?string
    {
        $descricao = trim((string) ($_POST['descricao'] ?? ''));

        return $descricao !== '' ? mb_substr($descricao, 0, 120) : null;
    }

    /**
     * Densidade e peso da chapa padrão — só entram no INSERT/UPDATE se a
     * migration 2026-07-21f já tiver criado as colunas (senão dariam erro
     * de coluna inexistente).
     *
     * @return array<string, mixed>
     */
    private function camposPeso(): array
    {
        if (!Espessura::temColunasPeso()) {
            return [];
        }

        $densidade = str_replace(',', '.', trim((string) ($_POST['densidade'] ?? '')));
        $pesoChapa = str_replace(',', '.', trim((string) ($_POST['peso_chapa_padrao'] ?? '')));

        return [
            'densidade'         => is_numeric($densidade) ? (float) $densidade : Espessura::DENSIDADE_PADRAO,
            'peso_chapa_padrao' => is_numeric($pesoChapa) ? (float) $pesoChapa : null,
        ];
    }
}
