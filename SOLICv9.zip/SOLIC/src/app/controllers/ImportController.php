<?php

namespace src\app\controllers;

use PhpOffice\PhpSpreadsheet\IOFactory;
use src\app\database\entities\Solicitacao;
use src\app\database\entities\Acompanhamento;
use src\app\database\entities\Historico;
use Exception;

class ImportController
{
    public function importarExcel()
    {
        try {
            $caminhoExcel = $_ENV['APP_UPLOADS_EXCEL'] ?? null;

            $caminhoExcel = trim($caminhoExcel, " \t\n\r\0\x0B\"");

            $spreadsheet = IOFactory::load($caminhoExcel);
            $worksheet = $spreadsheet->getActiveSheet();
            $rows = $worksheet->toArray(null, true, true, true);

            array_shift($rows);
            Solicitacao::delete()->finish();
            Acompanhamento::delete()->finish();

            foreach ($rows as $index => $row) {
                $ref = trim(str_replace('.0', '', (string)$row['A']));
                if (empty($ref)) continue;


               
                Solicitacao::create([
                    'ref'              => $ref,
                    'cod_z'            => $row['D'] ?? null,
                    'descricao'        => $row['B'] ?? null,
                    'solicitante'      => $row['C'] ?? null,
                    'data_solicitacao' => $this->formatarDataParaBanco($row['W'] ?? null),
                    'data_necessidade' => $this->formatarDataParaBanco($row['J'] ?? null), // Geralmente Conceito Fim ou similar
                    'aplicacao'        => $row['E'] ?? null,
                    'vagao'            => $row['F'] ?? null,
                    'lote'             => $row['Y'] ?? null,
                    'conta'            => $row['BG'] ?? null,
                    'classe'           => $row['AA'] ?? null,
                    'n_safety_walk'    => $row['AZ'] ?? null, // Verifique se a coluna está correta
                    'escopo'           => $row['X'] ?? null,  // Ou a coluna específica de escopo
                ]);

                Acompanhamento::create([
                    'ref'                 => $ref,
                    'cod_z'               => $row['D'] ?? null,
                    'descricao'           => $row['B'] ?? null,
                    'solicitante'         => $row['C'] ?? null,
                    'aplicacao'           => $row['E'] ?? null,
                    'vagao'               => $row['F'] ?? null,
                    'lote'                => $row['Y'] ?? null,
                    'conceito_proj'       => $row['G'] ?? null,
                    'conceito_status'     => $row['H'] ?? null,

                    // Datas processadas diretamente
                    'conceito_inicio'     => $this->formatarDataParaBanco($row['I'] ?? null),
                    'conceito_fim'        => $this->formatarDataParaBanco($row['J'] ?? null),

                    'detalhamento_proj'   => $row['K'] ?? null,
                    'detalhamento_status' => $row['L'] ?? null,
                    'detalhamento_inicio' => $this->formatarDataParaBanco($row['M'] ?? null),
                    'detalhamento_fim'    => $this->formatarDataParaBanco($row['N'] ?? null),

                    'liberacao_status'    => $row['O'] ?? null,
                    'liberacao_data'      => $this->formatarDataParaBanco($row['P'] ?? null),

                    'corte_status'        => $row['Q'] ?? null,
                    'corte_data'          => $this->formatarDataParaBanco($row['R'] ?? null),

                    'exec_status'         => $row['S'] ?? null,
                    'exec_data'           => $this->formatarDataParaBanco($row['T'] ?? null),

                    'tryout_status'       => $row['U'] ?? null,
                    'tryout_data'         => $this->formatarDataParaBanco($row['V'] ?? null),

                    'prio'                => $row['Z'] ?? null,
                    'data_solicitacao'    => $this->formatarDataParaBanco($row['W'] ?? null),

                    'aquisicao_status'    => $row['AB'] ?? null,
                    'aquisicao_data'      => $this->formatarDataParaBanco($row['AC'] ?? null),

                    'classe'              => $row['AA'] ?? null,
                    'conta'               => $row['BG'] ?? null,
                    'historico'           => $row['X'] ?? null,
                ]);


                // 3. Processar e Inserir HISTÓRICO
                // if (!empty($row['X'])) {
                //     $this->processarHistorico($row['X'], $ref);
                // }
            }

            echo "Importação concluída com sucesso!";
            exit;
        } catch (Exception $e) {
            http_response_code(500);
            echo "Erro Crítico: " . $e->getMessage();
            exit;
        }
    }

    private function formatarDataParaBanco($valor)
    {
        if (empty($valor)) {
            return null;
        }

        // 1. Se o Excel mandou o número serial (ex: 43685)
        if (is_numeric($valor)) {
            return \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($valor)->format('Y-m-d');
        }

        // 2. Se por algum motivo vier como texto (ex: "08/08/2019")
        // Trocamos "/" por "-" para o PHP não confundir formato americano/brasileiro
        $dataLimpa = str_replace('/', '-', $valor);
        $timestamp = strtotime($dataLimpa);

        if ($timestamp) {
            return date('Y-m-d', $timestamp);
        }

        return null;
    }

    // private function processarHistorico($textoBruto, $ref)
    // {
    //     if (empty($textoBruto) || strtolower($textoBruto) == 'none') return;

    //     // Regex para capturar: -- Usuario (DD.MM.YYYY - HH:MM): Mensagem
    //     $padrao = '/--\s+(.*?)\s+\((\d{2}\.\d{2}\.\d{4})\s+-\s+(\d{2}:\d{2})\s*\):\s*(.*?)(?=\s*--|$)/s';

    //     if (preg_match_all($padrao, $textoBruto, $matches, PREG_SET_ORDER)) {
    //         foreach ($matches as $m) {
    //             // Índices capturados pelos parênteses da Regex
    //             $nome = $m;  // Primeiro parêntese (.*?)
    //             $data = $m;        // Segundo parêntese (\d{2}\.\d{2}\.\d{4})
    //             $hora = $m;        // Terceiro parêntese (\d{2}:\d{2})
    //             $msg  = $m;  // Quarto parêntese (.*?)

    //             // Converte DD.MM.YYYY para YYYY-MM-DD
    //             $partesData = explode('.', $data);
    //             if (count($partesData) === 3) {
    //                 $dataSql = $partesData . '-' . $partesData . '-' . $partesData;
    //                 $createdAt = "$dataSql $hora:00";

    //                 // Usando create do Querio para gerar ID automático
    //                 // setUuid = true (padrão do seu Querio::create)
    //                 Historico::create([
    //                     'ref'        => $ref,
    //                     'usuario'    => $nome,
    //                     'mensagem'   => $msg,
    //                     'created_at' => $createdAt // Sobrescreve o date() do Querio com a data do histórico
    //                 ]);
    //             }
    //         }
    //     }
    // }
}
