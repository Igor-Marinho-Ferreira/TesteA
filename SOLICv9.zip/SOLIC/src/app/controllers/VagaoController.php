<?php

namespace src\app\controllers;

use src\app\database\entities\Vagao;
use src\app\requests\vagoes\StoreRequest;
use src\app\requests\vagoes\UpdateRequest;
use src\support\Redirect;
use src\support\View;
use Exception;
use src\exceptions\pdo\DuplicateEntryException;

/**
 * Controller responsável por gerenciar as operações CRUD (Criação, Leitura, 
 * Atualização e Exclusão) para a entidade Vagao.
 */
class VagaoController
{

    /**
     * Exibe a view principal de cadastro e listagem de vagões.
     * * @return View Retorna a view 'parametrizacao.vagao' com a lista de todos os vagões.
     */
    function cadastroVagaoView(): View
    {
        return view('parametrizacao.vagao', [
            "vagoes" => Vagao::getAll()
        ]);
    }

    /**
     * Armazena um novo registro de Vagão no banco de dados.
     * Inclui uma verificação prévia de associação (`isAlreadyAssociated`).
     * * @param StoreRequest $request Objeto de requisição contendo os dados validados.
     * @return Redirect Redireciona para a listagem com mensagem de sucesso ou erro.
     */
    function storeVagao(StoreRequest $request)
    {
        try {
            $vagao = Vagao::isAlreadyAssociated($request->get());

            if(!$vagao) {
                return redirect()->route("parametrizacao.vagoes")->withError("O registro não foi salvo. Verifique a associação.");
            }
            Vagao::create($request->get());
            return redirect()->route("parametrizacao.vagoes")->withSuccess("Registro salvo 🎉");

        } catch (DuplicateEntryException $e) {
            return redirect()->route("parametrizacao.vagoes")->withError("Registro já existente");

        } catch (Exception $e) {
            return redirect()->route("parametrizacao.vagoes")->withError("Ocorreu um erro interno ao salvar o registro.");
        }
    } 

    /**
     * Atualiza um registro de Vagão existente no banco de dados.
     * Inclui uma verificação prévia de associação (`isAlreadyAssociated`).
     * * @param UpdateRequest $request Objeto de requisição contendo os dados validados e o ID/UUID.
     * @return Redirect Redireciona para a listagem com mensagem de sucesso ou erro.
     */
    function updateVagao(UpdateRequest $request)
    {
        try{

        $data2update = $request->get();
        // Verifica se o vagão está associado e se a associação é válida
        $verifyData = Vagao::isAlreadyAssociated($data2update,  $data2update['id']);

        if(!$verifyData){
            return redirect()->route("parametrizacao.vagoes")->withError("O registro não foi salvo. Verifique a associação.");
        }
        
        Vagao::updateByUuid($data2update['id'], $data2update);
        return redirect()->route("parametrizacao.vagoes")->withSuccess("Registro atualizado 🎉");
        } catch (DuplicateEntryException $e) {
        return redirect()->route("parametrizacao.vagoes")->withError("Registro já existente");

        } catch (Exception $e) {
        return redirect()->route("parametrizacao.vagoes")->withError("Ocorreu um erro interno ao salvar o registro.");
        }
    }

    
    /**
     * Exibe o modal de confirmação para exclusão de um Vagão específico.
     *
     * @param string $id O UUID do Vagão a ser excluído.
     *
     * @return View Retorna a view do modal de confirmação ('modals.vagoes.destroy') com os dados do Vagão.
     */
    function modalConfirm(string $id): View
    {
        $vagao = Vagao::getByUuid($id);
        return view('modals.vagoes.destroy', [
            "vagao" => $vagao
        ]);
    }

    /**
     * Exibe o modal para edição de um Vagão específico.
     *
     * @param string $id O UUID do Vagão a ser editado.
     *
     * @return View Retorna a view do modal de edição ('modals.vagoes.edit') com os dados do Vagão.
     */
    function modalEdit(string $id): View
    {
        $vagao = Vagao::getByUuid($id);
        return view('modals.vagoes.edit', [
            "vagao" => $vagao
        ]);
    }

    /**
     * Exclui um Vagão permanentemente do banco de dados pelo seu UUID.
     *
     * @param string $id O UUID do Vagão a ser deletado.
     *
     * @return Redirect Redireciona para a tela de listagem de vagões com mensagem de sucesso.
     */
    function deleteVagao(string $id)
    {
        Vagao::deleteByUuid($id);
        return redirect()->route("parametrizacao.vagoes")->withSuccess("Registro deletado com sucesso🎉");
    }
}