<?php

namespace src\app\requests\historico;

use src\app\requests\Request;

class HistoricoRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "ref" => 'nullable',
        "usuario" => 'nullable',
        "mensagem" => 'nullable',
        "situacao" => 'nullable',
    ];
}
