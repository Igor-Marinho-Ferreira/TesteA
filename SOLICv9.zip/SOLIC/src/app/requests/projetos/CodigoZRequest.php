<?php

namespace src\app\requests\projetos;

use src\app\requests\Request;

class CodigoZRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "cod_z" => 'nullable',
        "qtdRev" => 'nullable'
    ];
}
