<?php

namespace src\app\requests\projetos;

use src\app\requests\Request;

class UpdateStatusRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }


  
    protected array $rules = [
        'id'     => 'nullable', 
        'coluna' => 'nullable', 
        'valor'  => 'nullable',
    ];
}
