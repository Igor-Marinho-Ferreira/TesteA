<?php
namespace src\app\requests\usuarios;

use src\app\requests\Request;

class UpdateRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "matricula" => 'nullable',
        "role" => 'nullable',
        "status" => 'nullable',
       
    ];
}