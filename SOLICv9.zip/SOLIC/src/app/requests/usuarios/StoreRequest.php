<?php
namespace src\app\requests\usuarios;

use src\app\requests\Request;

class StoreRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "matricula" => 'nullable',
        "nome" => 'nullable',
        "area" => 'nullable',
        "email" => 'nullable',
        "role" => 'nullable',
        "status" => 'nullable',
        "projeto_pend" => 'nullable',
    ];
}