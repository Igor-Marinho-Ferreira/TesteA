<?php

namespace src\app\requests\solicProjeto;

use src\app\requests\Request;
use Exception;

class StoreRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "cod_z" => 'nullable',
        "descricao" => 'nullable',
        "solicitante" => 'nullable',
        "data_solicitacao" => 'nullable',
        "data_necessidade" => 'nullable',
        "aplicacao" => 'nullable',
        "vagao" => 'nullable',
        "lote" => 'nullable',
        "conta" => 'nullable',
        // "conta_select" => 'nullable',
        "classe" => 'nullable',
        "n_safety_walk" => 'nullable',
        "escopo" => 'nullable',
        "requisito" => 'nullable',
        "anexo" => 'nullable',
        "anexoDescricao" => 'nullable'
    ];


    function getSolicitacaoData()
    {
        $formData = array_only($this->get(), [
            "cod_z", 
            "descricao", 
            "solicitante", 
            "data_solicitacao", 
            "data_necessidade", 
            "aplicacao" ,
            "vagao" ,
            "lote" ,
            "conta" ,
            "conta_select" ,
            "classe" ,
            "n_safety_walk", 
            "escopo" ,
        ]);


        $mensagemInicial = !empty($formData['escopo'])
        ? "ESCOPO: " . $formData['escopo'] 
        : "ESCOPO: (vazio)";

        $contaFinal = !empty($formData['conta']) ? $formData['conta']
            : $formData['conta_select'];

        unset($formData['conta']);
        unset($formData['conta_select']);

        $formData['conta'] = $contaFinal;
        $formData['escopo'] = $mensagemInicial;


        return array_fill_empty_to_null(array_merge($formData));
    }
    function getFilaData()
    {
        $formData = array_only($this->get(), [
            "ref", 
            "descricao", 
            "cod_z",
            "data_solicitacao", 
            "solicitante", 
            "aplicacao" ,
            "vagao" ,
            "lote" ,
            "classe" ,
            "prio" ,
            "conceito_proj" ,
            "conceito_status" ,
            "conceito_inicio" ,
            "conceito_fim" ,
            "detalhamento_proj" ,
            "detalhamento_status" ,
            "detalhamento_inicio" ,
            "detalhamento_fim" ,
            "liberacao_status" ,
            "liberacao_data" ,
            "corte_status" ,
            "corte_data" ,
            "exec_status" ,
            "exec_data" ,
            "conta" ,
            "n_safety_walk" ,
            "conta_select" ,
            "aquisicao_status",
            "aquisicao_data",
            "tryout_status" ,
            "tryout_data" ,
        ]);

        $contaFinal = !empty($formData['conta']) ? $formData['conta']
            : $formData['conta_select'];

        unset($formData['conta']);
        unset($formData['conta_select']);

        $formData['conta'] = $contaFinal;


        return array_fill_empty_to_null(array_merge($formData));
    }

    
    public function getRequisitosData() 
    {
        try {
            $campoRepeticaoFormulario = array_only($this->get(), ['requisito']);
            $camposRepeticaoFormularioPreenchidos = [];

            if (!empty($campoRepeticaoFormulario['requisito']) && is_array($campoRepeticaoFormulario['requisito'])) {
                $requisitoValues = $campoRepeticaoFormulario['requisito'];
                foreach ($requisitoValues as $requisitoText) {
                    $camposRepeticaoFormularioPreenchidos[] = [
                        'requisito' => $requisitoText,
                    ];
                }
            }

            return $camposRepeticaoFormularioPreenchidos;
        } catch (Exception $e) {
            error_log("Erro ao processar requisitos: " . $e->getMessage());
            return []; 
        }
    }



    public function getAnexosData()
    {
        try {
            $campoRepeticaoFormulario = array_only($this->get(), ['anexo', 'anexoDescricao']);

            
            $this->trataArrayCampoAnexo('anexo', $campoRepeticaoFormulario);
            
            $camposRepeticaoFormularioPreenchidos = [];

            if (!empty($campoRepeticaoFormulario['anexo']) && is_array($campoRepeticaoFormulario['anexo'])) {

                $anexosCaminhos = $campoRepeticaoFormulario['anexo'];
                $anexoDescricoes = $campoRepeticaoFormulario['anexoDescricao'] ?? [];

                foreach ($anexosCaminhos as $key => $anexoCaminho) {
                    $camposRepeticaoFormularioPreenchidos[] = [
                        'anexo'   => $anexoCaminho,
                        'descricao' => $anexoDescricoes[$key] ?? null, 
                    ];
                }
            }
            return $camposRepeticaoFormularioPreenchidos;
        } catch (Exception $e) {
            error_log("Erro ao processar anexos: " . $e->getMessage());
            return [];
        }
    }


    function trataArrayCampoAnexo($campoAnexo, &$requestData)
    {
        if (isset($_FILES[$campoAnexo]) && is_array($_FILES[$campoAnexo]['name'])) {
            foreach ($_FILES[$campoAnexo]['name'] as $key => $name) {
                // Verifica se não houve erro no envio do arquivo e se o nome não está vazio
                if ($_FILES[$campoAnexo]['error'][$key] === 0 && !empty($_FILES[$campoAnexo]['name'][$key])) {
                    $uploadDir = $_ENV['APP_UPLOADS_DIR'] ;
                    $targetPath = $uploadDir . basename($_FILES[$campoAnexo]['name'][$key]);
                    
                    // DD($uploadDir, $targetPath);
                    if (move_uploaded_file($_FILES[$campoAnexo]['tmp_name'][$key], $targetPath)) {
                        $requestData[$campoAnexo][] = $targetPath;
                    } else {
                        throw new Exception("Falha ao salvar o arquivo: $campoAnexo, arquivo: $name");
                    }
                } elseif ($_FILES[$campoAnexo]['error'][$key] !== 4) {
                    throw new Exception("Erro de upload no arquivo: $campoAnexo, arquivo: $name");
                }
            }

        } elseif (isset($_FILES[$campoAnexo]) && $_FILES[$campoAnexo]['error'] === 0 && !empty($_FILES[$campoAnexo]['name'])) {
            $uploadDir = $_ENV['APP_UPLOADS_DIR'];
            $targetPath = $uploadDir . basename($_FILES[$campoAnexo]['name']);
            if (move_uploaded_file($_FILES[$campoAnexo]['tmp_name'], $targetPath)) {
                // Adiciona o caminho do arquivo no requestData
                $requestData[$campoAnexo] = $targetPath;
            } else {
                throw new Exception("Falha ao salvar o arquivo: $campoAnexo");
            }
        }

    }



}