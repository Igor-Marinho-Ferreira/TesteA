<?php

namespace src\app\requests;

use src\support\Request as httpRequest;

abstract class Request
{
    /** @var array|null Armazena os dados decodificados do JSON */
    protected static ?array $jsonData = null;

    /** @var array<string, string> */
    protected array $rules;

    function __invoke()
    {
    }

    /**
     * Retorna todos os inputs (exceto token) ou uma chave específica
     */
    public function get(?string $key = null): array|string|null
    {
        if (!$key) {
            // Se não passar chave, retorna tudo do httpRequest tratando o JSON
            return $this->allExcept(["token"]);
        }
        return $this->input($key);
    }

    /**
     * Retorna todos os inputs exceto as chaves passadas no parâmetro
     */
    public function excepts(array $keys): array
    {
        return $this->allExcept($keys);
    }

    /**
     * Método centralizador para capturar dados (POST, GET ou JSON)
     */
    public static function input(string $key = null): string|array|null
    {
        // 1. Tenta pegar do $_GET e $_POST
        $data = array_merge($_GET, $_POST);

        // 2. Se o dado não existe nas globais, verifica se é um JSON no body
        if (!isset($data[$key])) {
            $json = self::getJsonInput();
            if (isset($json[$key])) {
                return $json[$key];
            }
        }

        if ($key === null) {
            return array_merge($data, self::getJsonInput());
        }

        return $data[$key] ?? null;
    }

    /**
     * Lógica interna para ler o php://input apenas uma vez
     */
    protected static function getJsonInput(): array
    {
        if (self::$jsonData === null) {
            $content = file_get_contents('php://input');
            self::$jsonData = json_decode($content, true) ?? [];
        }
        return self::$jsonData;
    }

    /**
     * Helper para filtrar inputs
     */
    protected function allExcept(array $keys): array
    {
        // Pega tudo (GET + POST + JSON)
        $allData = array_merge($_GET, $_POST, self::getJsonInput());

        foreach ($keys as $key) {
            unset($allData[$key]);
        }

        return $allData;
    }

    public function rules(): array
    {
        return $this->rules;
    }

    public function execute(): array
    {
        if (!formValidate($this->rules())) {
            notification()->error('Verifique todos os campos antes de prosseguir');
            redirect()->back()->make();
            die;
        }
        return [];
    }
}
