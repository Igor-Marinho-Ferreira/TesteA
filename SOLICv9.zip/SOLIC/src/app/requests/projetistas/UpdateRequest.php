<?php

namespace src\app\requests\projetistas;

use src\app\requests\Request;

class UpdateRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "projetista" => 'required',
    ];
}
