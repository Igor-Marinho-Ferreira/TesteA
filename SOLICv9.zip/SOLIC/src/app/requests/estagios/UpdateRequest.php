<?php
namespace src\app\requests\estagios;

use src\app\requests\Request;

class UpdateRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "estagio" => 'nullable',
    ];
}