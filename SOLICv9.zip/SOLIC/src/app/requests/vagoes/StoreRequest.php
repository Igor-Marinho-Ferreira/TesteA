<?php
namespace src\app\requests\vagoes;

use src\app\requests\Request;

class StoreRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

         protected array $rules = [
        "vagao" => 'nullable',
        "lote" => 'nullable',
        "descricao" => 'nullable',
        "status" => 'nullable',
        "projeto_pend" => 'nullable',      
    ];
}