<?php
namespace src\app\requests\vagoes;

use src\app\requests\Request;

class UpdateRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "lote" => 'nullable',
        "status" => 'nullable'
    ];
}