<?php
namespace src\app\requests\contas;

use src\app\requests\Request;

class UpdateRequest extends Request
{
    public function __construct()
    {
        $this->execute();
    }

    protected array $rules = [
        "sfp_conta_contabil" => 'nullable',
        "descricao" => 'nullable',
        "status" => 'nullable',
        "valor_ferramenta" => 'nullable',
        "valor_materia_prima" => 'nullable',
        "valor_hh" => 'nullable',
        "sfp" => 'nullable',
        "lider_projeto" => 'nullable',
        "vagao" => 'nullable',
        "lote" => 'nullable'    
    ];
}