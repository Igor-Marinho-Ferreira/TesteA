<?php

use DI\ContainerBuilder;

$containerBuilder = new ContainerBuilder();

$containerBuilder->useAttributes(true);

$containerBuilder->addDefinitions([]);

return $containerBuilder->build();
