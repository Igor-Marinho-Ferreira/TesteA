<?php

namespace src\support;

/**
 * Cronômetro das etapas — apenas EXIBIÇÃO.
 *
 * A contagem em si é gravada no banco por
 * DesenvolvimentoController::carimbarCronometro() a cada troca de status.
 * Aqui só lemos o que já está gravado e montamos o que a tela mostra.
 *
 * Dois modelos convivem (decisão de 2026-07-21, 4ª rodada):
 *
 *  - PRÓPRIO   (aquisição, corte, execução, tryout): colunas dedicadas
 *    {etapa}_tempo + {etapa}_retomado_em, com pausa real.
 *
 *  - DERIVADO  (conceito, detalhamento): não têm colunas novas. O tempo
 *    corrido é fim - início das colunas que já existiam, exibido AO LADO do
 *    cálculo de dias úteis (tempo_modelo / tempo_det), que segue intacto.
 */
final class Cronometro
{
    /** @var array<string, array{prefixo:string, derivado:bool}> */
    public const ETAPAS = [
        'conceito_status'     => ['prefixo' => 'conceito',     'derivado' => true],
        'detalhamento_status' => ['prefixo' => 'detalhamento', 'derivado' => true],
        'aquisicao_status'    => ['prefixo' => 'aquisicao',    'derivado' => false],
        'corte_status'        => ['prefixo' => 'corte',        'derivado' => false],
        'exec_status'         => ['prefixo' => 'exec',         'derivado' => false],
        'tryout_status'       => ['prefixo' => 'tryout',       'derivado' => false],
    ];

    /**
     * Monta o mapa de tempos por coluna de status.
     *
     * Etapa cuja coluna ainda não existe no banco (migration não rodada) é
     * simplesmente omitida — a tela não mostra cronômetro para ela.
     *
     * @return array<string, array{segundos:int, rodando:bool, derivado:bool}>
     */
    public static function mapa(?object $solic): array
    {
        if (!$solic) {
            return [];
        }

        $mapa = [];

        foreach (self::ETAPAS as $coluna => $cfg) {
            $prefixo = $cfg['prefixo'];

            if ($cfg['derivado']) {
                if (!property_exists($solic, $prefixo . '_inicio')) {
                    continue;
                }

                $segundos = self::derivado($solic, $prefixo);
                $rodando  = self::preenchido($solic->{$prefixo . '_inicio'} ?? null)
                    && !self::preenchido($solic->{$prefixo . '_fim'} ?? null);
            } else {
                if (!property_exists($solic, $prefixo . '_tempo')) {
                    continue;
                }

                $segundos = self::acumulado($solic, $prefixo);
                $rodando  = self::preenchido($solic->{$prefixo . '_retomado_em'} ?? null);
            }

            $mapa[$coluna] = [
                'segundos' => $segundos,
                'rodando'  => $rodando,
                'derivado' => $cfg['derivado'],
            ];
        }

        return $mapa;
    }

    /** Tempo acumulado + o intervalo ativo em curso (modelo com pausa). */
    private static function acumulado(object $solic, string $prefixo): int
    {
        $tempo    = (int) ($solic->{$prefixo . '_tempo'} ?? 0);
        $retomado = $solic->{$prefixo . '_retomado_em'} ?? null;

        if (self::preenchido($retomado)) {
            $ini = strtotime((string) $retomado);
            $now = time();
            if ($ini && $now > $ini) {
                $tempo += ($now - $ini);
            }
        }

        return max(0, $tempo);
    }

    /** fim - início (ou agora - início, se ainda em curso). */
    private static function derivado(object $solic, string $prefixo): int
    {
        $inicio = $solic->{$prefixo . '_inicio'} ?? null;
        $fim    = $solic->{$prefixo . '_fim'} ?? null;

        if (!self::preenchido($inicio)) {
            return 0;
        }

        $ini = strtotime((string) $inicio);
        if (!$ini) {
            return 0;
        }

        $ref = self::preenchido($fim) ? strtotime((string) $fim) : time();

        return ($ref && $ref > $ini) ? ($ref - $ini) : 0;
    }

    /** Trata NULL, string vazia e a data zero do MySQL. */
    private static function preenchido($valor): bool
    {
        return !empty($valor)
            && $valor !== '0000-00-00 00:00:00'
            && $valor !== '0000-00-00';
    }

    /** Formata segundos como "2h 05m", "45m", "30s" ou "—". */
    public static function formatar($segundos): string
    {
        $segundos = max(0, (int) $segundos);

        if ($segundos === 0) {
            return '—';
        }

        if ($segundos < 60) {
            return $segundos . 's';
        }

        $h = intdiv($segundos, 3600);
        $m = intdiv($segundos % 3600, 60);

        if ($h > 0) {
            return $h . 'h ' . str_pad((string) $m, 2, '0', STR_PAD_LEFT) . 'm';
        }

        return $m . 'm';
    }
}
