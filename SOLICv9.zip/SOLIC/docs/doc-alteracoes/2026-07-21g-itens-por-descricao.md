# Alterações — 21/07/2026 (7ª rodada)

**Consolidado de Itens Comprados por Descrição.** Separa/agrupa as SLs pela descrição dos
itens comprados (BOM), para ver quais solicitações pedem o mesmo item e a quantidade total.
É a mesma ideia do consolidado por espessura, mas sobre os itens comprados.

> **Premissa:** só soma, não refatora. Segurança geral continua em aberto.

---

## Sem migration

Usa a tabela `solicitacao_itens_comprados` que já existe (BOM). As colunas de aquisição
(N° OC, liquidado) só aparecem se a migration `2026-07-21-aquisicao...` já tiver rodado;
sem ela, a tela funciona igual, só não mostra essas duas colunas.

---

## 1. Arquivos

### Criados

| Arquivo | Função |
|---|---|
| `src/app/controllers/ItensConsolidadoController.php` | Agrupa os itens por descrição |
| `src/app/views/itens/consolidadoItens.php` | Tela do consolidado |
| `public/js/itensConsolidado.js` | Busca local (descrição/código/SL) |

### Alterados

| Arquivo | O que mudou |
|---|---|
| `src/app/database/entities/SolicitacaoItemComprado.php` | `tabelaExiste()`, `todosComContexto()` |
| `src/app/views/menus/menu.php` | card **"ITENS COMPRADOS POR DESCRIÇÃO"** |
| `src/routes/routes.php` | 1 rota nova |

---

## 2. O que a tela faz

Acesso pelo menu → **"ITENS COMPRADOS POR DESCRIÇÃO"** (`/dispositivos/itens-consolidado`).

- Junta **todos os itens comprados** (`solicitacao_itens_comprados`) e os **agrupa pela
  descrição** (decisão do usuário — agrupamento por texto).
- Cada grupo (descrição) mostra: **quantidade total**, **nº de SLs** e **nº de linhas**.
- Cada linha traz: **N° SL** (link para a SL), Cod Z, Vagão/Local, Projetista, Código, Rev,
  Qtde, Tipo e — se a aquisição estiver ativa — **N° OC** e **Status** (liquidado).
- No topo: totais gerais (descrições, itens e SLs envolvidas).
- **Busca** por descrição, código ou SL (filtra as linhas e esconde grupos vazios).

Assim fica explícito **quais SLs pedem o mesmo item** e **quanto no total** — útil para
consolidar a compra.

### Sobre o agrupamento

Como combinado, o agrupamento é **pela descrição** (comparada ignorando maiúsc/minúsc).
Descrições escritas de forma diferente (ex.: "PARAFUSO M8" x "PARAF. M8") formam **grupos
distintos** — é a limitação natural de agrupar por texto. Se um dia quiserem agrupar pelo
**código** (mais confiável), é uma troca de uma linha no controller.

---

## 3. Rota nova

| Método | Rota | Ação |
|---|---|---|
| GET | `/dispositivos/itens-consolidado` | `consolidadoItensView` |

---

## 4. Como testar

1. **Menu:** aparece o card "ITENS COMPRADOS POR DESCRIÇÃO".
2. **Tela:** os itens aparecem agrupados por descrição, com qtde total e nº de SLs por grupo.
   Se estiver vazia, é porque ainda não há BOM cadastrada — envie pelo Access (uploadBomVba)
   ou pela tela de desenvolvimento.
3. **Busca:** digite parte de uma descrição/código/SL e confirme que só os grupos com
   correspondência permanecem.

---

## 5. O que NÃO foi feito

- Agrupamento por código (ficou por descrição, como pedido).
- Exportação (PDF/Excel) — não pedida.
- Controle de acesso por perfil — como o resto do sistema.
