# Alterações — 21/07/2026 (5ª rodada)

**Controle de Cortes de Peças** — traz para a web a tela que hoje vive no Access
("Dados do Projeto", de 2018): a lista dos pacotes DXF e, ao abrir um DX, os planos
de corte.

> **Premissa:** só soma, não refatora. Segurança geral continua em aberto.

---

## ⚠️ Passo obrigatório

```
database/migrations/2026-07-21e-controle-cortes.sql
```

Cria **3 tabelas** (nenhuma existente é alterada):

| Tabela | Para quê |
|---|---|
| `dxf_controle` | NEST, prioridade, status de corte, observações — por pacote DXF |
| `dxf_planos_corte` | as linhas da grade (Nº Prog, Esp., Larg., Comp., Qtde, Tempo, Reserva, Corte?) |
| `espessuras` | parametrização da coluna Esp. (já vem com 3,00 / 4,75 Xd / 6,35 / 9,50) |

Antes de rodar **nada quebra**: a lista aparece com um aviso e os campos ficam
bloqueados.

---

## 1. Por que precisou de tabelas novas

O próprio doc do projeto (`docs/doc-desenvolvimento/pacote-dxf.md`) registra:

> | Metadados | Access (`DXF_Control`): Descricao, Prioridade, Status corte, Projetista, Projeto, IMG | Web (antes): **nenhum (só arquivo + código)** |

Ou seja: a web já recebe o **arquivo** do pacote (`solicitacao_anexo_arquivos`,
`tipo='PACOTE_DXF'`, `codigo='DX5064'`), mas nunca teve os metadados nem os planos
de corte. É isso que esta rodada preenche.

---

## 2. Arquivos

### Criados

| Arquivo | Função |
|---|---|
| `src/app/controllers/ControleCorteController.php` | Lista, detalhe e gravações |
| `src/app/controllers/EspessuraController.php` | Parametrização das espessuras |
| `src/app/database/entities/DxfControle.php` | Controle por pacote |
| `src/app/database/entities/DxfPlanoCorte.php` | Linhas da grade |
| `src/app/database/entities/Espessura.php` | Espessuras |
| `src/app/views/cortes/listaCortes.php` | Lista |
| `src/app/views/cortes/detalheCorte.php` | Tela "Dados do Projeto" |
| `src/app/views/parametrizacao/espessura.php` | Cadastro de espessuras |
| `public/css/cortes.css` | Visual da tela |
| `public/js/listaCortes.js`, `public/js/detalheCorte.js` | Comportamento |
| `database/migrations/2026-07-21e-...sql` | As 3 tabelas |

### Alterados

| Arquivo | O que mudou |
|---|---|
| `src/routes/routes.php` | 8 rotas novas |
| `src/app/views/menus/menu.php` | Card "CONTROLE DE CORTES DE PEÇAS" |
| `src/app/views/menus/menuParametrizacao.php` | Item "ESPESSURAS" |

---

## 3. Lista (`/dispositivos/cortes`)

Colunas conforme a imagem: **Ref. | Descrição | Cod Z | N° SL | Projeto | IMG | DXF | NEST |
Prioridade | Status Corte**.

Conforme combinado:

- **IMG e DXF** são *flags* calculadas (✓/–), não campos: IMG indica que a SL tem
  `IMAGEM_PROJETO`; DXF indica o pacote em si.
- **NEST** é campo digitado (coluna nova em `dxf_controle`).
- **Projeto = `vagao_lote`** — derivado da fila, sem coluna nova.
- **Projetista** = `detalhamento_proj` ou, na falta, `conceito_proj`.
- Lista **só os DX que já estão na web**. O histórico antigo do Access não foi migrado —
  DX anteriores à integração só aparecem quando forem reenviados.

Filtros por status e prioridade. A tabela usa a mesma correção de salto de layout das
outras listas.

O código DX é extraído com a **mesma cascata** que o `csvDxf` já usava
(`codigo` → `nome_arquivo` → `nome_original` → `caminho`), então não inventei uma
segunda regra de leitura.

---

## 4. Detalhe do DX (`/dispositivos/cortes/{codigo}`)

Espelha o formulário do Access:

- **Projeto**: DX em destaque, Código Z (vermelho), Solicitação (link para a SL),
  Projeto, Projetista, Descrição, miniatura da imagem, "DXF inserido em", e os botões
  **Imagem** e **Arquivos DXF (ZIP)** (usam as rotas de arquivo que já existiam)
- **NEST** e **Prioridade**
- **Status dos Projetos/Execução**: Aguardando / Corte Liberado / Corte em Andamento /
  Finalizado — com as cores do original. **Trocar o rádio grava na hora**
- **Dados dos Planos de Corte**: grade editável com Nº Prog, Esp. (select
  parametrizado), Larg., Comp., Qtde., Tempo, Reserva e "Corte? OK". Linha com corte OK
  fica **verde**, como no Access. Há sempre uma linha em branco no fim, e o botão
  "Adicionar linha"
- **Observações**

A linha de controle (`dxf_controle`) é criada **sob demanda**, na primeira vez que o DX é
aberto — não precisa de carga prévia.

### Validações no servidor

| Regra | Resultado |
|---|---|
| Nº Prog vazio | 422 |
| Tempo fora de HH:MM ou HH:MM:SS | 422 |
| Status fora da lista | 422 |
| Prioridade fora da lista | 422 |
| Linha de outro DX | 404 |
| Migration não rodada | 503 com a instrução |

`Esp.` é gravada como **texto** de propósito: "4,75 Xd" não é número. Se uma espessura
sair da parametrização, a linha que já a usava continua exibindo o valor antigo.

---

## 5. Parametrização de espessuras

Novo item no menu de parametrização, no mesmo padrão de Vagões/Estágios/Contas.
Cadastrar, listar e excluir. A migration já popula as quatro que aparecem na tela do
Access.

---

## 6. Rotas novas

| Método | Rota | Ação |
|---|---|---|
| GET | `/dispositivos/cortes` | `listaCortesView` |
| GET | `/dispositivos/cortes/{codigo}` | `detalheCorteView` |
| POST | `/dispositivos/cortes/{codigo}/controle` | `salvarControle` |
| POST | `/dispositivos/cortes/{codigo}/plano` | `salvarPlano` |
| POST | `/dispositivos/cortes/plano/{id}/remover` | `removerPlano` |
| GET | `/dispositivos/espessuras` | `cadastroEspessuraView` |
| POST | `/dispositivos/espessuras/store` \| `/update` | `storeEspessura` \| `updateEspessura` |
| GET | `/dispositivos/espessuras/delete/{id}` | `deleteEspessura` |

Conferi as colisões: a rota de remover plano tem 5 segmentos e as de `{codigo}` têm 4,
então o regex não se sobrepõe; e `/dispositivos/cortes` exato é resolvido pelo
`simpleRouter` antes das dinâmicas.

---

## 7. Como testar

1. Rode a migration.
2. **Menu:** aparecem "CONTROLE DE CORTES DE PEÇAS" e, em parametrização, "ESPESSURAS".
3. **Lista:** os pacotes DXF já recebidos aparecem com IMG/DXF marcados. Se estiver
   vazia, é porque ainda não há `PACOTE_DXF` na web — envie um pelo Access
   (`uploadDxfVba`) ou pela tela de desenvolvimento.
4. **Detalhe:** clique num DX. Confira cabeçalho, imagem e o botão de ZIP.
5. **Status:** troque o rádio — grava na hora e o toast confirma.
6. **Planos:** preencha a linha em branco e clique em Salvar; marque "OK" e veja a linha
   ficar verde e o contador subir. Adicione outra linha, remova uma. Tente salvar sem
   Nº Prog e com tempo inválido (ex.: `99:99`) — deve recusar.
7. **Espessuras:** cadastre uma nova e confirme que aparece no select da grade.

---

## 8. O que NÃO foi feito

- **Sem controle de acesso** — como o resto do sistema. Quando o SSO voltar, o
  `menu.php` já tem a estrutura de `authorization()` comentada.
- **Sem sincronização de volta para o Access.** Os planos de corte são novos e só
  existem na web. Se o Access precisar deles, dá para fazer um CSV no mesmo modelo do
  `csvDxf` que já existe — é o caminho natural, mas não foi pedido.
- **Imagem por DX:** no Access existe `.imgs\DX0005.jpg` (imagem por pacote). Na web só
  existe imagem por **SL** (`IMAGEM_PROJETO`), e é ela que a tela mostra. Se quiserem
  imagem por DX, precisa de um tipo de anexo novo.
- Não criei DX pela web nem rota de carga do histórico — conforme decidido, a lista
  mostra só o que já está na web.
