# Alterações — 21/07/2026 (6ª rodada)

**Cálculo de Peso — Consolidado por Espessura.** Resolve o problema apontado: na lista de
cortes "não fica claro para quais projetos preciso da mesma espessura". A nova tela junta
todos os planos de corte e os agrupa por espessura, com área e peso teórico por linha e por
grupo, e a quantidade de chapas a comprar.

> **Premissa:** só soma, não refatora. Segurança geral continua em aberto.

---

## ⚠️ Passo obrigatório

```
database/migrations/2026-07-21f-calculo-peso.sql
```

Só `ALTER TABLE` / `CREATE TABLE`:

| Mudança | Para quê |
|---|---|
| `espessuras` + `densidade`, `peso_chapa_padrao` | peso teórico e quantidade de chapas |
| Nova tabela `perfis` | perfis lineares (Tubo, Viga W, Perfil U, …) com peso por metro |

**O consolidado não tem tabela nova** — ele lê os planos de corte (`dxf_planos_corte`, da
5ª rodada). Antes da migration nada quebra: a tela usa densidade padrão (7860) e não mostra
"chapas a comprar".

---

## 1. Arquivos

### Criados

| Arquivo | Função |
|---|---|
| `src/app/controllers/CalculoPesoController.php` | Consolidado por espessura + tela de perfis |
| `src/app/controllers/PerfilController.php` | Parametrização dos perfis |
| `src/app/database/entities/Perfil.php` | Perfis |
| `src/app/views/cortes/calculoPeso.php` | Consolidado + calculadora de chapa |
| `src/app/views/cortes/calculoPerfis.php` | Calculadora de perfis |
| `src/app/views/parametrizacao/perfil.php` | Cadastro de perfis |
| `public/js/calculoPeso.js`, `public/js/calculoPerfis.js` | Calculadoras (no navegador) |
| `database/migrations/2026-07-21f-...sql` | Colunas + tabela |

### Alterados

| Arquivo | O que mudou |
|---|---|
| `src/app/database/entities/Espessura.php` | densidade, peso da chapa, normalização de espessura |
| `src/app/controllers/EspessuraController.php` | grava densidade e peso da chapa padrão |
| `src/app/views/parametrizacao/espessura.php` | campos densidade / chapa padrão |
| `src/app/views/cortes/listaCortes.php` | botão para o Cálculo de Peso |
| `src/app/views/menus/menuParametrizacao.php` | item "PERFIS" |
| `public/css/cortes.css` | estilo dos grupos por espessura |
| `src/routes/routes.php` | 6 rotas novas |
| `src/app/views/menus/menu.php` | card **"RESERVAS - CÁLCULO DE PESO"** no menu principal *(ajuste posterior)* |
| `src/app/views/cortes/calculoPeso.php` | título → "RESERVAS - CÁLCULO DE PESO"; volta ao menu *(ajuste posterior)* |

> **Ajuste posterior (menu):** a tela consolidada (equivalente à aba **Reservas** da
> planilha) ganhou um item próprio no menu principal — antes só era acessível por um botão
> dentro do Controle de Cortes. A rota (`dispositivos.cortes.calculoPeso`) e a tela não
> mudaram; apenas o acesso e o rótulo. É a mesma grade agrupada por espessura (Ctrl/DX,
> Cod Z, Descrição, Vagão, Projetista, Programa, Esp, Larg, Comp, Qtde, Área, Peso, Reserva).

---

## 2. Consolidado por Espessura (a tela principal)

Acesso pela lista de Controle de Cortes → botão **"Cálculo de Peso"** (ou
`/dispositivos/cortes-peso`).

- Junta **todos os planos de corte** (`dxf_planos_corte`) e os agrupa por espessura.
- Cada linha traz, como na planilha do Access: **Ctrl (DX), Cod Z, Descrição, Vagão/Local,
  Projetista, Programa, Esp, Larg, Comp, Qtde, Área (m²), Peso (kg), Reserva** — com link do
  DX para a tela de detalhe.
- Cada grupo mostra o **subtotal de área e peso** e a **quantidade de chapas a comprar**.
- No topo, os totais gerais (linhas, área e peso).

Assim, para qualquer espessura fica explícito **quais DX/projetos a usam** e **quanto pesa
no total** — que é o que a lista por SL não mostrava.

### Fórmula (validada contra a planilha)

```
Área(m²)  = Largura(mm) × Comprimento(mm) × Qtde ÷ 1.000.000
Peso(kg)  = Área(m²) × Espessura(mm)/1000 × Densidade(kg/m³)
```

Conferência com os números das imagens enviadas:

| Caso | Planilha | Cálculo |
|---|---|---|
| 1100 × 3000 × 6,35 mm | Volume 0,020955 m³ | 0,020955 m³ ✅ |
| DX5045 — 1450 × 2200 × 4,75 mm | Área 3,19 · Peso ~118,95 | Área 3,19 · Peso 119,10 ✅ |

*(A pequena diferença no peso é o arredondamento da própria planilha.)*

A espessura é lida do plano em texto ("4,75", "4,75 Xd", "6.35") e normalizada para número.
A **densidade** vem da parametrização por espessura (padrão 7860, aço). A **quantidade de
chapas** = arredonda para cima (peso total do grupo ÷ peso da chapa padrão), quando a chapa
padrão está cadastrada.

---

## 3. Calculadora de Peso Teórico (chapa)

Botão **"Calculadora de peso"** na própria tela do consolidado (espelha a tela "Cálculo do
Peso Teórico" do Access). Informa Largura, Comprimento, Espessura, Qtde e Densidade →
mostra Volume, Área, Peso unitário e Peso total. Roda **no navegador**, sem gravar. Ao
digitar uma espessura já cadastrada, a densidade é preenchida automaticamente.

---

## 4. Perfis (Tubo, Viga W, Perfil U, …)

Conforme combinado, os perfis lineares entram de forma **parametrizável**:

- **Parametrização → Perfis:** cadastro por tipo (as 9 abas da planilha: Tubo Retangular,
  Viga W, Perfil U, Barra, Fuso, Tubo, Cantoneira, Barra Chata, Barra Quadrada), com
  bitola/dimensão e o **peso por metro (kg/m)**.
- **Cálculo de Peso → Peso de perfis** (`/dispositivos/cortes-perfis`): escolhe o perfil,
  informa comprimento e quantidade → `Peso = kg/m × comprimento(m) × qtde`.

O **peso por metro** vem das tabelas de cada perfil (informado pela área). Não embuti as
tabelas de bitola no código — cada perfil é cadastrado com o seu kg/m, o que cobre os 9
tipos de forma uniforme e sem inventar fórmulas.

---

## 5. Parametrização de Espessuras (estendida)

O cadastro de espessuras ganhou **Densidade** (padrão 7860) e **Peso da chapa padrão (kg)**.
Só são gravados se a migration já tiver criado as colunas — senão o cadastro continua
funcionando sem eles.

---

## 6. Rotas novas

| Método | Rota | Ação |
|---|---|---|
| GET | `/dispositivos/cortes-peso` | `consolidadoView` |
| GET | `/dispositivos/cortes-perfis` | `perfisView` |
| GET | `/dispositivos/perfis` | `cadastroPerfilView` |
| POST | `/dispositivos/perfis/store` \| `/update` | `storePerfil` \| `updatePerfil` |
| GET | `/dispositivos/perfis/delete/{id}` | `deletePerfil` |

Usei os caminhos `cortes-peso` e `cortes-perfis` (com hífen) de propósito, para **não**
colidirem com a rota dinâmica `/dispositivos/cortes/{codigo}` da 5ª rodada.

---

## 7. Como testar

1. Rode a migration.
2. **Parametrização → Espessuras:** preencha densidade e peso da chapa padrão de uma
   espessura (ex.: 6,35 → 7860 / 1000).
3. **Controle de Cortes → Cálculo de Peso:** confira os grupos por espessura, com área,
   peso e chapas a comprar. Clique num DX para ir ao detalhe.
4. **Calculadora de peso:** 1100 × 3000 × 6,35 → Volume 0,020955 e Peso ~164,71 kg.
5. **Parametrização → Perfis:** cadastre um perfil (ex.: Tubo Retangular 50x30x2, 2,35 kg/m).
6. **Cálculo de Peso → Peso de perfis:** escolha o perfil, informe comprimento e qtde,
   confira o peso.

---

## 8. O que NÃO foi feito

- **"Peso saldo devedor" e "Média de Unidade"** (que aparecem na imagem 2): são controles
  específicos da planilha que dependem de regra de negócio não descrita. A conta de compra
  aqui é direta (peso total ÷ chapa padrão). Se quiserem o saldo devedor, é preciso definir
  de onde vem o saldo.
- **Tabelas de bitola dos perfis** embutidas: os perfis são cadastrados com o kg/m; não
  trouxe as tabelas de peso-por-metro de cada bitola para dentro do código.
- **"Gerar Relatório" / exportação** da planilha: a tela mostra o consolidado; a exportação
  (PDF/Excel) não foi pedida e pode entrar depois, no modelo do `csvDxf` que já existe.
- Controle de acesso por perfil — como o resto do sistema.
