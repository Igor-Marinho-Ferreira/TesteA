# Alterações — 21/07/2026 (10ª rodada)

A tela de **detalhe da Industrial** passou a ter o **mesmo contexto visual da
Automação** — imagem do projeto, documentação (PDFs), requisitos, anexos e
pacotes de DXF — **sem perder** a parte que já era da Industrial (campos #Pasta
etc., aquisição/OC, cortes).

> ⚠️ **Sem migration.** Nada de banco novo. Só leitura de dados que já existem.

---

## Decisão: SÓ LEITURA

Quem **sobe** arquivo (imagem, PDF, DXF, anexos) continua sendo a **automação**.
Na industrial esses blocos são **apenas para consultar e baixar** — não há botão
de upload, e **nenhuma rota nova** foi criada. Isso mantém o princípio da 8ª
rodada ("a automação sobe / a industrial vê") e o "só soma, não refatora".

---

## O que apareceu na tela da Industrial

O **topo ficou com o MESMO layout da automação** (um único card, mesma
disposição), só que em modo consulta:

1. **Card do topo (igual ao da automação)**:
   - Bloco **PROJETO**: Cód. Z, REV e Descrição do projeto — **só leitura**
     (não tem associar/gerar Z; isso é da automação).
   - Botões **Requisitos** e **Ver anexos** — abrem os mesmos modais de leitura
     da automação (`openModal`), via rotas genéricas de `solicitacao` que já
     existiam.
   - Bloco **DADOS DA SOLICITAÇÃO** + caixa cinza (Data, Solicitante, Estágio,
     Vagão, Lote, Classificação, Safety Walk) — igual à automação.
   - Coluna **VISUALIZAÇÃO**: imagem do projeto (abrir + **Baixar imagem**),
     sem inserir/alterar.
   - Coluna **DOCUMENTAÇÃO**: lista de PDFs (abrir + baixar), sem adicionar.
2. **Seção "PACOTES DE DXFs PARA CORTE"**: tabela com código, descrição,
   prioridade, status e **Baixar** — a industrial baixa o DXF para cortar.
3. **TXTs de Itens Comprados** (quando houver): lista com **Baixar**.

4. **Bloco PROJETO (projetistas)**: as três colunas Conceito/Modelo,
   Detalhamento e Execução — projetista + Início/Fim/Status — **só leitura**
   (sem os formulários de alocar/backlog, que são da automação).

A diferença em relação à automação são só os **ajustes da industrial**: os
uploads e os formulários de alocação viram consulta, e **somam-se** os campos do
industrial (#Pasta etc.), a **aquisição/OC** e os **cortes** — que já existiam.
Todo o resto (topo + projetistas) tem o mesmo layout da automação.

---

## Arquivos

### Alterados
| Arquivo | O que mudou |
|---|---|
| `src/app/controllers/IndustrialController.php` | `industrialInfoView` agora carrega os anexos (imagem, PDFs, DXF, TXT) e passa para a view; helpers privados `separarArquivosSolicitacao()` e `criarMapaCargas()` (espelho da automação, só leitura); imports das entidades de anexo |
| `src/app/views/industrial/industrialForm.php` | Card de contexto (imagem/documentação/requisitos/anexos) + seção de DXF + TXTs, tudo somente leitura; helper `$formatarBytes` |

### Reaproveitado (sem alterar)
- Rotas `dispositivos.desenvolvimento.arquivo.visualizar` / `.download` (servem
  arquivo por `id`, funcionam de qualquer tela).
- Modais `dispositivos/solicitacao/requisitos/{ref}` e `.../anexos/{ref}`.
- `openModal()` do `desenvolvimentoProj.js` (já era carregado na industrial).

---

## Como testar

1. Abra uma SL na **Industrial** (detalhe).
2. Confira que aparecem: imagem do projeto (se houver), lista de PDFs, botões
   **Requisitos** e **Ver anexos**, tabela de **DXFs para corte** e TXTs.
3. Clique em **Baixar** num PDF/DXF/TXT → baixa. **Requisitos**/**Ver anexos** →
   abrem o modal.
4. Confirme que **não há** botão de upload em lugar nenhum da industrial (o
   envio segue só na automação).
5. Os blocos que já existiam (campos do industrial, aquisição/OC, cortes)
   continuam funcionando igual.
