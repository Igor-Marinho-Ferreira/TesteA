# Alterações — 21/07/2026 (8ª rodada)

**Liberar SL, Aquisição/OC e cortes passaram para a INDUSTRIAL. A Automação apenas
visualiza.**

> **Premissa:** só soma, não refatora. Segurança geral continua em aberto.

Sem migration.

---

## O que mudou de dono

| Ação | Antes | Agora |
|---|---|---|
| **Liberar SL** | Automação (tela de desenvolvimento) | **Industrial** |
| **Aquisição / colocar OC** | Automação | **Industrial** |
| **Concluir aquisição / bypass** | Automação | **Industrial** |
| **Retornar SL** | Automação | **Industrial** |
| **Corte / Execução** | já era Industrial (4ª rodada) | Industrial |
| Conceito / Detalhamento / anexos | Automação | Automação (inalterado) |

Na tela de **Automação**, tudo isso agora é **somente leitura**.

---

## 1. Arquivos

### Criado

| Arquivo | Função |
|---|---|
| `src/app/views/desenvolvimento/aquisicaoPanel.php` | Painel de aquisição (itens + OC) — **partial** compartilhado, com flag `$editavel` |

### Alterados

| Arquivo | O que mudou |
|---|---|
| `src/app/controllers/DesenvolvimentoController.php` | etapas Liberação e Aquisição → `edit => false` |
| `src/app/views/desenvolvimento/desenvolvimentoForm.php` | força somente leitura; Liberar/Retornar viram rótulo de status |
| `src/app/controllers/IndustrialController.php` | Liberação editável; passa itens/OC/bypass à view |
| `src/app/views/industrial/industrialForm.php` | botão Liberar SL; seção "Itens Comprados e Aquisição" (inclui o partial) |

---

## 2. Automação (desenvolvimento) — somente leitura

- As etapas **Liberação** e **Aquisição** na barra ficam **travadas** (não editáveis).
- O painel de aquisição continua aparecendo, mas o **N° OC é só leitura** e os botões
  **Concluir / Pular liquidação** somem.
- No rodapé, onde havia **Liberar SL / Retornar SL**, agora há apenas um **rótulo de
  status**: "Aguardando liberação", "SL Liberada" ou "SL Cancelada".

Para não arriscar a tela que já está em produção, isso foi feito por **flags** (sem cortar
o HTML): `$aquisicaoEmAberto`, `$podeLiberarSl` e `$podeRetornarSl` foram forçados a
`false` na Automação.

---

## 3. Industrial — passou a fazer

- **Liberar SL:** a etapa Liberação vira um **select** (habilitado quando Conceito e
  Detalhamento estão OK) e há o botão **"Liberar SL"** no rodapé. Escolher **OK** ou clicar
  no botão abre a mesma **modal de consideração** de antes.
- **Aquisição / OC:** nova seção **"Itens Comprados e Aquisição"** com a grade de itens —
  **N° OC editável**, barra de liquidação, **Concluir aquisição** e o **bypass de teste**
  (matrícula 459844). Pedido e liquidação continuam vindo da rotina do Logix.
- **Retornar SL** já existia na Industrial.

O painel de aquisição é o **mesmo partial** usado pela Automação — a diferença é só o flag
`$editavel` (true na Industrial, false na Automação). Assim não há duplicação de HTML e o
comportamento é idêntico ao que já existia.

Nada mudou nos endpoints: a Industrial chama as mesmas rotas
(`/dispositivos/desenvolvimento/liberacao/...`, `.../aquisicao/...`) — o `liberacaoAquisicao.js`
já estava carregado na tela Industrial (4ª rodada), então toda a mecânica funciona lá.

---

## 4. Como testar

1. **Automação:** abra uma SL. Liberação e Aquisição devem estar **travadas**; o N° OC
   aparece como texto (não editável); o rodapé mostra só o status (sem Liberar/Retornar).
2. **Industrial:** na mesma SL (com Conceito e Detalhamento OK), deve aparecer o botão
   **Liberar SL**. Libere → registre a consideração → confira o histórico.
3. **Industrial — aquisição:** com a SL liberada e itens comprados, preencha o **N° OC**,
   veja a barra de liquidação, e o **Concluir aquisição** (ou o bypass, com a matrícula
   autorizada).
4. **Retornar / Cancelar** continuam na Industrial.

---

## 5. A confirmar

- **Uploads de anexos (DXF, PDF, BOM, imagem)** continuam na **Automação** — tratei-os
  como entregas do projetista, não como "cortes". Se esses uploads também forem da
  Industrial, me avise que movo.
- **Sem controle de acesso** por perfil: como não há SSO ativo, as duas telas continuam
  abertas a todos. A separação é por **tela/rótulo**, não por permissão — quando o SSO
  voltar, dá para restringir cada tela ao seu perfil.
