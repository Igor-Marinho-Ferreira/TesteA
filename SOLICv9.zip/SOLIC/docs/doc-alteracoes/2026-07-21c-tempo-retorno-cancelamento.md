# Alterações — 21/07/2026 (3ª rodada)

Continuação do módulo de desenvolvimento. As rodadas anteriores
(`2026-07-21-...` e `2026-07-21b-...`) já estão em produção; **este documento cobre só o
que veio depois.**

> **Premissa:** segue valendo — só soma, não refatora. Segurança geral (autenticação,
> SQL injection, XSS) continua em aberto e não foi tocada.

Quatro coisas, todas interligadas:

1. **Cronômetro com pausa** para Corte e Execução.
2. **Cancelar SL** ao escolher CANCELADO no corte/execução (pede motivo).
3. **Botão "Retornar SL"** nas etapas de aquisição/corte/execução.
4. **Travamento**: ao passar de uma etapa para a outra, a anterior não pode mais ser alterada.

---

## ⚠️ Passo obrigatório

Rode a migration **uma vez**:

```
database/migrations/2026-07-21c-tempo-corte-execucao.sql
```

Só `ALTER TABLE` / `ADD COLUMN`. Adiciona em `bd_device_request.fila`, para corte e exec:

| Coluna | Uso |
|---|---|
| `{etapa}_inicio` | 1ª vez que entrou em contagem |
| `{etapa}_fim` | quando finalizou |
| `{etapa}_tempo` | tempo acumulado em **segundos** (só períodos ativos) |
| `{etapa}_retomado_em` | início do intervalo ativo atual (NULL = pausado) |

Antes de rodar **nada quebra**: o cronômetro não aparece e o resto funciona normalmente.

---

## 1. Arquivos

### Criados

| Arquivo | Função |
|---|---|
| `database/migrations/2026-07-21c-tempo-corte-execucao.sql` | Colunas de tempo |
| `src/app/views/modals/motivoEtapa/modal.php` | Modal única de motivo (retornar/cancelar) |

### Alterados

| Arquivo | O que mudou |
|---|---|
| `src/app/controllers/DesenvolvimentoController.php` | Cronômetro; travamento; `retornarSl`; `cancelarSl`; `modalMotivoEtapa` |
| `src/app/views/desenvolvimento/desenvolvimentoForm.php` | Botão Retornar SL; exibição do tempo |
| `public/js/liberacaoAquisicao.js` | Interceptação de CANCELADO; modal de motivo |
| `src/routes/routes.php` | 3 rotas novas |

---

## 2. Cronômetro com pausa (Corte / Execução)

### Regra

| Status | Efeito no tempo |
|---|---|
| ANDAMENTO, TERCEIRIZADO | **conta** (inicia/retoma) |
| PARADO, AGUARDANDO | **pausa** (acumula o intervalo e para) |
| FINALIZADO | fecha o **fim** (acumula o último intervalo) |
| CANCELADO | não mexe no tempo (cancela a SL — ver §3) |

É **tempo decorrido real com pausa**: soma só os períodos em andamento/terceirizado. O
`{etapa}_tempo` acumula segundos; `{etapa}_retomado_em` marca o intervalo ativo em curso.

A conta roda no servidor a cada troca de status, em `carimbarTempoCorteExec()`, logo depois
do `atualizaStatus` que já existia (mesmo lugar onde conceito/detalhamento carimbam).

**Validação do acumulador** (portei a lógica e rodei 4 cenários):

| Cenário | Esperado | Resultado |
|---|---|---|
| ativo → pausa → ativo → finaliza | 150s | 150s ✅ |
| ANDAMENTO → TERCEIRIZADO contínuo → pausa | 100s | 100s ✅ |
| finaliza → reabre → finaliza (continua somando) | 150s | 150s ✅ |
| AGUARDANDO também pausa | 100s | 100s ✅ |

### Exibição

Aparece um cronômetro abaixo do select de Corte e de Execução, com ✓ verde e um `•` quando
está **rodando**. O número é renderizado no servidor — **atualiza a cada reload**, não fica
correndo sozinho na tela (não achei que valesse um ticker em JS; se quiserem, é fácil somar).

> **Nota:** o cálculo de dias úteis usado em conceito/detalhamento **não** foi mexido. Este
> é um modelo separado — é o único que respeita o "para de contar" que vocês pediram.

---

## 3. Cancelar SL (via CANCELADO)

Escolher **CANCELADO** no select de Corte ou Execução abre a modal de motivo. Ao confirmar,
espelha o cancelamento que já existia: **todas** as etapas viram CANCELADO e o motivo vai
para o histórico (chatbox).

- Fluxo: select → CANCELADO → JS reverte a seleção e abre a modal → `POST .../cancelar/{ref}`
- Servidor: `cancelarSl()` põe conceito/detalhe/liberação/aquisição/corte/exec/tryout em
  CANCELADO + histórico com o motivo.
- Depois de cancelada, o rodapé mostra **"SL Cancelada"** e os selects travam.

---

## 4. Retornar SL

Botão **"Retornar SL"** que aparece nas etapas de aquisição/corte/execução (ou seja, quando
a SL já está liberada e não cancelada). Ocupa o mesmo lugar do antigo aviso "SL Liberada".

Ao clicar → modal de motivo → `POST .../retornar/{ref}`:

- `liberacao_status = REVISAR` (entrou como opção nova da liberação)
- `aquisicao/corte/exec` voltam para PENDENTE/PARADO — o fluxo **reabre na liberação**
- **OC / pedido / liquidação dos itens são preservados** (decisão de vocês)
- o cronômetro de corte/exec é **zerado** (recontagem no novo ciclo)
- o motivo vai para o histórico

Depois do retorno, o rodapé volta a mostrar **"Liberar SL"** e a etapa Liberação fica
editável como REVISAR.

A modal de motivo (`modals/motivoEtapa/modal.php`) é **uma só**, parametrizada por
`?acao=retornar|cancelar` — muda título, cor, texto e a rota de POST.

---

## 5. Travamento ("ao passar de etapa a outra não é possível alterar")

Cada etapa trava assim que a **seguinte** começa a andar (sai do placeholder inicial
PENDENTE/PARADO). O único caminho de volta é o **Retornar SL**.

| Etapa | Fica editável enquanto… |
|---|---|
| Liberação | não está OK (trava em OK; volta via Retornar) |
| Aquisição | liberação OK e ainda não concluída |
| **Corte** | aquisição OK **e a execução ainda não começou** |
| **Execução** | corte concluído **e o tryout ainda não começou** |

Pausar a própria etapa (ex.: Corte → PARADO) **não** trava nada — só o avanço para a etapa
seguinte trava a anterior. Conceito/Detalhamento não foram tocados.

---

## 6. Rotas novas

| Método | Rota | Ação |
|---|---|---|
| GET | `/dispositivos/desenvolvimento/motivo-etapa/{ref}` | `modalMotivoEtapa` (?acao=) |
| POST | `/dispositivos/desenvolvimento/retornar/{ref}` | `retornarSl` |
| POST | `/dispositivos/desenvolvimento/cancelar/{ref}` | `cancelarSl` |

Registradas no fim do arquivo; não colidem com as dinâmicas.

---

## 7. Cores

`AGUARDANDO` e `ANDAMENTO` já haviam entrado no mapa de cores na 2ª rodada; nada novo aqui.

---

## 8. Como testar

1. **Cronômetro:** SL com aquisição OK. Corte → ANDAMENTO (aparece o `•` verde correndo).
   Recarregue depois de um tempo: o valor subiu. Corte → PARADO: para. Corte → ANDAMENTO de
   novo e → FINALIZADO: o tempo é a soma só dos períodos ativos.
2. **Execução:** só habilita com o corte em FINALIZADO/TERCEIRIZADO. Mesma cronometragem.
3. **Travamento:** com a execução em ANDAMENTO, o select do Corte deve estar **travado**.
4. **Cancelar:** Corte/Exec → CANCELADO → modal pede motivo → confirma → tudo CANCELADO,
   rodapé "SL Cancelada", motivo no histórico.
5. **Retornar SL:** botão no rodapé → motivo → confirma → liberação vira REVISAR,
   aquisição/corte/exec reabrem, OC preservada, cronômetro zerado, motivo no histórico.

---

## 9. O que NÃO foi feito

- Segurança geral (idem rodadas anteriores).
- Tryout continua sem cronômetro e sem edição (fora do pedido).
- O cronômetro na tela não "tica" sozinho — atualiza no reload. Dá para somar um ticker em
  JS depois, se quiserem.
- Retornar SL zera o cronômetro de corte/exec; se preferirem **preservar** o tempo já
  contado ao retornar, é um ajuste de uma linha — me avisem.
