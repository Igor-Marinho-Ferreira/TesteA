# Alterações — 21/07/2026

Responsividade, correção do salto da tabela, fluxo de **Liberar SL** e módulo de **Aquisição**.

> **Premissa desta entrega:** nada do que já existia foi refatorado. Toda mudança é aditiva
> ou pontual. Os problemas de segurança levantados na análise anterior (autenticação,
> SQL injection, XSS) **não** foram tratados aqui — continuam em aberto.

---

## ⚠️ Três passos antes de usar a Aquisição

### 1. Rodar a migration (uma vez)

```
database/migrations/2026-07-21-aquisicao-itens-comprados.sql
```

Só `ALTER TABLE` / `ADD COLUMN`. Adiciona em
`bd_device_request.solicitacao_itens_comprados`:

| Coluna | Origem |
|---|---|
| `n_oc` | **digitado** pelo comprador |
| `pedido` | preenchido pela **rotina do Logix** |
| `liquidado` | preenchido pela **rotina do Logix** |
| `liquidado_em` | data da primeira liquidação |
| `sincronizado_em` | data/hora da última consulta ao Logix |
| `updated_by` / `updated_at` | auditoria (`LOGIX` quando veio da rotina) |

O bloco de *rollback* está comentado no final do `.sql`.

### 2. Preencher a consulta do Logix

Abra `src/app/services/LogixOrdemCompraService.php` e preencha a constante
`SQL_CONSULTA_OC`. **É o único ponto do sistema que precisa ser ajustado.**

### 3. Definir o token do cron no `.env`

```
APP_CRON_TOKEN=algum-valor-secreto-longo
```

Sem ele a rotina recusa com `503` — de propósito, ver a seção 7.

> Enquanto qualquer um dos três estiver pendente **o sistema não quebra**: a tela avisa,
> os campos ficam somente leitura e os endpoints devolvem `503` explicando o que falta.

---

## 1. Arquivos

### Criados

| Arquivo | Função |
|---|---|
| `public/css/responsivo.css` | Toda a responsividade + correção do salto da tabela |
| `public/js/liberacaoAquisicao.js` | Modal de liberação, edição inline da aquisição |
| `src/app/views/modals/liberacao/modal.php` | Modal "Liberar SL" |
| `database/migrations/2026-07-21-aquisicao-itens-comprados.sql` | Colunas de OC/pedido/liquidação |
| `docs/doc-alteracoes/2026-07-21-...md` | Este documento |

### Alterados

| Arquivo | O que mudou |
|---|---|
| `src/app/views/templates/base.php` | +1 `<link>` para `responsivo.css` (carrega por último) |
| `src/app/views/desenvolvimento/listaDesenvolvimento.php` | `dt-loading-shell` no wrapper + `data-label` nos `<td>` |
| `public/js/listaProjetos.js` | Marca/libera o estado de carregamento da tabela |
| `src/app/views/desenvolvimento/desenvolvimentoForm.php` | Botão Liberar SL + tabela de aquisição editável |
| `src/app/controllers/DesenvolvimentoController.php` | 5 ações novas + `entrada()` + `edit` das etapas |
| `src/app/database/entities/SolicitacaoItemComprado.php` | Métodos de liquidação (era uma classe vazia) |
| `src/routes/routes.php` | 5 rotas novas no final |

---

## 2. Correção do salto da tabela

### Causa

A tabela era renderizada em HTML puro (largura 100%, altura livre) e **só depois** o
DataTables inicializava — `initTable()` é `async` e espera um `fetch` do arquivo de
tradução. Ao inicializar, o DT injeta o wrapper, liga o `scrollX` e reescreve a largura
das 16 colunas de uma vez.

Durante essa janela a tabela estava **visível e clicável**, mas ainda na posição errada.

### Medição

Reproduzido em ambiente isolado com os mesmos assets do projeto
(`public/js/dt/jquery.js` + `dt.js`), 40 linhas, mesma config de colunas:

| | antes | depois |
|---|---|---|
| tabela visível durante a carga | `true` | `false` |
| linha clicável durante a carga | `true` | `false` |
| topo da 6ª linha (início → fim) | 656px → 338px | 656px → 338px |
| **deslocamento com a tabela visível** | **318px** | **0px** |

A 6ª linha subia 318px — o suficiente para o clique cair 2–3 linhas abaixo do pretendido.

### Solução

1. `.dt-loading-shell` reserva `min-height: 460px`, então o conteúdo **abaixo** da tabela
   não se mexe.
2. A tabela recebe `visibility: hidden` enquanto o DT monta. Foi usado `visibility`
   e **não** `display: none` de propósito: o DataTables precisa medir a largura real das
   colunas, o que é impossível com o elemento fora do fluxo.
3. Um esqueleto ("Carregando solicitações...") ocupa o espaço.
4. A tabela só é revelada depois que o navegador pintou o layout final.

**Por que não estraga se o JS falhar:** a classe `.dt-loading` é adicionada *pelo próprio
JS*, de forma síncrona, e removida num `finally`. Se o script não carregar ou lançar erro,
a classe nunca entra e a tabela aparece normalmente. Não existe cenário em que o usuário
fique com a tela vazia.

**Aba em segundo plano:** `requestAnimationFrame` **não dispara** com
`document.visibilityState === "hidden"`. Sem tratamento, abrir a lista em nova aba
(clique do meio) deixaria a tabela invisível até o usuário focar a aba. Por isso
`aguardarPintura()` corre o rAF contra um limite de 600 ms — o que vier primeiro.
Isso foi testado com a aba oculta e confirmado.

---

## 3. Responsividade

Tudo em `public/css/responsivo.css`, carregado **por último** justamente para conseguir
sobrescrever alturas/larguras fixas sem editar os CSS existentes.

| Bloco | O que resolve |
|---|---|
| Grid/containers | `container` até 1600px em telas grandes; padding e logo no mobile; `overflow-x` nunca no `<body>` |
| Tabela `#list` | Scroll horizontal com a **1ª coluna (N° SL) fixa**; busca e paginação do DT empilhadas no mobile |
| Tabelas comuns | Viram card no mobile usando o `data-label` (CSS que já existia mas nunca recebeu os atributos) |
| Etapas | 2 colunas abaixo de 575px; sem `hover` preso em toque |
| Histórico | Remove o `max-height: 590px` fixo que sobrava/faltava conforme a tela |
| Colunas | `border-start` vira `border-top` ao empilhar |
| Modais | 96vw, rodapé empilhado, botões 100% |
| Toque | Alvos ≥ 42px; campos com 16px para não disparar o zoom do iOS; `:focus-visible` |

### Sobre o `#list` e o modo card

`table-responsive.css` transforma **qualquer** `<table>` em cards empilhados abaixo de
800px. Isso quebra o DataTables, que controla o próprio layout e precisa do `thead`
visível. Para uma grade de 16 colunas o padrão correto é scroll horizontal com a primeira
coluna fixa — então o modo card foi **desligado só para o `#list`**. As demais tabelas
continuam virando card normalmente, e agora com os rótulos corretos.

---

## 4. Liberar SL

### Antes

```html
<button type="submit" class="btn btn-company btn-sm w-100">Liberar SL</button>
```

Um `<button type="submit">` **fora de qualquer `<form>`** — não fazia absolutamente nada.

### Agora

1. O botão abre a modal `modals/liberacao/modal.php`.
2. A modal mostra para onde a SL vai (aquisição ou corte) e exige a consideração.
3. Ao confirmar (`POST .../liberacao/{ref}`):
   - `liberacao_status = 'OK'` + `liberacao_data`
   - o texto digitado vai para a tabela `historico` — **o chatbox**
   - grava um segundo registro automático com o roteamento, para deixar a decisão auditável

### Também pelo select

A etapa "Liberação" tinha `'edit' => false` — o select era permanentemente desabilitado.
Agora fica habilitado quando Conceito e Detalhamento estão OK. Escolher **OK** no select
abre **a mesma modal** — não existe caminho que grave OK sem a consideração.

A interceptação é feita embrulhando `gerenciarMudancaStatus`:

```js
const gerenciarOriginal = window.gerenciarMudancaStatus;

window.gerenciarMudancaStatus = function (selectElement) {
    // ... casos de Liberação/Aquisição ...
    if (typeof gerenciarOriginal === "function") {
        gerenciarOriginal(selectElement);   // resto segue intacto
    }
};
```

`desenvolvimentoProj.js` **não foi tocado**. Por isso `liberacaoAquisicao.js` precisa
carregar **depois** dele — a ordem no array `js` da view importa.

---

## 5. Aquisição

### Regra implementada

> SE TIVER ITENS COMPRADOS → VAI PARA AQUISIÇÃO.
> AQUISIÇÃO COLOCA O N° OC E TEM QUE ESTAR TUDO LIQUIDADO PARA OK.

Ao liberar a SL:

| Situação | Resultado |
|---|---|
| Tem itens comprados | `aquisicao_status = 'PENDENTE'` — vai para o comprador |
| Não tem | `aquisicao_status = 'OK'` + `corte_status = 'PARADO'` — pula a aquisição |

### Divisão de responsabilidade

| Campo | Quem preenche |
|---|---|
| **N° OC** | Pessoa, digitando na tela |
| **Pedido** | Rotina do Logix |
| **Status (liquidado)** | Rotina do Logix |
| **Concluir aquisição** | Pessoa, clicando |

A tabela já tinha as colunas `N° OC`, `STATUS` e `PEDIDO`, mas com `--` e `Pendente`
fixos no HTML. Agora só o **N° OC** é editável; pedido e status são somente leitura,
porque quem manda neles é o Logix. Enquanto a rotina não passa, o pedido mostra
*"aguardando Logix"*. O `title` do selo mostra a data da última consulta.

**Trocar a OC de um item zera o pedido e a liquidação** — eles pertenciam à OC anterior.
A rotina reconsulta no ciclo seguinte.

### A rotina (cron)

```
GET /dispositivos/desenvolvimento/aquisicao/sincronizar-logix?token=SEU_TOKEN
```

Crontab sugerido (a cada 15 minutos):

```cron
*/15 * * * * curl -fsS "https://SEU_HOST/dispositivos/desenvolvimento/aquisicao/sincronizar-logix?token=SEU_TOKEN" > /dev/null
```

O que ela faz:

1. Busca os itens com OC preenchida, ainda não liquidados, de SLs cuja aquisição não foi
   concluída (limite de 500 por execução).
2. Agrupa as OCs distintas e faz **uma única** consulta ao Logix para o lote.
3. Grava `pedido`, `liquidado` e `sincronizado_em` em cada item.
4. Quando a última pendência de uma SL cai, registra no histórico que ela está pronta.

**O que ela NÃO faz:** mudar `aquisicao_status` para OK. Conforme combinado, isso continua
sendo de uma pessoa — a rotina só habilita o botão.

Retorna JSON com `consultados`, `ocsConsultadas`, `atualizados`, `naoEncontrados` e
`slsProntas`, para o log do cron.

Falha no Logix (rede, banco fora) **não derruba nada**: é registrada em `error_log` e a
rotina termina sem marcar item algum. OC que o Logix não devolveu só recebe
`sincronizado_em` — nunca é presumida como liquidada.

### Validações (todas no servidor, não só na tela)

| Regra | Onde |
|---|---|
| Não conclui com item pendente | `concluirAquisicao()` → 422 |
| Não conclui SL sem itens | `concluirAquisicao()` → 422 |
| Não libera SL já liberada | `storeLiberacao()` → 409 |
| Não libera sem consideração | `storeLiberacao()` → 422 |
| Migration ausente | 503 com a instrução |
| Query do Logix não preenchida | 503 com a instrução |
| Token do cron ausente/errado | 503 / 403 |

O botão desabilitado é conveniência; quem decide é o servidor.

**Ponto importante:** se a migration não rodou, `resumoLiquidacao()` devolve
`liquidados = 0` e `pendentes = total`. Ou seja, na dúvida ele **trava** a conclusão em
vez de liberar por engano. O mesmo vale para a rotina: sem a query preenchida ela não
roda, em vez de rodar vazia e parecer que "não havia nada liquidado".

---

## 6. Rotas novas

| Método | Rota | Ação |
|---|---|---|
| GET | `/dispositivos/desenvolvimento/liberacao/{ref}` | `modalLiberacao` |
| POST | `/dispositivos/desenvolvimento/liberacao/{ref}` | `storeLiberacao` |
| POST | `/dispositivos/desenvolvimento/aquisicao/item/{id}/store` | `storeItemAquisicao` (só a OC) |
| GET | `/dispositivos/desenvolvimento/aquisicao/{ref}/resumo` | `resumoAquisicao` |
| POST | `/dispositivos/desenvolvimento/aquisicao/{ref}/concluir` | `concluirAquisicao` |
| GET | `/dispositivos/desenvolvimento/aquisicao/sincronizar-logix` | `sincronizarLogix` (cron) |

Verificado que nenhuma colide com as rotas dinâmicas já registradas — o `Router` devolve
a **primeira** que casar por regex, e as novas foram registradas no fim do arquivo.
A rota do cron é estática, e o `simpleRouter()` (busca exata) sempre resolve antes do
`dynamicRouter()`, então ela não é capturada por `aquisicao/{ref}/...`.

### Conexão com o Logix

`Database::setConfig()` **não tinha** mapeamento para o Informix: o `.env` já trazia
`DB_FILE_INFORMIX` e o `dns()` já sabia montar a DSN `informix:`, mas nenhum `$dbType`
apontava para o arquivo. Foi somado um branch `logix` — mesmo padrão do `senior`, que já
existia. Nenhum comportamento anterior mudou.

---

## 7. Detalhe que quase virou bug

`src\support\Request::input()` lê **apenas `$_POST`**:

```php
public static function input(string $name): string|null|array
{
    return $_POST[$name] ?? null;   // não faz parse de corpo JSON
}
```

O JS novo envia `Content-Type: application/json`, e nesse caso o PHP **não** popula
`$_POST` — todo campo chegaria `null` e a liberação falharia sempre com "Descreva a
liberação".

Existem duas classes `Request` no projeto: `src\support\Request` (só `$_POST`) e
`src\app\requests\Request` (essa **faz** parse de JSON — é o que o `atualizaStatus` já
usava). Para não mexer em nenhuma das duas, foi adicionado um helper privado no
controller, `entrada()`, que aceita os dois formatos.

---

## 7b. Por que a rotina do cron tem token

Todo o resto do sistema está sem autenticação (ver a análise anterior), e o combinado foi
**não** mexer nisso agora. Mas a rota do cron é **código novo que escreve no banco** —
deixá-la aberta seria abrir um buraco novo, não conviver com um antigo. Por isso ela exige
`APP_CRON_TOKEN`, comparado com `hash_equals`.

A escolha é falhar fechado: sem o token definido no `.env`, a rota recusa com `503` em vez
de liberar. É a única regra de segurança adicionada nesta entrega, e vale só para ela.

---

## 8. O que NÃO foi feito

- **Nada** dos problemas de segurança do relatório anterior (autenticação inexistente,
  SQL injection em `Acompanhamento`, XSS nas views, CSRF, `.env` versionado).
- Os `<td>` de `listaDesenvolvimento.php` continuam **sem escape** — só ganharam
  `data-label`. Escapar ali mudaria comportamento existente, o que estava fora do escopo
  combinado.
- A **query do Logix não foi escrita** — `SQL_CONSULTA_OC` está vazia, aguardando os nomes
  reais de tabela e campo. Toda a mecânica em volta (agendamento, lote, gravação,
  histórico, tela, tratamento de erro) está pronta e testada quanto a sintaxe.
- Não há botão de consulta manual na tela: por decisão, a rotina roda **só** por cron.
- A rotina **não** conclui a aquisição sozinha, também por decisão.

---

## 9. Como testar

1. Rode a migration.
2. **Tabela:** abra a lista de desenvolvimento e recarregue algumas vezes. A tabela deve
   aparecer já montada, sem encolher. Teste também abrindo em nova aba pelo clique do meio.
3. **Responsivo:** DevTools em 375px, 768px e 1024px. A página nunca deve rolar na
   horizontal — só a tabela, por dentro.
4. **Liberar SL:** numa SL com Conceito e Detalhamento OK, clique em *Liberar SL*, digite
   algo e confirme. Verifique o texto no histórico e o status em OK. Repita pelo select da
   etapa "Liberação" — deve abrir a mesma modal.
5. **Aquisição com itens:** confirme que foi para PENDENTE. Digite uma OC num item — o
   pedido deve mostrar *"aguardando Logix"*. Tente concluir com item pendente: deve recusar.
6. **Aquisição sem itens:** libere uma SL sem itens comprados; aquisição deve ir direto
   para OK e o corte abrir em PARADO.
7. **Rotina do Logix**, depois de preencher `SQL_CONSULTA_OC` e o `APP_CRON_TOKEN`:
   ```bash
   # sem token -> 403
   curl -i "https://SEU_HOST/dispositivos/desenvolvimento/aquisicao/sincronizar-logix"

   # com token -> JSON com o resumo
   curl -s "https://SEU_HOST/dispositivos/desenvolvimento/aquisicao/sincronizar-logix?token=SEU_TOKEN"
   ```
   Rode com uma OC que você sabe estar liquidada no Logix e confira: `pedido` preenchido,
   selo em *Liquidado*, e o aviso no histórico quando a SL fecha. Só então agende no cron.
