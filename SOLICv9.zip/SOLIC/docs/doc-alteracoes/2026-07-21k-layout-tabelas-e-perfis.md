# Alterações — 21/07/2026 (11ª rodada)

Melhorias de **layout de tabelas** + **código do item no cálculo de peso de
perfis**.

> ⚠️ **Sem migration.** Nada de banco novo — tudo view/CSS/JS.

---

## 1. Perfis — código do item + lista acumuladora

Na tela **Cálculo de Peso › Perfis** (`calculoPerfis`):

- Novo campo **Código do item** na calculadora.
- Novo botão **Adicionar**: joga o cálculo atual numa **lista** abaixo, com as
  colunas **Código do item · Perfil · Comp (mm) · Qtde · kg/m · Peso unit ·
  Peso total**, e um **peso total geral** somando tudo.
- Cada linha tem **remover** (×); o total recalcula.
- **Enter** em qualquer campo adiciona; após adicionar, o código é limpo e o foco
  volta para o próximo item.

Tudo no navegador — **não grava no banco** (é uma calculadora/lista de apoio).

**Arquivos:** `src/app/views/cortes/calculoPerfis.php`, `public/js/calculoPerfis.js`.

---

## 2. Carregamento das listas (salto ao abrir)

O "pulo" da tabela na carga (que induz clique errado) tinha um fix por um
**esqueleto** (`.dt-loading-shell`) que escondia a tabela até o DataTables montar
— mas o CSS só escondia a tabela de id `#list`. As listas com **outro id**
(Industrial `#listIndustrial`, Controle de Cortes) tinham o esqueleto mas
**continuavam saltando**.

Correções:

- **CSS generalizado** (`public/css/responsivo.css`): passa a esconder **qualquer
  `table`** e o wrapper `.dt-container` dentro do esqueleto, não só `#list`.
  Isso conserta de uma vez **Lista Industrial** e **Controle de Cortes**.
- **Acompanhar Solicitação de Projetos** (`listaSL.php` + `acompanhamento.js`)
  **não tinha** o esqueleto: agora tem — a tabela é envolvida em
  `.table-responsive.dt-loading-shell` e o JS marca/solta o "carregando",
  espera a pintura (rAF com limite de tempo, que também cobre aba em 2º plano) e
  reajusta as colunas.
- De quebra, os handlers de botão e o `select` de solicitante no
  `acompanhamento.js` ganharam **guardas de nulo** (antes podiam quebrar o script
  numa tela sem esses elementos).

**Telas cobertas:** Acompanhar Solicitação de Projetos, Lista de Solicitações de
Projetos, Lista Industrial - Corte e Execução, Controle de Corte de Peças.

**Arquivos:** `public/css/responsivo.css`, `src/app/views/solicitacao/listaSL.php`,
`public/js/acompanhamento.js`.

---

## 3. Grids desorganizando no minimizar/maximizar

Em **Reservas - Cálculo de Peso** e **Itens Comprados por Descrição** os grids
"desorganizavam" ao redimensionar e só voltavam repetindo o processo. Causa: o
CSS global define `table { table-layout: fixed }`, que nessas tabelas largas
recalcula as colunas de forma instável.

Correção (`public/css/cortes.css`): as tabelas consolidadas (`.tabela-planos`)
voltam ao **`table-layout: auto`** — as colunas seguem o conteúdo e o
`.table-responsive` cuida da rolagem horizontal de forma **determinística**
(não “desorganiza” mais no resize). Cabeçalho não quebra (define a largura
mínima), corpo pode quebrar (`word-break`).

---

## 4. Tabelas excedendo a largura (rolagem horizontal)

As listas largas (ex.: Acompanhar, com muitas etapas) continuam com rolagem
horizontal — é esperado para tanta coluna. Se quiser, dá para **enxugar as
colunas** mostrando só as que a equipe usa no dia a dia; como não estava claro
quais tirar, deixei tudo e o resto do layout mais estável. É só dizer quais
colunas manter em cada tela.

---

## Como testar

1. **Perfis:** preencha código + perfil + comprimento + qtde → **Adicionar**;
   confira a linha e o **peso total geral**; remova uma linha e veja o total
   recalcular.
2. **Carga das listas:** abra Acompanhar / Lista de Projetos / Lista Industrial /
   Controle de Cortes — a tabela deve aparecer **já montada** (sem pulo), com um
   "Carregando..." breve.
3. **Resize:** em Cálculo de Peso e Itens por Descrição, minimize/maximize e gire
   a janela — os grids devem se manter organizados sem precisar repetir.
