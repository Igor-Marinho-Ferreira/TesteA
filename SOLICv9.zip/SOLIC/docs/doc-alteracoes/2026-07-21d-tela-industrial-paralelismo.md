# Alterações — 21/07/2026 (4ª rodada)

Corte e Execução saem da automação e ganham tela própria (**Industrial**); as três
etapas finais passam a correr em **paralelo**; o cronômetro se espalha para as demais
etapas.

> **Premissa:** só soma, não refatora. Segurança geral (autenticação, SQL injection, XSS)
> continua em aberto.

> ⚠️ **Esta rodada REVERTE parte da 3ª.** O travamento sequencial
> (corte trava quando a execução começa) **deixou de existir** — ver §4.

---

## ⚠️ Passo obrigatório

```
database/migrations/2026-07-21d-industrial-cronometro.sql
```

Só `ALTER TABLE` / `ADD COLUMN`:

| Coluna | Uso |
|---|---|
| `data_entrega` | campo novo do industrial |
| `aquisicao_inicio/_fim/_tempo/_retomado_em` | cronômetro da aquisição |
| `tryout_inicio/_fim/_tempo/_retomado_em` | cronômetro do tryout |

Antes de rodar **nada quebra**: a etapa sem colunas simplesmente não mostra cronômetro,
e a coluna "Data Entrega" aparece vazia.

---

## 1. Arquivos

### Criados

| Arquivo | Função |
|---|---|
| `src/app/controllers/IndustrialController.php` | Lista + detalhe + campos do industrial |
| `src/app/views/industrial/listaIndustrial.php` | Lista com os campos das imagens |
| `src/app/views/industrial/industrialForm.php` | Tela de detalhe (espelha a de automação) |
| `src/support/Cronometro.php` | Cálculo de exibição do tempo (usado pelas duas telas) |
| `public/js/listaIndustrial.js` | DataTable da lista (com a correção do salto) |
| `public/js/industrialForm.js` | Salva os campos do industrial |
| `database/migrations/2026-07-21d-...sql` | Colunas novas |

### Alterados

| Arquivo | O que mudou |
|---|---|
| `src/app/controllers/DesenvolvimentoController.php` | Cronômetro generalizado; corte/exec travados; paralelismo |
| `src/app/database/entities/Acompanhamento.php` | `getParaIndustrial()`, `equipesDistintas()` |
| `src/app/controllers/SolicitacaoController.php` | Chatbox volta para a tela industrial (`tipo=industrial`) |
| `src/app/views/desenvolvimento/desenvolvimentoForm.php` | Tooltip do cronômetro |
| `src/app/views/menus/menu.php` | Card novo "LISTA INDUSTRIAL" |
| `src/routes/routes.php` | 3 rotas novas |

---

## 2. Tela Industrial

Estrutura **igual à de automação**: lista → clica na SL → tela de detalhe.

### Lista (`/dispositivos/industrial`)

Colunas, conforme as imagens — o mapeamento para o banco (todas já existiam, exceto
`data_entrega`):

| Coluna | Campo |
|---|---|
| SL | `ref` |
| Descrição | `descricao` |
| Solicitante | `solicitante` |
| COD Z | `cod_z` |
| **N° SFP / CC** | `conta` |
| Vagão | `vagao` |
| **Status** | *derivado* (ver abaixo) |
| **# Pasta** | `n_pasta` |
| **Data Entrega** | `data_entrega` *(coluna nova)* |
| **Natureza** | `natureza` |
| **Descrição do Serviço** | `descricaoservico` |
| Corte / Execução | `corte_status` / `exec_status` |
| **EQUIPE** | `equipeei` |
| **Setor** | `setor_pendencia` |

A lista traz **só as SLs já liberadas** — que são as que o industrial pode tocar. Filtros
por situação, solicitante e equipe.

**Status** é derivado (não existe coluna): CANCELADO → FINALIZADO (corte e exec
concluídos) → ANDAMENTO → AGUARDANDO → PARADO.

### Detalhe (`/dispositivos/industrial/info/{ref}`)

- Cabeçalho com os dados da SL (só leitura)
- Barra de progresso com **todas** as etapas e seus cronômetros. As da automação
  (conceito, detalhe, liberação, aquisição) aparecem **só para leitura**, como contexto;
  **Corte, Execução e Tryout** são editáveis
- Campos do industrial editáveis: # Pasta, Data de Entrega, Equipe, Setor, Natureza,
  Descrição do Serviço
- Datas de início/fim de corte e execução
- **Chatbox** (mesmo histórico da SL)
- **Retornar SL** (mesma modal de motivo da 3ª rodada)

CANCELADO no corte/execução continua abrindo a modal e cancelando a SL inteira.

---

## 3. Corte e Execução na automação

Continuam **visíveis** na barra de progresso da tela de desenvolvimento, para a automação
acompanhar o andamento — mas **travados** (`edit => false`). Quem controla é o industrial.

---

## 4. Paralelismo (reverte parte da 3ª rodada)

**Aquisição, Corte e Execução correm em paralelo.** Nenhuma espera a outra terminar; as
três abrem quando a SL é liberada.

Na prática, saíram:

- `corte editável só com aquisição em OK` → agora só depende da **liberação**
- `execução editável só com corte concluído` → agora só depende da **liberação**
- `corte trava quando a execução começa` → **removido**
- `execução trava quando o tryout começa` → **removido**

O que **permanece** da regra "ao passar de etapa a outra não é possível alterar": a parte
sequencial do fluxo (Conceito → Detalhamento → Liberação), onde cada etapa trava ao chegar
em OK. O caminho de volta continua sendo o **Retornar SL**.

---

## 5. Cronômetro nas demais etapas

Conforme decidido: **os dois cálculos convivem, nada foi removido.**

| Etapa | Modelo |
|---|---|
| Corte, Execução | próprio, com pausa (3ª rodada) |
| **Aquisição, Tryout** | próprio, com pausa (**novo**) |
| **Conceito, Detalhamento** | **derivado** — fim menos início das colunas que já existiam, exibido **ao lado** do cálculo de dias úteis (`tempo_modelo`/`tempo_det`), que segue **intacto** |
| Liberação | sem cronômetro (é uma aprovação pontual, não tem estado "em andamento") |

**Aquisição:** o relógio abre quando a liberação a coloca em PENDENTE e fecha no OK —
inclusive no bypass de teste. Conta em PENDENTE/REALIZADO/TERCEIRIZADO.

**Tryout:** mesmas regras de corte/execução (ANDAMENTO e TERCEIRIZADO contam; PARADO e
AGUARDANDO pausam; FINALIZADO fecha).

A lógica virou uma configuração única (`CRONOMETRO_ETAPAS`) em vez de um `if` por etapa, e
o cálculo de exibição saiu para `src/support/Cronometro.php`, compartilhado pelas duas telas.

O tooltip distingue os dois modelos ("tempo corrido" x "somando os períodos em andamento").

---

## 6. Rotas novas

| Método | Rota | Ação |
|---|---|---|
| GET | `/dispositivos/industrial` | `industrialListaView` |
| GET | `/dispositivos/industrial/info/{ref}` | `industrialInfoView` |
| POST | `/dispositivos/industrial/campos/{ref}` | `salvarCamposIndustrial` |

Verifiquei que nenhuma colide com as dinâmicas já registradas.

Os nomes de coluna gravados em `salvarCamposIndustrial` passam por **whitelist**
(`CAMPOS_EDITAVEIS`) — nome de campo nunca vem do request direto para o SQL. A data de
entrega é validada no formato antes de gravar.

---

## 7. Detalhe de implementação

`use` no meio de uma view do Plates é **erro de parse** — o template roda dentro de um
método. Na `industrialForm.php` o `Cronometro` é chamado pelo nome completo, via closure.

---

## 8. Como testar

1. **Menu:** aparece o card "LISTA INDUSTRIAL - CORTE E EXECUÇÃO".
2. **Lista:** abre com as 15 colunas; só SLs liberadas; filtros funcionam; a tabela não
   salta ao carregar.
3. **Paralelismo:** numa SL liberada com a aquisição ainda PENDENTE, o Corte **já deve
   estar editável** (antes exigia aquisição OK). Ponha a Execução em ANDAMENTO e confirme
   que o Corte **continua editável**.
4. **Cronômetro:** confira o relógio em conceito/detalhe (derivado, ao lado do número de
   dias úteis que já existia), em aquisição (abre na liberação) e em tryout.
5. **Campos do industrial:** preencha pasta/data/equipe/setor e salve; recarregue e
   confirme. Tente sair com alteração pendente — deve avisar.
6. **Automação:** na tela de desenvolvimento, Corte e Execução aparecem mas estão
   **travados**.
7. **Retornar SL / Cancelar:** funcionam igual, agora também a partir da tela industrial.

---

## 9. O que NÃO foi feito

- Segurança geral (idem rodadas anteriores). **A tela industrial não tem controle de
  acesso próprio** — como todo o resto do sistema, hoje qualquer um alcança. O `menu.php`
  já tem a estrutura de `authorization()` comentada; quando o SSO voltar, é ali que entra
  um `$industrial`.
- Liberação ficou sem cronômetro (ver §5). Se quiserem, dá para derivar de
  `detalhamento_fim → liberacao_data`.
- O cronômetro continua sem "ticar" sozinho na tela — atualiza no reload.
- A lista industrial não edita corte/execução inline; a edição é na tela de detalhe,
  como combinado ("igual a gente tem para automação").
