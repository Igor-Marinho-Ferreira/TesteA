# Arquivos alterados — 100% completos (projeto inteiro)

**Todos** os arquivos alterados na sincronização Access ↔ MySQL — Parte 1 (solicitação)
e Parte 2 (desenvolvimento) + storage-mapped + ajustes. Cada arquivo aparece **inteiro**,
pronto pra copiar e colar. Gerado em 21/06/2026.

> VBA também em arquivos avulsos: Lista em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\<modulo>.txt`;
> Solicitação em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\Solicitacao_<modulo>.txt`.

## Índice

**PHP (web):** `src/routes/routes.php`, `src/app/controllers/DesenvolvimentoController.php`, `src/app/controllers/SolicitacaoController.php`, `.env`

**VBA — Lista de Solicitações de Projeto_RevE.xlsm:** `Funcoes`, `frmaut`, `frmsol`, `M_Abre_UF`, `ufdxf`, `uf_lista_dxf`, `frm_bom`

**VBA — Solicitação de Projeto_RevE1.xlsm:** `Funcoes`, `frm_novo`, `frmsol`, `ufValidar`, `Plan1`, `Filtros`

> ⚠️ Os ajustes de caminho (`Plan1`, `Filtros`) são do **ambiente de teste** (em produção voltam pra rede).
> O login foi desativado no teste comentando `frmLogin.Show` no `Workbook_Open` (`EstaPasta_de_trabalho`)
> — **não incluído aqui**, é só teste.

---

# PHP

## `src/routes/routes.php`

```php
<?php

namespace src\routes;

use src\app\controllers\AcompanhamentoController;
use src\app\controllers\UsuarioController;
use src\app\controllers\VagaoController;
use src\app\controllers\EstagioController;
use src\app\controllers\ContaController;
use src\app\controllers\ImportController;
use src\app\controllers\MenuController;
use src\app\controllers\SolicitacaoController;
use src\app\controllers\DesenvolvimentoController;
use src\core\Route;

//Quando tiver {id} -> whereInt(['id'])



//ROTA VBA, PEGANDO OS DADOS ATUALIZADOS
Route::get('/dispositivos/csvAtualizado/fila', SolicitacaoController::class,
    'trataCsv'
)
->name('dispositivos.atualizaCSV.fila');

//ROTA VBA, PEGANDO OS DADOS ATUALIZADOS
Route::get('/dispositivos/csvAtualizado/projetos', SolicitacaoController::class,
    'trataProjetosCSV'
)
->name('dispositivos.atualizaCSV.projeto');



// ROTA PARA IMPORTAR O EXCEL DO CAMINHO DEFINIDO NO .ENV PARA O MYSQL
Route::get(
    '/dispositivos/importar-excel/access',
    ImportController::class,
    'importarExcel'
)
    ->name('dispositivos.importar.excel');



//MENU
Route::get('/dispositivos', MenuController::class, 'menuView')
    ->name('dispositivos.menu');

Route::get('/dispositivos/parametrizacoes', MenuController::class, 'menuParametrizacaoView')
    ->name('dispositivos.menu.parametrizacao');


//SOLICITAÇÃO
Route::get('/dispositivos/solicitacoes', SolicitacaoController::class, 'solicitacaoView')
    ->name('dispositivos.solicitacao');

Route::get('/dispositivos/solicitacao/validacao/{ref}', SolicitacaoController::class, 'modalValidacao')
    ->name('dispositivos.solicitacao.validacao')
    ->whereInt(['ref']);


Route::get('/dispositivos/solicitacao/requisitos/{ref}', SolicitacaoController::class, 'modalRequisitos')
    ->name('dispositivos.solicitacao.requisitos')
    ->whereInt(['ref']);


Route::get('/dispositivos/solicitacao/anexos/{ref}', SolicitacaoController::class, 'modalAnexos')
    ->name('dispositivos.solicitacao.requisitos')
    ->whereInt(['ref']);

Route::get('dispositivos/solicitacao/cancelarSl/{ref}', SolicitacaoController::class, 'modalCancelarSl')
    ->name('dispositivos.solicitacao.cancelarSl')
    ->whereInt(['ref']);

Route::get('/dispositivos/solicitacoes/getProjectInfos', SolicitacaoController::class, 'getProjectInfos')
    ->name('dispositivos.solicitacao.getProjectInfos');

Route::get('dispositivos/solicitacao/getSolicRole', SolicitacaoController::class, 'getRole')
    ->name('dispositivos.solicitacao.getRole');


Route::get('dispositivos/solicitacao/modalConfirmZ', SolicitacaoController::class, 'modalConfirmZ')
    ->name('dispositivos.solicitacao.modalConfirmZ');

Route::post('/dispositivos/solicitacao/store', SolicitacaoController::class, 'storeSolicitacao')
    ->name('dispositivos.solicitacao.store');

//SALVAR VINDO DO VBA/ACCESS — gera o Ref no MySQL (cartório) com GET_LOCK
Route::post('/dispositivos/solicitacao/salvarVba', SolicitacaoController::class, 'salvarVba')
    ->name('dispositivos.solicitacao.salvarVba');

//UPLOAD do PDF da SL vindo do Access (corpo binário cru) -> storage + tabela anexos
Route::post('/dispositivos/solicitacao/uploadAnexoVba', SolicitacaoController::class, 'uploadAnexoVba')
    ->name('dispositivos.solicitacao.uploadAnexoVba');

//COMENTÁRIO (histórico) vindo do Access -> insere 1 linha na tabela historico
Route::post('/dispositivos/solicitacao/comentarVba', SolicitacaoController::class, 'comentarVba')
    ->name('dispositivos.solicitacao.comentarVba');

// Access -> Web: lista de usuários (Solicitantes: email+nome) p/ casar o autor por e-mail.
Route::post('/dispositivos/solicitacao/uploadSolicitantesVba', SolicitacaoController::class, 'uploadSolicitantesVba')
    ->name('dispositivos.solicitacao.uploadSolicitantesVba');

//ATUALIZAR STATUS (cancelar/tryout/validar) vindo do Access -> UPDATE fila
Route::post('/dispositivos/solicitacao/atualizarStatusVba', SolicitacaoController::class, 'atualizarStatusVba')
    ->name('dispositivos.solicitacao.atualizarStatusVba');

//MIGRAÇÃO INICIAL Access -> MySQL (carga única, upsert preservando o Ref)
Route::post('/dispositivos/solicitacao/migrarFila', SolicitacaoController::class, 'migrarFila')
    ->name('dispositivos.solicitacao.migrarFila');


Route::post('/dispositivos/historico/store/{ref}/{tipo}', SolicitacaoController::class, method: 'registraHistorico')
    ->name('dispositivos.historico.store')
    ->whereint(['ref'])
    ->whereString(['tipo']);



//VALIDAÇÃO
Route::post('/dispositivos/solicitacao/validacao/{ref}', SolicitacaoController::class, 'updateSituacao')
    ->name('dispositivos.validacao.store')
    ->whereInt(['ref']);




//DESENVOLVIMENTO
Route::get('/dispositivos/desenvolvimento/lista', DesenvolvimentoController::class, 'desenvolvimentoListaView')
    ->name('dispositivos.desenvolvimento.lista');

Route::post('/dispositivos/desenvolvimento/atualizaStatus', DesenvolvimentoController::class, 'atualizaStatus')
    ->name('dispositivos.desenvolvimento.atualizaStatus');

Route::get('/dispositivos/desenvolvimento/info/{ref}', DesenvolvimentoController::class, 'desenvolvimentoInfoView')
    ->name('dispositivos.desenvolvimento.info')
    ->whereInt(['ref']);

Route::post('/dispositivos/desenvolvimento/storeProjetista/{ref}/{tipo}', DesenvolvimentoController::class, 'storeProjetista')
    ->name('dispositivos.desenvolvimento.storeProjetista')
    ->whereint(['ref'])
    ->whereString(['tipo']);


Route::get('/dispositivos/desenvolvimento/gerarZ/{ref}', DesenvolvimentoController::class, 'gerarZ')
    ->name('dispositivos.desenvolvimento.gerarZ')
    ->whereint(['ref']);

Route::post('/dispositivos/desenvolvimento/associarZ/{ref}', DesenvolvimentoController::class, 'associarZ')
    ->name('dispositivos.desenvolvimento.associarZ')
    ->whereint(['ref']);

Route::get('/dispositivos/desenvolvimento/arquivos-solicitacao/{ref}', DesenvolvimentoController::class, 'arquivosSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivosSolicitacao')
    ->whereint(['ref']);

Route::post('/dispositivos/desenvolvimento/arquivos-solicitacao/{ref}/store', DesenvolvimentoController::class, 'storeArquivosSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivosSolicitacao.store')
    ->whereint(['ref']);

Route::get('/dispositivos/desenvolvimento/arquivo/{id}/visualizar', DesenvolvimentoController::class, 'visualizarArquivoSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivo.visualizar');

Route::get('/dispositivos/desenvolvimento/arquivo/{id}/download', DesenvolvimentoController::class, 'downloadArquivoSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivo.download');
    
Route::post('/dispositivos/desenvolvimento/imagem-projeto/{ref}/store', DesenvolvimentoController::class, 'storeImagemProjeto')
    ->name('dispositivos.desenvolvimento.imagemProjeto.store')
    ->whereint(['ref']);

// Access -> Web: recebe a imagem do projeto (frmaut.btnLoadImage) em binário cru.
// Parâmetros via query string: ?ref=NNN&nome=arquivo.jpg
Route::post('/dispositivos/desenvolvimento/uploadImagemVba', DesenvolvimentoController::class, 'uploadImagemVba')
    ->name('dispositivos.desenvolvimento.uploadImagemVba');

Route::post('/dispositivos/desenvolvimento/dxf/{ref}/store', DesenvolvimentoController::class, 'storePacoteDxf')
    ->name('dispositivos.desenvolvimento.dxf.store')
    ->whereint(['ref']);

// Cria as subpastas do VBA dentro do storage mapeado (APP_STORAGE_MAPPED). Rode 1x.
Route::get('/dispositivos/desenvolvimento/garantirStorageMapeado', DesenvolvimentoController::class, 'garantirStorageMapeado')
    ->name('dispositivos.desenvolvimento.garantirStorageMapeado');

// Access -> Web: recebe os feriados (planilha "Feriados") -> cria/popula a tabela feriados.
Route::post('/dispositivos/desenvolvimento/uploadFeriadosVba', DesenvolvimentoController::class, 'uploadFeriadosVba')
    ->name('dispositivos.desenvolvimento.uploadFeriadosVba');

// Cartório do número de DXF (GET_LOCK) — Access (ufdxf) pede o próximo Controle.
// ?floor=N opcional (MAX(Controle) atual do Access).
Route::get('/dispositivos/desenvolvimento/nextDxf', DesenvolvimentoController::class, 'nextDxf')
    ->name('dispositivos.desenvolvimento.nextDxf');

// Access -> Web: recebe UM pacote DXF (zip) do Access (ufdxf) em binário cru.
// ?ref=NNN&codigo=DX0001&nome=arquivo.zip
Route::post('/dispositivos/desenvolvimento/uploadDxfVba', DesenvolvimentoController::class, 'uploadDxfVba')
    ->name('dispositivos.desenvolvimento.uploadDxfVba');

// Web -> Access (pull): CSV dos pacotes DXF p/ o VBA upsertar em DXF_Control.
Route::get('/dispositivos/csvAtualizado/dxf', DesenvolvimentoController::class, 'csvDxf')
    ->name('dispositivos.atualizaCSV.dxf');

Route::post('/dispositivos/desenvolvimento/pdf/{ref}/store', DesenvolvimentoController::class, 'storeDesenhosPdf')
    ->name('dispositivos.desenvolvimento.pdf.store')
    ->whereint(['ref']);

// Access -> Web: recebe UM desenho PDF (frmaut.btn_pdf_novo) em binário cru.
// Parâmetros via query string: ?ref=NNN&codigo=XXX&nome=arquivo.pdf
Route::post('/dispositivos/desenvolvimento/uploadDesenhoPdfVba', DesenvolvimentoController::class, 'uploadDesenhoPdfVba')
    ->name('dispositivos.desenvolvimento.uploadDesenhoPdfVba');

// Web -> Access (pull): CSV dos desenhos PDF p/ o VBA upsertar em PDF_Control.
Route::get('/dispositivos/csvAtualizado/desenhosPdf', DesenvolvimentoController::class, 'csvDesenhosPdf')
    ->name('dispositivos.atualizaCSV.desenhosPdf');

Route::post('/dispositivos/desenvolvimento/itens-comprados-txt/{ref}/store', DesenvolvimentoController::class, 'storeItensCompradosTxt')
    ->name('dispositivos.desenvolvimento.itensCompradosTxt.store')
    ->whereint(['ref']);

// Access -> Web: recebe os itens de BOM (frm_bom.btnInserir) em lote (form-urlencoded).
Route::post('/dispositivos/desenvolvimento/uploadBomVba', DesenvolvimentoController::class, 'uploadBomVba')
    ->name('dispositivos.desenvolvimento.uploadBomVba');

// Web -> Access (pull): CSV dos itens de BOM p/ o VBA upsertar em BOM_Control.
Route::get('/dispositivos/csvAtualizado/bom', DesenvolvimentoController::class, 'csvBom')
    ->name('dispositivos.atualizaCSV.bom');
    
Route::post('/dispositivos/desenvolvimento/arquivo/{id}/remover', DesenvolvimentoController::class, 'removerArquivoSolicitacao')
    ->name('dispositivos.desenvolvimento.arquivo.remover');    
//ACOMPANHAMENTO SOLICITAÇÕES
Route::get(
    '/dispositivos/acompanhamento',
    AcompanhamentoController::class,
    'acompanhamentoView'
)
    ->name('dispositivos.acompanhamento');

Route::get(
    '/dispositivos/acompanhamento/{ref}',
    AcompanhamentoController::class,
    'acompanhamentoFormSL'
)
    ->name('dispositivos.acompanhamento.sl');


//AUTOCOMPLETE
Route::get('/dispositivos/autocomplete/', AcompanhamentoController::class, 'autocomplete')->name('dispositivos.acompanhamento.autocomplete');



//PARAMETRIZACAO USUARIOS
Route::get('/dispositivos/usuarios', UsuarioController::class, 'cadastroUsuarioView')
    ->name('parametrizacao.usuario');

Route::post('/dispositivos/usuarios/store', UsuarioController::class, 'storeUsuario')
    ->name('parametrizacao.usuario.store');

Route::post('/dispositivos/usuarios/update', UsuarioController::class, 'updateUsuario')
    ->name('parametrizacao.usuario.update');

Route::get('/dispositivos/usuarios/consulta', UsuarioController::class, 'consultaUsuario')
    ->name('parametrizacao.usuario.consulta');

Route::get('/dispositivos/usuarios/modalConfirm/{id}', UsuarioController::class, 'modalConfirm')
    ->name('parametrizacao.modal.usuario.delete')
    ->whereUuid(['id']);

Route::get('/dispositivos/usuarios/modalEdit/{id}', UsuarioController::class, 'modalEdit')
    ->name('parametrizacao.modal.usuario.edit')
    ->whereUuid(['id']);

Route::get('/dispositivos/usuarios/delete/{id}', UsuarioController::class, 'deleteUsuario')
    ->name('parametrizacao.usuario.delete')
    ->whereUuid(['id']);
    


//PARAMETRIZACAO VAGOES E LOTE

Route::get('/dispositivos/vagoes', VagaoController::class, 'cadastroVagaoView')
    ->name('parametrizacao.vagoes');

Route::post('/dispositivos/vagoes/store', VagaoController::class, 'storeVagao')
    ->name('parametrizacao.vagoes.store');

Route::post('/dispositivos/vagoes/update', VagaoController::class, 'updatevagao')
    ->name('parametrizacao.vagoes.update')
    ->whereUuid(['id']);


Route::get('/dispositivos/vagoes/destroy/{id}', VagaoController::class, 'modalConfirm')
    ->name('parametrizacao.modal.vagoes.delete')
    ->whereUuid(['id']);

Route::get('/dispositivos/vagoes/edit/{id}', VagaoController::class, 'modalEdit')
    ->name('parametrizacao.modal.vagoes.edit')
    ->whereUuid(['id']);

Route::get('/dispositivos/vagoes/delete/{id}', VagaoController::class, 'deletevagao')
    ->name('parametrizacao.vagoes.delete')
    ->whereUuid(['id']);



//PARAMETRIZACAO ESTAGIO

Route::get('/dispositivos/estagios', EstagioController::class, 'cadastroEstagioView')
    ->name('parametrizacao.estagios');

Route::post('/dispositivos/estagios/store', EstagioController::class, 'storeEstagio')
    ->name('parametrizacao.estagios.store');

Route::post('/dispositivos/estagios/update', EstagioController::class, 'updateEstagio')
    ->name('parametrizacao.estagios.update')
    ->whereUuid(['id']);


Route::get('/dispositivos/estagios/destroy/{id}', EstagioController::class, 'modalConfirm')
    ->name('parametrizacao.modal.estagios.delete')
    ->whereUuid(['id']);

Route::get('/dispositivos/estagios/edit/{id}', EstagioController::class, 'modalEdit')
    ->name('parametrizacao.modal.estagios.edit')
    ->whereUuid(['id']);

Route::get('/dispositivos/estagios/delete/{id}', EstagioController::class, 'deleteEstagio')
    ->name('parametrizacao.estagios.delete')
    ->whereUuid(['id']);


//PARAMETRIZACAO CONTAS

Route::get('/dispositivos/contas', ContaController::class, 'cadastroContaView')
    ->name('parametrizacao.contas');


Route::get('/dispositivos/contas/getLoteByVagao', ContaController::class, 'getLoteByVagao')
    ->name('parametrizacao.contas.getLote');


Route::get('dispositivos/contas/getDescricaoConta', ContaController::class, 'getDescricaoConta')
    ->name('parametrizacao.contas.getDescricao');

Route::post('/dispositivos/contas/store', ContaController::class, 'storeConta')
    ->name('parametrizacao.contas.store');

Route::post('/dispositivos/contas/update', ContaController::class, 'updateConta')
    ->name('parametrizacao.contas.update')
    ->whereUuid(['id']);


Route::get('/dispositivos/contas/destroy/{id}', ContaController::class, 'modalConfirm')
    ->name('parametrizacao.modal.contas.delete')
    ->whereUuid(['id']);

Route::get('/dispositivos/contas/edit/{id}', ContaController::class, 'modalEdit')
    ->name('parametrizacao.modal.contas.edit')
    ->whereUuid(['id']);

Route::get('/dispositivos/contas/delete/{id}', ContaController::class, 'deleteEstagio')
    ->name('parametrizacao.contas.delete')
    ->whereUuid(['id']);
```

---

## `src/app/controllers/DesenvolvimentoController.php`

```php
<?php

namespace src\app\controllers;

use src\app\database\entities\Acompanhamento;
use src\app\database\entities\Historico;
use src\app\database\entities\Projeto;
use src\app\database\entities\Solicitacao;
use src\app\database\entities\Usuario;
use src\app\database\entities\SolicitacaoAnexoCarga;
use src\app\database\entities\SolicitacaoAnexoArquivo;
use src\app\database\entities\SolicitacaoItemComprado;
use src\app\requests\projetistas\UpdateRequest;
use src\app\requests\projetos\CodigoZRequest;
use src\app\requests\projetos\UpdateStatusRequest;
use src\support\Request;
use src\support\View;
use src\support\Json;

class DesenvolvimentoController
{
    function desenvolvimentoListaView(): View
    {
        $status      = Request::query('status') ?? '';
        $solicitante = Request::query('solicitante') ?? '';
        $projetista  = Request::query('projetista') ?? '';
        $coluna      = Request::query('coluna') ?? '';

        $solicitacoes = Acompanhamento::getAllNaoFinalizadoBySolic($status, $solicitante, $projetista, $coluna);

        foreach ($solicitacoes as $item) {
            $valorLimpo = trim(str_ireplace('Z', '', $item->cod_z));
            $item->cod_z_formatado = !empty($valorLimpo) ? 'Z' . $valorLimpo : '';
        }

        $numSL = count($solicitacoes);

        return view('/desenvolvimento.listaDesenvolvimento', [
            "solicitacoes" => $solicitacoes,
            "qtdSL"        => $numSL,
            "projetistas"  => Usuario::getByRole('role', 'PROJETISTA'),
            "solicitantes" => Usuario::getSolic()
        ]);
    }

    function atualizaStatus(UpdateStatusRequest $request)
    {
        $data = $request->get();

        $resultado = Acompanhamento::updateStatus(
            $data['id'],
            $data['coluna'],
            $data['valor']
        );

        if (!$resultado) {
            return JSON::return([
                "success" => false,
                "message" => "Erro interno ao atualizar no banco de dados."
            ], 500);
        }

        // Carimba a data de início quando a fase INICIA (espelha o btnConceito do Access).
        $this->carimbarInicioFase($data['id'], $data['coluna'], $data['valor']);
        // Carimba o FIM + tempo quando a fase termina (espelha o btnConceitoOK/btnDetalheOK).
        $this->carimbarFimFase($data['id'], $data['coluna'], $data['valor']);

        return JSON::return([
            "success" => true,
            "message" => "Status atualizado com sucesso."
        ], 200);
    }

    /**
     * Grava a data de início da fase quando o status muda para o valor de "início"
     * (conceito → MODELO; detalhamento → EM ANDAMENTO), igual ao btnConceito do VBA.
     * Só grava se ainda estiver vazio (não reseta o 1º início).
     */
    private function carimbarInicioFase($id, $coluna, $valor): void
    {
        $mapa = [
            'conceito_status'     => ['gatilho' => 'MODELO',       'campo' => 'conceito_inicio'],
            'detalhamento_status' => ['gatilho' => 'EM ANDAMENTO', 'campo' => 'detalhamento_inicio'],
        ];

        if (!isset($mapa[$coluna])) {
            return;
        }
        if (strtoupper(trim((string) $valor)) !== $mapa[$coluna]['gatilho']) {
            return;
        }

        $campo = $mapa[$coluna]['campo'];

        // não sobrescreve um início já gravado
        $linha = Acompanhamento::select([$campo])->where('id', '=', $id)->finish();
        $atual = $linha[0]->{$campo} ?? null;
        if (!empty($atual) && $atual !== '0000-00-00 00:00:00') {
            return;
        }

        Acompanhamento::updateStatus($id, $campo, date('Y-m-d H:i:s'));
    }

    /**
     * Carimba o FIM da fase + calcula o tempo (horas) quando o status vira OK,
     * espelhando o btnConceitoOK/btnDetalheOK do Access:
     *   Tempo = dias_uteis(inicio, fim) * 8 + (hora_fim - hora_inicio)
     * conceito → conceito_fim + tempo_modelo ; detalhamento → detalhamento_fim + tempo_det.
     * Só grava se ainda não houver fim (não recarimba).
     */
    private function carimbarFimFase($id, $coluna, $valor): void
    {
        $mapa = [
            'conceito_status'     => ['inicio' => 'conceito_inicio',     'fim' => 'conceito_fim',     'tempo' => 'tempo_modelo'],
            'detalhamento_status' => ['inicio' => 'detalhamento_inicio', 'fim' => 'detalhamento_fim', 'tempo' => 'tempo_det'],
        ];

        if (!isset($mapa[$coluna])) {
            return;
        }
        if (strtoupper(trim((string) $valor)) !== 'OK') {
            return;
        }

        $cfg   = $mapa[$coluna];
        $linha = Acompanhamento::select([$cfg['inicio'], $cfg['fim']])->where('id', '=', $id)->finish();
        if (empty($linha)) {
            return;
        }

        $inicio   = $linha[0]->{$cfg['inicio']} ?? null;
        $fimAtual = $linha[0]->{$cfg['fim']} ?? null;

        // não recarimba um fim já gravado
        if (!empty($fimAtual) && $fimAtual !== '0000-00-00 00:00:00') {
            return;
        }

        $agora = date('Y-m-d H:i:s');
        Acompanhamento::updateStatus($id, $cfg['fim'], $agora);

        if (!empty($inicio) && $inicio !== '0000-00-00 00:00:00') {
            Acompanhamento::updateStatus($id, $cfg['tempo'], $this->calcularTempoFaseHoras($inicio, $agora));
        }
    }

    /**
     * Tempo da fase em horas, igual ao Access (TESTE.Diff):
     *   dias_uteis * 8 + (hora_fim - hora_inicio em horas, podendo ser negativo).
     */
    private function calcularTempoFaseHoras(string $inicio, string $fim): float
    {
        try {
            $ini = new \DateTime($inicio);
            $f   = new \DateTime($fim);
        } catch (\Throwable $e) {
            return 0.0;
        }

        $diasUteis = $this->diasUteis($ini, $f);

        // diferença da HORA do dia (HH:MM, igual ao DateDiff("n")/60 do Access)
        $minIni = (int) $ini->format('H') * 60 + (int) $ini->format('i');
        $minFim = (int) $f->format('H') * 60 + (int) $f->format('i');
        $diffHoras = ($minFim - $minIni) / 60;

        return round($diasUteis * 8 + $diffHoras, 1);
    }

    /**
     * Dias úteis no intervalo (inicio, fim] — exclui sáb/dom e feriados — espelhando
     * a Diff_Dias do VBA. Feriados vêm da tabela `feriados` (se existir); senão, só fds.
     */
    private function diasUteis(\DateTime $ini, \DateTime $fim): int
    {
        $d1 = (clone $ini)->setTime(0, 0, 0);
        $d2 = (clone $fim)->setTime(0, 0, 0);
        if ($d2 <= $d1) {
            return 0;
        }

        $feriados = $this->feriados();
        $uteis  = 0;
        $cursor = clone $d1;

        while ($cursor < $d2) {
            $cursor->modify('+1 day');
            $dow = (int) $cursor->format('N'); // 1=seg ... 6=sáb, 7=dom
            if ($dow >= 6) {
                continue;
            }
            if (in_array($cursor->format('Y-m-d'), $feriados, true)) {
                continue;
            }
            $uteis++;
        }

        return $uteis;
    }

    /**
     * Lista de feriados ('Y-m-d'). Lê da tabela `feriados` (coluna `data`) se existir;
     * caso contrário devolve [] (aí o cálculo exclui só fins de semana).
     */
    private function feriados(): array
    {
        try {
            $pdo  = Acompanhamento::getPDO();
            $rows = $pdo->query("SELECT data FROM bd_device_request.feriados")->fetchAll(\PDO::FETCH_COLUMN);
            return array_map(function ($d) {
                return date('Y-m-d', strtotime((string) $d));
            }, $rows ?: []);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Access -> Web: recebe os feriados (planilha "Feriados" do VBA) e regrava a
     * tabela `feriados`. Cria a tabela se não existir. POST form-urlencoded:
     * dados = uma data YYYY-MM-DD por linha. Substitui todo o conteúdo.
     */
    public function uploadFeriadosVba()
    {
        $dados = (string) (Request::input('dados') ?? '');

        // valida e deduplica as datas (só aceita YYYY-MM-DD)
        $datas = [];
        foreach (preg_split('/\r\n|\r|\n/', $dados) as $linha) {
            $linha = trim($linha);
            if ($linha !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $linha)) {
                $datas[$linha] = true;
            }
        }
        $datas = array_keys($datas);

        $pdo = null;
        try {
            $pdo = Acompanhamento::getPDO();

            $pdo->exec("
                CREATE TABLE IF NOT EXISTS bd_device_request.feriados (
                    id   INT AUTO_INCREMENT PRIMARY KEY,
                    data DATE NOT NULL,
                    UNIQUE KEY uq_feriado_data (data)
                )
            ");

            if (!$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $pdo->exec("DELETE FROM bd_device_request.feriados");

            $stmt = $pdo->prepare("INSERT INTO bd_device_request.feriados (data) VALUES (:data)");
            $n = 0;
            foreach ($datas as $d) {
                $stmt->execute([':data' => $d]);
                $n++;
            }

            $pdo->commit();

            return Json::return(['ok' => true, 'feriados' => $n], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Erro no uploadFeriadosVba: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar feriados'], 500);
        }
    }

    function arquivosSolicitacao(string $ref): View
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        $cargasAnexos = SolicitacaoAnexoCarga::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $ultimaCarga = $cargasAnexos[0] ?? null;

        $arquivosSolicitacao = SolicitacaoAnexoArquivo::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $itensComprados = SolicitacaoItemComprado::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'ASC')
            ->finish() ?: [];

        $arquivosPorTipo = $this->separarArquivosSolicitacao($arquivosSolicitacao);

        return view('modals.arquivos-solicitacao', [
            'solicitacao'         => $solicitacao,
            'z_info'              => Projeto::getByZcode(ltrim((string)($solicitacao->cod_z ?? ''), 'zZ')),

            'ultimaCarga'         => $ultimaCarga,
            'cargasAnexos'        => $cargasAnexos,
            'arquivosSolicitacao' => $arquivosSolicitacao,
            'arquivosPorTipo'     => $arquivosPorTipo,

            'imagemProjeto'       => $arquivosPorTipo['IMAGEM_PROJETO'][0] ?? null,
            'pacotesDxf'          => $arquivosPorTipo['PACOTE_DXF'] ?? [],
            'txtItensComprados'   => $arquivosPorTipo['ITENS_COMPRADOS_TXT'] ?? [],
            'listasMateriais'     => $arquivosPorTipo['LISTA_MATERIAIS'] ?? [],
            'desenhosPdf'         => $arquivosPorTipo['DESENHO_PDF'] ?? [],

            'itensComprados'      => $itensComprados
        ]);
    }

    function storeArquivosSolicitacao(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível carregar arquivos quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $prioridade = $_POST['prioridade'] ?? '02-Média';

        $semArquivosDxf = isset($_POST['sem_arquivos_dxf']) ? '1' : '0';
        $nenhumItemComprado = isset($_POST['nenhum_item_comprado']) ? '1' : '0';

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $arquivosCriadosFisicamente = [];

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $prioridade,
                'sem_arquivos_dxf'     => $semArquivosDxf,
                'nenhum_item_comprado' => $nenhumItemComprado,
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga dos anexos.");
            }

            $cargaId = $saveCarga['id'];

            if (!empty($_FILES['imagem_projeto']) && $this->arquivoValido($_FILES['imagem_projeto'])) {
                $this->validarExtensaoArquivo($_FILES['imagem_projeto'], ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'], 'imagem');

                $arquivosParaExcluirFisicamente = array_merge(
                    $arquivosParaExcluirFisicamente,
                    $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO')
                );

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $_FILES['imagem_projeto'],
                    'IMAGEM_PROJETO',
                    "{$baseUploadDir}/imagem",
                    "{$baseUploadPath}/imagem",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
            }

            if ($semArquivosDxf === '1') {
                $arquivosParaExcluirFisicamente = array_merge(
                    $arquivosParaExcluirFisicamente,
                    $this->removerArquivosExistentesPorTipo($ref, 'PACOTE_DXF')
                );
            } elseif (!empty($_FILES['pacote_dxf']) && $this->arquivoValido($_FILES['pacote_dxf'])) {
                $this->validarExtensaoArquivo($_FILES['pacote_dxf'], ['zip', 'rar', '7z', 'dxf'], 'pacote DXF');

                $codigoDxf = $this->gerarProximoCodigoDxf($ref);

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $_FILES['pacote_dxf'],
                    'PACOTE_DXF',
                    "{$baseUploadDir}/dxf",
                    "{$baseUploadPath}/dxf",
                    $usuarioLogado,
                    $codigoDxf
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
            }

            if ($nenhumItemComprado === '1') {
                $arquivosParaExcluirFisicamente = array_merge(
                    $arquivosParaExcluirFisicamente,
                    $this->removerArquivosExistentesPorTipo($ref, 'ITENS_COMPRADOS_TXT')
                );
            } else {
                $arquivosTxt = $this->normalizarFilesArray($_FILES['itens_comprados_txt'] ?? null);

                $txtValidos = [];

                foreach ($arquivosTxt as $arquivoTxt) {
                    if (!$this->arquivoValido($arquivoTxt)) {
                        continue;
                    }

                    $this->validarExtensaoArquivo($arquivoTxt, ['txt'], 'TXT de itens comprados');

                    $txtValidos[] = $arquivoTxt;
                }

                if (!empty($txtValidos)) {
                    $arquivosParaExcluirFisicamente = array_merge(
                        $arquivosParaExcluirFisicamente,
                        $this->removerArquivosExistentesPorTipo($ref, 'ITENS_COMPRADOS_TXT')
                    );

                    foreach ($txtValidos as $arquivoTxt) {
                        $arquivoSalvo = $this->salvarArquivoSolicitacao(
                            $cargaId,
                            $ref,
                            $arquivoTxt,
                            'ITENS_COMPRADOS_TXT',
                            "{$baseUploadDir}/itens_comprados",
                            "{$baseUploadPath}/itens_comprados",
                            $usuarioLogado
                        );

                        $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

                        $this->salvarItensCompradosDoTxt(
                            $cargaId,
                            $arquivoSalvo['id'],
                            $ref,
                            $arquivoSalvo['caminho_fisico'],
                            $usuarioLogado
                        );
                    }
                }
            }

            if (!empty($_FILES['lista_materiais']) && $this->arquivoValido($_FILES['lista_materiais'])) {
                $this->validarExtensaoArquivo($_FILES['lista_materiais'], ['xls', 'xlsx', 'csv'], 'lista de materiais');

                $arquivosParaExcluirFisicamente = array_merge(
                    $arquivosParaExcluirFisicamente,
                    $this->removerArquivosExistentesPorTipo($ref, 'LISTA_MATERIAIS')
                );

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $_FILES['lista_materiais'],
                    'LISTA_MATERIAIS',
                    "{$baseUploadDir}/lista_materiais",
                    "{$baseUploadPath}/lista_materiais",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
            }

            $desenhosPdf = $this->normalizarFilesArray($_FILES['desenhos_pdf'] ?? null);

            foreach ($desenhosPdf as $desenhoPdf) {
                if (!$this->arquivoValido($desenhoPdf)) {
                    continue;
                }

                $this->validarExtensaoArquivo($desenhoPdf, ['pdf'], 'desenho PDF');

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $desenhoPdf,
                    'DESENHO_PDF',
                    "{$baseUploadDir}/desenhos_pdf",
                    "{$baseUploadPath}/desenhos_pdf",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Arquivos da solicitação carregados/atualizados com sucesso.',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Arquivos carregados com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar arquivos da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar os arquivos da solicitação.");
        }
    }

    public function removerArquivoSolicitacao(string $id)
    {
        $arquivo = $this->buscarArquivoSolicitacaoPorId($id);

        if (!$arquivo) {
            return redirect()
                ->back()
                ->withError("Arquivo não encontrado.");
        }

        $tipo = strtoupper(trim((string)($arquivo->tipo ?? '')));

        if (!in_array($tipo, ['PACOTE_DXF', 'DESENHO_PDF'], true)) {
            return redirect()
                ->back()
                ->withError("Este tipo de arquivo não pode ser removido manualmente.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $ref = $arquivo->ref ?? null;
        $nomeOriginal = $arquivo->nome_original ?? 'arquivo';
        $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');

        $pdo = null;

        try {
            $pdo = SolicitacaoAnexoArquivo::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $deleteArquivo = $pdo->prepare("
                DELETE FROM bd_device_request.solicitacao_anexo_arquivos
                WHERE id = :id
            ");

            $deleteArquivo->execute([
                ':id' => $id
            ]);

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Arquivo removido da solicitação: {$nomeOriginal}.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            if (!empty($caminhoFisico) && file_exists($caminhoFisico)) {
                @unlink($caminhoFisico);
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Arquivo removido com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log("Erro ao remover arquivo {$id}: " . $e->getMessage());

            return redirect()
                ->back()
                ->withError("Erro ao remover o arquivo.");
        }
    }

    function desenvolvimentoInfoView(string $ref): View
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        $zCode = ltrim((string)($solicitacao->cod_z ?? ''), 'zZ');

        if ($solicitacao->situacao === 'aprovar') {
            $statusConceito = ['OK', 'REVISAR'];
        }

        $statusConceito = ['EM ANÁLISE', 'BACKLOG', 'MODELO', 'PAUSADO', 'CONCEITO OK', 'OK', 'REVISAR'];
        $statusDetalhamento = ['EM ANDAMENTO', 'PAUSADO', 'OK'];
        $statusLiberacao = ['PENDENTE', 'OK'];
        $statusAquisicao = ['PENDENTE', 'REALIZADO', 'TERCEIRIZADO', 'OK'];
        $statusCorte = ['PARADO', 'ANDAMENTO', 'TERCEIRIZADO', 'FINALIZADO'];
        $statusExecucao = ['PARADO', 'ANDAMENTO', 'TERCEIRIZADO', 'FINALIZADO'];
        $statusTryout = ['PARADO', 'ANDAMENTO', 'TERCEIRIZADO', 'FINALIZADO'];

        $etapas = [
            [
                'label'  => 'Conceito',
                'coluna' => 'conceito_status',
                'valor'  => $solicitacao->conceito_status,
                'opcoes' => $statusConceito,
                'edit'   => true
            ],
            [
                'label'  => 'Detalhe',
                'coluna' => 'detalhamento_status',
                'valor'  => $solicitacao->detalhamento_status,
                'opcoes' => $statusDetalhamento,
                'edit'   => true
            ],
            [
                'label'  => 'Liberação',
                'coluna' => 'liberacao_status',
                'valor'  => $solicitacao->liberacao_status,
                'opcoes' => $statusLiberacao,
                'edit'   => false
            ],
            [
                'label'  => 'Aquisição',
                'coluna' => 'aquisicao_status',
                'valor'  => $solicitacao->aquisicao_status,
                'opcoes' => $statusAquisicao,
                'edit'   => false
            ],
            [
                'label'  => 'Corte',
                'coluna' => 'corte_status',
                'valor'  => $solicitacao->corte_status,
                'opcoes' => $statusCorte,
                'edit'   => false
            ],
            [
                'label'  => 'Execução',
                'coluna' => 'exec_status',
                'valor'  => $solicitacao->exec_status,
                'opcoes' => $statusExecucao,
                'edit'   => false
            ],
            [
                'label'  => 'Tryout',
                'coluna' => 'tryout_status',
                'valor'  => $solicitacao->tryout_status,
                'opcoes' => $statusTryout,
                'edit'   => false
            ]
        ];

        $cargasAnexos = SolicitacaoAnexoCarga::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $arquivosSolicitacao = SolicitacaoAnexoArquivo::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'DESC')
            ->finish() ?: [];

        $itensComprados = SolicitacaoItemComprado::select(['*'])
            ->where('ref', '=', $ref)
            ->order('created_at', 'ASC')
            ->finish() ?: [];

        $arquivosPorTipo = $this->separarArquivosSolicitacao($arquivosSolicitacao);
        $cargasMap = $this->criarMapaCargas($cargasAnexos);

        return view('desenvolvimento.desenvolvimentoForm', [
            "solicitacao" => $solicitacao,
            "z_info"      => Projeto::getByZcode($zCode),
            "etapas"      => $etapas,
            "projetistas" => Usuario::getByRole('role', 'PROJETISTA'),
            "interacoes"  => Historico::getHistoryInfos($ref) ?: [],

            "cargasAnexos"        => $cargasAnexos,
            "cargasMap"           => $cargasMap,
            "arquivosSolicitacao" => $arquivosSolicitacao,
            "arquivosPorTipo"     => $arquivosPorTipo,

            "imagemProjeto"       => $arquivosPorTipo['IMAGEM_PROJETO'][0] ?? null,
            "pacotesDxf"          => $arquivosPorTipo['PACOTE_DXF'] ?? [],
            "txtItensComprados"   => $arquivosPorTipo['ITENS_COMPRADOS_TXT'] ?? [],
            "listasMateriais"     => $arquivosPorTipo['LISTA_MATERIAIS'] ?? [],
            "desenhosPdf"         => $arquivosPorTipo['DESENHO_PDF'] ?? [],
            "itensComprados"      => $itensComprados
        ]);
    }

    /**
     * Cria (idempotente) todas as subpastas que o VBA usa dentro do storage
     * mapeado (APP_STORAGE_MAPPED) — a pasta que o Access enxerga (mapeada no
     * Windows). Rode uma vez após configurar/mapear a pasta. GET, devolve a lista.
     */
    public function garantirStorageMapeado()
    {
        $base = rtrim($_ENV['APP_STORAGE_MAPPED'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') {
            return Json::return(['error' => 'APP_STORAGE_MAPPED não configurado'], 500);
        }

        if (!is_dir($base)) {
            @mkdir($base, 0777, true);
        }

        // Mesmas pastas usadas pelo VBA (workbooks Solicitação + Lista)
        $subpastas = ['.Files', '.img_sl', '.img_z', '.imgs', '.desenhos', 'desenhosPDF', '.dxf', '.cortes', '.bom'];
        $criadas = [];
        $existentes = [];

        foreach ($subpastas as $p) {
            $dir = $base . '/' . $p;
            if (is_dir($dir)) {
                $existentes[] = $p;
            } elseif (@mkdir($dir, 0777, true)) {
                $criadas[] = $p;
            }
        }

        return Json::return([
            'base'       => $base,
            'criadas'    => $criadas,
            'existentes' => $existentes,
        ], 200);
    }

    public function storeImagemProjeto(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível alterar a imagem quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        if (empty($_FILES['imagem_projeto']) || !$this->arquivoValido($_FILES['imagem_projeto'])) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione uma imagem válida.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $arquivosCriadosFisicamente = [];

        try {
            $this->validarExtensaoArquivo($_FILES['imagem_projeto'], ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'], 'imagem');

            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da imagem.");
            }

            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO');

            $arquivoSalvo = $this->salvarArquivoSolicitacao(
                $saveCarga['id'],
                $ref,
                $_FILES['imagem_projeto'],
                'IMAGEM_PROJETO',
                "{$baseUploadDir}/imagem",
                "{$baseUploadPath}/imagem",
                $usuarioLogado
            );

            $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Imagem de visualização do projeto atualizada.',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Imagem atualizada com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar imagem da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao atualizar a imagem.");
        }
    }

    /**
     * Access -> Web: recebe a imagem do projeto enviada pelo VBA
     * (frmaut.btnLoadImage) como corpo binário cru (php://input) e a registra
     * como IMAGEM_PROJETO usando a MESMA estrutura do storeImagemProjeto:
     * cria a carga, grava o arquivo em .../imagem/, registra em
     * solicitacao_anexo_arquivos e adiciona ao histórico. Substitui a imagem
     * anterior, se houver. SEM trava de status — espelha o que o Access já fez.
     * Parâmetros via query string: ?ref=NNN&nome=arquivo.jpg
     */
    public function uploadImagemVba()
    {
        $ref  = (int) (Request::query('ref') ?? 0);
        $nome = Request::query('nome') ?: ('SL' . $ref . '.jpg');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado = 'ACCESS';

        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da imagem.");
            }

            // Remove o registro da imagem anterior (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'IMAGEM_PROJETO');

            // Grava a partir dos BYTES (não há $_FILES no POST do VBA, então não
            // dá pra usar salvarArquivoSolicitacao/move_uploaded_file)
            // Storage na ARQUITETURA DO ACCESS (a imagem já existe no Access; não espelha)
            [$subpasta, $nomeSeguro] = $this->caminhoAccess('IMAGEM_PROJETO', (string) $ref, null, $nome);
            $dirStorage = $this->storageBase() . '/' . $subpasta;
            if (!is_dir($dirStorage)) {
                mkdir($dirStorage, 0777, true);
            }
            $caminhoFisico   = $dirStorage . '/' . $nomeSeguro;
            $caminhoRelativo = $subpasta . '/' . $nomeSeguro;

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar a imagem.");
            }
            $caminhoFisicoNovo = $caminhoFisico;

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'IMAGEM_PROJETO',
                'codigo'        => null,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'image/jpeg',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);

            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro da imagem.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => 'Imagem de visualização do projeto atualizada (Access).',
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }

            error_log("Erro no uploadImagemVba {$ref}: " . $e->getMessage());

            return Json::return(['error' => 'falha ao salvar imagem'], 500);
        }
    }

    public function storePacoteDxf(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar DXF quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        if (empty($_FILES['pacote_dxf']) || !$this->arquivoValido($_FILES['pacote_dxf'])) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione um pacote DXF válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosCriadosFisicamente = [];

        try {
            $this->validarExtensaoArquivo($_FILES['pacote_dxf'], ['zip', 'rar', '7z', 'dxf'], 'pacote DXF');

            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do DXF.");
            }

            $codigoDxf = $this->gerarProximoCodigoDxf($ref);

            $arquivoSalvo = $this->salvarArquivoSolicitacao(
                $saveCarga['id'],
                $ref,
                $_FILES['pacote_dxf'],
                'PACOTE_DXF',
                "{$baseUploadDir}/dxf",
                "{$baseUploadPath}/dxf",
                $usuarioLogado,
                $codigoDxf
            );

            $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Pacote DXF {$codigoDxf} adicionado à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("Pacote DXF {$codigoDxf} salvo com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar DXF da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar o pacote DXF.");
        }
    }

    /**
     * Access -> Web: recebe UM pacote DXF (zip) enviado pelo VBA (ufdxf) como corpo
     * binário cru. Usa o `codigo` JÁ atribuído pelo Access via cartório (nextDxf),
     * tipo PACOTE_DXF. Se já houver DXF de mesmo codigo, substitui. Sem trava.
     * Parâmetros via query: ?ref=NNN&codigo=DX0001&nome=arquivo.zip
     */
    public function uploadDxfVba()
    {
        $ref    = (int) (Request::query('ref') ?? 0);
        $codigo = trim((string) (Request::query('codigo') ?? ''));
        $nome   = Request::query('nome') ?: (($codigo !== '' ? $codigo : ('SL' . $ref)) . '.zip');

        if ($ref <= 0)      return Json::return(['error' => 'ref inválido'], 400);
        if ($codigo === '') return Json::return(['error' => 'codigo obrigatório'], 400);

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) return Json::return(['error' => 'solicitação não encontrada'], 404);

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado  = 'ACCESS';
        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();
            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);
            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do DXF.");
            }

            // Substitui o DXF anterior de MESMO codigo (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivoPorCodigo($ref, 'PACOTE_DXF', $codigo);

            // Storage na ARQUITETURA DO ACCESS (o zip já existe no Access; não espelha)
            [$subpasta, $nomeSeguro] = $this->caminhoAccess('PACOTE_DXF', (string) $ref, $codigo, $nome);
            $dirStorage = $this->storageBase() . '/' . $subpasta;
            if (!is_dir($dirStorage)) {
                mkdir($dirStorage, 0777, true);
            }
            $caminhoFisico   = $dirStorage . '/' . $nomeSeguro;
            $caminhoRelativo = $subpasta . '/' . $nomeSeguro;

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar o DXF.");
            }
            $caminhoFisicoNovo = $caminhoFisico;

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'PACOTE_DXF',
                'codigo'        => $codigo,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'application/zip',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);
            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro do DXF.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Pacote DXF '{$codigo}' adicionado (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro, 'codigo' => $codigo], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }
            error_log("Erro no uploadDxfVba {$ref}/{$codigo}: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar DXF'], 500);
        }
    }

    /**
     * Remove (registro + retorna caminhos físicos) o arquivo de um dado tipo/codigo
     * de uma SL, para que o re-upload substitua em vez de duplicar.
     */
    private function removerArquivoPorCodigo(string $ref, string $tipo, string $codigo): array
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT *
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref AND tipo = :tipo AND codigo = :codigo
        ");
        $stmt->execute([':ref' => $ref, ':tipo' => $tipo, ':codigo' => $codigo]);
        $arquivos = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        if (empty($arquivos)) {
            return [];
        }

        $fisicos = [];
        foreach ($arquivos as $arquivo) {
            $arquivoId = $arquivo->id ?? null;
            if (!$arquivoId) {
                continue;
            }

            $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');
            if (!empty($caminhoFisico)) {
                $fisicos[] = $caminhoFisico;
            }

            $pdo->prepare("DELETE FROM bd_device_request.solicitacao_anexo_arquivos WHERE id = :id")
                ->execute([':id' => $arquivoId]);
        }

        return $fisicos;
    }

    /**
     * Web -> Access (pull): CSV dos pacotes DXF (PACOTE_DXF) p/ o VBA upsertar em
     * DXF_Control. Colunas: Controle;Solicitacao;Projeto;Descricao.
     * Controle = número do codigo (DX0001 -> 1); Solicitacao = "SL"+4 díg.;
     * Projeto = cod_z da SL. Descrição vem do nome do arquivo (web não modela a rica).
     */
    public function csvDxf()
    {
        if (ob_get_level()) ob_end_clean();

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=Dxf.csv');

        $pdo = SolicitacaoAnexoArquivo::getPDO();
        $rows = $pdo->query("
            SELECT a.ref AS ref, a.codigo AS codigo, a.nome_original AS nome, s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_anexo_arquivos a
            LEFT JOIN bd_device_request.solicitacoes s ON s.ref = a.ref
            WHERE a.tipo = 'PACOTE_DXF' AND a.codigo REGEXP '^DX[0-9]+$'
            ORDER BY a.codigo
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');
        fputs($file, "\xEF\xBB\xBF");
        fputcsv($file, ['Controle', 'Solicitacao', 'Projeto', 'Descricao'], ';');

        foreach ($rows as $r) {
            $controle = (int) preg_replace('/\D/', '', (string) $r->codigo);
            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);
            fputcsv($file, [$controle, $sl, $r->cod_z ?? '', $r->nome ?? ''], ';');
        }
        fclose($file);
        exit;
    }

    public function storeDesenhosPdf(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar PDF quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        $desenhosPdf = $this->normalizarFilesArray($_FILES['desenhos_pdf'] ?? null);

        if (empty($desenhosPdf)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione ao menos um PDF válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosCriadosFisicamente = [];

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga dos PDFs.");
            }

            $qtdSalvos = 0;
            $pdfsParaAccess = []; // [ ['codigo'=>..., 'fisico'=>...], ... ]

            foreach ($desenhosPdf as $pdf) {
                if (!$this->arquivoValido($pdf)) {
                    continue;
                }

                $this->validarExtensaoArquivo($pdf, ['pdf'], 'desenho PDF');

                // codigo = nome do arquivo sem extensão (mesma identidade do Access/PDF_Control)
                $codigo = pathinfo($pdf['name'] ?? '', PATHINFO_FILENAME);

                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $saveCarga['id'],
                    $ref,
                    $pdf,
                    'DESENHO_PDF',
                    "{$baseUploadDir}/desenhos_pdf",
                    "{$baseUploadPath}/desenhos_pdf",
                    $usuarioLogado,
                    $codigo
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];
                $pdfsParaAccess[] = ['codigo' => $codigo, 'fisico' => $arquivoSalvo['caminho_fisico']];
                $qtdSalvos++;
            }

            if ($qtdSalvos === 0) {
                throw new \Exception("Nenhum PDF válido foi enviado.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$qtdSalvos} desenho(s) PDF adicionado(s) à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("PDF(s) salvo(s) com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar PDF da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar os PDFs.");
        }
    }

    /**
     * Access -> Web: recebe UM desenho PDF enviado pelo VBA (frmaut.btn_pdf_novo)
     * como corpo binário cru. Registra como DESENHO_PDF com o `codigo` (= nome do
     * arquivo, igual ao PDF_Control do Access). Se já houver um PDF de mesmo
     * codigo nesta SL, substitui. SEM trava de status — espelha o Access.
     * Parâmetros via query string: ?ref=NNN&codigo=XXX&nome=arquivo.pdf
     */
    public function uploadDesenhoPdfVba()
    {
        $ref    = (int) (Request::query('ref') ?? 0);
        $codigo = trim((string) (Request::query('codigo') ?? ''));
        $nome   = Request::query('nome') ?: (($codigo !== '' ? $codigo : ('SL' . $ref)) . '.pdf');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }
        if ($codigo === '') {
            return Json::return(['error' => 'codigo obrigatório'], 400);
        }

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        $usuarioLogado = 'ACCESS';

        $baseUploadDir  = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $caminhoFisicoNovo = null;

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga do PDF.");
            }

            // Substitui o PDF anterior de MESMO codigo (físico só depois do commit)
            $arquivosParaExcluirFisicamente = $this->removerArquivoDesenhoPorCodigo($ref, $codigo);

            // Storage na ARQUITETURA DO ACCESS (o PDF já existe no Access; não espelha)
            [$subpasta, $nomeSeguro] = $this->caminhoAccess('DESENHO_PDF', (string) $ref, $codigo, $nome);
            $dirStorage = $this->storageBase() . '/' . $subpasta;
            if (!is_dir($dirStorage)) {
                mkdir($dirStorage, 0777, true);
            }
            $caminhoFisico   = $dirStorage . '/' . $nomeSeguro;
            $caminhoRelativo = $subpasta . '/' . $nomeSeguro;

            if (file_put_contents($caminhoFisico, $conteudo) === false) {
                throw new \Exception("Não foi possível gravar o PDF.");
            }
            $caminhoFisicoNovo = $caminhoFisico;

            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'DESENHO_PDF',
                'codigo'        => $codigo,
                'nome_original' => basename($nome),
                'nome_arquivo'  => $nomeSeguro,
                'caminho'       => $caminhoRelativo,
                'mime_type'     => 'application/pdf',
                'tamanho_bytes' => strlen($conteudo),
                'created_by'    => $usuarioLogado
            ]);

            if (!$saveArquivo || empty($saveArquivo['id'])) {
                throw new \Exception("Não foi possível salvar o registro do PDF.");
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "Desenho PDF '{$codigo}' adicionado (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return Json::return(['ok' => true, 'arquivo' => $nomeSeguro, 'codigo' => $codigo], 200);

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($caminhoFisicoNovo && file_exists($caminhoFisicoNovo)) {
                @unlink($caminhoFisicoNovo);
            }
            error_log("Erro no uploadDesenhoPdfVba {$ref}/{$codigo}: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar PDF'], 500);
        }
    }

    /**
     * Remove (registro + retorna caminhos físicos) o desenho PDF de mesmo codigo
     * de uma SL, para que o re-upload substitua em vez de duplicar.
     */
    private function removerArquivoDesenhoPorCodigo(string $ref, string $codigo): array
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT *
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref
              AND tipo = 'DESENHO_PDF'
              AND codigo = :codigo
        ");
        $stmt->execute([':ref' => $ref, ':codigo' => $codigo]);
        $arquivos = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        if (empty($arquivos)) {
            return [];
        }

        $fisicos = [];
        foreach ($arquivos as $arquivo) {
            $arquivoId = $arquivo->id ?? null;
            if (!$arquivoId) {
                continue;
            }

            $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');
            if (!empty($caminhoFisico)) {
                $fisicos[] = $caminhoFisico;
            }

            $pdo->prepare("DELETE FROM bd_device_request.solicitacao_anexo_arquivos WHERE id = :id")
                ->execute([':id' => $arquivoId]);
        }

        return $fisicos;
    }

    /**
     * Web -> Access (pull): CSV de todos os desenhos PDF (DESENHO_PDF) para o VBA
     * upsertar em PDF_Control. Colunas: Solicitacao;Projeto;Codigo;Revisao.
     * Solicitacao no formato do Access ("SL"+4 dígitos); Projeto = cod_z da SL.
     */
    public function csvDesenhosPdf()
    {
        if (ob_get_level()) ob_end_clean();

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=DesenhosPdf.csv');

        $pdo = SolicitacaoAnexoArquivo::getPDO();
        $rows = $pdo->query("
            SELECT a.ref AS ref, a.codigo AS codigo, s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_anexo_arquivos a
            LEFT JOIN bd_device_request.solicitacoes s ON s.ref = a.ref
            WHERE a.tipo = 'DESENHO_PDF'
              AND a.codigo IS NOT NULL AND a.codigo <> ''
            ORDER BY a.ref, a.codigo
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');
        fputs($file, "\xEF\xBB\xBF");
        fputcsv($file, ['Solicitacao', 'Projeto', 'Codigo', 'Revisao'], ';');

        foreach ($rows as $r) {
            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);
            fputcsv($file, [$sl, $r->cod_z ?? '', $r->codigo, '0'], ';');
        }
        fclose($file);
        exit;
    }

    public function storeItensCompradosTxt(string $ref)
    {
        $solicitacao = Acompanhamento::getByRef($ref);

        if (!$solicitacao) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Solicitação não encontrada.");
        }

        if (!$this->podeCarregarArquivos($solicitacao)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Só é possível adicionar itens quando Conceito/Modelo e Detalhamento estiverem com status OK.");
        }

        $arquivosTxt = $this->normalizarFilesArray($_FILES['itens_comprados_txt'] ?? null);

        if (empty($arquivosTxt)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Selecione ao menos um arquivo TXT válido.");
        }

        $usuarioLogado = $this->usuarioLogado();

        $baseUploadDir = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";
        $baseUploadPath = "/var/www/htdocs/greenbrier/v2/solic_dispositivos_files/{$ref}";

        $pdo = null;
        $arquivosParaExcluirFisicamente = [];
        $arquivosCriadosFisicamente = [];

        try {
            $pdo = SolicitacaoAnexoCarga::getPDO();

            if ($pdo && !$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => $_POST['prioridade'] ?? '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);

            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga dos itens comprados.");
            }

            $cargaId = $saveCarga['id'];
            $qtdTxtSalvos = 0;

            $txtValidos = [];

            foreach ($arquivosTxt as $arquivoTxt) {
                if (!$this->arquivoValido($arquivoTxt)) {
                    continue;
                }

                $this->validarExtensaoArquivo($arquivoTxt, ['txt'], 'TXT de itens comprados');

                $txtValidos[] = $arquivoTxt;
            }

            if (empty($txtValidos)) {
                throw new \Exception("Nenhum TXT válido foi enviado.");
            }

            $arquivosParaExcluirFisicamente = $this->removerArquivosExistentesPorTipo($ref, 'ITENS_COMPRADOS_TXT');

            foreach ($txtValidos as $arquivoTxt) {
                $arquivoSalvo = $this->salvarArquivoSolicitacao(
                    $cargaId,
                    $ref,
                    $arquivoTxt,
                    'ITENS_COMPRADOS_TXT',
                    "{$baseUploadDir}/itens_comprados",
                    "{$baseUploadPath}/itens_comprados",
                    $usuarioLogado
                );

                $arquivosCriadosFisicamente[] = $arquivoSalvo['caminho_fisico'];

                $this->salvarItensCompradosDoTxt(
                    $cargaId,
                    $arquivoSalvo['id'],
                    $ref,
                    $arquivoSalvo['caminho_fisico'],
                    $usuarioLogado
                );

                $qtdTxtSalvos++;
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$qtdTxtSalvos} arquivo(s) TXT de itens comprados adicionado(s) à solicitação.",
                'situacao' => 'anexos'
            ]);

            if ($pdo && $pdo->inTransaction()) {
                $pdo->commit();
            }

            foreach ($arquivosParaExcluirFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withSuccess("TXT(s) de itens comprados salvo(s) com sucesso!");

        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            foreach ($arquivosCriadosFisicamente as $arquivoFisico) {
                if (!empty($arquivoFisico) && file_exists($arquivoFisico)) {
                    @unlink($arquivoFisico);
                }
            }

            error_log("Erro ao salvar TXT de itens comprados da solicitação {$ref}: " . $e->getMessage());

            return redirect()
                ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
                ->withError("Erro ao salvar o(s) TXT(s) de itens comprados.");
        }
    }

    /**
     * Access -> Web: recebe os itens de BOM (frm_bom.btnInserir) como UM lote.
     * POST form-urlencoded: ref + dados (linhas "codigo\trev\tdescricao\tqtde\ttipo"
     * separadas por \n). Insere em solicitacao_itens_comprados os que ainda não
     * existem (dedup por ref+codigo+rev). Sem trava de status — espelha o Access.
     */
    public function uploadBomVba()
    {
        $ref   = (int) (Request::input('ref') ?? 0);
        $dados = (string) (Request::input('dados') ?? '');

        if ($ref <= 0) {
            return Json::return(['error' => 'ref inválido'], 400);
        }

        $solicitacao = Acompanhamento::getByRef($ref);
        if (!$solicitacao) {
            return Json::return(['error' => 'solicitação não encontrada'], 404);
        }

        // Parseia as linhas do lote (campos separados por TAB)
        $itens = [];
        foreach (preg_split('/\r\n|\r|\n/', $dados) as $linha) {
            if (trim($linha) === '') {
                continue;
            }
            $c = explode("\t", $linha);
            $codigo = trim($c[0] ?? '');
            if ($codigo === '') {
                continue;
            }
            $itens[] = [
                'codigo'     => $codigo,
                'rev'        => trim($c[1] ?? ''),
                'descricao'  => trim($c[2] ?? ''),
                'quantidade' => trim($c[3] ?? ''),
                'tipo'       => trim($c[4] ?? ''),
                'linha'      => $linha,
            ];
        }
        if (empty($itens)) {
            return Json::return(['ok' => true, 'inseridos' => 0], 200);
        }

        $usuarioLogado = 'ACCESS';
        $pdo = SolicitacaoItemComprado::getPDO();

        // Chaves já existentes (codigo|rev) desta SL, para dedup
        $stmt = $pdo->prepare("
            SELECT codigo, rev
            FROM bd_device_request.solicitacao_itens_comprados
            WHERE ref = :ref
        ");
        $stmt->execute([':ref' => $ref]);
        $existentes = [];
        foreach ($stmt->fetchAll(\PDO::FETCH_OBJ) as $r) {
            $existentes[strtoupper(trim((string) $r->codigo)) . '|' . strtoupper(trim((string) $r->rev))] = true;
        }

        $novos = [];
        foreach ($itens as $it) {
            $chave = strtoupper($it['codigo']) . '|' . strtoupper($it['rev']);
            if (!isset($existentes[$chave])) {
                $novos[] = $it;
                $existentes[$chave] = true; // evita duplicar dentro do próprio lote
            }
        }
        if (empty($novos)) {
            return Json::return(['ok' => true, 'inseridos' => 0], 200);
        }

        try {
            if (!$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }

            $saveCarga = SolicitacaoAnexoCarga::create([
                'ref'                  => $ref,
                'prioridade'           => '02-Média',
                'sem_arquivos_dxf'     => '0',
                'nenhum_item_comprado' => '0',
                'status'               => 'ATIVO',
                'created_by'           => $usuarioLogado
            ]);
            if (!$saveCarga || empty($saveCarga['id'])) {
                throw new \Exception("Não foi possível registrar a carga da BOM.");
            }

            // Arquivo "marcador": a BOM veio do Access, não de um TXT físico
            $saveArquivo = SolicitacaoAnexoArquivo::create([
                'carga_id'      => $saveCarga['id'],
                'ref'           => $ref,
                'tipo'          => 'ITENS_COMPRADOS_TXT',
                'codigo'        => null,
                'nome_original' => 'BOM (Access)',
                'nome_arquivo'  => '',
                'caminho'       => '',
                'mime_type'     => 'text/plain',
                'tamanho_bytes' => strlen($dados),
                'created_by'    => $usuarioLogado
            ]);
            $arquivoId = $saveArquivo['id'] ?? null;

            $inseridos = 0;
            foreach ($novos as $it) {
                SolicitacaoItemComprado::create([
                    'carga_id'       => $saveCarga['id'],
                    'arquivo_id'     => $arquivoId,
                    'ref'            => $ref,
                    'codigo'         => $it['codigo'],
                    'rev'            => $it['rev'],
                    'descricao'      => $it['descricao'],
                    'quantidade'     => $it['quantidade'],
                    'tipo'           => $it['tipo'],
                    'linha_original' => $it['linha'],
                    'created_by'     => $usuarioLogado
                ]);
                $inseridos++;
            }

            Historico::create([
                'ref'      => $ref,
                'usuario'  => $usuarioLogado,
                'mensagem' => "{$inseridos} item(ns) de BOM adicionado(s) (Access).",
                'situacao' => 'anexos'
            ]);

            if ($pdo->inTransaction()) {
                $pdo->commit();
            }

            return Json::return(['ok' => true, 'inseridos' => $inseridos], 200);

        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Erro no uploadBomVba {$ref}: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar BOM'], 500);
        }
    }

    /**
     * Web -> Access (pull): CSV dos itens de BOM (solicitacao_itens_comprados) p/ o
     * VBA upsertar em BOM_Control.
     * Colunas: Solicitacao;Projeto;Codigo;Revisao;Descricao;Qtde;Tipo.
     */
    public function csvBom()
    {
        if (ob_get_level()) ob_end_clean();

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=Bom.csv');

        // Tira ';' e quebras dos campos livres (o VBA faz Split simples por ';')
        $limpar = function ($v) {
            return str_replace([';', "\r", "\n"], [',', ' ', ' '], (string) $v);
        };

        $pdo = SolicitacaoItemComprado::getPDO();
        $rows = $pdo->query("
            SELECT i.ref AS ref, i.codigo AS codigo, i.rev AS rev, i.descricao AS descricao,
                   i.quantidade AS qtde, i.tipo AS tipo, s.cod_z AS cod_z
            FROM bd_device_request.solicitacao_itens_comprados i
            LEFT JOIN bd_device_request.solicitacoes s ON s.ref = i.ref
            ORDER BY i.ref, i.codigo
        ")->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $file = fopen('php://output', 'w');
        fputs($file, "\xEF\xBB\xBF");
        fputcsv($file, ['Solicitacao', 'Projeto', 'Codigo', 'Revisao', 'Descricao', 'Qtde', 'Tipo'], ';');

        foreach ($rows as $r) {
            $sl = 'SL' . str_pad((string) $r->ref, 4, '0', STR_PAD_LEFT);
            fputcsv($file, [
                $sl,
                $limpar($r->cod_z),
                $limpar($r->codigo),
                $limpar($r->rev),
                $limpar($r->descricao),
                $limpar($r->qtde),
                $limpar($r->tipo),
            ], ';');
        }
        fclose($file);
        exit;
    }

    public function storeProjetista(UpdateRequest $request, int $ref, string $tipo)
    {
        $projetista = $request->input('projetista');

        if (!$projetista) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", [$ref])
                ->withError("Por favor, selecione um projetista.");
        }

        $dadosParaAtualizar = [];

        if ($tipo === 'conceito') {
            $dadosParaAtualizar = [
                'conceito_proj'   => $projetista,
                'conceito_status' => 'BACKLOG'
            ];
        } else if ($tipo === 'detalhamento') {
            $dadosParaAtualizar = [
                'detalhamento_proj' => $projetista
            ];
        }

        if (empty($dadosParaAtualizar)) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", [$ref])
                ->withError("Tipo de alocação inválido.");
        }

        $updateProjetista = Acompanhamento::updateByColumn('ref', $ref, $dadosParaAtualizar);

        if (!$updateProjetista) {
            return redirect()
                ->route("dispositivos.desenvolvimento.info", [$ref])
                ->withError("Erro interno ao atualizar no banco de dados.");
        }

        return redirect()
            ->route("dispositivos.desenvolvimento.info", ['ref' => $ref])
            ->withSuccess('Projetista alocado!');
    }

    public function gerarZ(int $ref)
    {
        $lastZ = Projeto::getLastZ();
        $newZ = $lastZ + 1;
        $slInfos = Acompanhamento::getByRef($ref);

        $saveProjeto = Projeto::create([
            'cod_z'       => $newZ,
            'descricao'   => $slInfos->descricao,
            'vagao'       => $slInfos->vagao,
            'lote'        => $slInfos->lote,
            'solicitante' => $slInfos->solicitante
        ]);

        if (!$saveProjeto) {
            throw new \Exception("Erro ao criar registro no Controle Z.");
        }

        $updateFila = Acompanhamento::updateByColumn('ref', $ref, [
            'cod_z' => $newZ
        ]);

        if (!$updateFila) {
            return redirect()->back()->withError("Não foi possível gerar o Z");
        }

        return redirect()->back()->withSuccess("Z{$newZ} gerado com sucesso!");
    }

    public function associarZ(CodigoZRequest $request, int $ref)
    {
        $zAssociado = $request->get();

        if (!$zAssociado) {
            return redirect()->back()->withError("Não foi possível associar o Z");
        }

        $updateZ = Projeto::updateByColumn('cod_z', $zAssociado['cod_z'], [
            'cod_z'  => $zAssociado['cod_z'],
            'qtdRev' => $zAssociado['qtdRev'],
        ]);

        if (!$updateZ) {
            return redirect()->back()->withError("Não foi possível criar nova revisão para o Z");
        }

        $updateFila = Acompanhamento::updateByColumn('ref', $ref, [
            'cod_z'  => $zAssociado['cod_z'],
            'qtdRev' => $zAssociado['qtdRev'],
        ]);

        if (!$updateFila) {
            return redirect()->back()->withError("Não foi possível associar o Z");
        }

        return redirect()->back()->withSuccess("Z{$zAssociado['cod_z']} associado com sucesso!");
    }

    public function visualizarArquivoSolicitacao(string $id)
    {
        return $this->entregarArquivoSolicitacao($id, true);
    }

    public function downloadArquivoSolicitacao(string $id)
    {
        return $this->entregarArquivoSolicitacao($id, false);
    }

    private function entregarArquivoSolicitacao(string $id, bool $inline = false)
    {
        $arquivo = $this->buscarArquivoSolicitacaoPorId($id);

        if (!$arquivo) {
            return redirect()
                ->back()
                ->withError("Arquivo não encontrado.");
        }

        $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');

        if (!$caminhoFisico || !file_exists($caminhoFisico)) {
            return redirect()
                ->back()
                ->withError("Arquivo não localizado no servidor.");
        }

        $nomeOriginal = $arquivo->nome_original ?? basename($caminhoFisico);

        $mimeType = $arquivo->mime_type ?? null;

        if (!$mimeType && function_exists('mime_content_type')) {
            $mimeType = mime_content_type($caminhoFisico);
        }

        if (!$mimeType) {
            $mimeType = 'application/octet-stream';
        }

        while (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Type: ' . $mimeType);
        header('Content-Length: ' . filesize($caminhoFisico));

        if ($inline) {
            header('Content-Disposition: inline; filename="' . basename($nomeOriginal) . '"');
        } else {
            header('Content-Disposition: attachment; filename="' . basename($nomeOriginal) . '"');
        }

        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');

        readfile($caminhoFisico);
        exit;
    }

    private function criarMapaCargas(array $cargas): array
    {
        $mapa = [];

        foreach ($cargas as $carga) {
            if (!empty($carga->id)) {
                $mapa[$carga->id] = $carga;
            }
        }

        return $mapa;
    }

    private function gerarProximoCodigoDxf(string $ref): string
    {
        // MESMA REGRA DO ACCESS: numeração GLOBAL (todas as SLs), formato "DX" + 4 dígitos
        // (ex.: DX0001). Antes era "DXF" + número por-SL.
        return 'DX' . str_pad((string) $this->proximoNumeroDxfGlobal(), 4, '0', STR_PAD_LEFT);
    }

    /**
     * Próximo número global de DXF, espelhando o MAX(Controle)+1 do DXF_Control do
     * Access. Como o histórico do DXF_Control não foi migrado, usamos um PISO
     * (APP_DXF_FLOOR = MAX(Controle) atual do Access) para o contador da web não
     * reiniciar em 1 e colidir com os DX legados. `$floorExtra` permite o Access
     * passar o próprio MAX no momento da criação (rota nextDxf).
     */
    private function proximoNumeroDxfGlobal(int $floorExtra = 0): int
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $rows = $pdo->query("
            SELECT codigo
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE tipo = 'PACOTE_DXF' AND codigo REGEXP '^DX[0-9]+$'
        ")->fetchAll(\PDO::FETCH_COLUMN) ?: [];

        $max = max((int) ($_ENV['APP_DXF_FLOOR'] ?? 0), $floorExtra);

        foreach ($rows as $codigo) {
            if (preg_match('/^DX(\d+)$/i', trim((string) $codigo), $m)) {
                $n = (int) $m[1];
                if ($n > $max) {
                    $max = $n;
                }
            }
        }

        return $max + 1;
    }

    /**
     * Cartório do número de DXF: o Access (ufdxf) pede aqui o próximo Controle para
     * os dois lados compartilharem a MESMA numeração global (igual ao Ref).
     * Serializa com GET_LOCK. Aceita ?floor=N (MAX(Controle) atual do Access).
     * Devolve { "controle": N, "codigo": "DX000N" }.
     */
    public function nextDxf()
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();
        $floor = (int) (Request::query('floor') ?? 0);

        $pdo->query("SELECT GET_LOCK('solic_dxf', 10)")->fetchColumn();
        try {
            $n = $this->proximoNumeroDxfGlobal($floor);
        } finally {
            $pdo->query("SELECT RELEASE_LOCK('solic_dxf')")->fetchColumn();
        }

        return Json::return([
            'controle' => $n,
            'codigo'   => 'DX' . str_pad((string) $n, 4, '0', STR_PAD_LEFT),
        ], 200);
    }

    private function separarArquivosSolicitacao(array $arquivos): array
    {
        $separados = [
            'IMAGEM_PROJETO'      => [],
            'PACOTE_DXF'          => [],
            'ITENS_COMPRADOS_TXT' => [],
            'LISTA_MATERIAIS'     => [],
            'DESENHO_PDF'         => [],
            'OUTROS'              => []
        ];

        foreach ($arquivos as $arquivo) {
            $tipo = strtoupper(trim((string)($arquivo->tipo ?? '')));

            if (isset($separados[$tipo])) {
                $separados[$tipo][] = $arquivo;
                continue;
            }

            $separados['OUTROS'][] = $arquivo;
        }

        return $separados;
    }

    private function buscarArquivoSolicitacaoPorId(string $id)
    {
        $arquivos = SolicitacaoAnexoArquivo::select(['*'])
            ->where('id', '=', $id)
            ->finish() ?: [];

        return $arquivos[0] ?? null;
    }

    private function removerArquivosExistentesPorTipo(string $ref, string $tipo): array
    {
        $pdo = SolicitacaoAnexoArquivo::getPDO();

        $stmt = $pdo->prepare("
            SELECT *
            FROM bd_device_request.solicitacao_anexo_arquivos
            WHERE ref = :ref
            AND tipo = :tipo
        ");

        $stmt->execute([
            ':ref'  => $ref,
            ':tipo' => $tipo
        ]);

        $arquivos = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        if (empty($arquivos)) {
            return [];
        }

        $arquivosFisicosParaRemover = [];

        foreach ($arquivos as $arquivo) {
            $arquivoId = $arquivo->id ?? null;

            if (!$arquivoId) {
                continue;
            }

            $caminhoFisico = $this->resolverCaminhoArquivo($arquivo->caminho ?? '');

            if (!empty($caminhoFisico)) {
                $arquivosFisicosParaRemover[] = $caminhoFisico;
            }

            if ($tipo === 'ITENS_COMPRADOS_TXT') {
                $deleteItens = $pdo->prepare("
                    DELETE FROM bd_device_request.solicitacao_itens_comprados
                    WHERE arquivo_id = :arquivo_id
                ");

                $deleteItens->execute([
                    ':arquivo_id' => $arquivoId
                ]);
            }

            $deleteArquivo = $pdo->prepare("
                DELETE FROM bd_device_request.solicitacao_anexo_arquivos
                WHERE id = :id
            ");

            $deleteArquivo->execute([
                ':id' => $arquivoId
            ]);
        }

        return $arquivosFisicosParaRemover;
    }

    private function salvarArquivoSolicitacao(
        string $cargaId,
        string $ref,
        array $arquivo,
        string $tipo,
        string $diretorioFisico,
        string $diretorioRelativo,
        string $usuarioLogado,
        ?string $codigo = null
    ): array {
        if (!$this->arquivoValido($arquivo)) {
            throw new \Exception("Arquivo inválido para o tipo {$tipo}.");
        }

        $nomeOriginal = $arquivo['name'];

        // Storage do web na ARQUITETURA DO ACCESS (mesma p/ storage e storage-mapped).
        // ($diretorioFisico/$diretorioRelativo recebidos ficam só por compatibilidade.)
        [$subpasta, $nomeArquivo] = $this->caminhoAccess($tipo, $ref, $codigo, $nomeOriginal);

        $dirStorage = $this->storageBase() . '/' . $subpasta;
        if (!is_dir($dirStorage)) {
            mkdir($dirStorage, 0777, true);
        }

        $caminhoFisico   = $dirStorage . '/' . $nomeArquivo;
        $caminhoRelativo = $subpasta . '/' . $nomeArquivo;

        if (!move_uploaded_file($arquivo['tmp_name'], $caminhoFisico)) {
            throw new \Exception("Não foi possível mover o arquivo {$nomeOriginal}.");
        }

        // Salva também no storage-mapped (mesma estrutura) para o Access enxergar
        $this->espelharNoMapeado($subpasta, $nomeArquivo, $caminhoFisico);

        $saveArquivo = SolicitacaoAnexoArquivo::create([
            'carga_id'      => $cargaId,
            'ref'           => $ref,
            'tipo'          => $tipo,
            'codigo'        => $codigo,
            'nome_original' => $nomeOriginal,
            'nome_arquivo'  => $nomeArquivo,
            'caminho'       => $caminhoRelativo,
            'mime_type'     => $arquivo['type'] ?? null,
            'tamanho_bytes' => $arquivo['size'] ?? null,
            'created_by'    => $usuarioLogado
        ]);

        if (!$saveArquivo || empty($saveArquivo['id'])) {
            throw new \Exception("Não foi possível salvar o registro do arquivo {$nomeOriginal}.");
        }

        return [
            'id'               => $saveArquivo['id'],
            'codigo'           => $codigo,
            'nome_original'    => $nomeOriginal,
            'nome_arquivo'     => $nomeArquivo,
            'caminho_fisico'   => $caminhoFisico,
            'caminho_relativo' => $caminhoRelativo,
            'tipo'             => $tipo
        ];
    }

    private function salvarItensCompradosDoTxt(
        string $cargaId,
        string $arquivoId,
        string $ref,
        string $caminhoFisico,
        string $usuarioLogado
    ): void {
        if (!file_exists($caminhoFisico)) {
            return;
        }

        $conteudo = file_get_contents($caminhoFisico);

        if ($conteudo === false || trim($conteudo) === '') {
            return;
        }

        $conteudo = $this->normalizarEncodingTexto($conteudo);

        $linhas = preg_split('/\r\n|\r|\n/', $conteudo);

        if (!$linhas) {
            return;
        }

        foreach ($linhas as $linha) {
            $linhaOriginal = trim($linha);

            if ($linhaOriginal === '') {
                continue;
            }

            $item = $this->parseLinhaItemComprado($linhaOriginal);

            if (
                empty($item['codigo']) &&
                empty($item['rev']) &&
                empty($item['descricao']) &&
                empty($item['quantidade']) &&
                empty($item['tipo'])
            ) {
                continue;
            }

            SolicitacaoItemComprado::create([
                'carga_id'       => $cargaId,
                'arquivo_id'     => $arquivoId,
                'ref'            => $ref,
                'codigo'         => $item['codigo'],
                'rev'            => $item['rev'],
                'descricao'      => $item['descricao'],
                'quantidade'     => $item['quantidade'],
                'tipo'           => $item['tipo'],
                'linha_original' => $linhaOriginal,
                'created_by'     => $usuarioLogado
            ]);
        }
    }

    private function parseLinhaItemComprado(string $linha): array
    {
        $linha = str_replace("\xc2\xa0", ' ', $linha);
        $linha = trim($linha);

        $partes = preg_split('/\t+|\s{2,}/u', $linha);

        $partes = array_values(array_filter(array_map('trim', $partes), function ($parte) {
            return $parte !== '';
        }));

        $item = [
            'codigo'     => '',
            'rev'        => '',
            'descricao'  => '',
            'quantidade' => '',
            'tipo'       => '',
        ];

        if (count($partes) === 0) {
            return $item;
        }

        $item['codigo'] = $partes[0] ?? '';
        $item['rev'] = $partes[1] ?? '';

        $indiceQuantidade = null;

        foreach ($partes as $index => $parte) {
            if ($index <= 1) {
                continue;
            }

            if ($this->ehQuantidade($parte)) {
                $indiceQuantidade = $index;
                break;
            }
        }

        if ($indiceQuantidade !== null) {
            $descricaoPartes = array_slice($partes, 2, $indiceQuantidade - 2);
            $tipoPartes = array_slice($partes, $indiceQuantidade + 1);

            $item['descricao'] = trim(implode(' ', $descricaoPartes));
            $item['quantidade'] = $partes[$indiceQuantidade] ?? '';
            $item['tipo'] = trim(implode(' ', $tipoPartes));
        } else {
            $descricaoPartes = array_slice($partes, 2);
            $item['descricao'] = trim(implode(' ', $descricaoPartes));
        }

        return $item;
    }

    private function ehQuantidade(string $valor): bool
    {
        $valor = trim($valor);

        if ($valor === '') {
            return false;
        }

        return (bool) preg_match('/^-?\d+([,.]\d+)?$/', $valor)
            || (bool) preg_match('/^-?\d{1,3}(\.\d{3})+([,.]\d+)?$/', $valor);
    }

    private function normalizarFilesArray(?array $files): array
    {
        if (empty($files)) {
            return [];
        }

        if (!isset($files['name'])) {
            return [];
        }

        if (!is_array($files['name'])) {
            return [$files];
        }

        $arquivos = [];

        foreach ($files['name'] as $index => $name) {
            $arquivos[] = [
                'name'     => $files['name'][$index] ?? null,
                'type'     => $files['type'][$index] ?? null,
                'tmp_name' => $files['tmp_name'][$index] ?? null,
                'error'    => $files['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size'     => $files['size'][$index] ?? 0,
            ];
        }

        return $arquivos;
    }

    private function arquivoValido(?array $arquivo): bool
    {
        if (empty($arquivo)) {
            return false;
        }

        if (!isset($arquivo['error'])) {
            return false;
        }

        if ((int)$arquivo['error'] !== UPLOAD_ERR_OK) {
            return false;
        }

        if (empty($arquivo['tmp_name'])) {
            return false;
        }

        if (!is_uploaded_file($arquivo['tmp_name'])) {
            return false;
        }

        return true;
    }

    private function validarExtensaoArquivo(array $arquivo, array $extensoesPermitidas, string $descricao): void
    {
        $nome = $arquivo['name'] ?? '';
        $extensao = strtolower(pathinfo($nome, PATHINFO_EXTENSION));

        if (!in_array($extensao, $extensoesPermitidas, true)) {
            throw new \Exception("Arquivo inválido para {$descricao}. Extensão enviada: {$extensao}.");
        }
    }

    /** Base física do storage do web. */
    private function storageBase(): string
    {
        return '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files';
    }

    /**
     * Subpasta + nome do arquivo na ARQUITETURA DO ACCESS (igual ao VBA). A mesma
     * estrutura vale para o storage do web e para o storage-mapped.
     * Retorna [subpasta, nomeArquivo].
     */
    private function caminhoAccess(string $tipo, string $ref, ?string $codigo, string $nomeOriginal): array
    {
        $sl  = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT);
        $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));
        $cod = trim((string) $codigo);

        switch ($tipo) {
            case 'IMAGEM_PROJETO':
                return ['.img_sl', $sl . '.jpg'];                                  // .img_sl\SL0001.jpg
            case 'DESENHO_PDF':
                $c = $cod !== '' ? $cod : pathinfo($nomeOriginal, PATHINFO_FILENAME);
                return ['.desenhos', $sl . ' - ' . $c . '.pdf'];                   // .desenhos\SL0001 - COD.pdf
            case 'PACOTE_DXF':
                return ['.dxf', ($cod !== '' ? $cod : $sl) . '.zip'];              // .dxf\DX0001.zip
            case 'ITENS_COMPRADOS_TXT':
                // Access não guarda o TXT (vira linhas); mantém um nome único aqui
                return ['itens_comprados', $sl . '_' . $this->gerarNomeArquivoSeguro($ref, $tipo, $ext ?: 'txt')];
            default:
                $pasta = strtolower(preg_replace('/[^a-z0-9_]+/i', '_', $tipo));
                return [$pasta, $this->gerarNomeArquivoSeguro($ref, $tipo, $ext)];
        }
    }

    /**
     * Espelha um arquivo já gravado no storage para o storage-mapped (mesma
     * subpasta/nome), para o Access enxergar. Não faz nada se APP_STORAGE_MAPPED
     * não estiver configurado.
     */
    private function espelharNoMapeado(string $subpasta, string $nomeArquivo, string $caminhoFisicoStorage): void
    {
        if (!is_file($caminhoFisicoStorage)) {
            return;
        }
        $base = rtrim($_ENV['APP_STORAGE_MAPPED'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') {
            return;
        }
        $dir = $base . '/' . $subpasta;
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
        }
        @copy($caminhoFisicoStorage, $dir . '/' . $nomeArquivo);
    }

    private function gerarNomeArquivoSeguro(string $ref, string $tipo, string $extensao): string
    {
        $tipo = strtolower($tipo);
        $tipo = preg_replace('/[^a-z0-9_]+/', '_', $tipo);

        $extensao = strtolower($extensao);
        $extensao = preg_replace('/[^a-z0-9]+/', '', $extensao);

        $hash = bin2hex(random_bytes(8));
        $data = date('Ymd_His');

        if ($extensao) {
            return "{$ref}_{$tipo}_{$data}_{$hash}.{$extensao}";
        }

        return "{$ref}_{$tipo}_{$data}_{$hash}";
    }

    private function resolverCaminhoArquivo(string $caminho): ?string
    {
        $caminho = trim($caminho);

        if ($caminho === '') {
            return null;
        }

        if (file_exists($caminho)) {
            return $caminho;
        }

        $base = '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files';

        $caminhoLimpo = ltrim($caminho, '/');

        $possiveis = [
            $base . '/' . $caminhoLimpo,
            '/var/www/htdocs/' . $caminhoLimpo,
            dirname(__DIR__, 3) . '/' . $caminhoLimpo
        ];

        foreach ($possiveis as $possivel) {
            if (file_exists($possivel)) {
                return $possivel;
            }
        }

        return null;
    }

    private function normalizarEncodingTexto(string $conteudo): string
    {
        if (function_exists('mb_detect_encoding')) {
            $encoding = mb_detect_encoding($conteudo, ['UTF-8', 'Windows-1252', 'ISO-8859-1'], true);

            if ($encoding && strtoupper($encoding) !== 'UTF-8') {
                return mb_convert_encoding($conteudo, 'UTF-8', $encoding);
            }

            return $conteudo;
        }

        $convertido = @iconv('Windows-1252', 'UTF-8//IGNORE', $conteudo);

        if ($convertido !== false && trim($convertido) !== '') {
            return $convertido;
        }

        return $conteudo;
    }

    private function podeCarregarArquivos($solicitacao): bool
    {
        $statusConceito = strtoupper(trim((string)($solicitacao->status_conceito ?? $solicitacao->conceito_status ?? '')));
        $statusDetalhe  = strtoupper(trim((string)($solicitacao->status_detalhe ?? $solicitacao->detalhamento_status ?? '')));

        return $statusConceito === 'OK' && $statusDetalhe === 'OK';
    }

    private function usuarioLogado(): string
    {
        // Nome no formato do Access (casa por e-mail); cai no nome da sessão se não achar.
        return Usuario::nomeNoAccess();
    }
}
```

---

## `src/app/controllers/SolicitacaoController.php`

```php
<?php
namespace src\app\controllers;

use src\app\database\entities\Conta;
use src\app\database\entities\Estagio;
use src\app\database\entities\Vagao;
use src\app\database\entities\Usuario;
use src\app\database\entities\Solicitacao;
use src\app\database\entities\Historico;
use src\app\database\entities\Projeto;
use src\app\requests\solicProjeto\StoreRequest;
use src\support\Request;
use src\support\Json;
use src\support\View;
use DateTime;
use src\app\database\entities\Acompanhamento;
use src\app\database\entities\Requisito;
use src\app\database\entities\Anexo;
use src\app\requests\historico\HistoricoRequest;

class SolicitacaoController
{
    public static $USUARIO_LOGADO = null;

    /**
     * Exibe a view principal de cadastro e listagem de usuários.
     *
     * @return View Retorna a view 'parametrizacao.usuario' com a lista de todos os usuários.
     */
    function solicitacaoView(): View
    {

        if (isset($_SESSION['user']['nome'])) {
            $nomeDoUsuario = $_SESSION['user']['nome'];
            self::$USUARIO_LOGADO = $nomeDoUsuario;
        }

        $date = new DateTime();
        $todayIs = $date->format('Y-m-d');
        $role = Usuario::getSolicRole($nomeDoUsuario);
        $contas = Conta::getContasByRole($role);
        $nSl = Solicitacao::getNumSL();



        return view('solicitacao.solicitacao', [

            "estagios" => Estagio::getAll(),
            "vagoesInfos" => Vagao::getDistinctWagons(),
            "contas" => $contas,
            "solicitante" => $nomeDoUsuario,
            "todayIs" => $todayIs,
            "nSL" => $nSl
        ]);
    }


    function menuParametrizacaoView(): View
    {


        return view('menus.menuParametrizacao', []);
    }


    function modalConfirmZ(): View
    {

        return view('modals.codigoZ.modal', []);
    }

    function modalValidacao(string $ref): View
    {

        return view('modals.validacao.modal', [
            'ref' => $ref
        ]);
    }


    function modalAnexos(string $ref): View
    {
        $anexos = Anexo::getAnexosTratados($ref);
        return view('modals.anexos.modal', [
            'ref' => $ref,
            'anexos' => $anexos
        ]);
    }
    function modalRequisitos(string $ref): View
    {
     
        return view('modals.requisitos.modal', [
            'ref' => $ref,
            'requisitos' => Requisito::getAllByRef($ref)   
            ]);
    }

    function modalCancelarSl(string $ref): View

    {

        return view('modals.cancelaSl.modal', [

            'ref' => $ref

        ]);
    }


    function getProjectInfos()
    {
        $projectNumberRaw = Request::query('projectNumber');

        $projectNumber = ltrim($projectNumberRaw, 'Zz');



        $infos = Projeto::getProjectInfos($projectNumber);
        if (!$infos) {
            return Json::return([
                'message' => 'Código Z não encontrado',
                'infos' => null
            ], 404);
        }

        $status = Projeto::getProjectStatus($projectNumber);

        return Json::return([
            'message' => 'Código Z encontrado',
            'infos' => $infos,
            'status' => $status
        ], 200);
    }

    function getRole()
    {
        $nomeSolic = Request::query('solic');

        $role = Usuario::getSolicRole($nomeSolic);
        if (!$role) {
            return Json::return([
                'message' => 'Usuário não encontrado',
                'role' => null
            ], 404);
        }

        return Json::return([
            'message' => 'Usuário encontrado',
            'role' => $role
        ], 200);
    }



    function storeSolicitacao(StoreRequest $request)
    {

        $data2Save = $request->getSolicitacaoData();
        $requisitos2save = $request->getRequisitosData();
        $anexos2save = $request->getAnexosData();
        $fila2save = $request->getFilaData();
        $numSL = Solicitacao::getNumSL();
        $data2Save['ref'] = $numSL;
        $solicitacao = Solicitacao::create($data2Save);

        if (!$solicitacao) {
            return redirect()->route("dispositivos.solicitacao")->withError("Não foi possível salvar o registro");
        }

        if ($solicitacao) {
            $executeFila = Solicitacao::storeFila($fila2save, $solicitacao['ref'], 'bd_device_request.fila');
            $executeRequisitos = Solicitacao::storeRepeticao($requisitos2save, $solicitacao['ref'], 'bd_device_request.requisitos');
            $executeAnexos = Solicitacao::storeRepeticao($anexos2save, $solicitacao['ref'], 'bd_device_request.anexos');

            // Copia os anexos para a pasta do Access (web -> Access)
            $this->copiarAnexosParaAccess($solicitacao['ref'], $anexos2save);
            $executeHistorico = Historico::create([
                'ref' => $solicitacao['ref'],
                'mensagem'       => $solicitacao['escopo'],
                'usuario'        => $_SESSION['usuarioNome'],
            ]);

            if (!$executeRequisitos || !$executeAnexos || !$executeFila)
                return redirect()->route("dispositivos.solicitacao")->withError("Solicitação salva, mas **falha** ao salvar os campos dinâmicos.");
        }

        
        return redirect()->route("dispositivos.acompanhamento")->withSuccess("Registro salvo! 🎉");
    }

    /**
     * Copia os anexos enviados pela web para a pasta do Access (pasta mapeada/montada).
     * 1º PDF -> .Files/SL{ref}.pdf (o que o Access abre); os demais -> .Files/SL{ref}/.
     */
    private function copiarAnexosParaAccess($ref, array $anexos): void
    {
        if (empty($anexos)) return;

        $base = rtrim($_ENV['APP_STORAGE_MAPPED'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') return; // sem storage-mapped configurado -> não faz nada

        $filesDir = $base . '/.Files';
        if (!is_dir($filesDir)) @mkdir($filesDir, 0777, true);

        $refFmt = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT); // ex.: SL4001
        $pdfPrincipalUsado = false;

        foreach ($anexos as $a) {
            $origem = $a['anexo'] ?? '';
            if ($origem === '' || !is_file($origem)) continue;

            $ext = strtolower(pathinfo($origem, PATHINFO_EXTENSION));

            if (!$pdfPrincipalUsado && $ext === 'pdf') {
                @copy($origem, $filesDir . '/' . $refFmt . '.pdf');   // .Files/SL{ref}.pdf
                $pdfPrincipalUsado = true;
            } else {
                $sub = $filesDir . '/' . $refFmt;
                if (!is_dir($sub)) @mkdir($sub, 0777, true);
                @copy($origem, $sub . '/' . basename($origem));       // extras em .Files/SL{ref}/
            }
        }
    }


    /**
     * Recebe uma solicitação criada no Access (VBA), gera o Ref no MySQL
     * de forma atômica (GET_LOCK) e grava em solicitacoes + fila.
     * Devolve { "ref": NNNN } para o VBA usar no INSERT do Access.
     */
    function salvarVba()
    {
        $pdo = Solicitacao::getPDO();

        $dataSql = $this->dataBR2SQL(Request::input('data_solicitacao'));

        try {
            // Serializa a emissão do número NESTA conexão (evita Ref duplicado)
            $pdo->query("SELECT GET_LOCK('solic_ref', 10)")->fetchColumn();

            // Próximo Ref = MAX + 1
            $ref = (int) $pdo->query(
                "SELECT COALESCE(MAX(ref), 0) + 1 FROM bd_device_request.solicitacoes"
            )->fetchColumn();

            // Reserva o Ref já inserindo em solicitacoes (mesma conexão do lock)
            $stmt = $pdo->prepare(
                "INSERT INTO bd_device_request.solicitacoes
                 (id, ref, descricao, solicitante, data_solicitacao, cod_z, aplicacao, vagao, lote, conta, classe, escopo, created_at)
                 VALUES (:id, :ref, :descricao, :solicitante, :data_solicitacao, :cod_z, :aplicacao, :vagao, :lote, :conta, :classe, :escopo, :created_at)"
            );
            $stmt->execute([
                'id'               => \Ramsey\Uuid\Rfc4122\UuidV4::uuid4()->toString(),
                'ref'              => $ref,
                'descricao'        => Request::input('descricao'),
                'solicitante'      => Request::input('solicitante'),
                'data_solicitacao' => $dataSql,
                'cod_z'            => Request::input('cod_z'),
                'aplicacao'        => Request::input('aplicacao'),
                'vagao'            => Request::input('vagao'),
                'lote'             => Request::input('lote'),
                'conta'            => Request::input('conta'),
                'classe'           => Request::input('classe'),
                'escopo'           => Request::input('historico'),
                'created_at'       => date('Y-m-d H:i:s'),
            ]);
        } catch (\Exception $e) {
            $pdo->query("SELECT RELEASE_LOCK('solic_ref')")->fetchColumn();
            return Json::return(['error' => 'Falha ao gerar Ref: ' . $e->getMessage()], 500);
        }

        // Libera o lock assim que o Ref está reservado
        $pdo->query("SELECT RELEASE_LOCK('solic_ref')")->fetchColumn();

        // Grava na fila (status PENDENTE/PARADO via storeFila)
        Solicitacao::storeFila([
            'descricao'        => Request::input('descricao'),
            'solicitante'      => Request::input('solicitante'),
            'cod_z'            => Request::input('cod_z'),
            'aplicacao'        => Request::input('aplicacao'),
            'vagao'            => Request::input('vagao'),
            'lote'             => Request::input('lote'),
            'conta'            => Request::input('conta'),
            'classe'           => Request::input('classe'),
            'historico'        => Request::input('historico'),
            'data_solicitacao' => $dataSql,
            'prio'             => 99,
        ], $ref, 'bd_device_request.fila');

        // Histórico inicial (timeline) — mesma ideia do fluxo da web
        Historico::create([
            'ref'      => $ref,
            'usuario'  => Request::input('solicitante'),
            'mensagem' => Request::input('historico'),
        ]);

        return Json::return(['ref' => $ref], 200);
    }

    /**
     * Converte data do VBA para o MySQL.
     * Aceita 'DD/MM/YYYY' e 'DD/MM/YYYY HH:MM:SS'. Se já vier em
     * 'YYYY-MM-DD ...' (sem '/'), passa direto.
     */
    private function dataBR2SQL($valor)
    {
        if (empty($valor)) return null;
        $valor = trim($valor);
        $partes = explode(' ', $valor, 2);          // separa data e hora
        $d = explode('/', $partes[0]);
        if (count($d) !== 3) return $valor;          // já está em formato SQL
        $sql = sprintf('%04d-%02d-%02d', $d[2], $d[1], $d[0]);
        if (isset($partes[1]) && trim($partes[1]) !== '') $sql .= ' ' . trim($partes[1]);
        return $sql;
    }

    /**
     * Recebe o PDF da SL criada no Access (corpo binário cru), salva no storage
     * do web e registra na tabela anexos. Parâmetros: ?ref=NNN&nome=arquivo.pdf
     */
    function uploadAnexoVba()
    {
        $ref  = (int) (Request::query('ref') ?? 0);
        $nome = Request::query('nome') ?: ('SL' . $ref . '.pdf');
        if ($ref <= 0) return Json::return(['error' => 'ref inválido'], 400);

        $conteudo = file_get_contents('php://input');
        if ($conteudo === false || strlen($conteudo) === 0) {
            return Json::return(['error' => 'arquivo vazio'], 400);
        }

        // Storage do web (cria a pasta por ref)
        $base = rtrim($_ENV['APP_UPLOADS_DIR'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') $base = '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files';
        $dir = $base . '/' . $ref;
        if (!is_dir($dir)) @mkdir($dir, 0777, true);

        $nomeSeguro = 'SL' . $ref . '_' . basename($nome);
        $destino    = $dir . '/' . $nomeSeguro;

        if (file_put_contents($destino, $conteudo) === false) {
            return Json::return(['error' => 'falha ao salvar o arquivo'], 500);
        }

        // Registra em anexos (FK ref -> fila, que já existe via salvarVba)
        $pdo = Solicitacao::getPDO();
        $pdo->prepare(
            "INSERT INTO bd_device_request.anexos (id, ref, anexo, descricao, created_at)
             VALUES (:id, :ref, :anexo, :descricao, :created_at)"
        )->execute([
            'id'         => \Ramsey\Uuid\Rfc4122\UuidV4::uuid4()->toString(),
            'ref'        => $ref,
            'anexo'      => $destino,
            'descricao'  => 'PDF da solicitação (Access)',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return Json::return(['ok' => true, 'arquivo' => $nomeSeguro], 200);
    }

    /**
     * Recebe um comentário do Access e insere UMA linha em historico.
     * O texto completo é remontado por getAllTratado (não sobrescreve nada).
     * POST: ref, usuario, mensagem
     */
    function comentarVba()
    {
        $ref      = (int) (Request::input('ref') ?? 0);
        $usuario  = Request::input('usuario') ?? '';
        $mensagem = Request::input('mensagem') ?? '';

        if ($ref <= 0 || trim($mensagem) === '') {
            return Json::return(['error' => 'ref ou mensagem inválidos'], 400);
        }

        Historico::create([
            'ref'      => $ref,
            'usuario'  => $usuario,
            'mensagem' => $mensagem,
        ]);

        return Json::return(['ok' => true], 200);
    }

    /**
     * Atualiza campos de status da fila vindos do Access (cancelar/tryout/validar).
     * Só aceita as colunas de status (whitelist). POST: ref + status.
     */
    function atualizarStatusVba()
    {
        $ref = (int) (Request::input('ref') ?? 0);
        if ($ref <= 0) return Json::return(['error' => 'ref inválido'], 400);

        $permitidas = [
            'conceito_status', 'detalhamento_status', 'liberacao_status',
            'corte_status', 'exec_status', 'aquisicao_status', 'tryout_status',
        ];

        $dados = [];
        foreach ($permitidas as $col) {
            $v = Request::input($col);
            if ($v !== null && $v !== '') $dados[$col] = $v;
        }
        if (empty($dados)) return Json::return(['error' => 'nenhum status enviado'], 400);

        Acompanhamento::updateByRef($ref, $dados);

        return Json::return(['ok' => true, 'campos' => array_keys($dados)], 200);
    }


    /**
     * Carga inicial Access -> MySQL. Recebe UMA linha da Fila do Access (POST,
     * nomes de coluna do Access), mapeia e faz upsert por Ref em fila + solicitacoes.
     * Preserva o Ref existente (não gera número novo).
     */
    function migrarFila()
    {
        $pdo = Solicitacao::getPDO();

        $ref = (int) ($_POST['Ref'] ?? 0);
        if ($ref <= 0) return Json::return(['error' => 'Ref ausente ou invalido'], 400);

        // Access -> MySQL (tabela fila)
        $mapFila = [
            'Descricao' => 'descricao', 'Solicitante' => 'solicitante', 'Cod_Z' => 'cod_z',
            'Aplicacao' => 'aplicacao', 'Vagao' => 'vagao',
            'Conceito_P' => 'conceito_proj', 'Conceito_St' => 'conceito_status',
            'Conceito_Ini' => 'conceito_inicio', 'Conceito_Fim' => 'conceito_fim',
            'Det_P' => 'detalhamento_proj', 'Det_St' => 'detalhamento_status',
            'Det_Ini' => 'detalhamento_inicio', 'Det_Fim' => 'detalhamento_fim',
            'Liberacao_St' => 'liberacao_status', 'Liberacao_Data' => 'liberacao_data',
            'Corte_St' => 'corte_status', 'Corte_Data' => 'corte_data',
            'Exec_St' => 'exec_status', 'Exec_Data' => 'exec_data',
            'Tryout_St' => 'tryout_status', 'Tryout_Data' => 'tryout_data',
            'Aq_St' => 'aquisicao_status', 'Aq_Data' => 'aquisicao_data',
            'Data_Solicitacao' => 'data_solicitacao', 'Historico' => 'historico',
            'Lote' => 'lote', 'Prio' => 'prio', 'Classe' => 'classe', 'NumSfpCC' => 'conta',
        ];

        $fila = [];
        foreach ($mapFila as $acc => $my) {
            if (array_key_exists($acc, $_POST)) {
                $v = $_POST[$acc];
                $fila[$my] = ($v === '' ? null : $v);
            }
        }
        $this->upsert($pdo, 'bd_device_request.fila', 'ref', $ref, $fila);

        // Núcleo em solicitacoes (mantém o contador MAX(ref) correto)
        $solic = [];
        foreach (['descricao','solicitante','cod_z','aplicacao','vagao','lote','conta','classe','data_solicitacao'] as $c) {
            if (array_key_exists($c, $fila)) $solic[$c] = $fila[$c];
        }
        $this->upsert($pdo, 'bd_device_request.solicitacoes', 'ref', $ref, $solic);

        return Json::return(['ref' => $ref, 'ok' => true], 200);
    }

    /** Upsert genérico por chave: atualiza se existe, insere (com id uuid + created_at) se não. */
    private function upsert($pdo, string $table, string $key, $keyVal, array $data): void
    {
        unset($data[$key]);

        $chk = $pdo->prepare("SELECT 1 FROM {$table} WHERE {$key} = ? LIMIT 1");
        $chk->execute([$keyVal]);

        if ($chk->fetch()) {
            if (empty($data)) return;
            $sets = [];
            $params = [];
            foreach ($data as $col => $v) {
                $sets[] = "{$col} = :{$col}";
                $params[":{$col}"] = $v;
            }
            $params[':__k'] = $keyVal;
            $pdo->prepare("UPDATE {$table} SET " . implode(', ', $sets) . " WHERE {$key} = :__k")
                ->execute($params);
        } else {
            $data[$key]        = $keyVal;
            $data['id']        = \Ramsey\Uuid\Rfc4122\UuidV4::uuid4()->toString();
            $data['created_at'] = date('Y-m-d H:i:s');
            $cols = array_keys($data);
            $params = [];
            foreach ($data as $col => $v) $params[":{$col}"] = $v;
            $pdo->prepare("INSERT INTO {$table} (" . implode(', ', $cols) . ") VALUES (:" . implode(', :', $cols) . ")")
                ->execute($params);
        }
    }

    public function trataCSV(){


        try {
            if (ob_get_level()) ob_end_clean();

            // 2. Força cabeçalhos de "Não Cachear" para o Navegador/VBA
            header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
            header("Cache-Control: post-check=0, pre-check=0", false);
            header("Pragma: no-cache");
            header("Expires: Wed, 11 Jan 1984 05:00:00 GMT");
            // set_time_limit(300); // 5 minutos
            ini_set('memory_limit', '512M');

            $solicitacoes = Acompanhamento::getAllTratado();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=Fila.csv');

            //abre o arquivo
            $file  = fopen('php://output', 'w');
            //trata utf-8
            fputs($file, "\xEF\xBB\xBF");
            
            //cabeçalhos do meu arquivo
            $cabecalhos = [
                'Ref', 'Descricao', 'Solicitante', 'Cod_Z', 'Aplicacao', 'Vagao', 'Conceito_P',
                'Conceito_St', 'Conceito_Ini', 'Conceito_Fim', 'Det_P', 'Det_St',
                'Det_Ini', 'Det_Fim', 'Liberacao_St', 'Liberacao_Data', 'Corte_St',
                'Corte_Data', 'Exec_St', 'Exec_Data', 'Tryout_St', 'Tryout_Data',
                'Data_Solicitacao', 'Historico', 'Lote', 'Prio', 'Classe', 'Aq_St',
                'Aq_Data', 'Tempo_Modelo', 'Tempo_Det', 'Tempo_Fila_Det', 'Tempo_Fila_Lib',
                'Executor_EI', 'Data_Inicio_EI', 'Data_Fim_EI', 'Status_EI', 'Recebido_EI',
                'RVD', 'Obs_Aquisicao', 'TAG', 'Pendencia', 'Responsavel', 'Setor_Pendencia',
                'N_Pasta', 'Requisitos', 'CK3D', 'CKDet', 'CKReq', 'TempoTarefa',
                'PrioTarefa', 'IniTarefa', 'complexidade', 'FimTarefa', 'EquipeEI',
                'Liberacao', 'Natureza', 'DescricaoServico', 'NumSfpCC'
            ];

            fputcsv($file, $cabecalhos, ';');


            $formatarData = function ($valor) {
                if (empty($valor) || $valor == '0000-00-00') return '';
                try {
                    $date = new \DateTime($valor);
                    return $date->format('d/m/Y');
                } catch (\Exception $e) {
                    return $valor;
                    }
                    };

            foreach ($solicitacoes as $solicitacao) {
                $limpar = function ($texto) {
                    if (empty($texto)) return '';
                    // Remove quebras de linha (Windows e Linux) e troca por espaço
                    $texto = str_replace(["\r\n", "\r", "\n"], " ", $texto);
                    // Remove pontos e vírgula para não confundir o delimitador do CSV
                    $texto = str_replace(";", ",", $texto);
                    return $texto;
                };

                // Para o HISTÓRICO: preserva as quebras de linha como token [BR]
                // (o VBA troca [BR] por quebra de linha ao gravar no Access -> multilinha)
                $histAccess = function ($texto) {
                    if (empty($texto)) return '';
                    $texto = str_replace(["\r\n", "\r", "\n"], "[BR]", $texto);
                    $texto = str_replace(";", ",", $texto);
                    return $texto;
                };

                
                $novoRegistro = [
                    $solicitacao->ref ?? '',
                    // $solicitacao->descricao ?? '',
                    $limpar($solicitacao->descricao ?? ''),
                    $solicitacao->solicitante ?? '',
                    $solicitacao->cod_z ?? '',
                    $solicitacao->aplicacao ?? '',
                    $solicitacao->vagao ?? '',
                    $solicitacao->conceito_proj ?? '',
                    $solicitacao->conceito_status ?? 'PENDENTE',
                    $solicitacao->conceito_inicio ?? '',
                    $solicitacao->conceito_fim ?? '',
                    $solicitacao->detalhamento_proj ?? '',
                    $solicitacao->detalhamento_status ?? 'PENDENTE',
                    $solicitacao->detalhamento_inicio ?? '',
                    $solicitacao->detalhamento_fim ?? '',
                    $solicitacao->liberacao_status ?? 'PENDENTE',
                    $solicitacao->liberacao_data ?? '',
                    $solicitacao->corte_status ?? 'PARADO',
                    $solicitacao->corte_data ?? '',
                    $solicitacao->exec_status ?? 'PARADO',
                    $solicitacao->exec_data ?? '',
                    $solicitacao->tryout_status ?? 'PENDENTE',
                    $solicitacao->tryout_data ?? '',
                    $formatarData($solicitacao->data_solicitacao ?? ''),
                    $histAccess($solicitacao->historico ?? ''),
                    $solicitacao->lote ?? '',
                    $solicitacao->prio ?? '99',
                    $solicitacao->classe ?? '',
                    $solicitacao->aquisicao_status ?? 'PENDENTE',
                    $solicitacao->aquisicao_data ?? '',
                    $solicitacao->tempo_modelo ?? '',
                    $solicitacao->tempo_det ?? '',
                    $solicitacao->tempo_fila_det ?? '',
                    $solicitacao->tempo_fila_lib ?? '',
                    $solicitacao->executor_ei ?? '',
                    $solicitacao->data_inicio_ei ?? '',
                    $solicitacao->data_fim_ei ?? '',
                    $solicitacao->status_ei ?? '',
                    $solicitacao->recebido_ei ?? '',
                    $solicitacao->rvd ?? '',
                    $solicitacao->obs_aquisicao ?? '',
                    $solicitacao->tag ?? '',
                    $solicitacao->pendencia ?? '',
                    $solicitacao->responsavel ?? '',
                    $solicitacao->setor_pendencia ?? '',
                    $solicitacao->n_pasta ?? '',
                    $solicitacao->requisitos ?? '',
                    $solicitacao->ck3d ?? '',
                    $solicitacao->ckdet ?? '',
                    $solicitacao->ckreq ?? '',
                    $solicitacao->tempotarefa ?? '',
                    $solicitacao->prio ?? '',
                    $solicitacao->initarefa ?? '',
                    $solicitacao->complexidade ?? '',
                    $solicitacao->fimtarefa ?? '',
                    $solicitacao->equipeei ?? '',
                    $solicitacao->liberacao ?? '',
                    $solicitacao->natureza ?? '',
                    $solicitacao->descricaoservico ?? '',
                    $solicitacao->conta ?? ''
                ];

                fputcsv($file, $novoRegistro, ';');
            }

            fclose($file);
            exit;
        } catch (\Exception $e) {
            return "Erro ao gerar CSV: " . $e->getMessage();
        }

      
    }




    public function trataProjetosCSV()
    {
        try {
            if (ob_get_level()) ob_end_clean();
            
            // Headers anti-cache e tipo de arquivo
            header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
            header("Pragma: no-cache");
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=Projetos.csv');
            $projetos = Projeto::getInfoProjetos2CSV();
            $file = fopen('php://output', 'w');
            fputs($file, "\xEF\xBB\xBF"); // BOM UTF-8

            $cabecalhos = [
                'Controle', 'EAP', 'Solicitante', 'Data_solic', 'Descricao', 'Vagao',
                'Complexidade', 'Prioridade', 'Horas', 'Data_Inicio', 'Data_Fim',
                'Data_R_Inicio', 'Data_R_Fim', 'Projetista', 'Cod_Projeto', 'Status',
                'SEG', 'ERG', 'PROD', 'Observacao', 'Justificativa', 'Objetivo',
                'Beneficios', 'Produto', 'Requisitos', 'Stakeholder', 'Equipe',
                'Premissas', 'Entregas', 'Restricoes', 'Riscos', 'Prazos', 'Custos',
                'Data_Desenhos_EI', 'Executor_EI', 'Data_Inicio_EI', 'Data_Fim_EI',
                'Status_EI', 'Recebido_EI', 'RVD_EI', 'Data_Recebido_EI', 'Status_KB',
                'Conceito_KB', 'Modelamento_KB', 'Detalhamento_KB', 'Revisao_KB',
                'Licoes_Aprendidas', 'Comentarios', 'Lote'
            ];
            fputcsv($file, $cabecalhos, ';');

            $limpar = function ($texto) {
                if (empty($texto)) return '';
                $texto = str_replace(["\r\n", "\r", "\n"], " ", $texto);
                $texto = str_replace(";", ",", $texto);
                return trim($texto);
            };

            $formatarData = function ($valor) {
                if (empty($valor) || $valor == '0000-00-00') return '';
                try {
                    return (new \DateTime($valor))->format('d/m/Y');
                } catch (\Exception $e) {
                    return $valor;
                }
            };
            foreach ($projetos as $projeto) {
                $registro = [
                    $projeto->cod_z ?? '',        
                    '',                        
                    $projeto->solicitante ?? '',     
                    $formatarData($projeto->created_at ?? ''),
                    $limpar($projeto->descricao ?? ''), 
                    $projeto->vagao ?? '',           
                    '', '', '', '', '', '', '', '', '', '', 
                    0, 0, 0,                  
                    '', '', '', '', '', '', '', '', '', '', '', '', '', 
                    '', '', '', '', '', '', '', '', '', 
                    '',                       
                    '',                        
                    0, 0, 0, 0,               
                    '', '',                   
                    $projeto->lote ?? ''          
                ];

                fputcsv($file, $registro, ';');
            }
            fclose($file);
            exit; 
        } catch (\Exception $e) {
            http_response_code(500);
           dd("Erro interno: " . $e->getMessage());
            exit; 
        }
    }



    /**
     * Access -> Web: recebe a lista de usuários do Access (tabela Solicitantes:
     * Email + Nome) e regrava `solicitantes_access`. Serve para casar o autor do
     * histórico pelo e-mail (ver Usuario::nomeNoAccess). Cria a tabela se não existir.
     * POST form-urlencoded: dados = "email<TAB>nome" por linha.
     */
    public function uploadSolicitantesVba()
    {
        $dados = (string) (Request::input('dados') ?? '');

        $regs = [];
        foreach (preg_split('/\r\n|\r|\n/', $dados) as $linha) {
            if (trim($linha) === '') {
                continue;
            }
            $c = explode("\t", $linha);
            $email = strtolower(trim($c[0] ?? ''));
            $nome  = trim($c[1] ?? '');
            if ($email !== '' && $nome !== '') {
                $regs[$email] = $nome; // dedup por e-mail
            }
        }

        $pdo = null;
        try {
            $pdo = Solicitacao::getPDO();

            $pdo->exec("
                CREATE TABLE IF NOT EXISTS bd_device_request.solicitantes_access (
                    email VARCHAR(255) NOT NULL PRIMARY KEY,
                    nome  VARCHAR(255) NOT NULL
                )
            ");

            if (!$pdo->inTransaction()) {
                $pdo->beginTransaction();
            }
            $pdo->exec("DELETE FROM bd_device_request.solicitantes_access");

            $stmt = $pdo->prepare("INSERT INTO bd_device_request.solicitantes_access (email, nome) VALUES (:e, :n)");
            $n = 0;
            foreach ($regs as $email => $nome) {
                $stmt->execute([':e' => $email, ':n' => $nome]);
                $n++;
            }
            $pdo->commit();

            return Json::return(['ok' => true, 'usuarios' => $n], 200);
        } catch (\Throwable $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Erro no uploadSolicitantesVba: " . $e->getMessage());
            return Json::return(['error' => 'falha ao salvar solicitantes'], 500);
        }
    }

    public function updateSituacao(HistoricoRequest $request, int $ref)
    {
        try {
            $situacao = $request->input('situacao');
            $mensagemUsuario = $request->input('mensagem');

            if ($situacao === 'cancelar') {
                $updated = Acompanhamento::updateStatus($ref, [
                    'conceito_status',
                    'detalhamento_status',
                    'liberacao_status',
                    'corte_status',
                    'aquisicao_status',
                    'exec_status',
                    'tryout_status',
                ], 'CANCELADO');
            } 
            else if ($situacao === 'rejeitar') {
                Acompanhamento::updateStatus($ref, 'conceito_status', 'MODELO');
                $updated = Acompanhamento::updateStatus($ref, 'detalhamento_status', 'PENDENTE');
            } 
            else {
                $novoStatus = ($situacao === 'aprovar') ? 'EM ANDAMENTO' : 'PENDENTE';

                /*
                * Aqui precisa passar como string, não como array,
                * para o Acompanhamento::updateStatus conseguir aplicar
                * as regras automáticas, como preencher detalhamento_inicio.
                */
                $updated = Acompanhamento::updateStatus($ref, 'detalhamento_status', $novoStatus);
            }

            if (!$updated) {
                return redirect()->back()->withError("Erro ao processar a atualização da solicitação.");
            }

            [$statusMsg, $mensagemFinal] = match ($situacao) {
                'aprovar'  => ['success', 'Validação aprovada com sucesso!'],
                'rejeitar' => ['error',   'Validação rejeitada.'],
                'cancelar' => ['warning', 'Solicitação e todos os status relacionados foram cancelados.'],
                default    => ['success', 'Ação processada.']
            };

            $this->salvarHistoricoValidacao([
                'ref'      => $ref,
                'usuario'  => Usuario::nomeNoAccess(),  // autor no formato do Access (casa por e-mail)
                'mensagem' => $mensagemUsuario,
                'situacao' => $situacao
            ]);

            return redirect()
                ->route('dispositivos.acompanhamento.sl', ["ref" => $ref])
                ->with($statusMsg, $mensagemFinal);

        } catch (\Exception $e) {
            return redirect()->back()->withError("Erro crítico: " . $e->getMessage());
        }
    }
    private function salvarHistoricoValidacao(array $dados)
    {
        return Historico::create($dados, true);
    }



    function registraHistorico(HistoricoRequest $request, int $ref, string $tipo = null)
    {
        $dados = $request->get();
        $dados['usuario'] = Usuario::nomeNoAccess(); // autor no formato do Access (casa por e-mail)
        $execute = $this->salvarHistoricoValidacao($dados);

        if (!$execute)
            return redirect()->back()->withError("Não foi possível salvar a mensagem");

            $returnRota = match ($tipo) {
                'desenvolvimento' => 'dispositivos.desenvolvimento.info',
                default           => 'dispositivos.acompanhamento.sl'
            };

        return redirect()->route($returnRota, ['ref' => $ref])
            ->withSuccess("Mensagem enviada!");
    }
}
```

---

## `.env`

```ini


# APP_URL=http://localhost/action-itwalk

# DB_TYPE=mysql
# DB_HOST=localhost
# DB_NAME=firma
# DB_USER=root
# DB_PASSWORD=mySqlp@ss
# OFFSET_URI=1
# APP_LANGUAGE=pt-br
# APP_COMPANY=device

HOMOLOG = "dev"
PROD = "v2"


APP_ENVIRONMENT="http://172.29.5.2"
APP_COMPANY="device"
APP_DIR="solic_dispositivos"
APP_URL="${APP_ENVIRONMENT}/${APP_COMPANY}/${HOMOLOG}/${APP_DIR}"
APP_UPLOADS_DIR="/var/www/html/${APP_COMPANY}/${HOMOLOG}/${APP_DIR}-storage/"
APP_UPLOADS_EXCEL=/var/www/html/greenbrier/v2/solic_dispositivos-excel/Fila.xlsx
# -excel = SÓ o mapeamento da pasta do banco (K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB, o .accdb). NÃO é o espelho de arquivos.
APP_ACCESS_DIR=/var/www/html/greenbrier/v2/solic_dispositivos-excel
# Espelho dos arquivos na ARQUITETURA DO ACCESS (subpastas .img_sl/.desenhos/.dxf/.Files/...).
# O web salva no storage próprio E aqui; você mapeia CADA subpasta daqui para a
# correspondente no Windows (K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl, etc.). Rode 1x a rota
# /dispositivos/desenvolvimento/garantirStorageMapeado p/ criar as subpastas.
APP_STORAGE_MAPPED=/var/www/html/greenbrier/v2/solic_dispositivos-storage-mapped
# Piso do contador global de DXF: defina = MAX(Controle) atual do DXF_Control do Access
# (rode no Access:  SELECT MAX(Controle) FROM DXF_Control;  e ponha o número aqui)
APP_DXF_FLOOR=0
APP_URL_DOWNLOAD="${APP_URL}-storage"
OFFSET_URI=3
APP_LANGUAGE="pt-br"

# DB_HOMOLOG = "configuracoes59.php"
DB_HOMOLOG = "configuracoes.php"


DB_DEVICE_REQUEST = "bd_device_request"
DB_FILE_INTRANET="/var/www/html/${APP_COMPANY}/includes/${DB_HOMOLOG}"
DB_FILE_INTRANET_ACCESS_CONTROL="/var/www/html/${APP_COMPANY}/includes/${DB_HOMOLOG}"
DB_FILE_WORKFLOW="/var/www/html/${APP_COMPANY}/includes/sqlserver_wf_prod.php"
DB_FILE_INFORMIX="/var/www/html/${APP_COMPANY}/includes/informix.php"
DB_FILE_SENIOR_GBMX="/var/www/html/${APP_COMPANY}/includes/senior_gbmx.php"

APP_DOWNLOAD_CSV = "${APP_ENVIRONMENT}/${APP_COMPANY}/${HOMOLOG}/${APP_DIR}-excel/Fila.csv"
```

---

# VBA — Lista de Solicitações de Projeto_RevE.xlsm

## `Funcoes`

```vb
Attribute VB_Name = "Funcoes"
Option Explicit

Public caminho_arquivo As String

Function resQuery(SQL As String) As Variant

Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String
Dim arrRst      As Variant




'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant
Dim cnn         As ADODB.Connection
Dim rst         As ADODB.Recordset
Dim MyConn      As String

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Set rst = cnn.Execute(SQL)

cnn.Close

End Function



Function AbreXLS()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos Excel, *.xlsx"
    FilterIndex = 3
    Title = "Selecione um arquivo Excel"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreXLS = Filename
    
End Function

Function AbreJPG()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    Filter = "Arquivos JPG, *.jpg; *.jpeg"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("D")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        ChDir ("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreJPG = Filename
End Function


Function AbreZIP()
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    Filter = "Arquivos ZIP, *.zip; *.rar"
    FilterIndex = 3
    Title = "Selecione um arquivo de Imagem"
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If

    With Application
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    AbreZIP = Filename
End Function

Public Function AbrePDF() As Variant
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename()      As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo PDF (*.pdf),*.pdf,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione os arquivos PDF"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    If caminho_arquivo <> "" Then
        ChDir (caminho_arquivo)
    Else
        'ChDir ("F:\eng_automacao\")
        ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\")
    End If
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename() = .GetOpenFilename(Filter, FilterIndex, Title, MultiSelect:=True)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If IsEmpty(Filename) Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    AbrePDF = Filename()
End Function

Public Function OpenTXTDialog() As String
    Dim Filter          As String
    Dim Title           As String
    Dim FilterIndex     As Integer
    Dim Filename        As Variant
    
    
    ' Define o filtro de procura dos arquivos
    Filter = "Arquivo TXT (*.txt),*.txt,"
    ' O filtro padrão é *.*
    FilterIndex = 3
    ' Define o Título (Caption) da Tela
    Title = "Selecione o Arquivo TXT com a BOM"
    ' Define o disco de procura
    'ChDrive ("F")
    ChDrive ("K")
    'ChDir ("F:\eng_automacao\15.BOMs\")
    ChDir ("K:\engenharia_automacao_e_processos\equipe_automacao\15.BOMs\")
    
    With Application
        ' Abre a caixa de diálogo para seleção do arquivo com os parâmetros
        Filename = .GetOpenFilename(Filter, FilterIndex, Title)
        ' Reseta o Path
        ChDrive (Left(.DefaultFilePath, 1))
        ChDir (.DefaultFilePath)
    End With
    ' Abandona ao Cancelar
    If Filename = False Then
        MsgBox "Nenhum arquivo foi selecionado."
        Exit Function
    End If
    ' Retorna o caminho do arquivo
    OpenTXTDialog = Filename
End Function
'==================== INTEGRACAO COM A WEB (MySQL) ====================
' Base da aplicacao web (mesma do workbook de Solicitacao)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Codifica um valor para querystring (UTF-8)
Public Function enc(ByVal v As Variant) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Access -> Web: envia a imagem do projeto (bytes) para a rota uploadImagemVba.
' ref = numero da SL (so o numero, sem "SL"); caminhoArquivo = .jpg local.
Public Function enviarImagemParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarImagemParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "Imagem nao encontrada para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadImagemVba?ref=" & ref & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarImagemParaMySQL = True
    Else
        MsgBox "Falha ao enviar imagem (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar imagem para a web:" & vbCrLf & Err.Description, vbCritical
End Function
' Access -> Web: envia UM desenho PDF (bytes) para a rota uploadDesenhoPdfVba.
' ref = numero da SL; codigo = nome do arquivo sem extensao; caminho = .pdf local.
Public Function enviarPdfDesenhoParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http        As Object
    Dim stream      As Object
    Dim dados()     As Byte
    Dim url         As String
    Dim nomeArq     As String

    enviarPdfDesenhoParaMySQL = False

    If Dir(caminhoArquivo) = "" Then
        MsgBox "PDF nao encontrado para enviar a web:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDesenhoPdfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarPdfDesenhoParaMySQL = True
    Else
        MsgBox "Falha ao enviar PDF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If

    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar PDF para a web:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de desenhos PDF e faz upsert em PDF_Control.
' Os arquivos ja sao copiados pela web para .desenhos\ ; aqui so garantimos a
' linha em PDF_Control para o desenho aparecer na pdf_lst.
Public Sub sincronizarPdfsDoMySQL()
    Dim http        As Object
    Dim txt         As String
    Dim linhas()    As String
    Dim campos()    As String
    Dim i           As Long
    Dim sol         As String, proj As String, cod As String, rev As String
    Dim SQL         As String
    Dim ArrChk      As Variant
    Dim inseridos   As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/desenhosPdf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de PDFs (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM

    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                sol = Trim(campos(0))
                proj = Trim(campos(1))
                cod = Trim(campos(2))
                rev = Trim(campos(3))

                SQL = "SELECT Codigo FROM PDF_Control WHERE Codigo = '" & Replace(cod, "'", "''") & _
                      "' AND Solicitacao = '" & Replace(sol, "'", "''") & "';"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ('" & _
                          Replace(proj, "'", "''") & "','" & Replace(sol, "'", "''") & "','" & _
                          Replace(cod, "'", "''") & "','" & Replace(rev, "'", "''") & "');"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de PDFs concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar PDFs:" & vbCrLf & Err.Description, vbCritical
End Sub
' Cartorio do numero de DXF: pede o proximo Controle a web (GET_LOCK no servidor).
' floor = MAX(Controle) atual do Access (para o contador nao reiniciar/colidir).
Public Function pedirProximoDxf(ByVal floor As Long) As Long
    Dim http As Object
    Dim txt As String
    Dim p As Long
    Dim s As String
    Dim ch As String

    pedirProximoDxf = 0
    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/desenvolvimento/nextDxf?floor=" & floor, False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao pedir numero DXF (HTTP " & http.Status & ")", vbExclamation
        Exit Function
    End If

    ' Extrai o numero apos "controle": do JSON {"controle":N,"codigo":"DX000N"}
    txt = http.responseText
    p = InStr(txt, """controle""")
    If p = 0 Then Exit Function
    p = InStr(p, txt, ":") + 1
    s = ""
    Do While p <= Len(txt)
        ch = Mid(txt, p, 1)
        If ch >= "0" And ch <= "9" Then
            s = s & ch
        ElseIf s <> "" Then
            Exit Do
        End If
        p = p + 1
    Loop
    If s <> "" Then pedirProximoDxf = CLng(s)
    Exit Function
erro:
    MsgBox "Erro ao pedir numero DXF:" & vbCrLf & Err.Description, vbCritical
End Function

' Access -> Web: envia UM pacote DXF (zip) para a rota uploadDxfVba.
Public Function enviarDxfParaMySQL(ByVal ref As Long, ByVal codigo As String, ByVal caminhoArquivo As String) As Boolean
    Dim http As Object
    Dim stream As Object
    Dim dados() As Byte
    Dim url As String
    Dim nomeArq As String

    enviarDxfParaMySQL = False
    If Dir(caminhoArquivo) = "" Then
        MsgBox "Pacote DXF nao encontrado:" & vbCrLf & caminhoArquivo, vbExclamation
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1                 ' adTypeBinary
    stream.Open
    stream.LoadFromFile caminhoArquivo
    dados = stream.Read
    stream.Close
    Set stream = Nothing

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)
    url = urlBaseApp() & "/dispositivos/desenvolvimento/uploadDxfVba?ref=" & ref & _
          "&codigo=" & enc(codigo) & "&nome=" & enc(nomeArq)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.send dados

    If http.Status = 200 Then
        enviarDxfParaMySQL = True
    Else
        MsgBox "Falha ao enviar DXF (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar DXF:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de DXF e faz upsert em DXF_Control (insere os que faltam).
' O Controle vem do MySQL (cartorio), por isso pode ser inserido explicito.
Public Sub sincronizarDxfsDoMySQL()
    Dim http As Object
    Dim txt As String
    Dim linhas() As String
    Dim campos() As String
    Dim i As Long
    Dim ctrl As String, sol As String, proj As String, desc As String
    Dim SQL As String
    Dim ArrChk As Variant
    Dim inseridos As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/dxf", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de DXF (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM
    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 3 Then
                ctrl = Trim(campos(0))
                sol = Trim(campos(1))
                proj = Trim(campos(2))
                desc = Trim(campos(3))

                SQL = "SELECT Controle FROM DXF_Control WHERE Controle = " & Val(ctrl) & ";"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO DXF_Control (Controle, Solicitacao, Cod_Proj, Descricao, IMG, DXF) VALUES (" & _
                          Val(ctrl) & ",'" & Replace(sol, "'", "''") & "','" & Replace(proj, "'", "''") & "','" & _
                          Replace(desc, "'", "''") & "', TRUE, TRUE);"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de DXF concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar DXF:" & vbCrLf & Err.Description, vbCritical
End Sub
' Access -> Web: envia os itens de BOM (lote) para a rota uploadBomVba.
' payload = linhas "codigo<TAB>rev<TAB>descricao<TAB>qtde<TAB>tipo" separadas por vbLf.
Public Function enviarBomParaMySQL(ByVal ref As Long, ByVal payload As String) As Boolean
    Dim http As Object
    Dim corpo As String

    enviarBomParaMySQL = False
    If Trim(payload) = "" Then Exit Function

    corpo = "ref=" & ref & "&dados=" & enc(payload)

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", urlBaseApp() & "/dispositivos/desenvolvimento/uploadBomVba", False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.send corpo

    If http.Status = 200 Then
        enviarBomParaMySQL = True
    Else
        MsgBox "Falha ao enviar BOM (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Set http = Nothing
    Exit Function
erro:
    MsgBox "Erro ao enviar BOM:" & vbCrLf & Err.Description, vbCritical
End Function

' Web -> Access (pull): baixa o CSV de BOM e faz upsert em BOM_Control (insere os que faltam).
' Chave: Solicitacao + Codigo + Revisao. O Controle do BOM_Control continua AutoNumber.
Public Sub sincronizarBomDoMySQL()
    Dim http As Object
    Dim txt As String
    Dim linhas() As String
    Dim campos() As String
    Dim i As Long
    Dim sol As String, proj As String, cod As String, rev As String
    Dim desc As String, qtde As String, tipo As String
    Dim SQL As String
    Dim ArrChk As Variant
    Dim inseridos As Long

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/bom", False
    http.send
    If http.Status <> 200 Then
        MsgBox "Falha ao baixar CSV de BOM (HTTP " & http.Status & ")", vbExclamation
        Exit Sub
    End If

    txt = http.responseText
    If Len(txt) > 0 Then If AscW(Left(txt, 1)) = 65279 Then txt = Mid(txt, 2)  ' tira BOM
    linhas = Split(Replace(txt, vbCr, ""), vbLf)
    inseridos = 0

    For i = 1 To UBound(linhas)                 ' i=0 eh o cabecalho
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")
            If UBound(campos) >= 6 Then
                sol = Trim(campos(0))
                proj = Trim(campos(1))
                cod = Trim(campos(2))
                rev = Trim(campos(3))
                desc = Replace(Trim(campos(4)), "'", "")
                qtde = Trim(campos(5))
                tipo = Trim(campos(6))
                If Not IsNumeric(qtde) Then qtde = "0"
                qtde = Replace(qtde, ",", ".")

                SQL = "SELECT Codigo FROM BOM_Control WHERE Solicitacao = '" & Replace(sol, "'", "''") & _
                      "' AND Codigo = '" & Replace(cod, "'", "''") & "' AND Revisao = '" & Replace(rev, "'", "''") & "';"
                ArrChk = resQuery(SQL)
                If IsEmpty(ArrChk) Then
                    SQL = "INSERT INTO BOM_Control (Projeto, Solicitacao, Codigo, Revisao, Descricao, Qtde, Tipo) VALUES ('" & _
                          Replace(proj, "'", "''") & "','" & Replace(sol, "'", "''") & "','" & Replace(cod, "'", "''") & "','" & _
                          Replace(rev, "'", "''") & "','" & Replace(desc, "'", "''") & "'," & qtde & ",'" & Replace(tipo, "'", "''") & "');"
                    upQuery (SQL)
                    inseridos = inseridos + 1
                End If
            End If
        End If
    Next i

    MsgBox "Sincronizacao de BOM concluida. Novos registros: " & inseridos, vbInformation
    Exit Sub
erro:
    MsgBox "Erro ao sincronizar BOM:" & vbCrLf & Err.Description, vbCritical
End Sub
' Access -> Web: envia os feriados (planilha "Feriados") para a tabela feriados (MySQL).
' Le a coluna A da planilha "Feriados" e faz POST (uma data YYYY-MM-DD por linha).
Public Sub enviarFeriadosParaMySQL()
    Dim ws As Object
    Dim ultima As Long, i As Long
    Dim payload As String
    Dim http As Object
    Dim cel As Variant

    On Error Resume Next
    Set ws = ThisWorkbook.Sheets("Feriados")
    On Error GoTo 0
    If ws Is Nothing Then
        MsgBox "Planilha 'Feriados' nao encontrada neste workbook.", vbExclamation
        Exit Sub
    End If

    ultima = ws.Range("A10000").End(xlUp).Row
    payload = ""
    For i = 1 To ultima
        cel = ws.Cells(i, 1).Value
        If IsDate(cel) Then payload = payload & Format(cel, "YYYY-MM-DD") & vbLf
    Next i

    If payload = "" Then
        MsgBox "Nenhuma data encontrada na coluna A da planilha 'Feriados'.", vbExclamation
        Exit Sub
    End If

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", urlBaseApp() & "/dispositivos/desenvolvimento/uploadFeriadosVba", False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.send "dados=" & enc(payload)

    If http.Status = 200 Then
        MsgBox "Feriados sincronizados!" & vbCrLf & http.responseText, vbInformation
    Else
        MsgBox "Falha ao enviar feriados (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Exit Sub
erro:
    MsgBox "Erro ao enviar feriados:" & vbCrLf & Err.Description, vbCritical
End Sub
```

---

## `frmaut`

```vb
Attribute VB_Name = "frmaut"
Attribute VB_Base = "0{30BCCC7C-89F3-408D-8AAC-1376B95D71EE}{7DF0D717-93C6-4979-908D-92EAD7F3867F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False


Private Sub btn_bom_Click()

    cod_z = frmsol.lbl_codz.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="F:\eng_ind\PROJETOS_Controle\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


End Sub

Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_docs_Click()
    
    UF.lbl_codSL.Caption = Me.lbl_ref.Caption
    UF.lbl_codz.Caption = Me.lbl_cod_z.Caption
    UF.lbl_descricao_SL.Caption = Me.lbl_desc
    
    UF.Show

End Sub

Private Sub btn_dxf_novo_Click()
    ufdxf.Show
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.cmb_autor.Text
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)


End Sub

Private Sub btn_ok_Click()

    Unload Me
    
    filtro = Sheets("Fila").Range("M4").Value
    If filtro = 0 Then Listar_todos
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06
    If filtro = 7 Then filtro_07
    If filtro = 8 Then Listar_analise
    If filtro = 9 Then Lista_SL (Range("H4").Value)
    If filtro = 10 Then Lista_Z (Range("G4").Value)
    If filtro = 11 Then Call Lista_VG(Range("I4").Value, Range("G5").Value)
    If filtro = 12 Then Call Lista_Solic(Range("G5").Value, Range("I4").Value)
    If filtro = 13 Then filtro_08
    If filtro = 14 Then Call Lista_Projetista(Range("K4").Value, Range("I4").Value)
    If filtro = 15 Then Lista_Novos

End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(ln, 2).Value = li1.Text
                .Cells(ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(ln, 16).Value = li1.ListSubItems(3).Text
                ln = ln + 1
        Next a
                
        'Carrega OCs
        ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(ln, 17).Value = li2.ListSubItems(7).Text 'Status
                ln = ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("F:\eng_ind\PROJETOS_Controle\Controle\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    

    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
        Sheets("Fila").Activate
    
        Unload Me

End Sub


Private Sub carrega_pdf_Click()

End Sub

Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub

Private Sub btn_pdf_novo_Click()
    Dim SQL As String
    Dim SQL_pdf As String
    lista_PDF = AbrePDF()
    
    t_cod_z = frmsol.lbl_cod_z.Caption
    t_cod_sl = frmsol.lbl_ref.Caption
    
    If Not IsEmpty(lista_PDF) Then
        For a = 1 To UBound(lista_PDF)
            caminho = lista_PDF(a)
            pos = InStrRev(caminho, "\", , vbTextCompare)
            codigo = Mid(caminho, pos + 1, Len(caminho) - pos)
            codigo = Replace(codigo, ".PDF", "")
            codigo = Replace(codigo, ".pdf", "")
                       
            t_codigo_pdf = codigo
            t_caminho_pdf = caminho
            
            SQL_pdf = "SELECT Codigo From PDF_Control WHERE Codigo = '" & t_codigo_pdf & "' AND Solicitacao = '" & t_cod_sl & "';"
            ArrPDF = resQuery(SQL_pdf)
            
            If IsEmpty(ArrPDF) Then
                SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo_pdf & "',"
                SQL = SQL & "'0');"
                upQuery (SQL)
            End If
            
            Dim oldPathPDF As String, newPathPDF As String
            oldPathPDF = t_caminho_pdf
            
            newPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\desenhosPDF\" & t_cod_sl
            
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            
            newPathPDF = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            


            oldPathPDF = t_caminho_pdf
            newPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\desenhosPDF\" & t_cod_sl
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            newPathPDF2 = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            newPathPDF = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            If oldPathPDF <> "" Then
                Set fs = CreateObject("Scripting.FileSystemObject")
                fs.CopyFile oldPathPDF, newPathPDF
                fs.CopyFile oldPathPDF, newPathPDF2
                Set fs = Nothing

                ' Access -> Web: envia o desenho PDF pro MySQL/web
                enviarPdfDesenhoParaMySQL CLng(Replace(t_cod_sl, "SL", "")), t_codigo_pdf, newPathPDF
            End If

        Next a
    End If
    
    MsgBox "Desenhos em PDF carregados com sucesso!"
    
    Call carrega_pdf(frmsol.lbl_ref.Caption)
    
End Sub

Private Sub btn_buy_novo_Click()
    frm_bom2.lbl_ref.Caption = frmsol.lbl_ref.Caption
    frm_bom2.lbl_desc.Caption = frmsol.lbl_desc.Caption
    frm_bom2.Show
End Sub

Private Sub btnCheck_Click()


Me.multi.Value = 2

'set cor do botão ativo
Me.btnCheck.ForeColor = &H80000012
Me.bordaCheck.BorderColor = &H808080
Me.bordaCheck.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF




End Sub

Private Sub btnDados_Click()

Me.multi.Value = 0

'set cor do botão ativo
Me.btnDados.ForeColor = &H80000012
Me.bordaDados.BorderColor = &H808080
Me.bordaDados.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF

End Sub

Private Sub btnHabilitar_Click()

If Me.det_st.Caption = "OK" Then
    Me.btn_carregar_docs.Enabled = True
    Me.btn_carregar_docs.BackColor = &H80FF80
End If

End Sub

Private Sub btnLoad_Click()
    caminho = "http://mcs.eng.br/greenbrier/upload.html"
    ufLoad.wb.Navigate (caminho)
    ufLoad.Show
End Sub

Private Sub btnLimparComprados_Click()

Dim SQL As String
Dim rq As VbMsgBoxResult
rq = MsgBox("Deseja limpar a lista de Itens Comprados?", vbYesNo, "Deletar?")

If rq = vbYes Then
    nSL = Me.lbl_ref.Caption
    SQL = "DELETE FROM BOM_Control WHERE Solicitacao = '" & sSL & "' AND OC = '';"
    upQuery (SQL)
End If


End Sub

Private Sub btnReq_Click()
Me.multi.Value = 1

'set cor do botão ativo
Me.btnReq.ForeColor = &H80000012
Me.bordaReq.BorderColor = &H808080
Me.bordaReq.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF

End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        ArrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(ArrRes(10, 0)) Then frm_dxf.pg01.Caption = ArrRes(10, 0)
        If Not IsNull(ArrRes(0, 0)) Then frm_dxf.res01.Caption = ArrRes(0, 0)
        status_pg01 = ArrRes(11, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #2
        If Not IsNull(ArrRes(12, 0)) Then frm_dxf.pg02.Caption = ArrRes(12, 0)
        If Not IsNull(ArrRes(1, 0)) Then frm_dxf.res02.Caption = ArrRes(1, 0)
        status_pg02 = ArrRes(13, 0)
        
        'MsgBox status_pg02
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #3
        If Not IsNull(ArrRes(14, 0)) Then frm_dxf.pg03.Caption = ArrRes(14, 0)
        If Not IsNull(ArrRes(2, 0)) Then frm_dxf.res03.Caption = ArrRes(2, 0)
        status_pg03 = ArrRes(15, 0)
        
        'MsgBox status_pg03
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #4
        If Not IsNull(ArrRes(16, 0)) Then frm_dxf.pg04.Caption = ArrRes(16, 0)
        If Not IsNull(ArrRes(3, 0)) Then frm_dxf.res04.Caption = ArrRes(3, 0)
        status_pg04 = ArrRes(17, 0)
        
        'MsgBox status_pg04
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #5
        If Not IsNull(ArrRes(18, 0)) Then frm_dxf.pg05.Caption = ArrRes(18, 0)
        If Not IsNull(ArrRes(4, 0)) Then frm_dxf.res05.Caption = ArrRes(4, 0)
        status_pg05 = ArrRes(19, 0)
        
        'MsgBox status_pg05
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #6
        If Not IsNull(ArrRes(20, 0)) Then frm_dxf.pg06.Caption = ArrRes(20, 0)
        If Not IsNull(ArrRes(5, 0)) Then frm_dxf.res06.Caption = ArrRes(5, 0)
        status_pg06 = ArrRes(21, 0)
        
        'MsgBox status_pg06
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #7
        If Not IsNull(ArrRes(22, 0)) Then frm_dxf.pg07.Caption = ArrRes(22, 0)
        If Not IsNull(ArrRes(6, 0)) Then frm_dxf.res07.Caption = ArrRes(6, 0)
        status_pg07 = ArrRes(23, 0)
        
        'MsgBox status_pg07
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #8
        If Not IsNull(ArrRes(24, 0)) Then frm_dxf.pg08.Caption = ArrRes(24, 0)
        If Not IsNull(ArrRes(7, 0)) Then frm_dxf.res08.Caption = ArrRes(7, 0)
        status_pg08 = ArrRes(25, 0)
        
        'MsgBox status_pg08
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #9
        If Not IsNull(ArrRes(26, 0)) Then frm_dxf.pg09.Caption = ArrRes(26, 0)
        If Not IsNull(ArrRes(8, 0)) Then frm_dxf.res09.Caption = ArrRes(8, 0)
        status_pg09 = ArrRes(27, 0)
        
        'MsgBox status_pg09
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #10
        If Not IsNull(ArrRes(28, 0)) Then frm_dxf.pg10.Caption = ArrRes(28, 0)
        If Not IsNull(ArrRes(9, 0)) Then frm_dxf.res10.Caption = ArrRes(9, 0)
        status_pg10 = ArrRes(29, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        
        
        
        frm_dxf.Show
        
        
    End If


End Sub







Private Sub Label21_Click()
    Dim SQL_Z As String
    projetista = frmsol.lbl_projetista.Caption
    cod_z = Replace(frmsol.lbl_codz.Caption, "Z", "")
    data_inicio = DateValue(Me.dt_inicio.Caption)
    data_fim = DateValue(Me.dt_fim.Caption)
    SQL_Z = "UPDATE Projetos SET Data_Inicio = '" & data_inicio & "' , Data_Fim = '" & data_fim & "' , Projetista = '" & projetista & "', Status = 'Concluído', "
    SQL_Z = SQL_Z & "Data_R_Inicio = '" & data_inicio & "' , Data_R_Fim = '" & data_fim & "' "
    SQL_Z = SQL_Z & " WHERE Controle = " & cod_z & ";"
    upQuery (SQL_Z)
    MsgBox "Projeto " & Me.lbl_codz.Caption & " atualizado!"
    Unload Me
End Sub



Private Sub btnLoadBOM_Click()
    frm_bom.lbl_ref.Caption = frmaut.lbl_ref.Caption
    frm_bom.lbl_desc.Caption = frmaut.lbl_desc.Caption
    frm_bom.lblTipo.Caption = "Auto"
    frm_bom.lblCodZ.Caption = frmaut.lbl_codz.Caption
    frm_bom.Show
End Sub

Private Sub btnLoadImage_Click()
Dim fs As Object
Dim oldPathJPG As String, newPathJPG As String
Dim refNum As Long

oldPathJPG = AbreJPG
If oldPathJPG <> "" Then
    caminho_arquivo = Left(oldPathJPG, InStrRev(oldPathJPG, "\") - 1)
    caminho_arquivo = Left(caminho_arquivo, InStrRev(caminho_arquivo, "\") - 1)

    cod_sl = frmaut.lbl_ref.Caption                   ' ex.: "SL4001"
    refNum = CLng(Replace(cod_sl, "SL", ""))          ' "SL4001" -> 4001

    Set fs = CreateObject("Scripting.FileSystemObject")
    ' Mesmo nome que Carrega_campos le (SL{0000}.jpg), na pasta mapeada
    newPathJPG = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\SL" & Format(refNum, "0000") & ".jpg"
    fs.CopyFile oldPathJPG, newPathJPG
    Set fs = Nothing
    caminho = newPathJPG
    Me.img_sl.Picture = LoadPicture(caminho)

    ' Access -> Web: envia a mesma imagem pro MySQL/web
    enviarImagemParaMySQL refNum, newPathJPG
End If
End Sub



Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & frmaut.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub

Private Sub lbl_trocar_Click()


End Sub

Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
   
    codigo = Me.pdf_lst.Text
   
    tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)
        
    
    
    'user = "MARCOS"
    'codigo = Me.lbl_ref & " - " & Me.pdf_lst.Text
    
    'caminho = "http://mcs.eng.br/greenbrier/copia.php?nome=" & user & "&pdf=" & codigo & ".PDF"
    'ufView.wb.Navigate (caminho)
    
    'ufView.Show
End Sub

Private Sub pdf_lst_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
Dim SQL As String
Dim res As VbMsgBoxResult

If KeyAscii = 120 Then
    codigo = Me.pdf_lst.Text
    n_sl = Me.lbl_ref.Caption
    
    res = MsgBox("Deseja EXCLUIR o desenho nº " & codigo & "?", vbYesNoCancel, "EXCLUIR?")
    If res = vbYes Then
        SQL = "DELETE FROM PDF_Control WHERE Codigo = '" & codigo & "' AND Solicitacao = '" & n_sl & "';"
        upQuery (SQL)
    End If
End If

Call carrega_pdf(frmsol.lbl_ref.Caption)

End Sub



Private Sub txtReq01_Change()
If Me.txtReq01.Value <> "" Then
    Me.lblReq01.ForeColor = &H8080FF
    Me.txtReq01.BorderColor = &H8080FF
    Me.txtReq01.ForeColor = &H8080FF
    Me.chkReq01.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq01.ForeColor = &HC0C0C0
    Me.txtReq01.BorderColor = &HC0C0C0
    Me.txtReq01.ForeColor = &HC0C0C0
    Me.chkReq01.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq02_Change()
If Me.txtReq02.Value <> "" Then
    Me.lblReq02.ForeColor = &H8080FF
    Me.txtReq02.BorderColor = &H8080FF
    Me.txtReq02.ForeColor = &H8080FF
    Me.chkReq02.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq02.ForeColor = &HC0C0C0
    Me.txtReq02.BorderColor = &HC0C0C0
    Me.txtReq02.ForeColor = &HC0C0C0
    Me.chkReq02.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq03_Change()
If Me.txtReq03.Value <> "" Then
    Me.lblReq03.ForeColor = &H8080FF
    Me.txtReq03.BorderColor = &H8080FF
    Me.txtReq03.ForeColor = &H8080FF
    Me.chkReq03.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq03.ForeColor = &HC0C0C0
    Me.txtReq03.BorderColor = &HC0C0C0
    Me.txtReq03.ForeColor = &HC0C0C0
    Me.chkReq03.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq04_Change()
If Me.txtReq04.Value <> "" Then
    Me.lblReq04.ForeColor = &H8080FF
    Me.txtReq04.BorderColor = &H8080FF
    Me.txtReq04.ForeColor = &H8080FF
    Me.chkReq04.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq04.ForeColor = &HC0C0C0
    Me.txtReq04.BorderColor = &HC0C0C0
    Me.txtReq04.ForeColor = &HC0C0C0
    Me.chkReq04.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq05_Change()
If Me.txtReq05.Value <> "" Then
    Me.lblReq05.ForeColor = &H8080FF
    Me.txtReq05.BorderColor = &H8080FF
    Me.txtReq05.ForeColor = &H8080FF
    Me.chkReq05.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq05.ForeColor = &HC0C0C0
    Me.txtReq05.BorderColor = &HC0C0C0
    Me.txtReq05.ForeColor = &HC0C0C0
    Me.chkReq05.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq06_Change()
If Me.txtReq06.Value <> "" Then
    Me.lblReq06.ForeColor = &H8080FF
    Me.txtReq06.BorderColor = &H8080FF
    Me.txtReq06.ForeColor = &H8080FF
    Me.chkReq06.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq06.ForeColor = &HC0C0C0
    Me.txtReq06.BorderColor = &HC0C0C0
    Me.txtReq06.ForeColor = &HC0C0C0
    Me.chkReq06.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq07_Change()
If Me.txtReq07.Value <> "" Then
    Me.lblReq07.ForeColor = &H8080FF
    Me.txtReq07.BorderColor = &H8080FF
    Me.txtReq07.ForeColor = &H8080FF
    Me.chkReq07.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq07.ForeColor = &HC0C0C0
    Me.txtReq07.BorderColor = &HC0C0C0
    Me.txtReq07.ForeColor = &HC0C0C0
    Me.chkReq07.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq08_Change()
If Me.txtReq08.Value <> "" Then
    Me.lblReq08.ForeColor = &H8080FF
    Me.txtReq08.BorderColor = &H8080FF
    Me.txtReq08.ForeColor = &H8080FF
    Me.chkReq08.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq08.ForeColor = &HC0C0C0
    Me.txtReq08.BorderColor = &HC0C0C0
    Me.txtReq08.ForeColor = &HC0C0C0
    Me.chkReq08.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq09_Change()
If Me.txtReq09.Value <> "" Then
    Me.lblReq09.ForeColor = &H8080FF
    Me.txtReq09.BorderColor = &H8080FF
    Me.txtReq09.ForeColor = &H8080FF
    Me.chkReq09.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq09.ForeColor = &HC0C0C0
    Me.txtReq09.BorderColor = &HC0C0C0
    Me.txtReq09.ForeColor = &HC0C0C0
    Me.chkReq09.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq10_Change()
If Me.txtReq10.Value <> "" Then
    Me.lblReq10.ForeColor = &H8080FF
    Me.txtReq10.BorderColor = &H8080FF
    Me.txtReq10.ForeColor = &H8080FF
    Me.chkReq10.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq10.ForeColor = &HC0C0C0
    Me.txtReq10.BorderColor = &HC0C0C0
    Me.txtReq10.ForeColor = &HC0C0C0
    Me.chkReq10.Picture = Me.chkReqOff.Picture
End If
End Sub
```

---

## `frmsol`

```vb
Attribute VB_Name = "frmsol"
Attribute VB_Base = "0{316AB81B-4A3A-4B8F-AE6B-5D3608E11D71}{F38E8303-9D50-4862-A92C-269A29854D6F}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False



Private Sub btn_bom_Click()

    cod_z = frmsol.lbl_codz.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="F:\eng_ind\PROJETOS_Controle\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


End Sub

Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_docs_Click()
    
    UF.lbl_codSL.Caption = Me.lbl_ref.Caption
    UF.lbl_codz.Caption = Me.lbl_cod_z.Caption
    UF.lbl_descricao_SL.Caption = Me.lbl_desc
    
    UF.Show

End Sub

Private Sub btn_dxf_novo_Click()
    ufdxf.Show
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.cmb_autor.Text
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)


End Sub

Private Sub btn_ok_Click()
    Dim SQL         As String
    Dim vtReq       As String
    Dim a           As Integer
    
    
    vtReq = ""
    For a = 1 To 10
        vtReq = vtReq & Me.Controls("txtReq" & Format(a, "00")).Text & "-|-"
    Next a
    SQL = "UPDATE Fila SET Requisitos = '" & vtReq & "' WHERE Ref = " & Replace(Me.lbl_ref, "SL", "")
    upQuery (SQL)
 
    
    Unload Me
    
    filtro = Sheets("Fila").Range("M4").Value
    If filtro = 0 Then Listar_todos
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06
    If filtro = 7 Then filtro_07
    If filtro = 8 Then Listar_analise
    If filtro = 9 Then Lista_SL (Range("H4").Value)
    If filtro = 10 Then Lista_Z (Range("G4").Value)
    If filtro = 11 Then Call Lista_VG(Range("I4").Value, Range("G5").Value)
    If filtro = 12 Then Call Lista_Solic(Range("G5").Value, Range("I4").Value)
    If filtro = 13 Then filtro_08
    If filtro = 14 Then Call Lista_Projetista(Range("K4").Value, Range("I4").Value)
    If filtro = 15 Then Lista_Novos

End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(ln, 2).Value = li1.Text
                .Cells(ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(ln, 16).Value = li1.ListSubItems(3).Text
                ln = ln + 1
        Next a
                
        'Carrega OCs
        ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(ln, 17).Value = li2.ListSubItems(7).Text 'Status
                ln = ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("F:\eng_ind\PROJETOS_Controle\Controle\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    

    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
        Sheets("Fila").Activate
    
        Unload Me

End Sub


Private Sub carrega_pdf_Click()

End Sub

Private Sub btn_bom_novo_Click()
    
Dim lista_path As String
    
t_cod_z = frmsol.lbl_cod_z.Caption
t_cod_sl = frmsol.lbl_ref.Caption


lista_path = AbreXLS

newPathBOM = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.bom" 'Folder das Listas
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile lista_path, newPathBOM & "\" & t_cod_z & " - " & t_cod_sl & " - Lista_Materiais.xlsx"
Set fs = Nothing

MsgBox "Lista de Material carregada com sucesso!"

End Sub

Private Sub btn_pdf_novo_Click()
    Dim SQL As String
    Dim SQL_pdf As String
    lista_PDF = AbrePDF()
    
    t_cod_z = frmsol.lbl_cod_z.Caption
    t_cod_sl = frmsol.lbl_ref.Caption
    
    If Not IsEmpty(lista_PDF) Then
        For a = 1 To UBound(lista_PDF)
            caminho = lista_PDF(a)
            pos = InStrRev(caminho, "\", , vbTextCompare)
            codigo = Mid(caminho, pos + 1, Len(caminho) - pos)
            codigo = Replace(codigo, ".PDF", "")
            codigo = Replace(codigo, ".pdf", "")
                       
            t_codigo_pdf = codigo
            t_caminho_pdf = caminho
            
            SQL_pdf = "SELECT Codigo From PDF_Control WHERE Codigo = '" & t_codigo_pdf & "' AND Solicitacao = '" & t_cod_sl & "';"
            ArrPDF = resQuery(SQL_pdf)
            
            If IsEmpty(ArrPDF) Then
                SQL = "INSERT INTO PDF_Control (Projeto, Solicitacao, Codigo, Revisao) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo_pdf & "',"
                SQL = SQL & "'0');"
                upQuery (SQL)
            End If
            
            Dim oldPathPDF As String, newPathPDF As String
            oldPathPDF = t_caminho_pdf
            
            newPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\desenhosPDF\" & t_cod_sl
            
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            
            newPathPDF = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            


            oldPathPDF = t_caminho_pdf
            newPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\desenhosPDF\" & t_cod_sl
            If Len(Dir(newPath, vbDirectory)) = 0 Then
                MkDir newPath
            End If
            newPathPDF2 = newPath & "\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            newPathPDF = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & t_cod_sl & " - " & t_codigo_pdf & ".pdf"
            
            If oldPathPDF <> "" Then
                Set fs = CreateObject("Scripting.FileSystemObject")
                fs.CopyFile oldPathPDF, newPathPDF
                fs.CopyFile oldPathPDF, newPathPDF2
                Set fs = Nothing

                ' Access -> Web: envia o desenho PDF pro MySQL/web
                enviarPdfDesenhoParaMySQL CLng(Replace(t_cod_sl, "SL", "")), t_codigo_pdf, newPathPDF
            End If

        Next a
    End If
    
    MsgBox "Desenhos em PDF carregados com sucesso!"
    
    Call carrega_pdf(frmsol.lbl_ref.Caption)
    
End Sub

Private Sub btn_buy_novo_Click()
    frm_bom.lbl_ref.Caption = frmsol.lbl_ref.Caption
    frm_bom.lbl_desc.Caption = frmsol.lbl_desc.Caption
    frm_bom.lblTipo.Caption = "Auto"
    frm_bom.Show
End Sub

Private Sub btnCheck_Click()


Me.multi.Value = 2

'set cor do botão ativo
Me.btnCheck.ForeColor = &H80000012
Me.bordaCheck.BorderColor = &H808080
Me.bordaCheck.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF




End Sub

Private Sub btnDados_Click()

Me.multi.Value = 0

'set cor do botão ativo
Me.btnDados.ForeColor = &H80000012
Me.bordaDados.BorderColor = &H808080
Me.bordaDados.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF
Me.btnReq.ForeColor = &HC0C0C0
Me.bordaReq.BorderColor = &HE0E0E0
Me.bordaReq.BackColor = &HFFFFFF

End Sub

Private Sub btnHabilitar_Click()

If Me.det_st.Caption = "OK" Then
    Me.btn_carregar_docs.Enabled = True
    Me.btn_carregar_docs.BackColor = &H80FF80
End If

End Sub

Private Sub btnLoad_Click()
    caminho = "http://mcs.eng.br/greenbrier/upload.html"
    ufLoad.wb.Navigate (caminho)
    ufLoad.Show
End Sub

Private Sub btnLiberar_Click()
Dim SQL As String
Dim ref As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "")

SQL = "UPDATE Fila SET Conceito_St = 'OK', Det_St = 'OK', Liberacao_St = 'OK', Aq_St = 'OK', Corte_St = 'FINALIZADO', Exec_St = 'FINALIZADO', Tryout_St = 'OK', "
SQL = SQL + "Conceito_Fim = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Det_Ini = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Det_Fim = '" & Format(Now, "DD/MM/YYYY HH:MM")
SQL = SQL + "', Liberacao_Data = '" & Format(Now, "DD/MM/YYYY HH:MM") & "' WHERE Ref = " & ref & ";"
upQuery (SQL)

Call Carrega_campos(ref)
Call Formata_Campos


MsgBox "SL Liberada!"

End Sub

Private Sub btnLimparComprados_Click()

Dim SQL As String
Dim rq As VbMsgBoxResult
rq = MsgBox("Deseja limpar a lista de Itens Comprados?", vbYesNo, "Deletar?")

If rq = vbYes Then
    nSL = Me.lbl_ref.Caption
    SQL = "DELETE FROM BOM_Control WHERE Solicitacao = '" & sSL & "' AND OC = '';"
    upQuery (SQL)
End If


End Sub

Private Sub btnReq_Click()
Me.multi.Value = 1

'set cor do botão ativo
Me.btnReq.ForeColor = &H80000012
Me.bordaReq.BorderColor = &H808080
Me.bordaReq.BackColor = &HC0C0C0

'set cor botoes inativos
Me.btnDados.ForeColor = &HC0C0C0
Me.bordaDados.BorderColor = &HE0E0E0
Me.bordaDados.BackColor = &HFFFFFF
Me.btnCheck.ForeColor = &HC0C0C0
Me.bordaCheck.BorderColor = &HE0E0E0
Me.bordaCheck.BackColor = &HFFFFFF

End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        ArrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(ArrRes(10, 0)) Then frm_dxf.pg01.Caption = ArrRes(10, 0)
        If Not IsNull(ArrRes(0, 0)) Then frm_dxf.res01.Caption = ArrRes(0, 0)
        status_pg01 = ArrRes(11, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #2
        If Not IsNull(ArrRes(12, 0)) Then frm_dxf.pg02.Caption = ArrRes(12, 0)
        If Not IsNull(ArrRes(1, 0)) Then frm_dxf.res02.Caption = ArrRes(1, 0)
        status_pg02 = ArrRes(13, 0)
        
        'MsgBox status_pg02
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #3
        If Not IsNull(ArrRes(14, 0)) Then frm_dxf.pg03.Caption = ArrRes(14, 0)
        If Not IsNull(ArrRes(2, 0)) Then frm_dxf.res03.Caption = ArrRes(2, 0)
        status_pg03 = ArrRes(15, 0)
        
        'MsgBox status_pg03
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #4
        If Not IsNull(ArrRes(16, 0)) Then frm_dxf.pg04.Caption = ArrRes(16, 0)
        If Not IsNull(ArrRes(3, 0)) Then frm_dxf.res04.Caption = ArrRes(3, 0)
        status_pg04 = ArrRes(17, 0)
        
        'MsgBox status_pg04
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #5
        If Not IsNull(ArrRes(18, 0)) Then frm_dxf.pg05.Caption = ArrRes(18, 0)
        If Not IsNull(ArrRes(4, 0)) Then frm_dxf.res05.Caption = ArrRes(4, 0)
        status_pg05 = ArrRes(19, 0)
        
        'MsgBox status_pg05
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #6
        If Not IsNull(ArrRes(20, 0)) Then frm_dxf.pg06.Caption = ArrRes(20, 0)
        If Not IsNull(ArrRes(5, 0)) Then frm_dxf.res06.Caption = ArrRes(5, 0)
        status_pg06 = ArrRes(21, 0)
        
        'MsgBox status_pg06
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #7
        If Not IsNull(ArrRes(22, 0)) Then frm_dxf.pg07.Caption = ArrRes(22, 0)
        If Not IsNull(ArrRes(6, 0)) Then frm_dxf.res07.Caption = ArrRes(6, 0)
        status_pg07 = ArrRes(23, 0)
        
        'MsgBox status_pg07
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #8
        If Not IsNull(ArrRes(24, 0)) Then frm_dxf.pg08.Caption = ArrRes(24, 0)
        If Not IsNull(ArrRes(7, 0)) Then frm_dxf.res08.Caption = ArrRes(7, 0)
        status_pg08 = ArrRes(25, 0)
        
        'MsgBox status_pg08
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #9
        If Not IsNull(ArrRes(26, 0)) Then frm_dxf.pg09.Caption = ArrRes(26, 0)
        If Not IsNull(ArrRes(8, 0)) Then frm_dxf.res09.Caption = ArrRes(8, 0)
        status_pg09 = ArrRes(27, 0)
        
        'MsgBox status_pg09
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        'corte #10
        If Not IsNull(ArrRes(28, 0)) Then frm_dxf.pg10.Caption = ArrRes(28, 0)
        If Not IsNull(ArrRes(9, 0)) Then frm_dxf.res10.Caption = ArrRes(9, 0)
        status_pg10 = ArrRes(29, 0)
        
        'MsgBox status_pg01
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
            'MsgBox "Vermelho"
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
            'MsgBox "Azul"
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
            'MsgBox "Verde"
        End If
        
        
        
        
        frm_dxf.Show
        
        
    End If


End Sub







Private Sub Label21_Click()
    Dim SQL_Z As String
    projetista = frmsol.lbl_projetista.Caption
    cod_z = Replace(frmsol.lbl_codz.Caption, "Z", "")
    data_inicio = DateValue(Me.dt_inicio.Caption)
    data_fim = DateValue(Me.dt_fim.Caption)
    SQL_Z = "UPDATE Projetos SET Data_Inicio = '" & data_inicio & "' , Data_Fim = '" & data_fim & "' , Projetista = '" & projetista & "', Status = 'Concluído', "
    SQL_Z = SQL_Z & "Data_R_Inicio = '" & data_inicio & "' , Data_R_Fim = '" & data_fim & "' "
    SQL_Z = SQL_Z & " WHERE Controle = " & cod_z & ";"
    upQuery (SQL_Z)
    MsgBox "Projeto " & Me.lbl_codz.Caption & " atualizado!"
    Unload Me
End Sub



Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & frmsol.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub

Private Sub lbl_trocar_Click()
Dim fs As Object
Dim oldPathJPG As String, newPathJPG As String

oldPathJPG = AbreJPG
If oldPathJPG <> "" Then
    caminho_arquivo = Left(oldPathJPG, InStrRev(oldPathJPG, "\") - 1)
    caminho_arquivo = Left(caminho_arquivo, InStrRev(caminho_arquivo, "\") - 1)

    cod_sl = frmsol.lbl_ref.Caption

    If oldPathJPG <> "" Then
        Set fs = CreateObject("Scripting.FileSystemObject")
        newPathJPG = "F:\eng_ind\PROJETOS_Controle\Controle\.img_sl\" & cod_sl & ".jpg"
        fs.CopyFile oldPathJPG, newPathJPG
        Set fs = Nothing
        caminho = newPathJPG
        frmsol.img_sl.Picture = LoadPicture(caminho)
    End If
End If

End Sub

Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
   
    codigo = Me.pdf_lst.Text
   
    tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)
        
    
    
    'user = "MARCOS"
    'codigo = Me.lbl_ref & " - " & Me.pdf_lst.Text
    
    'caminho = "http://mcs.eng.br/greenbrier/copia.php?nome=" & user & "&pdf=" & codigo & ".PDF"
    'ufView.wb.Navigate (caminho)
    
    'ufView.Show
End Sub

Private Sub pdf_lst_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
Dim SQL As String
Dim res As VbMsgBoxResult

If KeyAscii = 120 Then
    codigo = Me.pdf_lst.Text
    n_sl = Me.lbl_ref.Caption
    
    res = MsgBox("Deseja EXCLUIR o desenho nº " & codigo & "?", vbYesNoCancel, "EXCLUIR?")
    If res = vbYes Then
        SQL = "DELETE FROM PDF_Control WHERE Codigo = '" & codigo & "' AND Solicitacao = '" & n_sl & "';"
        upQuery (SQL)
    End If
End If

Call carrega_pdf(frmsol.lbl_ref.Caption)

End Sub

Private Sub txt_msg_Change()
    
    If Me.cmb_autor.Value = "" Then
        MsgBox "O Nome do Projetista não foi informado!", vbInformation
        Me.cmb_autor.SetFocus
        Exit Sub
    End If
End Sub

Private Sub txtReq01_Change()
If Me.txtReq01.Value <> "" Then
    Me.lblReq01.ForeColor = &H8080FF
    Me.txtReq01.BorderColor = &H8080FF
    Me.txtReq01.ForeColor = &H8080FF
    Me.chkReq01.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq01.ForeColor = &HC0C0C0
    Me.txtReq01.BorderColor = &HC0C0C0
    Me.txtReq01.ForeColor = &HC0C0C0
    Me.chkReq01.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq02_Change()
If Me.txtReq02.Value <> "" Then
    Me.lblReq02.ForeColor = &H8080FF
    Me.txtReq02.BorderColor = &H8080FF
    Me.txtReq02.ForeColor = &H8080FF
    Me.chkReq02.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq02.ForeColor = &HC0C0C0
    Me.txtReq02.BorderColor = &HC0C0C0
    Me.txtReq02.ForeColor = &HC0C0C0
    Me.chkReq02.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq03_Change()
If Me.txtReq03.Value <> "" Then
    Me.lblReq03.ForeColor = &H8080FF
    Me.txtReq03.BorderColor = &H8080FF
    Me.txtReq03.ForeColor = &H8080FF
    Me.chkReq03.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq03.ForeColor = &HC0C0C0
    Me.txtReq03.BorderColor = &HC0C0C0
    Me.txtReq03.ForeColor = &HC0C0C0
    Me.chkReq03.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq04_Change()
If Me.txtReq04.Value <> "" Then
    Me.lblReq04.ForeColor = &H8080FF
    Me.txtReq04.BorderColor = &H8080FF
    Me.txtReq04.ForeColor = &H8080FF
    Me.chkReq04.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq04.ForeColor = &HC0C0C0
    Me.txtReq04.BorderColor = &HC0C0C0
    Me.txtReq04.ForeColor = &HC0C0C0
    Me.chkReq04.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq05_Change()
If Me.txtReq05.Value <> "" Then
    Me.lblReq05.ForeColor = &H8080FF
    Me.txtReq05.BorderColor = &H8080FF
    Me.txtReq05.ForeColor = &H8080FF
    Me.chkReq05.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq05.ForeColor = &HC0C0C0
    Me.txtReq05.BorderColor = &HC0C0C0
    Me.txtReq05.ForeColor = &HC0C0C0
    Me.chkReq05.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq06_Change()
If Me.txtReq06.Value <> "" Then
    Me.lblReq06.ForeColor = &H8080FF
    Me.txtReq06.BorderColor = &H8080FF
    Me.txtReq06.ForeColor = &H8080FF
    Me.chkReq06.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq06.ForeColor = &HC0C0C0
    Me.txtReq06.BorderColor = &HC0C0C0
    Me.txtReq06.ForeColor = &HC0C0C0
    Me.chkReq06.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq07_Change()
If Me.txtReq07.Value <> "" Then
    Me.lblReq07.ForeColor = &H8080FF
    Me.txtReq07.BorderColor = &H8080FF
    Me.txtReq07.ForeColor = &H8080FF
    Me.chkReq07.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq07.ForeColor = &HC0C0C0
    Me.txtReq07.BorderColor = &HC0C0C0
    Me.txtReq07.ForeColor = &HC0C0C0
    Me.chkReq07.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq08_Change()
If Me.txtReq08.Value <> "" Then
    Me.lblReq08.ForeColor = &H8080FF
    Me.txtReq08.BorderColor = &H8080FF
    Me.txtReq08.ForeColor = &H8080FF
    Me.chkReq08.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq08.ForeColor = &HC0C0C0
    Me.txtReq08.BorderColor = &HC0C0C0
    Me.txtReq08.ForeColor = &HC0C0C0
    Me.chkReq08.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq09_Change()
If Me.txtReq09.Value <> "" Then
    Me.lblReq09.ForeColor = &H8080FF
    Me.txtReq09.BorderColor = &H8080FF
    Me.txtReq09.ForeColor = &H8080FF
    Me.chkReq09.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq09.ForeColor = &HC0C0C0
    Me.txtReq09.BorderColor = &HC0C0C0
    Me.txtReq09.ForeColor = &HC0C0C0
    Me.chkReq09.Picture = Me.chkReqOff.Picture
End If
End Sub

Private Sub txtReq10_Change()
If Me.txtReq10.Value <> "" Then
    Me.lblReq10.ForeColor = &H8080FF
    Me.txtReq10.BorderColor = &H8080FF
    Me.txtReq10.ForeColor = &H8080FF
    Me.chkReq10.Picture = Me.chkReqOffVm.Picture
Else
    Me.lblReq10.ForeColor = &HC0C0C0
    Me.txtReq10.BorderColor = &HC0C0C0
    Me.txtReq10.ForeColor = &HC0C0C0
    Me.chkReq10.Picture = Me.chkReqOff.Picture
End If
End Sub
```

---

## `M_Abre_UF`

```vb
Attribute VB_Name = "M_Abre_UF"
Option Explicit

Sub Carrega_campos(ref)
Dim SQL             As String
Dim SQLz            As String
Dim ArrRes          As Variant
Dim a               As Integer
Dim ArrDesc         As Variant
Dim lib_st          As String
Dim caminho         As String


'Query de consulta para formulário
SQL = "SELECT Descricao, Data_Solicitacao, Solicitante, Aplicacao, Vagao, Lote, Historico,"
SQL = SQL & "Conceito_St, Conceito_Fim, "
SQL = SQL & "Det_St, Det_Fim, "
SQL = SQL & "Liberacao_St, Liberacao_Data, Aq_St, Aq_Data, Corte_St, Corte_Data, Exec_St, Exec_Data, Tryout_St, Tryout_Data, Cod_Z, Classe, "
SQL = SQL & "Tempo_Modelo, Tempo_Fila_Det, Tempo_Det, Tempo_Fila_Lib, Conceito_P, Conceito_Ini, Liberacao_Data, Liberacao_St, Executor_EI, Data_Inicio_EI, Data_Fim_EI, Status_EI "
SQL = SQL & " FROM Fila WHERE Ref = " & ref & ";"

ArrRes = resQuery(SQL)

If Not IsEmpty(ArrRes) Then
        a = 0
        frmsol.lbl_ref.Caption = "SL" & Format(ref, "0000")
        
        frmsol.lbl_desc = ArrRes(0, a)
        
        If IsNull(ArrRes(1, a)) Then frmsol.lbl_data = "" Else frmsol.lbl_data = ArrRes(1, a)
        If IsNull(ArrRes(2, a)) Then frmsol.lbl_solic = "" Else frmsol.lbl_solic = ArrRes(2, a)
        
        If IsNull(ArrRes(3, a)) Then frmsol.lbl_estagio = "" Else frmsol.lbl_estagio = ArrRes(3, a)
        If IsNull(ArrRes(4, a)) Then frmsol.lbl_vg = "" Else frmsol.lbl_vg = ArrRes(4, a)
        If IsNull(ArrRes(5, a)) Then frmsol.lbl_lote = "" Else frmsol.lbl_lote = ArrRes(5, a)
        If IsNull(ArrRes(6, a)) Then frmsol.txt_historico.Text = "" Else frmsol.txt_historico.Text = ArrRes(6, a)
        
        
        If IsNull(ArrRes(7, a)) Then frmsol.proj_st.Caption = "" Else frmsol.proj_st.Caption = ArrRes(7, a)
        If IsNull(ArrRes(8, a)) Then frmsol.proj_data.Caption = "" Else frmsol.proj_data.Caption = Format(ArrRes(8, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(8, a)) Then frmsol.dt_inicio.Caption = "" Else frmsol.dt_inicio.Caption = Format(ArrRes(8, a), "DD/MM/YY")
        
        
        If IsNull(ArrRes(9, a)) Then frmsol.det_st.Caption = "" Else frmsol.det_st.Caption = ArrRes(9, a)
        If IsNull(ArrRes(10, a)) Then frmsol.det_data.Caption = "" Else frmsol.det_data.Caption = Format(ArrRes(10, a), "DD.MM.YY | hh:mm")
        
        
        If IsNull(ArrRes(11, a)) Then frmsol.lib_st.Caption = "" Else frmsol.lib_st.Caption = ArrRes(11, a)
        If IsNull(ArrRes(12, a)) Then frmsol.lib_data.Caption = "" Else frmsol.lib_data.Caption = Format(ArrRes(12, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(12, a)) Then frmsol.dt_fim.Caption = "" Else frmsol.dt_fim.Caption = Format(ArrRes(12, a), "DD/MM/YY")
        
        If IsNull(ArrRes(13, a)) Then frmsol.aq_st.Caption = "" Else frmsol.aq_st.Caption = ArrRes(13, a)
        If IsNull(ArrRes(14, a)) Then frmsol.aq_data.Caption = "" Else frmsol.aq_data.Caption = Format(ArrRes(14, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(15, a)) Then frmsol.corte_st.Caption = "" Else frmsol.corte_st.Caption = ArrRes(15, a)
        If IsNull(ArrRes(16, a)) Then frmsol.corte_data.Caption = "" Else frmsol.corte_data.Caption = Format(ArrRes(16, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(17, a)) Then frmsol.exec_st.Caption = "" Else frmsol.exec_st.Caption = ArrRes(17, a)
        If IsNull(ArrRes(18, a)) Then frmsol.exec_data.Caption = "" Else frmsol.exec_data.Caption = Format(ArrRes(18, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(19, a)) Then frmsol.tryout_st.Caption = "" Else frmsol.tryout_st.Caption = ArrRes(19, a)
        If IsNull(ArrRes(20, a)) Then frmsol.tryout_data.Caption = "" Else frmsol.tryout_data.Caption = Format(ArrRes(20, a), "DD.MM.YY | hh:mm")
        
        If IsNull(ArrRes(21, a)) Then
            frmsol.lbl_codz.Caption = ""
            frmsol.lbl_cod_z.Caption = ""
        Else
            frmsol.lbl_cod_z.Caption = ArrRes(21, a)
            frmsol.lbl_codz.Caption = ArrRes(21, a)
            If ArrRes(21, a) <> "" Then
                SQLz = "SELECT Descricao FROM Projetos WHERE Controle = " & Replace(ArrRes(21, a), "Z", "") & ";"
                ArrDesc = resQuery(SQLz)
                If Not IsNull(ArrDesc(0, 0)) Then frmsol.lbl_descz.Caption = ArrDesc(0, 0)
            End If
        End If
              
        
        If IsNull(ArrRes(22, a)) Then frmsol.lbl_classe.Caption = "" Else frmsol.lbl_classe.Caption = ArrRes(22, a)
        
        'Horas
        If IsNull(ArrRes(23, a)) Then frmsol.lbl_proj_h.Caption = "" Else frmsol.lbl_proj_h.Caption = Format(ArrRes(23, a), "0.0h")
        If IsNull(ArrRes(24, a)) Then frmsol.lbl_fila_1.Caption = "" Else frmsol.lbl_fila_1.Caption = Format(ArrRes(24, a), "0.0h")
        If IsNull(ArrRes(25, a)) Then frmsol.lbl_det_h.Caption = "" Else frmsol.lbl_det_h.Caption = Format(ArrRes(25, a), "0.0h")
        If IsNull(ArrRes(26, a)) Then frmsol.lbl_fila_2.Caption = "" Else frmsol.lbl_fila_2.Caption = Format(ArrRes(26, a), "0.0h")
        
        If IsNull(ArrRes(27, a)) Then frmsol.lbl_projetista.Caption = "" Else frmsol.lbl_projetista.Caption = ArrRes(27, a)
        If IsNull(ArrRes(28, a)) Then frmsol.lbl_ini_proj.Caption = "" Else frmsol.lbl_ini_proj.Caption = ArrRes(28, a)
        If IsNull(ArrRes(29, a)) Then frmsol.lbl_fim_proj.Caption = "" Else frmsol.lbl_fim_proj.Caption = ArrRes(29, a)
        If IsNull(ArrRes(30, a)) Then frmsol.lbl_status_proj.Caption = "" Else frmsol.lbl_status_proj.Caption = ArrRes(30, a)
        
        If IsNull(ArrRes(31, a)) Then frmsol.lbl_executor.Caption = "" Else frmsol.lbl_executor.Caption = ArrRes(31, a)
        If IsNull(ArrRes(32, a)) Then frmsol.lbl_ini_exec.Caption = "" Else frmsol.lbl_ini_exec.Caption = ArrRes(32, a)
        If IsNull(ArrRes(33, a)) Then frmsol.lbl_fim_exec.Caption = "" Else frmsol.lbl_fim_exec.Caption = ArrRes(33, a)
        If IsNull(ArrRes(34, a)) Then frmsol.lbl_status_exec.Caption = "" Else frmsol.lbl_status_exec.Caption = ArrRes(34, a)
        
        
        If lib_st = "[VERIFICAÇÃO]" Then frmsol.btnLimparComprados.Enabled = True
        
        On Error Resume Next
        caminho = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\SL" & Format(ref, "0000") & ".jpg"
        On Error Resume Next
        frmsol.img_sl.Picture = LoadPicture(caminho)
        
        
End If

End Sub

Sub Formata_Campos()

    Dim azul                As String
    Dim vermelho            As String
    Dim vermelho_escuro     As String
    Dim azul_claro          As String
    Dim amarelo             As String
    Dim cinza_escuro        As String
    Dim cinza_claro         As String
    Dim verde               As String

    
    
        'Cores
        azul = &HC59452
        vermelho = &H8080FF
        vermelho_escuro = &HC0&
        azul_claro = &HFF8080
        amarelo = &H8080&
        cinza_escuro = &H808080
        cinza_claro = &HC0C0C0
        verde = &H8000&

        'Ajustar cor das Labels
        If frmsol.proj_st.Caption = "OK" Then frmsol.proj_st.BackColor = verde
        If frmsol.proj_st.Caption = "PENDENTE" Then frmsol.proj_st.BackColor = vermelho
        If frmsol.proj_st.Caption = "CANCELADO" Then frmsol.proj_st.BackColor = cinza_claro
        If frmsol.proj_st.Caption = "PAUSADO" Then frmsol.proj_st.BackColor = cinza_escuro
        If frmsol.proj_st.Caption = "EM ANÁLISE" Then frmsol.proj_st.BackColor = azul
        If frmsol.proj_st.Caption = "MODELO" Then frmsol.proj_st.BackColor = amarelo
        If frmsol.proj_st.Caption = "BACKLOG" Then frmsol.proj_st.BackColor = azul_claro
        
        If frmsol.det_st.Caption = "OK" Then frmsol.det_st.BackColor = verde
        If frmsol.det_st.Caption = "PENDENTE" Then frmsol.det_st.BackColor = vermelho
        If frmsol.det_st.Caption = "CANCELADO" Then frmsol.det_st.BackColor = cinza_claro
        
        If frmsol.lib_st.Caption = "OK" Then frmsol.lib_st.BackColor = verde
        If frmsol.lib_st.Caption = "PENDENTE" Then frmsol.lib_st.BackColor = vermelho
        If frmsol.lib_st.Caption = "CANCELADO" Then frmsol.lib_st.BackColor = cinza_claro
        
        If frmsol.aq_st.Caption = "OK" Then frmsol.aq_st.BackColor = verde
        If frmsol.aq_st.Caption = "PENDENTE" Then frmsol.aq_st.BackColor = vermelho
        If frmsol.aq_st.Caption = "REALIZADO" Then frmsol.aq_st.BackColor = amarelo
        If frmsol.aq_st.Caption = "CANCELADO" Then frmsol.aq_st.BackColor = cinza_claro

        If frmsol.corte_st.Caption = "FINALIZADO" Then frmsol.corte_st.BackColor = verde
        If frmsol.corte_st.Caption = "PARADO" Then frmsol.corte_st.BackColor = vermelho_escuro
        If frmsol.corte_st.Caption = "ANDAMENTO" Then frmsol.corte_st.BackColor = azul
        If frmsol.corte_st.Caption = "CANCELADO" Then frmsol.corte_st.BackColor = cinza_claro
        
        If frmsol.exec_st.Caption = "FINALIZADO" Then frmsol.exec_st.BackColor = verde
        If frmsol.exec_st.Caption = "PARADO" Then frmsol.exec_st.BackColor = vermelho_escuro
        If frmsol.exec_st.Caption = "ANDAMENTO" Then frmsol.exec_st.BackColor = azul
        If frmsol.exec_st.Caption = "CANCELADO" Then frmsol.exec_st.BackColor = cinza_claro
        
        If frmsol.tryout_st.Caption = "OK" Then frmsol.tryout_st.BackColor = verde
        If frmsol.tryout_st.Caption = "PENDENTE" Then frmsol.tryout_st.BackColor = vermelho
        If frmsol.tryout_st.Caption = "CANCELADO" Then frmsol.tryout_st.BackColor = cinza_claro
End Sub

Sub Carrega_DFX(cod_sl)
    Dim SQL             As String
    Dim ArrRes          As Variant
    Dim ArrRes_DXF      As Variant
    Dim tam_res         As Integer
    Dim i               As Integer
    Dim linha           As Variant
    Dim Colunas         As Integer
    Dim Linhas          As Integer
    Dim sts             As Variant
    Dim X               As Integer
    
    
            frmsol.dxf_lst.Gridlines = True
            frmsol.dxf_lst.View = lvwReport
            frmsol.dxf_lst.FullRowSelect = False
            frmsol.dxf_lst.ColumnHeaders.Clear
            frmsol.dxf_lst.ColumnHeaders.Add Text:="CTRL", Width:=40
            frmsol.dxf_lst.ColumnHeaders.Add Text:="DESCRIÇÃO", Width:=290, Alignment:=0
            frmsol.dxf_lst.ColumnHeaders.Add Text:="PRIORIDADE", Width:=60, Alignment:=0
            frmsol.dxf_lst.ColumnHeaders.Add Text:="STATUS CORTE", Width:=70, Alignment:=0
            
            SQL = "SELECT Controle, Descricao, Prioridade, Status FROM DXF_Control WHERE Solicitacao = '" & cod_sl & "' ORDER BY Controle DESC;"

            ArrRes_DXF = resQuery(SQL)

            If Not IsEmpty(ArrRes_DXF) Then
                tam_res = UBound(ArrRes_DXF, 2)
                frmsol.dxf_lst.ListItems.Clear
                For i = 0 To tam_res
                    Set linha = frmsol.dxf_lst.ListItems.Add(Text:="DX" & Format(ArrRes_DXF(0, i), "0000")) 'Controle
                    If Not IsNull(ArrRes_DXF(1, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(1, i) Else linha.ListSubItems.Add Text:="" 'Descrição
                    If Not IsNull(ArrRes_DXF(2, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(2, i) Else linha.ListSubItems.Add Text:="" 'Prioridade
                    If Not IsNull(ArrRes_DXF(3, i)) Then linha.ListSubItems.Add Text:=ArrRes_DXF(3, i) Else linha.ListSubItems.Add Text:="" 'Status
                Next i
            End If
            
            Colunas = frmsol.dxf_lst.ColumnHeaders.Count
            Linhas = frmsol.dxf_lst.ListItems.Count
    
            For i = 1 To Linhas
            sts = frmsol.dxf_lst.ListItems(i).ListSubItems(2)
            If sts = "CONCLUÍDO" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(35, 142, 35)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(35, 142, 35)
                Next X
            End If
            
            If sts = "99-Cancelado" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(150, 150, 150)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(150, 150, 150)
                Next X
            End If

            If sts <> "CONCLUÍDO" And sts <> "99-Cancelado" Then
                frmsol.dxf_lst.ListItems(i).ForeColor = RGB(255, 0, 0)
                For X = 1 To Colunas - 1
                    frmsol.dxf_lst.ListItems(i).ListSubItems(X).ForeColor = RGB(255, 0, 0)
                Next X
            End If

    Next i
End Sub

Sub carrega_pdf(cod_sl)
    Dim SQL                 As String
    Dim ArrRes_PDF          As Variant
    Dim tam_res             As Integer
    Dim i                   As Integer
         
            SQL = "SELECT Codigo FROM PDF_Control WHERE Solicitacao = '" & cod_sl & "' ORDER BY Codigo;"

            ArrRes_PDF = resQuery(SQL)

            If Not IsEmpty(ArrRes_PDF) Then
                tam_res = UBound(ArrRes_PDF, 2)
                frmsol.pdf_lst.Clear
                For i = 0 To tam_res
                    frmsol.pdf_lst.AddItem (ArrRes_PDF(0, i))
                Next i
            End If
End Sub
Sub Carrega_BOM(cod_sl)
    Dim SQL                 As String
    Dim ArrRes_BOM          As Variant
    Dim tam_res             As Integer
    Dim i                   As Integer
    Dim linha               As Variant
    Dim Colunas             As Integer
    Dim Linhas              As Integer
    Dim sts                 As String
    Dim cod                 As String
    Dim OC                  As String
    Dim X                   As Integer
    Dim caminho             As String

            frmsol.bom_lst.Gridlines = True
            frmsol.bom_lst.View = lvwReport
            frmsol.bom_lst.FullRowSelect = False
            frmsol.bom_lst.ColumnHeaders.Clear
            frmsol.bom_lst.ColumnHeaders.Add Text:="", Width:=1
            frmsol.bom_lst.ColumnHeaders.Add Text:="CÓDIGO", Width:=70
            frmsol.bom_lst.ColumnHeaders.Add Text:="REV", Width:=25, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="DESCRIÇÃO", Width:=200
            frmsol.bom_lst.ColumnHeaders.Add Text:="QTD.", Width:=40, Alignment:=1
            frmsol.bom_lst.ColumnHeaders.Add Text:="TIPO", Width:=85, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="Nº OC", Width:=50, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="STATUS", Width:=70, Alignment:=2
            frmsol.bom_lst.ColumnHeaders.Add Text:="PEDIDO", Width:=50, Alignment:=2
            
            SQL = "SELECT B.Controle, B.Codigo, B.Revisao, B.Descricao, B.Qtde, B.Tipo, B.OC, Aq.Status, Aq.Pedido FROM BOM_Control B LEFT OUTER JOIN OC_Control Aq ON B.OC = Aq.OC WHERE B.Solicitacao = '" & cod_sl & "';"
            
            ArrRes_BOM = resQuery(SQL)

            If Not IsEmpty(ArrRes_BOM) Then
                tam_res = UBound(ArrRes_BOM, 2)
                frmsol.bom_lst.ListItems.Clear
                For i = 0 To tam_res
                    Set linha = frmsol.bom_lst.ListItems.Add(Text:=ArrRes_BOM(0, i)) 'Controle
                    If Not IsNull(ArrRes_BOM(1, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(1, i) Else linha.ListSubItems.Add Text:="" 'Codigo
                    If Not IsNull(ArrRes_BOM(2, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(2, i) Else linha.ListSubItems.Add Text:="" 'Revisao
                    If Not IsNull(ArrRes_BOM(3, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(3, i) Else linha.ListSubItems.Add Text:="" 'Descricao
                    If Not IsNull(ArrRes_BOM(4, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(4, i) Else linha.ListSubItems.Add Text:="" 'Qtde
                    If Not IsNull(ArrRes_BOM(5, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(5, i) Else linha.ListSubItems.Add Text:="" 'Tipo
                    If Not IsNull(ArrRes_BOM(6, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(6, i) Else linha.ListSubItems.Add Text:="" 'OC
                    If Not IsNull(ArrRes_BOM(7, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(7, i) Else linha.ListSubItems.Add Text:="" 'Status
                    If Not IsNull(ArrRes_BOM(8, i)) Then linha.ListSubItems.Add Text:=ArrRes_BOM(8, i) Else linha.ListSubItems.Add Text:="" 'Pedido
                Next i
            End If

            Colunas = frmsol.bom_lst.ColumnHeaders.Count
            Linhas = frmsol.bom_lst.ListItems.Count
    
            For i = 1 To Linhas

            sts = frmsol.bom_lst.ListItems(i).ListSubItems(7)
            cod = frmsol.bom_lst.ListItems(i).ListSubItems(1)
            OC = frmsol.bom_lst.ListItems(i).ListSubItems(6)
      
            If sts = "LIQUIDADA" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H8000&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H8000&
                Next X
            End If

            If sts = "PENDENTE" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF&
                Next X
            End If

            If sts = "REALIZADA" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H80FF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H80FF&
                Next X
            End If

            If sts = "EM ABERTO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF0000
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF0000
                Next X
            End If
        
            If sts = "COTAÇÃO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HC000C0
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HC000C0
                Next X
            End If
       
            If sts = "CANCELADO" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &H808080
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &H808080
                Next X
            End If
       
            If cod = "SIDERÚRGICO" And OC <> "" Then
                frmsol.bom_lst.ListItems(i).ForeColor = &HFF&
                For X = 1 To Colunas - 1
                    frmsol.bom_lst.ListItems(i).ListSubItems(X).ForeColor = &HFF&
                Next X
            End If
            Next i
        

        
        
End Sub

Sub carregaReqs(codSL)
    Dim SQL                 As String
    Dim ArrRes              As Variant
    Dim requisitos          As String
    Dim chkReq               As String
    Dim StConceito          As String
    Dim vtReq               As Variant
    Dim Reqs                As Variant
    Dim a                   As Integer
    
    codSL = Replace(codSL, "SL", "")
    
    SQL = "SELECT Requisitos, CKReq, Conceito_St FROM Fila WHERE Ref = " & codSL & ";"
    ArrRes = resQuery(SQL)
    If Not IsEmpty(ArrRes) Then
        If Not IsNull(ArrRes(0, 0)) Then requisitos = ArrRes(0, 0)
        If Not IsNull(ArrRes(1, 0)) Then chkReq = ArrRes(1, 0)
        If Not IsNull(ArrRes(2, 0)) Then StConceito = ArrRes(2, 0)
        
        If Not IsEmpty(requisitos) And requisitos <> "" Then
                vtReq = Split(requisitos, "-|-")
                For a = 0 To 9
                    If vtReq(a) <> "" Then
                        frmsol.Controls("txtReq" & Format(a + 1, "00")).Text = vtReq(a)
                    End If
                    If StConceito = "OK1" Then
                        frmsol.Controls("txtReq" & Format(a + 1, "00")).Locked = True
                    End If
                Next a
        End If
        
        If Not IsEmpty(chkReq) And chkReq <> "0|0|0|0|0|0|0|0|0|0|" And chkReq <> "" Then
            Reqs = Split(chkReq, "|")
            For a = 0 To 9
                If Reqs(a) = "A" Then
                    frmsol.Controls("chkReq" & Format(a + 1, "00")).Picture = frmsol.chkReqOn.Picture
                    frmsol.Controls("txtReq" & Format(a + 1, "00")).ForeColor = &H999900
                    frmsol.Controls("txtReq" & Format(a + 1, "00")).BorderColor = &H999900
                    frmsol.Controls("lblReq" & Format(a + 1, "00")).ForeColor = &H999900
                End If
            Next a
            
        End If
    End If
End Sub
```

---

## `ufdxf`

```vb
Attribute VB_Name = "ufdxf"
Attribute VB_Base = "0{B8E8382F-16FA-4CDF-ACA0-E5E314F4ABB7}{679F29D4-B76B-4260-BF75-D3DF48D88559}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Private Sub btn_novo_dxf_Click()
'Carrega DXFs

Dim dxf_path As String
Dim floorDxf As Long
Dim controleDxf As Long
Dim arrMax As Variant

dxf_path = AbreZIP

t_desc = frmsol.lbl_desc.Caption
t_cod_z = frmsol.lbl_cod_z.Caption
ctrl = Replace(t_cod_z, "Z", "")
t_cod_sl = frmsol.lbl_ref.Caption
t_projeto = frmsol.lbl_vg.Caption & "_" & frmsol.lbl_lote.Caption
t_projetista = frmsol.lbl_projetista.Caption
t_prioridade = UF.cmb_prio_dxf.Text
t_data_dxf = DateValue(Date)

' Cartorio: pede o numero global do DXF a web (passando o MAX local como piso)
floorDxf = 0
arrMax = resQuery("SELECT MAX(Controle) FROM DXF_Control;")
If Not IsEmpty(arrMax) Then If Not IsNull(arrMax(0, 0)) Then floorDxf = CLng(arrMax(0, 0))
controleDxf = pedirProximoDxf(floorDxf)
If controleDxf <= 0 Then
    MsgBox "Nao foi possivel obter o numero do DXF (web). Operacao cancelada.", vbExclamation
    Exit Sub
End If

' INSERT com Controle EXPLICITO (Controle agora e Numero, nao AutoNumeracao)
SQL = "INSERT INTO DXF_Control (Controle, Descricao, Cod_Proj, Solicitacao, Projeto, Projetista, Prioridade, Data_DXF, IMG, DXF) VALUES ("
SQL = SQL & controleDxf & ","
SQL = SQL & "'" & t_desc & "',"
SQL = SQL & "'" & t_cod_z & "',"
SQL = SQL & "'" & t_cod_sl & "',"
SQL = SQL & "'" & t_projeto & "',"
SQL = SQL & "'" & t_projetista & "',"
SQL = SQL & "'" & t_prioridade & "',"
SQL = SQL & "'" & t_data_dxf & "', TRUE, TRUE)"

upQuery (SQL)

t_cod_dxf = "DX" & Format(controleDxf, "0000")

newPathDXF = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.dxf" 'Folder dos arquivos DXF
Dim fs As Object
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile dxf_path, newPathDXF & "\" & t_cod_dxf & ".zip"
Set fs = Nothing

' Access -> Web: envia o pacote DXF pro MySQL/web
enviarDxfParaMySQL CLng(Replace(t_cod_sl, "SL", "")), t_cod_dxf, newPathDXF & "\" & t_cod_dxf & ".zip"

img_path = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & t_cod_sl & ".jpg"
newPathIMG = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.imgs" 'Folder das imagens DXF
Dim FS2 As Object
Set FS2 = CreateObject("Scripting.FileSystemObject")
FS2.CopyFile img_path, newPathIMG & "\" & t_cod_dxf & ".jpg"
Set FS2 = Nothing

MsgBox "Pacote de DXF nº " & t_cod_dxf & " inserido com sucesso!"

Call Carrega_DFX(frmsol.lbl_ref.Caption)

Unload Me

End Sub

Private Sub btn_reparar_Click()
Dim SQL As String

SQL = "SELECT Controle FROM DXF_Control WHERE Solicitacao ='" & frmsol.lbl_ref.Caption & "';"

ArrRes = resQuery(SQL)
If Not IsEmpty(ArrRes) Then
uf_lista_dxf.lst_dxf.Clear
For a = 0 To UBound(ArrRes, 2)
    uf_lista_dxf.lst_dxf.AddItem ("DX" & Format(ArrRes(0, a), "0000"))
Next a
End If

Unload Me
uf_lista_dxf.Show

End Sub
```

---

## `uf_lista_dxf`

```vb
Attribute VB_Name = "uf_lista_dxf"
Attribute VB_Base = "0{C6C3BE26-6BD1-458D-AA46-09A5483E6F35}{BC7A82BD-BBB1-4B50-A590-39AF7A124C5E}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Private Sub btn_carregar_Click()
'Carrega DXFs
Dim dxf_path As String
dxf_path = AbreZIP

Me.lbl_path_dxf.Caption = dxf_path

Me.lbl_ok.ForeColor = &H4000&
Me.lbl_ok.BackColor = &HC000&
Me.btn_reparar.Enabled = True




End Sub

Private Sub btn_reparar_Click()
Dim SLQ As String

t_cod_dxf = Me.lst_dxf.Text
n_ctrl = Replace(t_cod_dxf, "DX", "")
t_data_dxf = DateValue(Date)

SQL = "UPDATE DXF_Control SET Data_DXF = " & t_data_dxf & " WHERE Controle = " & n_ctrl & ";"
upQuery (SQL)

dxf_path = Me.lbl_path_dxf.Caption

newPathDXF = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.dxf" 'Folder dos pacotes DXF
Dim fs As Object
Set fs = CreateObject("Scripting.FileSystemObject")
fs.CopyFile dxf_path, newPathDXF & "\" & t_cod_dxf & ".zip"
Set fs = Nothing

' Access -> Web: reenvia o pacote DXF substituido
enviarDxfParaMySQL CLng(Replace(frmsol.lbl_ref.Caption, "SL", "")), t_cod_dxf, newPathDXF & "\" & t_cod_dxf & ".zip"

MsgBox "Pacote de DXF nº " & t_cod_dxf & " substituído com sucesso!"

Call Carrega_DFX(frmsol.lbl_ref.Caption)

Unload Me



End Sub

Private Sub lst_dxf_Click()

If Me.lst_dxf.Text <> "" Then

    Me.btn_carregar.Enabled = True

End If

End Sub
```

---

## `frm_bom`

```vb
Attribute VB_Name = "frm_bom"
Attribute VB_Base = "0{FE49C5EC-1872-43E2-AB72-1B47E3C07A99}{0EF9FC77-FC53-4FA2-8E55-13EB5B976F24}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False


Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_carregar_Click()
    
    Dim Arquivo As Integer
    Dim CaminhoArquivo As String
    Dim TextoArquivo As String
    Dim TextoProximaLinha As String
    Dim ContadorLinha As Long
    
    Dim N_ultimo As Integer
        
    'Configura a leitura do arquivo
    Arquivo = FreeFile
    CaminhoArquivo = OpenTXTDialog
    
    'Abre o arquivo para leitura
    Open CaminhoArquivo For Input As Arquivo
    i = 1
    'Lê o conteúdo do arquivo linha a linha
    Do While Not EOF(Arquivo)
        Line Input #Arquivo, txt
        
        cod = Trim(Left(txt, 20))
        rev = Trim(Mid(txt, 21, 5))
        desc = Replace(Trim(Mid(txt, 27, 100)), "'", "")
        qtde = Trim(Mid(txt, 128, 15))
        tipo = Trim(Mid(txt, 144, 30))
        If cod <> "" Then
            Me.Controls("cod" & i).Value = cod
            Me.Controls("rev" & i).Value = rev
            Me.Controls("desc" & i).Value = desc
            Me.Controls("qtde" & i).Value = Format(qtde, "0.00")
            Me.Controls("tipo" & i).Value = tipo
            i = i + 1
        End If
    Loop
       
    'Fecha o arquivo
    Close Arquivo
    
    If i = 1 Then
        Me.Controls("cod" & i).Value = "VAZIO"
    End If

End Sub

Private Sub btn_inserir_Click()

Dim li As ListItem

UF.bom_lst.ListItems.Clear

For i = 1 To 100
    If Me.Controls("cod" & i).Text <> "" And Me.Controls("cod" & i).Text <> "VAZIO" Then
        Set li = UF.bom_lst.ListItems.Add(, , Me.Controls("cod" & i).Text)
            li.ListSubItems.Add , , Me.Controls("rev" & i).Text
            li.ListSubItems.Add , , Me.Controls("desc" & i).Text
            li.ListSubItems.Add , , Me.Controls("qtde" & i).Text
            li.ListSubItems.Add , , Me.Controls("tipo" & i).Text
            
            lst_ok = 1
            
    End If
Next i
If Me.Controls("cod1").Text = "VAZIO" Then
    lst_ok = 1
End If

Unload Me

If lst_ok = 1 Then
    UF.btn_editar_bom.Enabled = True
    UF.btn_pdf.Enabled = True
    UF.btn_bom.BackColor = &H80FF80
    UF.btn_pdf.BackColor = &HC0C0FF
    UF.seta4.Enabled = True
End If
End Sub

Private Sub btnCancelar_Click()
Unload Me
End Sub


Private Sub btnCarregar_Click()
    Dim Arquivo As Integer
    Dim CaminhoArquivo As String
    Dim TextoArquivo As String
    Dim TextoProximaLinha As String
    Dim ContadorLinha As Long
    
    Dim N_ultimo As Integer
        
    'Configura a leitura do arquivo
    Arquivo = FreeFile
    CaminhoArquivo = OpenTXTDialog
    
    'Abre o arquivo para leitura
    Open CaminhoArquivo For Input As Arquivo
    i = 1
    'Lê o conteúdo do arquivo linha a linha
    Do While Not EOF(Arquivo)
        Line Input #Arquivo, txt
        
        cod = Trim(Left(txt, 20))
        rev = Trim(Mid(txt, 21, 5))
        desc = Replace(Trim(Mid(txt, 27, 100)), "'", "")
        qtde = Trim(Mid(txt, 128, 15))
        tipo = Trim(Mid(txt, 144, 30))
        If cod <> "" Then
            Me.Controls("cod" & i).Value = cod
            Me.Controls("rev" & i).Value = rev
            Me.Controls("desc" & i).Value = desc
            Me.Controls("qtde" & i).Value = Format(qtde, "0.00")
            Me.Controls("tipo" & i).Value = tipo
            i = i + 1
        End If
    Loop
       
    'Fecha o arquivo
    Close Arquivo
    
    If i = 1 Then
        Me.Controls("cod" & i).Value = "VAZIO"
    End If

End Sub

Private Sub btnInserir_Click()

    Dim bomPayload As String

    If Me.lblTipo.Caption = "Auto" Then

        bomPayload = ""
        t_cod_sl = Me.lbl_ref.Caption
        t_cod_z = Me.lblCodZ.Caption
        'Carrega Lista de Comprados
        For i = 1 To 100
            If Me.Controls("cod" & i).Text <> "" Then
                t_codigo = Me.Controls("cod" & i).Text
                t_rev = Me.Controls("rev" & i).Text
                t_desc_bom = Me.Controls("desc" & i).Text
                t_qtde = Me.Controls("qtde" & i).Text
                t_tipo = Me.Controls("tipo" & i).Text
                If Not IsNumeric(t_qtde) Then t_qtde = 0
                t_qtde = Replace(t_qtde, ",", ".")

                SQL = "INSERT INTO BOM_Control (Projeto, Solicitacao, Codigo, Revisao, Descricao, Qtde, Tipo) VALUES ("
                SQL = SQL & "'" & t_cod_z & "',"
                SQL = SQL & "'" & t_cod_sl & "',"
                SQL = SQL & "'" & t_codigo & "',"
                SQL = SQL & "'" & t_rev & "',"
                SQL = SQL & "'" & t_desc_bom & "',"
                SQL = SQL & t_qtde & ","
                SQL = SQL & "'" & t_tipo & "');"

                upQuery (SQL)

                ' Acumula a linha p/ enviar pro MySQL/web (campos separados por TAB)
                bomPayload = bomPayload & t_codigo & vbTab & t_rev & vbTab & t_desc_bom & vbTab & t_qtde & vbTab & t_tipo & vbLf
            End If
        Next i

        ' Access -> Web: envia o lote de BOM
        enviarBomParaMySQL CLng(Replace(t_cod_sl, "SL", "")), bomPayload

        Unload Me
        Call CarregaBOMAut(t_cod_sl)

    Else
        Dim li As ListItem
        UF.bom_lst.ListItems.Clear
        For i = 1 To 100
            If Me.Controls("cod" & i).Text <> "" And Me.Controls("cod" & i).Text <> "VAZIO" Then
                Set li = UF.bom_lst.ListItems.Add(, , Me.Controls("cod" & i).Text)
                    li.ListSubItems.Add , , Me.Controls("rev" & i).Text
                    li.ListSubItems.Add , , Me.Controls("desc" & i).Text
                    li.ListSubItems.Add , , Me.Controls("qtde" & i).Text
                    li.ListSubItems.Add , , Me.Controls("tipo" & i).Text
                    lst_ok = 1
            End If
        Next i
        If Me.Controls("cod1").Text = "VAZIO" Then
            lst_ok = 1
        End If
        Unload Me

        If lst_ok = 1 Then
            UF.btn_editar_bom.Enabled = True
            UF.btn_pdf.Enabled = True
            UF.btn_bom.BackColor = &H80FF80
            UF.btn_pdf.BackColor = &HC0C0FF
            UF.seta4.Enabled = True
        End If
    End If
End Sub

Private Sub cod1_Change()
    If Me.cod1.Text <> "" Then
        Me.id2.Visible = True
        Me.cod2.Visible = True
        Me.rev2.Visible = True
        Me.desc2.Visible = True
        Me.qtde2.Visible = True
        Me.tipo2.Visible = True
    End If
End Sub
Private Sub cod2_Change()
    If Me.cod2.Text <> "" Then
        Me.id3.Visible = True
        Me.cod3.Visible = True
        Me.rev3.Visible = True
        Me.desc3.Visible = True
        Me.qtde3.Visible = True
        Me.tipo3.Visible = True
    End If
End Sub
Private Sub cod3_Change()
    If Me.cod3.Text <> "" Then
        Me.id4.Visible = True
        Me.cod4.Visible = True
        Me.rev4.Visible = True
        Me.desc4.Visible = True
        Me.qtde4.Visible = True
        Me.tipo4.Visible = True
    End If
End Sub
Private Sub cod4_Change()
    If Me.cod4.Text <> "" Then
        Me.id5.Visible = True
        Me.cod5.Visible = True
        Me.rev5.Visible = True
        Me.desc5.Visible = True
        Me.qtde5.Visible = True
        Me.tipo5.Visible = True
    End If
End Sub
Private Sub cod5_Change()
    If Me.cod5.Text <> "" Then
        Me.id6.Visible = True
        Me.cod6.Visible = True
        Me.rev6.Visible = True
        Me.desc6.Visible = True
        Me.qtde6.Visible = True
        Me.tipo6.Visible = True
    End If
End Sub
Private Sub cod6_Change()
    If Me.cod6.Text <> "" Then
        Me.id7.Visible = True
        Me.cod7.Visible = True
        Me.rev7.Visible = True
        Me.desc7.Visible = True
        Me.qtde7.Visible = True
        Me.tipo7.Visible = True
    End If
End Sub
Private Sub cod7_Change()
    If Me.cod7.Text <> "" Then
        Me.id8.Visible = True
        Me.cod8.Visible = True
        Me.rev8.Visible = True
        Me.desc8.Visible = True
        Me.qtde8.Visible = True
        Me.tipo8.Visible = True
    End If
End Sub
Private Sub cod8_Change()
    If Me.cod8.Text <> "" Then
        Me.id9.Visible = True
        Me.cod9.Visible = True
        Me.rev9.Visible = True
        Me.desc9.Visible = True
        Me.qtde9.Visible = True
        Me.tipo9.Visible = True
    End If
End Sub
Private Sub cod9_Change()
    If Me.cod9.Text <> "" Then
        Me.id10.Visible = True
        Me.cod10.Visible = True
        Me.rev10.Visible = True
        Me.desc10.Visible = True
        Me.qtde10.Visible = True
        Me.tipo10.Visible = True
    End If
End Sub
Private Sub cod10_Change()
    If Me.cod10.Text <> "" Then
        Me.id11.Visible = True
        Me.cod11.Visible = True
        Me.rev11.Visible = True
        Me.desc11.Visible = True
        Me.qtde11.Visible = True
        Me.tipo11.Visible = True
        Me.frm_lista.ScrollBars = fmScrollBarsVertical
        Me.frm_lista.ScrollHeight = 220 + 18
    End If
End Sub
Private Sub cod11_Change()
    If Me.cod11.Text <> "" Then
        Me.id12.Visible = True
        Me.cod12.Visible = True
        Me.rev12.Visible = True
        Me.desc12.Visible = True
        Me.qtde12.Visible = True
        Me.tipo12.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 36
    End If
End Sub
Private Sub cod12_Change()
    If Me.cod12.Text <> "" Then
        Me.id13.Visible = True
        Me.cod13.Visible = True
        Me.rev13.Visible = True
        Me.desc13.Visible = True
        Me.qtde13.Visible = True
        Me.tipo13.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 54
    End If
End Sub
Private Sub cod13_Change()
    If Me.cod13.Text <> "" Then
        Me.id14.Visible = True
        Me.cod14.Visible = True
        Me.rev14.Visible = True
        Me.desc14.Visible = True
        Me.qtde14.Visible = True
        Me.tipo14.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 72
    End If
End Sub

Private Sub cod14_Change()
    If Me.cod14.Text <> "" Then
        Me.id15.Visible = True
        Me.cod15.Visible = True
        Me.rev15.Visible = True
        Me.desc15.Visible = True
        Me.qtde15.Visible = True
        Me.tipo15.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 90
    End If
End Sub

Private Sub cod15_Change()
    If Me.cod15.Text <> "" Then
        Me.id16.Visible = True
        Me.cod16.Visible = True
        Me.rev16.Visible = True
        Me.desc16.Visible = True
        Me.qtde16.Visible = True
        Me.tipo16.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 108
    End If
End Sub

Private Sub cod16_Change()
    If Me.cod16.Text <> "" Then
        Me.id17.Visible = True
        Me.cod17.Visible = True
        Me.rev17.Visible = True
        Me.desc17.Visible = True
        Me.qtde17.Visible = True
        Me.tipo17.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 126
    End If
End Sub

Private Sub cod17_Change()
    If Me.cod17.Text <> "" Then
        Me.id18.Visible = True
        Me.cod18.Visible = True
        Me.rev18.Visible = True
        Me.desc18.Visible = True
        Me.qtde18.Visible = True
        Me.tipo18.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 144
    End If
End Sub

Private Sub cod18_Change()
    If Me.cod18.Text <> "" Then
        Me.id19.Visible = True
        Me.cod19.Visible = True
        Me.rev19.Visible = True
        Me.desc19.Visible = True
        Me.qtde19.Visible = True
        Me.tipo19.Visible = True
        Me.frm_lista.ScrollHeight = 220 + 162
    End If
End Sub

Private Sub cod19_Change()
    If Me.cod19.Text <> "" Then
        Me.id20.Visible = True
        Me.cod20.Visible = True
        Me.rev20.Visible = True
        Me.desc20.Visible = True
        Me.qtde20.Visible = True
        Me.tipo20.Visible = True
        Me.frm_lista.ScrollHeight = 400
    End If
End Sub

Private Sub cod20_Change()
    If Me.cod20.Text <> "" Then
        Me.id21.Visible = True
        Me.cod21.Visible = True
        Me.rev21.Visible = True
        Me.desc21.Visible = True
        Me.qtde21.Visible = True
        Me.tipo21.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 18
    End If
End Sub

Private Sub cod21_Change()
    If Me.cod21.Text <> "" Then
        Me.id22.Visible = True
        Me.cod22.Visible = True
        Me.rev22.Visible = True
        Me.desc22.Visible = True
        Me.qtde22.Visible = True
        Me.tipo22.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 36
    End If
End Sub

Private Sub cod22_Change()
    If Me.cod22.Text <> "" Then
        Me.id23.Visible = True
        Me.cod23.Visible = True
        Me.rev23.Visible = True
        Me.desc23.Visible = True
        Me.qtde23.Visible = True
        Me.tipo23.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 54
    End If
End Sub

Private Sub cod23_Change()
    If Me.cod23.Text <> "" Then
        Me.id24.Visible = True
        Me.cod24.Visible = True
        Me.rev24.Visible = True
        Me.desc24.Visible = True
        Me.qtde24.Visible = True
        Me.tipo24.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 72
    End If
End Sub

Private Sub cod24_Change()
    If Me.cod24.Text <> "" Then
        Me.id25.Visible = True
        Me.cod25.Visible = True
        Me.rev25.Visible = True
        Me.desc25.Visible = True
        Me.qtde25.Visible = True
        Me.tipo25.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 90
    End If
End Sub

Private Sub cod25_Change()
    If Me.cod25.Text <> "" Then
        Me.id26.Visible = True
        Me.cod26.Visible = True
        Me.rev26.Visible = True
        Me.desc26.Visible = True
        Me.qtde26.Visible = True
        Me.tipo26.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 108
    End If
End Sub

Private Sub cod26_Change()
    If Me.cod26.Text <> "" Then
        Me.id27.Visible = True
        Me.cod27.Visible = True
        Me.rev27.Visible = True
        Me.desc27.Visible = True
        Me.qtde27.Visible = True
        Me.tipo27.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 126
    End If
End Sub

Private Sub cod27_Change()
    If Me.cod27.Text <> "" Then
        Me.id28.Visible = True
        Me.cod28.Visible = True
        Me.rev28.Visible = True
        Me.desc28.Visible = True
        Me.qtde28.Visible = True
        Me.tipo28.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 144
    End If
End Sub

Private Sub cod28_Change()
    If Me.cod28.Text <> "" Then
        Me.id29.Visible = True
        Me.cod29.Visible = True
        Me.rev29.Visible = True
        Me.desc29.Visible = True
        Me.qtde29.Visible = True
        Me.tipo29.Visible = True
        Me.frm_lista.ScrollHeight = 400 + 162
    End If
End Sub

Private Sub cod29_Change()
    If Me.cod29.Text <> "" Then
        Me.id30.Visible = True
        Me.cod30.Visible = True
        Me.rev30.Visible = True
        Me.desc30.Visible = True
        Me.qtde30.Visible = True
        Me.tipo30.Visible = True
        Me.frm_lista.ScrollHeight = 580
    End If
End Sub

Private Sub cod30_Change()
    If Me.cod30.Text <> "" Then
        Me.id31.Visible = True
        Me.cod31.Visible = True
        Me.rev31.Visible = True
        Me.desc31.Visible = True
        Me.qtde31.Visible = True
        Me.tipo31.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 18
    End If
End Sub

Private Sub cod31_Change()
    If Me.cod31.Text <> "" Then
        Me.id32.Visible = True
        Me.cod32.Visible = True
        Me.rev32.Visible = True
        Me.desc32.Visible = True
        Me.qtde32.Visible = True
        Me.tipo32.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 36
    End If
End Sub

Private Sub cod32_Change()
    If Me.cod32.Text <> "" Then
        Me.id33.Visible = True
        Me.cod33.Visible = True
        Me.rev33.Visible = True
        Me.desc33.Visible = True
        Me.qtde33.Visible = True
        Me.tipo33.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 54
    End If
End Sub

Private Sub cod33_Change()
    If Me.cod33.Text <> "" Then
        Me.id34.Visible = True
        Me.cod34.Visible = True
        Me.rev34.Visible = True
        Me.desc34.Visible = True
        Me.qtde34.Visible = True
        Me.tipo34.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 72
    End If
End Sub

Private Sub cod34_Change()
    If Me.cod34.Text <> "" Then
        Me.id35.Visible = True
        Me.cod35.Visible = True
        Me.rev35.Visible = True
        Me.desc35.Visible = True
        Me.qtde35.Visible = True
        Me.tipo35.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 90
    End If
End Sub

Private Sub cod35_Change()
    If Me.cod35.Text <> "" Then
        Me.id36.Visible = True
        Me.cod36.Visible = True
        Me.rev36.Visible = True
        Me.desc36.Visible = True
        Me.qtde36.Visible = True
        Me.tipo36.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 108
    End If
End Sub

Private Sub cod36_Change()
    If Me.cod36.Text <> "" Then
        Me.id37.Visible = True
        Me.cod37.Visible = True
        Me.rev37.Visible = True
        Me.desc37.Visible = True
        Me.qtde37.Visible = True
        Me.tipo37.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 126
    End If
End Sub

Private Sub cod37_Change()
    If Me.cod37.Text <> "" Then
        Me.id38.Visible = True
        Me.cod38.Visible = True
        Me.rev38.Visible = True
        Me.desc38.Visible = True
        Me.qtde38.Visible = True
        Me.tipo38.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 144
    End If
End Sub

Private Sub cod38_Change()
    If Me.cod38.Text <> "" Then
        Me.id39.Visible = True
        Me.cod39.Visible = True
        Me.rev39.Visible = True
        Me.desc39.Visible = True
        Me.qtde39.Visible = True
        Me.tipo39.Visible = True
        Me.frm_lista.ScrollHeight = 580 + 162
    End If
End Sub

Private Sub cod39_Change()
    If Me.cod39.Text <> "" Then
        Me.id40.Visible = True
        Me.cod40.Visible = True
        Me.rev40.Visible = True
        Me.desc40.Visible = True
        Me.qtde40.Visible = True
        Me.tipo40.Visible = True
        Me.frm_lista.ScrollHeight = 760
    End If
End Sub

Private Sub cod40_Change()
    If Me.cod40.Text <> "" Then
        Me.id41.Visible = True
        Me.cod41.Visible = True
        Me.rev41.Visible = True
        Me.desc41.Visible = True
        Me.qtde41.Visible = True
        Me.tipo41.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 18
    End If
End Sub

Private Sub cod41_Change()
    If Me.cod41.Text <> "" Then
        Me.id42.Visible = True
        Me.cod42.Visible = True
        Me.rev42.Visible = True
        Me.desc42.Visible = True
        Me.qtde42.Visible = True
        Me.tipo42.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 36
    End If
End Sub

Private Sub cod42_Change()
    If Me.cod42.Text <> "" Then
        Me.id43.Visible = True
        Me.cod43.Visible = True
        Me.rev43.Visible = True
        Me.desc43.Visible = True
        Me.qtde43.Visible = True
        Me.tipo43.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 54
    End If
End Sub

Private Sub cod43_Change()
    If Me.cod43.Text <> "" Then
        Me.id44.Visible = True
        Me.cod44.Visible = True
        Me.rev44.Visible = True
        Me.desc44.Visible = True
        Me.qtde44.Visible = True
        Me.tipo44.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 72
    End If
End Sub

Private Sub cod44_Change()
    If Me.cod44.Text <> "" Then
        Me.id45.Visible = True
        Me.cod45.Visible = True
        Me.rev45.Visible = True
        Me.desc45.Visible = True
        Me.qtde45.Visible = True
        Me.tipo45.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 90
    End If
End Sub

Private Sub cod45_Change()
    If Me.cod45.Text <> "" Then
        Me.id46.Visible = True
        Me.cod46.Visible = True
        Me.rev46.Visible = True
        Me.desc46.Visible = True
        Me.qtde46.Visible = True
        Me.tipo46.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 108
    End If
End Sub

Private Sub cod46_Change()
    If Me.cod46.Text <> "" Then
        Me.id47.Visible = True
        Me.cod47.Visible = True
        Me.rev47.Visible = True
        Me.desc47.Visible = True
        Me.qtde47.Visible = True
        Me.tipo47.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 126
    End If
End Sub

Private Sub cod47_Change()
    If Me.cod47.Text <> "" Then
        Me.id48.Visible = True
        Me.cod48.Visible = True
        Me.rev48.Visible = True
        Me.desc48.Visible = True
        Me.qtde48.Visible = True
        Me.tipo48.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 144
    End If
End Sub

Private Sub cod48_Change()
    If Me.cod48.Text <> "" Then
        Me.id49.Visible = True
        Me.cod49.Visible = True
        Me.rev49.Visible = True
        Me.desc49.Visible = True
        Me.qtde49.Visible = True
        Me.tipo49.Visible = True
        Me.frm_lista.ScrollHeight = 760 + 162
    End If
End Sub

Private Sub cod49_Change()
    If Me.cod49.Text <> "" Then
        Me.id50.Visible = True
        Me.cod50.Visible = True
        Me.rev50.Visible = True
        Me.desc50.Visible = True
        Me.qtde50.Visible = True
        Me.tipo50.Visible = True
        Me.frm_lista.ScrollHeight = 940
    End If
End Sub

'############################################################################
Private Sub cod50_Change()
    If Me.cod50.Text <> "" Then
        Me.id51.Visible = True
        Me.cod51.Visible = True
        Me.rev51.Visible = True
        Me.desc51.Visible = True
        Me.qtde51.Visible = True
        Me.tipo51.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 18
    End If
End Sub

Private Sub cod51_Change()
    If Me.cod51.Text <> "" Then
        Me.id52.Visible = True
        Me.cod52.Visible = True
        Me.rev52.Visible = True
        Me.desc52.Visible = True
        Me.qtde52.Visible = True
        Me.tipo52.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 36
    End If
End Sub

Private Sub cod52_Change()
    If Me.cod52.Text <> "" Then
        Me.id53.Visible = True
        Me.cod53.Visible = True
        Me.rev53.Visible = True
        Me.desc53.Visible = True
        Me.qtde53.Visible = True
        Me.tipo53.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 54
    End If
End Sub

Private Sub cod53_Change()
    If Me.cod53.Text <> "" Then
        Me.id54.Visible = True
        Me.cod54.Visible = True
        Me.rev54.Visible = True
        Me.desc54.Visible = True
        Me.qtde54.Visible = True
        Me.tipo54.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 72
    End If
End Sub

Private Sub cod54_Change()
    If Me.cod54.Text <> "" Then
        Me.id55.Visible = True
        Me.cod55.Visible = True
        Me.rev55.Visible = True
        Me.desc55.Visible = True
        Me.qtde55.Visible = True
        Me.tipo55.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 90
    End If
End Sub

Private Sub cod55_Change()
    If Me.cod55.Text <> "" Then
        Me.id56.Visible = True
        Me.cod56.Visible = True
        Me.rev56.Visible = True
        Me.desc56.Visible = True
        Me.qtde56.Visible = True
        Me.tipo56.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 108
    End If
End Sub

Private Sub cod56_Change()
    If Me.cod56.Text <> "" Then
        Me.id57.Visible = True
        Me.cod57.Visible = True
        Me.rev57.Visible = True
        Me.desc57.Visible = True
        Me.qtde57.Visible = True
        Me.tipo57.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 126
    End If
End Sub

Private Sub cod57_Change()
    If Me.cod57.Text <> "" Then
        Me.id58.Visible = True
        Me.cod58.Visible = True
        Me.rev58.Visible = True
        Me.desc58.Visible = True
        Me.qtde58.Visible = True
        Me.tipo58.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 144
    End If
End Sub

Private Sub cod58_Change()
    If Me.cod58.Text <> "" Then
        Me.id59.Visible = True
        Me.cod59.Visible = True
        Me.rev59.Visible = True
        Me.desc59.Visible = True
        Me.qtde59.Visible = True
        Me.tipo59.Visible = True
        Me.frm_lista.ScrollHeight = 940 + 162
    End If
End Sub

Private Sub cod59_Change()
    If Me.cod59.Text <> "" Then
        Me.id60.Visible = True
        Me.cod60.Visible = True
        Me.rev60.Visible = True
        Me.desc60.Visible = True
        Me.qtde60.Visible = True
        Me.tipo60.Visible = True
        Me.frm_lista.ScrollHeight = 1120
    End If
End Sub

'############################################################################
Private Sub cod60_Change()
    If Me.cod60.Text <> "" Then
        Me.id61.Visible = True
        Me.cod61.Visible = True
        Me.rev61.Visible = True
        Me.desc61.Visible = True
        Me.qtde61.Visible = True
        Me.tipo61.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 18
    End If
End Sub

Private Sub cod61_Change()
    If Me.cod61.Text <> "" Then
        Me.id62.Visible = True
        Me.cod62.Visible = True
        Me.rev62.Visible = True
        Me.desc62.Visible = True
        Me.qtde62.Visible = True
        Me.tipo62.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 36
    End If
End Sub

Private Sub cod62_Change()
    If Me.cod62.Text <> "" Then
        Me.id63.Visible = True
        Me.cod63.Visible = True
        Me.rev63.Visible = True
        Me.desc63.Visible = True
        Me.qtde63.Visible = True
        Me.tipo63.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 54
    End If
End Sub

Private Sub cod63_Change()
    If Me.cod63.Text <> "" Then
        Me.id64.Visible = True
        Me.cod64.Visible = True
        Me.rev64.Visible = True
        Me.desc64.Visible = True
        Me.qtde64.Visible = True
        Me.tipo64.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 72
    End If
End Sub

Private Sub cod64_Change()
    If Me.cod64.Text <> "" Then
        Me.id65.Visible = True
        Me.cod65.Visible = True
        Me.rev65.Visible = True
        Me.desc65.Visible = True
        Me.qtde65.Visible = True
        Me.tipo65.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 90
    End If
End Sub

Private Sub cod65_Change()
    If Me.cod65.Text <> "" Then
        Me.id66.Visible = True
        Me.cod66.Visible = True
        Me.rev66.Visible = True
        Me.desc66.Visible = True
        Me.qtde66.Visible = True
        Me.tipo66.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 108
    End If
End Sub

Private Sub cod66_Change()
    If Me.cod66.Text <> "" Then
        Me.id67.Visible = True
        Me.cod67.Visible = True
        Me.rev67.Visible = True
        Me.desc67.Visible = True
        Me.qtde67.Visible = True
        Me.tipo67.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 126
    End If
End Sub

Private Sub cod67_Change()
    If Me.cod67.Text <> "" Then
        Me.id68.Visible = True
        Me.cod68.Visible = True
        Me.rev68.Visible = True
        Me.desc68.Visible = True
        Me.qtde68.Visible = True
        Me.tipo68.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 144
    End If
End Sub

Private Sub cod68_Change()
    If Me.cod68.Text <> "" Then
        Me.id69.Visible = True
        Me.cod69.Visible = True
        Me.rev69.Visible = True
        Me.desc69.Visible = True
        Me.qtde69.Visible = True
        Me.tipo69.Visible = True
        Me.frm_lista.ScrollHeight = 1120 + 162
    End If
End Sub

Private Sub cod69_Change()
    If Me.cod69.Text <> "" Then
        Me.id70.Visible = True
        Me.cod70.Visible = True
        Me.rev70.Visible = True
        Me.desc70.Visible = True
        Me.qtde70.Visible = True
        Me.tipo70.Visible = True
        Me.frm_lista.ScrollHeight = 1300
    End If
End Sub

'############################################################################
Private Sub cod70_Change()
    If Me.cod70.Text <> "" Then
        Me.id71.Visible = True
        Me.cod71.Visible = True
        Me.rev71.Visible = True
        Me.desc71.Visible = True
        Me.qtde71.Visible = True
        Me.tipo71.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 18
    End If
End Sub

Private Sub cod71_Change()
    If Me.cod71.Text <> "" Then
        Me.id72.Visible = True
        Me.cod72.Visible = True
        Me.rev72.Visible = True
        Me.desc72.Visible = True
        Me.qtde72.Visible = True
        Me.tipo72.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 36
    End If
End Sub

Private Sub cod72_Change()
    If Me.cod72.Text <> "" Then
        Me.id73.Visible = True
        Me.cod73.Visible = True
        Me.rev73.Visible = True
        Me.desc73.Visible = True
        Me.qtde73.Visible = True
        Me.tipo73.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 54
    End If
End Sub

Private Sub cod73_Change()
    If Me.cod73.Text <> "" Then
        Me.id74.Visible = True
        Me.cod74.Visible = True
        Me.rev74.Visible = True
        Me.desc74.Visible = True
        Me.qtde74.Visible = True
        Me.tipo74.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 72
    End If
End Sub

Private Sub cod74_Change()
    If Me.cod74.Text <> "" Then
        Me.id75.Visible = True
        Me.cod75.Visible = True
        Me.rev75.Visible = True
        Me.desc75.Visible = True
        Me.qtde75.Visible = True
        Me.tipo75.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 90
    End If
End Sub

Private Sub cod75_Change()
    If Me.cod75.Text <> "" Then
        Me.id76.Visible = True
        Me.cod76.Visible = True
        Me.rev76.Visible = True
        Me.desc76.Visible = True
        Me.qtde76.Visible = True
        Me.tipo76.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 108
    End If
End Sub

Private Sub cod76_Change()
    If Me.cod76.Text <> "" Then
        Me.id77.Visible = True
        Me.cod77.Visible = True
        Me.rev77.Visible = True
        Me.desc77.Visible = True
        Me.qtde77.Visible = True
        Me.tipo77.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 126
    End If
End Sub

Private Sub cod77_Change()
    If Me.cod77.Text <> "" Then
        Me.id78.Visible = True
        Me.cod78.Visible = True
        Me.rev78.Visible = True
        Me.desc78.Visible = True
        Me.qtde78.Visible = True
        Me.tipo78.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 144
    End If
End Sub

Private Sub cod78_Change()
    If Me.cod78.Text <> "" Then
        Me.id79.Visible = True
        Me.cod79.Visible = True
        Me.rev79.Visible = True
        Me.desc79.Visible = True
        Me.qtde79.Visible = True
        Me.tipo79.Visible = True
        Me.frm_lista.ScrollHeight = 1300 + 162
    End If
End Sub

Private Sub cod79_Change()
    If Me.cod79.Text <> "" Then
        Me.id80.Visible = True
        Me.cod80.Visible = True
        Me.rev80.Visible = True
        Me.desc80.Visible = True
        Me.qtde80.Visible = True
        Me.tipo80.Visible = True
        Me.frm_lista.ScrollHeight = 1480
    End If
End Sub


'############################################################################
Private Sub cod80_Change()
    If Me.cod80.Text <> "" Then
        Me.id81.Visible = True
        Me.cod81.Visible = True
        Me.rev81.Visible = True
        Me.desc81.Visible = True
        Me.qtde81.Visible = True
        Me.tipo81.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 18
    End If
End Sub

Private Sub cod81_Change()
    If Me.cod81.Text <> "" Then
        Me.id82.Visible = True
        Me.cod82.Visible = True
        Me.rev82.Visible = True
        Me.desc82.Visible = True
        Me.qtde82.Visible = True
        Me.tipo82.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 36
    End If
End Sub

Private Sub cod82_Change()
    If Me.cod82.Text <> "" Then
        Me.id83.Visible = True
        Me.cod83.Visible = True
        Me.rev83.Visible = True
        Me.desc83.Visible = True
        Me.qtde83.Visible = True
        Me.tipo83.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 54
    End If
End Sub

Private Sub cod83_Change()
    If Me.cod83.Text <> "" Then
        Me.id84.Visible = True
        Me.cod84.Visible = True
        Me.rev84.Visible = True
        Me.desc84.Visible = True
        Me.qtde84.Visible = True
        Me.tipo84.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 72
    End If
End Sub

Private Sub cod84_Change()
    If Me.cod84.Text <> "" Then
        Me.id85.Visible = True
        Me.cod85.Visible = True
        Me.rev85.Visible = True
        Me.desc85.Visible = True
        Me.qtde85.Visible = True
        Me.tipo85.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 90
    End If
End Sub

Private Sub cod85_Change()
    If Me.cod85.Text <> "" Then
        Me.id86.Visible = True
        Me.cod86.Visible = True
        Me.rev86.Visible = True
        Me.desc86.Visible = True
        Me.qtde86.Visible = True
        Me.tipo86.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 108
    End If
End Sub

Private Sub cod86_Change()
    If Me.cod86.Text <> "" Then
        Me.id87.Visible = True
        Me.cod87.Visible = True
        Me.rev87.Visible = True
        Me.desc87.Visible = True
        Me.qtde87.Visible = True
        Me.tipo87.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 126
    End If
End Sub

Private Sub cod87_Change()
    If Me.cod87.Text <> "" Then
        Me.id88.Visible = True
        Me.cod88.Visible = True
        Me.rev88.Visible = True
        Me.desc88.Visible = True
        Me.qtde88.Visible = True
        Me.tipo88.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 144
    End If
End Sub

Private Sub cod88_Change()
    If Me.cod88.Text <> "" Then
        Me.id89.Visible = True
        Me.cod89.Visible = True
        Me.rev89.Visible = True
        Me.desc89.Visible = True
        Me.qtde89.Visible = True
        Me.tipo89.Visible = True
        Me.frm_lista.ScrollHeight = 1480 + 162
    End If
End Sub

Private Sub cod89_Change()
    If Me.cod89.Text <> "" Then
        Me.id90.Visible = True
        Me.cod90.Visible = True
        Me.rev90.Visible = True
        Me.desc90.Visible = True
        Me.qtde90.Visible = True
        Me.tipo90.Visible = True
        Me.frm_lista.ScrollHeight = 1660
    End If
End Sub

'############################################################################
Private Sub cod90_Change()
    If Me.cod90.Text <> "" Then
        Me.id91.Visible = True
        Me.cod91.Visible = True
        Me.rev91.Visible = True
        Me.desc91.Visible = True
        Me.qtde91.Visible = True
        Me.tipo91.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 18
    End If
End Sub

Private Sub cod91_Change()
    If Me.cod91.Text <> "" Then
        Me.id92.Visible = True
        Me.cod92.Visible = True
        Me.rev92.Visible = True
        Me.desc92.Visible = True
        Me.qtde92.Visible = True
        Me.tipo92.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 36
    End If
End Sub

Private Sub cod92_Change()
    If Me.cod92.Text <> "" Then
        Me.id93.Visible = True
        Me.cod93.Visible = True
        Me.rev93.Visible = True
        Me.desc93.Visible = True
        Me.qtde93.Visible = True
        Me.tipo93.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 54
    End If
End Sub

Private Sub cod93_Change()
    If Me.cod93.Text <> "" Then
        Me.id94.Visible = True
        Me.cod94.Visible = True
        Me.rev94.Visible = True
        Me.desc94.Visible = True
        Me.qtde94.Visible = True
        Me.tipo94.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 72
    End If
End Sub

Private Sub cod94_Change()
    If Me.cod94.Text <> "" Then
        Me.id95.Visible = True
        Me.cod95.Visible = True
        Me.rev95.Visible = True
        Me.desc95.Visible = True
        Me.qtde95.Visible = True
        Me.tipo95.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 90
    End If
End Sub

Private Sub cod95_Change()
    If Me.cod95.Text <> "" Then
        Me.id96.Visible = True
        Me.cod96.Visible = True
        Me.rev96.Visible = True
        Me.desc96.Visible = True
        Me.qtde96.Visible = True
        Me.tipo96.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 108
    End If
End Sub

Private Sub cod96_Change()
    If Me.cod96.Text <> "" Then
        Me.id97.Visible = True
        Me.cod97.Visible = True
        Me.rev97.Visible = True
        Me.desc97.Visible = True
        Me.qtde97.Visible = True
        Me.tipo97.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 126
    End If
End Sub

Private Sub cod97_Change()
    If Me.cod97.Text <> "" Then
        Me.id98.Visible = True
        Me.cod98.Visible = True
        Me.rev98.Visible = True
        Me.desc98.Visible = True
        Me.qtde98.Visible = True
        Me.tipo98.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 144
    End If
End Sub

Private Sub cod98_Change()
    If Me.cod98.Text <> "" Then
        Me.id99.Visible = True
        Me.cod99.Visible = True
        Me.rev99.Visible = True
        Me.desc99.Visible = True
        Me.qtde99.Visible = True
        Me.tipo99.Visible = True
        Me.frm_lista.ScrollHeight = 1660 + 162
    End If
End Sub

Private Sub cod99_Change()
    If Me.cod99.Text <> "" Then
        Me.id100.Visible = True
        Me.cod100.Visible = True
        Me.rev100.Visible = True
        Me.desc100.Visible = True
        Me.qtde100.Visible = True
        Me.tipo100.Visible = True
        Me.frm_lista.ScrollHeight = 1840
    End If
End Sub


Private Sub UserForm_Initialize()
For i = 1 To 100

Me.Controls("cod" & i).TabIndex = (i * 5) - 5
Me.Controls("rev" & i).TabIndex = (i * 5) - 4
Me.Controls("desc" & i).TabIndex = (i * 5) - 3
Me.Controls("qtde" & i).TabIndex = (i * 5) - 2
Me.Controls("tipo" & i).TabIndex = (i * 5) - 1

Next i
End Sub
```

---

# VBA — Solicitação de Projeto_RevE1.xlsm

## `Funcoes`  *(inclui o `colsUpd` atualizado)*

```vb
Attribute VB_Name = "Funcoes"
Global G_Lider As String
Global G_Solicitante As String

Function resQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

If rst.EOF = False And rst.BOF = False Then
    arrRst = rst.GetRows
    resQuery = arrRst
End If

rst.Close
cnn.Close

End Function

Function upQuery(SQL As String) As Variant

Dim cnn As ADODB.Connection
Dim rst As ADODB.Recordset

'Caminho do DB
'----------------------------------------------------------
MyConn = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"
    
'Conexão ao DB
'----------------------------------------------------------
Set cnn = New ADODB.Connection
With cnn
    .Provider = "Microsoft.ACE.OLEDB.12.0"
    .Open MyConn
End With

Set rst = New ADODB.Recordset
rst.CursorLocation = adUseServer
rst.CursorType = adOpenDynamic
rst.LockType = adLockOptimistic
Debug.Print SQL
Set rst = cnn.Execute(SQL)

cnn.Close

End Function

Sub Reset()

Application.ScreenUpdating = True
Application.EnableEvents = True

End Sub

Sub Desabilita()

Application.ScreenUpdating = False
Application.EnableEvents = False

End Sub

' ===== NOVAS FUNÇÕES (integração com o MySQL) =====

' Base do PHP (servidor de teste)
Public Function urlBaseApp() As String
    urlBaseApp = "http://172.29.5.2/greenbrier/v2/solic_dispositivos"
End Function

' Envia a solicitação ao MySQL e retorna o Ref gerado (0 = falhou)
Function salvarNoMySQL(desc, solic, dataSolic, codZ, aplic, vg, lote, nSFP, hist, classe) As Long
    Dim http As Object, url As String, body As String
    url = urlBaseApp() & "/dispositivos/solicitacao/salvarVba"

    body = "descricao=" & enc(desc) & _
           "&solicitante=" & enc(solic) & _
           "&data_solicitacao=" & enc(dataSolic) & _
           "&cod_z=" & enc(codZ) & _
           "&aplicacao=" & enc(aplic) & _
           "&vagao=" & enc(vg) & _
           "&lote=" & enc(lote) & _
           "&conta=" & enc(nSFP) & _
           "&historico=" & enc(hist) & _
           "&classe=" & enc(classe)

    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send body

    If http.Status <> 200 Then
        MsgBox "Erro ao salvar no MySQL (" & http.Status & "): " & http.responseText, vbCritical
        salvarNoMySQL = 0
        Exit Function
    End If

    salvarNoMySQL = extrairRef(http.responseText)   ' resposta: {"ref":4001}
End Function

' Escapa um valor para a URL/POST
Function enc(v) As String
    enc = Application.WorksheetFunction.EncodeURL(CStr(v))
End Function

' Extrai o número do "ref" da resposta JSON
Function extrairRef(jsonTxt As String) As Long
    Dim p As Long, s As String, i As Long, ch As String, num As String
    p = InStr(jsonTxt, """ref""")
    If p = 0 Then extrairRef = 0: Exit Function
    s = Mid(jsonTxt, p + 5)
    For i = 1 To Len(s)
        ch = Mid(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            num = num & ch
        ElseIf num <> "" Then
            Exit For
        End If
    Next i
    extrairRef = CLng("0" & num)
End Function

' Envia um arquivo (PDF) para o web. Retorna True se OK.
Function enviarPdfParaMySQL(ByVal ref As Long, ByVal caminhoArquivo As String) As Boolean
    Dim http As Object, st As Object, url As String, nomeArq As String, bytes
    enviarPdfParaMySQL = False

    If Dir(caminhoArquivo) = "" Then Exit Function   ' arquivo não existe

    nomeArq = Mid(caminhoArquivo, InStrRev(caminhoArquivo, "\") + 1)

    ' lê os bytes do arquivo
    Set st = CreateObject("ADODB.Stream")
    st.Type = 1            ' adTypeBinary
    st.Open
    st.LoadFromFile caminhoArquivo
    bytes = st.Read
    st.Close

    url = urlBaseApp() & "/dispositivos/solicitacao/uploadAnexoVba?ref=" & ref & "&nome=" & enc(nomeArq)
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/octet-stream"
    http.Send bytes

    If http.Status = 200 Then
        enviarPdfParaMySQL = True
    Else
        MsgBox "Falha ao enviar PDF (" & http.Status & "): " & http.responseText, vbExclamation
    End If
End Function

' Envia um comentário para o histórico do web (tabela historico). Retorna True se OK.
Function comentarMySQL(ByVal ref As Long, ByVal usuario As String, ByVal mensagem As String) As Boolean
    Dim http As Object, url As String, body As String
    comentarMySQL = False
    If Trim(mensagem) = "" Then Exit Function

    url = urlBaseApp() & "/dispositivos/solicitacao/comentarVba"
    body = "ref=" & ref & "&usuario=" & enc(usuario) & "&mensagem=" & enc(mensagem)

    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send body

    If http.Status = 200 Then
        comentarMySQL = True
    Else
        MsgBox "Falha ao enviar comentário (" & http.Status & "): " & http.responseText, vbExclamation
    End If
End Function

' Atualiza status no MySQL. 'corpo' = pares já no formato campo=valor&campo2=valor2 (valores via enc()).
Function atualizarStatusMySQL(ByVal ref As Long, ByVal corpo As String) As Boolean
    Dim http As Object, url As String
    atualizarStatusMySQL = False
    If Trim(corpo) = "" Then Exit Function

    url = urlBaseApp() & "/dispositivos/solicitacao/atualizarStatusVba"
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "POST", url, False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.Send "ref=" & ref & "&" & corpo

    If http.Status = 200 Then
        atualizarStatusMySQL = True
    Else
        MsgBox "Falha ao atualizar status (" & http.Status & "): " & http.responseText, vbExclamation
    End If
End Function

' ===== MySQL -> Access: insere novos + ATUALIZA histórico e status dos existentes =====
Sub sincronizarDoMySQL()
    Dim http As Object, csv As String
    Dim linhas() As String, cab() As String, campos() As String
    Dim i As Long, j As Long
    Dim db As Object, rs As Object, rsExist As Object
    Dim existentes As Object, colIndex As Object
    Dim ref As String, col As String, val As String
    Dim inseridos As Long, atualizados As Long
    Dim idxRef As Long, colsUpd As Variant, c As Variant, idx As Long, v As String

    On Error GoTo ERRO

    ' 1) Baixa o CSV do MySQL
    Set http = CreateObject("MSXML2.ServerXMLHTTP")
    http.Open "GET", urlBaseApp() & "/dispositivos/csvAtualizado/fila?t=" & Timer, False
    http.Send
    If http.Status <> 200 Then
        MsgBox "Erro ao buscar CSV (" & http.Status & ")", vbCritical
        Exit Sub
    End If

    csv = http.responseText
    If Len(csv) > 0 Then If AscW(Left(csv, 1)) = 65279 Then csv = Mid(csv, 2) ' remove BOM
    csv = Replace(csv, vbCrLf, vbLf)
    csv = Replace(csv, vbCr, vbLf)
    linhas = Split(csv, vbLf)
    If UBound(linhas) < 1 Then Exit Sub

    cab = Split(linhas(0), ";")

    ' índice de cada coluna
    Set colIndex = CreateObject("Scripting.Dictionary")
    For j = 0 To UBound(cab)
        colIndex(Trim(cab(j))) = j
    Next j
    idxRef = -1
    If colIndex.Exists("Ref") Then idxRef = colIndex("Ref")

    ' colunas atualizadas nos existentes (histórico + status)
    colsUpd = Array("Historico", "Conceito_P", "Conceito_St", "Conceito_Ini", "Conceito_Fim", "Tempo_Modelo", "Det_P", "Det_St", "Det_Ini", "Det_Fim", "Tempo_Det", "Liberacao_St", "Corte_St", "Exec_St", "Aq_St", "Tryout_St")

    ' 2) Abre o Access via DAO
    Set db = OpenDatabase("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb")

    ' Refs que já existem
    Set existentes = CreateObject("Scripting.Dictionary")
    Set rsExist = db.OpenRecordset("SELECT Ref FROM Fila", 2)
    Do While Not rsExist.EOF
        existentes(CStr(rsExist.Fields(0).Value)) = True
        rsExist.MoveNext
    Loop
    rsExist.Close
    Set rsExist = Nothing

    ' 3) Recordset gravável da Fila
    Set rs = db.OpenRecordset("SELECT * FROM Fila", 2)

    inseridos = 0: atualizados = 0
    For i = 1 To UBound(linhas)
        If Trim(linhas(i)) <> "" Then
            campos = Split(linhas(i), ";")

            ref = ""
            If idxRef >= 0 And idxRef <= UBound(campos) Then ref = Trim(Replace(campos(idxRef), """", ""))

            If ref <> "" Then
                If Not existentes.Exists(ref) Then
                    ' ---- NOVO: insere todos os campos ----
                    rs.AddNew
                    For j = 0 To UBound(cab)
                        If j > UBound(campos) Then Exit For
                        col = Trim(cab(j))
                        val = Trim(Replace(campos(j), """", ""))
                        If col = "Historico" Then val = Replace(val, "[BR]", vbCrLf)
                        On Error Resume Next
                        If val = "" Then rs.Fields(col).Value = Null Else rs.Fields(col).Value = val
                        Err.Clear
                        On Error GoTo ERRO
                    Next j
                    rs.Update
                    existentes(ref) = True
                    inseridos = inseridos + 1
                Else
                    ' ---- EXISTENTE: atualiza histórico + status ----
                    rs.FindFirst "Ref = " & ref
                    If Not rs.NoMatch Then
                        rs.Edit
                        For Each c In colsUpd
                            If colIndex.Exists(CStr(c)) Then
                                idx = colIndex(CStr(c))
                                If idx <= UBound(campos) Then
                                    v = Trim(Replace(campos(idx), """", ""))
                                    If CStr(c) = "Historico" Then v = Replace(v, "[BR]", vbCrLf)
                                    On Error Resume Next
                                    If v = "" Then rs.Fields(CStr(c)).Value = Null Else rs.Fields(CStr(c)).Value = v
                                    Err.Clear
                                    On Error GoTo ERRO
                                End If
                            End If
                        Next c
                        rs.Update
                        atualizados = atualizados + 1
                    End If
                End If
            End If
        End If
    Next i

    rs.Close
    db.Close

    ' Reaplica o filtro atual para atualizar a lista na tela
    On Error Resume Next
    Select Case Range("I3").Value
        Case 1: filtro_01
        Case 2: filtro_02
        Case 3: filtro_03
        Case 4: filtro_04
        Case 5: filtro_05
        Case 6: filtro_06
        Case 7: lista_todos
        Case 0: lista_pendentes
        Case Else: lista_todos
    End Select
    On Error GoTo 0

    MsgBox "Sincronização concluída." & vbCrLf & _
           "Inseridos: " & inseridos & vbCrLf & _
           "Atualizados (hist+status): " & atualizados, vbInformation
    Exit Sub

ERRO:
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    If Not db Is Nothing Then db.Close
    MsgBox "Erro na sincronização: " & Err.Number & " - " & Err.Description, vbCritical
End Sub
' Access -> Web: envia a lista de usuarios (Solicitantes: Email + Nome) para a tabela
' solicitantes_access (MySQL), usada para casar o autor do historico pelo e-mail.
Public Sub enviarSolicitantesParaMySQL()
    Dim arr As Variant
    Dim i As Long
    Dim payload As String
    Dim http As Object

    arr = resQuery("SELECT Email, Nome FROM Solicitantes WHERE Email Is Not Null AND Nome Is Not Null;")
    If IsEmpty(arr) Then
        MsgBox "Nenhum solicitante com e-mail encontrado.", vbExclamation
        Exit Sub
    End If

    payload = ""
    For i = 0 To UBound(arr, 2)
        If Not IsNull(arr(0, i)) And Not IsNull(arr(1, i)) Then
            payload = payload & LCase(Trim(arr(0, i))) & vbTab & Trim(arr(1, i)) & vbLf
        End If
    Next i

    If payload = "" Then
        MsgBox "Nenhum solicitante com e-mail encontrado.", vbExclamation
        Exit Sub
    End If

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", urlBaseApp() & "/dispositivos/solicitacao/uploadSolicitantesVba", False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.send "dados=" & enc(payload)

    If http.Status = 200 Then
        MsgBox "Usuarios sincronizados!" & vbCrLf & http.responseText, vbInformation
    Else
        MsgBox "Falha ao enviar usuarios (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Exit Sub
erro:
    MsgBox "Erro ao enviar usuarios:" & vbCrLf & Err.Description, vbCritical
End Sub

```

---

## `frm_novo`

```vb
Attribute VB_Name = "frm_novo"
Attribute VB_Base = "0{89B5798A-0D85-4672-B22A-E7A7BA4477C1}{D435A435-0B82-4B0A-B385-BC7B2A0A19EB}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Dim newFileName As String
Dim oldFileName As String


Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_enviar_Click()

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        Dim SQL As String


        desc = UCase(frm_novo.txt_solicitacao.Text)
        solic = frm_novo.lbl_solic.Caption
        cod_z = frm_novo.txt_cod.Text
        cod_z = Replace(cod_z, "z", "Z")
        nSFP = frm_novo.cmbSFP.Text
        nSW = "SW" & frm_novo.txt_nSW.Text



        If IsNumeric(cod_z) Then cod_z = "Z" & Format(cod_z, "0000")


        aplic = frm_novo.cmb_aplic.Text
        vg = frm_novo.cmb_vg.Text
        lote = frm_novo.cmb_lote.Text

        classe = ""

        If frm_novo.opt_1 Then classe = frm_novo.opt_1.Caption
        If frm_novo.opt_1 Then desc = desc & " " & nSW
        If frm_novo.opt_2 Then classe = frm_novo.opt_2.Caption
        If frm_novo.opt_2 Then desc = desc & " " & nSW
        If frm_novo.opt_3 Then classe = frm_novo.opt_3.Caption
        If frm_novo.opt_3 Then desc = desc & " " & nSW
        If frm_novo.opt_4 Then classe = frm_novo.opt_4.Caption
        If frm_novo.opt_5 Then classe = frm_novo.opt_5.Caption
        If frm_novo.opt_6 Then classe = frm_novo.opt_6.Caption
        If frm_novo.opt_7 Then classe = frm_novo.opt_7.Caption
        If frm_novo.opt_8 Then classe = frm_novo.opt_8.Caption
        If frm_novo.opt_9 Then classe = frm_novo.opt_9.Caption

        If classe = "" Then classe = frm_novo.opt_4.Caption

        msg = frm_novo.txt_escopo.Text & vbCrLf
        qtd_requerida = frm_novo.txt_qtd.Text
        partNumber_ref = frm_novo.txt_partNumber.Text
        dicaLocal_ref = frm_novo.txt_dicaLocal.Text
            inicio = "** DADOS DE ENTRADA **" & vbCrLf
            cabec = "-- " & solic & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf
            qtd = "-- Quantidade Necessária: " & qtd_requerida & " --" & vbCrLf
            prtN = "-- Part Number de Referência: " & partNumber_ref & " --" & vbCrLf
            obsLocal = "-- Detalhes do Local: " & dicaLocal_ref & " --" & vbCrLf

            If chk_partNumber.Value = True And chk_dicaLocal.Value = True Then
                hist = inicio & cabec & msg & qtd & prtN & obsLocal
            ElseIf chk_partNumber.Value = True Then
                hist = inicio & cabec & msg & qtd & prtN
            ElseIf chk_dicaLocal.Value = True Then
                hist = inicio & cabec & msg & qtd & obsLocal
            Else
                hist = inicio & cabec & msg & qtd
            End If


            hist = Replace(hist, "'", "")

        data_solic = Format(Now, "DD/MM/YYYY")
        Dim data_solic_sql As String
        data_solic_sql = Format(Now, "DD/MM/YYYY HH:NN:SS")   ' com hora, só pro MySQL

        ' 1) Gera o Ref no MySQL (cartório) e já grava lá
        t_ref = salvarNoMySQL(desc, solic, data_solic_sql, cod_z, aplic, vg, lote, nSFP, hist, classe)
        If t_ref = 0 Then Exit Sub   ' falhou no MySQL -> não grava no Access com número errado

        ' 2) Grava no Access usando o MESMO Ref
        SQL = "INSERT INTO Fila (Ref, Descricao, Solicitante, Data_Solicitacao, Cod_Z, Aplicacao, Vagao, Lote, NumSfpCC, Historico, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St, Prio, Classe) VALUES (" & t_ref & ", '"
        SQL = SQL & desc & "', '"
        SQL = SQL & solic & "', '"
        SQL = SQL & data_solic & "', '"
        SQL = SQL & cod_z & "', '"
        SQL = SQL & aplic & "', '"
        SQL = SQL & vg & "', '"
        SQL = SQL & lote & "', '"
        SQL = SQL & nSFP & "', '"
        SQL = SQL & hist & "' , 'PENDENTE', 'PENDENTE', 'PENDENTE', 'PENDENTE', 'PARADO', 'PARADO', 'PENDENTE', 99, '" & classe & "');"

        upQuery (SQL)

        newFileName = "SL" & Format(t_ref, "0000") & ".pdf"
        'Debug.Print newFileName
        If lblFilePath.Caption <> "" Then
            Name "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & Right(frm_novo.lblFilePath.Caption, Len(frm_novo.lblFilePath.Caption) - InStrRev(frm_novo.lblFilePath.Caption, "\")) As _
            "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & newFileName
            enviarPdfParaMySQL t_ref, "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & newFileName    ' [ADICIONADO] manda o PDF pro web
        End If


        MsgBox "Solicitação inserida Ref.: SL" & Format(t_ref, "0000")

        Unload Me

        filtro = Range("I3").Value
        If filtro = 1 Then filtro_01
        If filtro = 2 Then filtro_02
        If filtro = 3 Then filtro_03
        If filtro = 4 Then filtro_04
        If filtro = 5 Then filtro_05
        If filtro = 6 Then filtro_06
        If filtro = 7 Then lista_todos
        If filtro = 0 Then lista_pendentes
    Else
        frm_novo.lblMissing.ForeColor = &HC0&
        'frm_novo.lblMissing.Font.Bold = True
    End If




End Sub


Private Sub btnAnexar_Click()
    
Dim fso As Object
Dim oldFileName As String

FilePath = Application.GetOpenFilename("Pdf Files (*.pdf),*.pdf", Title:="Selecione um arquivo .pdf")
lblFilePath.Caption = FilePath
oldFileName = Right(FilePath, Len(FilePath) - InStrRev(FilePath, "\"))
'Debug.Print oldFileName
destinationPath = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & t_ref & Mid(FilePath, InStrRev(FilePath, "\") + 1)
'Debug.Print destinationPath
Set fso = CreateObject("Scripting.FileSystemObject")
fso.CopyFile FilePath, destinationPath

End Sub

Private Sub chk_dicaLocal_Click()

    If chk_dicaLocal.Value = True Then
        txt_dicaLocal.Enabled = True
        txt_dicaLocal.SpecialEffect = fmSpecialEffectFlat
        txt_dicaLocal.BorderStyle = fmBorderStyleSingle
        chk_dicaLocal.Caption = "Obs. Local*:"
    Else
        txt_dicaLocal.Enabled = False
        txt_dicaLocal.SpecialEffect = fmSpecialEffectSunken
        txt_dicaLocal.BorderStyle = fmBorderStyleNone
        txt_dicaLocal.Text = ""
        chk_dicaLocal.Caption = "Obs. Local:"
    End If
End Sub

Private Sub chk_partNumber_Click()

    If chk_partNumber.Value = True Then
        txt_partNumber.Enabled = True
        txt_partNumber.SpecialEffect = fmSpecialEffectFlat
        txt_partNumber.BorderStyle = fmBorderStyleSingle
        chk_partNumber.Caption = "Part Number*:"
    Else
        txt_partNumber.Enabled = False
        txt_partNumber.SpecialEffect = fmSpecialEffectSunken
        txt_partNumber.BorderStyle = fmBorderStyleNone
        txt_partNumber.Text = ""
        chk_partNumber.Caption = "Part Number:"
    End If

End Sub

Private Sub cmb_vg_Change()

Dim SQL As String
'Combo Lote

vg = frm_novo.cmb_vg.Text
sfp = frm_novo.cmbSFP.Value

SQL = "SELECT DISTINCT Lote FROM dmAccounts WHERE Vagao = '" & vg & "'AND boValidade = true ORDER BY Lote;"
        
    
    arrRes = resQuery(SQL)
    
    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    
    End If

End Sub

Private Sub cmbSFP_Change()

Dim SQL As String
nSFP = Me.cmbSFP.Text
   

'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true AND numSfpCC = '" & nSFP & "';"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a
    If cmb_vg.ListCount = 1 Then cmb_vg.ListIndex = 0 Else cmb_vg.ListIndex = -1
        End If
    

'Combo Lote

    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true AND numSfpCC = '" & nSFP & "';"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    If cmb_lote.ListCount = 1 Then cmb_lote.ListIndex = 0 Else cmb_lote.ListIndex = -1
    End If


Dim SQLSfp As String

    nSFP = Me.cmbSFP.Text
    
    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If
    
    cmb_vg.Enabled = True
    cmb_lote.Enabled = True
End Sub



Private Sub lblMissing_Click()

End Sub

Private Sub opt_1_Click()   'notificação de segurança
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    
    Dim SQLSfp As String
    Dim SQL As String

    nSFP = Me.cmbSFP.Text
    
    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If
    
    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a
    
        End If
    

'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    
    End If
        
    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True
    
    
    
End Sub

Private Sub opt_2_Click() 'SW
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text
    
    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If
    
    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a
    
        End If
    

'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    
    End If
    
    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True
End Sub

Private Sub opt_3_Click()   'CIPA
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    
    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text
    
    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If
    
    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a
    
        End If
    

    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    
    End If
    
    cmbSFP.Enabled = False
    txt_nSW.Visible = True
    Label22.Visible = True
End Sub

Private Sub opt_4_Click()
    cmbSFP.Visible = True
    lblSFP.Caption = ""
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    cmbSFP.Value = ""
    cmb_vg.Value = ""
    cmb_lote.Value = ""
    cmbSFP.Enabled = True
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_5_Click()
    
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    
    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text
    
    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If
    
    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a
    
        End If
    

    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    
    End If
    
    cmbSFP.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_6_Click()
    cmbSFP.Visible = True
    cmbSFP.Value = 3231020503#
    cmb_aplic.Value = Null
    cmb_aplic.Enabled = True
    
    Dim SQLSfp As String
    Dim SQL As String


    nSFP = Me.cmbSFP.Text
    
    SQLSfp = "SELECT txDescricao FROM dmAccounts WHERE numSfpCC = '" & nSFP & "';"

    arrSfp = resQuery(SQLSfp)
    If Not IsEmpty(arrSfp) Then
        Me.lblSFP.Caption = arrSfp(0, 0)
    End If
    
    'Combo Vagão
    SQL = "SELECT Vagao FROM dmAccounts WHERE boValidade = true;"

    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_vg.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" And arrRes(0, a) <> "DIVERSOS" Then
                frm_novo.cmb_vg.AddItem arrRes(0, a)
            End If
        Next a
    
        End If
    

    'Combo Lote


    SQL = "SELECT Lote FROM dmAccounts WHERE boValidade = true;"
    arrRes = resQuery(SQL)

    If Not IsEmpty(arrRes) Then
        frm_novo.cmb_lote.Clear
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                frm_novo.cmb_lote.AddItem arrRes(0, a)
            End If
        Next a
    
    End If
    
    cmbSFP.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False
End Sub

Private Sub opt_7_Click()

    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_8_Click()

    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False

End Sub

Private Sub opt_9_Click()
    cmbSFP.Visible = False
    lblSFP.Caption = ""
    cmbSFP.Value = ""
    cmbSFP.Enabled = True
    cmb_aplic.Value = "AUTOMAÇÂO"
    cmb_aplic.Enabled = False
    frm_novo.cmb_vg.Clear
    frm_novo.cmb_vg.AddItem "LAB"
    cmb_vg.Value = "LAB"
    cmb_vg.Enabled = False
    frm_novo.cmb_lote.Clear
    frm_novo.cmb_lote.AddItem "000"
    cmb_lote.Value = "000"
    cmb_lote.Enabled = False
    txt_nSW.Visible = False
    Label22.Visible = False
End Sub


Private Sub txt_escopo_Change()
    frm_novo.cont.Caption = Format(Len(frm_novo.txt_escopo.Text), "000")

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        frm_novo.lblMissing.ForeColor = &H80000012
    End If

End Sub


Private Sub txt_qtd_Change()

    desc = frm_novo.txt_solicitacao.Text
    solic = frm_novo.lbl_solic.Caption
    aplic = frm_novo.cmb_aplic.Text
    vg = frm_novo.cmb_vg.Text
    lote = frm_novo.cmb_lote.Text
    sfp = frm_novo.cmbSFP.Text
    msg = frm_novo.txt_escopo.Text
    qtd = frm_novo.txt_qtd.Text
    If frm_novo.txt_nSW.Visible = True Then nSW = frm_novo.txt_nSW.Text Else nSW = " "
    If frm_novo.cmbSFP.Visible = False Then sfp = " "
    If aplic = "FABRICAÇÃO" Then vg = " "
    If aplic = "FABRICAÇÃO" Then lote = " "
    If aplic = "ROBÔS" Then vg = " "
    If aplic = "ROBÔS" Then lote = " "

    If desc <> "" And solic <> "" And aplic <> "" And vg <> "" And lote <> "" And sfp <> "" And msg <> "" And nSW <> "" And qtd <> "" Then
        frm_novo.lblMissing.ForeColor = &H80000012
    End If

End Sub

Private Sub txt_solicitacao_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    desc = frm_novo.txt_solicitacao.Text
    If desc <> "" Then frm_novo.txt_solicitacao.Text = UCase(frm_novo.txt_solicitacao.Text)
End Sub

Private Sub UserForm_Click()

End Sub
```

---

## `frmsol`

```vb
Attribute VB_Name = "frmsol"
Attribute VB_Base = "0{11A01C7E-D3CC-40BD-A83C-BB991548D9E5}{DA89EA2C-0265-4DA0-9A7A-96B49EF72229}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btn_enviar_Click()

msg_hist = frmsol.txt_historico.Text

msg = frmsol.txt_msg.Text

If msg_hist = "" Then hist = "" Else hist = msg_hist & vbCrLf & vbCrLf

autor = frmsol.lbl_solic.Caption
cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

hist = hist & cabec & msg

frmsol.txt_historico.Text = hist
frmsol.txt_msg.Text = ""

Dim SQL As String

ref = Replace(frmsol.lbl_ref.Caption, "SL", "") * 1
hist = frmsol.txt_historico.Text

SQL = "UPDATE Fila SET Historico = ' " & hist & "' WHERE Ref = " & ref & ";"
upQuery (SQL)

comentarMySQL ref, autor, msg    ' [ADICIONADO] manda o comentário pro web (tabela historico)

End Sub

Private Sub btn_ok_Click()
    Unload Me
    Call lista_pendentes
End Sub

Private Sub btn_pdf_Click()
    Sheets("PDF").Activate
    
    'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
        
    End With
    
    
    'Preencher informações
    With Sheets("PDF")
        
        .Range("N7:Q7").Value = frmsol.lbl_classe.Caption 'Classe
    
        .Range("B7:D7").Value = frmsol.lbl_ref.Caption 'SL
        .Range("B10:L10").Value = frmsol.lbl_desc.Caption 'Descrição
        .Range("B12:C12").Value = frmsol.lbl_data.Caption 'Data
        .Range("D12:F12").Value = frmsol.lbl_solic.Caption 'Solicitante
        .Range("G12:I12").Value = frmsol.lbl_estagio.Caption 'Estágio
        .Range("J12:K12").Value = frmsol.lbl_vg.Caption 'Vagão
        .Range("L12").Value = frmsol.lbl_lote.Caption 'Lote
        
        .Range("B15").Value = frmsol.proj_st.Caption 'Projeto
        .Range("D15").Value = frmsol.det_st.Caption 'Detalhamento
        .Range("F15").Value = frmsol.lib_st.Caption 'Liberação
        .Range("H15").Value = frmsol.corte_st.Caption 'Corte
        .Range("J15").Value = frmsol.exec_st.Caption 'Execução
        .Range("L15").Value = frmsol.tryout_st.Caption 'Tryout
        
        .Range("B16").Value = frmsol.proj_data.Caption 'Data Projeto
        .Range("D16").Value = frmsol.det_data.Caption 'Data Detalhamento
        .Range("F16").Value = frmsol.lib_data.Caption 'Data Liberação
        .Range("H16").Value = frmsol.corte_data.Caption 'Data Corte
        .Range("J16").Value = frmsol.exec_data.Caption 'Data Execução
        .Range("L16").Value = frmsol.tryout_data.Caption 'Data Tryout
        
        .Range("B20:F20").Value = frmsol.lbl_projetista.Caption 'Projetista
        .Range("B22:C22").Value = frmsol.lbl_ini_proj.Caption 'Inicio
        .Range("D22:F22").Value = frmsol.lbl_fim_proj.Caption 'Fim
        .Range("H22:J22").Value = frmsol.lbl_status_proj.Caption 'Status
    
        .Range("L20:P20").Value = frmsol.lbl_executor.Caption 'Executor
        .Range("L22:M22").Value = frmsol.lbl_ini_exec.Caption 'Inicio
        .Range("N22:O22").Value = frmsol.lbl_fim_exec.Caption 'Fim
        .Range("P22:Q22").Value = frmsol.lbl_status_exec.Caption 'Status
    
        'Carrega DXFs
        Ln = 26
        Dim li1 As ListItem
        For a = 1 To frmsol.dxf_lst.ListItems.Count
            Set li1 = frmsol.dxf_lst.ListItems(a)
                .Cells(Ln, 2).Value = li1.Text
                .Cells(Ln, 4).Value = li1.ListSubItems(1).Text
                .Cells(Ln, 14).Value = li1.ListSubItems(2).Text
                .Cells(Ln, 16).Value = li1.ListSubItems(3).Text
                Ln = Ln + 1
        Next a
                
        'Carrega OCs
        Ln = 34
        Dim li2 As ListItem
        For a = 1 To frmsol.bom_lst.ListItems.Count
            Set li2 = frmsol.bom_lst.ListItems(a)
                .Cells(Ln, 2).Value = li2.ListSubItems(1).Text 'Codigo
                .Cells(Ln, 4).Value = li2.ListSubItems(3).Text 'Descricao
                .Cells(Ln, 11).Value = li2.ListSubItems(4).Text 'Qtde
                .Cells(Ln, 13).Value = li2.ListSubItems(5).Text 'Tipo
                .Cells(Ln, 15).Value = li2.ListSubItems(6).Text 'OC
                .Cells(Ln, 16).Value = li2.ListSubItems(8).Text 'WF
                .Cells(Ln, 17).Value = li2.ListSubItems(7).Text 'Status
                Ln = Ln + 1
        Next a
    
        .Range("B45:Q76").Value = frmsol.txt_historico.Text 'Histórico

    End With
    
    cod_z = frmsol.lbl_cod_z.Caption
    
    
    With ActiveSheet.Pictures.Insert("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_z\" & cod_z & ".jpg")
        .Name = "img"
        .Height = 130
        largura = .Width
        
        If largura > 250 Then .Width = 250
        
        largura = .Width
        altura = .Height
        
        If altura = 130 Then l_top = 2 Else l_top = Int((130 - altura) / 2)
        If largura = 250 Then l_lat = 2 Else l_lat = Int((250 - largura) / 2)
        
        .Left = ActiveSheet.Range("imagem").Left + l_lat
        .Top = ActiveSheet.Range("imagem").Top + l_top
    End With
   
    
    
    Dim fDlg    As FileDialog
    Dim lPasta  As String
    Set fDlg = Application.FileDialog(FileDialogType:=msoFileDialogFolderPicker)
    'Retorna a pasta selecionada
    If fDlg.Show = -1 Then
        lPasta = fDlg.SelectedItems(1)
        'MsgBox "A pasta selecionada foi: " & lPasta
    Else
        MsgBox "Não foi selecionada nenhuma pasta"
    End If
    
    nome_pdf = lPasta & "/" & "Ficha_Resumo - " & frmsol.lbl_ref.Caption & ".pdf"
    
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=nome_pdf, _
            Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, _
            OpenAfterPublish:=True
    
    Sheets("Controle").Activate
    
        'Limpeza dos campos
    With Sheets("PDF")
        .Range("N7:Q7").ClearContents 'Classe
        .Range("B7:D7").ClearContents 'SL
        .Range("B10:L10").ClearContents 'Descrição
        .Range("B12:C12").ClearContents 'Data
        .Range("D12:F12").ClearContents 'Solicitante
        .Range("G12:I12").ClearContents 'Estágio
        .Range("J12:K12").ClearContents 'Vagão
        .Range("L12").ClearContents 'Lote
        
        .Range("B15").ClearContents 'Projeto
        .Range("D15").ClearContents 'Detalhamento
        .Range("F15").ClearContents 'Liberação
        .Range("H15").ClearContents 'Corte
        .Range("J15").ClearContents 'Execução
        .Range("L15").ClearContents 'Tryout
        
        .Range("B16").ClearContents 'Data Projeto
        .Range("D16").ClearContents 'Data Detalhamento
        .Range("F16").ClearContents 'Data Liberação
        .Range("H16").ClearContents 'Data Corte
        .Range("J16").ClearContents 'Data Execução
        .Range("L16").ClearContents 'Data Tryout
        
        .Range("B20:F20").ClearContents 'Projetista
        .Range("B22:C22").ClearContents 'Inicio
        .Range("D22:F22").ClearContents 'Fim
        .Range("H22:J22").ClearContents 'Status
    
        .Range("L20:P20").ClearContents 'Executor
        .Range("L22:M22").ClearContents 'Inicio
        .Range("N22:O22").ClearContents 'Fim
        .Range("P22:Q22").ClearContents 'Status
    
        .Range("B26:Q30").ClearContents 'DXFs
        
        .Range("B34:Q42").ClearContents 'OCs
    
        .Range("B45:Q76").ClearContents 'DXFs
        
        
    End With
        On Error Resume Next
        ActiveSheet.Shapes.Range(Array("img")).Delete
    
    Unload Me

End Sub


Private Sub btnBOM_Click()
    cod_z = frmsol.lbl_cod_z.Caption
    cod_sl = frmsol.lbl_ref.Caption
    Unload Me
    On Error Resume Next
    Workbooks.Open Filename:="K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True

End Sub

Private Sub btnCancelarSol_Click()

Dim answer As Integer
Dim SQL As String

ref = Me.lbl_ref.Caption

answer = MsgBox("Deseja realmente cancelar a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Cancelar?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Conceito_St = 'CANCELADO', Det_St = 'CANCELADO', Liberacao_St = 'CANCELADO', Aq_St = 'CANCELADO', Corte_St = 'CANCELADO', Exec_St = 'CANCELADO', Tryout_St = 'CANCELADO' WHERE Ref = " & Replace(ref, "SL", "") & ";"
    upQuery (SQL)

    atualizarStatusMySQL Replace(ref, "SL", "") * 1, "conceito_status=" & enc("CANCELADO") & "&detalhamento_status=" & enc("CANCELADO") & "&liberacao_status=" & enc("CANCELADO") & "&aquisicao_status=" & enc("CANCELADO") & "&corte_status=" & enc("CANCELADO") & "&exec_status=" & enc("CANCELADO") & "&tryout_status=" & enc("CANCELADO")   ' [ADICIONADO]

    MsgBox "Solicitação " & ref & " cancelada com sucesso!"
    Unload Me
    Call lista_pendentes
End If

End Sub

Private Sub btnTryout_NaoOK_Click() 'adicionado 19/12/24
Dim SQL As String
Dim answer As Integer
Dim cod_z As String

cod_z = Replace(frmsol.lbl_cod_z.Caption, "Z", "")
ref = Replace(Me.lbl_ref.Caption, "SL", "")

answer = MsgBox("Será necessário revisar a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Tryout NOK?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Tryout_St = 'NÂO OK' where Ref = " & ref & ";"
    upQuery (SQL)

    atualizarStatusMySQL ref, "tryout_status=" & enc("NÂO OK")   ' [ADICIONADO]

    MsgBox "Tryout realizado mas sem sucesso" & vbCrLf & "Nova SL sendo aberta para Z" & cod_z, , "Próximas Etapas"
    frm_novo.txt_cod.Value = cod_z
    frm_novo.txt_cod.Locked = True
    Unload Me
    Call lista_pendentes
    Load frm_novo
    Call inserir_nova
    
End If

If answer = 7 Then
    SQL = "UPDATE Fila SET Tryout_St = 'NÂO OK' where Ref = " & ref & ";"
    upQuery (SQL)

    atualizarStatusMySQL ref, "tryout_status=" & enc("NÂO OK")   ' [ADICIONADO]

    MsgBox "Tryout realizado mas sem sucesso" & vbCrLf & "Nova SL não será necessária", , "Próximas Etapas"
    Unload Me
    Call lista_pendentes
End If



End Sub

Private Sub btnTryout_OK_Click() 'rev 19/12/24
Dim SQL As String
Dim answer As Integer

ref = Replace(Me.lbl_ref.Caption, "SL", "")

answer = MsgBox("Deseja concluir a Solcitação " & ref & " ?", vbQuestion + vbYesNo + vbDefaultButton2, "Concluir?")

If answer = 6 Then
    SQL = "UPDATE Fila SET Tryout_St = 'OK' where Ref = " & ref & ";"
    upQuery (SQL)

    atualizarStatusMySQL ref, "tryout_status=" & enc("OK")   ' [ADICIONADO]

    MsgBox "Tryout validado com sucesso!!!"
    Unload Me
    Call lista_pendentes
End If

End Sub
Private Sub btnValidar_Click()
    ufValidar.Show
End Sub

Private Sub dxf_lst_DblClick()
    If frmsol.dxf_lst.ListItems.Count > 0 Then
        Dim SQL As String
        For i = 1 To (frmsol.dxf_lst.ListItems.Count)
            If frmsol.dxf_lst.ListItems.Item(i).Selected Then n_dxf = frmsol.dxf_lst.ListItems.Item(i).Text
        Next i
        
        frm_dxf.lbl_controle.Caption = n_dxf
        
        ctrl = Replace(n_dxf, "DX", "")
        
        SQL = "SELECT "
        SQL = SQL & "Reserva1, Reserva2, Reserva3, Reserva4, Reserva5, Reserva6, Reserva7, Reserva8, Reserva9, Reserva10, "
        SQL = SQL & "Prog01, OK01,"
        SQL = SQL & "Prog02, OK02,"
        SQL = SQL & "Prog03, OK03,"
        SQL = SQL & "Prog04, OK04,"
        SQL = SQL & "Prog05, OK05,"
        SQL = SQL & "Prog06, OK06,"
        SQL = SQL & "Prog07, OK07,"
        SQL = SQL & "Prog08, OK08,"
        SQL = SQL & "Prog09, OK09,"
        SQL = SQL & "Prog10, OK10 "
        SQL = SQL & "FROM DXF_Control WHERE Controle = " & ctrl & ";"
        
        arrRes = resQuery(SQL)
        
        'corte #1
        If Not IsNull(arrRes(10, 0)) Then frm_dxf.pg01.Caption = arrRes(10, 0)
        If Not IsNull(arrRes(0, 0)) Then frm_dxf.res01.Caption = arrRes(0, 0)
        status_pg01 = arrRes(11, 0)
        
        If frm_dxf.pg01.Caption = "" Then
           frm_dxf.pg01.Visible = False
           frm_dxf.ver01.Visible = False
           frm_dxf.res01.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg01.ForeColor = &HFF&
            frm_dxf.res01.ForeColor = &HFF&
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg01.ForeColor = &HFF0000
            frm_dxf.res01.ForeColor = &HFF0000
        Else
            frm_dxf.pg01.ForeColor = &H8000&
            frm_dxf.res01.ForeColor = &H8000&
        End If
        
        'corte #2
        If Not IsNull(arrRes(12, 0)) Then frm_dxf.pg02.Caption = arrRes(12, 0)
        If Not IsNull(arrRes(1, 0)) Then frm_dxf.res02.Caption = arrRes(1, 0)
        status_pg02 = arrRes(13, 0)
        
        If frm_dxf.pg02.Caption = "" Then
           frm_dxf.pg02.Visible = False
           frm_dxf.ver02.Visible = False
           frm_dxf.res02.Visible = False
        End If
        If status_pg02 = False And frm_dxf.res02.Caption <> "" Then
            frm_dxf.pg02.ForeColor = &HFF&
            frm_dxf.res02.ForeColor = &HFF&
        ElseIf status_pg02 = False And frm_dxf.res02.Caption = "" Then
            frm_dxf.pg02.ForeColor = &HFF0000
            frm_dxf.res02.ForeColor = &HFF0000
        Else
            frm_dxf.pg02.ForeColor = &H8000&
            frm_dxf.res02.ForeColor = &H8000&
        End If
        
        'corte #3
        If Not IsNull(arrRes(14, 0)) Then frm_dxf.pg03.Caption = arrRes(14, 0)
        If Not IsNull(arrRes(2, 0)) Then frm_dxf.res03.Caption = arrRes(2, 0)
        status_pg03 = arrRes(15, 0)
        
        If frm_dxf.pg03.Caption = "" Then
           frm_dxf.pg03.Visible = False
           frm_dxf.ver03.Visible = False
           frm_dxf.res03.Visible = False
        End If
        If status_pg03 = False And frm_dxf.res03.Caption <> "" Then
            frm_dxf.pg03.ForeColor = &HFF&
            frm_dxf.res03.ForeColor = &HFF&
        ElseIf status_pg03 = False And frm_dxf.res03.Caption = "" Then
            frm_dxf.pg03.ForeColor = &HFF0000
            frm_dxf.res03.ForeColor = &HFF0000
        Else
            frm_dxf.pg03.ForeColor = &H8000&
            frm_dxf.res03.ForeColor = &H8000&
        End If
        
        'corte #4
        If Not IsNull(arrRes(16, 0)) Then frm_dxf.pg04.Caption = arrRes(16, 0)
        If Not IsNull(arrRes(3, 0)) Then frm_dxf.res04.Caption = arrRes(3, 0)
        status_pg04 = arrRes(17, 0)
        
        If frm_dxf.pg04.Caption = "" Then
           frm_dxf.pg04.Visible = False
           frm_dxf.ver04.Visible = False
           frm_dxf.res04.Visible = False
        End If
        If status_pg04 = False And frm_dxf.res04.Caption <> "" Then
            frm_dxf.pg04.ForeColor = &HFF&
            frm_dxf.res04.ForeColor = &HFF&
        ElseIf status_pg04 = False And frm_dxf.res04.Caption = "" Then
            frm_dxf.pg04.ForeColor = &HFF0000
            frm_dxf.res04.ForeColor = &HFF0000
        Else
            frm_dxf.pg04.ForeColor = &H8000&
            frm_dxf.res04.ForeColor = &H8000&
        End If
        
        'corte #5
        If Not IsNull(arrRes(18, 0)) Then frm_dxf.pg05.Caption = arrRes(18, 0)
        If Not IsNull(arrRes(4, 0)) Then frm_dxf.res05.Caption = arrRes(4, 0)
        status_pg05 = arrRes(19, 0)
        
        If frm_dxf.pg05.Caption = "" Then
           frm_dxf.pg05.Visible = False
           frm_dxf.ver05.Visible = False
           frm_dxf.res05.Visible = False
        End If
        If status_pg05 = False And frm_dxf.res05.Caption <> "" Then
            frm_dxf.pg05.ForeColor = &HFF&
            frm_dxf.res05.ForeColor = &HFF&
        ElseIf status_pg05 = False And frm_dxf.res05.Caption = "" Then
            frm_dxf.pg05.ForeColor = &HFF0000
            frm_dxf.res05.ForeColor = &HFF0000
        Else
            frm_dxf.pg05.ForeColor = &H8000&
            frm_dxf.res05.ForeColor = &H8000&
        End If
        
        'corte #6
        If Not IsNull(arrRes(20, 0)) Then frm_dxf.pg06.Caption = arrRes(20, 0)
        If Not IsNull(arrRes(5, 0)) Then frm_dxf.res06.Caption = arrRes(5, 0)
        status_pg06 = arrRes(21, 0)
        
        If frm_dxf.pg06.Caption = "" Then
           frm_dxf.pg06.Visible = False
           frm_dxf.ver06.Visible = False
           frm_dxf.res06.Visible = False
        End If
        If status_pg06 = False And frm_dxf.res06.Caption <> "" Then
            frm_dxf.pg06.ForeColor = &HFF&
            frm_dxf.res06.ForeColor = &HFF&
        ElseIf status_pg06 = False And frm_dxf.res06.Caption = "" Then
            frm_dxf.pg06.ForeColor = &HFF0000
            frm_dxf.res06.ForeColor = &HFF0000
        Else
            frm_dxf.pg06.ForeColor = &H8000&
            frm_dxf.res06.ForeColor = &H8000&
        End If
        
        'corte #7
        If Not IsNull(arrRes(22, 0)) Then frm_dxf.pg07.Caption = arrRes(22, 0)
        If Not IsNull(arrRes(6, 0)) Then frm_dxf.res07.Caption = arrRes(6, 0)
        status_pg07 = arrRes(23, 0)
        
        If frm_dxf.pg07.Caption = "" Then
           frm_dxf.pg07.Visible = False
           frm_dxf.ver07.Visible = False
           frm_dxf.res07.Visible = False
        End If
        If status_pg07 = False And frm_dxf.res07.Caption <> "" Then
            frm_dxf.pg07.ForeColor = &HFF&
            frm_dxf.res07.ForeColor = &HFF&
        ElseIf status_pg07 = False And frm_dxf.res07.Caption = "" Then
            frm_dxf.pg07.ForeColor = &HFF0000
            frm_dxf.res07.ForeColor = &HFF0000
        Else
            frm_dxf.pg07.ForeColor = &H8000&
            frm_dxf.res07.ForeColor = &H8000&
        End If
        
        'corte #8
        If Not IsNull(arrRes(24, 0)) Then frm_dxf.pg08.Caption = arrRes(24, 0)
        If Not IsNull(arrRes(7, 0)) Then frm_dxf.res08.Caption = arrRes(7, 0)
        status_pg08 = arrRes(25, 0)
        
        If frm_dxf.pg08.Caption = "" Then
           frm_dxf.pg08.Visible = False
           frm_dxf.ver08.Visible = False
           frm_dxf.res08.Visible = False
        End If
        If status_pg08 = False And frm_dxf.res08.Caption <> "" Then
            frm_dxf.pg08.ForeColor = &HFF&
            frm_dxf.res08.ForeColor = &HFF&
        ElseIf status_pg08 = False And frm_dxf.res08.Caption = "" Then
            frm_dxf.pg08.ForeColor = &HFF0000
            frm_dxf.res08.ForeColor = &HFF0000
        Else
            frm_dxf.pg08.ForeColor = &H8000&
            frm_dxf.res08.ForeColor = &H8000&
        End If
        
        'corte #9
        If Not IsNull(arrRes(26, 0)) Then frm_dxf.pg09.Caption = arrRes(26, 0)
        If Not IsNull(arrRes(8, 0)) Then frm_dxf.res09.Caption = arrRes(8, 0)
        status_pg09 = arrRes(27, 0)
        
        If frm_dxf.pg09.Caption = "" Then
           frm_dxf.pg09.Visible = False
           frm_dxf.ver09.Visible = False
           frm_dxf.res09.Visible = False
        End If
        If status_pg09 = False And frm_dxf.res09.Caption <> "" Then
            frm_dxf.pg09.ForeColor = &HFF&
            frm_dxf.res09.ForeColor = &HFF&
        ElseIf status_pg09 = False And frm_dxf.res09.Caption = "" Then
            frm_dxf.pg09.ForeColor = &HFF0000
            frm_dxf.res09.ForeColor = &HFF0000
        Else
            frm_dxf.pg09.ForeColor = &H8000&
            frm_dxf.res09.ForeColor = &H8000&
        End If
        
        'corte #10
        If Not IsNull(arrRes(28, 0)) Then frm_dxf.pg10.Caption = arrRes(28, 0)
        If Not IsNull(arrRes(9, 0)) Then frm_dxf.res10.Caption = arrRes(9, 0)
        status_pg10 = arrRes(29, 0)
        
        If frm_dxf.pg10.Caption = "" Then
           frm_dxf.pg10.Visible = False
           frm_dxf.ver10.Visible = False
           frm_dxf.res10.Visible = False
        End If
        If status_pg01 = False And frm_dxf.res01.Caption <> "" Then
            frm_dxf.pg10.ForeColor = &HFF&
            frm_dxf.res10.ForeColor = &HFF&
        ElseIf status_pg01 = False And frm_dxf.res01.Caption = "" Then
            frm_dxf.pg10.ForeColor = &HFF0000
            frm_dxf.res10.ForeColor = &HFF0000
        Else
            frm_dxf.pg10.ForeColor = &H8000&
            frm_dxf.res10.ForeColor = &H8000&
        End If
        frm_dxf.Show
    End If
End Sub

Private Sub btnVisualizar_Click()
    
    strFileName = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & lbl_ref.Caption & ".pdf"
    If Dir(strFileName) = "" Then
        MsgBox "Arquivo não Encontrado!", vbExclamation
    Else
        ActiveWorkbook.FollowHyperlink "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & lbl_ref.Caption & ".pdf"
    End If
    Exit Sub
   
End Sub

Private Sub lbl_abrir_Click()
   Dim Shex As Object
   Set Shex = CreateObject("Shell.Application")
   tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & frmsol.lbl_ref.Caption & ".jpg"
   Shex.Open (tgtfile)
End Sub


Private Sub pdf_lst_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Dim Shex As Object
    Set Shex = CreateObject("Shell.Application")
    codigo = Me.pdf_lst.Text
   
    tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
    Shex.Open (tgtfile)

End Sub

Private Sub UserForm_Click()

End Sub
```

---

## `ufValidar`

```vb
Attribute VB_Name = "ufValidar"
Attribute VB_Base = "0{DCF192F5-87C3-42F8-A35D-63AE435D342E}{F69B1DFD-2642-40D5-938D-6DBFDD5E1B71}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Private Sub btn_cancelar_Click()
Unload Me
End Sub

Private Sub btnRejeitar_Click()
    Dim SQL As String
    Dim msg As String
    
    msg = Me.txt_msg.Text
    
    If msg = "" Then
        MsgBox "O motivo da rejeição deverá ser informado!"
        Exit Sub
    End If
    
    n_sl = Replace(frmsol.lbl_ref.Caption, "SL", "")
    SQL = "SELECT Historico, Solicitante FROM Fila WHERE Ref = " & n_sl & ";"
    arrHist = resQuery(SQL)
    hist = arrHist(0, 0)
    autor = arrHist(1, 0)
    
    inicio = vbCrLf & vbCrLf & vbCrLf & "** CONCEITO REJEITADO **" & vbCrLf
    cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf
    historico = hist & inicio & cabec & msg
    
    SQL = "UPDATE Fila SET Det_St = 'PENDENTE', Conceito_St = 'MODELO', Historico = '" & historico & "' WHERE Ref = " & n_sl & ";"
    upQuery (SQL)

    ' [ADICIONADO] push pro MySQL (status + comentário)
    atualizarStatusMySQL n_sl, "detalhamento_status=" & enc("PENDENTE") & "&conceito_status=" & enc("MODELO")
    comentarMySQL n_sl, autor, "** CONCEITO REJEITADO ** " & msg
    
    frmsol.txt_historico.Text = historico
    
    Unload Me
    
    
End Sub

Private Sub btnValidar_Click()
        
    Dim SQL As String
        
    For a = 1 To 10
        If Me.Controls("lblReq" & a).Visible = True Then
            If Me.Controls("chkReq" & a).Picture = Me.chkOn.Picture Then Allchk = "ok" Else Allchk = "nok"
        End If
    Next a
    
    If Allchk = "nok" Then
        MsgBox "Todos os Requisitos devem ser validados!"
        Exit Sub
    End If
    
    n_sl = Replace(frmsol.lbl_ref.Caption, "SL", "")
    SQL = "SELECT Historico, Solicitante FROM Fila WHERE Ref = " & n_sl & ";"
    arrHist = resQuery(SQL)
    hist = arrHist(0, 0)
    autor = arrHist(1, 0)
        
    inicio = vbCrLf & vbCrLf & vbCrLf & "** VALIDAÇÃO DA SOLICITAÇÃO **" & vbCrLf
    cabec = "-- " & autor & " (" & Format(Day(Now), "00") & "." & Format(Month(Now), "00") & "." & Format(Year(Now), "0000") & " - " & Format(Now, "HH:MM") & "):" & vbCrLf

    msg = Me.txt_msg.Text
    
    If msg = "" Then
        msg = "OK. De acordo!"
        Me.txt_msg.Text = msg
    End If
    
    historico = hist & inicio & cabec & msg
    
    chkReq = Me.lblReqs.Caption
    
    SQL = "UPDATE Fila SET Det_St = 'PENDENTE', Historico = '" & historico & "' , CKReq = '" & chkReq & "' WHERE Ref = " & n_sl & ";"
    upQuery (SQL)

    ' [ADICIONADO] push pro MySQL (status + comentário)
    atualizarStatusMySQL n_sl, "detalhamento_status=" & enc("PENDENTE")
    comentarMySQL n_sl, autor, "** VALIDAÇÃO DA SOLICITAÇÃO ** " & msg
    
    frmsol.det_st.Caption = "PENDENTE"
    frmsol.det_st.BackColor = &H8080FF
    
    frmsol.txt_historico.Text = historico
    
    frmsol.btnValidar.Enabled = False
    Unload Me
    
    MsgBox "Solicitação validada!"
    

End Sub

Private Sub chkReq1_Click()
    If Me.chkReq1.Picture = Me.chkOff.Picture Then
        Me.chkReq1.Picture = Me.chkOn.Picture
        Me.cxReq1.BorderColor = &H8000&
        Me.lblReq1.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq1.Picture = Me.chkOff.Picture
        Me.cxReq1.BorderColor = &HFF&
        Me.lblReq1.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq2_Click()
    If Me.chkReq2.Picture = Me.chkOff.Picture Then
        Me.chkReq2.Picture = Me.chkOn.Picture
        Me.cxReq2.BorderColor = &H8000&
        Me.lblReq2.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq

    Else
        Me.chkReq2.Picture = Me.chkOff.Picture
        Me.cxReq2.BorderColor = &HFF&
        Me.lblReq2.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq3_Click()
    If Me.chkReq3.Picture = Me.chkOff.Picture Then
        Me.chkReq3.Picture = Me.chkOn.Picture
        Me.cxReq3.BorderColor = &H8000&
        Me.lblReq3.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq3.Picture = Me.chkOff.Picture
        Me.cxReq3.BorderColor = &HFF&
        Me.lblReq3.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq4_Click()
    If Me.chkReq4.Picture = Me.chkOff.Picture Then
        Me.chkReq4.Picture = Me.chkOn.Picture
        Me.cxReq4.BorderColor = &H8000&
        Me.lblReq4.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq4.Picture = Me.chkOff.Picture
        Me.cxReq4.BorderColor = &HFF&
        Me.lblReq4.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq5_Click()
    If Me.chkReq5.Picture = Me.chkOff.Picture Then
        Me.chkReq5.Picture = Me.chkOn.Picture
        Me.cxReq5.BorderColor = &H8000&
        Me.lblReq5.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq5.Picture = Me.chkOff.Picture
        Me.cxReq5.BorderColor = &HFF&
        Me.lblReq5.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq6_Click()
    If Me.chkReq6.Picture = Me.chkOff.Picture Then
        Me.chkReq6.Picture = Me.chkOn.Picture
        Me.cxReq6.BorderColor = &H8000&
        Me.lblReq6.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq6.Picture = Me.chkOff.Picture
        Me.cxReq6.BorderColor = &H8000&
        Me.lblReq6.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq7_Click()
    If Me.chkReq7.Picture = Me.chkOff.Picture Then
        Me.chkReq7.Picture = Me.chkOn.Picture
        Me.cxReq7.BorderColor = &H8000&
        Me.lblReq7.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq7.Picture = Me.chkOff.Picture
        Me.cxReq7.BorderColor = &HFF&
        Me.lblReq7.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq8_Click()
    If Me.chkReq8.Picture = Me.chkOff.Picture Then
        Me.chkReq8.Picture = Me.chkOn.Picture
        Me.cxReq8.BorderColor = &H8000&
        Me.lblReq8.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq8.Picture = Me.chkOff.Picture
        Me.cxReq8.BorderColor = &HFF&
        Me.lblReq8.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq9_Click()
    If Me.chkReq9.Picture = Me.chkOff.Picture Then
        Me.chkReq9.Picture = Me.chkOn.Picture
        Me.cxReq9.BorderColor = &H8000&
        Me.lblReq9.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq9.Picture = Me.chkOff.Picture
        Me.cxReq9.BorderColor = &HFF&
        Me.lblReq9.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub
Private Sub chkReq10_Click()
    If Me.chkReq10.Picture = Me.chkOff.Picture Then
        Me.chkReq10.Picture = Me.chkOn.Picture
        Me.cxReq10.BorderColor = &H8000&
        Me.lblReq10.ForeColor = &H8000&
        Me.lblReqs.Caption = calculaReq
    Else
        Me.chkReq10.Picture = Me.chkOff.Picture
        Me.cxReq10.BorderColor = &HFF&
        Me.lblReq10.ForeColor = &HFF&
        Me.lblReqs.Caption = calculaReq
    End If
End Sub

Private Function calculaReq()
    Req = ""
    For a = 1 To 10
        If Me.Controls("lblReq" & a).Caption <> "" And Me.Controls("chkReq" & a).Picture = Me.chkOn.Picture Then Req = Req & "A" & "|" Else Req = Req & "0" & "|"
    Next a
    calculaReq = Req
End Function


Private Sub txt_msg_Change()
    If Me.txt_msg.Text <> "" Then Me.btnValidar.Enabled = True Else Me.btnValidar.Enabled = False
End Sub

Private Sub UserForm_Initialize()
    For i = 1 To 10
        Me.Controls("chkReq" & i).Picture = Me.chkOff.Picture
    Next i

    Dim SQL As String
    ctrl = Replace(frmsol.lbl_ref.Caption, "SL", "")
    SQL = "SELECT Requisitos FROM Fila WHERE Ref = " & ctrl & ";"
    ArrReq = resQuery(SQL)
    
    If Not IsNull(ArrReq(0, 0)) Then
        Req = Split(ArrReq(0, 0), "-|-")
        For a = 0 To 9
            If Req(a) <> "" Then
                Me.Controls("lblReq" & a + 1).Visible = True
                Me.Controls("cxReq" & a + 1).Visible = True
                Me.Controls("chkReq" & a + 1).Visible = True
                Me.Controls("lblReq" & a + 1).Caption = Req(a)
            End If
        Next a
    End If
End Sub
```

---

## `Plan1`

```vb
Attribute VB_Name = "Plan1"
Attribute VB_Base = "0{00020820-0000-0000-C000-000000000046}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = True

Private Sub Worksheet_BeforeDoubleClick(ByVal Target As Range, Cancel As Boolean)

Dim SQL As String

Cancel = True
Ln = Target.Row

ref = Cells(Ln, 2).Value
ref_sl = ref
frmsol.lbl_ref.Caption = ref

ref = Replace(ref, "SL", "") * 1

'CARREGAR INFORMAÇÕES DA SOLICITAÇÃO
SQL = "SELECT Descricao, Data_Solicitacao, Solicitante, Aplicacao, Vagao, Lote, Historico,"
SQL = SQL & "Conceito_St, Conceito_Fim, "
SQL = SQL & "Det_St, Det_Fim, "
SQL = SQL & "Liberacao_St, Liberacao_Data, Aq_St, Aq_Data, Corte_St, Corte_Data, Exec_St, Exec_Data, Tryout_St, Tryout_Data, Classe, "
SQL = SQL & " Cod_Z , Conceito_P, Det_P, Conceito_Ini, Liberacao_Data, Liberacao_St, Executor_EI, Data_Inicio_EI, Data_Fim_EI, Status_EI, NumSfpCC"
SQL = SQL & " FROM Fila WHERE Ref = " & ref & ";"


If Cells(Ln, 2).Value <> "" And Cells(Ln, 2).Value <> "Ref" Then
       arrRes = resQuery(SQL)

        If Not IsEmpty(arrRes) Then
            a = 0
            frmsol.lbl_desc = arrRes(0, a)
            If IsNull(arrRes(1, a)) Then frmsol.lbl_data = "" Else frmsol.lbl_data = arrRes(1, a)
            If IsNull(arrRes(2, a)) Then frmsol.lbl_solic = "" Else frmsol.lbl_solic = arrRes(2, a)
        
            If IsNull(arrRes(3, a)) Then frmsol.lbl_estagio = "" Else frmsol.lbl_estagio = arrRes(3, a)
            If IsNull(arrRes(4, a)) Then frmsol.lbl_vg = "" Else frmsol.lbl_vg = arrRes(4, a)
            If IsNull(arrRes(5, a)) Then frmsol.lbl_lote = "" Else frmsol.lbl_lote = arrRes(5, a)
            If IsNull(arrRes(6, a)) Then frmsol.txt_historico.Text = "" Else frmsol.txt_historico.Text = arrRes(6, a)
        
        
            If IsNull(arrRes(7, a)) Then frmsol.proj_st.Caption = "" Else frmsol.proj_st.Caption = arrRes(7, a)
            If IsNull(arrRes(8, a)) Then frmsol.proj_data.Caption = "" Else frmsol.proj_data.Caption = Format(arrRes(8, a), "DD.MM.YY | hh:mm")
        
        
            If IsNull(arrRes(9, a)) Then frmsol.det_st.Caption = "" Else frmsol.det_st.Caption = arrRes(9, a)
            If IsNull(arrRes(10, a)) Then frmsol.det_data.Caption = "" Else frmsol.det_data.Caption = Format(arrRes(10, a), "DD.MM.YY | hh:mm")
        
        
            If IsNull(arrRes(11, a)) Then frmsol.lib_st.Caption = "" Else frmsol.lib_st.Caption = arrRes(11, a)
            If IsNull(arrRes(12, a)) Then frmsol.lib_data.Caption = "" Else frmsol.lib_data.Caption = Format(arrRes(12, a), "DD.MM.YY | hh:mm")
        
            If IsNull(arrRes(13, a)) Then frmsol.aq_st.Caption = "" Else frmsol.aq_st.Caption = arrRes(13, a)
            If IsNull(arrRes(14, a)) Then frmsol.aq_data.Caption = "" Else frmsol.aq_data.Caption = Format(arrRes(14, a), "DD.MM.YY | hh:mm")
        
            If IsNull(arrRes(15, a)) Then frmsol.corte_st.Caption = "" Else frmsol.corte_st.Caption = arrRes(15, a)
            If IsNull(arrRes(16, a)) Then frmsol.corte_data.Caption = "" Else frmsol.corte_data.Caption = Format(arrRes(16, a), "DD.MM.YY | hh:mm")
        
            If IsNull(arrRes(17, a)) Then frmsol.exec_st.Caption = "" Else frmsol.exec_st.Caption = arrRes(17, a)
            If IsNull(arrRes(18, a)) Then frmsol.exec_data.Caption = "" Else frmsol.exec_data.Caption = Format(arrRes(18, a), "DD.MM.YY | hh:mm")
        
            If IsNull(arrRes(19, a)) Then frmsol.tryout_st.Caption = "" Else frmsol.tryout_st.Caption = arrRes(19, a)
            If IsNull(arrRes(20, a)) Then frmsol.tryout_data.Caption = "" Else frmsol.tryout_data.Caption = Format(arrRes(20, a), "DD.MM.YY | hh:mm")
        
            If IsNull(arrRes(21, a)) Then frmsol.lbl_classe.Caption = "" Else frmsol.lbl_classe.Caption = arrRes(21, a)
        
            G_Solicitante = Sheets("Controle").Range("S1").Value
        
            If frmsol.det_st.Caption = "[VALIDAÇÃO]" And frmsol.lbl_solic = G_Solicitante Then frmsol.btnValidar.Enabled = True Else frmsol.btnValidar.Enabled = False
            If (frmsol.exec_st = "FINALIZADO" Or frmsol.exec_st.Caption = "TERCEIRIZADO") And frmsol.tryout_st <> "OK" Then frmsol.btnTryout_OK.Enabled = True Else frmsol.btnTryout_OK.Enabled = False
            If (frmsol.exec_st = "FINALIZADO" Or frmsol.exec_st.Caption = "TERCEIRIZADO") And frmsol.tryout_st <> "OK" Then frmsol.btnTryout_NaoOK.Enabled = True Else frmsol.btnTryout_NaoOK.Enabled = False
            If frmsol.proj_st.Caption = "PENDENTE" Or frmsol.proj_st.Caption = "EM ANÁLISE" Then frmsol.btnCancelarSol.Enabled = True Else frmsol.btnCancelarSol.Enabled = False
            If (frmsol.exec_st = "FINALIZADO" Or frmsol.exec_st.Caption = "TERCEIRIZADO") And frmsol.tryout_st.Caption <> "OK" Then frmsol.btnTryout_OK.BackColor = &HC0FFC0
            If (frmsol.exec_st = "FINALIZADO" Or frmsol.exec_st.Caption = "TERCEIRIZADO") And frmsol.tryout_st.Caption <> "OK" Then frmsol.btnTryout_NaoOK.BackColor = &HC0C0FF
            
            'Cores
            azul = &HC59452
            vermelho = &H8080FF
            azul_claro = &HFF8080
            amarelo = &H8080&
            amarelo2 = &HFFFF&
            cinza_escuro = &H808080
            cinza_claro = &HC0C0C0
            verde = &H8000&

            'Ajustar cor das Labels
            If frmsol.proj_st.Caption = "OK" Then frmsol.proj_st.BackColor = verde
            If frmsol.proj_st.Caption = "PENDENTE" Then frmsol.proj_st.BackColor = vermelho
            If frmsol.proj_st.Caption = "CANCELADO" Then frmsol.proj_st.BackColor = cinza_claro
            If frmsol.proj_st.Caption = "PAUSADO" Then frmsol.proj_st.BackColor = cinza_escuro
            If frmsol.proj_st.Caption = "EM ANÁLISE" Then frmsol.proj_st.BackColor = azul
            If frmsol.proj_st.Caption = "MODELO" Then frmsol.proj_st.BackColor = amarelo
            If frmsol.proj_st.Caption = "BACKLOG" Then frmsol.proj_st.BackColor = azul_claro
        
            If frmsol.det_st.Caption = "OK" Then frmsol.det_st.BackColor = verde
            If frmsol.det_st.Caption = "[VALIDAÇÃO]" Then frmsol.det_st.BackColor = amarelo2
            If frmsol.det_st.Caption = "PENDENTE" Then frmsol.det_st.BackColor = vermelho
            If frmsol.det_st.Caption = "CANCELADO" Then frmsol.det_st.BackColor = cinza_claro
            
        
            If frmsol.lib_st.Caption = "OK" Then frmsol.lib_st.BackColor = verde
            If frmsol.lib_st.Caption = "PENDENTE" Then frmsol.lib_st.BackColor = vermelho
            If frmsol.lib_st.Caption = "CANCELADO" Then frmsol.lib_st.BackColor = cinza_claro
        
            If frmsol.aq_st.Caption = "OK" Then frmsol.aq_st.BackColor = verde
            If frmsol.aq_st.Caption = "PENDENTE" Then frmsol.aq_st.BackColor = vermelho
            If frmsol.aq_st.Caption = "CANCELADO" Then frmsol.aq_st.BackColor = cinza_claro
        
            If frmsol.corte_st.Caption = "FINALIZADO" Then frmsol.corte_st.BackColor = verde
            If frmsol.corte_st.Caption = "ANDAMENTO" Then frmsol.corte_st.BackColor = amarelo
            If frmsol.corte_st.Caption = "PARADO" Then frmsol.corte_st.BackColor = vermelho
            If frmsol.corte_st.Caption = "CANCELADO" Then frmsol.corte_st.BackColor = cinza_claro
        
            If frmsol.exec_st.Caption = "FINALIZADO" Then frmsol.exec_st.BackColor = verde
            If frmsol.exec_st.Caption = "ANDAMENTO" Then frmsol.exec_st.BackColor = amarelo
            If frmsol.exec_st.Caption = "PARADO" Then frmsol.exec_st.BackColor = vermelho
            If frmsol.exec_st.Caption = "CANCELADO" Then frmsol.exec_st.BackColor = cinza_claro
        
            If frmsol.tryout_st.Caption = "OK" Then frmsol.tryout_st.BackColor = verde
            If frmsol.tryout_st.Caption = "PENDENTE" Then frmsol.tryout_st.BackColor = vermelho
            If frmsol.tryout_st.Caption = "CANCELADO" Then frmsol.tryout_st.BackColor = cinza_claro
            If frmsol.tryout_st.Caption = "NÃO OK" Then frmsol.tryout_st.BackColor = amarelo 'rev 19/12/24

            'Preenche dados do Projeto
            If IsNull(arrRes(22, a)) Then frmsol.lbl_cod_z.Caption = "" Else frmsol.lbl_cod_z.Caption = arrRes(22, a)
            If IsNull(arrRes(23, a)) Then frmsol.lbl_projeto.Caption = "" Else frmsol.lbl_projeto.Caption = arrRes(23, a)
            If IsNull(arrRes(24, a)) Then frmsol.lbl_detalhe.Caption = "" Else frmsol.lbl_detalhe.Caption = arrRes(24, a)
            If IsNull(arrRes(25, a)) Then frmsol.lbl_ini_proj.Caption = "" Else frmsol.lbl_ini_proj.Caption = Format(arrRes(25, a), "DD.MM.YY")
            If IsNull(arrRes(26, a)) Then frmsol.lbl_fim_proj.Caption = "" Else frmsol.lbl_fim_proj.Caption = Format(arrRes(26, a), "DD.MM.YY")
            If IsNull(arrRes(27, a)) Then frmsol.lbl_status_proj.Caption = "" Else frmsol.lbl_status_proj.Caption = arrRes(27, a)
            
            'Preenche dados da Execução
            If IsNull(arrRes(28, a)) Then frmsol.lbl_executor.Caption = "" Else frmsol.lbl_executor.Caption = arrRes(28, a)
            If IsNull(arrRes(29, a)) Then frmsol.lbl_ini_exec.Caption = "" Else frmsol.lbl_ini_exec.Caption = arrRes(29, a)
            If IsNull(arrRes(30, a)) Then frmsol.lbl_fim_exec.Caption = "" Else frmsol.lbl_fim_exec.Caption = arrRes(30, a)
            If IsNull(arrRes(31, a)) Then frmsol.lbl_status_exec.Caption = "" Else frmsol.lbl_status_exec.Caption = arrRes(31, a)
            
            'Número SFP ou Conta Contábil
            If IsNull(arrRes(32, a)) Then frmsol.lbl_sfp.Caption = "" Else frmsol.lbl_sfp.Caption = arrRes(32, a)
        
          
          
            'Carregar List DXF
            SQL = "SELECT Controle, Descricao, Prioridade, Status FROM DXF_Control WHERE Solicitacao = '" & ref_sl & "' ORDER BY Controle DESC;"

            ArrRes_DXF = resQuery(SQL)

            If Not IsEmpty(ArrRes_DXF) Then
                tam_res = UBound(ArrRes_DXF, 2)
                If tam_res > 2 Then tam_res = 2
                For Ln = 1 To tam_res + 1
                    cell = "dxf_ln" & Ln & "_col"
                    i = Ln - 1
                    For col = 1 To 4
                        If Not IsNull(ArrRes_DXF(col - 1, i)) Then
                            If col = 1 Then valor = "DX" & Format(ArrRes_DXF(col - 1, i), "0000") Else valor = ArrRes_DXF(col - 1, i)
                            frmsol.Controls(cell & col).Caption = valor
                            sts = ArrRes_DXF(2, i)
                            If sts = "CONCLUÍDO" Then frmsol.Controls(cell & col).ForeColor = RGB(35, 142, 35)
                            If sts = "99-Cancelado" Then frmsol.Controls(cell & col).ForeColor = RGB(150, 150, 150)
                            If sts <> "CONCLUÍDO" And sts <> "99-Cancelado" Then frmsol.Controls(cell & col).ForeColor = RGB(255, 0, 0)
                        Else
                            frmsol.Controls(cell & col).Caption = ""
                        End If
                        
                    Next col
                Next Ln
            End If

            'Carregar List PDF
            SQL = "SELECT Codigo FROM PDF_Control WHERE Solicitacao = '" & ref_sl & "' ORDER BY Codigo;"
            ArrRes_PDF = resQuery(SQL)
            If Not IsEmpty(ArrRes_PDF) Then
                tam_res = UBound(ArrRes_PDF, 2)
                frmsol.pdf_lst.Clear
                For i = 0 To tam_res
                    frmsol.pdf_lst.AddItem (ArrRes_PDF(0, i))
                Next i
            End If
        
            'Carregar List BOM

            SQL = "SELECT B.Controle, B.Codigo, B.Revisao, B.Descricao, B.Qtde, B.Tipo, B.OC, Aq.Status, Aq.Pedido FROM BOM_Control B LEFT OUTER JOIN OC_Control Aq ON B.OC = Aq.OC WHERE B.Solicitacao = '" & ref_sl & "';"
            
            ArrRes_BOM = resQuery(SQL)

            If Not IsEmpty(ArrRes_BOM) Then
                tam_res = UBound(ArrRes_BOM, 2)
                If tam_res > 9 Then tam_res = 9
                For Ln = 1 To tam_res + 1
                    cell = "bom_ln" & Ln & "_col"
                    i = Ln - 1
                    For col = 1 To 8
                        If Not IsNull(ArrRes_BOM(col, i)) Then frmsol.Controls(cell & col).Caption = ArrRes_BOM(col, i) Else frmsol.Controls(cell & col).Caption = ""
                        If ArrRes_BOM(7, i) = "LIQUIDADA" Then frmsol.Controls(cell & col).ForeColor = &H8000&
                        If ArrRes_BOM(7, i) = "PENDENTE" Then frmsol.Controls(cell & col).ForeColor = &HFF&
                        If ArrRes_BOM(7, i) = "REALIZADA" Then frmsol.Controls(cell & col).ForeColor = &H80FF&
                        If ArrRes_BOM(7, i) = "EM ABERTO" Then frmsol.Controls(cell & col).ForeColor = &HFF0000
                        If ArrRes_BOM(7, i) = "COTAÇÃO" Then frmsol.Controls(cell & col).ForeColor = &HC000C0
                        If ArrRes_BOM(7, i) = "CANCELADO" Then frmsol.Controls(cell & col).ForeColor = &H808080
                        If ArrRes_BOM(1, i) = "SIDERÚRGICO" Then frmsol.Controls(cell & col).ForeColor = &HFF&
                    Next col
                Next Ln
            End If

      
            On Error Resume Next
            caminho = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & ref_sl & ".jpg"
            On Error Resume Next
            frmsol.img_sl.Picture = LoadPicture(caminho)
        End If
    
    frmsol.Show

End If
End Sub

Private Sub Worksheet_Change(ByVal Target As Range)
Dim KeyCells1, KeyCells2, KeyCells3, KeyCells4
Dim SQL As String

Application.ScreenUpdating = False
Application.EnableEvents = False



Cancel = True
Ln = Target.Row

Set KeyCells1 = Range("G3") 'Referencia
If Not Application.Intersect(KeyCells1, Range(Target.Address)) Is Nothing Then
    
    Range("H3").ClearContents
    
    vg = Range("G3").Value
    
    SQL = "SELECT DISTINCT Lote FROM VGs WHERE VGs = '" & vg & "';"
    
    arrRes = resQuery(SQL)
    
    If Not IsEmpty(arrRes) Then
        Worksheets("Listas").Range("C3:C100").ClearContents
        lin = 3
        For a = 0 To UBound(arrRes, 2)
            If arrRes(0, a) <> "" Then
                Sheets("Listas").Cells(lin, 3).Value = arrRes(0, a)
                lin = lin + 1
            End If
        Next a
    
    End If
    
End If


Set KeyCells2 = Range("D3:H3") 'Solicitante

If Not Application.Intersect(KeyCells2, Range(Target.Address)) Is Nothing Then

    filtro = Range("I3").Value
    If filtro = 1 Then filtro_01
    If filtro = 2 Then filtro_02
    If filtro = 3 Then filtro_03
    If filtro = 4 Then filtro_04
    If filtro = 5 Then filtro_05
    If filtro = 6 Then filtro_06

    If filtro = 7 Then lista_todos
    If filtro = 0 Then lista_pendentes

End If


Set KeyCells3 = Range("I3:I1000") 'Prioridade
If Not Application.Intersect(KeyCells3, Range(Target.Address)) Is Nothing Then
'Ln = Target.Row
'prio = Cells(Ln, 9).Value
'ref = Cells(Ln, 2).Value
' ref = Replace(ref, "SL", "") * 1
'    If ref <> "" Then
'        SQL = "UPDATE Fila SET Prio = " & prio & " WHERE Ref = " & ref & ";"
'        upQuery (SQL)
        filtro = Range("I3").Value
        If filtro = 1 Then filtro_01
        If filtro = 2 Then filtro_02
        If filtro = 3 Then filtro_03
        If filtro = 4 Then filtro_04
        If filtro = 5 Then filtro_05
        If filtro = 6 Then filtro_06
        If filtro = 7 Then lista_todos
        If filtro = 0 Then lista_pendentes
'    End If
End If


Set KeyCells4 = Range("C5:C1000") 'Inserir Novo

If Not Application.Intersect(KeyCells4, Range(Target.Address)) Is Nothing Then
Ln = Target.Row

desc = Cells(Ln, 3).Value

If ref = "" Then
    frm_novo.txt_solicitacao.Text = UCase(desc)
    Call inserir_nova
    
Else
    Application.Undo
End If

End If

Application.ScreenUpdating = True
Application.EnableEvents = True


End Sub
```

---

## `Filtros`

```vb
Attribute VB_Name = "Filtros"
Sub Gerar_Lista(SQL As String)

arrRes = resQuery(SQL)

    Range("B5:Q1000").ClearContents

    If Not IsEmpty(arrRes) Then
        lin = 5
        
        For a = 0 To UBound(arrRes, 2)
            Sheets("Controle").Cells(lin, 2).Value = "SL" & Format(arrRes(0, a), "0000")
            Sheets("Controle").Cells(lin, 3).Value = arrRes(1, a)
            Sheets("Controle").Cells(lin, 4).Value = arrRes(2, a)
            Sheets("Controle").Cells(lin, 5).Value = arrRes(3, a)
            Sheets("Controle").Cells(lin, 6).Value = arrRes(4, a)
            Sheets("Controle").Cells(lin, 7).Value = arrRes(5, a)
            Sheets("Controle").Cells(lin, 8).Value = arrRes(6, a)
            Sheets("Controle").Cells(lin, 9).Value = arrRes(7, a)
            
            
            st_con = arrRes(8, a)
            If st_con = "PENDENTE" Then st_con = "PEN"
            If st_con = "EM ANÁLISE" Then st_con = "ANA"
            If st_con = "BACKLOG" Then st_con = "BAK"
            If st_con = "CANCELADO" Then st_con = "CAN"
            If st_con = "MODELO" Then st_con = "MOD"
            If st_con = "PAUSADO" Then st_con = "PSD"
            If st_con = "OK" Then st_con = "OK"
            
            st_det = arrRes(9, a)
            If st_det = "PENDENTE" Then st_det = "PEN"
            If st_det = "EM ANDAMENTO" Then st_det = "AND"
            If st_det = "PAUSADO" Then st_det = "PSD"
            If st_det = "CANCELADO" Then st_det = "CAN"
            If st_det = "OK" Then st_det = "OK"
            If st_det = "[VALIDAÇÃO]" Then st_det = "VAL"
            
            
            st_lib = arrRes(10, a)
            If st_lib = "PENDENTE" Then st_lib = "PEN"
            If st_lib = "CANCELADO" Then st_lib = "CAN"
            If st_lib = "OK" Then st_lib = "OK"
            
            
            st_aq = arrRes(11, a)
            If st_aq = "PENDENTE" Then st_aq = "PEN"
            If st_aq = "CANCELADO" Then st_aq = "CAN"
            If st_aq = "REALIZADO" Then st_aq = "RLZ"
            If st_aq = "OK" Then st_aq = "OK"
            
            st_corte = arrRes(12, a)
            If st_corte = "PARADO" Then st_corte = "PAR"
            If st_corte = "ANDAMENTO" Then st_corte = "AND"
            If st_corte = "CANCELADO" Then st_corte = "CAN"
            If st_corte = "FINALIZADO" Then st_corte = "FIN"
            If st_corte = "TERCEIRIZADO" Then st_corte = "TER"
            
            st_exec = arrRes(13, a)
            If st_exec = "PARADO" Then st_exec = "PAR"
            If st_exec = "ANDAMENTO" Then st_exec = "AND"
            If st_exec = "CANCELADO" Then st_exec = "CAN"
            If st_exec = "FINALIZADO" Then st_exec = "FIN"
            If st_exec = "TERCEIRIZADO" Then st_exec = "TER"
            
            st_tryout = arrRes(14, a)
            If st_tryout = "PENDENTE" Then st_tryout = "PEN"
            If st_tryout = "CANCELADO" Then st_tryout = "CAN"
            If st_tryout = "OK" Then st_tryout = "OK"
            If st_tryout = "NÃO OK" Then st_tryout = "NOK" 'rev 19/12/24
            
                        
            Sheets("Controle").Cells(lin, 11).Value = st_con
            Sheets("Controle").Cells(lin, 12).Value = st_det
            Sheets("Controle").Cells(lin, 13).Value = st_lib
            Sheets("Controle").Cells(lin, 14).Value = st_aq
            Sheets("Controle").Cells(lin, 15).Value = st_corte
            Sheets("Controle").Cells(lin, 16).Value = st_exec
            Sheets("Controle").Cells(lin, 17).Value = st_tryout
            lin = lin + 1
        Next a
    
    End If
End Sub

Sub Limpa_tudo()
    
    Desabilita

    Worksheets("Controle").Range("B5:Q10000").ClearContents
    Worksheets("Controle").Range("D3").ClearContents
    Worksheets("Controle").Range("G3").ClearContents
    Worksheets("Controle").Range("H3").ClearContents

    Limpar_botoes
    
    Reset

End Sub



Sub Limpar_botoes()
    Application.EnableEvents = False
      
    Worksheets("Controle").Shapes("BT_01").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_01").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_02").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_02").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_03").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_03").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_04").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_04").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_05").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_05").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_06").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_06").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_07").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_07").TextFrame.Characters.Font.ColorIndex = 15
    
    Application.EnableEvents = True

End Sub

Sub filtro_01()

    Desabilita
    
    Worksheets("Controle").Shapes("BT_01").ShapeStyle = msoShapeStylePreset24
    Worksheets("Controle").Shapes("BT_01").TextFrame.Characters.Font.ColorIndex = 30
    Worksheets("Controle").Shapes("BT_02").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_02").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_03").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_03").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_04").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_04").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_05").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_05").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_06").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_06").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_07").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_07").TextFrame.Characters.Font.ColorIndex = 15
    
    Dim SQL As String
   
    solic = Worksheets("Controle").Range("D3").Value
    vg = Worksheets("Controle").Range("G3").Value
    lote = Worksheets("Controle").Range("H3").Value
    
       
    SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila WHERE "
    
    If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
    If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
    If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
    If lote = "" Or lote = "TODOS" Then
        SQL = SQL & "Conceito_St <> 'OK' ORDER BY Prio,Ref;"
    Else
        SQL = SQL & "Conceito_St <> 'OK' AND Lote = ' & lote & ' ORDER BY Prio,Ref;"
    End If
        
    Gerar_Lista (SQL)
    
    Sheets("Controle").Range("I3").Value = 1

    Reset
    
End Sub

Sub filtro_02()

    Desabilita
    
    Worksheets("Controle").Shapes("BT_01").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_01").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_02").ShapeStyle = msoShapeStylePreset24
    Worksheets("Controle").Shapes("BT_02").TextFrame.Characters.Font.ColorIndex = 30
    Worksheets("Controle").Shapes("BT_03").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_03").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_04").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_04").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_05").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_05").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_06").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_06").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_07").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_07").TextFrame.Characters.Font.ColorIndex = 15
    
    Dim SQL As String
   
    solic = Worksheets("Controle").Range("D3").Value
    vg = Worksheets("Controle").Range("G3").Value
    lote = Worksheets("Controle").Range("H3").Value
    
       
    SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila  WHERE "
    
    If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
    If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
    If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
    If lote = "" Or lote = "TODOS" Then
        SQL = SQL & "Conceito_St = 'OK' AND Det_St <> 'OK' ORDER BY Prio,Ref;"
    Else
        SQL = SQL & "Conceito_St = 'OK' AND Det_St <> 'OK' AND Lote = ' & lote & ' ORDER BY Prio,Ref;"
    End If
        
    Gerar_Lista (SQL)
    
    Sheets("Controle").Range("I3").Value = 2

    Reset
    
End Sub

Sub filtro_03()
    
    Desabilita

    Worksheets("Controle").Shapes("BT_01").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_01").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_02").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_02").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_03").ShapeStyle = msoShapeStylePreset24
    Worksheets("Controle").Shapes("BT_03").TextFrame.Characters.Font.ColorIndex = 30
    Worksheets("Controle").Shapes("BT_04").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_04").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_05").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_05").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_06").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_06").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_07").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_07").TextFrame.Characters.Font.ColorIndex = 15

    
    Dim SQL As String
   
    solic = Worksheets("Controle").Range("D3").Value
    vg = Worksheets("Controle").Range("G3").Value
    lote = Worksheets("Controle").Range("H3").Value
    
       
    SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila WHERE  "
    
    If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
    If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
    If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
    If lote = "" Or lote = "TODOS" Then
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St <> 'OK' ORDER BY Prio,Ref;"
    Else
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St <> 'OK' AND Lote = ' & lote & ' ORDER BY Prio,Ref;"
    End If
        
    Gerar_Lista (SQL)
    
    Sheets("Controle").Range("I3").Value = 3

    Reset
    
End Sub

Sub filtro_04()

    Desabilita

    Worksheets("Controle").Shapes("BT_01").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_01").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_02").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_02").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_03").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_03").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_04").ShapeStyle = msoShapeStylePreset24
    Worksheets("Controle").Shapes("BT_04").TextFrame.Characters.Font.ColorIndex = 30
    Worksheets("Controle").Shapes("BT_05").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_05").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_06").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_06").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_07").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_07").TextFrame.Characters.Font.ColorIndex = 15

    
    Dim SQL As String
   
    solic = Worksheets("Controle").Range("D3").Value
    vg = Worksheets("Controle").Range("G3").Value
    lote = Worksheets("Controle").Range("H3").Value
    
       
    SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila WHERE  "
    
    If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
    If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
    If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
    If lote = "" Or lote = "TODOS" Then
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St = 'OK'  AND Aq_St <> 'OK'  ORDER BY Prio,Ref;"
    Else
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St = 'OK'  AND Aq_St <> 'OK'  AND Lote = ' & lote & ' ORDER BY Prio,Ref;"
    End If
        
    Gerar_Lista (SQL)
    
    Sheets("Controle").Range("I3").Value = 4

    Reset
    
End Sub

Sub filtro_05()
    
    Desabilita

    Worksheets("Controle").Shapes("BT_01").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_01").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_02").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_02").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_03").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_03").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_04").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_04").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_05").ShapeStyle = msoShapeStylePreset24
    Worksheets("Controle").Shapes("BT_05").TextFrame.Characters.Font.ColorIndex = 30
    Worksheets("Controle").Shapes("BT_06").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_06").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_07").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_07").TextFrame.Characters.Font.ColorIndex = 15

    
    Dim SQL As String
   
    solic = Worksheets("Controle").Range("D3").Value
    vg = Worksheets("Controle").Range("G3").Value
    lote = Worksheets("Controle").Range("H3").Value
    
       
    SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila  WHERE "
    
    If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
    If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
    If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
    If lote = "" Or lote = "TODOS" Then
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St = 'OK'  AND Corte_St <> 'OK' ORDER BY Prio,Ref;"
    Else
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St = 'OK'  AND Corte_St <> 'OK'  AND Lote = ' & lote & ' ORDER BY Prio,Ref;"
    End If
        
    Gerar_Lista (SQL)
    
    Sheets("Controle").Range("I3").Value = 4

    Reset
    
End Sub

Sub filtro_06()
    
    Desabilita

    Worksheets("Controle").Shapes("BT_01").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_01").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_02").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_02").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_03").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_03").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_04").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_04").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_05").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_05").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_06").ShapeStyle = msoShapeStylePreset24
    Worksheets("Controle").Shapes("BT_06").TextFrame.Characters.Font.ColorIndex = 30
    Worksheets("Controle").Shapes("BT_07").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_07").TextFrame.Characters.Font.ColorIndex = 15

    
    Dim SQL As String
   
    solic = Worksheets("Controle").Range("D3").Value
    vg = Worksheets("Controle").Range("G3").Value
    lote = Worksheets("Controle").Range("H3").Value
        
       
    SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila WHERE  "
    
    If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
    If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
    If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
    If lote = "" Or lote = "TODOS" Then
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St = 'OK'  AND Corte_St = 'OK' AND Exec_St <> 'OK' ORDER BY Prio,Ref;"
    Else
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St = 'OK'  AND Corte_St = 'OK' AND Exec_St <> 'OK' AND Lote = ' & lote & ' ORDER BY Prio,Ref;"
    End If
        
    Gerar_Lista (SQL)
    
    Sheets("Controle").Range("I3").Value = 4

    Reset
    
End Sub

Sub filtro_07()
    
    Desabilita

    Worksheets("Controle").Shapes("BT_01").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_01").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_02").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_02").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_03").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_03").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_04").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_04").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_05").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_05").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_06").ShapeStyle = msoShapeStylePreset4
    Worksheets("Controle").Shapes("BT_06").TextFrame.Characters.Font.ColorIndex = 15
    Worksheets("Controle").Shapes("BT_07").ShapeStyle = msoShapeStylePreset24
    Worksheets("Controle").Shapes("BT_07").TextFrame.Characters.Font.ColorIndex = 30
    
    Dim SQL As String
   
    solic = Worksheets("Controle").Range("D3").Value
    vg = Worksheets("Controle").Range("G3").Value
    lote = Worksheets("Controle").Range("H3").Value
        
       
    SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila WHERE  "
    
    If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
    If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
    If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
    If lote = "" Or lote = "TODOS" Then
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St = 'OK'  AND Corte_St = 'OK' AND Exec_St = 'OK' AND Tryout_St <> 'OK' ORDER BY Prio,Ref;"
    Else
        SQL = SQL & "Conceito_St = 'OK' AND Det_St = 'OK'  AND Liberacao_St = 'OK'  AND Corte_St = 'OK' AND Exec_St = 'OK' AND Tryout_St <> 'OK' AND Lote = ' & lote & ' ORDER BY Prio,Ref;"
    End If
        
    Gerar_Lista (SQL)
    
    Sheets("Controle").Range("I3").Value = 4

    Reset
    
End Sub

Sub lista_todos()
Limpar_botoes

Dim SQL As String

Desabilita

solic = Worksheets("Controle").Range("D3").Value
vg = Worksheets("Controle").Range("G3").Value
lote = Worksheets("Controle").Range("H3").Value
       
       
SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila WHERE  "
    
If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
If lote = "" Or lote = "TODOS" Then
    SQL = SQL & " 1 ORDER BY Prio,Ref;"
Else
    SQL = SQL & " Lote = ' & lote & ' ORDER BY Prio,Ref;"
End If
        
Gerar_Lista (SQL)

Sheets("Controle").Range("I3").Value = 7

Reset

End Sub

Sub lista_pendentes()
Limpar_botoes

Dim SQL As String

Desabilita

solic = Worksheets("Controle").Range("D3").Value
vg = Worksheets("Controle").Range("G3").Value
lote = Worksheets("Controle").Range("H3").Value
       
       
SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila WHERE  "
    
If solic <> "" And vg = "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
If solic <> "" And vg <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND Vagao = '" & vg & "' AND "
If solic = "" And vg <> "" Then SQL = SQL & "Vagao = '" & vg & "' AND "
    
If lote = "" Or lote = "TODOS" Then
    SQL = SQL & " Tryout_St <> 'OK' AND Tryout_St <> 'CANCELADO' AND Tryout_St <> 'NÂO OK' ORDER BY Prio,Ref;"
Else
    SQL = SQL & " Tryout_St <> 'OK' AND Tryout_St <> 'CANCELADO' AND Tryout_St <> 'NÂO OK' AND Lote = ' & lote & ' ORDER BY Prio,Ref;"
End If
        
Gerar_Lista (SQL)

Sheets("Controle").Range("I3").Value = 0

Reset



End Sub

Sub ListaValidacao()

Limpar_botoes

Dim SQL As String

Desabilita

solic = Worksheets("Controle").Range("D3").Value
       
SQL = "SELECT Ref, Descricao, Solicitante, Cod_Z, Aplicacao, Vagao, Lote, Prio, Conceito_St, Det_St, Liberacao_St, Aq_St, Corte_St, Exec_St, Tryout_St FROM Fila WHERE  "
If solic <> "" Then SQL = SQL & "Solicitante = '" & solic & "' AND "
SQL = SQL & "Det_St = '[VALIDAÇÃO]' ORDER BY Prio,Ref;"

        
Gerar_Lista (SQL)

Sheets("Controle").Range("I3").Value = 8

Reset

End Sub

Sub SincronizaMySQL()
    Dim http As Object
    Dim db As Object '
    Dim rs As Object '
    Dim csvConteudo As String
    Dim linhas() As String, campos() As String, cabecalho() As String
    Dim i As Long, j As Long
    Dim caminhoAccess As String, URL_CSV As String, urlFinal As String
    Dim totalColunasCSV As Integer, linhaAtual As String
    
   caminhoAccess = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB\DB_Projetos.accdb"

    
    ' 1. Sincroniza a Tabela FILA
    Debug.Print "Sincronizando Fila..."
    
    Call ExecutaImportacao("http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/csvAtualizado/fila", "Fila", caminhoAccess)
    
    ' 2. Sincroniza a Tabela PROJETOS
    Debug.Print "Sincronizando Projetos..."


    Call ExecutaImportacao("http://172.29.5.2/greenbrier/v2/solic_dispositivos/dispositivos/csvAtualizado/projetos", "Projetos", caminhoAccess)
    
   
    Call lista_todos
    MsgBox "Sincronização concluída para todas as tabelas!", vbInformation
End Sub

' --- FUNÇÃO AUXILIAR (O MOTOR QUE FAZ A IMPORTAÇÃO) ---
Private Sub ExecutaImportacao(ByVal urlBase As String, ByVal nomeTabela As String, ByVal caminhoDB As String)
    Dim http As Object, db As Object, rs As Object
    Dim csvConteudo As String, urlFinal As String, linhaAtual As String
    Dim linhas() As String, campos() As String, cabecalho() As String
    Dim i As Long, j As Long, totalColunasCSV As Integer

    urlFinal = urlBase & "?t=" & Timer
    Set http = CreateObject("MSXML2.ServerXMLHTTP") ' Mais seguro contra cache

    On Error Resume Next
    http.Open "GET", urlFinal, False
    http.Send
    
    If Err.Number <> 0 Or http.Status <> 200 Then
        MsgBox "Erro ao conectar com: " & urlBase, vbCritical
        Exit Sub
    End If
    On Error GoTo 0

    csvConteudo = http.responseText
    csvConteudo = Replace(csvConteudo, vbCrLf, vbLf)
    csvConteudo = Replace(csvConteudo, vbCr, vbLf)
    linhas = Split(csvConteudo, vbLf)

    If UBound(linhas) < 1 Then Exit Sub

    Set db = OpenDatabase(caminhoDB)
    db.Execute "DELETE FROM " & nomeTabela ' Limpa a tabela específica
    
    Set rs = db.OpenRecordset(nomeTabela)
    cabecalho = Split(linhas(0), ";")
    totalColunasCSV = UBound(cabecalho)

    For i = 1 To UBound(linhas)
        linhaAtual = Trim(linhas(i))
        If linhaAtual <> "" Then
            campos = Split(linhaAtual, ";")
            
            ' Só insere se a linha tiver o número mínimo de colunas do cabeçalho
            If UBound(campos) >= totalColunasCSV Then
                rs.AddNew
                For j = 0 To totalColunasCSV
                    Dim nomeCampo As String, valor As String
                    nomeCampo = Trim(cabecalho(j))
                    valor = Trim(Replace(campos(j), """", ""))
                    
                    On Error Resume Next
                    If valor = "" Then
                        rs(nomeCampo) = Null
                    Else
                        rs(nomeCampo) = valor
                    End If
                    Err.Clear
                    On Error GoTo 0
                Next j
                On Error GoTo ErroRegistro ' <--- Adicione isso antes do rs.Update
            rs.Update
            On Error GoTo 0
            End If
        End If
    Next i

    rs.Close
    db.Close
    
    Set rs = Nothing
    Set db = Nothing
    Set http = Nothing
    
    ' Atualiza a planilha para mostrar os novos dados
    Call lista_todos
    Exit Sub ' Saída normal da macro

ErroRegistro:
    MsgBox "Erro no registro da linha: " & i & vbCrLf & _
           "Conteúdo da linha: " & linhas(i) & vbCrLf & _
           "Erro: " & Err.Description, vbCritical, "Erro de Chave Primária"
    Resume Next ' Pula esse registro e continua o resto
    MsgBox "Sincronização concluída! O banco Access e a tela foram atualizados.", vbInformation
    
End Sub
```

---

