# Autor do histórico igual ao Access (casado por e-mail)

Faz o **nome do autor** gravado no histórico pelo **web** ficar igual ao que o
**Access** usa — casando os usuários pelo **e-mail**.

---

## 1. O problema

Os nomes vinham de **3 fontes diferentes**:

| Fonte | Nome | Onde |
|---|---|---|
| Login da intranet/Senior (web) | **nome completo** | `$_SESSION['usuarioNome']` — era o autor gravado pelo web |
| Tabela `usuarios` (web/MySQL) | `nome`, `email`, `matricula` | `/dispositivos/usuarios` |
| Tabela `Solicitantes` (Access) | `Nome` (curto) + `Email` | login + autor no Access (`frmsol`: `autor = lbl_solic`) |

Resultado: no mesmo histórico, comentário feito **no web** aparecia com o nome completo
e comentário feito **no Access** com o nome curto — inconsistente.

---

## 2. A solução (casar por e-mail)

1. Espelhar a lista de usuários do Access (`Solicitantes`: `Email` + `Nome`) numa tabela
   MySQL **`solicitantes_access`**.
2. Ao gravar o autor no web, **traduzir** o usuário logado → e-mail → `Nome` do Access.

```
Web grava comentário / validação / anexo
   → Usuario::nomeNoAccess():
        e-mail do logado  =  $_SESSION['user']['email]
                             ou  usuarios.email  (pela matrícula = usuarioLogin)
        → SELECT nome FROM solicitantes_access WHERE LOWER(email) = <e-mail>
        → usa esse nome como autor      (fallback: nome completo da sessão)
```

---

## 3. Componentes

### 3.1 MySQL — tabela `solicitantes_access`
Criada/populada automaticamente pelo endpoint (não precisa criar à mão):
```sql
CREATE TABLE IF NOT EXISTS bd_device_request.solicitantes_access (
    email VARCHAR(255) NOT NULL PRIMARY KEY,
    nome  VARCHAR(255) NOT NULL
);
```

### 3.2 PHP — `Usuario::nomeNoAccess()` (resolve o nome)
```php
public static function nomeNoAccess(): string
{
    $padrao = $_SESSION['usuarioNome'] ?? ($_SESSION['user']['nome'] ?? 'Sistema');

    try {
        $pdo = static::getPDO();

        // 1) e-mail do logado: da sessão, ou da tabela usuarios pela matrícula (login)
        $email = $_SESSION['user']['email'] ?? null;
        if (!$email && !empty($_SESSION['usuarioLogin'])) {
            $st = $pdo->prepare("SELECT email FROM bd_device_request.usuarios WHERE matricula = :m LIMIT 1");
            $st->execute([':m' => $_SESSION['usuarioLogin']]);
            $email = $st->fetchColumn() ?: null;
        }

        $email = strtolower(trim((string) $email));
        if ($email === '') return $padrao;

        // 2) nome do Access casando pelo e-mail
        $st = $pdo->prepare("SELECT nome FROM bd_device_request.solicitantes_access WHERE LOWER(email) = :e LIMIT 1");
        $st->execute([':e' => $email]);
        $nome = $st->fetchColumn();

        return $nome ?: $padrao;
    } catch (\Throwable $e) {
        return $padrao;
    }
}
```

### 3.3 PHP — onde é aplicado (autor = `Usuario::nomeNoAccess()`)
- `SolicitacaoController::registraHistorico` — caixa de comentário (sobrescreve o `usuario` do form).
- `SolicitacaoController::updateSituacao` — validar / cancelar / rejeitar.
- `DesenvolvimentoController::usuarioLogado()` — autor dos anexos do desenvolvimento.

### 3.4 PHP — endpoint que popula a tabela
`POST /dispositivos/solicitacao/uploadSolicitantesVba` → `SolicitacaoController::uploadSolicitantesVba`
(cria a tabela se não existir e regrava com `email<TAB>nome` por linha).

### 3.5 VBA — `Funcoes` (workbook **Solicitação**)
```vba
' Access -> Web: envia a lista de usuarios (Solicitantes: Email + Nome) para a tabela
' solicitantes_access (MySQL), usada para casar o autor do historico pelo e-mail.
Public Sub enviarSolicitantesParaMySQL()
    Dim arr As Variant
    Dim i As Long
    Dim payload As String
    Dim http As Object

    arr = resQuery("SELECT Email, Nome FROM Solicitantes WHERE Email Is Not Null AND Nome Is Not Null;")
    If IsEmpty(arr) Then
        MsgBox "Nenhum solicitante com e-mail encontrado.", vbExclamation
        Exit Sub
    End If

    payload = ""
    For i = 0 To UBound(arr, 2)
        If Not IsNull(arr(0, i)) And Not IsNull(arr(1, i)) Then
            payload = payload & LCase(Trim(arr(0, i))) & vbTab & Trim(arr(1, i)) & vbLf
        End If
    Next i

    If payload = "" Then
        MsgBox "Nenhum solicitante com e-mail encontrado.", vbExclamation
        Exit Sub
    End If

    On Error GoTo erro
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", urlBaseApp() & "/dispositivos/solicitacao/uploadSolicitantesVba", False
    http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
    http.send "dados=" & enc(payload)

    If http.Status = 200 Then
        MsgBox "Usuarios sincronizados!" & vbCrLf & http.responseText, vbInformation
    Else
        MsgBox "Falha ao enviar usuarios (HTTP " & http.Status & "):" & vbCrLf & http.responseText, vbExclamation
    End If
    Exit Sub
erro:
    MsgBox "Erro ao enviar usuarios:" & vbCrLf & Err.Description, vbCritical
End Sub
```

---

## 4. Como ativar

1. **Re-deploy** do PHP (`Usuario.php`, `SolicitacaoController.php`, `DesenvolvimentoController.php`, `routes.php`).
2. Colar o `Funcoes` atualizado no workbook **Solicitação** (`K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\vba_atualizado\Solicitacao_Funcoes.txt`).
3. Rodar a macro **`enviarSolicitantesParaMySQL`** 1× (cria + popula a `solicitantes_access`).
   Repetir sempre que a lista de usuários do Access mudar.

---

## 5. Limitações / notas

- Se o e-mail **não casar** (ou a tabela ainda não existir), cai no **nome completo da sessão** — não quebra.
- Casamento de e-mail é **case-insensitive** (gravado e comparado em minúsculas).
- Depende do **e-mail bater nas duas pontas**: `usuarios.email` (web/Senior) ↔ `Solicitantes.Email` (Access).
  Usuário sem e-mail em algum lado continua com o nome completo.
- Vale para o autor do **histórico**; não muda o login nem o nome em outras telas.

---

## 6. Arquivos-chave

| Item | Caminho |
|---|---|
| Resolver | `Usuario::nomeNoAccess()` |
| Endpoint (popula) | `SolicitacaoController::uploadSolicitantesVba` → `dispositivos/solicitacao/uploadSolicitantesVba` |
| Aplicado em | `registraHistorico`, `updateSituacao`, `DesenvolvimentoController::usuarioLogado` |
| Tabela | `bd_device_request.solicitantes_access (email, nome)` |
| VBA | `Funcoes.enviarSolicitantesParaMySQL` (workbook Solicitação) |
