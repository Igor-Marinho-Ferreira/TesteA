# Storage na arquitetura do Access + espelho mapeado

Mudança transversal (afeta imagem/PDF/DXF): o **storage do web** passou a usar as
**mesmas pastas e nomes do VBA** (arquitetura do Access), e o web salva **também**
num **storage-mapped** que você mapeia, pasta por pasta, no Windows.

> Substitui o mecanismo antigo (`{ref}/imagem/`, `{ref}/dxf/`… com nomes "seguros" +
> funções `copiar*ParaAccess`). Aquelas funções foram **removidas**.

---

## 1. Os 3 lugares

```
STORAGE (web)        /var/www/htdocs/greenbrier/v2/solic_dispositivos_files/
  └─ .img_sl/SL0001.jpg   .desenhos/SL0001 - COD.pdf   .dxf/DX0001.zip   ...
     (arquitetura do Access; é o que a UI do web baixa via solicitacao_anexo_arquivos.caminho)

STORAGE-MAPPED       APP_STORAGE_MAPPED (você mapeia CADA subpasta -> Windows K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\...)
  └─ mesma estrutura/nome — cópia 1:1 do storage, p/ o Access enxergar

-excel (APP_ACCESS_DIR)  = SÓ o mapeamento de K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB (o .accdb). NÃO guarda anexos.
```

| Direção | O que acontece |
|---|---|
| **Web cria** (UI) | `salvarArquivoSolicitacao` grava no STORAGE (arquit. Access) **e** espelha no STORAGE-MAPPED |
| **Access cria** (VBA) | `uploadImagem/DesenhoPdf/DxfVba` grava no STORAGE (arquit. Access). Não espelha (o Access já tem o arquivo) |

---

## 2. Mapa de pastas/nomes (caminhoAccess)

| Tipo | Subpasta | Nome do arquivo |
|---|---|---|
| `IMAGEM_PROJETO` | `.img_sl` | `SL{ref}.jpg` |
| `DESENHO_PDF` | `.desenhos` | `SL{ref} - {codigo}.pdf` |
| `PACOTE_DXF` | `.dxf` | `{codigo}.zip` (ex.: `DX0001.zip`) |
| `ITENS_COMPRADOS_TXT` | `itens_comprados` | nome único (Access não guarda o TXT — vira linhas) |

Pastas criadas no espelho (todas): `.Files .img_sl .img_z .imgs .desenhos desenhosPDF .dxf .cortes .bom`.

---

## 2.1 Mapa completo — onde cada arquivo cai no `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE`

| Tipo | Pasta | Nome do arquivo | Exemplo | Quem grava |
|---|---|---|---|---|
| PDF da criação (anexo da SL) | `.Files` | `SL{ref}.pdf` | `SL4001.pdf` | web + Access |
| ↳ anexos extras da criação | `.Files\SL{ref}\` | nome original | `.Files\SL4001\manual.pdf` | web + Access |
| Imagem do projeto | `.img_sl` | `SL{ref}.jpg` | `SL4001.jpg` | web + Access |
| Imagem do Z (ficha resumo) | `.img_z` | `{cod_z}.jpg` | `Z123.jpg` | só Access |
| Desenhos PDF | `.desenhos` | `SL{ref} - {codigo}.pdf` | `SL4001 - DESENHO01.pdf` | web + Access |
| ↳ 2ª via dos desenhos | `desenhosPDF\SL{ref}\` | `SL{ref} - {codigo}.pdf` | `desenhosPDF\SL4001\SL4001 - DESENHO01.pdf` | só Access |
| Pacote DXF (zip) | `.dxf` | `{codigo}.zip` | `DX0001.zip` | web + Access |
| Imagem do DXF | `.imgs` | `{codigo}.jpg` | `DX0001.jpg` | só Access |
| Cortes (PDFs individuais) | `.cortes` | `{controle}-{página}.pdf` | `DX0001-CORTE_A.pdf` | só Access |
| BOM (Lista de Materiais) | `.bom` | `{cod_z} - SL{ref} - Lista_Materiais.xlsx` | `Z123 - SL4001 - Lista_Materiais.xlsx` | só Access |
| Banco Access | `DB` | `DB_Projetos.accdb` | — | — |

**Quem grava cada pasta:**
- **Web grava** (no storage **e** no espelho mapeado → cai no D:): `.Files`, `.img_sl`, `.desenhos`, `.dxf`.
- **Só o Access (VBA) grava** (web ainda não cuida): `.img_z`, `.imgs`, `.cortes`, `.bom`, `desenhosPDF`.

**Notas:**
- O **`.cortes`** (`frm_dxf`, botões ver01–ver10) ainda abre de **`F:\eng_ind\...`** — não migrado (não fez parte das fatias). Trocar para `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.cortes` quando for usar o "ver corte".
- O **`.bom` (.xlsx)** não é sincronizado pelo web — o web sincroniza só as **linhas** da BOM (`BOM_Control` ↔ `solicitacao_itens_comprados`); o arquivo `.xlsx` fica só no Access.

---

## 3. Código — helpers novos (`DesenvolvimentoController`)

```php
private function storageBase(): string
{
    return '/var/www/htdocs/greenbrier/v2/solic_dispositivos_files';
}

private function caminhoAccess(string $tipo, string $ref, ?string $codigo, string $nomeOriginal): array
{
    $sl  = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT);
    $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));
    $cod = trim((string) $codigo);

    switch ($tipo) {
        case 'IMAGEM_PROJETO':
            return ['.img_sl', $sl . '.jpg'];
        case 'DESENHO_PDF':
            $c = $cod !== '' ? $cod : pathinfo($nomeOriginal, PATHINFO_FILENAME);
            return ['.desenhos', $sl . ' - ' . $c . '.pdf'];
        case 'PACOTE_DXF':
            return ['.dxf', ($cod !== '' ? $cod : $sl) . '.zip'];
        case 'ITENS_COMPRADOS_TXT':
            return ['itens_comprados', $sl . '_' . $this->gerarNomeArquivoSeguro($ref, $tipo, $ext ?: 'txt')];
        default:
            $pasta = strtolower(preg_replace('/[^a-z0-9_]+/i', '_', $tipo));
            return [$pasta, $this->gerarNomeArquivoSeguro($ref, $tipo, $ext)];
    }
}

private function espelharNoMapeado(string $subpasta, string $nomeArquivo, string $caminhoFisicoStorage): void
{
    if (!is_file($caminhoFisicoStorage)) return;
    $base = rtrim($_ENV['APP_STORAGE_MAPPED'] ?? '', " \t\n\r\0\x0B/\\");
    if ($base === '') return;
    $dir = $base . '/' . $subpasta;
    if (!is_dir($dir)) @mkdir($dir, 0777, true);
    @copy($caminhoFisicoStorage, $dir . '/' . $nomeArquivo);
}
```

---

## 4. `salvarArquivoSolicitacao` — ANTES × DEPOIS (trecho do save)

**ANTES** (por `{ref}/{tipo}` + nome seguro, sem espelho):
```php
        if (!is_dir($diretorioFisico)) { mkdir($diretorioFisico, 0777, true); }
        $nomeOriginal = $arquivo['name'];
        $extensao = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));
        $nomeSeguro = $this->gerarNomeArquivoSeguro($ref, $tipo, $extensao);
        $caminhoFisico = "{$diretorioFisico}/{$nomeSeguro}";
        $caminhoRelativo = "{$diretorioRelativo}/{$nomeSeguro}";
        if (!move_uploaded_file($arquivo['tmp_name'], $caminhoFisico)) { ... }
```

**DEPOIS** (arquitetura do Access + espelho):
```php
        $nomeOriginal = $arquivo['name'];
        [$subpasta, $nomeArquivo] = $this->caminhoAccess($tipo, $ref, $codigo, $nomeOriginal);
        $dirStorage = $this->storageBase() . '/' . $subpasta;
        if (!is_dir($dirStorage)) { mkdir($dirStorage, 0777, true); }
        $caminhoFisico   = $dirStorage . '/' . $nomeArquivo;
        $caminhoRelativo = $subpasta . '/' . $nomeArquivo;
        if (!move_uploaded_file($arquivo['tmp_name'], $caminhoFisico)) { ... }
        $this->espelharNoMapeado($subpasta, $nomeArquivo, $caminhoFisico);   // <- novo
```

Os uploads do VBA (`uploadImagemVba`, `uploadDesenhoPdfVba`, `uploadDxfVba`) usam o
mesmo `caminhoAccess` + `storageBase`, mas **sem** `espelharNoMapeado` (o arquivo já
está no Access).

---

## 5. `.env`

```ini
# -excel = SÓ o mapeamento da pasta do banco (K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\DB, o .accdb).
APP_ACCESS_DIR=/var/www/html/greenbrier/v2/solic_dispositivos-excel
# Espelho dos arquivos na arquitetura do Access (você mapeia cada subpasta no Windows).
APP_STORAGE_MAPPED=/var/www/html/greenbrier/v2/solic_dispositivos-storage-mapped
```

---

## 6. Criar as subpastas no espelho

Rota (1×): `GET /dispositivos/desenvolvimento/garantirStorageMapeado` →
```php
public function garantirStorageMapeado()
{
    $base = rtrim($_ENV['APP_STORAGE_MAPPED'] ?? $_ENV['APP_ACCESS_DIR'] ?? '', " \t\n\r\0\x0B/\\");
    ...
    $subpastas = ['.Files', '.img_sl', '.img_z', '.imgs', '.desenhos', 'desenhosPDF', '.dxf', '.cortes', '.bom'];
    // mkdir idempotente de cada uma; devolve {base, criadas, existentes}
}
```
Ou no servidor:
```bash
mkdir -p /var/www/html/greenbrier/v2/solic_dispositivos-storage-mapped/{.Files,.img_sl,.img_z,.imgs,.desenhos,desenhosPDF,.dxf,.cortes,.bom}
```

---

## 7. Limitações / notas

- A **UI do web** baixa via `solicitacao_anexo_arquivos.caminho` (= `subpasta/nome`),
  resolvido por `resolverCaminhoArquivo` sob o `storageBase`. **Registros antigos**
  (com caminho no formato velho `{ref}/imagem/...`) continuam válidos enquanto o
  arquivo físico existir; novos arquivos usam o formato novo.
- **`ITENS_COMPRADOS_TXT`** não tem pasta equivalente no Access (vira linhas em
  `BOM_Control`) — fica em `itens_comprados/` só no storage do web.
- Fluxo de **criação** (`.Files`, tabela `anexos`) segue pelo `copiarAnexosParaAccess`
  (SolicitacaoController), que também usa `APP_STORAGE_MAPPED`.
