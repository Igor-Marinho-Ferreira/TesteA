# Automação da sincronização (Agendador de Tarefas do Windows)

Mantém o **Access sempre sincronizado** com o web, rodando os **pulls** (web → Access)
de tempos em tempos, sem ninguém clicar em botão.

> **Só o PULL precisa de agendamento.** O **push** (Access → web) já é em **tempo real**
> (dispara quando o usuário cria SL, comenta, troca status, sobe imagem/PDF/DXF/BOM).
> O que precisa de agenda é trazer de volta o que mudou **na web**.

```
Agendador de Tarefas (a cada X min)
   → wscript  sync_access.vbs
       → abre o Excel (oculto, sem eventos)
           → roda as macros de PULL (modo silencioso)
               → grava na Fila/PDF_Control/DXF_Control/BOM_Control do Access
       → fecha o Excel
```

---

## 1. Quais sincronizações entram

| Macro (pull) | Workbook | O que traz pro Access |
|---|---|---|
| `sincronizarDoMySQL` | **Solicitação** | Fila: dados, status, **projetista**, histórico, **datas/tempo** |
| `sincronizarPdfsDoMySQL` | **Lista** | `PDF_Control` (desenhos PDF criados na web) |
| `sincronizarDxfsDoMySQL` | **Lista** | `DXF_Control` (pacotes DXF criados na web) |
| `sincronizarBomDoMySQL` | **Lista** | `BOM_Control` (itens de BOM criados na web) |

*(Opcionais, rodar só quando a lista muda — não precisam de alta frequência:
`enviarSolicitantesParaMySQL`, `enviarFeriadosParaMySQL`.)*

---

## 2. Pré-requisito: modo silencioso (tirar o `MsgBox`)

As macros terminam com `MsgBox "Sincronização concluída..."`. Numa execução automática
isso **trava** (a caixa fica esperando alguém clicar OK). Solução: uma **flag silenciosa**
+ um **wrapper** que o `.vbs` chama.

### 2.1 Em **cada** workbook (módulo `Funcoes`), adicione no topo:
```vba
Public gSyncSilencioso As Boolean   ' True = sincronizações não mostram MsgBox
```

### 2.2 Wrapper — no workbook **Solicitação** (`Funcoes`):
```vba
' Roda o pull da Fila em modo silencioso (chamado pelo Agendador via VBS)
Public Sub sincronizarTudoAuto()
    gSyncSilencioso = True
    On Error Resume Next
    sincronizarDoMySQL
    gSyncSilencioso = False
End Sub
```

### 2.3 Wrapper — no workbook **Lista** (`Funcoes`):
```vba
' Roda os pulls do desenvolvimento em modo silencioso
Public Sub sincronizarTudoAuto()
    gSyncSilencioso = True
    On Error Resume Next
    sincronizarPdfsDoMySQL
    sincronizarDxfsDoMySQL
    sincronizarBomDoMySQL
    gSyncSilencioso = False
End Sub
```

### 2.4 Guardar os `MsgBox` das sincronizações
Em cada `sincronizar*`, troque os `MsgBox` (o de sucesso no fim **e** os do `erro:`)
para só aparecerem quando NÃO for automático. Ex.:
```vba
' ANTES
MsgBox "Sincronização concluída." & vbCrLf & "Inseridos: " & inseridos & ...

' DEPOIS
If Not gSyncSilencioso Then MsgBox "Sincronização concluída." & vbCrLf & "Inseridos: " & inseridos & ...
```
(idem para os `MsgBox` dentro dos blocos `erro:` / `ERRO:`).

---

## 3. O script VBS — `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\sync_access.vbs`

```vbscript
Option Explicit
Dim xl, wb, base, fso, log
base = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\"

' log simples
Set fso = CreateObject("Scripting.FileSystemObject")
Set log = fso.OpenTextFile(base & "sync_access.log", 8, True) ' 8 = append
log.WriteLine Now & "  - inicio"

On Error Resume Next
Set xl = CreateObject("Excel.Application")
xl.Visible = False
xl.DisplayAlerts = False
xl.EnableEvents = False          ' nao dispara Workbook_Open (login/setup)
xl.AutomationSecurity = 1        ' msoAutomationSecurityLow (pasta e Local Confiavel)

' --- Solicitacao: pull da Fila ---
Set wb = xl.Workbooks.Open(base & "Solicitação de Projeto_RevE1.xlsm", 0, True) ' ReadOnly
If Not wb Is Nothing Then
    xl.Run "'" & wb.Name & "'!sincronizarTudoAuto"
    wb.Close False
    Set wb = Nothing
End If

' --- Lista: pull do desenvolvimento ---
Set wb = xl.Workbooks.Open(base & "Lista de Solicitações de Projeto_RevE.xlsm", 0, True)
If Not wb Is Nothing Then
    xl.Run "'" & wb.Name & "'!sincronizarTudoAuto"
    wb.Close False
    Set wb = Nothing
End If

xl.Quit
Set xl = Nothing

log.WriteLine Now & "  - fim"
log.Close
```

Notas do VBS:
- `EnableEvents = False` evita o `Workbook_Open`; `ReadOnly` (3º arg `True`) evita conflito
  se o workbook já estiver aberto pelo usuário.
- Roda as macros **qualificadas pelo nome do workbook** (`'nome'!macro`) — seguro mesmo com
  os dois abertos.
- Grava `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\sync_access.log` (início/fim de cada execução).

---

## 4. Agendar no Windows

### Opção A — linha de comando (Prompt como Admin)
A cada **5 minutos**:
```cmd
schtasks /Create /SC MINUTE /MO 5 /TN "SyncAccessMySQL" ^
  /TR "wscript.exe \"K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\sync_access.vbs\"" /RL LIMITED /F
```
- `/SC MINUTE /MO 5` = a cada 5 min · `/TN` = nome · `/TR` = o que roda · `/F` = sobrescreve.
- Conferir/rodar na hora: `schtasks /Run /TN "SyncAccessMySQL"` · Apagar: `schtasks /Delete /TN "SyncAccessMySQL" /F`.

### Opção B — pela interface (Agendador de Tarefas)
1. **Criar Tarefa** (não "tarefa básica").
2. **Disparadores** → Novo → "Repetir a cada **5 minutos**" por tempo indefinido.
3. **Ações** → Novo → Programa: `wscript.exe` · Argumentos: `"K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\sync_access.vbs"`.
4. **Configurações** → marcar **"Não iniciar nova instância se já estiver em execução"**
   (evita acúmulo se um ciclo demorar).

---

## 5. Cuidados / limitações

- **Local Confiável:** `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` já é Local Confiável no Excel (macros rodam sem prompt).
  Se mudar de máquina/pasta, reconfigurar.
- **Access aberto:** se o `.accdb` estiver aberto (Access em uso), o `OpenDatabase` falha e
  aquele ciclo é pulado (em silêncio) — sincroniza no próximo. Sem perda de dados.
- **Intervalo:** 5 min é um bom começo. Pull mais frequente = mais carga; menos frequente =
  Access "atrasa" mais. Ajuste no `/MO`.
- **Usuário logado / sessão:** a tarefa roda com a conta configurada; rode com um usuário que
  tenha acesso ao `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` (e à rede, se a pasta for mapeada).
- **`enviarSolicitantesParaMySQL` / `enviarFeriadosParaMySQL`:** não precisam ser frequentes —
  rode manualmente quando a lista de usuários/feriados mudar (ou crie uma 2ª tarefa diária).
- Só o **pull** é agendado; o **push** continua em tempo real (não mexer).

---

## 6. Resumo do que fazer

1. Adicionar `gSyncSilencioso` + `sincronizarTudoAuto` nos 2 workbooks e guardar os `MsgBox` (seção 2).
2. Salvar o `sync_access.vbs` em `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE` (seção 3).
3. Criar a tarefa no Agendador (seção 4).
4. Conferir o `sync_access.log` e a Fila do Access depois do 1º ciclo.
