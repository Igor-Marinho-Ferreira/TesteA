# Código completo — Anexos: MySQL → Access

Companheiro de [anexos-mysql-access.md](anexos-mysql-access.md).

Índice:
1. PHP — `.env`
2. PHP — `storeSolicitacao` (gatilho) + `copiarAnexosParaAccess`
3. VBA — `frmsol` (caminhos: antes / depois)

---

## 1. PHP — `.env`

**Adicionado:**
```
APP_UPLOADS_EXCEL=/var/www/html/greenbrier/v2/solic_dispositivos-excel/Fila.xlsx
APP_ACCESS_DIR=/var/www/html/greenbrier/v2/solic_dispositivos-excel
```

---

## 2. PHP — `src/app/controllers/SolicitacaoController.php`

### 2.1 Gatilho dentro do `storeSolicitacao`

```php
            $executeAnexos = Solicitacao::storeRepeticao($anexos2save, $solicitacao['ref'], 'bd_device_request.anexos');

            // [ADICIONADO] Copia os anexos para a pasta do Access (web -> Access)
            $this->copiarAnexosParaAccess($solicitacao['ref'], $anexos2save);
```

### 2.2 Método `copiarAnexosParaAccess` (novo)

```php
    /**
     * Copia os anexos enviados pela web para a pasta do Access (pasta mapeada/montada).
     * 1º PDF -> .Files/SL{ref}.pdf (o que o Access abre); os demais -> .Files/SL{ref}/.
     */
    private function copiarAnexosParaAccess($ref, array $anexos): void
    {
        if (empty($anexos)) return;

        $base = rtrim($_ENV['APP_ACCESS_DIR'] ?? '', " \t\n\r\0\x0B/\\");
        if ($base === '') return; // sem pasta mapeada configurada -> não faz nada

        $filesDir = $base . '/.Files';
        if (!is_dir($filesDir)) @mkdir($filesDir, 0777, true);

        $refFmt = 'SL' . str_pad((string) $ref, 4, '0', STR_PAD_LEFT); // ex.: SL4001
        $pdfPrincipalUsado = false;

        foreach ($anexos as $a) {
            $origem = $a['anexo'] ?? '';
            if ($origem === '' || !is_file($origem)) continue;

            $ext = strtolower(pathinfo($origem, PATHINFO_EXTENSION));

            if (!$pdfPrincipalUsado && $ext === 'pdf') {
                @copy($origem, $filesDir . '/' . $refFmt . '.pdf');   // .Files/SL{ref}.pdf
                $pdfPrincipalUsado = true;
            } else {
                $sub = $filesDir . '/' . $refFmt;
                if (!is_dir($sub)) @mkdir($sub, 0777, true);
                @copy($origem, $sub . '/' . basename($origem));       // extras em .Files/SL{ref}/
            }
        }
    }
```

---

## 3. VBA — `frmsol` (caminhos)

A mudança foi trocar o prefixo dos caminhos. Aplicável com 2 substituições (Ctrl+H) no módulo:

- `K:\eng_ind\PROJETOS_Controle_bkp\Eng_Processos\Projeto_RevE\` → `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\`
- `K:\eng_ind\PROJETOS_Controle_bkp\Controle\` → `K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\`

### Os 5 pontos (antes → depois)

```vba
' btn_pdf_Click (imagem do código Z)
' ANTES:
With ActiveSheet.Pictures.Insert("K:\eng_ind\PROJETOS_Controle_bkp\Controle\.img_z\" & cod_z & ".jpg")
' DEPOIS:
With ActiveSheet.Pictures.Insert("K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_z\" & cod_z & ".jpg")


' btnBOM_Click (lista de materiais)
' ANTES:
Workbooks.Open Filename:="K:\eng_ind\PROJETOS_Controle_bkp\Controle\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True
' DEPOIS:
Workbooks.Open Filename:="K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.bom\" & cod_z & " - " & cod_sl & " - Lista_Materiais.xlsx", ReadOnly:=True


' btnVisualizar_Click (PDF da SL) — 2 ocorrências
' ANTES:
strFileName = "K:\eng_ind\PROJETOS_Controle_bkp\Eng_Processos\Projeto_RevE\.Files\" & lbl_ref.Caption & ".pdf"
...
ActiveWorkbook.FollowHyperlink "K:\eng_ind\PROJETOS_Controle_bkp\Eng_Processos\Projeto_RevE\.Files\" & lbl_ref.Caption & ".pdf"
' DEPOIS:
strFileName = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & lbl_ref.Caption & ".pdf"
...
ActiveWorkbook.FollowHyperlink "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.Files\" & lbl_ref.Caption & ".pdf"


' lbl_abrir_Click (imagem da SL)
' ANTES:
tgtfile = "K:\eng_ind\PROJETOS_Controle_bkp\Controle\.img_sl\" & frmsol.lbl_ref.Caption & ".jpg"
' DEPOIS:
tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.img_sl\" & frmsol.lbl_ref.Caption & ".jpg"


' pdf_lst_DblClick (desenhos)
' ANTES:
tgtfile = "K:\eng_ind\PROJETOS_Controle_bkp\Controle\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
' DEPOIS:
tgtfile = "K:\eng_ind\PROJETOS_Controle\Eng_Processos\Projeto_RevE\.desenhos\" & Me.lbl_ref.Caption & " - " & codigo & ".pdf"
```

> O `frmsol` completo (todas as Subs) é o módulo que você já colou — só esses 5 caminhos mudaram.
> O `btnVisualizar` monta o nome com `lbl_ref.Caption & ".pdf"`; precisa ser `SL` + 4 dígitos
> (ex.: `SL4001`) para casar com o `SL{ref}.pdf` salvo pelo PHP.
